"""Read-only, field-level Cash conflict evidence. Never selects a winning price."""
import datetime as dt
from collections import Counter
from pathlib import Path
from model.cash_recovery import identity,enrich,source_rows
from model.cash_restore import require,guard
from model.cash_inventory_preview import check_rows
from model.config.market_calendar import IST
from model.quality import stamp,canonical,COMPARE_FIELDS,MAX_PARTITION_ROWS
from model.storage_inventory import safe_root


def field_comparison(sql,parquet,sample_limit=20):
    def index(rows):
        require(len(rows)<=MAX_PARTITION_ROWS,'row_limit')
        result={}
        for row in rows:
            ts=stamp(row['candle_timestamp'])
            require(ts not in result,'duplicate_timestamp_comparison_ambiguous')
            result[ts]=row
        return result
    a,b=index(sql),index(parquet)
    counts=Counter();samples=[];market_rows=metadata_rows=invalid_rows=0
    for ts in sorted(a.keys()&b.keys()):
        changes={};invalid=False
        for field in COMPARE_FIELDS:
            try:
                av=canonical(a[ts].get(field),field);bv=canonical(b[ts].get(field),field)
                if av!=bv:
                    counts[field]+=1
                    changes[field]={'sql':av,'parquet':bv}
            except Exception:
                invalid=True
                counts['uncomparable_'+field]+=1
                changes[field]={'sql':str(a[ts].get(field)),'parquet':str(b[ts].get(field)),'invalid':True}
        market=any(f in changes for f in ('open','high','low','close','volume'))
        if invalid:invalid_rows+=1
        elif market:market_rows+=1
        elif changes:metadata_rows+=1
        if changes and len(samples)<sample_limit:samples.append({'timestamp':ts.isoformat(),'fields':changes})
    left=sorted(a.keys()-b.keys());right=sorted(b.keys()-a.keys())
    category=('UNCOMPARABLE_VALUES' if invalid_rows else 'MARKET_VALUE_DIFFERENCES' if market_rows else
              'KEY_DIFFERENCES' if left or right else 'METADATA_ONLY' if metadata_rows else 'EXACT')
    return {'category':category,'sql_only':len(left),'parquet_only':len(right),
            'sql_only_samples':[x.isoformat() for x in left[:sample_limit]],
            'parquet_only_samples':[x.isoformat() for x in right[:sample_limit]],
            'market_value_rows':market_rows,'metadata_only_rows':metadata_rows,'uncomparable_rows':invalid_rows,
            'field_counts':dict(counts),'samples':samples,'sample_limit':sample_limit}


def audit_conflicts(preview,scope,root,store,now=None,progress=None):
    root=safe_root(root);now=now or dt.datetime.now(IST)
    require(preview.get('format_version')==1 and preview.get('complete') is True,'complete_preview_required')
    require(scope.get('operation')=='INSERT_ONLY_CASH_RECOVERY' and scope.get('format_version')==1,'invalid_scope_plan')
    require(Path(scope['target_root']).resolve()==root,'configured_root_changed')
    wanted=[e for e in scope['entries'] if e['status']=='UNRESOLVED']
    require(len({e['relative_path'] for e in wanted})==len(wanted),'duplicate_scope_partition')
    available={}
    for p in preview['partitions']:
        require(p['relative_path'] not in available,'duplicate_preview_partition')
        available[p['relative_path']]=p
    results=[]
    for i,e in enumerate(wanted,1):
        out={'relative_path':e['relative_path'],'prior_reason':e.get('reason'),'variants':[]}
        try:
            rel=e['relative_path'];require(rel in available,'partition_missing_from_preview')
            symbol,day=identity(rel);meta=store.metadata(symbol)
            sql=enrich(store.rows(meta['id'],day),symbol)
            out['sql_quality']=check_rows(sql,symbol,day,now);out['sql_rows']=len(sql)
            variants=available[rel]['variants'];require(len(variants)<=20,'variant_limit')
            for v in variants:
                detail={'source':v.get('path')}
                try:
                    path=guard(v['path']);size=path.stat().st_size
                    rows=source_rows({'source':str(path),'sha256':v['sha256'],'bytes':size})
                    detail.update(sha256=v['sha256'],rows=len(rows),quality=check_rows(rows,symbol,day,now),
                        metadata_matches=all(all(str(r.get(k))==str(meta[k]) for k in ('internal_name','exchange','instrument_type')) for r in rows),
                        comparison=field_comparison(sql,rows),status='COMPARED')
                except Exception as exc:
                    detail.update(status='ERROR',error=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
                out['variants'].append(detail)
            require(sql==enrich(store.rows(meta['id'],day),symbol) and meta==store.metadata(symbol),'SQL_changed_during_audit')
            out['status']='PARTIAL' if any(v['status']=='ERROR' for v in out['variants']) else 'CHECKED'
        except Exception as exc:
            out.update(status='ERROR',error=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
        results.append(out)
        if progress:progress(i,len(wanted))
    comparisons=[v['comparison'] for e in results if e['status']!='ERROR' for v in e['variants'] if v['status']=='COMPARED']
    return {'format_version':1,'operation':'READ_ONLY_CASH_FIELD_AUDIT','created_at':now.isoformat(),
            'complete':all(e['status']=='CHECKED' for e in results),'data_modified':False,
            'summary':{'partitions':len(results),'statuses':dict(Counter(e['status'] for e in results)),
                'variant_categories':dict(Counter(c['category'] for c in comparisons)),
                'field_counts':dict(sum((Counter(c['field_counts']) for c in comparisons),Counter()))},
            'entries':results,'scope':'SQL versus preview source variants for unresolved partitions only. Counts are per variant and may overlap. Samples bounded; field counts cover all matched timestamps. Session findings reflect configured calendar, not independent exchange verification. No target parity certification or automatic repair.'}
