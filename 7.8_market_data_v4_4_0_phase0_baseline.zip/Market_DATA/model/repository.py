"""
model/repository.py
THE stable read API for every OTHER module (Indicator Engine, Strategy
Framework, Paper Trading, etc.) that needs market data. Those modules
should import MarketDataRepository -- never reach into
model/storage/mysql.py or model/storage/parquet.py directly.

Why this exists:
    Without this, every future consumer would have to know whether
    MySQL or Parquet is enabled, how to build a DB engine/URL, and how
    each storage backend's read function is shaped. That knowledge
    would get duplicated everywhere. This class is the ONE place that
    knowledge lives -- if storage internals change later, only this
    file needs to change, not every downstream module.

Backend selection (mirrors main.py's build_1m_reader, generalized to
any timeframe): prefers MySQL if enabled (better for arbitrary date-
range random access), falls back to Parquet, raises a clear error if
neither is enabled -- never silently returns empty data when no
backend is configured.
"""

import logging
from typing import Optional

from model.config.env_loader import EnvConfig
from model.config.data_settings import DataSettings
from model.config.instrument_loader import InstrumentRegistry, Instrument
from model.processing.models import Candle

log = logging.getLogger("market_data.repository")


class NoStorageBackendError(Exception):
    """Raised when neither MySQL nor Parquet storage is enabled, so
    there is nothing to read from. Callers should treat this as a
    configuration problem, not silently proceed with no data."""


class MarketDataRepository:
    """
    Usage (from ANY other module):
        from model.repository import MarketDataRepository
        repo = MarketDataRepository(env, data_settings, instruments)
        candles = repo.get_candles("SBIN", "5m", "2024-01-01", "2024-01-31")
        latest = repo.get_latest_candle("SBIN", "1m")
        active = repo.list_instruments(active_only=True)
    """

    def __init__(self, env: EnvConfig, data_settings: DataSettings, instruments: InstrumentRegistry):
        self._env = env
        self._data_settings = data_settings
        self._instruments = instruments
        self._mysql_engine = None  # lazily created, at most once
        self._parquet_sink = None

    def _get_mysql_engine(self):
        if self._mysql_engine is None:
            from model.storage.mysql import build_db_url, get_engine
            db_url = build_db_url(
                self._env.db.host, self._env.db.port, self._env.db.name, self._env.db.user, self._env.db.password,
            )
            self._mysql_engine = get_engine(db_url)
        return self._mysql_engine

    def _get_parquet_sink(self):
        if self._parquet_sink is None:
            from model.storage.parquet import ParquetCandleSink
            self._parquet_sink = ParquetCandleSink()
        return self._parquet_sink

    def _resolve_instrument(self, internal_name: str) -> Instrument:
        try:
            return self._instruments.get(internal_name)
        except KeyError:
            raise ValueError(f"Unknown instrument: '{internal_name}' is not configured in stocks.yaml/indices.yaml")

    def get_candles(self, internal_name: str, timeframe: str, from_date: str, to_date: str) -> list:
        """
        Returns candles for one instrument/timeframe/date-range,
        sorted ascending by timestamp. Raises NoStorageBackendError if
        neither MySQL nor Parquet is enabled. Raises ValueError for an
        unconfigured internal_name -- never silently returns [] for a
        typo'd symbol, so callers don't mistake "no data" for "no such
        instrument".
        """
        instrument = self._resolve_instrument(internal_name)

        if self._data_settings.storage.mysql_enabled:
            from model.storage.mysql import read_candles
            return read_candles(self._get_mysql_engine(), instrument.fyers_symbol, timeframe, from_date, to_date, instrument)

        if self._data_settings.storage.parquet_enabled:
            return self._get_parquet_sink().read_candles(instrument.fyers_symbol, timeframe, from_date, to_date)

        raise NoStorageBackendError(
            "Neither MySQL nor Parquet storage is enabled in config/data_settings.yaml -- "
            "there is nothing to read candles from."
        )

    def iter_verified_days(self, internal_name, timeframe, from_date, to_date, *, session="all", audit=None):
        """Bounded, strict historical analysis reads; raises on incomplete evidence."""
        from model.verified_reads import iter_verified_days
        return iter_verified_days(self,internal_name,timeframe,from_date,to_date,session=session,audit=audit)

    def get_candles_df(self, internal_name: str, timeframe: str, from_date: str, to_date: str):
        """
        Same as get_candles(), but returns a pandas DataFrame instead
        of a list[Candle] -- the shape most indicator/statistics code
        (pandas/numpy-based RSI, EMA, rolling stats, etc.) actually
        wants to work with, so future modules don't all have to write
        their own "list of dataclasses -> DataFrame" conversion.

        Columns: timestamp (index), open, high, low, close, volume,
        status. timestamp is set as the DataFrame index, sorted
        ascending, since that's the conventional shape for time-series
        indicator calculations (e.g. df['close'].rolling(14).mean()).
        """
        import pandas as pd

        candles = self.get_candles(internal_name, timeframe, from_date, to_date)
        if not candles:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume", "status"])

        rows = [{
            "timestamp": c.timestamp, "open": c.open, "high": c.high, "low": c.low,
            "close": c.close, "volume": c.volume, "status": c.status,
        } for c in candles]

        df = pd.DataFrame(rows).set_index("timestamp").sort_index()
        return df

    def get_candles_multi(self, internal_names: list, timeframe: str, from_date: str, to_date: str) -> dict:
        """
        Bulk read across MULTIPLE instruments in one call -- e.g. an
        Indicator Engine computing RSI for 50 stocks doesn't need to
        call get_candles() 50 times itself. Returns {internal_name:
        list[Candle]}. An instrument with no data gets an empty list,
        not a missing key -- callers can always safely index the
        result by every name they asked for.

        Note: this is a convenience loop, not a single optimized bulk
        SQL query -- for MySQL, that means one query per instrument
        under the hood (via get_candles()), same total DB round-trips
        as calling get_candles() yourself in a loop. It exists for the
        cleaner call-site ergonomics and the guaranteed all-keys-present
        return shape, not for raw performance. If/when this becomes a
        real bottleneck at your data volume, replace the loop body with
        a single multi-symbol SQL query -- callers of this method won't
        need to change.
        """
        result = {}
        for name in internal_names:
            try:
                result[name] = self.get_candles(name, timeframe, from_date, to_date)
            except ValueError:
                log.warning(f"get_candles_multi: skipping unknown instrument '{name}'")
                result[name] = []
        return result

    def get_latest_candle(self, internal_name: str, timeframe: str) -> Optional[Candle]:
        """
        Convenience wrapper: returns the most recent candle for an
        instrument/timeframe, or None if there is none yet. Looks back
        up to 7 calendar days to find it (handles weekends/holidays
        without needing a trading calendar) -- returns None rather
        than guessing if nothing is found in that window.
        """
        import datetime
        today = datetime.date.today()
        lookback_start = (today - datetime.timedelta(days=7)).isoformat()

        candles = self.get_candles(internal_name, timeframe, lookback_start, today.isoformat())
        if not candles:
            return None
        return max(candles, key=lambda c: c.timestamp)

    def list_instruments(self, active_only: bool = True) -> list:
        return self._instruments.active_instruments() if active_only else self._instruments.all_instruments()

    def has_storage_backend(self) -> bool:
        return self._data_settings.storage.mysql_enabled or self._data_settings.storage.parquet_enabled
