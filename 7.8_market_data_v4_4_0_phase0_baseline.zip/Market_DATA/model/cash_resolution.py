"""Preserve session-only matches and stage provider candidates without overwrites."""
import datetime as dt
import shutil
import uuid
from collections import Counter
from pathlib import Path
from model.cash_recovery import identity,enrich,source_rows,equal,write_json_new
from model.cash_restore import guard,require
from model.cash_inventory_preview import check_rows
from model.cash_conflict_audit import field_comparison
from model.quality import integrity,stamp
from model.config.market_calendar import IST
from model.storage_inventory import fingerprint,safe_root


def classify_session(rows,symbol,day,now):
    q=check_rows(rows,symbol,day,now)
    reasons=Counter();outside=[];regular=[];other=0
    for row in rows:
        errors=[r for s in integrity([row],'1m',day,now)['samples'] for r in s['reasons']]
        reasons.update(errors)
        if any(r!='outside_session' for r in errors):other+=1
        (outside if 'outside_session' in errors else regular).append(row)
    blocked=set(q['issues'])-{'integrity_findings'}
    review=set(q['review_reasons'])-{'calendar_not_verified','incomplete_minute_coverage'}
    require(not blocked and not review and not other,'non_session_quality_findings')
    return {'regular_rows':len(regular),'outside_session_rows':len(outside),'reason_counts':dict(reasons),
        'quality':q,'classification':'CONFIGURED_CALENDAR_ONLY','canonical_certified':False}


def resolve_candidates(audit,root,store,operations_root,fetch,now=None,progress=None):
    require(audit.get('operation')=='READ_ONLY_CASH_FIELD_AUDIT' and audit.get('complete') is True,'complete_audit_required')
    require(len({e['relative_path'] for e in audit['entries']})==len(audit['entries']),'duplicate_partition')
    root=safe_root(root);op=guard(operations_root)
    require(root!=op and root not in op.parents and op not in root.parents,'operation_directory_overlaps_data')
    folder=op/('resolution-'+uuid.uuid4().hex);folder.mkdir(parents=True,exist_ok=False)
    now=now or dt.datetime.now(IST);out=[]
    for index,e in enumerate(audit['entries'],1):
        item={'relative_path':e['relative_path']};out.append(item)
        try:
            symbol,day=identity(e['relative_path']);meta=store.metadata(symbol)
            sql=enrich(store.rows(meta['id'],day),symbol)
            exact=[v for v in e['variants'] if v.get('comparison',{}).get('category')=='EXACT']
            dest=folder/f'partition-{index:03d}';dest.mkdir()
            write_json_new(dest/'sql_before.json',{'metadata':meta,'rows':sql})
            if exact:
                v=exact[0];src=guard(v['source']);size=src.stat().st_size
                rows=source_rows({'source':str(src),'sha256':v['sha256'],'bytes':size})
                require(equal(sql,rows),'SQL_source_changed_since_audit')
                require(all(all(str(r.get(k))==str(meta[k]) for k in ('internal_name','exchange','instrument_type')) for r in rows),'metadata_changed')
                classification=classify_session(rows,symbol,day,now)
                require(sql==enrich(store.rows(meta['id'],day),symbol),'SQL_changed_during_preservation')
                candidate=dest/'preserved_source.parquet';shutil.copyfile(src,candidate)
                require(fingerprint(candidate)==(v['sha256'],size),'source_changed_during_copy')
                write_json_new(dest/'session_classification.json',classification)
                item.update(status='SESSION_PRESERVED_REVIEW',classification=classification,candidate=str(candidate))
            else:
                rows=fetch(meta,day)
                if not rows:
                    item.update(status='PROVIDER_NO_DATA');continue
                require(len(rows)<=20000,'provider_row_limit')
                classification=classify_session(rows,symbol,day,now)
                require(all(r['source']=='FYERS_HISTORICAL' for r in rows),'provider_source_invalid')
                compare=field_comparison(sql,rows)
                require(sql==enrich(store.rows(meta['id'],day),symbol),'SQL_changed_during_fetch')
                import pandas as pd
                candidate=dest/'provider_candidate.parquet';pd.DataFrame(rows).to_parquet(candidate,index=False)
                sha,size=fingerprint(candidate)
                item.update(status='PROVIDER_CANDIDATE_STAGED',candidate=str(candidate),sha256=sha,bytes=size,
                    comparison=compare,classification=classification)
        except Exception as exc:
            item.update(status='REVIEW_REQUIRED',error=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
        finally:
            write_json_new(folder/f'outcome-{index:03d}.json',item)
            if progress:progress(index,len(audit['entries']))
    result={'status':'REVIEW_READY','market_data_modified':False,'sql_modified':False,
            'summary':dict(Counter(e['status'] for e in out)),'outcomes':out,
            'report':str(folder/'result.json'),
            'scope':'Recovery workspace only. Source and SQL preserved; candidates are not promoted to canonical data. Session classification uses configured calendar; provider response is evidence, not automatic approval.'}
    write_json_new(folder/'result.json',result)
    return result
