"""Fresh bounded Cash parity check; no market-data writes or candidate generation."""
import datetime as dt
import uuid
from collections import Counter, defaultdict
from pathlib import Path
from model.cash_rebuild import normalized, derived_sql, file_rows
from model.cash_recovery import identity, enrich, write_json_new, FIELDS
from model.cash_inventory_preview import check_rows
from model.cash_restore import guard, require
from model.storage_inventory import safe_root
from model.config.market_calendar import IST, session_window, in_session
from model.quality import stamp
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe, SUPPORTED_TIMEFRAMES
from model.storage.parquet import _candle_to_row


def final_check(preview, plans, root, store, operations_root, now=None, progress=None):
    require(preview.get('complete') is True and preview.get('format_version') == 1, 'complete_cash_preview_required')
    paths = [p['relative_path'] for p in preview['partitions']]
    require(paths and len(paths) == len(set(paths)), 'empty_or_duplicate_raw_scope')
    for rel in paths: identity(rel)
    root = safe_root(root); op = guard(operations_root)
    require(root != op and root not in op.parents and op not in root.parents, 'report_directory_overlaps_data')
    by_source = defaultdict(set)
    for plan in plans:
        require(plan.get('operation') == 'CASH_DERIVED_REBUILD_PREVIEW' and plan.get('format_version') == 1, 'derived_plan_required')
        require(root == Path(plan['target_root']).resolve(), 'derived_plan_root_changed')
        for e in plan['entries']:
            rel = e['source_relative_path']; identity(rel); tf = e['timeframe']
            require(rel in paths and tf in SUPPORTED_TIMEFRAMES, 'derived_source_outside_raw_scope')
            require(e['relative_path'] == rel.replace('raw/1m/',f'processed/{tf}/',1), 'derived_path_invalid')
            by_source[rel].add(tf)
    require(bool(by_source), 'empty_derived_scope')
    now = now or dt.datetime.now(IST); raw_results = []; derived_results = []
    for index, rel in enumerate(sorted(paths), 1):
        result = {'relative_path':rel}; raw_results.append(result)
        pending = []
        try:
            symbol, day = identity(rel); meta = store.metadata(symbol); path = guard(root/rel)
            state, rows = file_rows(path); require(state is not None, 'raw_file_missing')
            require(all(all(str(r.get(k)) == str(meta[k]) for k in ('internal_name','exchange','instrument_type')) for r in rows),
                    'raw_metadata_mismatch')
            values = normalized(rows,symbol,day,'1m')
            sql = normalized(enrich(store.rows(meta['id'],day),symbol),symbol,day,'1m')
            require(values == sql, 'raw_SQL_Parquet_mismatch')
            # Permit preservation of off-session raw rows, retaining all other integrity checks.
            q = check_rows(rows,symbol,day,now,allow_outside_session=True)
            window = session_window(day)
            outside = sum(not window or not in_session(stamp(r['candle_timestamp'])) for r in rows)
            result.update(status='PARITY_VERIFIED',rows=len(rows),quality_issues=q['issues'],
                          quality_review_reasons=q['review_reasons'],calendar_verified=q['calendar_verified'],
                          outside_configured_session_rows=outside)
            for tf in sorted(by_source.get(rel,())):
                d = {'relative_path':rel.replace('raw/1m/',f'processed/{tf}/',1)}; pending.append(d)
                try:
                    require(not q['issues'] and not(set(q['review_reasons'])-{'incomplete_minute_coverage'}), 'raw_quality_review_required')
                    require(q['calendar_verified'] and window is not None, 'calendar_review_required')
                    regular = [r for r in rows if in_session(stamp(r['candle_timestamp']))]
                    regular_q = check_rows(regular,symbol,day,now)
                    require(not regular_q['issues'] and not regular_q['review_reasons'], 'regular_session_incomplete_or_invalid')
                    candles = [Candle(**{k:meta[k] for k in ('internal_name','fyers_symbol','exchange','instrument_type')},
                                      timestamp=stamp(r['candle_timestamp']),timeframe='1m',**{k:r[k] for k in FIELDS}) for r in regular]
                    expected = normalized([_candle_to_row(c) for c in aggregate_1m_to_timeframe(candles,tf)],symbol,day,tf)
                    require(bool(expected), 'empty_derived_expectation')
                    target = guard(root/d['relative_path']); target_state, pq = file_rows(target)
                    require(target_state is not None, 'derived_file_missing')
                    require(all(all(str(r.get(k)) == str(meta[k]) for k in ('internal_name','exchange','instrument_type')) for r in pq),
                            'derived_metadata_mismatch')
                    ds = normalized(derived_sql(store,meta['id'],day,tf),symbol,day,tf)
                    require(ds == normalized(pq,symbol,day,tf) == expected, 'derived_SQL_Parquet_or_recomputed_mismatch')
                    require(target_state == file_rows(target)[0] and ds == normalized(derived_sql(store,meta['id'],day,tf),symbol,day,tf),
                            'derived_changed_during_check')
                    d.update(status='VERIFIED',rows=len(expected))
                except Exception as exc:
                    d.update(status='FINDINGS',reason=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
            require(state == file_rows(path)[0] and values == normalized(enrich(store.rows(meta['id'],day),symbol),symbol,day,'1m'),
                    'raw_changed_during_check')
        except Exception as exc:
            result.update(status='FINDINGS',reason=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
            pending = [{'relative_path':rel.replace('raw/1m/',f'processed/{tf}/',1), 'status':'FINDINGS',
                        'reason':'raw_source_not_verified'} for tf in sorted(by_source.get(rel,()))]
        derived_results.extend(pending)
        if progress and (index%25 == 0 or index == len(paths)): progress(index,len(paths))
    quality_findings = [r for r in raw_results if r.get('quality_issues') or r.get('quality_review_reasons')
                        or r.get('outside_configured_session_rows')]
    storage_ok = all(r['status']=='PARITY_VERIFIED' for r in raw_results) and all(r['status']=='VERIFIED' for r in derived_results)
    summary = {'raw_partitions':len(raw_results),'raw_statuses':dict(Counter(r['status'] for r in raw_results)),
               'derived_partitions':len(derived_results),'derived_statuses':dict(Counter(r['status'] for r in derived_results)),
               'raw_quality_review_partitions':len(quality_findings),
               'quality_reasons':dict(Counter(reason for r in raw_results for reason in r.get('quality_issues',[])+r.get('quality_review_reasons',[]))),
               'raw_rows':sum(r.get('rows',0) for r in raw_results if r['status']=='PARITY_VERIFIED'),
               'derived_rows':sum(r.get('rows',0) for r in derived_results if r['status']=='VERIFIED')}
    report = op/('check-'+uuid.uuid4().hex+'.json'); op.mkdir(parents=True,exist_ok=True)
    result = {'status':'SCOPED_STORAGE_PASS' if storage_ok else 'FINDINGS', 'complete':True,
              'market_data_modified':False,'sql_modified':False,'canonical_quality_certified':False,
              'summary':summary,'raw_results':raw_results,'derived_results':derived_results,'report':str(report),
              'scope':'Fresh Cash check limited to supplied inventory paths and derived plan paths. SQL/Parquet parity is separate from '
                      'calendar, coverage and session quality. No FNO check, directory discovery, whole-database certification, or atomic snapshot.'}
    write_json_new(report,result); return result
