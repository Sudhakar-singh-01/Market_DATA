"""Read-only byte inventory. No database, broker, configuration or repair imports."""
import hashlib
import os
import re
from collections import Counter, defaultdict
from pathlib import Path

SKIP = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', 'backups',
        'backup', 'quarantine', 'recovery'}
DATE = r'\d{4}-\d{2}-\d{2}'
PATTERNS = [
    ('CASH', re.compile(r'(?:^|/)((?:raw|processed)/[^/]+/[^/]+/' + DATE + r'\.parquet)$')),
    ('FNO', re.compile(r'(?:^|/)(candles/[^/]+/underlying=[^/]+/expiry=' + DATE + r'/date=' + DATE + r'\.parquet)$')),
    ('FNO', re.compile(r'(?:^|/)(option_chain/underlying=[^/]+/date=' + DATE + r'\.parquet)$')),
]


def linked(path):
    return path.is_symlink() or getattr(path, 'is_junction', lambda: False)()


def safe_root(value):
    path = Path(value).absolute()
    if any(linked(p) for p in (path, *path.parents)):
        raise ValueError('Root contains a link or junction')
    if not path.is_dir() or path == Path(path.anchor):
        raise ValueError('Root must be an existing non-filesystem-root directory')
    return path.resolve()


def classify(path):
    for segment, pattern in PATTERNS:
        match = pattern.search(path.as_posix())
        if match:
            return segment, match.group(1)
    return None


def fingerprint(path):
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    after = path.stat()
    fields = ('st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_ino', 'st_dev')
    if any(getattr(before, f) != getattr(after, f) for f in fields):
        raise ValueError('File changed while hashing')
    return digest.hexdigest(), after.st_size


def inventory(sources, cash_root, fno_root, progress=None):
    targets = {'CASH': safe_root(cash_root), 'FNO': safe_root(fno_root)}
    if (targets['CASH'] == targets['FNO'] or
        targets['CASH'] in targets['FNO'].parents or
        targets['FNO'] in targets['CASH'].parents):
        raise ValueError('Inventory destination roots must be separate')
    roots = [safe_root(p) for p in sources] + list(targets.values())
    # A parent scan already includes its child; never hash a physical path twice.
    roots = sorted(set(roots), key=lambda p: (len(p.parts), str(p)))
    roots = [p for i, p in enumerate(roots) if not any(q in p.parents for q in roots[:i])]
    groups, issues, unknown, skipped = defaultdict(list), [], [], []
    seen = set()

    def error(path, exc):
        issues.append({'path': str(path), 'error': type(exc).__name__})

    for root in roots:
        for directory, dirs, files in os.walk(root, followlinks=False,
                onerror=lambda exc: error(exc.filename, exc)):
            base = Path(directory)
            for name in list(dirs):
                path = base / name
                if linked(path):
                    dirs.remove(name)
                    issues.append({'path': str(path), 'error': 'LinkOrJunctionSkipped'})
                elif name.lower() in SKIP:
                    dirs.remove(name)
                    skipped.append(str(path))
            for name in sorted(files):
                path = base / name
                if path.suffix.lower() != '.parquet':
                    continue
                if linked(path):
                    issues.append({'path': str(path), 'error': 'LinkOrJunctionSkipped'})
                    continue
                identity = str(path.absolute())
                if identity in seen:
                    continue
                seen.add(identity)
                key = classify(path)
                if key is None:
                    unknown.append(str(path))
                    continue
                segment, relative = key
                expected = targets[segment] / relative
                try:
                    checksum, size = fingerprint(path)
                    groups[key].append({'path': str(path), 'sha256': checksum,
                        'bytes': size, 'is_target': path == expected})
                except (OSError, ValueError) as exc:
                    error(path, exc)
                if progress and len(seen) % 100 == 0:
                    progress(len(seen))
    partitions = []
    for (segment, relative), copies in sorted(groups.items()):
        hashes = {c['sha256'] for c in copies}
        destination = next((c for c in copies if c['is_target']), None)
        status = ('DIFFERENT_BYTES_REVIEW' if len(hashes) > 1 else
                  'TARGET_PRESENT' if destination else 'MISSING_TARGET_CANDIDATE')
        identical = [paths for paths in (
            [c['path'] for c in copies if c['sha256'] == h] for h in sorted(hashes)
        ) if len(paths) > 1]
        partitions.append({'segment': segment, 'relative_path': relative,
            'target_path': str(targets[segment] / relative),
            'target_present': destination is not None, 'status': status,
            'identical_byte_groups': identical, 'copies': copies})
    return {'format_version': 1, 'read_only': True,
        'complete': not issues and not unknown,
        'scope': 'Recognized Parquet layouts only; excluded directories and unknown paths are listed. '
                 'SHA256 compares bytes, not candle values. No schema, SQL parity or market-quality verification. '
                 'Stop writers for a stable inventory; this is not an atomic snapshot.',
        'roots': list(map(str, roots)), 'target_roots': {k: str(v) for k,v in targets.items()},
        'summary': {'parquet_paths_seen': len(seen), 'partitions': len(partitions),
            'classified_files': sum(len(p['copies']) for p in partitions),
            'statuses': dict(Counter(p['status'] for p in partitions)),
            'identical_byte_groups': sum(len(p['identical_byte_groups']) for p in partitions),
            'issues': len(issues), 'unclassified': len(unknown)},
        'issues': issues, 'unclassified': unknown, 'excluded_directories': skipped,
        'partitions': partitions}
