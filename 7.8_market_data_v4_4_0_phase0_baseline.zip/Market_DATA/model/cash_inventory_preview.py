"""Bounded read-only Cash minute validation; previews never authorize imports."""
import datetime as dt
import re
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from model.storage_inventory import fingerprint, linked
from model.quality import integrity, compare_rows, stamp, MAX_PARTITION_ROWS
from model.config.market_calendar import IST, calendar_verified, expected_starts

PARTITION = re.compile(r'^raw/1m/([^/\\]+)/([0-9]{4}-[0-9]{2}-[0-9]{2})\.parquet$')
REQUIRED = {'fyers_symbol', 'timeframe', 'candle_timestamp', 'open', 'high',
            'low', 'close', 'volume', 'source', 'status'}


def load_candidate(copy, roots):
    import pyarrow.parquet as pq
    path = Path(copy['path']).absolute()
    if any(linked(p) for p in (path, *path.parents)):
        raise ValueError('LinkedPath')
    path = path.resolve()
    if not any(path == root or root in path.parents for root in roots):
        raise ValueError('OutsideInventoryRoots')
    sha, size = fingerprint(path)
    if sha != copy['sha256'] or size != copy['bytes']:
        raise ValueError('StaleInventory')
    file = pq.ParquetFile(path)
    if file.metadata.num_rows > MAX_PARTITION_ROWS:
        raise ValueError('PartitionRowLimit')
    if not REQUIRED.issubset(file.schema_arrow.names):
        raise ValueError('UnsupportedSchema')
    rows = file.read().to_pandas().to_dict('records')
    if fingerprint(path) != (sha, size):
        raise ValueError('ChangedDuringRead')
    return rows


def check_rows(rows, symbol, day, now, *, allow_outside_session=False):
    known = calendar_verified(day)
    issues = []
    if not rows:
        issues.append('empty_partition')
    if any(r.get('fyers_symbol') != symbol or r.get('timeframe') != '1m' for r in rows):
        issues.append('identity_mismatch')
    naive = False
    for row in rows:
        value = row.get('candle_timestamp')
        try:
            if isinstance(value, str): value = dt.datetime.fromisoformat(value)
            if getattr(value, 'tzinfo', None) is None: naive = True
        except ValueError:
            pass
    check = integrity(rows, '1m', day, now, allow_outside_session=allow_outside_session)
    # Do not reject a date solely using unverified session assumptions.
    if not known and not allow_outside_session:
        bad = []
        for row in rows:
            one = integrity([row], '1m', day, now)
            for sample in one['samples']:
                reasons = [r for r in sample['reasons'] if r != 'outside_session']
                if reasons: bad.append(dict(sample, reasons=reasons))
        check['invalid'] = len(bad)
        check['samples'] = bad[:30]
    if check['invalid']: issues.append('integrity_findings')
    if check['duplicates']: issues.append('duplicate_timestamps')
    if any(r.get('status') != 'CLOSED' for r in rows): issues.append('not_closed')
    if any(not isinstance(r.get('source'), str) or not r['source'].strip() for r in rows):
        issues.append('missing_source')
    coverage = None
    if known:
        expected = set(expected_starts(day))
        present = {stamp(r['candle_timestamp']) for r in rows}
        coverage = {'expected': len(expected), 'missing': len(expected-present),
                    'unexpected': len(present-expected)}
    review = []
    if not known: review.append('calendar_not_verified')
    if naive: review.append('naive_timestamp_assumed_IST_requires_review')
    if day >= now.date(): review.append('day_not_closed')
    if coverage and coverage['missing']: review.append('incomplete_minute_coverage')
    return {'issues': issues, 'review_reasons': review, 'integrity': check,
            'coverage': coverage, 'calendar_verified': known}


def preview(report, sql_reader=None, limit=None, progress=None, now=None):
    if report.get('format_version') != 1 or not isinstance(report.get('partitions'), list):
        raise ValueError('Unsupported inventory format')
    roots = [Path(p).absolute().resolve() for p in report['roots']]
    now = now or dt.datetime.now(IST)
    selected = [p for p in report['partitions'] if p.get('segment') == 'CASH'
                and PARTITION.fullmatch(p.get('relative_path', ''))]
    total = len(selected)
    if limit is not None: selected = selected[:limit]
    output = []
    for index, partition in enumerate(selected, 1):
        relative = partition['relative_path']
        match = PARTITION.fullmatch(relative)
        encoded, date = match.groups()
        symbol = encoded.replace('_', ':', 1)
        item = {'relative_path': relative, 'symbol': symbol,
                'inventory_status': partition.get('status'), 'variants': [],
                'comparisons': [], 'import_allowed': False}
        try:
            day = dt.date.fromisoformat(date)
            variants = defaultdict(list)
            for copy in partition['copies']: variants[copy['sha256']].append(copy)
            if len(variants) > 20: raise ValueError('VariantLimitExceeded')
            sql = None
            if sql_reader is not None:
                meta = sql_reader.instrument(symbol)
                if meta is None: raise ValueError('SQLInstrumentMissing')
                sql = [dict(row, fyers_symbol=symbol) for row in sql_reader.sql_day(meta['id'], '1m', day)]
                if len(sql) > MAX_PARTITION_ROWS: raise ValueError('SQLRowLimit')
                item['sql_quality'] = check_rows([dict(row, candle_timestamp=stamp(row['candle_timestamp'])) for row in sql], symbol, day, now) if sql else None
                item['sql_rows'] = len(sql)
            item['sql_status'] = 'CHECKED' if sql is not None else 'NOT_CHECKED'
            loaded = []
            for sha, copies in sorted(variants.items()):
                failures = []
                rows = None
                for copy in sorted(copies, key=lambda c: (not c.get('is_target', False), c['path'])):
                    try:
                        rows = load_candidate(copy, roots)
                        break
                    except Exception as exc:
                        failures.append({'path': copy['path'], 'error': type(exc).__name__,
                            'reason': str(exc) if isinstance(exc, ValueError) else 'ReadFailed'})
                variant = {'sha256': sha, 'copy_count': len(copies), 'read_failures': failures}
                item['variants'].append(variant)
                if rows is None:
                    variant['status'] = 'UNAVAILABLE'
                    continue
                variant.update(path=copy['path'], rows=len(rows), quality=check_rows(rows,symbol,day,now))
                q = variant['quality']
                variant['status'] = 'REJECTED' if q['issues'] else 'REVIEW_REQUIRED' if q['review_reasons'] else 'VALIDATED_CANDIDATE'
                if sql is not None:
                    variant['sql_comparison'] = compare_rows(sql, rows)
                loaded.append((sha, rows))
            for (sha_a, a), (sha_b, b) in combinations(loaded, 2):
                c = compare_rows(a, b)
                item['comparisons'].append({'variant_a': sha_a, 'variant_b': sha_b,
                    'a_only': c['sql_only'], 'b_only': c['parquet_only'],
                    'value_mismatches': c['value_mismatches'],
                    'mismatch_samples': c['mismatch_samples']})
            states = [v['status'] for v in item['variants']]
            item['status'] = ('UNAVAILABLE' if not states or 'UNAVAILABLE' in states else
                'REJECTED' if 'REJECTED' in states else
                'REVIEW_REQUIRED' if len(states)>1 or 'REVIEW_REQUIRED' in states or sql is None else
                'REVIEW_REQUIRED' if item.get('sql_quality') and (item['sql_quality']['issues'] or item['sql_quality']['review_reasons']) else
                'REVIEW_REQUIRED' if any(v['sql_comparison']['value_mismatches'] or v['sql_comparison']['sql_only'] for v in item['variants']) else
                'VALIDATED_CANDIDATE')
        except Exception as exc:
            item.update(status='UNAVAILABLE', error=type(exc).__name__)
        output.append(item)
        if progress and index % 25 == 0: progress(index, len(selected))
    counts = dict(Counter(p['status'] for p in output))
    return {'format_version': 1, 'read_only': True, 'import_allowed': False,
        'as_of': now.isoformat(), 'inventory_complete': report.get('complete', False),
        'complete': bool(report.get('complete')) and len(selected)==total and not counts.get('UNAVAILABLE'),
        'scope': 'Cash raw/1m only. One readable copy per SHA256 variant; other duplicates not revalidated. '
                 'Prices compared at existing four-decimal storage precision; source/status included. '
                 'Calendar, timezone, partial days and missing coverage require review. No import authorization.',
        'summary': {'available_partitions': total, 'checked_partitions': len(output), 'statuses': counts},
        'partitions': output}
