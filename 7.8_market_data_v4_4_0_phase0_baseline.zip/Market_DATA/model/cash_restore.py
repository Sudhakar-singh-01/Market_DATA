"""Restore absent Cash minute files only; SQL is always read-only."""
import datetime as dt
import hashlib
import json
import os
import shutil
import uuid
from pathlib import Path

from model.cash_inventory_preview import PARTITION, load_candidate, check_rows
from model.config.market_calendar import IST
from model.quality import compare_rows, stamp
from model.storage_inventory import linked, fingerprint, safe_root
from model.storage.locking import file_lock


def require(value, reason):
    if not value: raise ValueError(reason)


def guard(path):
    path = Path(path).absolute()
    require(not any(linked(p) for p in (path, *path.parents)), 'Linked path blocked')
    return path


def digest(plan):
    return hashlib.sha256(json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def destination(root, item):
    rel = item['relative_path']
    require(PARTITION.fullmatch(rel) is not None, 'Only canonical Cash raw/1m paths allowed')
    return guard(root / rel)


def check_item(item, root, reader, now=None):
    """Fresh source, full storage schema/identity, calendar, SQL and target checks."""
    target = destination(root, item)
    match = PARTITION.fullmatch(item['relative_path'])
    symbol = match.group(1).replace('_', ':', 1)
    day = dt.date.fromisoformat(match.group(2))
    source = guard(item['source']).resolve()
    require(source != target.resolve(), 'Source must be separate from destination')
    # Absolute explicit source; no source tree mutation occurs.
    rows = load_candidate({'path': str(source), 'sha256': item['sha256'],
                           'bytes': item['bytes']}, [source.parent])
    now = now or dt.datetime.now(IST)
    quality = check_rows(rows, symbol, day, now)
    require(not quality['issues'] and not (set(quality['review_reasons']) - {'calendar_not_verified'}), 'Source quality requires review')
    require(len(rows) == item['rows'], 'Source row count changed')
    meta = reader.instrument(symbol)
    require(meta is not None, 'SQL instrument missing')
    for row in rows:
        for field in ('internal_name', 'exchange', 'instrument_type'):
            require(field in row and str(row[field]) == str(meta[field]), 'Instrument metadata mismatch')
    sql = reader.sql_day(meta['id'], '1m', day)
    sql = [dict(r, fyers_symbol=symbol, candle_timestamp=stamp(r['candle_timestamp'])) for r in sql]
    quality = check_rows(sql, symbol, day, now)
    require(not quality['issues'] and not (set(quality['review_reasons']) - {'calendar_not_verified'}), 'SQL quality requires review')
    comparison = compare_rows(sql, rows)
    require(not any(comparison[k] for k in ('sql_only','parquet_only','value_mismatches')), 'SQL/source equality changed')
    if target.exists():
        require(fingerprint(target) == (item['sha256'], item['bytes']), 'Destination conflict: no overwrite')
        return 'ALREADY_IDENTICAL'
    return 'MISSING'


def make_plan(report, root, reader, progress=None, now=None):
    root = safe_root(root)
    require(report.get('format_version') == 1 and report.get('complete') is True,
            'A complete preview report is required')
    candidates = [p for p in report['partitions'] if p.get('status') in {'VALIDATED_CANDIDATE', 'REVIEW_REQUIRED'}
                  and p.get('inventory_status') == 'MISSING_TARGET_CANDIDATE']
    require(bool(candidates), 'No eligible missing candidates')
    items, blocked, seen = [], [], set()
    for i, p in enumerate(candidates, 1):
        try:
            require(p['relative_path'] not in seen, 'Duplicate partition in preview')
            seen.add(p['relative_path'])
            if len(p['variants']) != 1: continue
            quality = p['variants'][0].get('quality', {})
            if quality.get('issues') or set(quality.get('review_reasons', [])) - {'calendar_not_verified'}: continue
            if any(p['variants'][0]['sql_comparison'][k] for k in ('sql_only','parquet_only','value_mismatches')): continue
            v = p['variants'][0]
            require(p.get('sql_status') == 'CHECKED', 'SQL preview required')
            require(not any(v['sql_comparison'][k] for k in ('sql_only','parquet_only','value_mismatches')),
                    'Only SQL-identical restoration supported')
            source = guard(v['path'])
            item = {'relative_path': p['relative_path'], 'source': str(source),
                    'sha256': v['sha256'], 'bytes': source.stat().st_size, 'rows': v['rows'], 'warnings': quality.get('review_reasons', [])}
            if check_item(item, root, reader, now) == 'ALREADY_IDENTICAL':
                continue
            items.append(item)
        except Exception as exc:
            blocked.append({'relative_path': p.get('relative_path'), 'error': type(exc).__name__,
                            'reason': str(exc) if isinstance(exc, ValueError) else 'Read or SQL check failed'})
        if progress and i % 25 == 0: progress(i, len(candidates))
    return {'format_version': 1, 'operation': 'RESTORE_SQL_IDENTICAL_CASH_PARQUET',
        'target_root': str(root), 'created_at': (now or dt.datetime.now(IST)).isoformat(),
        'ready': bool(items) and not blocked, 'summary': {'eligible': len(items)+len(blocked),
        'excluded_by_policy': len(candidates)-len(items)-len(blocked), 'planned': len(items),
        'blocked': len(blocked), 'rows': sum(i['rows'] for i in items),
        'bytes': sum(i['bytes'] for i in items)}, 'items': items, 'blocked': blocked}


def append_event(path, event):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(event) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def apply_plan(plan, root, reader, journal_root, *, writers_stopped=False, progress=None, now=None):
    require(writers_stopped, 'Stop all writers and pass --writers-stopped')
    root = safe_root(root)
    require(plan.get('format_version') == 1 and plan.get('operation') == 'RESTORE_SQL_IDENTICAL_CASH_PARQUET'
            and plan.get('ready') is True and not plan.get('blocked'), 'Plan is not ready')
    require(root == Path(plan['target_root']).resolve(), 'Configured Cash root differs from plan')
    items = plan['items']
    require(items and len({i['relative_path'] for i in items}) == len(items), 'Empty or duplicate plan')
    # Preflight the whole plan before writing any market file.
    for i, item in enumerate(items, 1):
        check_item(item, root, reader, now)
        if progress and i % 25 == 0: progress('preflight', i, len(items))
    journal_root = guard(journal_root)
    require(journal_root != root and root not in journal_root.parents and journal_root not in root.parents,
            'Journal must be outside Cash data root')
    journal_root.mkdir(parents=True, exist_ok=True)
    plan_id = digest(plan)
    journal = guard(journal_root / (plan_id + '.jsonl'))
    restored = skipped = 0
    with file_lock(guard(journal_root / (plan_id + '.lock')), timeout=0):
        append_event(journal, {'event': 'START', 'plan_id': plan_id,
                              'at': dt.datetime.now(IST).isoformat()})
        for i, item in enumerate(items, 1):
            target = destination(root, item)
            temp = None
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                with file_lock(guard(str(target) + '.lock'), timeout=0):
                    state = check_item(item, root, reader, now)
                    if state == 'ALREADY_IDENTICAL':
                        skipped += 1
                        append_event(journal, {'event': state, 'path': item['relative_path']})
                        continue
                    temp = guard(target.parent / ('.restore-' + uuid.uuid4().hex + '.tmp'))
                    append_event(journal, {'event': 'PREPARED', 'path': item['relative_path'],
                        'source': item['source'], 'sha256': item['sha256'], 'temporary': str(temp)})
                    with open(item['source'], 'rb') as source, temp.open('xb') as stage:
                        shutil.copyfileobj(source, stage, length=1024*1024)
                        stage.flush()
                        os.fsync(stage.fileno())
                    require(fingerprint(temp) == (item['sha256'],item['bytes']), 'Staged checksum differs')
                    check_item(item, root, reader, now)
                    # Hard-link publication is atomic and refuses an existing target.
                    # Fail closed on filesystems that do not support hard links.
                    os.link(temp, target)
                    temp.unlink()
                    temp = None
                    require(check_item(item, root, reader, now) == 'ALREADY_IDENTICAL', 'Postcheck failed')
                    restored += 1
                    append_event(journal, {'event': 'RESTORED_VERIFIED', 'path': item['relative_path'],
                                          'sha256': item['sha256']})
                if progress: progress('restore', i, len(items))
            except Exception as exc:
                append_event(journal, {'event': 'STOPPED_REVIEW', 'path': item['relative_path'],
                                      'error': type(exc).__name__})
                raise
            finally:
                if temp is not None and temp.exists(): temp.unlink()
        append_event(journal, {'event': 'COMPLETE', 'restored': restored, 'already_identical': skipped})
    return {'status': 'COMPLETE', 'restored': restored, 'already_identical': skipped,
            'journal': str(journal), 'sql_modified': False}
