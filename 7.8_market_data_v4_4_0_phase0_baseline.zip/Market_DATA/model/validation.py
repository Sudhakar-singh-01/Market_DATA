"""
model/validation.py
Startup-level validation orchestrator. Runs every check called for in
spec Section 10 and fails loudly (raises ConfigurationError) rather
than letting the app continue with broken configuration.

This module does NOT re-implement validation logic that already lives
in the individual loaders (env_loader, data_settings, timeframe_settings,
instrument_loader each validate their own file as they load it) --
it just calls them in order and reports where in the chain things
failed, giving one clear entry point for main.py.
"""

import logging

from model.config.env_loader import EnvConfig
from model.config.data_settings import DataSettings
from model.config.timeframe_settings import TimeframeSettings
from model.config.instrument_loader import InstrumentRegistry
from model.exceptions import ConfigurationError

log = logging.getLogger("market_data.validation")


def validate_startup(
    env: EnvConfig,
    data_settings: DataSettings,
    timeframe_settings: TimeframeSettings,
    instruments: InstrumentRegistry,
) -> None:
    """
    Additional cross-cutting checks that don't belong to any single
    loader (each loader already validated its own file's internal
    structure at load time). Raises ConfigurationError on the first
    problem found.
    """
    if not instruments.active_stocks() and not instruments.active_indices():
        raise ConfigurationError(
            "No active instruments configured -- at least one active stock or index is required "
            "in instruments/stocks.yaml or instruments/indices.yaml."
        )

    if timeframe_settings.base_timeframe != "1m":
        # Defense in depth -- timeframe_settings.py already enforces this,
        # but this is the project's single most important invariant, so
        # it is checked again explicitly here.
        raise ConfigurationError("base_timeframe must be '1m'.")

    log.info("Configuration validation passed.")
    log.info(f"Active stocks: {len(instruments.active_stocks())}, active indices: {len(instruments.active_indices())}")
    log.info(f"Base timeframe: {timeframe_settings.base_timeframe}, derived timeframes: "
              f"{[tf.name for tf in timeframe_settings.derived_timeframes]}")
    log.info(f"Historical ingestion enabled: {data_settings.historical_enabled}, "
              f"live ingestion enabled: {data_settings.live_enabled}")
