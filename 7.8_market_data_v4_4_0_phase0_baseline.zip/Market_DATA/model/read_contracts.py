"""Small public read contracts. No provider calls, storage writes or UI imports."""
import base64
import datetime as dt
import hashlib
import json
from decimal import Decimal

from model.config.market_calendar import IST

TIMEFRAMES = ('1m', '5m', '15m', '30m', '1h', '1d')


class ReadRequestError(ValueError):
    pass


class DataNotVerifiedError(ReadRequestError):
    pass


def segment_name(value):
    value = str(value).upper()
    if value not in ('CASH', 'FNO'):
        raise ReadRequestError('segment must be CASH or FNO')
    return value


def page_limit(value, maximum=1000):
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= maximum:
        raise ReadRequestError(f'limit must be between 1 and {maximum}')
    return value


def date_scope(start, end, max_days=3661):
    try:
        a, b = dt.date.fromisoformat(str(start)), dt.date.fromisoformat(str(end))
    except ValueError as exc:
        raise ReadRequestError('Use ISO dates: YYYY-MM-DD') from exc
    if a > b or (b-a).days >= max_days:
        raise ReadRequestError(f'Use an ordered range of at most {max_days} days')
    return a, b


def json_value(value):
    """Keep Decimal precision; SQL wall-clock timestamps are explicitly IST."""
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_value(v) for v in value]
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, dt.datetime):
        return (value.replace(tzinfo=IST) if value.tzinfo is None else value.astimezone(IST)).isoformat()
    if isinstance(value, (dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.hex()
    return value


def scope_key(scope):
    return hashlib.sha256(json.dumps(json_value(scope), sort_keys=True).encode()).hexdigest()


def encode_cursor(scope, position):
    value = {'v': 1, 'scope': scope_key(scope), 'position': json_value(position)}
    return base64.urlsafe_b64encode(json.dumps(value).encode()).decode()


def decode_cursor(token, scope):
    if not token:
        return None
    try:
        if len(token) > 2048:
            raise ValueError()
        data = json.loads(base64.b64decode(token, altchars=b'-_', validate=True))
        if data['v'] != 1 or data['scope'] != scope_key(scope):
            raise ValueError()
        return data['position']
    except (ValueError, TypeError, KeyError, UnicodeError) as exc:
        raise ReadRequestError('Invalid cursor or cursor belongs to a different query') from exc


def result_page(rows, *, cursor=None, quality='NOT_VERIFIED', **meta):
    return {'data': json_value(rows),
            'meta': {'returned': len(rows), 'next_cursor': cursor, 'timezone': 'Asia/Kolkata', **meta},
            'quality': {'status': quality}}
