"""Fast Parquet-only calendar review. No broker, SQL, restore, or derived writes."""
import datetime as dt
import uuid
from collections import Counter
from model.cash_restore import guard, require
from model.cash_recovery import identity, source_rows, write_json_new
from model.storage_inventory import fingerprint, safe_root
from model.cash_inventory_preview import check_rows
from model.config.cash_calendar_patch import SPECIALS
from model.config.market_calendar import IST, calendar_verified, expected_starts, session_windows, calendar_metadata
from model.quality import stamp


def review(report, root, operations_root, now=None, progress=None):
    require(report.get('status')=='SCOPED_STORAGE_PASS' and report.get('complete') is True,
            'complete_storage_report_required')
    entries=report['raw_results']; paths=[e['relative_path'] for e in entries]
    require(len(paths)==len(set(paths)) and paths,'empty_or_duplicate_scope')
    root=safe_root(root); op=guard(operations_root)
    require(root!=op and root not in op.parents and op not in root.parents,'report_directory_overlaps_data')
    now=now or dt.datetime.now(IST); results=[]; selected=[]
    metadata=calendar_metadata()
    for e in entries:
        symbol,day=identity(e['relative_path'])
        if str(day) in SPECIALS or e.get('outside_configured_session_rows',0):
            selected.append(e)
        elif 'calendar_not_verified' in e.get('quality_review_reasons',[]):
            count=len(expected_starts(day))
            match=calendar_verified(day) and e.get('rows')==count and count>0
            results.append(dict(relative_path=e['relative_path'], status='REPORT_ONLY_CALENDAR_MATCH' if match else 'REPORT_ONLY_REVIEW',
                                reported_rows=e.get('rows'),expected_minutes=count, fresh_rows_checked=False))
    for index,e in enumerate(selected,1):
        item=dict(relative_path=e['relative_path'],fresh_rows_checked=True);results.append(item)
        try:
            symbol,day=identity(e['relative_path']);path=guard(root/e['relative_path'])
            sha,size=fingerprint(path)
            rows=source_rows(dict(source=str(path),sha256=sha,bytes=size))
            q=check_rows(rows,symbol,day,now,allow_outside_session=True)
            expected=set(expected_starts(day));present={stamp(r['candle_timestamp']) for r in rows}
            outside=sorted(present-expected);missing=sorted(expected-present)
            ok=q['calendar_verified'] and not q['issues'] and not q['review_reasons'] and not outside and not missing
            item.update(status='PARQUET_SESSION_PASS' if ok else 'REVIEW_REQUIRED', rows=len(rows),
                expected_minutes=len(expected),missing_minutes=len(missing),outside_minutes=len(outside),
                outside_samples=[str(x) for x in outside[:30]],missing_samples=[str(x) for x in missing[:30]],
                quality=q,intervals=[[a.isoformat(),b.isoformat()] for a,b in session_windows(day)],sha256=sha)
            require(fingerprint(path)==(sha,size),'file_changed_during_review')
        except Exception as exc:
            item.update(status='REVIEW_REQUIRED',error=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
        if progress:progress(index,len(selected))
    require(calendar_metadata()==metadata,'calendar_changed_during_review')
    op.mkdir(parents=True,exist_ok=True)
    target=op/('calendar-'+uuid.uuid4().hex+'.json')
    result=dict(status='CALENDAR_REVIEW_COMPLETE',complete=True,
        summary=dict(parquet_files_checked=len(selected),report_only_partitions=len(results)-len(selected),
                     statuses=dict(Counter(x['status'] for x in results))),
        results=results, report=str(target),market_data_modified=False,sql_modified=False,
        scope='Supplied report dates only. Selected current Parquet files checked; no fresh SQL parity, no derived check. Report-only matches are not fresh data certification.')
    write_json_new(target,result);return result
