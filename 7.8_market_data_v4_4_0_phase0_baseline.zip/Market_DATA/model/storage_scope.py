"""Storage ownership for the existing Cash raw/processed and separate FNO layout.

No directory is moved or created here. A nested FNO tree is excluded from Cash
inventory; equal roots and overlap with Cash candle namespaces remain forbidden.
"""
import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def cash_data_root(project_root=None):
    from dotenv import load_dotenv
    base = Path(project_root or PROJECT_ROOT)
    from model.config.runtime_paths import env_path, profile_home
    load_dotenv(env_path(base))
    home = profile_home()
    configured = os.environ.get('CASH_DATA_ROOT', '').strip() or (str(home / 'data/cash') if home else 'data')
    path = Path(configured)
    return (path if path.is_absolute() else (home or base) / path).absolute()


def _overlap(a, b):
    return a == b or a in b.parents or b in a.parents


def validate_storage_roots(roots):
    resolved = {}
    for segment, configured in roots.items():
        if configured is None:
            continue
        path = Path(configured).absolute()
        for ancestor in (path, *path.parents):
            if ancestor.is_symlink() or getattr(ancestor, 'is_junction', lambda: False)():
                raise ValueError('Symlink or junction in configured storage path')
        path = path.resolve()
        if path == Path(path.anchor):
            raise ValueError('Filesystem root is not a safe data root')
        resolved[segment] = path
    cash, fno = resolved.get('CASH'), resolved.get('FNO')
    excluded = []
    if cash is not None and fno is not None:
        if cash == fno or fno in cash.parents or any(_overlap(cash / part, fno) for part in ('raw', 'processed')):
            raise ValueError('Cash/FNO roots overlap in an owned candle tree')
        if cash in fno.parents:
            excluded = [fno.relative_to(cash).as_posix()]
    return {segment: {'root': str(path), 'excluded_subtrees': excluded if segment == 'CASH' else []}
            for segment, path in resolved.items()}


def owned_paths(root, excluded_subtrees=()):
    """Walk only this segment's tree, rejecting links instead of following them."""
    root = Path(root)
    excluded = {root / rel for rel in excluded_subtrees}
    def walk(directory):
        for path in sorted(directory.iterdir()):
            if path.is_symlink() or getattr(path, 'is_junction', lambda: False)():
                raise ValueError('Symlinks or junctions are not allowed in data tree')
            if path in excluded:
                continue
            yield path
            if path.is_dir():
                yield from walk(path)
    yield from walk(root)
