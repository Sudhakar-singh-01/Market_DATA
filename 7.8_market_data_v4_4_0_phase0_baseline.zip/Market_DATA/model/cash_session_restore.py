"""Restore SQL-identical session-flagged raw files; quality gates stay strict."""
import datetime as dt
from collections import Counter
from model.cash_recovery import current_state,apply_plan,write_json_new
from model.cash_recovery import identity
from model.cash_restore import guard,require
from model.storage_inventory import fingerprint,safe_root
from model.config.market_calendar import IST


def restore_sessions(result,root,store,operations_root,*,writers_stopped=False,now=None):
    require(writers_stopped,'writers_stopped_required')
    require(result.get('status')=='REVIEW_READY','resolution_report_required')
    root=safe_root(root);now=now or dt.datetime.now(IST)
    entries=[];seen=set()
    for source in result['outcomes']:
        if source['status']!='SESSION_PRESERVED_REVIEW':continue
        rel=source['relative_path'];require(rel not in seen,'duplicate_partition');seen.add(rel)
        entry={'relative_path':rel,'status':'UNRESOLVED'};entries.append(entry)
        try:
            symbol,day=identity(rel);meta=store.metadata(symbol)
            path=guard(source['candidate']);sha,size=fingerprint(path)
            item={'relative_path':rel,'source':str(path),'sha256':sha,'bytes':size,
                  'instrument_id':meta['id'],'preserve_session_exact':True,'sql_exact_required':True}
            rows,sql,present,q=current_state(item,root,store,now)
            item.update(rows=len(rows),warnings=q['review_reasons'])
            entry.update(status='ALREADY_CONSISTENT' if present else 'READY',item=item,
                sql_insert_keys=[],sql_insert_rows=0,restore_file=not present,
                session_classification=q['session_classification'])
        except Exception as exc:
            entry['reason']=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
    require(entries,'no_session_preservation_entries')
    plan={'format_version':1,'operation':'INSERT_ONLY_CASH_RECOVERY','target_root':str(root),'entries':entries,
          'policy':'Only full nonempty SQL-exact files; no SQL correction. Session warnings remain and canonical_certified is false.'}
    import uuid
    op=guard(operations_root)
    require(root!=op and root not in op.parents and op not in root.parents,'operation_directory_overlaps_data')
    run=op/('session-'+uuid.uuid4().hex);run.mkdir(parents=True,exist_ok=False)
    write_json_new(run/'plan.json',plan)
    if any(e['status']=='READY' for e in entries):
        outcome=apply_plan(plan,root,store,op,writers_stopped=True,now=now)
    else:
        outcome={'status':'PARTIAL' if any(e['status']=='UNRESOLVED' for e in entries) else 'COMPLETE',
                 'restored_files':0,'inserted_rows':0,'outcomes':[]}
    outcome.update(scope='Raw storage preservation/parity only; session quality is NOT certified.',
        canonical_certified=False,session_entries=entries,
        plan_statuses=dict(Counter(e['status'] for e in entries)),
        aggregation_status='NOT_REBUILT',report=str(run/'result.json'))
    write_json_new(run/'result.json',outcome)
    return outcome
