"""Read-only management of explicitly registered databases; no arbitrary SQL API."""
import datetime as dt
import threading
from pathlib import Path

from sqlalchemy import MetaData, Table, inspect, select, func

from model.read_contracts import ReadRequestError, json_value, page_limit, segment_name


class DatabaseCatalog:
    def __init__(self, factories, roots=None, fno_settings=None):
        self.factories = dict(factories)
        self.roots = roots or {}
        self.fno_settings = fno_settings
        self._engines = {}
        self._lock = threading.RLock()

    def engine(self, segment):
        segment = segment_name(segment)
        if segment not in self.factories:
            raise ReadRequestError('Database is not enabled/configured for this segment')
        with self._lock:
            if segment not in self._engines:
                self._engines[segment] = self.factories[segment]()
            return self._engines[segment]

    def databases(self):
        out = []
        for segment in self.factories:
            try:
                engine = self.engine(segment)
                out.append({'segment': segment, 'name': engine.url.database,
                            'status': 'AVAILABLE', 'tables': len(inspect(engine).get_table_names())})
            except Exception:
                out.append({'segment': segment, 'status': 'UNAVAILABLE', 'tables': None})
        return out

    def table_names(self, segment):
        return sorted(inspect(self.engine(segment)).get_table_names())

    def table(self, segment, name):
        # Reflection quotes identifiers. Only exact discovered tables are accepted.
        if name not in self.table_names(segment):
            raise ReadRequestError('Table is not present in the registered database')
        return Table(name, MetaData(), autoload_with=self.engine(segment))

    def schema(self, segment, name):
        self.table(segment, name)
        inspector = inspect(self.engine(segment))
        cols = inspector.get_columns(name)
        return json_value({'table': name, 'columns': [dict(c, type=str(c['type'])) for c in cols],
                           'primary_key': inspector.get_pk_constraint(name),
                           'foreign_keys': inspector.get_foreign_keys(name),
                           'indexes': inspector.get_indexes(name),
                           'unique_constraints': inspector.get_unique_constraints(name)})

    def _filtered(self, table, filters):
        predicates = []
        if len(filters or {}) > 20:
            raise ReadRequestError('At most 20 equality filters are supported')
        for key, value in (filters or {}).items():
            if key not in table.c:
                raise ReadRequestError('Unknown filter column')
            if isinstance(value, (dict, list)):
                raise ReadRequestError('Filter values must be scalar')
            col = table.c[key]
            if value is not None:
                try:
                    kind = col.type.python_type
                    if kind is dt.datetime:
                        value = dt.datetime.fromisoformat(str(value))
                        if value.tzinfo is not None:
                            from model.config.market_calendar import IST
                            value = value.astimezone(IST).replace(tzinfo=None)
                    elif kind is dt.date:
                        value = dt.date.fromisoformat(str(value))
                    elif kind is bool:
                        if str(value).lower() not in ('true', 'false', '1', '0'):
                            raise ValueError()
                        value = str(value).lower() in ('true', '1')
                    elif kind in (int, float):
                        value = kind(value)
                except (ValueError, TypeError, NotImplementedError) as exc:
                    raise ReadRequestError('Invalid filter value for column') from exc
            predicates.append(col == value)
        return predicates

    def rows(self, segment, name, *, limit=100, offset=0, filters=None):
        page_limit(limit)
        if isinstance(offset, bool) or not isinstance(offset, int) or not 0 <= offset <= 100000:
            raise ReadRequestError('offset must be between 0 and 100000')
        table = self.table(segment, name)
        keys = list(table.primary_key.columns)
        if not keys:
            raise ReadRequestError('Stable browsing requires a primary key; schema remains available')
        query = select(table).where(*self._filtered(table, filters)).order_by(*keys).limit(limit+1).offset(offset)
        with self.engine(segment).connect() as conn:
            rows = [dict(r) for r in conn.execute(query).mappings()]
        return {'data': json_value(rows[:limit]), 'meta': {'returned': min(limit, len(rows)),
                'next_offset': offset+limit if len(rows) > limit else None,
                'pagination': 'offset; concurrent changes may move rows', 'table': name}}

    def count(self, segment, name, filters=None):
        table = self.table(segment, name)
        with self.engine(segment).connect() as conn:
            return conn.execute(select(func.count()).select_from(table).where(*self._filtered(table, filters))).scalar_one()


def configured_catalog():
    """Read stored data without constructing FYERS clients or requiring broker secrets."""
    import os
    from dotenv import load_dotenv
    from model.config.data_settings import load_data_settings
    from model.storage.mysql import build_db_url, get_engine
    from model.fno.config import load_fno_database_config, load_fno_settings
    from model.fno.db import get_fno_engine

    root = Path(__file__).resolve().parents[1]
    from model.config.runtime_paths import env_path
    load_dotenv(env_path())
    settings = load_data_settings()
    factories = {}
    cash_name = os.environ.get('DB_NAME', '')
    if settings.storage.mysql_enabled and cash_name and os.environ.get('DB_USER'):
        url = build_db_url(os.environ.get('DB_HOST', 'localhost'), int(os.environ.get('DB_PORT', '3306')),
                           cash_name, os.environ['DB_USER'], os.environ.get('DB_PASSWORD', ''))
        factories['CASH'] = lambda: get_engine(url)
    fcfg = load_fno_database_config()
    fs = load_fno_settings()
    if fcfg.name and fcfg.user:
        def fno_engine():
            engine = get_fno_engine(fcfg, cash_name)
            # Preserve the existing guarded factory and also verify the exact selected DB.
            from sqlalchemy import text
            with engine.connect() as conn:
                if conn.execute(text('SELECT DATABASE()')).scalar() != fcfg.name:
                    raise ReadRequestError('Connected FNO database differs from configuration')
            return engine
        factories['FNO'] = fno_engine
    from model.storage_scope import cash_data_root
    roots = {'CASH': cash_data_root() if settings.storage.parquet_enabled else None, 'FNO': fs.parquet_root}
    return DatabaseCatalog(factories, roots, fs)
