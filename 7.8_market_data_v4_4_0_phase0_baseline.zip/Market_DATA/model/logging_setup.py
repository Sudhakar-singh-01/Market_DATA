"""
model/logging_setup.py
Centralized logging configuration. Called once at startup (main.py).
No module should call logging.basicConfig() itself -- this is the only
place that does.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def configure_logging(level: str, log_dir: str, log_file: str) -> logging.Logger:
    """
    Configures root logging with both a console handler and a rotating
    file handler. Returns the application's top-level logger.
    Never logs secrets -- callers must ensure sensitive values are kept
    out of any log message (see model/config/env_loader.py's redacted
    __repr__ for EnvConfig as the primary safeguard).
    """
    from model.config.runtime_paths import profile_home
    log_dir_path = Path(log_dir)
    home = profile_home()
    if home is not None and not log_dir_path.is_absolute():
        log_dir_path = home / log_dir_path
    log_dir_path.mkdir(parents=True, exist_ok=True)
    log_path = log_dir_path / log_file

    root_logger = logging.getLogger()
    root_logger.setLevel(level.upper())
    root_logger.handlers.clear()  # avoid duplicate handlers if called more than once

    formatter = logging.Formatter(_LOG_FORMAT)

    console_handler = logging.StreamHandler(stream=sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    file_handler = RotatingFileHandler(log_path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    return logging.getLogger("market_data")
