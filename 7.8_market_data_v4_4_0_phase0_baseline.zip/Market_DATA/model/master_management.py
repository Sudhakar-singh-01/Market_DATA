"""Validated metadata sync, stale preview detection and atomic audit."""
import dataclasses
import hashlib
import json
from sqlalchemy import text


def sync_preview(engine,instruments):
    configured=[dataclasses.asdict(i) for i in instruments.all_instruments()]
    with engine.connect() as c:rows=[dict(r) for r in c.execute(text('SELECT * FROM instruments ORDER BY id')).mappings()]
    token=hashlib.sha256(json.dumps({'db':rows,'config':configured},sort_keys=True,default=str).encode()).hexdigest()
    return _preview(rows,configured,token)

def _preview(rows,configured,token):
    by={r['fyers_symbol']:r for r in rows}
    changes=[]
    for i in configured:
        old=by.get(i['fyers_symbol'])
        want={k:i[k] for k in ('internal_name','fyers_symbol','exchange','instrument_type','category')};want['is_active']=i['active']
        if old is None or any(old[k]!=v for k,v in want.items()):changes.append({'before':old,'after':want})
    return {'token':token,'changes':changes,'count':len(changes)}


def apply_sync(engine,instruments,preview,role,confirmed=False):
    if role!='admin':raise PermissionError('Administrator access required')
    if not confirmed:raise ValueError('Explicit confirmation required')
    with engine.begin() as c:
        c.execute(text('SELECT id FROM instruments ORDER BY id FOR UPDATE')).all()
        # Use the same transaction for the snapshot; avoid a second connection while locks are held.
        configured=[dataclasses.asdict(i) for i in instruments.all_instruments()]
        rows=[dict(r) for r in c.execute(text('SELECT * FROM instruments ORDER BY id')).mappings()]
        token=hashlib.sha256(json.dumps({'db':rows,'config':configured},sort_keys=True,default=str).encode()).hexdigest()
        if token!=preview.get('token'):raise ValueError('Metadata changed; create a fresh preview')
        preview=_preview(rows,configured,token)
        for change in preview['changes']:
            row=change['after']
            if row['category'] not in ('stock','index') or not row['fyers_symbol'].startswith(row['exchange']+':'):raise ValueError('Invalid instrument metadata')
            c.execute(text('INSERT INTO instruments (internal_name,fyers_symbol,exchange,instrument_type,category,is_active) VALUES '
                '(:internal_name,:fyers_symbol,:exchange,:instrument_type,:category,:is_active) ON DUPLICATE KEY UPDATE '
                'internal_name=VALUES(internal_name),exchange=VALUES(exchange),instrument_type=VALUES(instrument_type),category=VALUES(category),is_active=VALUES(is_active)'),row)
        c.execute(text("INSERT INTO audit_log (actor_role,action,target,parameters,records_affected,result) VALUES ('admin','MASTER_SYNC','instruments',:p,:n,'success')"),
            {'p':json.dumps(preview,default=str),'n':preview['count']})
    return {'updated':preview['count']}
