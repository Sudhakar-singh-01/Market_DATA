"""Bounded asynchronous telemetry; reception and storage commits are distinct.

Only pipeline_events metadata is written. A failed telemetry write never claims
that a market-data write succeeded. Alert delivery is an explicit CLI operation.
"""
import datetime as dt
import hashlib
import json
import logging
import queue
import threading
import time
from sqlalchemy import inspect,text
from model.config.market_calendar import IST
log=logging.getLogger('market_data.monitoring')
_queue=queue.Queue(maxsize=2000)
_engine=None
_worker=None
_lock=threading.Lock()
_last={}
_dropped=0


def configure(engine):
    global _engine,_worker
    with _lock:
        if _engine is engine and _worker and _worker.is_alive():return
        if not inspect(engine).has_table('pipeline_events'):return
        _engine=engine
        if _worker and _worker.is_alive():return
        _worker=threading.Thread(target=_consume,daemon=True,name='pipeline-telemetry');_worker.start()


def emit(kind,details=None,symbol=None,severity='INFO',throttle_seconds=0):
    global _dropped
    if _engine is None:return False
    key=(kind,symbol);now=time.monotonic()
    with _lock:
        if throttle_seconds and now-_last.get(key,-1e12)<throttle_seconds:return False
        _last[key]=now
    event={'at':dt.datetime.now(IST).replace(tzinfo=None),'kind':kind,'severity':severity,
           'symbol':symbol,'details':json.dumps(details or {},default=str)}
    try:_queue.put_nowait(event);return True
    except queue.Full:_dropped+=1;return False


def _consume():
    while True:
        event=_queue.get()
        try:
            key=hashlib.sha256((event['kind']+str(event['symbol'])+str(int(event['at'].timestamp())//300)).encode()).hexdigest() if event['severity']=='ERROR' else None
            with _engine.begin() as c:c.execute(text('INSERT IGNORE INTO pipeline_events (occurred_at,kind,severity,symbol,details,event_key,delivery) VALUES (:at,:kind,:severity,:symbol,:details,:key,:delivery)'),
                {**event,'key':key,'delivery':'PENDING' if event['severity']=='ERROR' else 'DISABLED'})
        except Exception as exc:log.warning('Telemetry persistence unavailable (%s)',type(exc).__name__)
        finally:_queue.task_done()


def flush(timeout=3):
    until=time.monotonic()+timeout
    while _queue.unfinished_tasks and time.monotonic()<until:time.sleep(.02)
    return _queue.unfinished_tasks==0


def status():return {'queued':_queue.qsize(),'dropped_in_this_process':_dropped,'configured':_engine is not None}


def commit_events(kind,candles):
    now=dt.datetime.now(IST)
    latest={}
    for candle in candles:
        if candle.source=='FYERS_LIVE' and candle.timeframe=='1m' and candle.status=='CLOSED':latest[candle.fyers_symbol]=candle
    for symbol,c in latest.items():
        emit(kind,{'candle_start':c.timestamp.isoformat(),'committed_at':now.isoformat(),
            'delay_seconds':max(0.,(now-c.timestamp-dt.timedelta(minutes=1)).total_seconds()),'rows_in_batch':len(candles)},symbol)


def dispatch_alerts(engine,send=False,sender=None):
    """Read-only preview by default. Explicit send enables bounded retry delivery.
    Telegram credentials are operator environment settings, never part of reports.
    """
    with engine.connect() as c:rows=[dict(r) for r in c.execute(text("SELECT * FROM pipeline_events WHERE severity='ERROR' AND delivery IN ('PENDING','RETRY') ORDER BY id LIMIT 20")).mappings()]
    if not send:return {'pending':len(rows),'delivery':'DISABLED; use --send with configured channel'}
    if sender is None:
        import os,urllib.request
        token=os.environ.get('TIOS_TELEGRAM_BOT_TOKEN');chat=os.environ.get('TIOS_TELEGRAM_CHAT_ID')
        if not token or not chat:raise ValueError('Configure TIOS_TELEGRAM_BOT_TOKEN and TIOS_TELEGRAM_CHAT_ID to send alerts')
        def sender(message):
            body=json.dumps({'chat_id':chat,'text':message}).encode()
            req=urllib.request.Request('https://api.telegram.org/bot'+token+'/sendMessage',data=body,headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=10) as response:
                if not json.load(response).get('ok'):raise RuntimeError('Alert delivery rejected')
    delivered=failed=0
    from model.storage.locking import file_lock
    from model.fyers.rate_limiter import account_runtime_path
    with file_lock(account_runtime_path('alerts','dispatch.lock'),timeout=0):
        for row in rows:
            with engine.connect() as c:current=c.execute(text('SELECT delivery FROM pipeline_events WHERE id=:i'),{'i':row['id']}).scalar()
            if current not in ('PENDING','RETRY'):continue
            try:sender(f"TIOS {row['kind']} · {row['symbol'] or 'pipeline'} · {row['occurred_at']} IST");state='SENT';delivered+=1
            except Exception:state='RETRY';failed+=1
            with engine.begin() as c:c.execute(text('UPDATE pipeline_events SET delivery=:s WHERE id=:i'),{'s':state,'i':row['id']})
    return {'delivered':delivered,'retry_pending':failed,'semantics':'At least once; a process crash after sending can duplicate a notification'}
