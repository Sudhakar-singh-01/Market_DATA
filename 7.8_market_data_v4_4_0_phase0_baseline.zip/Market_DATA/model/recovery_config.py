"""Explicit recovery-only connection; never reuses an ingestion engine."""
import os
import re
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from sqlalchemy.pool import NullPool
from model.backup_service import BackupService
from model.database_catalog import configured_catalog


def configured_verifier():
    from dotenv import load_dotenv
    from model.recovery_verification import RecoveryVerifier
    from model.config.runtime_paths import env_path
    load_dotenv(env_path())
    name=os.environ.get('RECOVERY_DB_NAME','')
    live=[os.environ.get('DB_NAME','market_data'),os.environ.get('FNO_DB_NAME','fno_market_data')]
    if not re.fullmatch(r'tios_recovery_[a-zA-Z0-9_]{1,50}',name) or name.casefold() in {n.casefold() for n in live}:
        raise ValueError('Configure a separate RECOVERY_DB_NAME beginning tios_recovery_')
    user=os.environ.get('RECOVERY_DB_USER','')
    if not user:
        raise ValueError('Configure a dedicated RECOVERY_DB_USER with read-only access to the recovery database')
    try:
        port=int(os.environ.get('RECOVERY_DB_PORT','3306'))
        if not 1<=port<=65535:raise ValueError()
    except ValueError as exc:
        raise ValueError('RECOVERY_DB_PORT must be between 1 and 65535') from exc
    url=URL.create('mysql+pymysql',username=user,password=os.environ.get('RECOVERY_DB_PASSWORD',''),
                   host=os.environ.get('RECOVERY_DB_HOST','localhost'),port=port,database=name,
                   query={'charset':'utf8mb4'})
    # Each run uses fresh connections; no worker shares this pool/session state.
    engine=create_engine(url,poolclass=NullPool,connect_args={'connect_timeout':10})
    return RecoveryVerifier(BackupService(configured_catalog()),engine,live)


def staged_recoveries(backup_service, *, role):
    if role!='admin':raise PermissionError('Administrator access required')
    root=backup_service.recovery_root
    if root.is_symlink():raise ValueError('Recovery root cannot be a symlink')
    return sorted(p.name for p in root.glob('*') if not p.is_symlink() and p.is_dir()
                  and re.fullmatch(r'[0-9a-f]{32}_[0-9a-f]{8}',p.name))
