"""Optional strict analysis boundary over the existing Cash repository.

Each historical day is checked on read; an old report is never a certificate
for mutated data. No verification history or source data is written here.
"""
import datetime as dt
from model.config.market_calendar import IST,calendar_verified,expected_starts,in_session
from model.quality import integrity,compare_rows,stamp,MAX_PARTITION_ROWS
from controller.verification_controller import CashReader,row_candles,candle_rows
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe,SUPPORTED_TIMEFRAMES
class QualityNotVerifiedError(ValueError):pass


def iter_verified_days(repository,internal_name,timeframe,start,end,*,session="all",audit=None):
    if session not in ("all","regular"):raise ValueError("session must be all or regular")
    filtered = session == "regular"
    if timeframe not in ('1m',*SUPPORTED_TIMEFRAMES):raise ValueError('Unsupported timeframe')
    a,b=dt.date.fromisoformat(start),dt.date.fromisoformat(end);now=dt.datetime.now(IST)
    if a>b or (b-a).days>3660:raise ValueError('Use an ordered range of at most 3661 days')
    if not repository._data_settings.storage.mysql_enabled or not repository._data_settings.storage.parquet_enabled:
        raise QualityNotVerifiedError('Both stores are required for strict verified reads')
    inst=repository._resolve_instrument(internal_name)
    reader=CashReader(repository._get_mysql_engine(),repository._get_parquet_sink()._data_root)
    meta=reader.instrument(inst.fyers_symbol)
    if not meta:raise QualityNotVerifiedError('Instrument metadata is missing')
    for offset in range((b-a).days+1):
        day=a+dt.timedelta(days=offset)
        if day>=now.date() or not calendar_verified(day):raise QualityNotVerifiedError(f'{day}: calendar or closed-day evidence unavailable')
        rows=reader.sql_day(meta['id'],timeframe,day)
        if len(rows)>MAX_PARTITION_ROWS:raise QualityNotVerifiedError('Partition bound exceeded')
        pq,_=reader.parquet_day(inst.fyers_symbol,timeframe,day)
        check=integrity(rows,timeframe,day,now,allow_outside_session=filtered);pc=integrity(pq,timeframe,day,now,allow_outside_session=filtered);comparison=compare_rows(rows,pq)
        if any(comparison[k] for k in ('sql_only','parquet_only','value_mismatches')) or check['invalid'] or check['duplicates'] or pc['invalid'] or pc['duplicates']:
            raise QualityNotVerifiedError(f'{day}: invalid or inconsistent stored data')
        stored_rows = rows
        base=rows if timeframe=='1m' else reader.sql_day(meta['id'],'1m',day)
        if len(base)>MAX_PARTITION_ROWS:raise QualityNotVerifiedError('Base partition bound exceeded')
        full_base = base
        base_check=integrity(base,'1m',day,now,allow_outside_session=filtered)
        if filtered:
            rows=[r for r in rows if in_session(stamp(r['candle_timestamp']))]
            base=[r for r in base if in_session(stamp(r['candle_timestamp']))]
        if base_check['invalid'] or base_check['duplicates'] or {stamp(r['candle_timestamp']) for r in base if r['status']=='CLOSED'}!=set(expected_starts(day)):
            raise QualityNotVerifiedError(f'{day}: canonical minute coverage is incomplete')
        if timeframe!='1m':
            base_pq,_=reader.parquet_day(inst.fyers_symbol,'1m',day)
            base_comparison=compare_rows(full_base,base_pq)
            if any(base_comparison[k] for k in ('sql_only','parquet_only','value_mismatches')) or any(integrity(base_pq,'1m',day,now,allow_outside_session=filtered)[k] for k in ('invalid','duplicates')):raise QualityNotVerifiedError(f'{day}: canonical base stores differ')
            comparison=compare_rows(rows,candle_rows(aggregate_1m_to_timeframe(row_candles(base,inst),timeframe)))
            if any(comparison[k] for k in ('sql_only','parquet_only','value_mismatches')):raise QualityNotVerifiedError(f'{day}: aggregation differs from source')
        if audit is not None:
            audit.append(dict(date=str(day),excluded_rows=len(stored_rows)-len(rows),
                              excluded_base_1m_rows=len(full_base)-len(base)))
        yield day,[__import__('dataclasses').replace(c,timeframe=timeframe) for c in row_candles(rows,inst)]
