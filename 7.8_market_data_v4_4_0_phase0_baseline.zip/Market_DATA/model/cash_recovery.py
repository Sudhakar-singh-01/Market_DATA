"""Combined Cash recovery: diagnose all minute partitions, insert-only apply.

No existing SQL candle or target file is updated/deleted. Cross-store failure
is journaled and resumable, not represented as an atomic dual-store commit.
"""
import datetime as dt
import json
import os
import shutil
import uuid
from collections import Counter
from pathlib import Path

from sqlalchemy import inspect, text
from model.cash_restore import guard, require, destination, digest, append_event
from model.cash_inventory_preview import PARTITION, check_rows, load_candidate
from model.config.market_calendar import IST
from model.quality import compare_rows, stamp, canonical, MAX_PARTITION_ROWS
from model.storage_inventory import safe_root, fingerprint
from model.storage.locking import file_lock

WARNINGS_ALLOWED = {'calendar_not_verified', 'incomplete_minute_coverage'}
FIELDS = ('open','high','low','close','volume','source','status')


def equal(a,b):
    c=compare_rows(a,b)
    return not any(c[k] for k in ('sql_only','parquet_only','value_mismatches'))


def compatible(existing, candidate):
    c=compare_rows(existing,candidate)
    return not c['sql_only'] and not c['value_mismatches']


def quality(rows, symbol, day, now, metadata=None, *, preserve_session=False):
    q=check_rows(rows,symbol,day,now)
    if preserve_session:
        from model.cash_resolution import classify_session
        classification=classify_session(rows,symbol,day,now)
        q=dict(q,session_classification=classification,canonical_certified=False)
    else:
        require(not q['issues'], 'record_integrity_findings')
    require(not(set(q['review_reasons'])-WARNINGS_ALLOWED), 'timestamp_or_closed_day_review')
    if metadata:
        for row in rows:
            require(all(str(row.get(f))==str(metadata[f]) for f in
                ('internal_name','exchange','instrument_type')), 'instrument_metadata_mismatch')
    return q


def identity(rel):
    m=PARTITION.fullmatch(rel)
    require(m is not None, 'unsupported_partition_path')
    return m.group(1).replace('_',':',1),dt.date.fromisoformat(m.group(2))


def source_rows(item):
    p=guard(item['source']).resolve()
    return load_candidate({'path':str(p),'sha256':item['sha256'],'bytes':item['bytes']},[p.parent])


def enrich(rows,symbol):
    return [dict(r,fyers_symbol=symbol,timeframe='1m',candle_timestamp=stamp(r['candle_timestamp'])) for r in rows]


class RecoveryStore:
    def __init__(self,engine):self.engine=engine

    def metadata(self,symbol,conn=None):
        if conn is None:
            with self.engine.connect() as c:return self.metadata(symbol,c)
        rows=conn.execute(text('SELECT * FROM instruments WHERE fyers_symbol=:s'),{'s':symbol}).mappings().all()
        require(len(rows)==1,'instrument_missing_or_ambiguous')
        return dict(rows[0])

    def rows(self,iid,day,conn=None,lock=False):
        if conn is None:
            with self.engine.connect() as c:return self.rows(iid,day,c)
        sql=('SELECT * FROM candles WHERE instrument_id=:i AND timeframe=:tf '
             'AND candle_timestamp>=:a AND candle_timestamp<:b ORDER BY candle_timestamp LIMIT :lim')
        if lock and self.engine.dialect.name=='mysql':sql+=' FOR UPDATE'
        rows=list(conn.execute(text(sql),{'i':iid,'tf':'1m','a':dt.datetime.combine(day,dt.time.min),
            'b':dt.datetime.combine(day+dt.timedelta(days=1),dt.time.min),'lim':MAX_PARTITION_ROWS+1}).mappings())
        require(len(rows)<=MAX_PARTITION_ROWS,'SQL_row_limit')
        return [dict(r) for r in rows]

    def ensure_insert_schema(self):
        info=inspect(self.engine)
        columns={c['name']:c for c in info.get_columns('candles')}
        key={'instrument_id','timeframe','candle_timestamp'}
        require(key|set(FIELDS)<=columns.keys(),'unsupported_candle_schema')
        unique=info.get_unique_constraints('candles')+[i for i in info.get_indexes('candles') if i.get('unique')]
        require(any(set(i['column_names'])==key for i in unique),'required_unique_candle_key_missing')
        require(all(not columns[k]['nullable'] for k in key),'nullable_candle_key')
        if self.engine.dialect.name=='mysql':
            with self.engine.connect() as c:
                engine=c.execute(text("SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='candles'")).scalar()
            require(str(engine).upper()=='INNODB','transactional_InnoDB_required')

    def insert_missing(self,conn,iid,rows):
        if not rows:return
        values=[]
        for row in rows:
            values.append(dict(instrument_id=iid,timeframe='1m',
                candle_timestamp=stamp(row['candle_timestamp']).replace(tzinfo=None),
                **{f:canonical(row[f],f) for f in FIELDS}))
        if self.engine.dialect.name=='sqlite':
            for value in values:
                for field in ('open','high','low','close'):value[field]=float(value[field])
        conn.execute(text('INSERT INTO candles (instrument_id,timeframe,candle_timestamp,open,high,low,close,volume,source,status) '
            'VALUES (:instrument_id,:timeframe,:candle_timestamp,:open,:high,:low,:close,:volume,:source,:status)'),values)


def current_state(item,root,store,now,conn=None,lock=False):
    symbol,day=identity(item['relative_path'])
    target=destination(root,item)
    rows=source_rows(item)
    meta=store.metadata(symbol,conn)
    require(meta['id']==item['instrument_id'],'instrument_id_changed')
    preserve=bool(item.get('preserve_session_exact'))
    q=quality(rows,symbol,day,now,meta,preserve_session=preserve)
    sql=enrich(store.rows(meta['id'],day,conn,lock),symbol)
    if sql:quality(sql,symbol,day,now,preserve_session=preserve)
    require(compatible(sql,rows),'SQL_extra_or_conflicting_rows')
    if item.get('sql_exact_required') or preserve:
        require(bool(sql) and equal(sql,rows),'SQL_exact_snapshot_changed_replan')
    target_present=target.exists()
    if target_present:
        sha,size=fingerprint(target)
        pq=load_candidate({'path':str(target),'sha256':sha,'bytes':size},[root])
        quality(pq,symbol,day,now,meta,preserve_session=preserve)
        require(equal(pq,rows),'destination_has_different_rows_no_overwrite')
    return rows,sql,target_present,q


def make_plan(report,root,store,progress=None,now=None,*,prefer_sql_exact=False):
    root=safe_root(root);now=now or dt.datetime.now(IST)
    require(report.get('format_version')==1 and report.get('complete') is True,'complete_preview_required')
    entries=[];seen=set()
    for index,p in enumerate(report['partitions'],1):
        rel=p['relative_path']
        if PARTITION.fullmatch(rel) is None:continue
        entry={'relative_path':rel,'status':'UNRESOLVED','variants':[]}
        entries.append(entry)
        try:
            require(rel not in seen,'duplicate_partition');seen.add(rel)
            symbol,day=identity(rel);meta=store.metadata(symbol)
            sql=enrich(store.rows(meta['id'],day),symbol)
            entry['sql_rows']=len(sql)
            entry['sql_quality']=check_rows(sql,symbol,day,now) if sql else None
            require(len(p['variants'])<=20,'variant_limit')
            good=[]
            for v in p['variants']:
                item={'relative_path':rel,'source':v.get('path'),'sha256':v['sha256'],
                      'instrument_id':meta['id']}
                variant_quality=None
                try:
                    require(bool(item['source']),'source_unavailable')
                    item['bytes']=guard(item['source']).stat().st_size
                    rows=source_rows(item)
                    variant_quality=check_rows(rows,symbol,day,now)
                    q=quality(rows,symbol,day,now,meta)
                    item.update(rows=len(rows),warnings=q['review_reasons'])
                    entry['variants'].append({'source':item['source'],'status':'USABLE','rows':len(rows),
                        'quality':variant_quality,'sql_comparison':compare_rows(sql,rows)})
                    good.append((item,rows))
                except Exception as exc:
                    entry['variants'].append({'source':item.get('source'),'status':'REVIEW','quality':variant_quality,
                        'reason':str(exc) if isinstance(exc,ValueError) else type(exc).__name__})
            require(good,'no_usable_source_variant')
            # Never union contradictory data or choose by file size/newest date.
            good.sort(key=lambda pair:(-len(pair[1]),pair[0]['source']))
            item,rows=good[0]
            if not all(compatible(other,rows) for _,other in good):
                exact=[pair for pair in good if sql and equal(sql,pair[1])]
                require(prefer_sql_exact and exact,'usable_variants_conflict_or_need_union')
                item,rows=exact[0]
                item['sql_exact_required']=True
                entry['selection']='EXACT_CURRENT_SQL_MATCH_CONFLICTING_SOURCES_PRESERVED'
            if sql:quality(sql,symbol,day,now)
            require(compatible(sql,rows),'SQL_extra_or_conflicting_rows')
            rows,sql,present,q=current_state(item,root,store,now)
            inserts=compare_rows(sql,rows)['parquet_only']
            entry.update(status='ALREADY_CONSISTENT' if present and not inserts else 'READY',
                         action='NONE' if present and not inserts else 'INSERT_MISSING_SQL_AND_OR_FILE',
                         sql_insert_rows=inserts,restore_file=not present,item=item,
                         sql_insert_keys=[stamp(r['candle_timestamp']).isoformat() for r in rows
                             if stamp(r['candle_timestamp']) not in {stamp(x['candle_timestamp']) for x in sql}])
        except Exception as exc:
            entry['reason']=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
        if progress and index%25==0:progress(index,len(report['partitions']))
    counts=dict(Counter(e['status'] for e in entries))
    return {'format_version':1,'operation':'INSERT_ONLY_CASH_RECOVERY',
        'created_at':now.isoformat(),'target_root':str(root),
        'summary':{'partitions':len(entries),'statuses':counts,
            'unresolved_reasons':dict(Counter(e.get('reason') for e in entries if e['status']=='UNRESOLVED')),
            'sql_exact_selections':sum('selection' in e for e in entries),
            'sql_insert_rows':sum(e.get('sql_insert_rows',0) for e in entries if e['status']=='READY'),
            'files_to_restore':sum(e.get('restore_file',False) for e in entries if e['status']=='READY')},
        'prefer_sql_exact':prefer_sql_exact,
        'entries':entries,'policy':'Only READY entries apply; unresolved entries retained. No update/delete/overwrite. Explicit SQL-exact selection establishes storage agreement, not provider truth. Calendar/coverage warnings are not quality certificates.'}


def write_json_new(path,payload):
    with guard(path).open('x',encoding='utf-8') as f:
        json.dump(payload,f,indent=2,default=str);f.flush();os.fsync(f.fileno())


def apply_plan(plan,root,store,operations_root,*,writers_stopped=False,now=None,progress=None):
    require(writers_stopped,'writers_stopped_ack_required')
    root=safe_root(root);now=now or dt.datetime.now(IST)
    require(plan.get('format_version')==1 and plan.get('operation')=='INSERT_ONLY_CASH_RECOVERY','invalid_plan')
    require(root==Path(plan['target_root']).resolve(),'configured_root_changed')
    entries=[e for e in plan['entries'] if e['status']=='READY']
    require(entries,'no_READY_entries')
    require(len({e['item']['relative_path'] for e in entries})==len(entries),'duplicate_plan_entries')
    store.ensure_insert_schema()
    operations_root=guard(operations_root)
    require(root!=operations_root and root not in operations_root.parents and operations_root not in root.parents,'operation_directory_overlaps_data')
    operation=guard(operations_root/digest(plan));operation.mkdir(parents=True,exist_ok=True)
    journal=guard(operation/'events.jsonl');outcomes=[]
    with file_lock(guard(operation/'operation.lock'),timeout=0):
        append_event(journal,{'event':'START','plan_id':digest(plan),'at':now.isoformat()})
        for index,entry in enumerate(entries,1):
            item=entry['item'];target=destination(root,item);temp=None;committed=False;commit_attempted=False
            outcome={'relative_path':item['relative_path']}
            try:
                target.parent.mkdir(parents=True,exist_ok=True)
                with file_lock(guard(str(target)+'.lock'),timeout=0):
                    rows,sql,present,q=current_state(item,root,store,now)
                    planned_keys=set(entry['sql_insert_keys'])
                    have={stamp(r['candle_timestamp']) for r in sql}
                    require({stamp(r['candle_timestamp']).isoformat() for r in rows if stamp(r['candle_timestamp']) not in have}<=planned_keys, 'SQL_missing_scope_changed_replan')
                    if present and equal(sql,rows):
                        outcome.update(status='ALREADY_CONSISTENT',inserted=0,restored=False)
                    else:
                        # Durable per-attempt preimage: exact candidate bytes, selected
                        # instrument and the existing scoped SQL rows before any INSERT.
                        attempt=guard(operation/('partition-'+uuid.uuid4().hex));attempt.mkdir()
                        backup=attempt/'source.parquet'
                        with open(item['source'],'rb') as src,backup.open('xb') as dst:
                            shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
                        require(fingerprint(backup)==(item['sha256'],item['bytes']),'backup_hash_changed')
                        if not present:
                            temp=guard(target.parent/('.recovery-'+uuid.uuid4().hex+'.tmp'))
                            with backup.open('rb') as src,temp.open('xb') as dst:
                                shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
                            require(fingerprint(temp)==(item['sha256'],item['bytes']),'stage_hash_changed')
                            # Test publication support BEFORE committing SQL.
                            probe=guard(target.parent/('.recovery-probe-'+uuid.uuid4().hex))
                            os.link(temp,probe);probe.unlink()
                        symbol,day=identity(item['relative_path'])
                        with store.engine.begin() as conn:
                            rows,sql,present_now,q=current_state(item,root,store,now,conn,True)
                            require(present_now==present,'destination_changed_during_apply')
                            write_json_new(attempt/'before.json',{'item':item,'instrument':store.metadata(symbol,conn),
                                'sql_rows':sql,'target_existed':present,'warnings':q['review_reasons']})
                            append_event(journal,{'event':'BACKUP_VERIFIED','path':item['relative_path'],
                                'backup':str(attempt),'temporary':str(temp) if temp else None})
                            have={stamp(r['candle_timestamp']) for r in sql}
                            missing=[r for r in rows if stamp(r['candle_timestamp']) not in have]
                            require({stamp(r['candle_timestamp']).isoformat() for r in missing}<=planned_keys,'SQL_missing_scope_changed_replan')
                            store.insert_missing(conn,item['instrument_id'],missing)
                            after=enrich(store.rows(item['instrument_id'],day,conn,True),symbol)
                            require(equal(after,rows),'SQL_insert_readback_failed')
                            commit_attempted=True
                        committed=True
                        outcome['inserted']=len(missing)
                        append_event(journal,{'event':'SQL_COMMITTED','path':item['relative_path'],'inserted':len(missing)})
                        if not present:
                            os.link(temp,target)  # atomic no-clobber; NEVER replace
                            temp.unlink();temp=None
                        final_rows,final_sql,final_present,_=current_state(item,root,store,now)
                        require(final_present and equal(final_sql,final_rows),'postcheck_failed')
                        outcome.update(status='VERIFIED',inserted=len(missing),restored=not present)
                    append_event(journal,dict(event=outcome['status'],**outcome))
            except Exception as exc:
                outcome.update(status='REVIEW_REQUIRED',sql_may_have_committed=committed or commit_attempted,
                    reason=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
                # A durable journal failure aborts the operation; it is not swallowed.
                append_event(journal,dict(event='REVIEW_REQUIRED',**outcome))
            finally:
                if temp is not None and temp.exists():temp.unlink()
            outcomes.append(outcome)
            if progress:progress(index,len(entries))
        unresolved=sum(e['status']=='UNRESOLVED' for e in plan['entries'])
        summary={'status':'PARTIAL' if unresolved or any(o['status']=='REVIEW_REQUIRED' for o in outcomes) else 'COMPLETE',
            'applied_statuses':dict(Counter(o['status'] for o in outcomes)),
            'inserted_rows':sum(o.get('inserted',0) for o in outcomes),
            'restored_files':sum(o.get('restored',False) for o in outcomes),
            'unresolved_plan_entries':unresolved,'journal':str(journal),'outcomes':outcomes}
        append_event(journal,{'event':'FINISHED','status':summary['status']})
    return summary
