"""
model/fyers/rate_limiter.py
ONE process-wide limiter for FYERS REST calls (history, quotes, option
chain, profile ...). The FYERS quota is per ACCOUNT, so Subsystem A and
the FNO subsystem must draw from the same budget.

Design notes
------------
* Sliding-window log, not a classic token bucket. Providers enforce
  "N calls in any 1 s / 60 s window"; a token bucket of capacity 200 per
  minute can pass ~400 calls in the first 60 s (full bucket + refill) and
  breach the real quota. The window log cannot.
* Three windows: per second, per minute, per IST calendar day. Limits come
  from config (config/fno_settings.yaml -> rate_limits); nothing here is
  hard-coded to a plan.
* Two priorities. "high" (Subsystem A, incl. live reconnect backfill) may use
  100% of every window. "low" (FNO bulk work) may only use
  (1 - reserve_fraction) of every window, so FNO traffic can never starve
  Subsystem A.
* Thread-safe. Sleeping happens outside the lock. Clock/sleep are
  injectable so tests need no real waiting.
* LIMITATION (documented, not hidden): the limiter is process-wide, not
  machine-wide. If the dashboard and a headless CLI worker run as separate
  processes they each hold their own copy of the budget; size the configured
  limits accordingly (see docs/FNO_RUNBOOK.md).

Subsystem A integration is opt-in and a no-op by default:
acquire_shared() does nothing until configure_shared_limiter() has been
called, so existing A behaviour and tests are unchanged.
"""

import datetime
import logging
import threading
import time
from collections import deque
from typing import Callable, Optional
from zoneinfo import ZoneInfo

log = logging.getLogger("market_data.fyers.rate_limiter")

IST = ZoneInfo("Asia/Kolkata")
HIGH = "high"
LOW = "low"


class DailyQuotaExhausted(Exception):
    """Raised instead of waiting when the per-day budget for this priority is used up."""


class LimiterTimeout(Exception):
    """Raised when acquire(timeout=...) could not get a slot in time."""


class SlidingWindowLimiter:
    def __init__(
        self,
        per_second: int,
        per_minute: int,
        per_day: int,
        low_priority_reserve: float = 0.3,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
        today: Optional[Callable[[], datetime.date]] = None,
    ):
        if min(per_second, per_minute, per_day) < 1:
            raise ValueError("rate limits must be >= 1")
        if not 0.0 <= low_priority_reserve < 1.0:
            raise ValueError("low_priority_reserve must be in [0, 1)")
        self._limits = {1.0: int(per_second), 60.0: int(per_minute)}
        self._per_day = int(per_day)
        self._reserve = float(low_priority_reserve)
        self._clock = clock
        self._sleep = sleep
        self._today = today or (lambda: datetime.datetime.now(tz=IST).date())
        self._lock = threading.Lock()
        self._windows = {1.0: deque(), 60.0: deque()}
        self._day = self._today()
        self._day_count = 0
        self._counts = {HIGH: 0, LOW: 0}      # lifetime of this limiter, per priority
        self._waited_total = 0.0

    # ------------------------------------------------------------- internals
    def _cap(self, limit: int, priority: str) -> int:
        if priority == HIGH:
            return limit
        return max(1, int(limit * (1.0 - self._reserve)))

    def _roll_day(self):
        today = self._today()
        if today != self._day:
            self._day, self._day_count = today, 0

    def _try_take(self, priority: str) -> float:
        """Returns 0.0 if a slot was taken, else seconds to wait before retrying."""
        with self._lock:
            self._roll_day()
            if self._day_count >= self._cap(self._per_day, priority):
                raise DailyQuotaExhausted(
                    f"Daily FYERS request budget used up for priority '{priority}' "
                    f"({self._day_count}/{self._cap(self._per_day, priority)})."
                )
            now = self._clock()
            wait = 0.0
            for span, window in self._windows.items():
                while window and now - window[0] >= span:
                    window.popleft()
                cap = self._cap(self._limits[span], priority)
                if len(window) >= cap:
                    # the slot that must expire is the one `cap` positions from the newest
                    blocking = window[len(window) - cap]
                    wait = max(wait, span - (now - blocking))
            if wait > 0:
                return max(wait, 0.001)
            for window in self._windows.values():
                window.append(now)
            self._day_count += 1
            self._counts[priority] += 1
            return 0.0

    # ------------------------------------------------------------------ API
    def acquire(self, priority: str = HIGH, timeout: Optional[float] = None) -> float:
        """Blocks until a request slot is available. Returns seconds waited."""
        if priority not in (HIGH, LOW):
            raise ValueError(f"unknown priority '{priority}'")
        start = self._clock()
        while True:
            from controller.worker_lifecycle import check
            check()
            wait = self._try_take(priority)
            if wait == 0.0:
                waited = self._clock() - start
                with self._lock:
                    self._waited_total += waited
                return waited
            if timeout is not None and (self._clock() - start) + wait > timeout:
                raise LimiterTimeout(f"Could not obtain a FYERS request slot within {timeout}s.")
            self._sleep(min(wait, 0.5))

    def stats(self) -> dict:
        with self._lock:
            self._roll_day()
            now = self._clock()
            in_second = sum(1 for t in self._windows[1.0] if now - t < 1.0)
            in_minute = sum(1 for t in self._windows[60.0] if now - t < 60.0)
            return {
                "per_second_limit": self._limits[1.0], "per_minute_limit": self._limits[60.0],
                "per_day_limit": self._per_day, "low_priority_reserve": self._reserve,
                "used_last_second": in_second, "used_last_minute": in_minute,
                "used_today": self._day_count,
                "remaining_today_high": max(0, self._per_day - self._day_count),
                "remaining_today_low": max(0, self._cap(self._per_day, LOW) - self._day_count),
                "granted_high": self._counts[HIGH], "granted_low": self._counts[LOW],
                "total_wait_seconds": round(self._waited_total, 3),
            }


# --------------------------------------------------------------- shared handle
_shared: Optional[SlidingWindowLimiter] = None
_shared_lock = threading.Lock()


def configure_shared_limiter(limiter: Optional[SlidingWindowLimiter]) -> None:
    """Installs (or, with None, removes) the process-wide limiter."""
    global _shared
    with _shared_lock:
        _shared = limiter


def get_shared_limiter() -> Optional[SlidingWindowLimiter]:
    return _shared


def acquire_shared(priority: str = HIGH) -> float:
    """Hook called from Subsystem A REST call sites. No-op (returns 0.0)
    unless a shared limiter has been configured in this process."""
    limiter = _shared
    if limiter is None:
        return 0.0
    return limiter.acquire(priority)


# Methods of the FYERS REST client that count against the quota.
_REST_METHODS = frozenset({
    "history", "quotes", "optionchain", "depth", "get_profile", "fno_historical_data",
    "expiry_dates", "futures_chain", "history_underlying_symbols", "market_status",
})


class RateLimitedClient:
    """Transparent proxy around a FyersModel: every REST method listed in
    _REST_METHODS first takes a slot from the limiter at the given priority."""

    def __init__(self, client, limiter: SlidingWindowLimiter, priority: str = LOW):
        self._client = client
        self._limiter = limiter
        self._priority = priority
        self.requests_made = 0

    def __getattr__(self, name):
        target = getattr(self._client, name)
        if name in _REST_METHODS and callable(target):
            def limited(*args, **kwargs):
                self._limiter.acquire(self._priority)
                from controller.worker_lifecycle import check
                check()
                self.requests_made += 1
                return target(*args, **kwargs)
            return limited
        return target


class PersistentLimiter(SlidingWindowLimiter):
    """One account budget across processes sharing a runtime directory.

    Atomic file replacement under an OS lock. Contains counts/timestamps only.
    A corrupt existing budget fails closed; it is never silently reset.
    """
    def __init__(self, path, *args, **kwargs):
        from pathlib import Path
        kwargs.setdefault('clock',time.time)
        super().__init__(*args,**kwargs)
        self.path=Path(path)
    def _read(self):
        import json
        if not self.path.exists():return {'day':str(self._today()),'count':0,'times':[],'expired':0}
        state=json.loads(self.path.read_text())
        if not isinstance(state['count'],int) or not isinstance(state['times'],list):raise ValueError('Invalid account quota state')
        if state['day']!=str(self._today()):return {'day':str(self._today()),'count':0,'times':[],'expired':0}
        return state
    def _write(self,state):
        import json,os,tempfile
        self.path.parent.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(dir=self.path.parent,suffix='.tmp')
        try:
            with os.fdopen(fd,'w') as f:json.dump(state,f);f.flush();os.fsync(f.fileno())
            os.replace(name,self.path)
        finally:
            if os.path.exists(name):os.unlink(name)
    def _try_take(self,priority):
        from model.storage.locking import file_lock
        with self._lock,file_lock(str(self.path)+'.lock'):
            s=self._read();now=self._clock()
            if s['count']>=self._cap(self._per_day,priority):raise DailyQuotaExhausted('Shared account daily budget exhausted')
            times=[x for x in s['times'] if now-x<60]
            waits=[]
            for span,limit in self._limits.items():
                recent=[t for t in times if now-t<span];cap=self._cap(limit,priority)
                if len(recent)>=cap:waits.append(span-(now-recent[-cap]))
            if waits:return max(.001,max(waits))
            s['times']=times+[now];s['count']+=1;self._write(s);self._counts[priority]+=1
            return 0.
    def acquire_expired(self):
        from model.storage.locking import file_lock
        with self._lock,file_lock(str(self.path)+'.lock'):
            s=self._read()
            if s.get('expired',0)>=10:raise DailyQuotaExhausted('Expired intraday request allowance exhausted (10/day)')
            s['expired']=s.get('expired',0)+1;self._write(s)
    def stats(self):
        from model.storage.locking import file_lock
        with self._lock,file_lock(str(self.path)+'.lock'):
            s=self._read();now=self._clock()
            return {'per_second_limit':self._limits[1.],'per_minute_limit':self._limits[60.],
                'per_day_limit':self._per_day,'used_today':s['count'],
                'used_last_second':sum(now-t<1 for t in s['times']),
                'used_last_minute':sum(now-t<60 for t in s['times']),
                'remaining_today_high':max(0,self._per_day-s['count']),
                'remaining_today_low':max(0,self._cap(self._per_day,LOW)-s['count']),
                'expired_intraday_used':s.get('expired',0),'scope':'Shared runtime directory'}


def account_runtime_path(account, filename):
    import hashlib,os
    from pathlib import Path
    from model.config.runtime_paths import runtime_dir
    root=runtime_dir()
    return root/hashlib.sha256(account.encode()).hexdigest()[:20]/filename


def configure_account_limiter(account,settings=None):
    from model.fno.config import load_fno_settings
    limits=(settings or load_fno_settings()).rate_limits
    limiter=PersistentLimiter(account_runtime_path(account,'quota.json'),limits.per_second,limits.per_minute,
        limits.per_day,limits.fno_reserve_fraction)
    configure_shared_limiter(limiter)
    return limiter
