"""
model/fyers/historical.py
Fetches historical market data from FYERS's Historical API. Part 2
scope: ONLY the canonical base timeframe, 1-minute (spec Section 3 --
5m/15m/30m/1h/1d are generated locally in Part 3, never fetched).

Verified against fyers-apiv3's documented usage pattern:
    client.history(data={...})
with a payload of symbol/resolution/date_format/range_from/range_to/
cont_flag, and a response dict with 's' (status) and 'candles' keys.
This matches the same call pattern already in use and tested in this
project's earlier historical pipeline.

CHUNK-SIZE ASSUMPTION (flagged per spec Section 5/28 -- NOT invented,
but NOT independently reconfirmed either):
    FYERS's exact maximum date-range-per-request for 1-minute
    resolution could not be verified against current live API
    documentation at implementation time. MAX_DAYS_PER_REQUEST_1M below
    is a conservative, explicit default (90 calendar days), not a
    confirmed FYERS limit. Verify against https://myapi.fyers.in/docsv3
    before relying on this for large-scale backfills, and adjust the
    constant if needed -- it is centralized here specifically so that's
    a one-line change.

CHECKPOINT/RESUME INTERFACE (spec Section 6):
    Storage-backed resume is explicitly deferred to Part 3. This module
    defines the interface Part 3 must implement (CheckpointStore) and
    ships a NullCheckpointStore that always reports "nothing synced
    yet" -- i.e. resume is a documented no-op until Part 3 provides a
    real implementation, not faked here.
"""

import datetime
import logging
import re
import time
from typing import Optional, Protocol

from controller import worker_lifecycle as lifecycle
from model.config.data_settings import RetrySettings
from model.fyers.rate_limiter import acquire_shared
from model.exceptions import HistoricalAvailabilityError, HistoricalProviderError

log = logging.getLogger("market_data.fyers.historical")

RESOLUTION_1M = "1"  # FYERS resolution code for 1-minute

# See "CHUNK-SIZE ASSUMPTION" in the module docstring.
MAX_DAYS_PER_REQUEST_1M = 90

# See "CHUNK-SIZE ASSUMPTION" -- also unverified; conservative default
# spacing between consecutive historical API requests.
MIN_REQUEST_INTERVAL_SECONDS = 0.5


class TransientError(Exception):
    """Wraps a retryable failure (network/timeout/rate_limit). Anything
    else propagates immediately -- see with_retry()."""

    def __init__(self, category: str, original: Exception):
        self.category = category
        self.original = original
        super().__init__(f"[{category}] {original}")


def with_retry(fn, retry_settings: RetrySettings, context: str = ""):
    attempt = 0
    backoff = retry_settings.initial_backoff_seconds
    retryable = ("network", "timeout", "rate_limit")

    while True:
        lifecycle.check()
        try:
            return fn()
        except TransientError as exc:
            attempt += 1
            if exc.category not in retryable:
                log.error(f"[{context}] Non-retryable category '{exc.category}': {exc.original}")
                raise exc.original
            if attempt > retry_settings.max_retries:
                log.error(f"[{context}] Exhausted {retry_settings.max_retries} retries: {exc.original}")
                raise exc.original
            log.warning(
                f"[{context}] Transient '{exc.category}' error (attempt {attempt}/{retry_settings.max_retries}), "
                f"retrying in {backoff:.1f}s: {exc.original}"
            )
            time.sleep(backoff)
            backoff *= retry_settings.backoff_multiplier


def chunk_date_range(from_date: str, to_date: str, max_days: int) -> list:
    start = datetime.datetime.strptime(from_date, "%Y-%m-%d").date()
    end = datetime.datetime.strptime(to_date, "%Y-%m-%d").date()
    if start > end:
        raise ValueError(f"from_date ({from_date}) is after to_date ({to_date})")

    chunks = []
    cursor = start
    step = datetime.timedelta(days=max_days - 1)
    while cursor <= end:
        chunk_end = min(cursor + step, end)
        chunks.append((cursor.isoformat(), chunk_end.isoformat()))
        cursor = chunk_end + datetime.timedelta(days=1)
    return chunks


class CheckpointStore(Protocol):
    """Interface Part 3's storage layer must implement for resumable
    historical ingestion. Deliberately minimal -- two methods, both
    scoped to (fyers_symbol, timeframe)."""

    def get_last_synced_date(self, fyers_symbol: str, timeframe: str) -> Optional[str]:
        """Returns the last successfully-persisted date ('YYYY-MM-DD')
        for this instrument+timeframe, or None if nothing has been
        synced yet."""
        ...

    def save_checkpoint(self, fyers_symbol: str, timeframe: str, synced_through_date: str) -> None:
        """Records that data through synced_through_date has been
        durably persisted."""
        ...


class NullCheckpointStore:
    """Default, no-op CheckpointStore. Always reports nothing synced --
    i.e. every historical run re-fetches the full requested range until
    Part 3 supplies a real, storage-backed implementation. This is a
    documented limitation, not a silent gap."""

    def get_last_synced_date(self, fyers_symbol: str, timeframe: str) -> Optional[str]:
        return None

    def save_checkpoint(self, fyers_symbol: str, timeframe: str, synced_through_date: str) -> None:
        log.debug(
            f"NullCheckpointStore: not persisting checkpoint for {fyers_symbol} [{timeframe}] "
            f"through {synced_through_date} -- Part 3 has not supplied a real CheckpointStore yet."
        )


def _safe_provider_text(value) -> str:
    """Keep diagnostics bounded and redact credentials; never stringify whole responses."""
    if not isinstance(value, (str, int, float)):
        return ""
    text = str(value)
    text = re.sub(r"(?i)\bbearer\s+\S+", "Bearer [REDACTED]", text)
    text = re.sub(
        r"(?i)\b(access_token|refresh_token|authorization|client_secret|api_key|token)"
        r"\b[\"']?\s*[:=]\s*(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)",
        r"\1=[REDACTED]", text,
    )
    return " ".join(text.split())[:1000]


def _provider_error(response, symbol, from_date, to_date):
    code = response.get("code")
    if not isinstance(code, (int, str)):
        code = None
    elif isinstance(code, str):
        code = _safe_provider_text(code)[:80]
    message = _safe_provider_text(response.get("message")) or "Historical request rejected"
    data = response.get("data")
    # Only documented request-field errors belong in diagnostics. Other response
    # keys may contain authentication material or unrelated account information.
    details = {}
    if isinstance(data, dict):
        for field in ("range_from", "range_to", "symbol", "resolution", "date_format", "cont_flag"):
            detail = _safe_provider_text(data.get(field))
            if detail:
                details[field] = detail
    diagnostic = " ".join([message, *details.values()]).lower()
    unavailable = (
        "historical data available" in diagnostic
        or ("histor" in diagnostic and any(term in diagnostic for term in (
            "not available", "unavailable", "not supported", "plan", "subscription",
        )))
    )
    cls = HistoricalAvailabilityError if unavailable else HistoricalProviderError
    return cls(symbol, from_date, to_date, code, message, details)


def _fetch_chunk(client, fyers_symbol: str, from_date: str, to_date: str) -> list:
    payload = {
        "symbol": fyers_symbol,
        "resolution": RESOLUTION_1M,
        "date_format": "1",
        "range_from": from_date,
        "range_to": to_date,
        "cont_flag": "1",
    }

    lifecycle.check()
    acquire_shared()  # no-op unless a process-wide limiter is configured (FNO shares the FYERS quota)
    lifecycle.check()
    try:
        response = client.history(data=payload)
    except TimeoutError as exc:
        raise TransientError("timeout", exc)
    except ConnectionError as exc:
        raise TransientError("network", exc)

    lifecycle.check()
    if not isinstance(response, dict):
        raise HistoricalProviderError(
            fyers_symbol, from_date, to_date, None, "Malformed historical response",
        )
    if response.get("s") != "ok":
        error = _provider_error(response, fyers_symbol, from_date, to_date)
        if isinstance(error, HistoricalAvailabilityError):
            raise error
        message = error.message.lower()
        if str(error.code) == "429" or "rate limit" in message or "too many requests" in message:
            raise TransientError("rate_limit", error)
        raise error

    return response.get("candles", [])


def fetch_historical_1m(
    client,
    fyers_symbol: str,
    from_date: str,
    to_date: str,
    retry_settings: RetrySettings,
    checkpoint_store: Optional[CheckpointStore] = None,
) -> list:
    """
    Fetches raw 1-minute candle rows for [from_date, to_date], chunked
    per MAX_DAYS_PER_REQUEST_1M, retried per retry_settings.

    If checkpoint_store reports a later last-synced date than from_date,
    the effective start is advanced to the day after it -- this is the
    resume behavior (spec Section 6). With the default
    NullCheckpointStore, this has no effect (always starts from
    from_date), since Part 3 hasn't supplied real checkpoint persistence
    yet.
    """
    checkpoint_store = checkpoint_store or NullCheckpointStore()

    effective_from = from_date
    # Coverage-aware callers plan the missing ranges. A maximum-date legacy
    # checkpoint cannot prove that older dates or the second store are complete.
    chunks = chunk_date_range(effective_from, to_date, MAX_DAYS_PER_REQUEST_1M)
    log.info(f"{fyers_symbol}: fetching {len(chunks)} chunk(s) for 1m range {effective_from}..{to_date}")

    all_rows = []
    last_request_time = 0.0
    for chunk_from, chunk_to in chunks:
        lifecycle.check()
        elapsed = time.monotonic() - last_request_time
        wait = MIN_REQUEST_INTERVAL_SECONDS - elapsed
        if wait > 0:
            time.sleep(wait)
        last_request_time = time.monotonic()

        context = f"{fyers_symbol} 1m {chunk_from}..{chunk_to}"

        def do_fetch():
            return _fetch_chunk(client, fyers_symbol, chunk_from, chunk_to)

        rows = with_retry(do_fetch, retry_settings, context=context)
        log.info(f"{context}: {len(rows)} raw candles")
        all_rows.extend(rows)

    # Deliberately NOT calling checkpoint_store.save_checkpoint() here --
    # a checkpoint should only advance once data is durably PERSISTED,
    # not merely fetched. That call belongs in Part 3's storage layer /
    # historical_controller.py, after storage confirms success, using
    # the same CheckpointStore instance passed in here.
    return all_rows
