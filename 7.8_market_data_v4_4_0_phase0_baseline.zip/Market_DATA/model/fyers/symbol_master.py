"""
model/fyers/symbol_master.py
Downloads and caches FYERS's public NSE/BSE symbol master files so the
dashboard can offer a searchable "all NSE/BSE symbols" dropdown -- not
just the internal_name/fyers_symbol pairs configured in
instruments/stocks.yaml and indices.yaml.

Public, documented FYERS URLs (no auth needed, confirmed via FYERS's
own community/support posts):
    https://public.fyers.in/sym_details/NSE_CM_sym_master.json
    https://public.fyers.in/sym_details/BSE_CM_sym_master.json
(CM = Capital Market / cash segment -- equities and indices, which
covers "stocks and indices" as asked for; F&O/currency/commodity
segments are out of scope here.)

IMPORTANT: these URLs and the exact JSON key names are FYERS-documented
but could not be fetched or exercised from the sandbox this was built
in (public.fyers.in is not reachable there). Parsing is written
defensively against the commonly-reported shape (a dict keyed by
trading symbol, e.g. {"NSE:TCS-EQ": {...fields...}, ...}) and several
key-name variants are tried per field. Please run a real search once
and report back the exact error (or a sample raw entry) if nothing
shows up, so the key list can be corrected precisely.
"""

import datetime
import json
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("market_data.fyers.symbol_master")

_URLS = {
    "NSE": "https://public.fyers.in/sym_details/NSE_CM_sym_master.json",
    "BSE": "https://public.fyers.in/sym_details/BSE_CM_sym_master.json",
}
_CACHE_DIR = None  # test/embedding override; normal runtime resolves through TIOS_HOME
_CACHE_MAX_AGE_HOURS = 20  # FYERS refreshes these roughly daily; re-download once a day


def _cache_path(exchange: str) -> Path:
    if _CACHE_DIR is None:
        from model.config.runtime_paths import state_path
        cache_dir = state_path("data/symbol_master")
    else:
        cache_dir = Path(_CACHE_DIR)
    return cache_dir / f"{exchange}_CM.json"


def _is_stale(path: Path) -> bool:
    if not path.exists():
        return True
    age_hours = (datetime.datetime.now().timestamp() - path.stat().st_mtime) / 3600
    return age_hours > _CACHE_MAX_AGE_HOURS


def _normalize_entry(symbol_ticker: str, raw: dict) -> Optional[dict]:
    def first(*keys):
        for k in keys:
            if k in raw and raw[k] not in (None, ""):
                return raw[k]
        return None

    exchange = first("exchange", "ex_symbol", "exSymbol")
    if isinstance(exchange, str) and ":" not in exchange and len(exchange) <= 4:
        pass  # looks like a plain exchange code already, fine
    exchange = (exchange or symbol_ticker.split(":", 1)[0] if ":" in symbol_ticker else exchange)

    instrument_type = first("instrument_type", "exInstType", "instType")
    is_index = False
    if isinstance(instrument_type, (int, str)) and str(instrument_type).strip() in ("10", "INDEX"):
        is_index = True
    if symbol_ticker.endswith("-INDEX"):
        is_index = True

    return {
        "fyers_symbol": symbol_ticker,
        "name": first("symbol_desc", "description", "short_name", "symDetails") or symbol_ticker,
        "exchange": exchange or "",
        "category": "index" if is_index else "stock",
    }


def download_symbol_master(exchange: str, force: bool = False) -> Optional[str]:
    """Downloads (if stale/missing) and returns the cache file path as a
    string, or None on failure (network error, unexpected shape, etc --
    logged, never raised, so a download failure degrades to 'dropdown
    unavailable' rather than crashing the page)."""
    exchange = exchange.upper()
    if exchange not in _URLS:
        return None
    path = _cache_path(exchange)
    if not force and not _is_stale(path):
        return str(path)
    try:
        import requests
        # Some servers reject the default python-requests User-Agent as a
        # basic anti-scraping measure -- a normal browser-like one is a
        # harmless, common defensive addition for a public static file.
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                 "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        resp = requests.get(_URLS[exchange], headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, dict) or not data:
            log.warning(f"Symbol master for {exchange} did not look like the expected {{symbol: {{...}}}} shape")
            return str(path) if path.exists() else None  # fall back to stale cache if we have one
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
        log.info(f"Downloaded {exchange} symbol master: {len(data)} symbols")
        return str(path)
    except Exception as exc:
        log.warning(f"Could not download {exchange} symbol master: {exc}")
        return str(path) if path.exists() else None  # serve stale cache rather than nothing, if we have one


def search_symbols(query: str, exchange: Optional[str] = None, limit: int = 30) -> list:
    """Case-insensitive substring search over symbol ticker + name.
    Returns [] (never raises) if the relevant cache isn't available --
    callers should fall back to direct-symbol entry (model/fyers/quotes.py)
    in that case."""
    query = (query or "").strip().lower()
    if len(query) < 2:
        return []
    exchanges = [exchange.upper()] if exchange else list(_URLS)
    results = []
    for ex in exchanges:
        path = _cache_path(ex)
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text())
        except Exception as exc:
            log.warning(f"Could not read cached {ex} symbol master: {exc}")
            continue
        for symbol_ticker, raw in data.items():
            if not isinstance(raw, dict):
                continue
            entry = _normalize_entry(symbol_ticker, raw)
            if entry is None:
                continue
            haystack = f"{entry['fyers_symbol']} {entry['name']}".lower()
            if query in haystack:
                results.append(entry)
                if len(results) >= limit:
                    return results
    return results


def cache_status() -> dict:
    """For the UI to show 'last refreshed' / 'not downloaded yet' honestly."""
    status = {}
    for ex in _URLS:
        path = _cache_path(ex)
        if path.exists():
            age_hours = (datetime.datetime.now().timestamp() - path.stat().st_mtime) / 3600
            status[ex] = {"cached": True, "age_hours": round(age_hours, 1), "stale": age_hours > _CACHE_MAX_AGE_HOURS}
        else:
            status[ex] = {"cached": False, "age_hours": None, "stale": True}
    return status
