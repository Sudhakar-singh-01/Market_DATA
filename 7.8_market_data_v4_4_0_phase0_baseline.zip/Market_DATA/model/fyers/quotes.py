"""
model/fyers/quotes.py
Ad-hoc quote lookup for ANY FYERS symbol -- not limited to what's in
instruments/stocks.yaml or indices.yaml (spec: search should work for
any stock/index, whether or not it's in the instrument file).

Uses the already-authenticated FyersModel client's quotes() REST call
(model/fyers/auth.py's get_authenticated_client() -- no new auth flow,
per Section 41 "do not change existing FYERS authentication flow").

IMPORTANT: this module's response parsing is written against FYERS's
PUBLICLY DOCUMENTED v3 quotes response shape (community-reported field
names: d[].v.{lp,ch,chp,open_price,high_price,low_price,
prev_close_price,volume,short_name,description}), but could not be
exercised against a live FYERS account from the environment this was
built in (no network access to FYERS endpoints there). Parsing is
deliberately defensive (tries several known key-name variants per
field) so a minor field-naming difference degrades to "N/A" rather than
crashing -- but please verify against a real account and report back
any field that shows N/A when it shouldn't, so the key list can be
corrected precisely.
"""

import logging
from dataclasses import dataclass
from typing import Optional

from model.fyers.rate_limiter import acquire_shared

log = logging.getLogger("market_data.fyers.quotes")


@dataclass
class QuoteResult:
    ok: bool
    fyers_symbol: str
    name: Optional[str] = None
    ltp: Optional[float] = None
    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    prev_close: Optional[float] = None
    change: Optional[float] = None
    change_pct: Optional[float] = None
    volume: Optional[int] = None
    error: Optional[str] = None


def _first(d: dict, *keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return None


def get_quote(client, fyers_symbol: str) -> QuoteResult:
    """One symbol, one real REST call. For multiple symbols in one call
    (FYERS allows up to 50 comma-separated), see get_quotes_bulk()."""
    results = get_quotes_bulk(client, [fyers_symbol])
    return results.get(fyers_symbol, QuoteResult(ok=False, fyers_symbol=fyers_symbol, error="No data returned"))


def get_quotes_bulk(client, fyers_symbols: list) -> dict:
    """Returns {fyers_symbol: QuoteResult}. A single failed symbol does
    not fail the others."""
    if not fyers_symbols:
        return {}
    out = {}
    acquire_shared()  # no-op unless a process-wide limiter is configured
    try:
        response = client.quotes(data={"symbols": ",".join(fyers_symbols)})
    except Exception as exc:
        log.warning(f"FYERS quotes() call failed: {exc}")
        return {s: QuoteResult(ok=False, fyers_symbol=s, error=str(exc)) for s in fyers_symbols}

    if not isinstance(response, dict) or response.get("s") != "ok":
        message = response.get("message", str(response)) if isinstance(response, dict) else str(response)
        log.warning(f"FYERS quotes() returned a non-ok response: {message}")
        return {s: QuoteResult(ok=False, fyers_symbol=s, error=message) for s in fyers_symbols}

    by_symbol = {}
    for item in response.get("d", []):
        sym = item.get("n") or item.get("symbol")
        if sym:
            by_symbol[sym] = item

    for sym in fyers_symbols:
        item = by_symbol.get(sym)
        if item is None or item.get("s") not in (None, "ok"):
            out[sym] = QuoteResult(ok=False, fyers_symbol=sym, error="Symbol not found in response")
            continue
        v = item.get("v", {}) or {}
        ltp = _first(v, "lp", "ltp")
        prev_close = _first(v, "prev_close_price", "prevClosePrice", "pc")
        change = _first(v, "ch")
        change_pct = _first(v, "chp")
        if change is None and ltp is not None and prev_close is not None:
            change = ltp - prev_close
        if change_pct is None and change is not None and prev_close:
            change_pct = (change / prev_close) * 100
        out[sym] = QuoteResult(
            ok=True, fyers_symbol=sym,
            name=_first(v, "short_name", "shortName", "description", "symbol"),
            ltp=ltp,
            open=_first(v, "open_price", "o"),
            high=_first(v, "high_price", "h"),
            low=_first(v, "low_price", "l"),
            prev_close=prev_close,
            change=change,
            change_pct=change_pct,
            volume=_first(v, "volume", "vol_traded_today", "v"),
        )
    return out
