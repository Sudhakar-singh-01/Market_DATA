"""
model/fyers/auth.py
Owns ALL FYERS authentication for this project. Historical and
WebSocket modules in Part 2 must import get_authenticated_client() from
here rather than implementing any login/token logic themselves (spec
Section 7).

Verified against the fyers-apiv3 SDK's documented usage: SessionModel
for the OAuth-style login-code exchange, FyersModel for the resulting
REST client. If FYERS's SDK changes these names/parameters, only this
file needs to change.
"""

import logging

from fyers_apiv3 import fyersModel

from model.config.env_loader import FyersCredentials
from model.exceptions import ConfigurationError

log = logging.getLogger("market_data.fyers.auth")


class FyersAuthError(Exception):
    """Raised when authentication cannot produce a usable client."""


def run_interactive_login(creds: FyersCredentials) -> str:
    """
    One-time interactive login flow. Prints a login URL, accepts the
    auth_code pasted back, and returns a fresh access token.

    This is the ONLY place in the project that performs interactive
    authentication -- run manually via `python -m model.fyers.auth`
    when a new token is needed, then store the result in config/.env
    as FYERS_ACCESS_TOKEN. Never called automatically from historical
    or WebSocket ingestion.
    """
    session = fyersModel.SessionModel(
        client_id=creds.client_id,
        secret_key=creds.secret_key,
        redirect_uri=creds.redirect_uri,
        response_type="code",
        grant_type="authorization_code",
    )
    auth_url = session.generate_authcode()
    print(f"\n1. Open this URL, log in, and copy the 'auth_code' from the redirected URL:\n{auth_url}\n")

    auth_code = input("Paste auth_code here: ").strip()

    session.set_token(auth_code)
    response = session.generate_token()

    if "access_token" not in response:
        # Never log the raw response -- it may echo back sensitive fields.
        log.error("Token generation failed: FYERS did not return an access_token.")
        raise FyersAuthError("Token generation failed. Check client_id/secret_key/redirect_uri.")

    log.info("FYERS access token generated successfully.")
    print("\nAdd this to config/.env as FYERS_ACCESS_TOKEN:\n")
    return response["access_token"]


def get_authenticated_client(creds: FyersCredentials) -> fyersModel.FyersModel:
    """
    Builds a FYERS REST client from an already-available access token.
    Performs NO interactive login. Raises FyersAuthError if no token is
    configured, so callers can surface a clear "run the login flow
    first" message instead of a confusing downstream API failure.
    """
    if not creds.access_token:
        raise FyersAuthError(
            "No FYERS_ACCESS_TOKEN configured in config/.env. "
            "Run `python -m model.fyers.auth` once to generate one."
        )

    try:
        client = fyersModel.FyersModel(
            client_id=creds.client_id,
            token=creds.access_token,
            is_async=False,
            log_path="",
        )
    except Exception as exc:
        # Never include creds/token in the raised exception message.
        raise FyersAuthError(f"Failed to initialize FYERS client: {type(exc).__name__}") from exc

    from model.fyers.rate_limiter import configure_account_limiter
    configure_account_limiter(creds.client_id)
    log.info("FYERS client initialized.")
    return client


if __name__ == "__main__":
    # Manual, one-time use: `python -m model.fyers.auth`
    from model.config.env_loader import load_env_config

    logging.basicConfig(level=logging.INFO)
    try:
        env = load_env_config()
    except ConfigurationError as exc:
        print(f"Configuration error: {exc}")
    else:
        run_interactive_login(env.fyers)
        print("Access token generated. Store it as FYERS_ACCESS_TOKEN in the selected config/.env file.")
