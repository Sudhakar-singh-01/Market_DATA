"""Consumer-facing reads over the existing Cash/FNO stores.

No fetch, migration, repair, or job submission happens on a read. Decimal values
serialize as strings. Pagination is a live view, not a cross-request snapshot.
"""
import datetime as dt
from types import SimpleNamespace

from sqlalchemy import select, or_, and_, false, func, case

from model.config.market_calendar import IST, calendar_verified, expected_starts, session_window, session_windows, calendar_metadata
from model.read_contracts import (ReadRequestError, DataNotVerifiedError, TIMEFRAMES,
    segment_name, page_limit, date_scope, encode_cursor, decode_cursor, result_page)


class MarketReadService:
    def __init__(self, catalog, clock=None):
        self.catalog = catalog
        self.clock = clock or (lambda: dt.datetime.now(IST))

    def _read(self, segment, query):
        with self.catalog.engine(segment).connect() as conn:
            return [dict(r) for r in conn.execute(query).mappings()]

    def _master(self, segment):
        return self.catalog.table(segment, 'instruments' if segment == 'CASH' else 'fno_instruments')

    def _instrument(self, segment, symbol):
        table = self._master(segment)
        rows = self._read(segment, select(table).where(table.c.fyers_symbol == symbol).limit(2))
        if len(rows) != 1:
            raise ReadRequestError('Select one existing FYERS symbol from get_instruments()')
        return rows[0]

    def _id_page(self, segment, table, predicates, scope, limit, cursor):
        page_limit(limit)
        position = decode_cursor(cursor, scope)
        if position is not None:
            if isinstance(position, bool) or not isinstance(position, int) or position < 0:
                raise ReadRequestError('Invalid cursor position')
            predicates = [*predicates, table.c.id > position]
        rows = self._read(segment, select(table).where(*predicates).order_by(table.c.id).limit(limit+1))
        more = len(rows) > limit
        rows = rows[:limit]
        return result_page(rows, cursor=encode_cursor(scope, rows[-1]['id']) if more else None,
                           segment=segment, pagination='id keyset; live view')

    def get_instruments(self, segment='CASH', *, category=None, active_only=False, limit=100, cursor=None):
        segment = segment_name(segment)
        table = self._master(segment)
        predicates = []
        if category:
            allowed = ('stock', 'index') if segment == 'CASH' else ('FUTURES', 'OPTIONS')
            if category not in allowed:
                raise ReadRequestError(f'category must be one of {allowed}')
            predicates.append(table.c.category == category)
        if active_only:
            predicates.append(table.c.is_active == True if segment == 'CASH' else table.c.status == 'ACTIVE')
        return self._id_page(segment, table, predicates, ['instruments', segment, category, active_only], limit, cursor)

    def _candle_query(self, segment, symbol, timeframe, start, end):
        if timeframe not in TIMEFRAMES:
            raise ReadRequestError('Unsupported timeframe')
        a, b = date_scope(start, end)
        inst = self._instrument(segment, symbol)
        table = self.catalog.table(segment, 'candles' if segment == 'CASH' else 'fno_candles')
        identity = table.c.instrument_id if segment == 'CASH' else table.c.contract_id
        conditions = [identity == inst['id'], table.c.timeframe == timeframe,
            table.c.candle_timestamp >= dt.datetime.combine(a, dt.time()),
            table.c.candle_timestamp < dt.datetime.combine(b+dt.timedelta(days=1), dt.time())]
        return inst, table, conditions, a, b

    def get_candles(self, segment, symbol, timeframe, start, end, *, closed_only=True,
                    quality='raw', limit=1000, cursor=None, session='all'):
        segment = segment_name(segment)
        page_limit(limit)
        if quality not in ('raw', 'verified'):
            raise ReadRequestError('quality must be raw or verified')
        if session not in ('all','regular'):
            raise ReadRequestError('session must be all or regular')
        if session == 'regular' and segment != 'CASH':
            raise ReadRequestError('session=regular currently supports CASH only; FNO reads are unchanged')
        inst, table, conditions, a, b = self._candle_query(segment, symbol, timeframe, start, end)
        calendar_before = calendar_metadata() if session == 'regular' else None
        session_predicate = None
        if session == 'regular':
            date_scope(a,b,max_days=31)
            intervals=[]
            for offset in range((b-a).days+1):
                day=a+dt.timedelta(days=offset)
                if not calendar_verified(day):
                    raise DataNotVerifiedError('Regular-session reads require a verified calendar for every requested date')
                intervals.extend(session_windows(day))
            session_predicate = or_(*[and_(table.c.candle_timestamp >= op.replace(tzinfo=None),
                table.c.candle_timestamp < cl.replace(tzinfo=None)) for op,cl in intervals]) if intervals else false()
        scope = ['candles', segment, symbol, timeframe, str(a), str(b), closed_only, quality]
        if session == 'regular':
            scope.extend([session, calendar_before])
        position = decode_cursor(cursor, scope)
        last = None
        if position is not None:
            try:
                last = dt.datetime.fromisoformat(position)
                if last.tzinfo is not None or not a <= last.date() <= b:
                    raise ValueError()
            except (TypeError, ValueError) as exc:
                raise ReadRequestError('Invalid candle cursor') from exc
        coverage = None
        session_counts = None
        if quality == 'verified':
            if not closed_only:
                raise ReadRequestError('Verified reads require closed_only=true')
            date_scope(a, b, max_days=31)
            rows, coverage = (self._verified_range(segment, inst, timeframe, a, b, session=session) if session == 'regular'
                              else self._verified_range(segment, inst, timeframe, a, b))
            if session == 'regular':
                session_counts = dict(mode=session,excluded_rows=coverage.pop('excluded_rows'),
                    excluded_base_1m_rows=coverage.pop('excluded_base_1m_rows'),
                    scope_rows=len(rows),counts_scope='Full requested range before pagination',
                    evidence='SQL_PARQUET_CHECKED')
            rows = [r for r in rows if last is None or r['candle_timestamp'] > last]
            rows = rows[:limit+1]
        else:
            if closed_only:
                conditions.append(table.c.status == 'CLOSED')
            if session == 'regular':
                counts=self._read(segment,select(func.count().label('total'),
                    func.coalesce(func.sum(case((session_predicate,1),else_=0)),0).label('regular'))
                    .select_from(table).where(*conditions))[0]
                session_counts=dict(mode=session,excluded_rows=int(counts['total'])-int(counts['regular']),
                    scope_rows=int(counts['regular']),counts_scope='Full requested range, respecting closed_only, before pagination',
                    evidence='SQL_OBSERVATION_ONLY')
                conditions.append(session_predicate)
            if last is not None:
                conditions.append(table.c.candle_timestamp > last)
            # Both existing schemas enforce uniqueness within instrument/timeframe/timestamp.
            rows = self._read(segment, select(table).where(*conditions).order_by(table.c.candle_timestamp).limit(limit+1))
        more = len(rows) > limit
        rows = rows[:limit]
        next_cursor = encode_cursor(scope, rows[-1]['candle_timestamp'].isoformat()) if more else None
        result = result_page(rows, cursor=next_cursor, quality='VERIFIED' if quality == 'verified' else 'NOT_VERIFIED',
            segment=segment, symbol=symbol, timeframe=timeframe, quality_mode=quality,
            pagination='timestamp keyset; live view, not a snapshot', numeric_format='Decimal values are strings')
        result['meta']['session'] = session
        if session_counts is not None:
            if calendar_metadata() != calendar_before:
                raise DataNotVerifiedError('Calendar changed during read; retry request')
            result['meta']['session_filter'] = session_counts
        if coverage:
            result['quality'].update(coverage)
        return result

    def iter_candles(self, segment, symbol, timeframe, start, end, **kwargs):
        """Yield all requested rows in bounded pages; no hidden truncation."""
        cursor = kwargs.pop('cursor', None)
        while True:
            page = self.get_candles(segment, symbol, timeframe, start, end, cursor=cursor, **kwargs)
            yield from page['data']
            cursor = page['meta']['next_cursor']
            if not cursor:
                return

    def get_latest_candles(self, segment, symbol, timeframe='1m', *, closed_only=True, limit=1):
        segment = segment_name(segment)
        page_limit(limit, 100)
        if timeframe not in TIMEFRAMES:
            raise ReadRequestError('Unsupported timeframe')
        inst = self._instrument(segment, symbol)
        table = self.catalog.table(segment, 'candles' if segment == 'CASH' else 'fno_candles')
        identity = table.c.instrument_id if segment == 'CASH' else table.c.contract_id
        conditions = [identity == inst['id'], table.c.timeframe == timeframe]
        if closed_only:
            conditions.append(table.c.status == 'CLOSED')
        rows = self._read(segment, select(table).where(*conditions).order_by(table.c.candle_timestamp.desc()).limit(limit))
        out = result_page(rows, segment=segment, symbol=symbol, timeframe=timeframe)
        out['meta']['as_of'] = self.clock().isoformat()
        out['meta']['age_seconds'] = ((self.clock()-rows[0]['candle_timestamp'].replace(tzinfo=IST)).total_seconds() if rows else None)
        return out

    def get_coverage(self, segment, symbol, start, end):
        segment = segment_name(segment)
        a, b = date_scope(start, end, max_days=366)
        inst = self._instrument(segment, symbol)
        now = self.clock()
        days = []
        for offset in range((b-a).days+1):
            day = a+dt.timedelta(days=offset)
            _, table, predicates, _, _ = self._candle_query(segment, symbol, '1m', day, day)
            rows = self._read(segment, select(table.c.candle_timestamp, table.c.status).where(*predicates).limit(20001))
            expected = set(expected_starts(day, segment, now=now, lag_seconds=60))
            actual = {r['candle_timestamp'].replace(tzinfo=IST) for r in rows if r['status'] == 'CLOSED'}
            known = calendar_verified(day, segment)
            missing = expected-actual
            sparse = segment == 'FNO' and inst['category'] == 'OPTIONS'
            status = ('NOT_VERIFIED' if not known or len(rows) > 20000 or day > now.date() else
                      'SPARSE_UNCONFIRMED' if missing and sparse else 'INCOMPLETE' if missing else
                      ('NO_EXPECTED_MINUTES_YET' if session_window(day, segment) else 'NO_SESSION')
                      if not expected else 'OBSERVED_COVERAGE')
            days.append({'date': day, 'status': status, 'expected': len(expected), 'observed_closed': len(actual & expected),
                         'missing': len(missing), 'outside_expected': len(actual-expected),
                         'calendar_verified': known, 'missing_samples': sorted(missing)[:20]})
        return result_page(days, segment=segment, symbol=symbol,
            note='SQL observation only; missing option minutes are not proof of corruption or no trading')

    def get_option_chain(self, underlying, start, end, *, batch_id=None, limit=1000, cursor=None):
        a, b = date_scope(start, end)
        table = self.catalog.table('FNO', 'fno_option_chain_snapshots')
        predicates = [table.c.underlying == underlying, table.c.captured_at >= dt.datetime.combine(a, dt.time()),
                      table.c.captured_at < dt.datetime.combine(b+dt.timedelta(days=1), dt.time())]
        if batch_id:
            predicates.append(table.c.batch_id == batch_id)
        out = self._id_page('FNO', table, predicates, ['chain', underlying, str(a), str(b), batch_id], limit, cursor)
        out['meta']['note'] = 'Locally captured snapshots only; preserve batch_id when grouping contracts'
        return out

    def get_quality_report(self, segment, *, scope=None, job_id=None, limit=100, cursor=None):
        segment = segment_name(segment)
        table = self.catalog.table(segment, 'data_quality_results' if segment == 'CASH' else 'fno_data_quality_results')
        predicates = [table.c.scope == scope] if scope else []
        if job_id is not None:
            if segment != 'CASH':
                raise ReadRequestError('FNO findings have no job_id column; use exact scope')
            predicates.append(table.c.job_id == job_id)
        out = self._id_page(segment, table, predicates, ['quality', segment, scope, job_id], limit, cursor)
        out['meta']['note'] = 'Historical observations, not a current certificate; use verified candle reads'
        return out

    def get_job_status(self, segment, job_id):
        segment = segment_name(segment)
        if job_id < 1:
            raise ReadRequestError('job_id must be positive')
        table = self.catalog.table(segment, 'ingestion_jobs' if segment == 'CASH' else 'fno_ingestion_jobs')
        # Operational errors/params may contain sensitive context; keep public job summaries narrow.
        columns = [table.c[k] for k in ('id', 'job_type', 'state', 'status', 'started_at', 'finished_at',
                   'heartbeat_at', 'cancel_requested', 'requests_made', 'rows_raw', 'rows_valid', 'rows_invalid',
                   'rows_stored', 'raw_count', 'valid_count', 'invalid_count', 'result') if k in table.c]
        rows = self._read(segment, select(*columns).where(table.c.id == job_id))
        if not rows:
            raise ReadRequestError('Job not found in selected segment')
        from controller.unified_workflow import public_result
        for row in rows:
            result=row.pop('result',None)
            if row.get('job_type')=='WORKFLOW':
                safe=public_result(result)
                if safe is not None:
                    safe['ready']=bool(safe.get('ready') and row.get('state')=='SUCCESS')
                    row['workflow']=safe
        return result_page(rows, segment=segment)

    def _verified_range(self, segment, inst, timeframe, a, b, *, session="all"):
        audit=[]
        if not self.catalog.roots.get(segment):
            raise DataNotVerifiedError('Both SQL and Parquet are required')
        out, sparse, session_days = [], False, 0
        for offset in range((b-a).days+1):
            day = a+dt.timedelta(days=offset)
            if day >= self.clock().date() or not calendar_verified(day, segment):
                raise DataNotVerifiedError('Only closed historical days with verified calendar evidence are supported')
            session_days += bool(session_window(day, segment))
            try:
                if segment == 'CASH':
                    rows = (self._cash_verified_day(inst, timeframe, day, session=session, audit=audit) if session == 'regular'
                            else self._cash_verified_day(inst, timeframe, day))
                else:
                    rows, is_sparse = self._fno_verified_day(inst, timeframe, day)
                    sparse |= is_sparse
            except DataNotVerifiedError:
                raise
            except Exception as exc:
                raise DataNotVerifiedError('Source validation unavailable or failed; run the existing verification tools') from exc
            out.extend(rows)
        details = {'checked_at': self.clock().isoformat(),
                     'coverage': 'NO_SESSION' if not session_days else 'SPARSE_UNCONFIRMED' if sparse else 'COMPLETE',
                     'meaning': 'Returned values checked against both stores; no cross-request snapshot guarantee'}
        if session == 'regular':
            details.update(excluded_rows=sum(x['excluded_rows'] for x in audit),
                           excluded_base_1m_rows=sum(x['excluded_base_1m_rows'] for x in audit))
        return out, details

    def _cash_verified_day(self, inst, timeframe, day, *, session="all", audit=None):
        # Reuse strict Cash logic; expose only the exact validated rows, never a second raw query.
        from model.verified_reads import iter_verified_days
        instrument = SimpleNamespace(**inst)
        instrument.active = bool(inst['is_active'])
        repository = SimpleNamespace(
            _data_settings=SimpleNamespace(storage=SimpleNamespace(mysql_enabled=True, parquet_enabled=True)),
            _resolve_instrument=lambda _: instrument,
            _get_mysql_engine=lambda: self.catalog.engine('CASH'),
            _get_parquet_sink=lambda: SimpleNamespace(_data_root=self.catalog.roots['CASH']))
        rows = []
        for _, candles in iter_verified_days(repository, inst['internal_name'], timeframe, str(day), str(day),session=session,audit=audit):
            for c in candles:
                rows.append({'instrument_id': inst['id'], 'timeframe': c.timeframe,
                    'candle_timestamp': c.timestamp.replace(tzinfo=None), 'open': c.open, 'high': c.high,
                    'low': c.low, 'close': c.close, 'volume': c.volume, 'source': c.source, 'status': c.status})
        return rows

    def _fno_verified_day(self, inst, timeframe, day):
        from model.fno.read_verification import verified_day
        return verified_day(self, inst, timeframe, day)
