"""Read-only, session-filtered derived rebuild plans for verified recovery scope."""
import datetime as dt
import uuid
from collections import Counter
from sqlalchemy import text
from model.cash_recovery import identity, enrich, quality, source_rows, write_json_new, FIELDS
from model.cash_repair import write_parquet_new
from model.cash_restore import guard, require, digest
from model.storage_inventory import safe_root, fingerprint
from model.config.market_calendar import IST, calendar_verified, session_window, in_session
from model.quality import stamp, canonical, MAX_PARTITION_ROWS
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe, SUPPORTED_TIMEFRAMES
from model.storage.parquet import _candle_to_row


def recovery_scope(reports):
    paths = set()
    for report in reports:
        require(report.get('status') in ('COMPLETE', 'PARTIAL', 'BASE_REPAIR_VERIFIED'), 'recovery_result_required')
        for item in report.get('outcomes', []):
            if item.get('status') in ('VERIFIED', 'ALREADY_APPLIED', 'ALREADY_CONSISTENT'):
                identity(item['relative_path']); paths.add(item['relative_path'])
    require(bool(paths), 'no_verified_recovery_partitions')
    return sorted(paths)


def normalized(rows, symbol, day, tf):
    result = []; seen = set()
    for r in rows:
        ts = stamp(r['candle_timestamp'])
        require(ts.date() == day and ts not in seen, 'wrong_date_or_duplicate_timestamp')
        require(r.get('timeframe') == tf and r.get('fyers_symbol', symbol) == symbol, 'partition_identity_mismatch')
        seen.add(ts)
        result.append(dict(candle_timestamp=ts.isoformat(), timeframe=tf,
                           **{k: str(canonical(r[k], k)) if k in ('open', 'high', 'low', 'close')
                              else canonical(r[k], k) for k in FIELDS}))
    return sorted(result, key=lambda r: r['candle_timestamp'])


def derived_sql(store, iid, day, tf, conn=None, lock=False):
    if conn is None:
        with store.engine.connect() as c:
            return derived_sql(store, iid, day, tf, c, lock)
    query = ('SELECT * FROM candles WHERE instrument_id=:i AND timeframe=:tf '
             'AND candle_timestamp>=:a AND candle_timestamp<:b ORDER BY candle_timestamp LIMIT :lim')
    if lock and store.engine.dialect.name == 'mysql': query += ' FOR UPDATE'
    rows = conn.execute(text(query),
                         {'i': iid, 'tf': tf, 'a': dt.datetime.combine(day, dt.time.min),
                          'b': dt.datetime.combine(day+dt.timedelta(days=1), dt.time.min),
                          'lim': MAX_PARTITION_ROWS+1}).mappings().all()
    require(len(rows) <= MAX_PARTITION_ROWS, 'derived_SQL_row_limit')
    return [dict(r) for r in rows]


def file_rows(path):
    if not path.exists(): return None, []
    sha, size = fingerprint(path)
    return {'sha256': sha, 'bytes': size}, source_rows({'source': str(path), 'sha256': sha, 'bytes': size})


def differences(before, after):
    a = {r['candle_timestamp']: r for r in before}; b = {r['candle_timestamp']: r for r in after}
    return {'missing': len(b.keys()-a.keys()), 'extra': len(a.keys()-b.keys()),
            'changed': sum(a[k] != b[k] for k in a.keys() & b.keys())}


def plan_rebuild(reports, root, store, operations_root, now=None, progress=None):
    paths = recovery_scope(reports); root = safe_root(root); op = guard(operations_root)
    require(root != op and root not in op.parents and op not in root.parents, 'operation_directory_overlaps_data')
    folder = op/('rebuild-'+uuid.uuid4().hex); folder.mkdir(parents=True, exist_ok=False)
    now = now or dt.datetime.now(IST); entries = []; sources = []
    for index, rel in enumerate(paths, 1):
        source = {'relative_path': rel}; sources.append(source)
        try:
            symbol, day = identity(rel)
            require(day < now.date(), 'session_not_closed')
            require(calendar_verified(day), 'calendar_review_required')
            window = session_window(day)
            require(window is not None, 'calendar_review_required')
            meta = store.metadata(symbol); raw_path = guard(root/rel)
            state, raw = file_rows(raw_path); require(state is not None, 'raw_file_missing')
            quality(raw, symbol, day, now, meta, preserve_session=True)
            sql = enrich(store.rows(meta['id'], day), symbol)
            base = normalized(raw, symbol, day, '1m')
            require(base == normalized(sql, symbol, day, '1m'), 'raw_SQL_Parquet_mismatch')
            regular = [r for r in raw if in_session(stamp(r['candle_timestamp']))]
            q = quality(regular, symbol, day, now, meta)
            require(not q['review_reasons'] and q['coverage']['missing'] == 0, 'incomplete_regular_session')
            candles = [Candle(**{k: meta[k] for k in ('internal_name', 'fyers_symbol', 'exchange', 'instrument_type')},
                              timestamp=stamp(r['candle_timestamp']), timeframe='1m',
                              **{k: r[k] for k in FIELDS}) for r in regular]
            source.update(status='SOURCE_VERIFIED', raw_rows=len(raw), regular_rows=len(regular),
                          preserved_outside_rows=len(raw)-len(regular), fingerprint=state, sql_hash=digest(base))
            for tf in SUPPORTED_TIMEFRAMES:
                item = {'source_relative_path': rel, 'timeframe': tf}; entries.append(item)
                try:
                    target_rel = rel.replace('raw/1m/', f'processed/{tf}/', 1)
                    target = guard(root/target_rel)
                    expected_rows = [_candle_to_row(c) for c in aggregate_1m_to_timeframe(candles, tf)]
                    require(bool(expected_rows), 'no_complete_buckets')
                    expected = normalized(expected_rows, symbol, day, tf)
                    old_sql = derived_sql(store, meta['id'], day, tf)
                    sql_values = normalized(old_sql, symbol, day, tf)
                    target_state, pq = file_rows(target)
                    require(all(all(str(r.get(k)) == str(meta[k]) for k in
                                    ('internal_name', 'exchange', 'instrument_type')) for r in pq),
                            'derived_instrument_metadata_mismatch')
                    pq_values = normalized(pq, symbol, day, tf)
                    candidate = folder/f'candidate-{index:03d}-{tf}.parquet'
                    write_parquet_new(candidate, expected_rows)
                    candidate_state, loaded = file_rows(candidate)
                    require(normalized(loaded, symbol, day, tf) == expected, 'candidate_readback_mismatch')
                    require(sql_values == normalized(derived_sql(store, meta['id'], day, tf), symbol, day, tf), 'derived_SQL_changed')
                    require(target_state == file_rows(target)[0], 'derived_file_changed')
                    item.update(status='ALREADY_CONSISTENT' if sql_values == expected == pq_values else 'NEEDS_REBUILD',
                                relative_path=target_rel, expected_rows=len(expected),
                                sql_changes=differences(sql_values, expected), parquet_changes=differences(pq_values, expected),
                                sql_before=old_sql, target_before=target_state, expected=expected,
                                candidate=str(candidate), candidate_fingerprint=candidate_state)
                except Exception as exc:
                    item.update(status='REVIEW_REQUIRED', reason=str(exc) if isinstance(exc, ValueError) else type(exc).__name__)
            require(state == file_rows(raw_path)[0] and base == normalized(enrich(store.rows(meta['id'], day), symbol), symbol, day, '1m'),
                    'raw_source_changed_during_plan')
        except Exception as exc:
            source.update(status='REVIEW_REQUIRED', reason=str(exc) if isinstance(exc, ValueError) else type(exc).__name__)
            for item in entries:
                if item['source_relative_path'] == rel:
                    item.update(status='REVIEW_REQUIRED', reason='source_not_stable_or_verified')
        if progress: progress(index, len(paths))
    plan = {'operation': 'CASH_DERIVED_REBUILD_PREVIEW', 'format_version': 1,
            'target_root': str(root), 'sources': sources, 'entries': entries,
            'market_data_modified': False, 'sql_modified': False, 'apply_allowed': False,
            'summary': {'source_partitions': len(paths), 'source_statuses': dict(Counter(s['status'] for s in sources)),
                        'source_review_reasons': dict(Counter(s['reason'] for s in sources if 'reason' in s)),
                        'derived_partitions': len(entries), 'statuses': dict(Counter(e['status'] for e in entries))},
            'scope': 'Scoped preview only. Raw rows preserved. No SQL or canonical Parquet writes; candidates are not promoted.'}
    write_json_new(folder/'plan.json', plan)
    return {'status': 'REBUILD_PREVIEW_READY', 'summary': plan['summary'], 'plan': str(folder/'plan.json'),
            'market_data_modified': False, 'sql_modified': False, 'apply_allowed': False}
