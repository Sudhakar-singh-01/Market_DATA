"""Pure record-level checks shared by Cash verification and Smart Fetch."""
import datetime as dt
from decimal import Decimal, InvalidOperation
from model.config.market_calendar import IST, session_windows

PRICE_FIELDS=('open','high','low','close')
COMPARE_FIELDS=(*PRICE_FIELDS,'volume','source','status')
RULE_VERSION='TIOS-Q4.2-SPLIT-SESSIONS'
MAX_PARTITION_ROWS=20000


def stamp(value):
    if isinstance(value,str):value=dt.datetime.fromisoformat(value)
    if hasattr(value,'to_pydatetime'):value=value.to_pydatetime()
    if not isinstance(value,dt.datetime):raise ValueError('Invalid timestamp')
    return value.replace(tzinfo=IST) if value.tzinfo is None else value.astimezone(IST)


def canonical(value,field):
    if value is None:return None
    if field in PRICE_FIELDS:
        n=Decimal(str(value))
        if not n.is_finite():raise ValueError('Non-finite price')
        return n.quantize(Decimal('.0001'))
    if field=='volume':
        n=Decimal(str(value))
        if not n.is_finite() or n!=n.to_integral():raise ValueError('Invalid volume')
        return int(n)
    return str(value)


def compare_rows(sql,parquet):
    """Counts and bounded samples. Duplicates are checked independently."""
    def index(rows):
        return {stamp(r['candle_timestamp']):tuple(canonical(r.get(k),k) for k in COMPARE_FIELDS) for r in rows}
    a,b=index(sql),index(parquet)
    left,right=sorted(a.keys()-b.keys()),sorted(b.keys()-a.keys())
    different=[k for k in sorted(a.keys()&b.keys()) if a[k]!=b[k]]
    return {'sql_only':len(left),'parquet_only':len(right),'value_mismatches':len(different),
        'sql_only_samples':list(map(str,left[:20])),'parquet_only_samples':list(map(str,right[:20])),
        'mismatch_samples':list(map(str,different[:20]))}


def integrity(rows,timeframe,day,now,*,allow_outside_session=False):
    from model.processing.timeframe_aggregator import _bucket_start, SUPPORTED_TIMEFRAMES
    seen=set();bad=[];duplicates=0
    windows=session_windows(day)
    for row in rows:
        errors=[]
        try:
            ts=stamp(row['candle_timestamp'])
            if ts in seen:duplicates+=1
            seen.add(ts)
            if ts.date()!=day or ts.second or ts.microsecond:errors.append('timestamp_alignment')
            if ts>now:errors.append('future_timestamp')
            if not allow_outside_session and not any(op<=ts<cl for op,cl in windows):errors.append('outside_session')
            if timeframe!='1m' and (timeframe not in SUPPORTED_TIMEFRAMES or _bucket_start(ts,timeframe)!=ts):errors.append('bucket_alignment')
            o,h,l,c=[canonical(row[k],k) for k in PRICE_FIELDS]
            if min(o,h,l,c)<=0 or not l<=min(o,c)<=max(o,c)<=h:errors.append('invalid_ohlc')
            if canonical(row['volume'],'volume')<0:errors.append('negative_volume')
            if row.get('status') not in {'OPEN','CLOSED'}:errors.append('invalid_status')
        except (ValueError,TypeError,KeyError,InvalidOperation,OverflowError):errors.append('malformed_record')
        if errors:bad.append({'timestamp':str(row.get('candle_timestamp')),'reasons':errors})
    return {'rows':len(rows),'invalid':len(bad),'duplicates':duplicates,'samples':bad[:30]}


def parquet_has_duplicate_keys(path, keys):
    """Exact cross-batch detection with bounded RAM, even for unsorted chain UUIDs.

    The scratch SQLite index is removed on exit; the source file is never changed.
    """
    import json
    import sqlite3
    import tempfile
    from contextlib import closing
    from pathlib import Path
    import pyarrow.parquet as pq
    with tempfile.TemporaryDirectory(prefix='tios-verify-') as folder:
        # sqlite3.Connection's context manager commits/rolls back but does not
        # close the handle. Windows cannot remove the temporary database while
        # that handle is open, so own its lifetime explicitly.
        with closing(sqlite3.connect(str(Path(folder)/'keys.sqlite'))) as db:
            db.execute('PRAGMA cache_size=-2048')
            db.execute('CREATE TABLE seen (key TEXT PRIMARY KEY) WITHOUT ROWID')
            for batch in pq.ParquetFile(path).iter_batches(batch_size=2000,columns=keys):
                rows=batch.to_pandas().itertuples(index=False,name=None)
                try:db.executemany('INSERT INTO seen VALUES (?)',((json.dumps(r,default=str),) for r in rows))
                except sqlite3.IntegrityError:return True
                db.commit()
    return False
