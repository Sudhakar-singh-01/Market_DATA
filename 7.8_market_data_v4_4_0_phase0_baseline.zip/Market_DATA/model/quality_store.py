"""Cash job/report metadata. Explicit migration only; reuses ingestion_jobs.

Market data reads/writes remain in their existing repositories. No startup DDL.
"""
import datetime as dt
import hashlib
import json
from sqlalchemy import inspect, text
from sqlalchemy.exc import IntegrityError
from model.config.market_calendar import IST
from model.fno.errors import DuplicateJobError
from model.fno.job_store import dedupe_key, COUNTERS

ADDITIONS = {
    'params':'JSON NULL', 'state':'VARCHAR(16) NULL', 'active_key':'CHAR(64) NULL',
    'dedupe_key':'CHAR(64) NULL', 'resumed_from':'BIGINT NULL',
    'heartbeat_at':'DATETIME NULL', 'cancel_requested':'BOOLEAN NOT NULL DEFAULT 0',
    'result':'JSON NULL', 'error':'TEXT NULL', 'created_at':'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
    **{k:'BIGINT NOT NULL DEFAULT 0' for k in COUNTERS},
}
QUALITY_DDL = '''CREATE TABLE IF NOT EXISTS data_quality_results (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, job_id BIGINT NOT NULL,
 check_name VARCHAR(80) NOT NULL, scope VARCHAR(240) NOT NULL,
 status VARCHAR(16) NOT NULL, details JSON NULL,
 run_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_quality_job (job_id,id), INDEX idx_quality_status (status,run_at)
) ENGINE=InnoDB'''
EVENT_DDL = '''CREATE TABLE IF NOT EXISTS pipeline_events (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, occurred_at DATETIME(3) NOT NULL,
 kind VARCHAR(40) NOT NULL, severity VARCHAR(16) NOT NULL, symbol VARCHAR(100) NULL,
 details JSON NOT NULL, event_key CHAR(64) NULL, delivery VARCHAR(16) NOT NULL DEFAULT 'DISABLED',
 INDEX idx_event_time (occurred_at), INDEX idx_event_kind_time (kind,occurred_at),
 UNIQUE KEY uq_event_key (event_key)
) ENGINE=InnoDB'''


def migration_plan(engine):
    inspector=inspect(engine)
    tables=set(inspector.get_table_names())
    if 'ingestion_jobs' not in tables:
        raise ValueError('Apply existing database/schema.sql to the CASH database first')
    cols={c['name'] for c in inspector.get_columns('ingestion_jobs')}
    statements=[f'ALTER TABLE ingestion_jobs ADD COLUMN {k} {v}' for k,v in ADDITIONS.items() if k not in cols]
    indexes={i['name'] for i in inspector.get_indexes('ingestion_jobs')}
    if 'uq_pipeline_active' not in indexes:
        statements.append('CREATE UNIQUE INDEX uq_pipeline_active ON ingestion_jobs (active_key)')
    if 'data_quality_results' not in tables:statements.append(QUALITY_DDL)
    if 'pipeline_events' not in tables:statements.append(EVENT_DDL)
    return statements


def migrate(engine, confirmed=False):
    if not confirmed:raise ValueError('Explicit migration confirmation required')
    statements=migration_plan(engine)
    with engine.begin() as conn:
        for sql in statements:conn.execute(text(sql))
    return len(statements)


def ready(engine):
    return not migration_plan(engine)


def now():
    return dt.datetime.now(IST).replace(tzinfo=None)


def decode(row):
    if row is None:return None
    d=dict(row)
    for k in ('params','result','details'):
        if isinstance(d.get(k),(str,bytes)):d[k]=json.loads(d[k])
    return d


class QualityStore:
    """Same runner contract as FnoJobStore; FnoJobRunner is reused."""
    def __init__(self,engine):self.engine=engine
    def query(self,sql,params=None):
        with self.engine.connect() as c:return [decode(r) for r in c.execute(text(sql),params or {}).mappings()]
    def submit(self,job_type,params,resumed_from=None):
        if job_type not in {'VERIFY','SMART_FETCH','AGGREGATION','SCHEDULE_EOD','WORKFLOW'}:raise ValueError('Unsupported cash job')
        key=dedupe_key(job_type,params)
        try:
            with self.engine.begin() as c:
                jid=c.execute(text("INSERT INTO ingestion_jobs (job_type,status,state,params,dedupe_key,active_key,resumed_from) "
                    "VALUES (:t,'queued','PENDING',:p,:k,:k,:r)"),dict(t=job_type,p=json.dumps(params,default=str),k=key,r=resumed_from)).lastrowid
                c.execute(text("INSERT INTO audit_log (actor_role,action,target,parameters,records_affected,result) VALUES ('admin','PIPELINE_SUBMIT','ingestion_jobs',:p,1,'queued')"),{'p':json.dumps({'id':jid,'type':job_type,'params':params},default=str)})
                return jid
        except IntegrityError:
            rows=self.query('SELECT id FROM ingestion_jobs WHERE active_key=:k',{'k':key})
            if not rows:raise
            raise DuplicateJobError(rows[0]['id'])
    def get(self,jid):
        rows=self.query('SELECT * FROM ingestion_jobs WHERE id=:i AND params IS NOT NULL',{'i':jid})
        return rows[0] if rows else None
    def list(self,state=None,limit=50,offset=0):
        return self.query('SELECT * FROM ingestion_jobs WHERE params IS NOT NULL'+(' AND state=:s' if state else '')+
            ' ORDER BY id DESC LIMIT :l OFFSET :o',{'s':state,'l':min(200,int(limit)),'o':max(0,int(offset))})
    def claim_next(self,job_types=None):
        for r in self.query("SELECT id,job_type FROM ingestion_jobs WHERE state='PENDING' ORDER BY id LIMIT 100"):
            if job_types and r['job_type'] not in job_types:continue
            with self.engine.begin() as c:
                n=c.execute(text("UPDATE ingestion_jobs SET state='RUNNING',status='running',started_at=:n,heartbeat_at=:n WHERE id=:i AND state='PENDING'"),{'n':now(),'i':r['id']}).rowcount
            if n:return self.get(r['id'])
    def heartbeat(self,jid):
        with self.engine.begin() as c:c.execute(text("UPDATE ingestion_jobs SET heartbeat_at=:n WHERE id=:i AND state='RUNNING'"),{'i':jid,'n':now()})
    def add_counters(self,jid,**deltas):
        if set(deltas)-set(COUNTERS):raise ValueError('Unsupported counter')
        if not deltas:return
        with self.engine.begin() as c:c.execute(text('UPDATE ingestion_jobs SET '+','.join(k+'='+k+'+:'+k for k in deltas)+' WHERE id=:i'),{'i':jid,**deltas})
    def progress(self,jid,result):
        with self.engine.begin() as c:c.execute(text('UPDATE ingestion_jobs SET result=:r,heartbeat_at=:n WHERE id=:i'),{'i':jid,'r':json.dumps(result,default=str),'n':now()})
    def cancel_requested(self,jid):
        row=self.get(jid);return bool(row and row['cancel_requested'])
    def request_cancel(self,jid):
        with self.engine.begin() as c:
            c.execute(text("UPDATE ingestion_jobs SET cancel_requested=1 WHERE id=:i AND state IN ('PENDING','RUNNING')"),{'i':jid})
            c.execute(text("UPDATE ingestion_jobs SET state='CANCELLED',status='cancelled',active_key=NULL,finished_at=:n WHERE id=:i AND state='PENDING'"),{'i':jid,'n':now()})
        return 'Cancellation requested'
    def finish(self,jid,state,error=None,result=None):
        if state not in {'SUCCESS','PARTIAL','FAILED','CANCELLED','INTERRUPTED','NO_DATA'}:raise ValueError('Invalid final state')
        with self.engine.begin() as c:c.execute(text('UPDATE ingestion_jobs SET state=:s,status=:status,active_key=NULL,finished_at=:n,error=:e,result=:r WHERE id=:i'),
            {'i':jid,'s':state,'status':state.lower(),'n':now(),'e':error,'r':json.dumps(result or {},default=str)})
    def recover_interrupted(self,seconds):
        rows=self.query("SELECT id FROM ingestion_jobs WHERE state='RUNNING' AND COALESCE(heartbeat_at,started_at,created_at)<:c",{'c':now()-dt.timedelta(seconds=seconds)})
        for row in rows:self.finish(row['id'],'INTERRUPTED','Worker heartbeat expired; explicit resume available',self.get(row['id']).get('result'))
        return [r['id'] for r in rows]
    def resume(self,jid):
        r=self.get(jid)
        if not r or r['state'] not in {'INTERRUPTED','FAILED','PARTIAL'}:raise ValueError('Only interrupted/failed/partial jobs can resume')
        return self.submit(r['job_type'],r['params'],jid)
    def finding(self,jid,name,scope,status,details):
        if status not in {'PASS','WARNING','FAIL','NOT_VERIFIED'}:raise ValueError('Unknown finding status')
        with self.engine.begin() as c:c.execute(text('INSERT INTO data_quality_results (job_id,check_name,scope,status,details) VALUES (:j,:n,:s,:t,:d)'),
            {'j':jid,'n':name,'s':scope[:240],'t':status,'d':json.dumps(details,default=str)})
    def findings(self,jid,check=None,status=None,after=0,limit=200):
        where='job_id=:j AND id>:after'
        if check:where+=' AND check_name=:check'
        if status:where+=' AND status=:status'
        return self.query('SELECT * FROM data_quality_results WHERE '+where+' ORDER BY id LIMIT :l',
            {'j':jid,'after':after,'check':check,'status':status,'l':min(2000,limit)})
