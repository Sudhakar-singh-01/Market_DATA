"""Read-only, exhaustive checks of a manually imported, isolated recovery database.

Dump text is parsed as data and is never sent to a database. DDL equivalence,
market health and application-level parity are deliberately outside this check.
"""
import contextlib
import datetime as dt
import json
import os
import re
import sqlite3
import tempfile
import uuid
from pathlib import Path, PurePosixPath
from sqlalchemy import inspect, text
from model.backup_service import sha256_file, sql_literal

MAX_LINE_BYTES = 16 * 1024 * 1024
MAX_TABLES = 10000
MAX_SCHEMA_BYTES = 64 * 1024 * 1024


def _no_symlink_ancestors(path):
    path=Path(path).absolute()
    if any(p.is_symlink() for p in (path,*path.parents)):
        raise ValueError('PATH_SYMLINK')


_IDENT = r'(?:`(?:``|[^`])+`|[A-Za-z_][A-Za-z0-9_$]*)'
_INSERT = re.compile(r'^INSERT INTO ('+_IDENT+r') \((.+)\) VALUES \((.*)\);$')
_LITERAL = re.compile(r"(?:NULL|CONVERT\(X'[0-9a-f]*' USING utf8mb4\)|X'[0-9a-f]*'|'[-0-9:. T]+'|[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)")
_SETTINGS = {"SET NAMES utf8mb4;", "SET SESSION SQL_MODE='NO_AUTO_VALUE_ON_ZERO';", "SET SESSION time_zone='+00:00';", 'SET FOREIGN_KEY_CHECKS=0;', 'SET FOREIGN_KEY_CHECKS=1;'}


def _name(token):
    if not re.fullmatch(_IDENT, token): raise ValueError('DUMP_GRAMMAR')
    return token[1:-1].replace('``','`') if token.startswith('`') else token


def _row(value):
    # CONVERT parentheses contain no commas; no general-purpose SQL parser needed.
    parts=value.split(',')
    if not parts or any(not _LITERAL.fullmatch(p) for p in parts): raise ValueError('DUMP_GRAMMAR')
    for p in parts:
        if p.startswith("CONVERT(X'"):
            try: bytes.fromhex(p[10:p.index("' USING")]).decode('utf-8')
            except (ValueError,UnicodeError): raise ValueError('DUMP_GRAMMAR') from None
    return json.dumps(parts,ensure_ascii=True,separators=(',',':'))


class RecoveryVerifier:
    def __init__(self, backup_service, recovery_engine, live_database_names, report_root=None):
        self.backups=backup_service
        self.backup_service=backup_service
        self.engine=recovery_engine
        self.recovery_engine=recovery_engine
        self.live_names={str(n).casefold() for n in live_database_names if n}
        self.report_root=Path(report_root or self.backups.recovery_root.parent/'recovery_reports')

    def _identity(self, manifest, confirmation):
        name=self.engine.url.database
        if (self.engine.dialect.name!='mysql' or not name or not re.fullmatch(r'tios_recovery_[A-Za-z0-9_]{1,50}',name) or
            name.casefold() in self.live_names or name.casefold()==str(manifest['database']).casefold()):
            raise ValueError('TARGET_IDENTITY')
        if confirmation!='VERIFY '+name: raise ValueError('CONFIRMATION')
        return name

    @contextlib.contextmanager
    def _snapshot(self, name):
        with self.engine.connect().execution_options(isolation_level='REPEATABLE READ') as conn:
            zone=conn.exec_driver_sql('SELECT @@session.time_zone').scalar()
            conn.commit()
            try:
                conn.exec_driver_sql("SET SESSION time_zone = '+00:00'")
                conn.commit()
                conn.exec_driver_sql('START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY')
                if conn.exec_driver_sql('SELECT DATABASE()').scalar()!=name: raise ValueError('TARGET_IDENTITY')
                bad=conn.execute(text("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=:db AND TABLE_TYPE='BASE TABLE' AND ENGINE <> 'InnoDB'"),{'db':name}).scalar()
                for kind,field in [('TRIGGERS','TRIGGER_SCHEMA'),('ROUTINES','ROUTINE_SCHEMA'),('EVENTS','EVENT_SCHEMA')]:
                    bad+=conn.execute(text('SELECT COUNT(*) FROM information_schema.'+kind+' WHERE '+field+'=:db'),{'db':name}).scalar()
                if bad: raise ValueError('UNSUPPORTED_OBJECTS')
                yield conn
            finally:
                conn.rollback()
                try:
                    conn.exec_driver_sql('SET SESSION time_zone = %s',(zone,))
                    conn.commit()
                except Exception:
                    conn.invalidate()
                    raise

    def _staged(self, backup_id, recovery_id, verified):
        if not re.fullmatch(re.escape(backup_id)+r'_[0-9a-f]{8}',recovery_id): raise ValueError('STAGE_IDENTITY')
        root=self.backups.recovery_root
        _no_symlink_ancestors(root)
        target=root/recovery_id
        if root.is_symlink() or target.is_symlink() or not target.is_dir(): raise ValueError('STAGE_IDENTITY')
        for live in self.backups.catalog.roots.values():
            if live:
                a,b=root.resolve(),Path(live).resolve()
                if a==b or a in b.parents or b in a.parents: raise ValueError('STAGE_LOCATION')
        members=verified['manifest']['members']
        expected=set(members)|{'manifest.json'}
        actual=set()
        # Archive member names remain POSIX even when the verifier runs on Windows.
        allowed_dirs={str(PurePosixPath(n).parent) for n in expected}
        allowed_dirs|={str(p) for n in expected for p in PurePosixPath(n).parents if str(p)!='.'}
        for p in target.rglob('*'):
            rel=p.relative_to(target).as_posix()
            if p.is_symlink(): raise ValueError('STAGE_SYMLINK')
            if p.is_dir():
                if rel not in allowed_dirs: raise ValueError('STAGE_INVENTORY')
            elif p.is_file(): actual.add(rel)
            else: raise ValueError('STAGE_INVENTORY')
        if actual!=expected: raise ValueError('STAGE_INVENTORY')
        if json.loads((target/'manifest.json').read_text(encoding='utf-8'))!=verified['manifest']: raise ValueError('STAGE_MANIFEST')
        for n,entry in members.items():
            p=target/n
            if p.stat().st_size!=entry['bytes'] or sha256_file(p)!=entry['sha256']: raise ValueError('STAGE_CHECKSUM')
        return target

    def _source(self, path, db, expected):
        if (not isinstance(expected,dict) or len(expected)>MAX_TABLES or
            any(not isinstance(n,str) or not n or type(c) is not int or c<0 for n,c in expected.items())):
            raise ValueError('MANIFEST_TABLES')
        columns={}; creates=set(); counts={n:0 for n in expected}; ddl=False; ddls={}; ddl_lines=[]; ddl_name=None; schema_bytes=0
        with path.open('rb') as source:
            while True:
                raw=source.readline(MAX_LINE_BYTES+1)
                if not raw: break
                if len(raw)>MAX_LINE_BYTES: raise ValueError('DUMP_LINE_LIMIT')
                line=raw.decode('utf-8').rstrip('\n')
                if ddl or line.startswith('CREATE TABLE '):
                    schema_bytes+=len(raw)
                    if schema_bytes>MAX_SCHEMA_BYTES: raise ValueError('DUMP_SCHEMA_LIMIT')
                if ddl:
                    ddl_lines.append(line)
                    if line.endswith(';'):
                        ddl=False; ddls[ddl_name]='\n'.join(ddl_lines).strip().removesuffix(';')
                    continue
                if line.startswith('CREATE TABLE '):
                    match=re.match(r'^CREATE TABLE ('+_IDENT+r')\s*\(',line)
                    if not match: raise ValueError('DUMP_GRAMMAR')
                    name=_name(match[1])
                    if name in creates or name not in expected: raise ValueError('DUMP_INVENTORY')
                    creates.add(name); ddl=not line.endswith(';'); ddl_name=name; ddl_lines=[line]
                    if not ddl: ddls[name]=line.strip().removesuffix(';')
                    continue
                if line in _SETTINGS or line=='-- TIOS recovery dump. Import into an EMPTY, separate recovery database.': continue
                match=_INSERT.fullmatch(line)
                if not match: raise ValueError('DUMP_GRAMMAR')
                name=_name(match[1]); cols=tuple(_name(c) for c in match[2].split(','))
                if name not in creates or len(set(cols))!=len(cols): raise ValueError('DUMP_INVENTORY')
                if name in columns and columns[name]!=cols: raise ValueError('DUMP_COLUMNS')
                columns[name]=cols
                row=_row(match[3])
                if len(json.loads(row))!=len(cols): raise ValueError('DUMP_COLUMNS')
                db.execute('INSERT INTO rows VALUES (?,?,1) ON CONFLICT(t,r) DO UPDATE SET n=n+1',(name,row))
                counts[name]+=1
        if ddl or creates!=set(expected) or counts!=expected: raise ValueError('DUMP_INVENTORY')
        db.commit()
        return columns,ddls

    def _ddl(self, conn, table):
        return conn.exec_driver_sql('SHOW CREATE TABLE '+conn.dialect.identifier_preparer.quote(table)).one()[1]

    def _compare(self, conn, db, expected, columns, name, ddls):
        inspector=inspect(conn); quote=conn.dialect.identifier_preparer.quote
        if inspector.get_view_names() or set(inspector.get_table_names())!=set(expected): raise ValueError('TABLE_INVENTORY')
        for table,count in expected.items():
            if self._ddl(conn,table).strip().removesuffix(';')!=ddls[table]: raise ValueError('SCHEMA_DDL_MISMATCH')
            insertable=tuple(c['name'] for c in inspector.get_columns(table) if not c.get('computed'))
            cols=columns.get(table,insertable)
            if cols!=insertable: raise ValueError('COLUMN_INVENTORY')
            seen=0
            result=conn.execution_options(stream_results=True).exec_driver_sql('SELECT '+','.join(quote(c) for c in cols)+' FROM '+quote(table))
            try:
                for row in result:
                    canonical=json.dumps([sql_literal(v) for v in row],ensure_ascii=True,separators=(',',':'))
                    changed=db.execute('UPDATE rows SET n=n-1 WHERE t=? AND r=? AND n>0',(table,canonical)).rowcount
                    if changed!=1: raise ValueError('ROW_CONTENT')
                    seen+=1
            finally: result.close()
            if seen!=count: raise ValueError('ROW_COUNT')
            if db.execute('SELECT 1 FROM rows WHERE t=? AND n<>0 LIMIT 1',(table,)).fetchone(): raise ValueError('ROW_CONTENT')
            for fk in inspector.get_foreign_keys(table):
                if fk.get('referred_schema') not in (None,name) or fk['referred_table'] not in expected: raise ValueError('EXTERNAL_FOREIGN_KEY')
                local=fk['constrained_columns']; remote=fk['referred_columns']
                if not local or len(local)!=len(remote): raise ValueError('FOREIGN_KEY_METADATA')
                present=' AND '.join('c.'+quote(c)+' IS NOT NULL' for c in local)
                join=' AND '.join('p.'+quote(r)+'=c.'+quote(c) for c,r in zip(local,remote))
                sql='SELECT 1 FROM '+quote(table)+' c WHERE '+present+' AND NOT EXISTS (SELECT 1 FROM '+quote(fk['referred_table'])+' p WHERE '+join+') LIMIT 1'
                if conn.exec_driver_sql(sql).first(): raise ValueError('FOREIGN_KEY_ORPHAN')

    def verify(self, backup_id, recovery_id, *, role, confirmation):
        self.backups._admin(role)
        report={'format':'tios-recovery-verification-v1','backup_id':backup_id,'recovery_id':recovery_id,
                'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'status':'FAILED','restore_tested':False,
                'market_parity':'NOT_TESTED','schema_coverage':'Exact server CREATE TABLE text (outer whitespace and terminal semicolon ignored), including empty tables. Server version rewrites or AUTO_INCREMENT differences fail closed. Market health NOT_TESTED.',
                'limitations':['Requires metadata visibility; hidden database objects cannot be certified absent.',
                               'Keep the recovery database and staged files idle; verification is point-in-time evidence, not live cutover approval.',
                               'File hashes establish copy fidelity, not Parquet readability, SQL/Parquet parity or authenticity of a locally altered archive.'],
                'checks':[],'errors':[]}
        try:
            verified=self.backups.verify(backup_id,role=role)
            report['backup_sha256']=verified['sha256']; report['checks'].append('ARCHIVE_CHECKSUM_AND_INVENTORY')
            name=self._identity(verified['manifest'],confirmation)
            report['target']={'database':name,'host':self.engine.url.host,'port':self.engine.url.port}
            staged=self._staged(backup_id,recovery_id,verified); report['checks'].append('STAGED_FILES_CHECKSUM_AND_INVENTORY')
            with tempfile.TemporaryDirectory(prefix='tios-verify-') as temp:
                for protected in [self.backups.backup_root,self.backups.recovery_root,*self.backups.catalog.roots.values()]:
                    if protected and (Path(protected).resolve()==Path(temp).resolve() or Path(protected).resolve() in Path(temp).resolve().parents):
                        raise ValueError('TEMP_LOCATION')
                with contextlib.closing(sqlite3.connect(str(Path(temp)/'rows.sqlite'))) as db:
                    db.execute('CREATE TABLE rows(t TEXT,r TEXT,n INTEGER,PRIMARY KEY(t,r)) WITHOUT ROWID')
                    columns,ddls=self._source(staged/'database.sql',db,verified['manifest']['tables'])
                    with self._snapshot(name) as conn:
                        self._compare(conn,db,verified['manifest']['tables'],columns,name,ddls)
            if self.backups.verify(backup_id,role=role)['sha256']!=verified['sha256']: raise ValueError('ARCHIVE_CHANGED')
            self._staged(backup_id,recovery_id,verified)
            report['checks']+=['EXACT_SCHEMA_DDL','EXACT_TYPED_ROW_MULTISET','TABLE_COUNTS_AND_INVENTORY','FOREIGN_KEY_ORPHANS','VISIBLE_UNSUPPORTED_OBJECTS_ABSENT']
            report['status']='VERIFIED'; report['scope']='SQL_AND_FILES_VERIFIED'
        except Exception as exc:
            # No driver error text, SQL text, credentials or row values enter reports.
            code=str(exc) if type(exc) is ValueError and re.fullmatch('[A-Z_]+',str(exc)) else 'VERIFICATION_ERROR'
            report['errors'].append(code)
        report['completed_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        # Reports are append-only evidence outside all staged and live inputs.
        destination=self.report_root.resolve()
        protected=[self.backups.backup_root,self.backups.recovery_root]
        protected += [p for p in self.backups.catalog.roots.values() if p]
        for root in protected:
            root=Path(root).resolve()
            if destination==root or root in destination.parents or destination in root.parents:
                raise ValueError('Report directory must be separate from backup, recovery and live roots')
        _no_symlink_ancestors(self.report_root)
        self.report_root.mkdir(parents=True,exist_ok=True)
        path=self.report_root/(uuid.uuid4().hex+'.json')
        report['report_path']=str(path)
        try:
            with path.open('x',encoding='utf-8') as out:
                json.dump(report,out,indent=2,sort_keys=True)
                out.flush(); os.fsync(out.fileno())
                if hasattr(os,'fchmod'):
                    os.fchmod(out.fileno(),0o400)
            if not hasattr(os,'fchmod'):
                path.chmod(0o400)
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return report
