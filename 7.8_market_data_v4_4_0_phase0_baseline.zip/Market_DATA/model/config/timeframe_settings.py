"""
model/config/timeframe_settings.py
Loads and validates config/timeframe_settings.yaml. Enforces the
project's core rule: base_timeframe must be 1m (spec Section 10 --
"base timeframe is 1m" is an explicit required validation).
"""

from dataclasses import dataclass
from pathlib import Path

from model.config.yaml_loader import load_yaml
from model.exceptions import ConfigurationError

_SETTINGS_PATH = Path(__file__).resolve().parents[2] / "config" / "timeframe_settings.yaml"


@dataclass(frozen=True)
class DerivedTimeframe:
    name: str
    source: str
    multiplier: int | None  # None for session-based timeframes (e.g. 1d)


@dataclass(frozen=True)
class TimeframeSettings:
    base_timeframe: str
    fyers_native_timeframes: list
    derived_timeframes: list


def load_timeframe_settings() -> TimeframeSettings:
    raw = load_yaml(_SETTINGS_PATH)

    if "base_timeframe" not in raw:
        raise ConfigurationError("timeframe_settings.yaml is missing required key: base_timeframe")

    base_timeframe = str(raw["base_timeframe"])
    if base_timeframe != "1m":
        raise ConfigurationError(
            f"timeframe_settings.yaml base_timeframe must be '1m' (project principle: 1m is the "
            f"canonical/base timeframe), got '{base_timeframe}'"
        )

    fyers_native = raw.get("fyers_native_timeframes")
    if not fyers_native or not isinstance(fyers_native, list):
        raise ConfigurationError("timeframe_settings.yaml fyers_native_timeframes must be a non-empty list")
    if base_timeframe not in fyers_native:
        raise ConfigurationError(
            f"timeframe_settings.yaml base_timeframe '{base_timeframe}' must appear in fyers_native_timeframes"
        )

    derived_raw = raw.get("derived_timeframes")
    if derived_raw is None:
        raise ConfigurationError("timeframe_settings.yaml is missing required key: derived_timeframes")
    if not isinstance(derived_raw, list):
        raise ConfigurationError("timeframe_settings.yaml derived_timeframes must be a list")

    derived_timeframes = []
    seen_names = set()
    for entry in derived_raw:
        for key in ("name", "source"):
            if key not in entry:
                raise ConfigurationError(f"timeframe_settings.yaml derived_timeframes entry missing '{key}': {entry}")

        name = str(entry["name"])
        if name in seen_names:
            raise ConfigurationError(f"timeframe_settings.yaml has a duplicate derived timeframe name: '{name}'")
        seen_names.add(name)

        source = str(entry["source"])
        if source != base_timeframe:
            raise ConfigurationError(
                f"timeframe_settings.yaml derived timeframe '{name}' has source '{source}', "
                f"but all derived timeframes must source from base_timeframe '{base_timeframe}'"
            )

        multiplier = entry.get("multiplier")
        if multiplier is not None:
            multiplier = int(multiplier)
            if multiplier <= 1:
                raise ConfigurationError(
                    f"timeframe_settings.yaml derived timeframe '{name}' has invalid multiplier {multiplier} "
                    f"(must be > 1, or null for session-based timeframes like 1d)"
                )

        derived_timeframes.append(DerivedTimeframe(name=name, source=source, multiplier=multiplier))

    return TimeframeSettings(
        base_timeframe=base_timeframe,
        fyers_native_timeframes=[str(tf) for tf in fyers_native],
        derived_timeframes=derived_timeframes,
    )
