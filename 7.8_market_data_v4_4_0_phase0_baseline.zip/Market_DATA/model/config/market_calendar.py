"""
model/config/market_calendar.py
Single source of truth for "is the exchange open on this date?".

A date is a trading day when it is Monday-Friday AND not listed in
config/holidays.yaml. The holiday list is maintained by the user from the
official NSE holiday circular -- no dates are hard-coded here, so a wrong
guess can never silently hide real data gaps.

If config/holidays.yaml does not exist, no holidays are applied (the
previous Mon-Fri behaviour). A malformed file raises ConfigurationError.

File format:
    holidays:
      - date: 2026-10-02
        name: Gandhi Jayanti
      - 2026-11-08            # a bare date is also accepted
"""

import datetime
import threading
import functools
from pathlib import Path
from typing import Optional

import yaml
from zoneinfo import ZoneInfo

from model.exceptions import ConfigurationError

_HOLIDAY_PATH = Path(__file__).resolve().parents[2] / "config" / "holidays.yaml"

_lock = threading.Lock()
_cache_version = None
_cache: Optional[dict] = None  # {date: name}; None = not loaded yet
_path_override: Optional[Path] = None


def _to_date(value, source: str) -> datetime.date:
    if isinstance(value, datetime.datetime):
        return value.date()
    if isinstance(value, datetime.date):
        return value
    if isinstance(value, str):
        try:
            return datetime.date.fromisoformat(value.strip())
        except ValueError:
            pass
    raise ConfigurationError(f"{source}: invalid holiday date {value!r} (use YYYY-MM-DD).")


def parse_holidays(data) -> dict:
    """Turn parsed YAML into {date: name}. Pure function (easy to test)."""
    if data is None:
        return {}
    if not isinstance(data, dict) or not isinstance(data.get("holidays", []), list):
        raise ConfigurationError("holidays.yaml must contain a 'holidays:' list.")
    out = {}
    for item in data.get("holidays") or []:
        if isinstance(item, dict):
            if "date" not in item:
                raise ConfigurationError(f"holidays.yaml: entry {item!r} has no 'date'.")
            out[_to_date(item["date"], "holidays.yaml")] = str(item.get("name", "") or "Holiday")
        else:
            out[_to_date(item, "holidays.yaml")] = "Holiday"
    return out


def _load() -> dict:
    path = _path_override or _HOLIDAY_PATH
    from model.config.runtime_paths import config_path
    path = config_path(path)
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"Invalid YAML syntax in {path}: {exc}") from exc
    return parse_holidays(data)


def get_holidays(segment="CASH") -> dict:
    global _cache, _cache_version
    path=_path_override or _HOLIDAY_PATH
    from model.config.runtime_paths import config_path
    path=config_path(path)
    stat=path.stat() if path.exists() else None
    version=(str(path),stat.st_mtime_ns if stat else None,stat.st_size if stat else None)
    with _lock:
        if _cache is None or version!=_cache_version:
            _cache = _load();_cache_version=version
        common = dict(_cache)
    extras = calendar_metadata().get("segment_holidays", {}).get(segment, [])
    common.update(parse_holidays({"holidays": extras}))
    return common


def reload_holidays(path: Optional[Path] = None) -> dict:
    """Drop the cache (and optionally point at another file); used by tests and after edits."""
    global _cache, _path_override
    with _lock:
        _path_override = Path(path) if path else None
        _cache = None
    return get_holidays()


def is_holiday(day: datetime.date, segment="CASH") -> bool:
    return day in get_holidays(segment)


def holiday_name(day: datetime.date, segment="CASH") -> Optional[str]:
    return get_holidays(segment).get(day)


def _special(day, segment="CASH"):
    item = calendar_metadata().get("special_sessions", {}).get(day.isoformat())
    if item is not None and segment not in item.get("segments", ["CASH", "FNO"]):
        return None
    return item


def is_trading_day(day: datetime.date, segment="CASH") -> bool:
    special = _special(day, segment)
    if special is not None:
        return bool(special.get("intervals") or (special.get("open") and special.get("close")))
    return day.weekday() < 5 and day not in get_holidays(segment)


def previous_trading_day(day: datetime.date) -> datetime.date:
    d = day - datetime.timedelta(days=1)
    while not is_trading_day(d):
        d -= datetime.timedelta(days=1)
    return d


IST = ZoneInfo("Asia/Kolkata")


def today_ist():
    return datetime.datetime.now(IST).date()


def calendar_metadata():
    """Small configuration read; never downloads or modifies the calendar."""
    path = _path_override or _HOLIDAY_PATH
    from model.config.runtime_paths import config_path
    path = config_path(path)
    if not path.exists():
        return {}
    info=path.stat()
    return _metadata_cached(str(path),info.st_mtime_ns,info.st_size)


@functools.lru_cache(maxsize=4)
def _metadata_cached(path,mtime,size):
    with open(path,encoding='utf-8') as stream:data=yaml.safe_load(stream) or {}
    return data if isinstance(data,dict) else {}


def calendar_verified(day, segment="CASH"):
    data = calendar_metadata()
    known = data.get("verified_years", {}).get(segment, [])
    special = _special(day, segment)
    earliest=data.get("verified_from",{}).get(segment)
    return day.year in known and (not earliest or day>=_to_date(earliest,"verified_from")) and not (special is not None and not special.get("verified", False))


def session_windows(day, segment="CASH", fallback_close=None, session=None):
    """Ordered, non-overlapping trading intervals; every close is exclusive."""
    special = _special(day, segment)
    if special is not None:
        if "intervals" in special:
            items = special["intervals"]
            if not isinstance(items, list) or not items:
                raise ConfigurationError("Special-session intervals must be a non-empty list")
        elif not special.get("open") or not special.get("close"):
            return ()
        else:
            items = [special]
    elif not is_trading_day(day, segment):
        return ()
    else:
        items = [{"open": session.open if session is not None else "09:15",
                  "close": session.close if session is not None else (fallback_close or ("15:30" if segment == "CASH" else "15:40"))}]
    windows = []
    for item in items:
        try:
            op, cl = (datetime.time.fromisoformat(str(item[k])) if isinstance(item[k], str)
                      else item[k] for k in ("open", "close"))
            if (op.tzinfo or cl.tzinfo or op.second or cl.second or op.microsecond or cl.microsecond
                    or cl <= op):
                raise ValueError("Invalid minute-aligned interval")
            start, end = datetime.datetime.combine(day, op, IST), datetime.datetime.combine(day, cl, IST)
            if windows and start < windows[-1][1]:
                raise ValueError("Intervals must be ordered and non-overlapping")
            windows.append((start, end))
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            raise ConfigurationError("Invalid special-session interval") from exc
    return tuple(windows)


def session_window(day, segment="CASH", fallback_close=None, session=None):
    """Compatibility envelope for daily open/close. Use session_windows for membership."""
    windows = session_windows(day, segment, fallback_close, session)
    return (windows[0][0], windows[-1][1]) if windows else None


def in_session(ts, segment="CASH", session=None):
    ts = ts.replace(tzinfo=IST) if ts.tzinfo is None else ts.astimezone(IST)
    return any(op <= ts < cl for op, cl in session_windows(ts.date(), segment, session=session))


def expected_starts(day, segment="CASH", now=None, lag_seconds=0):
    cutoff = None
    if now is not None:
        if now.tzinfo is None:
            now = now.replace(tzinfo=IST)
        cutoff = now.astimezone(IST) - datetime.timedelta(seconds=lag_seconds)
    result = []
    for start, close in session_windows(day, segment):
        end = min(close, cutoff) if cutoff is not None else close
        result.extend(start + datetime.timedelta(minutes=i)
                      for i in range(max(0, int((end-start).total_seconds()//60))))
    return result


def live_session_status(now=None, segment="CASH", session=None):
    """Verified exchange session decision; never used to gate historical fetches."""
    now = now or datetime.datetime.now(IST)
    now = now.replace(tzinfo=IST) if now.tzinfo is None else now.astimezone(IST)
    if not calendar_verified(now.date(), segment):
        return {"open": False, "reason": "calendar_not_verified"}
    active = in_session(now, segment, session=session)
    return {"open": active, "reason": None if active else "market_closed"}
