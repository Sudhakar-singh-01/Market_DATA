"""
model/config/env_loader.py
Loads secrets/environment configuration from config/.env. This is the
ONLY module that reads FYERS credentials or DB connection details from
the environment -- nothing else should call os.getenv() for these
directly (spec Sections 2, 9).
"""

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

from model.exceptions import ConfigurationError

_ENV_PATH = Path(__file__).resolve().parents[2] / "config" / ".env"


@dataclass(frozen=True)
class FyersCredentials:
    client_id: str
    secret_key: str
    redirect_uri: str
    access_token: str  # may be empty until the one-time login flow is run


@dataclass(frozen=True)
class DatabaseConfig:
    host: str
    port: int
    name: str
    user: str
    password: str  # never logged or included in __repr__ output below


@dataclass(frozen=True)
class EnvConfig:
    fyers: FyersCredentials
    db: DatabaseConfig

    def __repr__(self) -> str:
        # Deliberately overridden so an accidental print(env_config) or
        # inclusion in a log message never leaks secrets.
        return "EnvConfig(fyers=FyersCredentials(***redacted***), db=DatabaseConfig(***redacted***))"


def _require(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise ConfigurationError(
            f"Required environment variable '{name}' is not set. Check config/.env "
            f"(see config/.env.example for the expected keys)."
        )
    return value


def load_env_config(reload=False) -> EnvConfig:
    """
    Loads config/.env and returns a validated EnvConfig.
    FYERS_ACCESS_TOKEN is the one exception allowed to be empty at load
    time -- it may not exist yet before the first interactive login
    (see model/fyers/auth.py). Everything else is required.
    """
    from model.config.runtime_paths import config_path
    selected_env = config_path(_ENV_PATH)
    if not selected_env.exists():
        raise ConfigurationError(
            f"Environment file not found: {selected_env}. Copy config/.env.example to config/.env and fill it in."
        )

    load_dotenv(dotenv_path=selected_env,override=reload)

    fyers = FyersCredentials(
        client_id=_require("FYERS_CLIENT_ID"),
        secret_key=_require("FYERS_SECRET_KEY"),
        redirect_uri=_require("FYERS_REDIRECT_URI"),
        access_token=os.getenv("FYERS_ACCESS_TOKEN", ""),
    )

    db = DatabaseConfig(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        name=os.getenv("DB_NAME", ""),
        user=os.getenv("DB_USER", ""),
        password=os.getenv("DB_PASSWORD", ""),
    )

    return EnvConfig(fyers=fyers, db=db)
