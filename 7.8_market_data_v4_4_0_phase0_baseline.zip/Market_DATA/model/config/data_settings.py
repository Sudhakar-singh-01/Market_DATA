"""
model/config/data_settings.py
Loads and validates config/data_settings.yaml into a typed structure.
Part 2 reads these values; nothing in Part 1 or Part 2 should hard-code
these toggles/policies in Python.
"""

from dataclasses import dataclass
from pathlib import Path

from model.config.yaml_loader import load_yaml
from model.exceptions import ConfigurationError

_SETTINGS_PATH = Path(__file__).resolve().parents[2] / "config" / "data_settings.yaml"

_REQUIRED_TOP_LEVEL_KEYS = [
    "historical", "live", "validation", "storage", "logging",
    "retry", "reconnect", "duplicate_handling", "missing_data",
]


@dataclass(frozen=True)
class RetrySettings:
    max_retries: int
    initial_backoff_seconds: float
    backoff_multiplier: float


@dataclass(frozen=True)
class ReconnectSettings:
    enabled: bool
    max_attempts: int
    initial_backoff_seconds: float
    backoff_multiplier: float


@dataclass(frozen=True)
class StorageSettings:
    mysql_enabled: bool
    parquet_enabled: bool
    csv_enabled: bool
    csv_output_dir: str


@dataclass(frozen=True)
class DataSettings:
    historical_enabled: bool
    live_enabled: bool
    validation_enabled: bool
    storage: StorageSettings
    log_level: str
    log_dir: str
    log_file: str
    retry: RetrySettings
    reconnect: ReconnectSettings
    duplicate_strategy: str
    missing_data_strategy: str


def load_data_settings() -> DataSettings:
    raw = load_yaml(_SETTINGS_PATH)

    missing = [k for k in _REQUIRED_TOP_LEVEL_KEYS if k not in raw]
    if missing:
        raise ConfigurationError(f"data_settings.yaml is missing required key(s): {missing}")

    try:
        storage_raw = raw["storage"]
        storage = StorageSettings(
            mysql_enabled=bool(storage_raw["mysql"]["enabled"]),
            parquet_enabled=bool(storage_raw["parquet"]["enabled"]),
            csv_enabled=bool(storage_raw["csv"]["enabled"]),
            csv_output_dir=str(storage_raw["csv"]["output_dir"]),
        )

        retry_raw = raw["retry"]
        retry = RetrySettings(
            max_retries=int(retry_raw["max_retries"]),
            initial_backoff_seconds=float(retry_raw["initial_backoff_seconds"]),
            backoff_multiplier=float(retry_raw["backoff_multiplier"]),
        )

        reconnect_raw = raw["reconnect"]
        reconnect = ReconnectSettings(
            enabled=bool(reconnect_raw["enabled"]),
            max_attempts=int(reconnect_raw["max_attempts"]),
            initial_backoff_seconds=float(reconnect_raw["initial_backoff_seconds"]),
            backoff_multiplier=float(reconnect_raw["backoff_multiplier"]),
        )

        duplicate_strategy = raw["duplicate_handling"]["strategy"]
        missing_data_strategy = raw["missing_data"]["strategy"]

        settings = DataSettings(
            historical_enabled=bool(raw["historical"]["enabled"]),
            live_enabled=bool(raw["live"]["enabled"]),
            validation_enabled=bool(raw["validation"]["enabled"]),
            storage=storage,
            log_level=str(raw["logging"]["level"]),
            log_dir=str(raw["logging"]["log_dir"]),
            log_file=str(raw["logging"]["log_file"]),
            retry=retry,
            reconnect=reconnect,
            duplicate_strategy=str(duplicate_strategy),
            missing_data_strategy=str(missing_data_strategy),
        )
    except KeyError as exc:
        raise ConfigurationError(f"data_settings.yaml is missing required nested key: {exc}") from exc

    if settings.duplicate_strategy not in ("skip", "overwrite"):
        raise ConfigurationError(
            f"data_settings.yaml duplicate_handling.strategy must be 'skip' or 'overwrite', got '{settings.duplicate_strategy}'"
        )

    if settings.missing_data_strategy not in ("report_only", "fail"):
        raise ConfigurationError(
            f"data_settings.yaml missing_data.strategy must be 'report_only' or 'fail', got '{settings.missing_data_strategy}'"
        )

    valid_log_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
    if settings.log_level.upper() not in valid_log_levels:
        raise ConfigurationError(f"data_settings.yaml logging.level must be one of {valid_log_levels}, got '{settings.log_level}'")

    return settings
