"""Reviewed NSE Cash 2024/25 calendar additions; explicit, backed-up profile update."""
import copy
import datetime as dt
import hashlib
import os
import uuid
from pathlib import Path
import yaml
from model.cash_restore import guard, require
from model.storage.locking import file_lock
from model.config.market_calendar import parse_holidays, _to_date

BASE = 'https://nsearchives.nseindia.com/content/circulars/'
SOURCES = [BASE+s+'.pdf' for s in ('CMTR59722','CMTR60338','CMTR61518','CMTR64960',
    'MSD60340','MSD60677','MSD61893','CMTR64628','CMTR65587','CMTR65729','CMTR70319')]
HOLIDAYS = {
    2024: '01-22 01-26 03-08 03-25 03-29 04-11 04-17 05-01 05-20 06-17 07-17 08-15 10-02 11-01 11-15 11-20 12-25',
    2025: '02-26 03-14 03-31 04-10 04-14 04-18 05-01 08-15 08-27 10-02 10-21 10-22 11-05 12-25',
}

def special(name, op, cl, circular):
    return dict(name=name, verified=True, segments=['CASH'], open=op, close=cl, source=BASE+circular+'.pdf')

SPECIALS = {
    '2024-01-20': special('Regular Saturday session','09:15','15:30','MSD60340'),
    '2024-03-02': dict(name='DR split session', verified=True, segments=['CASH'],
        intervals=[dict(open='09:15',close='10:00'),dict(open='11:30',close='12:30')], source=BASE+'MSD60677.pdf'),
    '2024-05-18': dict(name='DR split session', verified=True, segments=['CASH'],
        intervals=[dict(open='09:15',close='10:00'),dict(open='11:30',close='12:30')], source=BASE+'MSD61893.pdf'),
    '2024-11-01': special('Muhurat','18:00','19:00','CMTR64628'),
    '2025-02-01': special('Union Budget Saturday session','09:15','15:30','CMTR65729'),
    '2025-10-21': special('Muhurat','13:45','14:45','CMTR70319'),
}
PATCH_ID = 'NSE-CASH-2024-2025-REVIEW-2026-10-29'


def merged_calendar(data):
    require(isinstance(data,dict), 'calendar_mapping_required')
    parse_holidays(data)
    result = copy.deepcopy(data)
    specials = result.setdefault('special_sessions', {})
    require(isinstance(specials,dict), 'special_sessions_mapping_required')
    for day, item in SPECIALS.items():
        # Never silently override an existing custom/session/segment decision.
        existing = specials.get(day, specials.get(dt.date.fromisoformat(day)))
        require(existing is None or existing == item, 'existing_special_session_conflict:'+day)
        specials[day] = copy.deepcopy(item)
    extras = result.setdefault('segment_holidays',{})
    existing = extras.get('CASH',[])
    days = set(parse_holidays({'holidays':existing}))
    days.update(dt.date.fromisoformat(f'{year}-{day}') for year,values in HOLIDAYS.items() for day in values.split())
    # Retain named existing entries; append only new dates.
    extras['CASH'] = existing + [d.isoformat() for d in sorted(days-set(parse_holidays({'holidays':existing})))]
    known = result.setdefault('verified_years', {})
    known['CASH'] = sorted(set(known.get('CASH',[])) | {2024,2025})
    earliest = result.get('verified_from',{}).get('CASH')
    require(not earliest or _to_date(earliest,'verified_from') <= dt.date(2024,1,1), 'cash_verified_from_conflict')
    result.setdefault('calendar_reviews',{})[PATCH_ID] = dict(segment='CASH', sources=SOURCES)
    version = str(result.get('version', 'UNVERSIONED'))
    if PATCH_ID not in version:
        result['version'] = version + '+' + PATCH_ID
    return result


def update_calendar(path, *, apply=False, writers_stopped=False):
    path = guard(path)
    require(path.is_file(), 'existing_calendar_required')
    if apply: require(writers_stopped, 'writers_stopped_required')
    # Only this updater shares this lock; digest check also detects manual edits before publication.
    with file_lock(guard(path.with_suffix('.yaml.update.lock'))):
        before = path.read_bytes(); data = yaml.safe_load(before.decode('utf-8-sig'))
        merged = merged_calendar(data)
        result = dict(status='CALENDAR_PREVIEW_READY', config=str(path), config_modified=False,
                      market_data_modified=False, sql_modified=False, patch=PATCH_ID,
                      cash_years=merged['verified_years']['CASH'], special_dates=list(SPECIALS),
                      fno_unchanged=True)
        if merged == data:
            result['status']='CALENDAR_ALREADY_CURRENT'; return result
        if not apply: return result
        payload = yaml.safe_dump(merged,sort_keys=False,allow_unicode=True).encode('utf-8')
        require(yaml.safe_load(payload)==merged,'calendar_roundtrip_failed')
        backup = guard(path.with_name(path.name+'.before-'+uuid.uuid4().hex+'.bak'))
        with backup.open('xb') as stream:
            stream.write(before); stream.flush(); os.fsync(stream.fileno())
        require(backup.read_bytes()==before,'calendar_backup_failed')
        stage = guard(path.with_name(path.name+'.stage-'+uuid.uuid4().hex))
        try:
            with stage.open('xb') as stream:
                stream.write(payload); stream.flush(); os.fsync(stream.fileno())
            require(path.read_bytes()==before,'calendar_changed_during_update')
            os.replace(stage,path)
        finally:
            stage.unlink(missing_ok=True)
        require(path.read_bytes()==payload,'calendar_readback_failed')
        result.update(status='CALENDAR_UPDATED',config_modified=True,backup=str(backup),
                      sha256=hashlib.sha256(payload).hexdigest())
        return result
