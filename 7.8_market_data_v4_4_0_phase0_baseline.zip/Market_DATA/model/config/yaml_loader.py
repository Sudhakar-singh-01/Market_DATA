"""
model/config/yaml_loader.py
Single, reusable place all YAML parsing goes through. No other module
should call yaml.safe_load() directly -- this keeps parsing/error
handling consistent instead of scattered across the codebase (spec
Section 9).
"""

from pathlib import Path

import yaml

from model.exceptions import ConfigurationError


def load_yaml(path: Path | str) -> dict:
    """
    Loads and parses a YAML file, raising a clear ConfigurationError
    (not a raw exception) if the file is missing or malformed.
    """
    from model.config.runtime_paths import config_path
    path = config_path(path)

    if not path.exists():
        raise ConfigurationError(f"Required configuration file not found: {path}")

    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"Invalid YAML syntax in {path}: {exc}") from exc

    if data is None:
        raise ConfigurationError(f"Configuration file is empty: {path}")

    if not isinstance(data, dict):
        raise ConfigurationError(f"Configuration file must contain a YAML mapping at the top level: {path}")

    return data
