"""
model/config/instrument_loader.py
Loads instruments/stocks.yaml and instruments/indices.yaml into a
single, queryable InstrumentRegistry. Stocks and indices are kept as
logically separate collections internally (spec Section 4: "Do NOT
merge stocks and indices into the same YAML file" -- extended here to
mean they stay distinguishable in code too), but exposed through one
registry object so Part 2 doesn't need to know which YAML file an
instrument came from.
"""

from dataclasses import dataclass
from pathlib import Path

from model.config.yaml_loader import load_yaml
from model.exceptions import InstrumentValidationError

_STOCKS_PATH = Path(__file__).resolve().parents[2] / "instruments" / "stocks.yaml"
_INDICES_PATH = Path(__file__).resolve().parents[2] / "instruments" / "indices.yaml"

_REQUIRED_FIELDS = ["internal_name", "fyers_symbol", "exchange", "instrument_type", "active"]


@dataclass(frozen=True)
class Instrument:
    internal_name: str
    fyers_symbol: str
    exchange: str
    instrument_type: str
    active: bool
    category: str  # 'stock' or 'index' -- which YAML file this came from


def _parse_entries(raw: dict, list_key: str, category: str, source_path: Path) -> list:
    entries = raw.get(list_key)
    if not entries or not isinstance(entries, list):
        raise InstrumentValidationError(f"{source_path} must contain a non-empty '{list_key}' list")

    instruments = []
    for entry in entries:
        missing = [f for f in _REQUIRED_FIELDS if f not in entry]
        if missing:
            raise InstrumentValidationError(f"{source_path}: entry missing required field(s) {missing}: {entry}")

        internal_name = str(entry["internal_name"]).strip()
        fyers_symbol = str(entry["fyers_symbol"]).strip()

        if not internal_name:
            raise InstrumentValidationError(f"{source_path}: internal_name cannot be empty: {entry}")
        if not fyers_symbol:
            raise InstrumentValidationError(f"{source_path}: fyers_symbol cannot be empty for '{internal_name}'")

        instruments.append(Instrument(
            internal_name=internal_name,
            fyers_symbol=fyers_symbol,
            exchange=str(entry["exchange"]).strip(),
            instrument_type=str(entry["instrument_type"]).strip(),
            active=bool(entry["active"]),
            category=category,
        ))

    return instruments


class InstrumentRegistry:
    """Queryable collection of all configured stocks + indices."""

    def __init__(self, instruments: list):
        self._by_name: dict = {}
        for instrument in instruments:
            if instrument.internal_name in self._by_name:
                raise InstrumentValidationError(
                    f"Duplicate internal_name '{instrument.internal_name}' found across stocks/indices "
                    f"(internal names must be unique across the entire instrument universe)"
                )
            self._by_name[instrument.internal_name] = instrument
        self._all = list(instruments)

    # ---- stocks ----
    def all_stocks(self) -> list:
        return [i for i in self._all if i.category == "stock"]

    def active_stocks(self) -> list:
        return [i for i in self.all_stocks() if i.active]

    # ---- indices ----
    def all_indices(self) -> list:
        return [i for i in self._all if i.category == "index"]

    def active_indices(self) -> list:
        return [i for i in self.all_indices() if i.active]

    # ---- combined ----
    def all_instruments(self) -> list:
        return list(self._all)

    def active_instruments(self) -> list:
        return [i for i in self._all if i.active]

    def get(self, internal_name: str) -> Instrument:
        if internal_name not in self._by_name:
            raise KeyError(f"No instrument registered with internal_name '{internal_name}'")
        return self._by_name[internal_name]

    def get_fyers_symbol(self, internal_name: str) -> str:
        return self.get(internal_name).fyers_symbol


def load_instrument_registry() -> InstrumentRegistry:
    stocks_raw = load_yaml(_STOCKS_PATH)
    indices_raw = load_yaml(_INDICES_PATH)

    stocks = _parse_entries(stocks_raw, "stocks", "stock", _STOCKS_PATH)
    indices = _parse_entries(indices_raw, "indices", "index", _INDICES_PATH)

    return InstrumentRegistry(stocks + indices)
