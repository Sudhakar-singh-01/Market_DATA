"""Strict, session-anchored FNO adapter for the shared OHLCV combiner.

Every output requires all CLOSED one-minute bars in its session-clipped bucket.
No interpolation or assumption about silent option ticks is made. Daily bars
start at session open, including the shortened final intraday bucket.
"""
import datetime as dt
from dataclasses import dataclass, field

from model.fno.config import DEFAULT_SESSION
from model.fno.models import FnoCandle, IST, SOURCE_AGGREGATED
from model.processing.models import Candle
from model.processing.timeframe_aggregator import _combine

MINUTES = {"5m": 5, "15m": 15, "30m": 30, "1h": 60, "1d": 1440}


def session_bounds(day, session=DEFAULT_SESSION):
    return (dt.datetime.combine(day, session.open, tzinfo=IST),
            dt.datetime.combine(day, session.last_minute, tzinfo=IST) + dt.timedelta(minutes=1))


def buckets(day, timeframe, session=DEFAULT_SESSION):
    if timeframe not in MINUTES:
        raise ValueError(f"Unsupported FNO target timeframe: {timeframe}")
    start, close = session_bounds(day, session)
    while start < close:
        end = min(close, start + dt.timedelta(minutes=MINUTES[timeframe]))
        yield start, end
        start = end


def invalid_candle(c):
    prices = [c.open, c.high, c.low, c.close]
    return (any(not p.is_finite() or p <= 0 for p in prices)
            or c.low > min(c.open, c.close) or c.high < max(c.open, c.close)
            or c.low > c.high or c.volume < 0 or (c.oi is not None and c.oi < 0))


@dataclass
class AggregationResult:
    candles: list = field(default_factory=list)
    input_rows: int = 0
    invalid_rows: int = 0
    missing_buckets: int = 0
    incomplete_buckets: int = 0
    forming_buckets: int = 0

    @property
    def skipped(self):
        return self.missing_buckets + self.incomplete_buckets + self.forming_buckets


def aggregate_day(rows, day, timeframe, session=DEFAULT_SESSION, now=None):
    now = now or dt.datetime.now(IST)
    if now.tzinfo is None:
        raise ValueError("now must be timezone aware")
    result = AggregationResult(input_rows=len(rows))
    lo, hi = session_bounds(day, session)
    stamps, bad_stamps = {}, set()
    ids = {c.contract_id for c in rows}
    if len(ids) > 1:
        raise ValueError("aggregate_day accepts one contract at a time")
    for c in rows:
        if c.timestamp.tzinfo is None:
            raise ValueError("FNO timestamps must be timezone aware")
        ts = c.timestamp.astimezone(IST)
        if (c.timeframe != "1m" or not lo <= ts < hi or ts.second or ts.microsecond
                or invalid_candle(c)):
            result.invalid_rows += 1
            bad_stamps.add(ts)
            continue
        if ts in stamps:
            result.invalid_rows += 1
            bad_stamps.add(ts)
        stamps[ts] = c
    for start, end in buckets(day, timeframe, session):
        if end > now:
            result.forming_buckets += 1
            continue
        expected = [start + dt.timedelta(minutes=i) for i in range(int((end-start).total_seconds()/60))]
        group = [stamps[t] for t in expected if t in stamps]
        if not group:
            result.missing_buckets += 1
            continue
        if len(group) != len(expected) or any(t in bad_stamps for t in expected) or any(c.status != "CLOSED" for c in group):
            result.incomplete_buckets += 1
            continue
        # Decimal values pass through the shared combiner without float conversion.
        base = [Candle(str(c.contract_id), str(c.contract_id), "FNO", "NSE", c.timestamp,
                       "1m", c.open, c.high, c.low, c.close, c.volume, c.source, c.status) for c in group]
        combined = _combine(base, start, timeframe, "CLOSED")
        oi = next((c.oi for c in reversed(group) if c.oi is not None), None)
        result.candles.append(FnoCandle(group[0].contract_id, timeframe, start, combined.open,
                             combined.high, combined.low, combined.close, combined.volume,
                             source=SOURCE_AGGREGATED, oi=oi))
    return result
