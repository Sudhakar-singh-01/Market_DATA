"""
model/fno/db.py
The ONE factory for FNO MySQL engines.

Isolation rule: the FNO database must never be Subsystem A's database. The
factory refuses (IsolationError) when the names are equal, when A's name is
unknown, and -- after connecting -- when the server reports a different
database than the one configured. FnoRepository only accepts engines created
here (is_fno_engine), so no code path can hand it an A engine by accident.
"""

import logging
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from model.fno.config import FnoDatabaseConfig
from model.fno.errors import IsolationError

log = logging.getLogger("market_data.fno.db")

_ENGINES: dict = {}
_GUARDED_IDS: set = set()


def build_fno_url(cfg: FnoDatabaseConfig) -> str:
    host = "127.0.0.1" if cfg.host.strip().lower() == "localhost" else cfg.host
    from sqlalchemy.engine import URL
    return URL.create("mysql+pymysql", username=cfg.user, password=cfg.password,
                      host=host, port=cfg.port, database=cfg.name).render_as_string(hide_password=False)


def check_isolation(fno_db_name: str, subsystem_a_db_name: str) -> None:
    fno, a = (fno_db_name or "").strip(), (subsystem_a_db_name or "").strip()
    if not fno:
        raise IsolationError("FNO database name is empty (FNO_DB_NAME).")
    if not a:
        raise IsolationError(
            "Subsystem A database name is unknown (DB_NAME is empty), so FNO isolation cannot be proven. "
            "Refusing to create an FNO engine.")
    if fno.lower() == a.lower():
        raise IsolationError(
            f"FNO database '{fno}' is the same as Subsystem A's database. "
            f"FNO must use its own database (default 'fno_market_data').")


def get_fno_engine(cfg: FnoDatabaseConfig, subsystem_a_db_name: str) -> Engine:
    """Returns a cached engine for the FNO database after proving isolation."""
    check_isolation(cfg.name, subsystem_a_db_name)
    cfg.require_credentials()
    url = build_fno_url(cfg)
    engine = _ENGINES.get(url)
    if engine is None:
        engine = create_engine(url, pool_pre_ping=True, pool_recycle=1800, connect_args={"connect_timeout": 5})
        with engine.connect() as conn:  # defence in depth: ask the server which DB we really got
            actual = conn.execute(text("SELECT DATABASE()")).scalar()
        if (actual or "").lower() == subsystem_a_db_name.strip().lower():
            engine.dispose()
            raise IsolationError(f"Connected database '{actual}' is Subsystem A's database.")
        _ENGINES[url] = engine
        _GUARDED_IDS.add(id(engine))
        log.info("FNO engine ready for database '%s'", cfg.name)
    return engine


def is_fno_engine(engine) -> bool:
    return id(engine) in _GUARDED_IDS


def reset_engine_cache() -> None:
    """Test helper: dispose and forget every FNO engine."""
    for e in _ENGINES.values():
        e.dispose()
    _ENGINES.clear()
    _GUARDED_IDS.clear()
