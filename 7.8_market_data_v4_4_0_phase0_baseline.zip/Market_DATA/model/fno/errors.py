"""model/fno/errors.py -- exception types for the FNO subsystem."""


class FnoError(Exception):
    """Base class for FNO errors."""


class IsolationError(FnoError):
    """An operation would cross the FNO / Subsystem A boundary. Never retried."""


class TokenExpiredError(FnoError):
    """FYERS rejected the access token. Jobs must fail clearly, not retry."""


class DuplicateJobError(FnoError):
    """An identical job (same type + params) is already PENDING or RUNNING."""

    def __init__(self, job_id: int):
        self.job_id = job_id
        super().__init__(f"An identical FNO job is already active (id={job_id}).")


class StorageVerificationError(FnoError):
    """A store accepted a write but read-back verification failed."""
