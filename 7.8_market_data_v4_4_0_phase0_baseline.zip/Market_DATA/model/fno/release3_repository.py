"""Bounded FNO analytics queries and explicit derived-data replacement.

Canonical 1m write policy remains in FnoRepository. Rebuilding derived candles
is a separate operation because a later historical correction must invalidate
old aggregates, including buckets that are no longer complete.
"""
import datetime as dt
import hashlib
import json
from contextlib import contextmanager

from sqlalchemy import text

from model.fno.repository import FnoRepository, _row_values, _UPSERT_SQL
from model.fno.aggregation import MINUTES
from model.fno.models import FnoContract, IST


def date_range(params):
    a, b = (dt.date.fromisoformat(str(params[k])) for k in ("from", "to"))
    if a > b or (b-a).days > 3660:
        raise ValueError("Choose an ordered date range of at most 3661 days")
    return a, b


def day_bounds(day):
    return dt.datetime.combine(day, dt.time()), dt.datetime.combine(day+dt.timedelta(days=1), dt.time())


class Release3Repository(FnoRepository):
    def query(self, sql, params=None):
        with self.engine.connect() as conn:
            return [dict(r) for r in conn.execute(text(sql), params or {}).mappings()]

    def iter_contracts(self, underlyings=None, contract_ids=None, data_range=None, include_claims=False):
        after = 0
        while True:
            where, p = ["id > :after"], {"after": after}
            for col, vals, key in (("underlying", underlyings, "u"), ("id", contract_ids, "c")):
                if vals is not None:
                    if not vals:
                        return
                    where.append(col+" IN ("+",".join(f":{key}{i}" for i in range(len(vals)))+")")
                    p.update({f"{key}{i}": v for i, v in enumerate(vals)})
            if data_range is not None and contract_ids is None:
                a,b=data_range
                p.update(start=day_bounds(a)[0],end=day_bounds(b)[1],day_a=a,day_b=b)
                has_data="EXISTS (SELECT 1 FROM fno_candles c WHERE c.contract_id=fno_instruments.id AND c.candle_timestamp>=:start AND c.candle_timestamp<:end)"
                if include_claims:
                    has_data+=" OR EXISTS (SELECT 1 FROM fno_checkpoint_ranges k WHERE k.contract_id=fno_instruments.id AND k.range_from<=:day_b AND k.range_to>=:day_a)"
                where.append("("+has_data+")")
            rows = self.query("SELECT * FROM fno_instruments WHERE "+" AND ".join(where)+" ORDER BY id LIMIT 200", p)
            if not rows:
                return
            for r in rows:
                yield FnoContract(**{k: r[k] for k in ("fyers_symbol", "underlying", "exchange", "category", "expiry",
                    "strike", "option_type", "lot_size", "tick_size", "fytoken", "source", "status")}, contract_id=r["id"])
            after = rows[-1]["id"]

    @contextmanager
    def partition_lock(self, key):
        name = "fno:"+hashlib.sha256((self.engine.url.database+":"+key).encode()).hexdigest()[:55]
        with self.engine.connect() as conn:
            if conn.execute(text("SELECT GET_LOCK(:key, 5)"), {"key": name}).scalar() != 1:
                raise RuntimeError("Another FNO operation holds this partition; retry the job")
            try:
                yield
            finally:
                conn.execute(text("SELECT RELEASE_LOCK(:key)"), {"key": name})

    def replace_derived_day(self, cid, tf, day, candles):
        if tf not in MINUTES or any(c.contract_id != cid or c.timeframe != tf or c.source != "AGGREGATED"
                                   or c.naive_ist().date() != day for c in candles):
            raise ValueError("Only this contract/day's derived candles can be replaced")
        a, b = day_bounds(day)
        with self.engine.begin() as conn:
            conn.execute(text("DELETE FROM fno_candles WHERE contract_id=:c AND timeframe=:tf AND candle_timestamp>=:a AND candle_timestamp<:b"),
                         {"c": cid, "tf": tf, "a": a, "b": b})
            if candles:
                conn.execute(_UPSERT_SQL, [_row_values(c) for c in candles])

    def invalidate_aggregation_day(self, cid, tf, day):
        # Splits only this job type's ranges; historical checkpoints are untouched.
        with self.engine.begin() as conn:
            rows = conn.execute(text("SELECT * FROM fno_checkpoint_ranges WHERE contract_id=:c AND job_type='AGGREGATION' "
                "AND timeframe=:tf AND range_from<=:d AND range_to>=:d FOR UPDATE"), {"c":cid,"tf":tf,"d":day}).mappings().all()
            for r in rows:
                conn.execute(text("DELETE FROM fno_checkpoint_ranges WHERE id=:id"), {"id":r["id"]})
                for a,b in ((r["range_from"],day-dt.timedelta(days=1)),(day+dt.timedelta(days=1),r["range_to"])):
                    if a<=b:
                        conn.execute(text("INSERT INTO fno_checkpoint_ranges (contract_id,job_type,timeframe,range_from,range_to,status,verified_at) "
                            "VALUES (:c,'AGGREGATION',:tf,:a,:b,:s,:v)"),
                            {"c":cid,"tf":tf,"a":a,"b":b,"s":r["status"],"v":r["verified_at"]})

    def start_aggregation(self, job_id, tf, params):
        a,b = date_range(params)
        now = dt.datetime.now(IST).replace(tzinfo=None)
        with self.engine.begin() as conn:
            return conn.execute(text("INSERT INTO fno_aggregation_jobs (source_timeframe,target_timeframe,contract_selection,"
                "source_from,source_to,state,started_at,heartbeat_at) VALUES ('1m',:tf,:p,:a,:b,'RUNNING',:n,:n)"),
                {"tf":tf,"p":json.dumps({"job_id":job_id, **params},default=str),"a":a,"b":b,"n":now}).lastrowid

    def aggregation_progress(self, record_id, result, state="RUNNING", error=None):
        now = dt.datetime.now(IST).replace(tzinfo=None)
        with self.engine.begin() as conn:
            conn.execute(text("UPDATE fno_aggregation_jobs SET input_rows=:i,output_rows=:o,skipped_intervals=:s,state=:state,"
                "verification_result=:r,heartbeat_at=:n,finished_at=:f,error=:e,output_from=:a,output_to=:b WHERE id=:id"),
                {"id":record_id,"i":result["input_rows"],"o":result["output_rows"],"s":result["skipped_buckets"],
                 "state":state,"r":json.dumps(result,default=str),"n":now,"f":None if state=="RUNNING" else now,"e":error,
                 "a":result.get("output_from"),"b":result.get("output_to")})

    def partition_candles(self, underlying, expiry, tf, day):
        # One underlying/expiry/day, streamed contract by contract by the caller's bounded job.
        a,b = day_bounds(day)
        ids = self.query("SELECT DISTINCT c.contract_id FROM fno_candles c JOIN fno_instruments i ON i.id=c.contract_id "
            "WHERE i.underlying=:u AND i.expiry=:e AND c.timeframe=:tf AND c.candle_timestamp>=:a AND c.candle_timestamp<:b",
            {"u":underlying,"e":expiry,"tf":tf,"a":a,"b":b})
        return [c for r in ids for c in self.fetch_candles(r["contract_id"],tf,day,day)]
