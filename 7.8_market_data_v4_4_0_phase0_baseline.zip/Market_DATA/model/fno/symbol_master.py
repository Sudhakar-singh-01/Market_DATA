"""
model/fno/symbol_master.py
Parses the FYERS NSE F&O symbol master into FnoContract objects.

Underlying, expiry, strike and option type come from master FIELDS, never from
parsing the symbol name (monthly and weekly symbols use different layouts).
Classification: option_type CE/PE -> OPTIONS (strike required); option_type
XX/empty with strike <= 0 or missing -> FUTURES; anything else is skipped and
counted (reported, never guessed).

The file URL, format and CSV column positions are CONFIG values and are
UNVERIFIED until `fno-probe` confirms them (docs/FNO_API_FINDINGS.md).
Network access is isolated in download_symbol_master() so parsing is testable.
"""
import csv
import datetime
import io
import json
import logging
import os
import time
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Optional

from model.fno.models import FnoContract, IST, CATEGORY_FUTURES, CATEGORY_OPTIONS

log = logging.getLogger("market_data.fno.symbol_master")

JSON_KEYS = {  # field-name variants for the JSON master (first present wins)
    "symbol": ("symTicker", "symbol", "fyers_symbol"), "fytoken": ("fyToken", "fytoken"),
    "underlying": ("underSym", "underlying", "underlyingSymbol"), "exchange": ("exchange", "exName"),
    "expiry": ("expiryDate", "expiry"), "strike": ("strikePrice", "strike"), "option_type": ("optType", "option_type"),
    "lot_size": ("minLotSize", "lotSize", "lot_size"), "tick_size": ("tickSize", "tick_size"),
}


@dataclass
class ParseReport:
    contracts: list = field(default_factory=list)
    skipped: dict = field(default_factory=dict)       # reason -> count
    total_rows: int = 0

    def skip(self, reason: str):
        self.skipped[reason] = self.skipped.get(reason, 0) + 1


def parse_expiry(value) -> Optional[datetime.date]:
    """Epoch seconds (FYERS style), 'YYYY-MM-DD' or 'DD-MM-YYYY' -> IST calendar date."""
    if value in (None, ""):
        return None
    s = str(value).strip()
    try:
        if s.replace(".", "", 1).isdigit():
            return datetime.datetime.fromtimestamp(float(s), tz=datetime.timezone.utc).astimezone(IST).date()
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d-%b-%Y"):
            try:
                return datetime.datetime.strptime(s, fmt).date()
            except ValueError:
                pass
    except (OverflowError, OSError, ValueError):
        return None
    return None


def _dec(v) -> Optional[Decimal]:
    try:
        return None if v in (None, "") else Decimal(str(v).strip())
    except InvalidOperation:
        return None


def _int(v) -> Optional[int]:
    try:
        return None if v in (None, "") else int(float(v))
    except ValueError:
        return None


def build_contract(raw: dict, report: ParseReport, source: str) -> None:
    """raw keys: symbol, fytoken, underlying, exchange, expiry, strike, option_type, lot_size, tick_size."""
    report.total_rows += 1
    symbol = (raw.get("symbol") or "").strip()
    underlying = (raw.get("underlying") or "").strip().upper()
    if not symbol:
        return report.skip("missing_symbol")
    if not underlying:
        return report.skip("missing_underlying")
    expiry = parse_expiry(raw.get("expiry"))
    if expiry is None:
        return report.skip("bad_expiry")
    opt = (raw.get("option_type") or "").strip().upper()
    strike = _dec(raw.get("strike"))
    if opt in ("CE", "PE"):
        if strike is None or strike <= 0:
            return report.skip("option_without_strike")
        category = CATEGORY_OPTIONS
    elif opt in ("XX", ""):
        if strike is not None and strike > 0:
            return report.skip("unclassifiable")
        category, strike, opt = CATEGORY_FUTURES, None, None
    else:
        return report.skip("unknown_option_type")
    prefix = symbol.partition(":")[0].upper() if ":" in symbol else ""
    raw_ex = (raw.get("exchange") or "").strip()
    # probe: the master's exchange column holds a numeric CODE ("10"), so take the name from the symbol prefix
    exchange = prefix if prefix.isalpha() else (raw_ex.upper() if raw_ex.isalpha() else "NSE")
    report.contracts.append(FnoContract(
        fyers_symbol=symbol, underlying=underlying, exchange=exchange,
        category=category, expiry=expiry, strike=strike, option_type=opt, lot_size=_int(raw.get("lot_size")),
        tick_size=_dec(raw.get("tick_size")), fytoken=(str(raw["fytoken"]).strip() if raw.get("fytoken") else None),
        source=source))


def parse_json_master(data: dict, source: str = "FYERS_SYMBOL_MASTER_JSON") -> ParseReport:
    report = ParseReport()
    items = data.items() if isinstance(data, dict) else enumerate(data)
    for key, entry in items:
        if not isinstance(entry, dict):
            report.total_rows += 1; report.skip("malformed_row"); continue
        raw = {}
        for field_name, variants in JSON_KEYS.items():
            raw[field_name] = next((entry[v] for v in variants if v in entry and entry[v] not in (None, "")), None)
        if not raw["symbol"] and isinstance(key, str) and ":" in key:
            raw["symbol"] = key
        build_contract(raw, report, source)
    return report


def parse_csv_master(text: str, columns: dict, source: str = "FYERS_SYMBOL_MASTER_CSV") -> ParseReport:
    report = ParseReport()
    need = max(columns.values()) + 1
    for row in csv.reader(io.StringIO(text)):
        if not row:
            continue
        if len(row) < need:
            report.total_rows += 1; report.skip("short_row"); continue
        get = lambda k: row[columns[k]].strip() if k in columns else None
        build_contract({k: get(k) for k in ("symbol", "fytoken", "underlying", "exchange", "expiry", "strike",
                                            "option_type", "lot_size", "tick_size")}, report, source)
    return report


def parse_master(content: str, fmt: str, columns: dict) -> ParseReport:
    if fmt == "json":
        return parse_json_master(json.loads(content))
    return parse_csv_master(content, columns)


def filter_underlyings(contracts: list, underlyings) -> list:
    wanted = {u.upper() for u in underlyings}
    return [c for c in contracts if c.underlying in wanted]


def download_symbol_master(url: str, cache_path: Path, max_age_hours: float, timeout: float,
                           force: bool = False, http_get=None) -> str:
    """Returns the master text, using the cache file when younger than max_age_hours."""
    cache_path = Path(cache_path)
    if not force and cache_path.exists() and (time.time() - cache_path.stat().st_mtime) / 3600 < max_age_hours:
        return cache_path.read_text(encoding="utf-8")
    if http_get is None:
        import requests
        http_get = lambda u, t: requests.get(u, timeout=t)
    resp = http_get(url, timeout)
    if getattr(resp, "status_code", 200) != 200:
        raise RuntimeError(f"Symbol master download failed: HTTP {resp.status_code}")
    text = resp.text
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache_path.with_suffix(".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, cache_path)
    return text


def sync_contracts(repo, report: ParseReport, universe_underlyings, today: datetime.date,
                   now: Optional[datetime.datetime] = None) -> dict:
    """Upserts the configured universe (ALL its expiries/strikes: the master is the contract
    catalogue; the harvest planner narrows it) and expires contracts that vanished from the master."""
    now = now or datetime.datetime.now(tz=IST).replace(tzinfo=None, microsecond=0)
    started = now
    contracts = filter_underlyings(report.contracts, universe_underlyings)
    live = [c for c in contracts if c.expiry >= today]          # already-expired rows are not (re)activated
    out = repo.upsert_contracts(live, seen_at=started)
    expired = repo.mark_expired(today, started)
    return {"parsed": report.total_rows, "in_universe": len(contracts), "inserted": out["inserted"],
            "updated": out["updated"], "expired_marked": expired, "skipped": dict(report.skipped)}
