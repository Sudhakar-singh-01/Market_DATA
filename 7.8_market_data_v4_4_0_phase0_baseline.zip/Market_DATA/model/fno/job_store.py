"""
model/fno/job_store.py
Persistence for fno_ingestion_jobs. Jobs survive restarts (unlike ui/job_manager.py,
whose jobs live in memory). Duplicate prevention is enforced by the database:
`active_key` equals the dedupe key while a job is PENDING/RUNNING and is NULL
afterwards, under a UNIQUE index -- so it is race-free even across processes.
"""
import datetime
import hashlib
import json
from typing import Optional

from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from model.fno.db import is_fno_engine
from model.fno.errors import DuplicateJobError, IsolationError
from model.fno.models import IST, JOB_STATES

COUNTERS = ("requests_made", "rows_raw", "rows_valid", "rows_invalid", "rows_stored", "rows_duplicate",
            "no_data_count", "retry_count")
_COLS = ("id, job_type, params, state, created_at, started_at, finished_at, heartbeat_at, cancel_requested, "
         "resumed_from, " + ", ".join(COUNTERS) + ", error, result")


def _now():
    return datetime.datetime.now(tz=IST).replace(tzinfo=None, microsecond=0)


def dedupe_key(job_type: str, params: dict) -> str:
    canon = json.dumps({"t": job_type, "p": params}, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()


def _to_dict(r) -> dict:
    d = dict(zip([c.strip() for c in _COLS.split(",")], r))
    for k in ("params", "result"):
        if isinstance(d.get(k), (str, bytes)):
            d[k] = json.loads(d[k])
    return d


class FnoJobStore:
    def __init__(self, engine):
        if not is_fno_engine(engine):
            raise IsolationError("FnoJobStore requires an engine created by model.fno.db.get_fno_engine().")
        self.engine = engine

    def submit(self, job_type: str, params: dict, resumed_from: Optional[int] = None) -> int:
        key = dedupe_key(job_type, params)
        try:
            with self.engine.begin() as conn:
                return conn.execute(text("""
                    INSERT INTO fno_ingestion_jobs (job_type, params, dedupe_key, active_key, state, resumed_from)
                    VALUES (:t, :p, :k, :k, 'PENDING', :r)"""),
                    {"t": job_type, "p": json.dumps(params, default=str), "k": key, "r": resumed_from}).lastrowid
        except IntegrityError:
            with self.engine.connect() as conn:
                existing = conn.execute(text("SELECT id FROM fno_ingestion_jobs WHERE active_key = :k"), {"k": key}).scalar()
            if existing is None:
                raise
            raise DuplicateJobError(existing)

    def get(self, job_id: int) -> Optional[dict]:
        with self.engine.connect() as conn:
            r = conn.execute(text(f"SELECT {_COLS} FROM fno_ingestion_jobs WHERE id = :i"), {"i": job_id}).fetchone()
        return _to_dict(r) if r else None

    def list(self, state: Optional[str] = None, limit: int = 50, offset: int = 0) -> list:
        sql, p = f"SELECT {_COLS} FROM fno_ingestion_jobs", {"l": int(limit), "o": int(offset)}
        if state:
            sql += " WHERE state = :s"; p["s"] = state
        with self.engine.connect() as conn:
            rows = conn.execute(text(sql + " ORDER BY id DESC LIMIT :l OFFSET :o"), p).fetchall()
        return [_to_dict(r) for r in rows]

    def claim_next(self, job_types: Optional[list] = None) -> Optional[dict]:
        """Atomically moves the oldest PENDING job to RUNNING. Returns it, or None."""
        with self.engine.connect() as conn:
            sql = "SELECT id FROM fno_ingestion_jobs WHERE state = 'PENDING'"
            p = {}
            if job_types:
                sql += " AND job_type IN (" + ",".join(f":t{i}" for i in range(len(job_types))) + ")"
                p = {f"t{i}": t for i, t in enumerate(job_types)}
            ids = [r[0] for r in conn.execute(text(sql + " ORDER BY id LIMIT 5"), p)]
        for jid in ids:
            now = _now()
            with self.engine.begin() as conn:
                n = conn.execute(text("""UPDATE fno_ingestion_jobs SET state='RUNNING', started_at=:n, heartbeat_at=:n
                                         WHERE id=:i AND state='PENDING'"""), {"n": now, "i": jid}).rowcount
            if n == 1:
                return self.get(jid)
        return None

    def heartbeat(self, job_id: int, now: Optional[datetime.datetime] = None) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("UPDATE fno_ingestion_jobs SET heartbeat_at=:n WHERE id=:i AND state='RUNNING'"),
                         {"n": now or _now(), "i": job_id})
            conn.execute(text("UPDATE fno_aggregation_jobs SET heartbeat_at=:n WHERE state='RUNNING' "
                "AND JSON_UNQUOTE(JSON_EXTRACT(contract_selection,'$.job_id'))=:i"),{"n":now or _now(),"i":str(job_id)})

    def add_counters(self, job_id: int, **deltas) -> None:
        bad = set(deltas) - set(COUNTERS)
        if bad:
            raise ValueError(f"unknown counters: {bad}")
        sets = ", ".join(f"{k} = {k} + :{k}" for k in deltas if deltas[k])
        if not sets:
            return
        with self.engine.begin() as conn:
            conn.execute(text(f"UPDATE fno_ingestion_jobs SET {sets} WHERE id = :i"),
                         {**{k: int(v) for k, v in deltas.items() if v}, "i": job_id})

    def progress(self, job_id: int, result: dict) -> None:
        """Persist an in-flight result and refresh its heartbeat atomically."""
        with self.engine.begin() as conn:
            conn.execute(text("""UPDATE fno_ingestion_jobs SET result=:r, heartbeat_at=:n
                                 WHERE id=:i AND state='RUNNING'"""),
                         {"i": job_id, "r": json.dumps(result, default=str), "n": _now()})

    def request_cancel(self, job_id: int) -> str:
        """PENDING -> CANCELLED at once; RUNNING -> flag, honoured after the current contract."""
        with self.engine.begin() as conn:
            n = conn.execute(text("""UPDATE fno_ingestion_jobs SET state='CANCELLED', finished_at=:n, active_key=NULL
                                     WHERE id=:i AND state='PENDING'"""), {"n": _now(), "i": job_id}).rowcount
            if n:
                return "CANCELLED"
            n = conn.execute(text("UPDATE fno_ingestion_jobs SET cancel_requested=1 WHERE id=:i AND state='RUNNING'"),
                             {"i": job_id}).rowcount
            return "CANCEL_REQUESTED" if n else "NOT_ACTIVE"

    def cancel_requested(self, job_id: int) -> bool:
        with self.engine.connect() as conn:
            return bool(conn.execute(text("SELECT cancel_requested FROM fno_ingestion_jobs WHERE id=:i"), {"i": job_id}).scalar())

    def finish(self, job_id: int, state: str, error: Optional[str] = None, result: Optional[dict] = None) -> None:
        if state not in JOB_STATES or state in ("PENDING", "RUNNING"):
            raise ValueError(f"invalid final state {state}")
        with self.engine.begin() as conn:
            conn.execute(text("""UPDATE fno_ingestion_jobs SET state=:s, finished_at=:n, active_key=NULL, error=:e, result=:r
                                 WHERE id=:i"""),
                         {"s": state, "n": _now(), "e": (error or None) and error[:4000], "i": job_id,
                          "r": json.dumps(result, default=str) if result is not None else None})

    def recover_interrupted(self, stale_after_seconds: float, now: Optional[datetime.datetime] = None) -> list:
        """RUNNING jobs whose heartbeat is older than the threshold -> INTERRUPTED (resumable). Returns ids."""
        now = now or _now()
        cutoff = now - datetime.timedelta(seconds=stale_after_seconds)
        with self.engine.begin() as conn:
            ids = [r[0] for r in conn.execute(text("""SELECT id FROM fno_ingestion_jobs WHERE state='RUNNING'
                     AND COALESCE(heartbeat_at, started_at, created_at) < :c"""), {"c": cutoff})]
            for i in ids:
                conn.execute(text("""UPDATE fno_ingestion_jobs SET state='INTERRUPTED', finished_at=:n, active_key=NULL,
                    error=COALESCE(error, 'Heartbeat went stale: process stopped or crashed; resume to continue.')
                    WHERE id=:i"""), {"n": now, "i": i})
                conn.execute(text("UPDATE fno_aggregation_jobs SET state='INTERRUPTED',finished_at=:n,error='Worker heartbeat expired' "
                    "WHERE state='RUNNING' AND JSON_UNQUOTE(JSON_EXTRACT(contract_selection,'$.job_id'))=:i"),{"n":now,"i":str(i)})
        return ids

    def resume(self, job_id: int) -> int:
        """New PENDING job with the same params, linked via resumed_from. Verified ranges are skipped by the planner."""
        old = self.get(job_id)
        if old is None:
            raise KeyError(f"job {job_id} not found")
        if old["state"] not in ("INTERRUPTED", "PARTIAL", "FAILED"):
            raise ValueError(f"job {job_id} is {old['state']}; only INTERRUPTED/PARTIAL/FAILED jobs can be resumed")
        return self.submit(old["job_type"], old["params"], resumed_from=job_id)
