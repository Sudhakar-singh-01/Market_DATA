"""FNO (Futures & Options) subsystem. Independent of Subsystem A (stocks/indices):
own database, own Parquet root, own checkpoints and jobs. See docs/FNO_AUDIT.md."""
