"""Bounded FNO read verification; existing parsers/comparison/aggregation reused.

This never invokes the verification job writer or repairs a partition. Sparse
options can have verified values without claiming complete minute coverage.
"""
import datetime as dt
from decimal import Decimal

import pandas as pd
from sqlalchemy import select

from model.config.market_calendar import IST, expected_starts, session_window
from model.fno.aggregation import aggregate_day, invalid_candle
from model.fno.comparison import frames_equal
from model.fno.config import SessionSettings, assert_within_fno_root
from model.fno.models import FnoCandle
from model.fno.parquet_store import COLUMNS, KEY, FnoParquetStore, candles_to_frame
from model.read_contracts import DataNotVerifiedError

MAX_CONTRACT_ROWS = 20000
MAX_SCAN_ROWS = 2000000


def _sql(service, inst, tf, day):
    _, table, conditions, _, _ = service._candle_query('FNO', inst['fyers_symbol'], tf, day, day)
    rows = service._read('FNO', select(table).where(*conditions).order_by(table.c.candle_timestamp).limit(MAX_CONTRACT_ROWS+1))
    if len(rows) > MAX_CONTRACT_ROWS:
        raise DataNotVerifiedError('Contract-day exceeds verification bound')
    return rows


def _parquet(service, inst, tf, day):
    import pyarrow.parquet as pq
    root = service.catalog.roots['FNO']
    store = FnoParquetStore(root, None)
    expiry = inst['expiry']
    if isinstance(expiry, str):
        expiry = dt.date.fromisoformat(expiry)
    rel = store.relative_candle_path(tf, inst['underlying'], expiry, day)
    path = assert_within_fno_root(store.abs_path(rel), root)
    table = service.catalog.table('FNO', 'fno_storage_manifest')
    entries = service._read('FNO', select(table).where(table.c.relative_path == rel))
    if not path.exists():
        if entries:
            raise DataNotVerifiedError('Manifest references missing Parquet')
        return []
    if len(entries) != 1 or entries[0]['status'] != 'VERIFIED':
        raise DataNotVerifiedError('Parquet manifest is not VERIFIED')
    before = path.stat()
    file = pq.ParquetFile(path)
    if file.metadata.num_rows > MAX_SCAN_ROWS:
        raise DataNotVerifiedError('Shared partition exceeds scan bound; narrow/split storage before verification')
    if file.metadata.num_rows != entries[0]['row_count'] or store.sha256(path) != entries[0]['checksum']:
        raise DataNotVerifiedError('Parquet checksum/row count differs from manifest')
    out = []
    for batch in file.iter_batches(batch_size=2000, columns=COLUMNS):
        frame = batch.to_pandas()
        out.extend(frame[frame.contract_id == inst['id']].to_dict('records'))
        if len(out) > MAX_CONTRACT_ROWS:
            raise DataNotVerifiedError('Contract-day exceeds verification bound')
    after = path.stat()
    if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size):
        raise DataNotVerifiedError('Partition changed during verification; retry')
    return out


def _candles(rows):
    result = []
    for row in rows:
        optional = {k: None if pd.isna(row.get(k)) else Decimal(str(row[k]))
                    for k in ('iv', 'delta', 'gamma', 'theta', 'vega')}
        oi = row.get('oi')
        volume = Decimal(str(row['volume']))
        if not volume.is_finite() or volume != volume.to_integral():
            raise DataNotVerifiedError('Invalid volume')
        if oi is not None and not pd.isna(oi):
            oi = Decimal(str(oi))
            if not oi.is_finite() or oi != oi.to_integral():
                raise DataNotVerifiedError('Invalid OI')
            oi = int(oi)
        else:
            oi = None
        ts = pd.Timestamp(row['candle_timestamp']).to_pydatetime()
        ts = ts.replace(tzinfo=IST) if ts.tzinfo is None else ts.astimezone(IST)
        c = FnoCandle(int(row['contract_id']), row['timeframe'], ts,
            *(Decimal(str(row[k])) for k in ('open','high','low','close')),
            int(volume), source=row['source'], status=row['status'], oi=oi, **optional)
        if invalid_candle(c) or any(v is not None and not v.is_finite() for v in optional.values()):
            raise DataNotVerifiedError('Invalid OHLCV or optional values')
        if c.iv is not None and c.iv < 0:
            raise DataNotVerifiedError('Negative IV')
        result.append(c)
    return result


def _checked(service, inst, tf, day):
    sql, parquet = _sql(service, inst, tf, day), _parquet(service, inst, tf, day)
    frames = [pd.DataFrame(rows, columns=COLUMNS) for rows in (sql, parquet)]
    if any(f.duplicated(KEY).any() for f in frames) or not frames_equal(*frames):
        raise DataNotVerifiedError('SQL and Parquet values/keys disagree')
    window = session_window(day, 'FNO')
    for rows in (sql, parquet):
        candles = _candles(rows)
        for c in candles:
            if (c.contract_id != inst['id'] or c.timeframe != tf or c.status != 'CLOSED'
                or c.timestamp.second or c.timestamp.microsecond or not window
                or not window[0] <= c.timestamp < window[1]):
                raise DataNotVerifiedError('Invalid candle identity, status, alignment or session')
    return sql, _candles(sql)


def verified_day(service, inst, tf, day):
    base_rows, base = _checked(service, inst, '1m', day)
    expected = set(expected_starts(day, 'FNO'))
    observed = {c.timestamp for c in base}
    missing = expected-observed
    sparse = bool(missing) and inst['category'] == 'OPTIONS'
    if missing and not sparse:
        raise DataNotVerifiedError('Futures minute coverage is incomplete')
    if expected and not base:
        raise DataNotVerifiedError('Empty session cannot prove no trading; fetch/verify evidence is required')
    if tf == '1m':
        return base_rows, sparse
    rows, _ = _checked(service, inst, tf, day)
    window = session_window(day, 'FNO')
    if not window:
        return rows, sparse
    # Special-session times are explicit, without changing legacy aggregation defaults.
    session = SessionSettings(window[0].time(), (window[1]-dt.timedelta(minutes=1)).time(), window[1].time(), False)
    calculated = aggregate_day(base, day, tf, session, now=service.clock())
    if not frames_equal(pd.DataFrame(rows, columns=COLUMNS), candles_to_frame(calculated.candles)):
        raise DataNotVerifiedError('Derived candles disagree with canonical source')
    return rows, sparse
