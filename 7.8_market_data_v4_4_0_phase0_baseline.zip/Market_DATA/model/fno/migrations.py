"""
model/fno/migrations.py
Applies the numbered, idempotent SQL files in database/fno/ to the FNO
database. NEVER called implicitly: only by `main.py fno-migrate --apply`
and the admin-confirmed dashboard button (same pattern as the audit-log
table button). Without --apply it only lists what would run.
"""

import logging
import re
from pathlib import Path
from sqlalchemy import text

from model.fno.errors import IsolationError
from model.fno.db import is_fno_engine

log = logging.getLogger("market_data.fno.migrations")

SQL_DIR = Path(__file__).resolve().parents[2] / "database" / "fno"


def list_sql_files(sql_dir: Path = SQL_DIR) -> list:
    return sorted(p for p in Path(sql_dir).glob("[0-9][0-9][0-9]_*.sql"))


def split_statements(sql: str) -> list:
    """Splits on ';' outside of -- comments. Files must not contain procedural code."""
    no_comments = re.sub(r"--[^\n]*", "", sql)
    return [s.strip() for s in no_comments.split(";") if s.strip()]


def plan(sql_dir: Path = SQL_DIR) -> list:
    return [(p.name, len(split_statements(p.read_text(encoding="utf-8")))) for p in list_sql_files(sql_dir)]


def apply_all(engine, sql_dir: Path = SQL_DIR) -> list:
    if not is_fno_engine(engine):
        raise IsolationError("fno-migrate requires an engine created by model.fno.db.get_fno_engine().")
    applied = []
    for path in list_sql_files(sql_dir):
        statements = split_statements(path.read_text(encoding="utf-8"))
        with engine.begin() as conn:
            for stmt in statements:
                conn.execute(text(stmt))
        applied.append((path.name, len(statements)))
        log.info("Applied %s (%d statements)", path.name, len(statements))
    return applied
