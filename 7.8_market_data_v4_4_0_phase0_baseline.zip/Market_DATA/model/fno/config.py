"""
model/fno/config.py
Typed configuration for the FNO subsystem.

* FnoDatabaseConfig  <- NEW env variables FNO_DB_HOST/PORT/NAME/USER/PASSWORD.
  Same MySQL server as Subsystem A is allowed; the settings are explicit
  and separate, and model/fno/db.py refuses a database name equal to A's.
* FnoSettings        <- config/fno_settings.yaml (no secrets, no machine paths).

Parquet root isolation: resolve_parquet_root() refuses any root that equals,
contains, or lies inside Subsystem A's data/raw or data/processed trees.
"""

import datetime
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

from model.config.yaml_loader import load_yaml
from model.exceptions import ConfigurationError

PROJECT_ROOT = Path(__file__).resolve().parents[2]
_ENV_PATH = PROJECT_ROOT / "config" / ".env"
_SETTINGS_PATH = PROJECT_ROOT / "config" / "fno_settings.yaml"

# Subsystem A's Parquet trees (see model/storage/parquet.py): never FNO's.
SUBSYSTEM_A_DATA_ROOT = "data"
SUBSYSTEM_A_PARQUET_DIRS = ("raw", "processed")


# ------------------------------------------------------------------ database
@dataclass(frozen=True)
class FnoDatabaseConfig:
    host: str
    port: int
    name: str
    user: str
    password: str

    def __repr__(self) -> str:
        return f"FnoDatabaseConfig(host={self.host!r}, port={self.port}, name={self.name!r}, user=***, password=***)"

    @staticmethod
    def from_env(environ=None) -> "FnoDatabaseConfig":
        env = os.environ if environ is None else environ
        try:
            port = int(env.get("FNO_DB_PORT", "3306"))
        except ValueError as exc:
            raise ConfigurationError("FNO_DB_PORT must be an integer.") from exc
        return FnoDatabaseConfig(
            host=env.get("FNO_DB_HOST", "localhost"),
            port=port,
            name=env.get("FNO_DB_NAME", "fno_market_data"),
            user=env.get("FNO_DB_USER", ""),
            password=env.get("FNO_DB_PASSWORD", ""),
        )

    def require_credentials(self) -> None:
        if not self.user:
            raise ConfigurationError(
                "FNO_DB_USER is not set. Add FNO_DB_HOST/PORT/NAME/USER/PASSWORD to config/.env "
                "(see config/.env.example)."
            )


def load_fno_database_config() -> FnoDatabaseConfig:
    from model.config.runtime_paths import config_path
    selected_env = config_path(_ENV_PATH)
    if selected_env.exists():
        load_dotenv(dotenv_path=selected_env)
    return FnoDatabaseConfig.from_env()


# ------------------------------------------------------------------ settings
@dataclass(frozen=True)
class RateLimitSettings:
    per_second: int
    per_minute: int
    per_day: int
    fno_reserve_fraction: float


@dataclass(frozen=True)
class UniverseSettings:
    underlyings: tuple
    expiries_ahead: int
    strike_window: int
    include_futures: bool
    include_options: bool
    spot_symbols: dict


@dataclass(frozen=True)
class SymbolMasterSettings:
    url: str
    format: str
    max_age_hours: float
    timeout_seconds: float
    csv_columns: dict


@dataclass(frozen=True)
class SessionSettings:
    open: datetime.time
    last_minute: datetime.time
    close: datetime.time
    reject_weekend_timestamps: bool


DEFAULT_SESSION = SessionSettings(datetime.time(9, 15), datetime.time(15, 39), datetime.time(15, 40), False)


@dataclass(frozen=True)
class HistorySettings:
    resolution: str
    max_days_per_request: int
    oi_flag: bool
    cont_flag: str
    default_lookback_days: int
    session_close_buffer_minutes: int
    max_retries: int
    initial_backoff_seconds: float
    backoff_multiplier: float
    invalid_symbol_codes: tuple
    auth_error_codes: tuple
    rate_limit_codes: tuple


@dataclass(frozen=True)
class SubscriptionSettings:
    max_subscriptions: int
    max_extra_sockets: int


@dataclass(frozen=True)
class JobSettings:
    concurrency: int
    heartbeat_seconds: float
    stale_after_seconds: float


@dataclass(frozen=True)
class ChainSettings:
    interval_minutes: int
    strikecount: int
    greeks: bool


@dataclass(frozen=True)
class LiveSettings:
    flush_seconds: float
    stale_after_seconds: float
    backfill_max_contracts: int
    max_buffered_candles: int


@dataclass(frozen=True)
class RetentionSettings:
    candles_1m_days: int
    option_chain_days: int


@dataclass(frozen=True)
class FnoSettings:
    parquet_root: Path               # absolute, already validated
    universe: UniverseSettings
    symbol_master: SymbolMasterSettings
    history: HistorySettings
    session: SessionSettings
    expired_history_enabled: bool
    expired_history_max_age_days: int
    rate_limits: RateLimitSettings
    subscriptions: SubscriptionSettings
    jobs: JobSettings
    chain: ChainSettings
    live: LiveSettings
    retention: RetentionSettings


def _is_within(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def resolve_parquet_root(root: str, project_root: Path = PROJECT_ROOT,
                         a_data_root: Optional[str] = None) -> Path:
    """Returns the absolute FNO Parquet root, or raises ConfigurationError if it
    would overlap Subsystem A's Parquet trees."""
    if not root or not str(root).strip():
        raise ConfigurationError("fno_settings.yaml parquet.root must be set.")
    path = Path(root)
    from model.config.runtime_paths import profile_home
    home = profile_home()
    resolved = (path if path.is_absolute() else ((home or project_root) / path)).resolve()
    from model.storage_scope import cash_data_root
    a_root = (project_root / a_data_root).resolve() if a_data_root is not None else cash_data_root(project_root).resolve()
    # FNO may sit INSIDE data/ (e.g. data/fno) but must not equal or contain data/ itself ...
    if resolved == a_root or _is_within(a_root, resolved):
        raise ConfigurationError(
            f"FNO Parquet root '{resolved}' is (or contains) Subsystem A's data directory '{a_root}'. "
            f"Use a dedicated folder such as data/fno.")
    # ... and must not equal, contain, or lie inside A's raw/ or processed/ trees.
    for sub in SUBSYSTEM_A_PARQUET_DIRS:
        a_dir = a_root / sub
        if resolved == a_dir or _is_within(resolved, a_dir) or _is_within(a_dir, resolved):
            raise ConfigurationError(
                f"FNO Parquet root '{resolved}' overlaps Subsystem A's Parquet tree '{a_dir}'. "
                f"Use a dedicated folder such as data/fno.")
    return resolved


def assert_within_fno_root(path, fno_root: Path) -> Path:
    """Guard used by every FNO delete/cleanup/rename: the path must resolve to a
    location strictly inside the FNO Parquet root."""
    resolved = Path(path).resolve()
    root = Path(fno_root).resolve()
    if resolved == root or not _is_within(resolved, root):
        raise ConfigurationError(f"Refusing to touch '{resolved}': it is not inside the FNO root '{root}'.")
    return resolved


def _need(raw: dict, *keys):
    node = raw
    for k in keys:
        if not isinstance(node, dict) or k not in node:
            raise ConfigurationError(f"fno_settings.yaml is missing required key: {'.'.join(keys)}")
        node = node[k]
    return node


def parse_fno_settings(raw: dict, project_root: Path = PROJECT_ROOT) -> FnoSettings:
    try:
        universe = UniverseSettings(
            underlyings=tuple(str(u).upper() for u in _need(raw, "universe", "underlyings")),
            expiries_ahead=int(_need(raw, "universe", "expiries_ahead")),
            strike_window=int(_need(raw, "universe", "strike_window")),
            include_futures=bool(_need(raw, "universe", "include_futures")),
            include_options=bool(_need(raw, "universe", "include_options")),
            spot_symbols={str(k).upper(): str(v) for k, v in (raw["universe"].get("spot_symbols") or {}).items()},
        )
        sm = _need(raw, "symbol_master")
        symbol_master = SymbolMasterSettings(
            url=str(sm["url"]), format=str(sm["format"]).lower(),
            max_age_hours=float(sm["max_age_hours"]), timeout_seconds=float(sm["timeout_seconds"]),
            csv_columns={str(k): int(v) for k, v in (sm.get("csv_columns") or {}).items()},
        )
        h = _need(raw, "history")
        history = HistorySettings(
            resolution=str(h["resolution"]), max_days_per_request=int(h["max_days_per_request"]),
            oi_flag=bool(h["oi_flag"]), cont_flag=str(h.get("cont_flag", "0")),
            default_lookback_days=int(h["default_lookback_days"]),
            session_close_buffer_minutes=int(h["session_close_buffer_minutes"]),
            max_retries=int(h["max_retries"]), initial_backoff_seconds=float(h["initial_backoff_seconds"]),
            backoff_multiplier=float(h["backoff_multiplier"]),
            invalid_symbol_codes=tuple(int(c) for c in h["invalid_symbol_codes"]),
            auth_error_codes=tuple(int(c) for c in h["auth_error_codes"]),
            rate_limit_codes=tuple(int(c) for c in h["rate_limit_codes"]),
        )
        sess = raw.get("session") or {}
        hhmm = lambda v: datetime.datetime.strptime(str(v), "%H:%M").time()
        session = SessionSettings(hhmm(sess.get("open", "09:15")), hhmm(sess.get("last_minute", "15:39")),
                                  hhmm(sess.get("close", "15:40")), bool(sess.get("reject_weekend_timestamps", False)))
        r = _need(raw, "rate_limits")
        rate_limits = RateLimitSettings(
            per_second=int(r["per_second"]), per_minute=int(r["per_minute"]), per_day=int(r["per_day"]),
            fno_reserve_fraction=float(r["fno_reserve_fraction"]),
        )
        s = _need(raw, "subscriptions")
        subscriptions = SubscriptionSettings(int(s["max_subscriptions"]), int(s["max_extra_sockets"]))
        j = _need(raw, "jobs")
        jobs = JobSettings(int(j["concurrency"]), float(j["heartbeat_seconds"]), float(j["stale_after_seconds"]))
        c = _need(raw, "chain")
        chain = ChainSettings(int(c["interval_minutes"]), int(c["strikecount"]), bool(c["greeks"]))
        lv = raw.get("live") or {}
        live = LiveSettings(float(lv.get("flush_seconds", 5)), float(lv.get("stale_after_seconds", 120)),
                            int(lv.get("backfill_max_contracts", 100)), int(lv.get("max_buffered_candles", 50000)))
        t = _need(raw, "retention")
        retention = RetentionSettings(int(t["candles_1m_days"]), int(t["option_chain_days"]))
        eh = raw.get("expired_history") or {}
        expired_enabled = bool(eh.get("enabled", False))
        expired_max_age = int(eh.get("max_age_days", 14))
        parquet_root = resolve_parquet_root(str(_need(raw, "parquet", "root")), project_root)
    except (KeyError, TypeError, ValueError) as exc:
        raise ConfigurationError(f"fno_settings.yaml has an invalid value: {exc}") from exc

    if not universe.underlyings:
        raise ConfigurationError("fno_settings.yaml universe.underlyings must not be empty.")
    if symbol_master.format not in ("csv", "json"):
        raise ConfigurationError("symbol_master.format must be 'csv' or 'json'.")
    if not (session.open <= session.last_minute < session.close):
        raise ConfigurationError("session must satisfy open <= last_minute < close.")
    if expired_max_age < 0:
        raise ConfigurationError("expired_history.max_age_days must be >= 0.")
    if history.max_days_per_request < 1:
        raise ConfigurationError("history.max_days_per_request must be >= 1.")
    if not 0.0 <= rate_limits.fno_reserve_fraction < 1.0:
        raise ConfigurationError("rate_limits.fno_reserve_fraction must be in [0, 1).")
    if min(rate_limits.per_second, rate_limits.per_minute, rate_limits.per_day) < 1:
        raise ConfigurationError("rate_limits values must be >= 1.")
    if live.flush_seconds <= 0 or live.backfill_max_contracts < 0 or live.max_buffered_candles < 1:
        raise ConfigurationError("live.* values are invalid.")
    if jobs.concurrency < 1 or jobs.stale_after_seconds <= jobs.heartbeat_seconds:
        raise ConfigurationError("jobs.concurrency must be >= 1 and stale_after_seconds > heartbeat_seconds.")

    return FnoSettings(
        parquet_root=parquet_root, universe=universe, symbol_master=symbol_master, history=history, session=session,
        expired_history_enabled=expired_enabled, expired_history_max_age_days=expired_max_age, rate_limits=rate_limits, subscriptions=subscriptions,
        jobs=jobs, chain=chain, live=live, retention=retention,
    )


def load_fno_settings(path: Optional[Path] = None) -> FnoSettings:
    return parse_fno_settings(load_yaml(path or _SETTINGS_PATH))
