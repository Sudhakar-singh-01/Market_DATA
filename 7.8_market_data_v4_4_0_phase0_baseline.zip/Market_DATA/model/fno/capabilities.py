"""Documented FYERS v3 data methods, checked against the installed SDK.

No guessed REST routes or silently constructed derivative symbols.
"""
import datetime as dt
METHODS=('history','optionchain','expiry_dates','history_underlying_symbols','fno_historical_data','futures_chain')
class UnsupportedCapabilityError(RuntimeError):pass

def capabilities(client=None):
    if client is None:
        from fyers_apiv3.fyersModel import FyersModel
        client=FyersModel
    return {name:callable(getattr(client,name,None)) for name in METHODS}


def call(client,method,payload):
    if method not in METHODS or not capabilities(client).get(method):
        raise UnsupportedCapabilityError(f'{method} is NOT AVAILABLE in the installed FYERS SDK. Review the documented SDK upgrade and run an account probe.')
    return getattr(client,method)(data=payload)


def discovery(client,kind,symbol,start=None,end=None,expiry=None):
    if not symbol or ':' not in symbol:raise ValueError('Use an exact FYERS master symbol')
    if kind=='expiries':
        a,b=dt.date.fromisoformat(start),dt.date.fromisoformat(end)
        if a>b or (b-a).days>365:raise ValueError('Expiry discovery supports at most 366 days')
        return call(client,'expiry_dates',{'symbol':symbol,'range_from':start,'range_to':end,'date_format':'1'})
    if kind=='contracts':
        dt.date.fromisoformat(expiry)
        return call(client,'history_underlying_symbols',{'symbol':symbol,'expiry_date':expiry})
    if kind=='futures':return call(client,'futures_chain',{'symbol':symbol})
    raise ValueError('Unknown discovery operation')
