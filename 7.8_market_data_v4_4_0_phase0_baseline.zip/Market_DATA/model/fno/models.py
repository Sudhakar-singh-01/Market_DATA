"""
model/fno/models.py
Canonical FNO data types. Prices are Decimal (quantised to 4 dp at the
normalisation boundary) because MySQL columns are DECIMAL; unknown values are
None, never 0. Timestamps are tz-aware Asia/Kolkata in memory and IST
wall-clock (naive) in MySQL, matching Subsystem A.
"""

import datetime
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from model.processing.models import IST  # same zone object as Subsystem A

CATEGORY_FUTURES = "FUTURES"
CATEGORY_OPTIONS = "OPTIONS"
STATUS_ACTIVE = "ACTIVE"
STATUS_EXPIRED = "EXPIRED"

SOURCE_HISTORICAL = "FYERS_HISTORICAL"
SOURCE_LIVE = "FYERS_LIVE"
SOURCE_AGGREGATED = "AGGREGATED"


@dataclass
class FnoContract:
    fyers_symbol: str
    underlying: str
    exchange: str
    category: str                       # FUTURES | OPTIONS
    expiry: datetime.date
    strike: Optional[Decimal] = None
    option_type: Optional[str] = None   # CE | PE
    lot_size: Optional[int] = None
    tick_size: Optional[Decimal] = None
    fytoken: Optional[str] = None
    source: str = "FYERS_SYMBOL_MASTER"
    status: str = STATUS_ACTIVE
    contract_id: Optional[int] = None   # set once stored


@dataclass
class FnoCandle:
    contract_id: int
    timeframe: str
    timestamp: datetime.datetime        # tz-aware IST, period start
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: int
    source: str = SOURCE_HISTORICAL
    status: str = "CLOSED"
    oi: Optional[int] = None
    iv: Optional[Decimal] = None
    delta: Optional[Decimal] = None
    gamma: Optional[Decimal] = None
    theta: Optional[Decimal] = None
    vega: Optional[Decimal] = None

    def naive_ist(self) -> datetime.datetime:
        return self.timestamp.astimezone(IST).replace(tzinfo=None)


@dataclass
class WriteResult:
    """Outcome of one MySQL candle write. All counters are per call."""
    inserted: int = 0          # new rows
    filled: int = 0            # existing rows that had NULL columns filled / OPEN->CLOSED
    duplicate: int = 0         # identical to what is already stored
    conflicts: int = 0         # CLOSED OHLCV differs from stored -> NOT applied, reported
    conflict_samples: list = field(default_factory=list)
    superseded_live: int = 0          # provisional LIVE candles replaced by authoritative history
    superseded_changed: int = 0       # ...of which OHLC or volume actually differed (= live approximation error)
    superseded_fields: dict = field(default_factory=dict)   # per-field count of differences (open/high/low/close/volume)
    parquet_quarantined: int = 0      # existing Parquet files set aside because their manifest row was not VERIFIED

    def merge(self, other: "WriteResult") -> "WriteResult":
        self.inserted += other.inserted
        self.filled += other.filled
        self.duplicate += other.duplicate
        self.conflicts += other.conflicts
        self.superseded_live += other.superseded_live
        self.superseded_changed += other.superseded_changed
        self.parquet_quarantined += other.parquet_quarantined
        for k, v in other.superseded_fields.items():
            self.superseded_fields[k] = self.superseded_fields.get(k, 0) + v
        self.conflict_samples = (self.conflict_samples + other.conflict_samples)[:20]
        return self

    @property
    def stored(self) -> int:
        return self.inserted + self.filled


# checkpoint range statuses
R_VERIFIED = "VERIFIED"
R_NO_DATA = "NO_DATA"
R_FAILED = "FAILED"
R_EXPIRED = "EXPIRED_UNRECOVERABLE"

JOB_STATES = ("PENDING", "RUNNING", "PARTIAL", "SUCCESS", "NO_DATA", "FAILED", "CANCELLED", "INTERRUPTED")
JOB_ACTIVE_STATES = ("PENDING", "RUNNING")
