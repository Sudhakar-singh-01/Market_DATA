"""
model/fno/ranges.py
Pure date-range arithmetic for range-based checkpoints (no I/O -> fully unit-testable).

A range is (from_date, to_date, status), both ends inclusive calendar days.
Status precedence when ranges overlap:
    VERIFIED > NO_DATA > EXPIRED_UNRECOVERABLE > FAILED
A FAILED mark never overwrites VERIFIED/NO_DATA days. Adjacent or overlapping
ranges with the same status are merged (adjacent = consecutive days).
"""

import datetime
from typing import Iterable

from model.fno.models import R_VERIFIED, R_NO_DATA, R_FAILED, R_EXPIRED

_ONE = datetime.timedelta(days=1)
PRECEDENCE = {R_VERIFIED: 4, R_NO_DATA: 3, R_EXPIRED: 2, R_FAILED: 1}
DONE_STATUSES = (R_VERIFIED, R_NO_DATA)          # days that need no more fetching
TERMINAL_STATUSES = (R_VERIFIED, R_NO_DATA, R_EXPIRED)


def merge_ranges(ranges: Iterable) -> list:
    """Merges overlapping/adjacent ranges that share a status."""
    out = []
    by_status = {}
    for a, b, s in ranges:
        if a > b:
            raise ValueError(f"invalid range {a}..{b}")
        by_status.setdefault(s, []).append((a, b))
    for status, items in by_status.items():
        items.sort()
        cur_a, cur_b = items[0]
        for a, b in items[1:]:
            if a <= cur_b + _ONE:
                cur_b = max(cur_b, b)
            else:
                out.append((cur_a, cur_b, status))
                cur_a, cur_b = a, b
        out.append((cur_a, cur_b, status))
    return sorted(out)


def _subtract(base: tuple, cut_a: datetime.date, cut_b: datetime.date) -> list:
    a, b, s = base
    if cut_b < a or cut_a > b:
        return [base]
    pieces = []
    if a < cut_a:
        pieces.append((a, cut_a - _ONE, s))
    if b > cut_b:
        pieces.append((cut_b + _ONE, b, s))
    return pieces


def apply_range(existing: Iterable, new_from: datetime.date, new_to: datetime.date, status: str) -> list:
    """Returns the new full set of ranges after marking [new_from, new_to] with `status`."""
    if new_from > new_to:
        raise ValueError(f"invalid range {new_from}..{new_to}")
    new_rank = PRECEDENCE[status]
    kept = []
    for rng in existing:
        if PRECEDENCE[rng[2]] <= new_rank:
            kept.extend(_subtract(rng, new_from, new_to))     # new mark wins over equal/lower
        else:
            kept.append(rng)                                  # higher-precedence ranges stay intact
    # the new range minus anything of strictly higher precedence
    pieces = [(new_from, new_to, status)]
    for a, b, s in kept:
        if PRECEDENCE[s] > new_rank:
            nxt = []
            for p in pieces:
                nxt.extend(_subtract(p, a, b))
            pieces = nxt
    return merge_ranges(kept + pieces)


def missing_days(want_from: datetime.date, want_to: datetime.date, ranges: Iterable,
                 done_statuses=DONE_STATUSES) -> list:
    """Sub-ranges of [want_from, want_to] NOT covered by ranges whose status is in done_statuses."""
    gaps = [(want_from, want_to)]
    for a, b, s in sorted(ranges):
        if s not in done_statuses:
            continue
        nxt = []
        for ga, gb in gaps:
            if b < ga or a > gb:
                nxt.append((ga, gb))
                continue
            if ga < a:
                nxt.append((ga, a - _ONE))
            if gb > b:
                nxt.append((b + _ONE, gb))
        gaps = nxt
    return sorted(gaps)


def chunk_range(a: datetime.date, b: datetime.date, max_days: int) -> list:
    if max_days < 1:
        raise ValueError("max_days must be >= 1")
    out, cur = [], a
    while cur <= b:
        end = min(cur + datetime.timedelta(days=max_days - 1), b)
        out.append((cur, end))
        cur = end + _ONE
    return out
