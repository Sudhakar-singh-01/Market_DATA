"""
model/fno/repository.py
All FNO MySQL access (except jobs -> job_store.py). Works ONLY on fno_* tables
and only with an engine produced by model.fno.db.get_fno_engine().

Candle write policy (differs from Subsystem A's write-once INSERT IGNORE).
SOURCE PRECEDENCE: a LIVE candle (built from sampled ticks: OHLC and volume are approximate) is
PROVISIONAL. An incoming FYERS_HISTORICAL candle supersedes it (counted as `filled`), while a LIVE
candle never changes a stored HISTORICAL one (ignored as a duplicate, not a conflict).
  * new key                      -> inserted.
  * stored CLOSED, same OHLCV    -> only columns that are currently NULL
                                    (oi, iv, delta, gamma, theta, vega) are filled.
  * stored CLOSED, OHLCV differs -> NOTHING is applied; counted as a conflict
                                    and reported (a CLOSED candle's OHLCV/volume
                                    is never overwritten).
  * stored OPEN                  -> replaced by the new values; a CLOSED arrival
                                    moves status OPEN -> CLOSED.
The same rules are enforced again in SQL (ON DUPLICATE KEY UPDATE) so a race
between two writers cannot violate them.

Checkpoint reset and candle delete are SEPARATE actions: resetting checkpoints
never deletes candles; deleting candles never resets checkpoints.
"""

import datetime
import json
import logging
from decimal import Decimal
from typing import Iterable, Optional

from sqlalchemy import text

from model.fno import ranges as rng
from model.fno.db import is_fno_engine
from model.fno.errors import IsolationError
from model.fno.models import (FnoContract, FnoCandle, WriteResult, IST, STATUS_ACTIVE, STATUS_EXPIRED,
                              R_VERIFIED, R_NO_DATA, R_EXPIRED, R_FAILED)

log = logging.getLogger("market_data.fno.repository")

_Q4, _Q6, _Q8 = Decimal("0.0001"), Decimal("0.000001"), Decimal("0.00000001")
_OPT_COLS = (("oi", None), ("iv", _Q6), ("delta", _Q8), ("gamma", _Q8), ("theta", _Q8), ("vega", _Q8))
_BATCH = 2000


def _dec(value, q) -> Optional[Decimal]:
    return None if value is None else Decimal(str(value)).quantize(q)


def _now_ist() -> datetime.datetime:
    return datetime.datetime.now(tz=IST).replace(tzinfo=None, microsecond=0)


def _row_values(c: FnoCandle) -> dict:
    return {
        "contract_id": c.contract_id, "timeframe": c.timeframe, "ts": c.naive_ist(),
        "open": _dec(c.open, _Q4), "high": _dec(c.high, _Q4), "low": _dec(c.low, _Q4), "close": _dec(c.close, _Q4),
        "volume": int(c.volume), "oi": None if c.oi is None else int(c.oi),
        "iv": _dec(c.iv, _Q6), "delta": _dec(c.delta, _Q8), "gamma": _dec(c.gamma, _Q8),
        "theta": _dec(c.theta, _Q8), "vega": _dec(c.vega, _Q8), "source": c.source, "status": c.status,
    }


# stored candle may be replaced when it is still OPEN, or when it is provisional LIVE and the incoming one is HISTORICAL
_SUPERSEDE = "(status = 'OPEN' OR (source = 'FYERS_LIVE' AND VALUES(source) = 'FYERS_HISTORICAL' AND VALUES(status) = 'CLOSED'))"
_SAME_ALLOWED = "(open=VALUES(open) AND high=VALUES(high) AND low=VALUES(low) AND close=VALUES(close) AND volume=VALUES(volume) AND NOT (source='FYERS_HISTORICAL' AND VALUES(source)='FYERS_LIVE'))"

_UPSERT_SQL = text("""
    INSERT INTO fno_candles
        (contract_id, timeframe, candle_timestamp, open, high, low, close, volume,
         oi, iv, delta, gamma, theta, vega, source, status)
    VALUES
        (:contract_id, :timeframe, :ts, :open, :high, :low, :close, :volume,
         :oi, :iv, :delta, :gamma, :theta, :vega, :source, :status)
    ON DUPLICATE KEY UPDATE
        -- assignments run left-to-right: `status` is assigned LAST so the IF()s see the stored status
        open   = IF(@SUP@, VALUES(open),   open),
        high   = IF(@SUP@, VALUES(high),   high),
        low    = IF(@SUP@, VALUES(low),    low),
        close  = IF(@SUP@, VALUES(close),  close),
        volume = IF(@SUP@, VALUES(volume), volume),
        oi     = IF(@SUP@, COALESCE(VALUES(oi),    oi),    IF(@SAME@, COALESCE(oi,    VALUES(oi)),oi)),
        iv     = IF(@SUP@, COALESCE(VALUES(iv),    iv),    IF(@SAME@, COALESCE(iv,    VALUES(iv)),iv)),
        delta  = IF(@SUP@, COALESCE(VALUES(delta), delta), IF(@SAME@, COALESCE(delta, VALUES(delta)),delta)),
        gamma  = IF(@SUP@, COALESCE(VALUES(gamma), gamma), IF(@SAME@, COALESCE(gamma, VALUES(gamma)),gamma)),
        theta  = IF(@SUP@, COALESCE(VALUES(theta), theta), IF(@SAME@, COALESCE(theta, VALUES(theta)),theta)),
        vega   = IF(@SUP@, COALESCE(VALUES(vega),  vega),  IF(@SAME@, COALESCE(vega,  VALUES(vega)),vega)),
        source = IF(@SUP@, VALUES(source), source),
        status = IF(status = 'OPEN' AND VALUES(status) = 'CLOSED', 'CLOSED', status)
""".replace("@SUP@", _SUPERSEDE).replace("@SAME@",_SAME_ALLOWED))


class FnoRepository:
    def __init__(self, engine):
        if not is_fno_engine(engine):
            raise IsolationError("FnoRepository requires an engine created by model.fno.db.get_fno_engine().")
        self.engine = engine

    # ------------------------------------------------------------- contracts
    def upsert_contracts(self, contracts: Iterable[FnoContract], seen_at: Optional[datetime.datetime] = None) -> dict:
        """Inserts new contracts and refreshes last_seen_at/status for known ones.
        first_seen_at is never changed. Returns {'inserted': n, 'updated': n}."""
        seen_at = seen_at or _now_ist()
        contracts = list(contracts)
        inserted = updated = 0
        for start in range(0, len(contracts), _BATCH):
            chunk = contracts[start:start + _BATCH]
            symbols = [c.fyers_symbol for c in chunk]
            with self.engine.begin() as conn:
                existing = set()
                for s in range(0, len(symbols), 500):
                    part = symbols[s:s + 500]
                    ph = ",".join(f":s{i}" for i in range(len(part)))
                    rows = conn.execute(text(f"SELECT fyers_symbol FROM fno_instruments WHERE fyers_symbol IN ({ph})"),
                                        {f"s{i}": v for i, v in enumerate(part)}).fetchall()
                    existing.update(r[0] for r in rows)
                new_rows, upd_rows = [], []
                for c in chunk:
                    p = {"sym": c.fyers_symbol, "tok": c.fytoken, "und": c.underlying, "ex": c.exchange,
                         "cat": c.category, "exp": c.expiry, "strike": _dec(c.strike, _Q4), "ot": c.option_type,
                         "lot": c.lot_size, "tick": _dec(c.tick_size, _Q4), "seen": seen_at, "src": c.source}
                    (upd_rows if c.fyers_symbol in existing else new_rows).append(p)
                if new_rows:
                    conn.execute(text("""
                        INSERT INTO fno_instruments (fyers_symbol, fytoken, underlying, exchange, category, expiry,
                            strike, option_type, lot_size, tick_size, status, first_seen_at, last_seen_at, source)
                        VALUES (:sym, :tok, :und, :ex, :cat, :exp, :strike, :ot, :lot, :tick, 'ACTIVE', :seen, :seen, :src)
                    """), new_rows)
                if upd_rows:
                    conn.execute(text("""
                        UPDATE fno_instruments SET last_seen_at = :seen, status = 'ACTIVE', exchange = :ex,
                            fytoken = COALESCE(:tok, fytoken), lot_size = COALESCE(:lot, lot_size),
                            tick_size = COALESCE(:tick, tick_size), source = :src
                        WHERE fyers_symbol = :sym
                    """), upd_rows)
                inserted += len(new_rows)
                updated += len(upd_rows)
        return {"inserted": inserted, "updated": updated}

    def upsert_contract(self, contract: FnoContract) -> int:
        self.upsert_contracts([contract])
        return self.get_contract_id(contract.fyers_symbol)

    def get_contract_id(self, fyers_symbol: str) -> Optional[int]:
        with self.engine.connect() as conn:
            row = conn.execute(text("SELECT id FROM fno_instruments WHERE fyers_symbol = :s"), {"s": fyers_symbol}).fetchone()
        return row[0] if row else None

    def mark_expired(self, today: datetime.date, synced_at: datetime.datetime) -> int:
        """ACTIVE contracts past expiry AND absent from the sync that started at `synced_at`
        (their last_seen_at is older) become EXPIRED. Rows are never deleted."""
        with self.engine.begin() as conn:
            n = conn.execute(text("""
                UPDATE fno_instruments SET status = 'EXPIRED'
                WHERE status = 'ACTIVE' AND expiry < :today AND last_seen_at < :synced_at
            """), {"today": today, "synced_at": synced_at}).rowcount
            conn.execute(text("""
                UPDATE fno_harvest_state h JOIN fno_instruments i ON i.id = h.contract_id
                SET h.status = 'EXPIRED' WHERE i.status = 'EXPIRED' AND h.status <> 'EXPIRED'
            """))
        return n

    def get_contracts(self, underlying: Optional[str] = None, category: Optional[str] = None,
                      status: Optional[str] = None, expiry_from: Optional[datetime.date] = None,
                      expiry_to: Optional[datetime.date] = None, limit: Optional[int] = None,
                      offset: int = 0) -> list:
        where, p = ["1=1"], {}
        for col, key, val in (("underlying", "u", underlying), ("category", "c", category), ("status", "s", status)):
            if val:
                where.append(f"{col} = :{key}"); p[key] = val
        if expiry_from:
            where.append("expiry >= :ef"); p["ef"] = expiry_from
        if expiry_to:
            where.append("expiry <= :et"); p["et"] = expiry_to
        sql = ("SELECT id, fyers_symbol, fytoken, underlying, exchange, category, expiry, strike, option_type, "
               "lot_size, tick_size, status, source FROM fno_instruments WHERE " + " AND ".join(where) +
               " ORDER BY expiry, underlying, strike, option_type, fyers_symbol")
        if limit is not None:
            sql += " LIMIT :lim OFFSET :off"; p.update(lim=int(limit), off=int(offset))
        with self.engine.connect() as conn:
            rows = conn.execute(text(sql), p).fetchall()
        return [FnoContract(contract_id=r[0], fyers_symbol=r[1], fytoken=r[2], underlying=r[3], exchange=r[4],
                            category=r[5], expiry=r[6], strike=r[7], option_type=r[8], lot_size=r[9],
                            tick_size=r[10], status=r[11], source=r[12]) for r in rows]

    def count_contracts(self, **filters) -> int:
        return len(self.get_contracts(**filters))

    # --------------------------------------------------------------- candles
    def _existing(self, conn, contract_id: int, timeframe: str, lo, hi) -> dict:
        rows = conn.execute(text("""
            SELECT candle_timestamp, open, high, low, close, volume, oi, iv, delta, gamma, theta, vega, status, source
            FROM fno_candles WHERE contract_id = :c AND timeframe = :tf AND candle_timestamp BETWEEN :a AND :b
        """), {"c": contract_id, "tf": timeframe, "a": lo, "b": hi}).fetchall()
        return {r[0]: r for r in rows}

    @staticmethod
    def classify(new: dict, stored) -> str:
        """Pure decision: 'insert' | 'duplicate' | 'fill' | 'conflict' (see module docstring)."""
        if stored is None:
            return "insert"
        s_ohlcv = (stored[1], stored[2], stored[3], stored[4], int(stored[5]))
        n_ohlcv = (new["open"], new["high"], new["low"], new["close"], new["volume"])
        s_status, s_source = stored[12], stored[13]
        if s_status == "CLOSED":
            if s_source == "FYERS_LIVE" and new["source"] == "FYERS_HISTORICAL" and new["status"] == "CLOSED":
                return "fill"                 # authoritative history supersedes the provisional live candle
            if s_source == "FYERS_HISTORICAL" and new["source"] == "FYERS_LIVE":
                return "duplicate"            # live never touches stored history; not a conflict
            if s_ohlcv != n_ohlcv:
                return "conflict"
            s_opt = dict(zip(("oi", "iv", "delta", "gamma", "theta", "vega"), stored[6:12]))
            return "fill" if any(s_opt[k] is None and new[k] is not None for k in s_opt) else "duplicate"
        # stored OPEN
        s_opt = dict(zip(("oi", "iv", "delta", "gamma", "theta", "vega"), stored[6:12]))
        same = s_ohlcv == n_ohlcv and all(new[k] is None or s_opt[k] == new[k] for k in s_opt)
        if new["status"] == "OPEN" and same:
            return "duplicate"
        return "fill"

    def upsert_candles(self, candles: Iterable[FnoCandle]) -> WriteResult:
        result = WriteResult()
        groups: dict = {}
        for c in candles:
            groups.setdefault((c.contract_id, c.timeframe), []).append(c)
        for (cid, tf), items in groups.items():
            for start in range(0, len(items), _BATCH):
                result.merge(self._upsert_group(cid, tf, items[start:start + _BATCH]))
        return result

    def _upsert_group(self, cid: int, tf: str, items: list) -> WriteResult:
        res = WriteResult()
        rows = [_row_values(c) for c in items]
        lo, hi = min(r["ts"] for r in rows), max(r["ts"] for r in rows)
        with self.engine.begin() as conn:
            stored = self._existing(conn, cid, tf, lo, hi)
            to_send, seen_keys = [], set()
            for r in rows:
                if r["ts"] in seen_keys:            # duplicate inside the batch itself
                    res.duplicate += 1
                    continue
                seen_keys.add(r["ts"])
                verdict = self.classify(r, stored.get(r["ts"]))
                if verdict == "insert":
                    res.inserted += 1; to_send.append(r)
                elif verdict == "fill":
                    res.filled += 1; to_send.append(r)
                    s_old = stored.get(r["ts"])
                    if s_old is not None and s_old[13] == "FYERS_LIVE" and s_old[12] == "CLOSED" and r["source"] == "FYERS_HISTORICAL":
                        res.superseded_live += 1               # only CLOSED live candles: OPEN partials are not "approximation error"
                        diff = [n for n, a, b in (("open", s_old[1], r["open"]), ("high", s_old[2], r["high"]), ("low", s_old[3], r["low"]),
                                                  ("close", s_old[4], r["close"]), ("volume", int(s_old[5]), r["volume"])) if a != b]
                        if diff:
                            res.superseded_changed += 1
                            for n in diff:
                                res.superseded_fields[n] = res.superseded_fields.get(n, 0) + 1
                elif verdict == "duplicate":
                    res.duplicate += 1
                else:
                    res.conflicts += 1
                    if len(res.conflict_samples) < 20:
                        s = stored[r["ts"]]
                        res.conflict_samples.append({
                            "contract_id": cid, "timeframe": tf, "timestamp": str(r["ts"]),
                            "stored": [str(s[1]), str(s[2]), str(s[3]), str(s[4]), int(s[5])],
                            "incoming": [str(r["open"]), str(r["high"]), str(r["low"]), str(r["close"]), r["volume"]]})
            if to_send:
                conn.execute(_UPSERT_SQL, to_send)
        if res.conflicts:
            log.warning("fno_candles: %d conflicting CLOSED candle(s) NOT applied for contract %s %s", res.conflicts, cid, tf)
        return res

    def count_candles(self, contract_id: int, timeframe: str, from_dt: datetime.datetime, to_dt: datetime.datetime) -> int:
        with self.engine.connect() as conn:
            return conn.execute(text("""
                SELECT COUNT(*) FROM fno_candles
                WHERE contract_id = :c AND timeframe = :tf AND candle_timestamp BETWEEN :a AND :b
            """), {"c": contract_id, "tf": timeframe, "a": from_dt, "b": to_dt}).scalar()

    def verify_candles_present(self, candles: list) -> bool:
        """Read-back check: every (contract, timeframe, timestamp) of `candles` exists in MySQL."""
        groups: dict = {}
        for c in candles:
            groups.setdefault((c.contract_id, c.timeframe), set()).add(c.naive_ist())
        for (cid, tf), stamps in groups.items():
            lo, hi = min(stamps), max(stamps)
            with self.engine.connect() as conn:
                have = {r[0] for r in conn.execute(text("""
                    SELECT candle_timestamp FROM fno_candles
                    WHERE contract_id = :c AND timeframe = :tf AND candle_timestamp BETWEEN :a AND :b
                """), {"c": cid, "tf": tf, "a": lo, "b": hi})}
            if not stamps <= have:
                return False
        return True

    def accepted_candles(self, candles: Iterable[FnoCandle]) -> list:
        """Return canonical MySQL rows for the keys represented by ``candles``.

        Upserts can reject conflicting CLOSED values or preserve authoritative
        history over live data. Downstream stores must therefore mirror the
        database read-back, never the incoming objects.
        """
        groups: dict = {}
        for candle in candles:
            groups.setdefault((candle.contract_id, candle.timeframe), set()).add(candle.naive_ist())
        accepted = []
        for (contract_id, timeframe), stamps in groups.items():
            if not stamps:
                continue
            first, last = min(stamps), max(stamps)
            stored = self.fetch_candles(contract_id, timeframe, first.date(), last.date())
            accepted.extend(c for c in stored if c.naive_ist() in stamps)
        accepted.sort(key=lambda c: (c.contract_id, c.timeframe, c.naive_ist()))
        return accepted

    def fetch_candles(self, contract_id: int, timeframe: str, from_date: datetime.date, to_date: datetime.date) -> list:
        with self.engine.connect() as conn:
            rows = conn.execute(text("""
                SELECT candle_timestamp, open, high, low, close, volume, oi, iv, delta, gamma, theta, vega, source, status
                FROM fno_candles WHERE contract_id = :c AND timeframe = :tf
                  AND candle_timestamp >= :a AND candle_timestamp < :b ORDER BY candle_timestamp
            """), {"c": contract_id, "tf": timeframe, "a": datetime.datetime.combine(from_date, datetime.time.min),
                   "b": datetime.datetime.combine(to_date + datetime.timedelta(days=1), datetime.time.min)}).fetchall()
        return [FnoCandle(contract_id=contract_id, timeframe=timeframe, timestamp=r[0].replace(tzinfo=IST),
                          open=r[1], high=r[2], low=r[3], close=r[4], volume=int(r[5]),
                          oi=None if r[6] is None else int(r[6]), iv=r[7], delta=r[8], gamma=r[9], theta=r[10],
                          vega=r[11], source=r[12], status=r[13]) for r in rows]

    def daily_candle_counts(self, contract_id: int, timeframe: str, from_date: datetime.date, to_date: datetime.date) -> dict:
        with self.engine.connect() as conn:
            rows = conn.execute(text("""
                SELECT DATE(candle_timestamp), COUNT(*) FROM fno_candles
                WHERE contract_id = :c AND timeframe = :tf AND candle_timestamp >= :a AND candle_timestamp < :b
                GROUP BY DATE(candle_timestamp)
            """), {"c": contract_id, "tf": timeframe, "a": datetime.datetime.combine(from_date, datetime.time.min),
                   "b": datetime.datetime.combine(to_date + datetime.timedelta(days=1), datetime.time.min)}).fetchall()
        return {r[0]: int(r[1]) for r in rows}

    def daily_counts_all(self, timeframe: str, from_date: Optional[datetime.date] = None,
                         to_date: Optional[datetime.date] = None) -> dict:
        """{(contract_id, date): row_count} for one timeframe, computed server-side."""
        where, p = ["timeframe = :tf"], {"tf": timeframe}
        if from_date:
            where.append("candle_timestamp >= :a"); p["a"] = datetime.datetime.combine(from_date, datetime.time.min)
        if to_date:
            where.append("candle_timestamp < :b"); p["b"] = datetime.datetime.combine(to_date + datetime.timedelta(days=1), datetime.time.min)
        with self.engine.connect() as conn:
            rows = conn.execute(text("SELECT contract_id, DATE(candle_timestamp), COUNT(*) FROM fno_candles WHERE "
                                     + " AND ".join(where) + " GROUP BY contract_id, DATE(candle_timestamp)"), p).fetchall()
        return {(r[0], r[1]): int(r[2]) for r in rows}

    def all_checkpoint_ranges(self, status: Optional[str] = None) -> list:
        sql = "SELECT contract_id, job_type, timeframe, range_from, range_to, status FROM fno_checkpoint_ranges"
        p = {}
        if status:
            sql += " WHERE status = :s"; p["s"] = status
        with self.engine.connect() as conn:
            return [tuple(r) for r in conn.execute(text(sql), p).fetchall()]

    def contract_meta(self, ids) -> dict:
        ids = list(ids)
        if not ids:
            return {}
        ph = ",".join(f":i{k}" for k in range(len(ids)))
        with self.engine.connect() as conn:
            rows = conn.execute(text(f"SELECT id, underlying, expiry FROM fno_instruments WHERE id IN ({ph})"),
                                {f"i{k}": v for k, v in enumerate(ids)}).fetchall()
        return {r[0]: (r[1], r[2]) for r in rows}

    # ----------------------------------------------------------- checkpoints
    def get_checkpoint_ranges(self, contract_id: int, job_type: str, timeframe: str, conn=None) -> list:
        sql = text("""SELECT range_from, range_to, status FROM fno_checkpoint_ranges
                      WHERE contract_id = :c AND job_type = :j AND timeframe = :tf ORDER BY range_from""")
        params = {"c": contract_id, "j": job_type, "tf": timeframe}
        if conn is not None:
            return [tuple(r) for r in conn.execute(sql, params).fetchall()]
        with self.engine.connect() as c2:
            return [tuple(r) for r in c2.execute(sql, params).fetchall()]

    def add_checkpoint_range(self, contract_id: int, job_type: str, timeframe: str, range_from: datetime.date,
                             range_to: datetime.date, status: str, error: Optional[str] = None) -> list:
        """Marks [range_from, range_to] with `status`, merging with neighbours. Returns the resulting ranges.
        Callers must only pass VERIFIED/NO_DATA after every enabled store has verified the write."""
        now = _now_ist()
        with self.engine.begin() as conn:
            rows = conn.execute(text("""
                SELECT id, range_from, range_to, status, retry_count, last_error FROM fno_checkpoint_ranges
                WHERE contract_id = :c AND job_type = :j AND timeframe = :tf FOR UPDATE
            """), {"c": contract_id, "j": job_type, "tf": timeframe}).fetchall()
            old = {(r[1], r[2], r[3]): r for r in rows}
            failed_old = [(r[1], r[2], r[4]) for r in rows if r[3] == R_FAILED]
            new_set = rng.apply_range([(r[1], r[2], r[3]) for r in rows], range_from, range_to, status)
            keep_ids = set()
            to_insert = []
            for a, b, s in new_set:
                match = old.get((a, b, s))
                touched = not (b < range_from or a > range_to)
                if match is not None and not touched:
                    keep_ids.add(match[0])
                else:
                    to_insert.append((a, b, s))
            for r in rows:
                if r[0] not in keep_ids:
                    conn.execute(text("DELETE FROM fno_checkpoint_ranges WHERE id = :i"), {"i": r[0]})
            for a, b, s in to_insert:
                is_fail = s == R_FAILED
                retries = 0
                if is_fail:
                    retries = max([rc for fa, fb, rc in failed_old if fa <= b and fb >= a] or [0])
                    if status == R_FAILED and not (b < range_from or a > range_to):
                        retries += 1                      # this piece was (re)marked failed just now
                conn.execute(text("""
                    INSERT INTO fno_checkpoint_ranges
                        (contract_id, job_type, timeframe, range_from, range_to, status, verified_at, retry_count, last_error)
                    VALUES (:c, :j, :tf, :a, :b, :s, :v, :rc, :err)
                """), {"c": contract_id, "j": job_type, "tf": timeframe, "a": a, "b": b, "s": s,
                       "v": None if is_fail else now, "rc": retries,
                       "err": (error or "")[:500] if is_fail else None})
            return new_set

    def missing_ranges(self, contract_id: int, job_type: str, timeframe: str, want_from: datetime.date,
                       want_to: datetime.date) -> list:
        """Days in [want_from, want_to] not yet VERIFIED / NO_DATA. FAILED and EXPIRED_UNRECOVERABLE
        days are still 'missing' here; the planner decides whether they are retryable."""
        return rng.missing_days(want_from, want_to, self.get_checkpoint_ranges(contract_id, job_type, timeframe))

    def count_checkpoint_ranges(self, contract_ids: Optional[list] = None, job_type: Optional[str] = None,
                                timeframe: Optional[str] = None) -> int:
        where, p = self._ckpt_where(contract_ids, job_type, timeframe)
        with self.engine.connect() as conn:
            return conn.execute(text(f"SELECT COUNT(*) FROM fno_checkpoint_ranges WHERE {where}"), p).scalar()

    @staticmethod
    def _ckpt_where(contract_ids, job_type, timeframe):
        where, p = ["1=1"], {}
        if contract_ids is not None:
            if not contract_ids:
                return "1=0", {}
            ph = ",".join(f":c{i}" for i in range(len(contract_ids)))
            where.append(f"contract_id IN ({ph})"); p.update({f"c{i}": v for i, v in enumerate(contract_ids)})
        if job_type:
            where.append("job_type = :j"); p["j"] = job_type
        if timeframe:
            where.append("timeframe = :tf"); p["tf"] = timeframe
        return " AND ".join(where), p

    def reset_checkpoints(self, contract_ids: Optional[list] = None, job_type: Optional[str] = None,
                          timeframe: Optional[str] = None) -> int:
        """Deletes checkpoint ranges ONLY (fno_checkpoint_ranges). Never touches candles."""
        where, p = self._ckpt_where(contract_ids, job_type, timeframe)
        with self.engine.begin() as conn:
            return conn.execute(text(f"DELETE FROM fno_checkpoint_ranges WHERE {where}"), p).rowcount

    def count_candles_for_delete(self, contract_ids: list, timeframe: Optional[str] = None) -> int:
        if not contract_ids:
            return 0
        ph = ",".join(f":c{i}" for i in range(len(contract_ids)))
        p = {f"c{i}": v for i, v in enumerate(contract_ids)}
        sql = f"SELECT COUNT(*) FROM fno_candles WHERE contract_id IN ({ph})"
        if timeframe:
            sql += " AND timeframe = :tf"; p["tf"] = timeframe
        with self.engine.connect() as conn:
            return conn.execute(text(sql), p).scalar()

    def delete_candles(self, contract_ids: list, timeframe: Optional[str] = None) -> int:
        """Deletes candles ONLY (fno_candles). Never touches checkpoints."""
        if not contract_ids:
            return 0
        ph = ",".join(f":c{i}" for i in range(len(contract_ids)))
        p = {f"c{i}": v for i, v in enumerate(contract_ids)}
        sql = f"DELETE FROM fno_candles WHERE contract_id IN ({ph})"
        if timeframe:
            sql += " AND timeframe = :tf"; p["tf"] = timeframe
        with self.engine.begin() as conn:
            return conn.execute(text(sql), p).rowcount

    # --------------------------------------------------------- harvest state
    def upsert_harvest_state(self, contract_id: int, expiry: datetime.date, priority: int, status: str,
                             last_harvested_date: Optional[datetime.date] = None,
                             next_due: Optional[datetime.date] = None) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO fno_harvest_state (contract_id, expiry, last_harvested_date, next_due, priority, status)
                VALUES (:c, :e, :l, :n, :p, :s)
                ON DUPLICATE KEY UPDATE expiry = VALUES(expiry), priority = VALUES(priority), status = VALUES(status),
                    last_harvested_date = COALESCE(VALUES(last_harvested_date), last_harvested_date),
                    next_due = VALUES(next_due)
            """), {"c": contract_id, "e": expiry, "l": last_harvested_date, "n": next_due, "p": priority, "s": status})

    def harvest_tracked_ids(self) -> set:
        with self.engine.connect() as conn:
            return {r[0] for r in conn.execute(text("SELECT contract_id FROM fno_harvest_state"))}

    def harvest_queue(self, limit: int = 100) -> list:
        with self.engine.connect() as conn:
            rows = conn.execute(text("""
                SELECT h.contract_id, i.fyers_symbol, h.expiry, h.priority, h.status, h.last_harvested_date
                FROM fno_harvest_state h JOIN fno_instruments i ON i.id = h.contract_id
                WHERE h.status IN ('PENDING','FAILED') ORDER BY h.priority, h.expiry, i.fyers_symbol LIMIT :l
            """), {"l": limit}).fetchall()
        return [tuple(r) for r in rows]

    # -------------------------------------------------------- chain snapshots
    def contracts_by_symbol(self, symbols) -> dict:
        """{symbol: (contract_id, expiry)} for symbols that exist in the contract master (never inserted/guessed here)."""
        symbols, out = list(symbols), {}
        for s in range(0, len(symbols), 500):
            part = symbols[s:s + 500]
            ph = ",".join(f":s{i}" for i in range(len(part)))
            with self.engine.connect() as conn:
                for r in conn.execute(text(f"SELECT fyers_symbol, id, expiry FROM fno_instruments WHERE fyers_symbol IN ({ph})"),
                                      {f"s{i}": v for i, v in enumerate(part)}):
                    out[r[0]] = (r[1], r[2])
        return out

    def insert_chain_snapshot(self, batch_id: str, underlying: str, captured_at: datetime.datetime, rows: list) -> int:
        """rows: dicts with contract_id, chain_expiry + chain fields. One batch = one call; UNIQUE(batch_id, contract_id)."""
        if not rows:
            return 0
        payload = [{**r, "batch": batch_id, "und": underlying, "cap": captured_at} for r in rows]
        with self.engine.begin() as conn:
            conn.execute(text("""
                INSERT IGNORE INTO fno_option_chain_snapshots
                    (batch_id, underlying, captured_at, chain_expiry, contract_id, strike, side, ltp, bid, ask,
                     volume, oi, oi_change, iv, delta, gamma, theta, vega)
                VALUES (:batch, :und, :cap, :chain_expiry, :contract_id, :strike, :side, :ltp, :bid, :ask,
                        :volume, :oi, :oi_change, :iv, :delta, :gamma, :theta, :vega)"""), payload)
            return conn.execute(text("SELECT COUNT(*) FROM fno_option_chain_snapshots WHERE batch_id = :b"), {"b": batch_id}).scalar()

    def chain_snapshot_rows(self, batch_id: str) -> list:
        with self.engine.connect() as conn:
            return [tuple(r) for r in conn.execute(text("""SELECT contract_id, strike, side, ltp, bid, ask, volume, oi, oi_change,
                iv, delta, captured_at, chain_expiry FROM fno_option_chain_snapshots WHERE batch_id = :b ORDER BY strike, side"""), {"b": batch_id})]

    def save_quality_result(self, check_name: str, scope: str, status: str, details: dict) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("INSERT INTO fno_data_quality_results (check_name, scope, status, details) VALUES (:c, :s, :st, :d)"),
                         {"c": check_name, "s": scope[:200], "st": status, "d": json.dumps(details, default=str)})

    # -------------------------------------------------------------- manifest
    def manifest_begin(self, relative_path: str, dataset: str, timeframe: Optional[str], partition_key: str,
                       row_count: int, job_id: Optional[int] = None) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO fno_storage_manifest (relative_path, dataset, timeframe, partition_key, row_count, status, job_id)
                VALUES (:p, :d, :tf, :k, :n, 'WRITING', :j)
                ON DUPLICATE KEY UPDATE status = 'WRITING', row_count = VALUES(row_count), job_id = VALUES(job_id), note = NULL
            """), {"p": relative_path, "d": dataset, "tf": timeframe, "k": partition_key, "n": row_count, "j": job_id})

    def manifest_verify(self, relative_path: str, min_ts, max_ts, row_count: int, checksum: str,
                        schema_version: int = 1) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("""
                UPDATE fno_storage_manifest SET status = 'VERIFIED', min_timestamp = :a, max_timestamp = :b,
                    row_count = :n, checksum = :h, schema_version = :v, note = NULL WHERE relative_path = :p
            """), {"a": min_ts, "b": max_ts, "n": row_count, "h": checksum, "v": schema_version, "p": relative_path})

    def manifest_quarantine(self, relative_path: str, note: str) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("UPDATE fno_storage_manifest SET status = 'QUARANTINED', note = :n WHERE relative_path = :p"),
                         {"n": note[:300], "p": relative_path})

    def manifest_get(self, relative_path: str) -> Optional[dict]:
        with self.engine.connect() as conn:
            r = conn.execute(text("""SELECT relative_path, dataset, timeframe, partition_key, min_timestamp, max_timestamp,
                row_count, schema_version, checksum, status, job_id, note FROM fno_storage_manifest
                WHERE relative_path = :p"""), {"p": relative_path}).fetchone()
        return None if r is None else dict(zip(("relative_path", "dataset", "timeframe", "partition_key", "min_timestamp",
                                               "max_timestamp", "row_count", "schema_version", "checksum", "status",
                                               "job_id", "note"), r))

    def manifest_list(self, dataset: Optional[str] = None, status: Optional[str] = None, limit: int = 200,
                      offset: int = 0) -> list:
        where, p = ["1=1"], {"l": int(limit), "o": int(offset)}
        if dataset:
            where.append("dataset = :d"); p["d"] = dataset
        if status:
            where.append("status = :s"); p["s"] = status
        with self.engine.connect() as conn:
            rows = conn.execute(text("""SELECT relative_path, dataset, timeframe, partition_key, min_timestamp, max_timestamp,
                row_count, checksum, status, note FROM fno_storage_manifest WHERE """ + " AND ".join(where) +
                " ORDER BY relative_path LIMIT :l OFFSET :o"), p).fetchall()
        return [dict(zip(("relative_path", "dataset", "timeframe", "partition_key", "min_timestamp", "max_timestamp",
                          "row_count", "checksum", "status", "note"), r)) for r in rows]

    def manifest_delete(self, relative_path: str) -> None:
        with self.engine.begin() as conn:
            conn.execute(text("DELETE FROM fno_storage_manifest WHERE relative_path = :p"), {"p": relative_path})

    def chain_counts_by_day(self) -> dict:
        with self.engine.connect() as conn:
            return {(r[0], r[1]): int(r[2]) for r in conn.execute(text(
                "SELECT underlying, DATE(captured_at), COUNT(*) FROM fno_option_chain_snapshots GROUP BY underlying, DATE(captured_at)"))}

    def chain_rows_for_day(self, underlying: str, day: datetime.date) -> list:
        cols = ("batch_id", "underlying", "captured_at", "chain_expiry", "contract_id", "strike", "side", "ltp", "bid", "ask",
                "volume", "oi", "oi_change", "iv", "delta", "gamma", "theta", "vega")
        with self.engine.connect() as conn:
            rows = conn.execute(text(f"SELECT {', '.join(cols)} FROM fno_option_chain_snapshots WHERE underlying = :u "
                                     "AND captured_at >= :a AND captured_at < :b"),
                                {"u": underlying, "a": datetime.datetime.combine(day, datetime.time.min),
                                 "b": datetime.datetime.combine(day + datetime.timedelta(days=1), datetime.time.min)}).fetchall()
        return [dict(zip(cols, r)) for r in rows]
