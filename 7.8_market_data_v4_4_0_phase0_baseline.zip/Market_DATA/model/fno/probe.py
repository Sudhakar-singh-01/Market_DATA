"""
model/fno/probe.py
P0 probe: run by the USER with a real FYERS token (`python main.py fno-probe`). It checks what
the FNO design only ASSUMES and writes docs/FNO_API_FINDINGS.md from the real responses.

Rules: never invent a result; a check that was not run (or could not run) is NOT_VERIFIED /
SKIPPED, never "confirmed"; tokens and secrets are scrubbed from everything written.
Statuses: CONFIRMED | NOT_CONFIRMED | ERROR | SKIPPED.
Every REST call goes through the shared rate limiter via the client the caller passes in.
"""
import datetime
import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from model.fno import symbol_master as sm
from model.fno.models import CATEGORY_FUTURES, CATEGORY_OPTIONS

log = logging.getLogger("market_data.fno.probe")

CONFIRMED, NOT_CONFIRMED, ERROR, SKIPPED = "CONFIRMED", "NOT_CONFIRMED", "ERROR", "SKIPPED"
_SECRET_WORDS = ("token", "secret", "password", "authorization", "api_key", "apikey")
GREEK_NAMES = ("delta", "gamma", "theta", "vega", "iv")


@dataclass
class ProbeResult:
    check: str
    status: str
    summary: str
    evidence: dict = field(default_factory=dict)


def scrub(obj, depth=0):
    """Removes secret-looking keys and truncates big structures so evidence stays readable and safe."""
    if depth > 6:
        return "..."
    if isinstance(obj, dict):
        return {k: ("***" if any(w in str(k).lower() for w in _SECRET_WORDS) else scrub(v, depth + 1))
                for k, v in list(obj.items())[:40]}
    if isinstance(obj, (list, tuple)):
        if all(isinstance(v, (str, int, float, bool, type(None))) for v in obj):
            return list(obj)[:40] + (["..."] if len(obj) > 40 else [])      # candle rows / field-name lists stay whole
        return [scrub(v, depth + 1) for v in list(obj)[:5]] + (["..."] if len(obj) > 5 else [])
    if isinstance(obj, str) and len(obj) > 300:
        return obj[:300] + "..."
    return obj


def _shape(resp) -> dict:
    if not isinstance(resp, dict):
        return {"type": type(resp).__name__}
    return {"top_level_keys": sorted(resp.keys()), "s": resp.get("s"), "code": resp.get("code"),
            "message": resp.get("message")}


class FnoProbe:
    def __init__(self, client, settings, http_get: Callable, today: Optional[datetime.date] = None,
                 sleep=time.sleep, ws_factory: Optional[Callable] = None, raw_client=None):
        self.client, self.s, self.http_get = client, settings, http_get
        self.today = today or datetime.date.today()
        self._sleep, self.ws_factory = sleep, ws_factory
        self.raw_client = raw_client if raw_client is not None else client      # un-limited, for the rate-limit burst only
        self.report = None
        self.contracts = []
        self.throttled_retries = 0

    RATE_CODES = (-360, 429, -429)

    def _throttled(self, resp) -> bool:
        if not isinstance(resp, dict):
            return False
        msg = str(resp.get("message", "")).lower()
        return resp.get("code") in self.RATE_CODES or "requests/second" in msg or "plan limit" in msg

    def _retry(self, call, tries: int = 6):
        """Probe evidence must never be throttling noise: wait and retry on rate-limit answers."""
        resp = None
        for _ in range(tries):
            resp = call()
            if not self._throttled(resp):
                return resp
            self.throttled_retries += 1
            self._sleep(1.2)
        return resp

    # ------------------------------------------------------------- 1. symbol master
    def check_symbol_master(self) -> ProbeResult:
        url = self.s.symbol_master.url
        try:
            resp = self.http_get(url, self.s.symbol_master.timeout_seconds)
        except Exception as exc:
            return ProbeResult("symbol_master", ERROR, f"download failed: {type(exc).__name__}: {exc}", {"url": url})
        ev = {"url": url, "http_status": getattr(resp, "status_code", None), "bytes": len(getattr(resp, "text", "") or "")}
        if ev["http_status"] != 200:
            return ProbeResult("symbol_master", NOT_CONFIRMED, f"HTTP {ev['http_status']}", ev)
        text = resp.text
        fmt = self.s.symbol_master.format
        try:
            if fmt == "csv":
                lines = [ln for ln in text.splitlines() if ln.strip()][:3]
                ev["first_rows_raw"] = [ln[:400] for ln in lines]
                ev["column_counts_first_rows"] = [len(ln.split(",")) for ln in lines]
            else:
                data = json.loads(text)
                first = next(iter(data.items())) if isinstance(data, dict) else (0, data[0])
                ev["first_entry"] = {"key": first[0], "fields": sorted(first[1].keys()) if isinstance(first[1], dict) else str(first[1])[:200]}
            report = sm.parse_master(text, fmt, self.s.symbol_master.csv_columns)
        except Exception as exc:
            ev["error"] = f"{type(exc).__name__}: {exc}"
            return ProbeResult("symbol_master", ERROR, "downloaded but could not be parsed with the configured format/columns", ev)
        self.contracts = report.contracts
        by_und = {}
        for c in report.contracts:
            by_und.setdefault(c.underlying, 0); by_und[c.underlying] += 1
        ev.update({"parsed_rows": report.total_rows, "contracts_parsed": len(report.contracts), "skipped": report.skipped,
                   "categories": {k: sum(1 for c in report.contracts if c.category == k) for k in (CATEGORY_FUTURES, CATEGORY_OPTIONS)},
                   "configured_underlyings_found": {u: by_und.get(u.upper(), 0) for u in self.s.universe.underlyings},
                   "sample": [vars(c) | {"expiry": str(c.expiry)} for c in report.contracts[:2]]})
        ok = bool(report.contracts) and sum(report.skipped.values()) <= 0.5 * max(1, report.total_rows) \
            and all(v > 0 for v in ev["configured_underlyings_found"].values())
        return ProbeResult("symbol_master", CONFIRMED if ok else NOT_CONFIRMED,
                           f"{len(report.contracts)} contracts parsed from {report.total_rows} rows with the CONFIGURED layout"
                           if ok else "configured layout did not yield the expected contracts; compare first_rows_raw with csv_columns", ev)

    # --------------------------------------------------------------------- helpers
    def _spot(self, underlying: str) -> Optional[float]:
        sym = self.s.universe.spot_symbols.get(underlying)
        if not sym:
            return None
        resp = self._retry(lambda: self.client.quotes(data={"symbols": sym}))
        try:
            d = resp["d"][0]
            return float((d.get("v") or d).get("lp"))
        except Exception:
            return None

    def _pick(self, category: str, underlying: str, spot: Optional[float] = None):
        pool = [c for c in self.contracts if c.underlying == underlying and c.category == category and c.expiry >= self.today]
        if not pool:
            return None
        exp = min(c.expiry for c in pool)
        pool = [c for c in pool if c.expiry == exp]
        if category == CATEGORY_OPTIONS and spot:
            pool = sorted((c for c in pool if c.option_type == "CE"), key=lambda c: abs(float(c.strike) - spot)) or pool
        return pool[0]

    def _history(self, symbol, d_from, d_to, extra=None):
        p = {"symbol": symbol, "resolution": "1", "date_format": "1", "range_from": d_from.isoformat(),
             "range_to": d_to.isoformat(), "cont_flag": "0"}
        p.update(extra or {})
        return self._retry(lambda: self.client.history(data=p))

    # ---------------------------------------------------- 2/3. history for future/option
    def check_history(self, category: str, underlying: str = "NIFTY") -> ProbeResult:
        name = f"history_{category.lower()}"
        try:
            spot = self._spot(underlying) if category == CATEGORY_OPTIONS else None
            c = self._pick(category, underlying, spot)
            if c is None:
                return ProbeResult(name, SKIPPED, "no active contract available from the symbol master (run check 1 first)")
            d_to, d_from = self.today, self.today - datetime.timedelta(days=5)
            plain = self._history(c.fyers_symbol, d_from, d_to)
            with_oi = self._history(c.fyers_symbol, d_from, d_to, {"oi_flag": "1"})
            ev = {"symbol": c.fyers_symbol, "spot_used": spot, "plain": _shape(plain), "with_oi_flag": _shape(with_oi)}
            candles = plain.get("candles") if isinstance(plain, dict) else None
            ev["plain"]["candle_count"] = len(candles or [])
            ev["plain"]["first_candle"] = (candles or [None])[0]
            oi_c = with_oi.get("candles") if isinstance(with_oi, dict) else None
            ev["with_oi_flag"]["candle_count"] = len(oi_c or [])
            ev["with_oi_flag"]["first_candle"] = (oi_c or [None])[0]
            oi_len, plain_len = len((oi_c or [[]])[0] or []), len((candles or [[]])[0] or [])
            ev["row_length_plain"], ev["row_length_with_oi_flag"] = plain_len, oi_len
            ev["oi_flag_adds_a_column"] = bool(oi_len and plain_len and oi_len > plain_len)
            spans, sample30 = {}, None
            for span in (30, 60, 100, 200):
                r = self._history(c.fyers_symbol, d_to - datetime.timedelta(days=span), d_to)
                if span == 30 and isinstance(r, dict):
                    sample30 = r.get("candles") or []
                spans[span] = {"s": r.get("s"), "code": r.get("code"), "message": r.get("message"),
                               "candles": len(r.get("candles") or [])} if isinstance(r, dict) else str(type(r))
                if isinstance(r, dict) and r.get("s") != "ok":
                    break
            ev["span_days_tested"] = spans
            single = {}
            last_day = d_to
            if sample30:
                try:
                    last_day = datetime.datetime.fromtimestamp(float(sample30[-1][0]), datetime.timezone(datetime.timedelta(hours=5, minutes=30))).date()
                except Exception:
                    pass
            ev["single_day_tested_date"] = str(last_day)                  # the last day that really has candles, not "today"
            for label, extra in (("plain", {}), ("with_oi_flag", {"oi_flag": "1"})):
                r1 = self._history(c.fyers_symbol, last_day, last_day, extra)
                cs = (r1.get("candles") or []) if isinstance(r1, dict) else []
                stamps = [row[0] for row in cs if row]
                single[label] = {"s": r1.get("s") if isinstance(r1, dict) else None, "rows": len(cs), "unique_timestamps": len(set(stamps)),
                                 "duplicate_rows": len(stamps) - len(set(stamps)), "first": cs[0] if cs else None, "last": cs[-1] if cs else None}
            ev["single_day_request"] = single
            ev["throttled_retries_so_far"] = self.throttled_retries
            ev["time_of_day"] = self._time_of_day(sample30 or [])
            ok = bool(candles)
            return ProbeResult(name, CONFIRMED if ok else NOT_CONFIRMED,
                               ("history works for an active contract; oi_flag adds a column: "
                                f"{ev['oi_flag_adds_a_column']}") if ok else "no candles returned (market closed / no trades / not allowed?)", ev)
        except Exception as exc:
            return ProbeResult(name, ERROR, f"{type(exc).__name__}: {exc}")

    def _time_of_day(self, candles: list) -> dict:
        """What hours do candles really cover? (decides the session window and any evening session)"""
        IST = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
        per_day, times = {}, []
        for row in candles:
            try:
                t = datetime.datetime.fromtimestamp(float(row[0]), IST)
            except Exception:
                continue
            per_day[t.date().isoformat()] = per_day.get(t.date().isoformat(), 0) + 1
            times.append(t.time())
        sess = self.s.session
        outside = sum(1 for t in times if not (sess.open <= t <= sess.last_minute))
        return {"candles": len(times), "first_time": str(min(times)) if times else None,
                "last_time": str(max(times)) if times else None,
                "outside_configured_session": outside,
                "candles_per_day": dict(sorted(per_day.items())[-8:]),
                "weekend_days_seen": sorted(d for d in per_day if datetime.date.fromisoformat(d).weekday() >= 5)}

    # --------------------------------------------------------------- 4. option chain
    def check_option_chain(self, underlying: str = "NIFTY") -> ProbeResult:
        sym = self.s.universe.spot_symbols.get(underlying)
        if not sym:
            return ProbeResult("option_chain", SKIPPED, f"no spot symbol configured for {underlying}")
        try:
            base = self._retry(lambda: self.client.optionchain(data={"symbol": sym, "strikecount": 5, "timestamp": ""}))
            greeks = self._retry(lambda: self.client.optionchain(data={"symbol": sym, "strikecount": 5, "timestamp": "", "greeks": "1"}))
            ev = {"symbol": sym, "base": _shape(base), "with_greeks_flag": _shape(greeks)}

            def entries(r):
                d = (r or {}).get("data") if isinstance(r, dict) else None
                return (d or {}).get("optionsChain") or []
            b, g = entries(base), entries(greeks)
            ev["entries_base"], ev["entries_greeks"] = len(b), len(g)
            ev["entry_keys_base"] = sorted(b[0].keys()) if b and isinstance(b[0], dict) else []
            ev["entry_keys_greeks"] = sorted(g[0].keys()) if g and isinstance(g[0], dict) else []
            ev["greek_fields_only_with_flag"] = sorted(set(ev["entry_keys_greeks"]) - set(ev["entry_keys_base"]))
            nested = sorted({k for e in g if isinstance(e, dict) and isinstance(e.get("greeks"), dict) for k in e["greeks"]})
            ev["nested_greeks_keys"] = nested                               # greeks arrive as a nested dict on option rows
            ev["greek_like_fields_in_flagged_response"] = [k for k in ev["entry_keys_greeks"] if any(n in k.lower() for n in GREEK_NAMES)] + \
                [f"greeks.{k}" for k in nested]
            ev["sample_entries_base"] = [scrub(e) for e in b[:3]]
            ev["sample_entries_with_greeks_flag"] = [scrub(e) for e in g[:3]]
            ev["entries_without_option_type"] = sum(1 for e in b if isinstance(e, dict) and not e.get("option_type"))
            raw_exp = ((base.get("data") or {}).get("expiryData") if isinstance(base, dict) else None)
            from model.fno.chain import parse_expiry_data
            ev["expiry_data_sample"] = scrub(raw_exp[:3]) if isinstance(raw_exp, list) else scrub(raw_exp)
            ev["expiry_data_entries"] = len(raw_exp) if isinstance(raw_exp, list) else None
            ev["expiry_data_parsed_by_our_parser"] = len(parse_expiry_data(raw_exp)) if isinstance(raw_exp, list) else 0
            ev["top_level_data_keys"] = sorted((base.get("data") or {}).keys()) if isinstance(base, dict) else []
            ev["captured_time_field_present"] = any("time" in k.lower() or "stamp" in k.lower() for k in ev["entry_keys_base"])
            mx = {}
            for n in (50, 51):
                r = self._retry(lambda n=n: self.client.optionchain(data={"symbol": sym, "strikecount": n, "timestamp": ""}))
                mx[n] = {"s": r.get("s"), "code": r.get("code"), "message": r.get("message"), "entries": len(entries(r))}
            ev["strikecount_limit_test"] = mx
            return ProbeResult("option_chain", CONFIRMED if b else NOT_CONFIRMED,
                               f"chain returned {len(b)} entries; greeks fields seen: {ev['greek_like_fields_in_flagged_response'] or 'none'}"
                               if b else "no chain entries returned", ev)
        except Exception as exc:
            return ProbeResult("option_chain", ERROR, f"{type(exc).__name__}: {exc}")

    # ------------------------------------------------------- 5. expired symbols
    def check_expired(self, expired_symbol: Optional[str], underlying: str = "NIFTY") -> ProbeResult:
        ev = {}
        if expired_symbol:
            known = next((c for c in self.contracts if c.fyers_symbol == expired_symbol), None)
            ev["symbol_in_current_master"] = known is not None
            if known is not None and known.expiry >= self.today:
                ev["listed_expiry"] = str(known.expiry)
                return ProbeResult("expired_contracts", ERROR,
                                   f"INVALID TEST: {expired_symbol} is still listed in the symbol master with expiry {known.expiry} "
                                   f"(today is {self.today}), so it has NOT expired. Use a symbol whose expiry date has passed "
                                   f"(SELECT fyers_symbol, expiry FROM fno_instruments WHERE expiry < CURDATE()).", ev)
            if known is None and not self.contracts:
                ev["expiry_verification"] = "symbol master unavailable: could not verify that the symbol is really expired"
        try:
            if expired_symbol:
                r = self._history(expired_symbol, self.today - datetime.timedelta(days=10), self.today)
                ev["expired_symbol"] = expired_symbol; ev["history_on_expired_symbol"] = _shape(r)
                ev["expired_history_candles"] = len((r or {}).get("candles") or []) if isinstance(r, dict) else 0
            # The installed SDK exposes /history/fno/expired/*; record what they really answer.
            sym = self.s.universe.spot_symbols.get(underlying)
            ev["sdk_has_expiry_dates_method"] = hasattr(self.client, "expiry_dates")
            ev["sdk_has_fno_historical_data_method"] = hasattr(self.client, "fno_historical_data")
            if sym and ev["sdk_has_expiry_dates_method"]:
                r2 = self.client.expiry_dates(data={"symbol": sym, "date_format": 1,
                                                    "range_from": (self.today - datetime.timedelta(days=60)).isoformat(),
                                                    "range_to": self.today.isoformat()})
                ev["sdk_expiry_dates_endpoint"] = {"shape": _shape(r2), "sample": scrub(r2.get("data") if isinstance(r2, dict) else None)}
        except Exception as exc:
            ev["error"] = f"{type(exc).__name__}: {exc}"
        if not expired_symbol:
            return ProbeResult("expired_contracts", SKIPPED if "error" not in ev else ERROR,
                               "no --expired-symbol given, so the -300 assumption is untested. Pass a recently expired real "
                               "symbol (copy one from an old fno_instruments row) to test the -300 assumption.", ev)
        ev["note"] = ("symbol is absent from today's master (consistent with expired); its exact expiry date cannot be proven from the "
                      "master alone, so check it yourself" if not ev.get("symbol_in_current_master") else "")
        got_300 = (ev.get("history_on_expired_symbol") or {}).get("code") == -300
        has_data = ev.get("expired_history_candles", 0) > 0
        if has_data:
            return ProbeResult("expired_contracts", NOT_CONFIRMED,
                               "expired symbol DID return candles: the 'no history after expiry' assumption is WRONG for this account; "
                               "review expired_history.enabled in config", ev)
        return ProbeResult("expired_contracts", CONFIRMED if got_300 else NOT_CONFIRMED,
                           "expired symbol rejected with -300 as assumed" if got_300 else "expired symbol returned no data but not code -300 (see evidence)", ev)

    # ---------------------------------------------------------- 6. WebSocket limit
    def check_ws_limit(self, steps=(50, 100, 200, 500, 1000, 2000, 5000), wait_seconds: float = 4.0) -> ProbeResult:
        if self.ws_factory is None:
            return ProbeResult("websocket_limit", SKIPPED, "not run (opt in with --ws-limit; needs live market hours)")
        syms = [c.fyers_symbol for c in self.contracts if c.expiry >= self.today]
        if len(syms) < steps[0]:
            return ProbeResult("websocket_limit", SKIPPED, f"only {len(syms)} active symbols available")
        events, lock = [], threading.Lock()
        def on_msg(m):
            with lock: events.append(scrub(m) if isinstance(m, dict) else str(m)[:200])
        sock = self.ws_factory(on_msg)
        results, last_ok, first_fail = [], 0, None
        try:
            sock.connect(); self._sleep(wait_seconds)
            subscribed = 0
            for n in steps:
                if n > len(syms):
                    results.append({"requested_total": n, "note": "not enough symbols"}); break
                with lock: events.clear()
                sock.subscribe(syms[subscribed:n]); subscribed = n
                self._sleep(wait_seconds)
                with lock: snap = list(events)
                err = [e for e in snap if isinstance(e, dict) and (e.get("code") == -351 or "limit" in str(e.get("message", "")).lower())]
                results.append({"requested_total": n, "limit_error": bool(err), "messages_seen": len(snap), "sample": snap[:2]})
                if err:
                    first_fail = n; break
                last_ok = n
        finally:
            try: sock.close()
            except Exception: pass
        ev = {"steps": results, "highest_total_without_error": last_ok, "first_total_with_limit_error": first_fail}
        return ProbeResult("websocket_limit", CONFIRMED if first_fail else NOT_CONFIRMED,
                           f"limit error (-351) first seen at {first_fail} symbols; last clean total {last_ok}" if first_fail
                           else f"no limit error up to {last_ok} symbols (real limit is at least that; true ceiling NOT found)", ev)

    # ---------------------------------------------------------- 7. rate-limit behaviour
    def check_rate_limit(self, burst: int = 15) -> ProbeResult:
        times, outcomes = [], []
        t0 = time.monotonic()
        for _ in range(burst):
            try:
                r = self.raw_client.get_profile()
                outcomes.append({"s": r.get("s"), "code": r.get("code")} if isinstance(r, dict) else "non-dict")
            except Exception as exc:
                outcomes.append(f"{type(exc).__name__}")
            times.append(round(time.monotonic() - t0, 3))
        throttled = [o for o in outcomes if isinstance(o, dict) and (o.get("code") in (429, -429) or o.get("s") != "ok")]
        ev = {"burst": burst, "elapsed_seconds": times[-1], "throttled_responses": len(throttled), "sample_outcomes": outcomes[:20]}
        return ProbeResult("rate_limit", CONFIRMED if throttled else NOT_CONFIRMED,
                           f"{len(throttled)}/{burst} calls were refused in a {times[-1]}s burst" if throttled
                           else f"no refusals in a {burst}-call burst over {times[-1]}s: the 10/s figure was NOT reproduced by this small burst", ev)

    def run_all(self, expired_symbol=None, ws_limit=False, rate_limit=False) -> list:
        results = [self.check_symbol_master(), self.check_history(CATEGORY_FUTURES), self.check_history(CATEGORY_OPTIONS),
                   self.check_option_chain(), self.check_expired(expired_symbol)]
        results.append(self.check_ws_limit() if ws_limit else ProbeResult("websocket_limit", SKIPPED, "not run (opt in with --ws-limit)"))
        results.append(self.check_rate_limit() if rate_limit else ProbeResult("rate_limit", SKIPPED, "not run (opt in with --rate-limit)"))
        return results


def render_findings(results: list, generated_at: str, sdk_version: str = "unknown") -> str:
    by = {r.check: r for r in results}
    lines = ["# FNO API findings", "",
             f"Generated: {generated_at} (IST) by `python main.py fno-probe`. fyers-apiv3: {sdk_version}.", "",
             "Only checks that actually ran are reported as results. SKIPPED / NOT_CONFIRMED means **not verified** -- "
             "the FNO code keeps its conservative defaults for those items.", "",
             "| Check | Status | Summary |", "|---|---|---|"]
    for r in results:
        lines.append(f"| {r.check} | {r.status} | {r.summary.replace('|', '/')} |")
    lines += ["", "## Consequences for the FNO configuration", ""]
    def st(n): return by[n].status if n in by else SKIPPED
    lines.append("- `history.oi_flag`: " + ("leave **false** until `history_*` shows an extra column with the flag."
                 if not all(by.get(n) and by[n].evidence.get("oi_flag_adds_a_column") for n in ("history_futures", "history_options") if n in by and by[n].status == CONFIRMED) or st("history_futures") != CONFIRMED
                 else "the flag adds a column for the contracts tested; you may set it to true."))
    spans_ok = []
    for n in ("history_futures", "history_options"):
        if n in by and by[n].status == CONFIRMED:
            sp = by[n].evidence.get("span_days_tested", {})
            spans_ok.append(max([int(k) for k, v in sp.items() if isinstance(v, dict) and v.get("s") == "ok"] or [0]))
    lines.append("- `history.max_days_per_request`: " + (f"largest span that returned `ok` for every contract tested: {min(spans_ok)} days "
                 "(spans that failed with a rate-limit code are retried by the probe and are not evidence)." if spans_ok else "not tested; keep the default."))
    lines.append("- `subscriptions.max_subscriptions`: " + ("set below the first failing total." if st("websocket_limit") == CONFIRMED
                 else "keep the conservative default; the real ceiling is unknown."))
    lines.append("- `rate_limits`: keep the configured values (below the reported limits); the probe does not raise them.")
    lines.append("- Expired contracts: " + ("history after expiry is unavailable; capture-forward harvest is required." if st("expired_contracts") == CONFIRMED
                 else "NOT verified; keep `expired_history.enabled: false`. Newer SDKs (3.2.0) expose `/history/fno/expired/*`; see `sdk_has_expiry_dates_method` in the evidence for YOUR install."))
    lines += ["", "## Evidence", ""]
    for r in results:
        lines += [f"### {r.check} - {r.status}", "", r.summary, "", "```json", json.dumps(scrub(r.evidence), indent=2, default=str), "```", ""]
    return "\n".join(lines)


def render_not_run() -> str:
    return ("# FNO API findings\n\n**Status: probe NOT RUN yet.**\n\nNothing in this repository has been verified against the real FYERS API. "
            "Run `python main.py fno-probe --write-report` with a valid token (during market hours for best results) and this file will be "
            "replaced with the real results. Until then every FYERS limit in `config/fno_settings.yaml` is a conservative default, "
            "not a confirmed fact.\n\nOpen question: fyers-apiv3 3.2.0 exposes `/history/fno/expired/*` endpoints, "
            "which would contradict the assumption that expired contracts have no history. Whether your installed SDK has them is recorded by the probe.\n")
