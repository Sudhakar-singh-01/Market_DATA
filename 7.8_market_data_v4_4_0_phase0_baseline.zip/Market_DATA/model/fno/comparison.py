"""Compare persisted values, not only row counts or timestamp keys."""
from decimal import Decimal
import pandas as pd
from model.fno.parquet_store import COLUMNS, KEY


def frame_records(frame, columns=COLUMNS, keys=KEY):
    if frame is None:
        return []
    if any(c not in frame.columns for c in columns):
        raise ValueError("Missing storage columns")
    numeric = {"open":4,"high":4,"low":4,"close":4,"strike":4,"ltp":4,"bid":4,"ask":4,
               "iv":6,"delta":8,"gamma":8,"theta":8,"vega":8}
    def norm(k,v):
        if pd.isna(v): return None
        if k in numeric: return Decimal(str(v)).quantize(Decimal(1).scaleb(-numeric[k]))
        if k in ("contract_id","volume","oi","oi_change"): return int(v)
        if k in ("candle_timestamp","captured_at"): return pd.Timestamp(v).to_pydatetime()
        if k == "chain_expiry": return pd.Timestamp(v).date()
        return str(v)
    return [tuple(norm(k,r[k]) for k in columns) for _,r in frame.sort_values(keys).iterrows()]


def frames_equal(a,b,columns=COLUMNS,keys=KEY):
    return frame_records(a,columns,keys) == frame_records(b,columns,keys)
