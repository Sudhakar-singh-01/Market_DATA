"""
model/processing/models.py
Canonical internal market-data representation, shared by BOTH the
historical and live pipelines (spec Section 8-9: "the normalizer must
be reusable by both"). Neither historical.py nor websocket.py should
leak raw FYERS-specific structures past their own boundary -- normalizer.py
is the only place raw FYERS data is converted into these types.

Timezone policy (spec Section 8):
    All timestamps are timezone-AWARE datetimes in Asia/Kolkata, using
    Python's zoneinfo (not a fixed UTC+5:30 offset) so DST-less-but-
    correct IANA tz semantics are used consistently. This is a
    deliberate refinement over Part 1's design notes -- Asia/Kolkata
    has no DST, so in practice this behaves identically to a fixed
    +05:30 offset, but using zoneinfo is the technically correct way
    to express "Indian market data" per spec Section 8 ("use the
    appropriate Asia/Kolkata interpretation").

Precision:
    Prices are float, matching FYERS's own historical/live response
    types. If the eventual Part 3 MySQL schema uses DECIMAL, that
    conversion happens at the storage boundary, not here -- this
    contract does not silently round.
"""

import datetime
from dataclasses import dataclass, field
from typing import Literal, Optional
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

CandleStatus = Literal["OPEN", "CLOSED"]
DataSource = Literal["FYERS_HISTORICAL", "FYERS_LIVE"]


@dataclass
class Candle:
    """Canonical 1-minute OHLCV bar. Historical candles are always
    status='CLOSED'. Live candles are 'OPEN' while still forming and
    'CLOSED' only once the minute boundary has passed (spec Section 17
    -- downstream code must be able to tell these apart)."""

    # Instrument identity
    internal_name: str
    fyers_symbol: str
    instrument_type: str
    exchange: str

    # Bar identity
    timestamp: datetime.datetime  # tz-aware, Asia/Kolkata, period start
    timeframe: str                # always "1m" in Part 2

    # OHLCV
    open: float
    high: float
    low: float
    close: float
    volume: int

    # Provenance
    source: DataSource
    status: CandleStatus = "CLOSED"


@dataclass
class Tick:
    """Canonical normalized live market update. Deliberately NOT forced
    into candle shape. Only fields the adapter could confirm from the
    raw FYERS message are populated; everything else stays None rather
    than being guessed (spec Section 28: do not invent response fields)."""

    fyers_symbol: str
    timestamp: datetime.datetime  # tz-aware, Asia/Kolkata
    ltp: float
    volume_traded_today: Optional[int] = None
    bid_price: Optional[float] = None
    ask_price: Optional[float] = None
    open_price: Optional[float] = None
    high_price: Optional[float] = None
    low_price: Optional[float] = None
    prev_close_price: Optional[float] = None
    raw: Optional[dict] = field(default=None, repr=False)


def to_ist(epoch_seconds: Optional[float]) -> datetime.datetime:
    """Converts an epoch timestamp (as FYERS provides) to a tz-aware
    Asia/Kolkata datetime. If epoch_seconds is None, uses current time
    (used only for live messages that omit an explicit timestamp field
    -- see normalizer.py for exactly when this fallback applies)."""
    if epoch_seconds is None:
        return datetime.datetime.now(tz=IST)
    return datetime.datetime.fromtimestamp(float(epoch_seconds), tz=datetime.timezone.utc).astimezone(IST)
