"""
model/processing/validator.py
Validates canonical Candle objects (model/processing/models.py). Never
silently modifies bad data (spec Section 10) -- a candle either passes
as-is or is reported invalid/warning with structured reasons.
"""

import datetime
import math
import logging
from dataclasses import dataclass, field
from typing import Literal, Optional

from model.config.instrument_loader import InstrumentRegistry
from model.processing.models import Candle
from model.processing.timeframe_aggregator import SUPPORTED_TIMEFRAMES

log = logging.getLogger("market_data.processing.validator")

ValidationStatus = Literal["valid", "invalid", "warning"]

FUTURE_TIMESTAMP_TOLERANCE_SECONDS = 300

# Every timeframe this engine can legitimately produce: the canonical
# base (1m) plus every derived timeframe the aggregator supports. Must
# stay in sync with model/processing/timeframe_aggregator.py's
# SUPPORTED_TIMEFRAMES rather than hard-coding "1m only" (that was a
# Part-2-only restriction; Part 3 validates derived candles too).
VALID_TIMEFRAMES = {"1m"} | set(SUPPORTED_TIMEFRAMES)


@dataclass
class ValidationResult:
    status: ValidationStatus
    candle: Optional[Candle]
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return self.status in ("valid", "warning")


def validate_candle(candle: Candle, instruments: Optional[InstrumentRegistry] = None) -> ValidationResult:
    """
    Validates a single canonical Candle. `instruments`, if provided,
    is used to check the candle's fyers_symbol is actually a configured
    instrument (spec Section 10, check #4 "instrument validity") --
    optional because some callers (e.g. isolated unit tests) may not
    have a registry available.
    """
    errors = []
    warnings = []

    # 1. Required fields
    required = {
        "internal_name": candle.internal_name,
        "fyers_symbol": candle.fyers_symbol,
        "timestamp": candle.timestamp,
        "timeframe": candle.timeframe,
        "open": candle.open,
        "high": candle.high,
        "low": candle.low,
        "close": candle.close,
        "volume": candle.volume,
    }
    for field_name, value in required.items():
        if value is None or value == "":
            errors.append(f"Missing required field: {field_name}")

    if errors:
        return ValidationResult(status="invalid", candle=candle, errors=errors, warnings=warnings)

    # 2 & 3. Timestamp validity + timezone correctness
    if candle.timestamp.tzinfo is None:
        errors.append("Timestamp is not timezone-aware (must be Asia/Kolkata)")
    elif candle.timestamp.utcoffset() != datetime.timedelta(hours=5, minutes=30):
        errors.append(f"Timestamp is not in Asia/Kolkata: tzinfo={candle.timestamp.tzinfo}")

    # 11. Future timestamps
    now = datetime.datetime.now(tz=candle.timestamp.tzinfo) if candle.timestamp.tzinfo else datetime.datetime.now()
    if candle.timestamp > now + datetime.timedelta(seconds=FUTURE_TIMESTAMP_TOLERANCE_SECONDS):
        errors.append(f"Timestamp is in the future: {candle.timestamp}")

    # 5. Timeframe validity
    if candle.timeframe not in VALID_TIMEFRAMES:
        errors.append(f"Unsupported timeframe: '{candle.timeframe}' (expected one of {sorted(VALID_TIMEFRAMES)})")

    # 4. Instrument validity
    if instruments is not None:
        try:
            instruments.get(candle.internal_name)
        except KeyError:
            errors.append(f"Unknown instrument: internal_name='{candle.internal_name}' not in registry")

    # 6. Numeric field validity
    numeric_fields = {"open": candle.open, "high": candle.high, "low": candle.low, "close": candle.close}
    for name, value in numeric_fields.items():
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
            errors.append(f"Field '{name}' is not numeric: {value!r}")
    if not isinstance(candle.volume, int) or isinstance(candle.volume, bool):
        errors.append(f"Field 'volume' is not an integer: {candle.volume!r}")

    if errors:
        return ValidationResult(status="invalid", candle=candle, errors=errors, warnings=warnings)

    # 7. OHLC relationships
    if candle.high < candle.low:
        errors.append(f"high ({candle.high}) < low ({candle.low})")
    if not (candle.low <= candle.open <= candle.high):
        errors.append(f"open ({candle.open}) outside [low, high] ([{candle.low}, {candle.high}])")
    if not (candle.low <= candle.close <= candle.high):
        errors.append(f"close ({candle.close}) outside [low, high] ([{candle.low}, {candle.high}])")
    if candle.open <= 0 or candle.high <= 0 or candle.low <= 0 or candle.close <= 0:
        errors.append("One or more prices are non-positive")

    # 8. Volume validity
    if candle.volume < 0:
        errors.append(f"Negative volume: {candle.volume}")
    if candle.volume == 0:
        # Legitimate for e.g. illiquid instruments or a quiet minute --
        # not an error, but worth surfacing (spec: "warning" bucket exists
        # for exactly this kind of case).
        warnings.append("Volume is zero")

    if errors:
        return ValidationResult(status="invalid", candle=candle, errors=errors, warnings=warnings)

    status: ValidationStatus = "warning" if warnings else "valid"
    return ValidationResult(status=status, candle=candle, errors=errors, warnings=warnings)


def validate_candles(candles: list, instruments: Optional[InstrumentRegistry] = None) -> list:
    """
    Batch validation. Beyond per-candle validate_candle(), this also
    performs batch-level checks that only make sense across a sequence:
    duplicate timestamp detection (#9) and out-of-order detection (#10).
    Assumes candles all belong to the same instrument+timeframe (the
    normal case coming out of historical_controller.py for one
    instrument's fetch) -- callers processing multiple instruments must
    call this once per instrument, not on a mixed batch.
    """
    results = []
    seen_timestamps = set()
    last_timestamp = None

    for candle in candles:
        result = validate_candle(candle, instruments=instruments)

        if result.status != "invalid":
            if candle.timestamp in seen_timestamps:
                result.warnings.append(f"Duplicate timestamp within batch: {candle.timestamp}")
                result.status = "warning"
            else:
                seen_timestamps.add(candle.timestamp)

            if last_timestamp is not None and candle.timestamp < last_timestamp:
                result.warnings.append(
                    f"Out-of-order record: {candle.timestamp} arrived after {last_timestamp}"
                )
                result.status = "warning"
            last_timestamp = candle.timestamp

        results.append(result)

    return results
