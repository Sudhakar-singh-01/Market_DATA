"""
model/processing/gap_detector.py
Scans a chronologically-sorted list of 1-minute candles for missing
minutes DURING the standard NSE equity trading session, and reports
them -- never fabricates or interpolates missing data (project
principle, spec Section 35).

SESSION-WINDOW ASSUMPTION (explicitly flagged, not invented):
    Uses a fixed 09:15-15:30 IST session window on trading days:
    Monday-Friday minus the holidays listed in config/holidays.yaml
    (see model/config/market_calendar.py). If that file lists no
    holidays, a weekday exchange holiday can still be a FALSE POSITIVE
    gap, so keep the file up to date.
    Weekends and listed holidays are correctly excluded (no gap reported for a weekend
    with zero candles, since the session window simply doesn't apply).
"""

import datetime
from dataclasses import dataclass

from model.config.market_calendar import is_trading_day
from model.processing.models import IST

SESSION_START = datetime.time(9, 15)
SESSION_END = datetime.time(15, 30)


@dataclass
class Gap:
    date: datetime.date
    gap_start: datetime.datetime  # last candle BEFORE the gap
    gap_end: datetime.datetime    # first candle AFTER the gap
    missing_minutes: int


def _session_minutes_for_date(date: datetime.date) -> list:
    from model.config.market_calendar import expected_starts
    return expected_starts(date)


def find_gaps_1m(candles: list) -> list:
    """
    candles: 1m Candle objects for ONE instrument, any order (sorted
    internally). Returns a list of Gap objects, one per contiguous
    run of missing session minutes. Dates with zero candles at all
    (e.g. a holiday, or a range never fetched) are NOT reported as
    gaps here -- that's a "no data" condition, distinguishable via
    the controller's own result status instead.
    """
    if not candles:
        return []

    sorted_candles = sorted(candles, key=lambda c: c.timestamp)
    present_timestamps = {c.timestamp.replace(second=0, microsecond=0) for c in sorted_candles}

    dates = sorted({c.timestamp.date() for c in sorted_candles})

    gaps = []
    for date in dates:
        expected_minutes = _session_minutes_for_date(date)
        if not expected_minutes:
            continue

        day_candles = [ts for ts in present_timestamps if ts.date() == date]
        if not day_candles:
            continue
        day_start, day_end = min(day_candles), max(day_candles)

        relevant_expected = [m for m in expected_minutes if day_start <= m <= day_end]

        missing_run_start = None
        last_present = None
        for minute in relevant_expected:
            if minute in present_timestamps:
                if missing_run_start is not None:
                    gaps.append(Gap(
                        date=date, gap_start=last_present, gap_end=minute,
                        missing_minutes=int((minute - last_present).total_seconds() // 60) - 1,
                    ))
                    missing_run_start = None
                last_present = minute
            else:
                if missing_run_start is None:
                    missing_run_start = minute

    return gaps


def format_gap_report(gaps: list, fyers_symbol: str) -> str:
    if not gaps:
        return f"{fyers_symbol}: no gaps detected."
    lines = [f"{fyers_symbol}: {len(gaps)} gap(s) detected (session-window only, no holiday calendar -- verify against NSE holidays):"]
    for gap in gaps:
        lines.append(f"  {gap.date}: missing {gap.missing_minutes} minute(s) between {gap.gap_start.time()} and {gap.gap_end.time()}")
    return "\n".join(lines)
