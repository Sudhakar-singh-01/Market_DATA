"""Stage complete historical sessions for preserved or incomplete Cash partitions."""
import datetime as dt
import uuid
from collections import Counter

from model.cash_recovery import identity, enrich, quality, write_json_new
from model.cash_resolution import classify_session
from model.cash_repair import plan_repair, write_parquet_new
from model.cash_restore import guard, require
from model.storage_inventory import safe_root, fingerprint
from model.config.market_calendar import IST


def stage_gaps(report, root, store, operations_root, fetch, now=None, progress=None, *, from_check=False, day_filter=None):
    if from_check:
        require(report.get('status') == 'SCOPED_STORAGE_PASS' and report.get('complete') is True,
                'complete_storage_check_required')
        require(isinstance(day_filter, dt.date), 'explicit_coverage_date_required')
        entries = report['raw_results']
    else:
        require(report.get('status') == 'COMPLETE' and report.get('canonical_certified') is False,
                'completed_session_restore_report_required')
        entries = report['session_entries']
    require(len({e['relative_path'] for e in entries}) == len(entries), 'duplicate_partition')
    verified = {e['relative_path'] for e in report.get('outcomes', []) if e['status'] == 'VERIFIED'}
    selected = []
    for e in entries:
        if from_check:
            _, day = identity(e['relative_path'])
            if (day == day_filter and e.get('status') == 'PARITY_VERIFIED' and e.get('calendar_verified') is True
                    and e.get('quality_issues') == [] and set(e.get('quality_review_reasons', [])) == {'incomplete_minute_coverage'}):
                selected.append(e)
            continue
        c = e.get('session_classification', {})
        coverage = c.get('quality', {}).get('coverage') or {}
        if c.get('regular_rows') == 0 and coverage.get('expected', 0) > 0 and coverage.get('missing', 0) > 0:
            require(e['relative_path'] in verified, 'partition_not_restored')
            selected.append(e)
    root = safe_root(root); op = guard(operations_root)
    require(root != op and root not in op.parents and op not in root.parents,
            'operation_directory_overlaps_data')
    folder = op / ('gaps-' + uuid.uuid4().hex); folder.mkdir(parents=True, exist_ok=False)
    now = now or dt.datetime.now(IST); outcomes = []
    for index, e in enumerate(selected, 1):
        item = {'relative_path': e['relative_path']}; outcomes.append(item)
        try:
            symbol, day = identity(e['relative_path']); meta = store.metadata(symbol)
            sql = enrich(store.rows(meta['id'], day), symbol)
            current = classify_session(sql, symbol, day, now)
            if from_check:
                current_q = current['quality']; current_coverage = current_q['coverage'] or {}
                require(day < now.date() and current_q['calendar_verified'] and current_coverage.get('expected',0) > 0
                        and current_coverage.get('missing',0) > 0
                        and set(current_q['review_reasons']) == {'incomplete_minute_coverage'},
                        'current_session_no_longer_incomplete_or_calendar_changed')
            else:
                require(current['regular_rows'] == 0 and current['outside_session_rows'] > 0,
                        'current_SQL_no_longer_offsession_only')
            rows = fetch(meta, day)
            require(0 < len(rows) <= 20000, 'empty_or_oversized_provider_response')
            q = quality(rows, symbol, day, now, meta)
            require(not q['review_reasons'], 'provider_session_needs_review')
            require(all(r['source'] == 'FYERS_HISTORICAL' for r in rows), 'provider_source_invalid')
            coverage = q['coverage'] or {}
            require(coverage.get('expected', 0) > 0 and coverage.get('missing') == 0
                    and coverage.get('unexpected') == 0, 'complete_regular_session_required')
            require(sql == enrich(store.rows(meta['id'], day), symbol), 'SQL_changed_during_fetch')
            candidate = folder / f'candidate-{index:03d}.parquet'
            write_parquet_new(candidate, rows)
            sha, size = fingerprint(candidate)
            item.update(status='PROVIDER_CANDIDATE_STAGED', candidate=str(candidate), sha256=sha, bytes=size)
        except Exception as exc:
            item.update(status='REVIEW_REQUIRED', error=str(exc) if isinstance(exc, ValueError) else type(exc).__name__)
        if progress: progress(index, len(selected))
    result = {'status': 'REVIEW_READY', 'outcomes': outcomes, 'market_data_modified': False,
              'sql_modified': False, 'summary': dict(Counter(x['status'] for x in outcomes))}
    write_json_new(folder / 'candidates.json', result)
    plan = plan_repair(result, root, store, now=now)
    # Original off-session mode remains insert-only. Explicit final-check mode
    # may prefer reviewed provider values on existing keys via the repair engine.
    for e in plan['entries']:
        if not from_check and e['status'] == 'READY' and e['updated']:
            e.update(status='BLOCKED', reason='gap_recovery_cannot_update_existing_rows')
    plan['summary'] = {'statuses': dict(Counter(e['status'] for e in plan['entries'])),
                      **{k: sum(e.get(k, 0) for e in plan['entries'] if e['status'] == 'READY')
                         for k in ('inserted', 'updated', 'preserved_sql_only')}}
    write_json_new(folder / 'plan.json', plan)
    return {'status': 'PLAN_CREATED', 'selected_partitions': len(selected), 'summary': plan['summary'],
            'candidate_summary': result['summary'], 'plan': str(folder / 'plan.json'),
            'mode': 'INCOMPLETE_SESSION_PROVIDER_REPAIR' if from_check else 'OFFSESSION_ONLY_GAP_FILL',
            'market_data_modified': False, 'sql_modified': False, 'aggregation_status': 'NOT_REBUILT'}
