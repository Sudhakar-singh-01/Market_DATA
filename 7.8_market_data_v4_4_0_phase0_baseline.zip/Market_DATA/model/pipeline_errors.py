"""Actionable preflight failures shared by pipeline callers."""


class FetchPreflightError(ValueError):
    def __init__(self, preview):
        self.preview=preview
        self.blocked=preview.get('blocked',[])
        super().__init__('Fetch blocked for '+str(len(self.blocked))+' symbol-day(s). Review the listed storage, calendar or lookback findings before retrying.')
