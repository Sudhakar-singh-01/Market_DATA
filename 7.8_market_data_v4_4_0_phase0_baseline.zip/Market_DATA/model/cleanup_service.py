"""Bounded whole-day candle cleanup. Never invoked automatically.

SQL and local files cannot commit atomically. Originals and a fsynced journal are
retained on every execution; RECOVERY_NEEDED requires manual backup/journal review.
All writers (including external processes) must remain stopped throughout.
"""
from model.config.runtime_paths import state_path
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import uuid
from contextlib import ExitStack, contextmanager
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq
from sqlalchemy import MetaData, Table, select, inspect, func, text

from model.backup_service import sha256_file
from model.read_contracts import TIMEFRAMES, date_scope, segment_name
from model.schema_management import SchemaManager, ROOT, _digest
from model.storage.locking import file_lock
from model.storage_scope import validate_storage_roots, owned_paths

MAX_ROWS = 200000
MAX_FILE_ROWS = 200000
MAX_FILE_BYTES = 128 * 1024 * 1024
MAX_SCOPE_BYTES = 512 * 1024 * 1024


class CleanupService:
    def __init__(self, catalog, journal_root=None):
        self.catalog = catalog
        self.guard = SchemaManager(catalog)
        self.journal_root = Path(journal_root or state_path('logs/cleanup_operations'))

    @staticmethod
    def _admin(role):
        if role != 'admin':
            raise PermissionError('Administrator access required')

    def _root(self, segment):
        configured = self.catalog.roots.get(segment)
        if not configured:
            raise ValueError('Explicit Parquet root is required for dual-storage cleanup')
        scope = validate_storage_roots(self.catalog.roots)[segment]
        root = Path(scope['root'])
        if not root.is_dir():
            raise ValueError('Configured data root is missing or unsafe')
        journal = self.journal_root.absolute()
        for p in (journal, *journal.parents):
            if p.is_symlink():
                raise ValueError('Symlink journal destination')
        for configured in self.catalog.roots.values():
            if not configured:
                continue
            data_root = Path(configured).resolve()
            if data_root == journal or data_root in journal.parents or journal in data_root.parents:
                raise ValueError('Journal must be outside all configured data roots')
        # A symlink anywhere in this configured tree makes layout discovery unsafe.
        for p in owned_paths(root, scope['excluded_subtrees']):
            if p.is_symlink():
                raise ValueError('Symlinks are not allowed in data tree')
        return root

    def _tables(self, engine, segment):
        names = (['instruments','candles','checkpoints','ingestion_jobs'] if segment == 'CASH' else
                 ['fno_instruments','fno_candles','fno_checkpoint_ranges','fno_harvest_state',
                  'fno_storage_manifest','fno_ingestion_jobs','fno_aggregation_jobs'])
        found = set(inspect(engine).get_table_names())
        if not set(names) <= found:
            raise ValueError('Required candle, checkpoint, manifest or job tables missing')
        # Reflected identifiers come exclusively from this fixed allowlist.
        if engine.dialect.name == 'mysql':
            # Rollback claims require transactional tables and no hidden delete side effects.
            with engine.connect() as conn:
                storage = conn.execute(text('SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=:db'),
                                       {'db':engine.url.database}).all()
                if any(dict(storage).get(n) != 'InnoDB' for n in names):
                    raise ValueError('Cleanup requires InnoDB tables')
                triggers = conn.execute(text('SELECT EVENT_OBJECT_TABLE FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=:db'),
                                        {'db':engine.url.database}).scalars().all()
                if set(triggers) & set(names):
                    raise ValueError('Triggers require manual DBA cleanup')
                cascades = conn.execute(text('SELECT REFERENCED_TABLE_NAME FROM information_schema.REFERENTIAL_CONSTRAINTS '
                    "WHERE UNIQUE_CONSTRAINT_SCHEMA=:db AND DELETE_RULE IN ('CASCADE','SET NULL')"),
                    {'db':engine.url.database}).scalars().all()
                if set(cascades) & (set(names)-{prefix+'instruments' for prefix in ('','fno_')}):
                    raise ValueError('Cascading foreign keys require manual DBA cleanup')
        return {n: Table(n, MetaData(), autoload_with=engine) for n in names}

    @staticmethod
    def _schema_snapshot(engine,tables):
        inspector = inspect(engine)
        return {name:{'columns':inspector.get_columns(name),
                      'primary_key':inspector.get_pk_constraint(name),
                      'foreign_keys':inspector.get_foreign_keys(name),
                      'indexes':inspector.get_indexes(name),
                      'unique_constraints':inspector.get_unique_constraints(name)}
                for name in tables}

    @staticmethod
    def _rows(conn, table, predicate):
        rows = conn.execute(select(table).where(predicate).limit(MAX_ROWS+1)).mappings().all()
        if len(rows) > MAX_ROWS:
            raise ValueError('Cleanup exceeds row bound; narrow date range')
        rows = [dict(r) for r in rows]
        return sorted(rows, key=lambda r: _digest(r))

    def _snapshot(self, segment, symbol, a, b, timeframe, engine, root):
        tables = self._tables(engine, segment)
        prefix = '' if segment == 'CASH' else 'fno_'
        candles = tables[prefix+'candles']
        master = tables[prefix+'instruments']
        tfs = list(TIMEFRAMES) if timeframe == '1m' else [timeframe]
        with engine.connect() as conn:
            for name in (['ingestion_jobs'] if segment == 'CASH' else ['fno_ingestion_jobs','fno_aggregation_jobs']):
                job = tables[name]
                state = job.c.status if segment == 'CASH' else job.c.state
                active = func.upper(state).in_(['PENDING','RUNNING','QUEUED','STARTING','CANCELLING','CANCEL_REQUESTED','STOPPING'])
                if segment == 'CASH' and 'state' in job.c:
                    active = active | func.upper(job.c.state).in_(['PENDING','RUNNING','QUEUED','STARTING','CANCELLING','CANCEL_REQUESTED','STOPPING'])
                if 'active_key' in job.c:
                    active = active | job.c.active_key.is_not(None)
                if conn.execute(select(job).where(active).limit(1)).first():
                    raise ValueError('Active jobs must be stopped before cleanup')
            instruments = self._rows(conn, master, master.c.fyers_symbol == symbol)
            if len(instruments) != 1:
                raise ValueError('Exact registered symbol required')
            instrument = instruments[0]; cid = instrument['id']
            identity_col = candles.c.instrument_id if segment == 'CASH' else candles.c.contract_id
            predicate = ((identity_col == cid) & candles.c.timeframe.in_(tfs) &
                         (candles.c.candle_timestamp >= dt.datetime.combine(a, dt.time())) &
                         (candles.c.candle_timestamp < dt.datetime.combine(b+dt.timedelta(days=1), dt.time())))
            rows = self._rows(conn, candles, predicate)
            predicates = {candles.name: predicate}
            snapshots = {candles.name: rows}
            if segment == 'CASH':
                ck = tables['checkpoints']
                pred = (ck.c.fyers_symbol == symbol) & ck.c.timeframe.in_(tfs) & (ck.c.synced_through_date >= a)
                predicates[ck.name] = pred; snapshots[ck.name] = self._rows(conn, ck, pred)
            else:
                ck = tables['fno_checkpoint_ranges']
                pred = ((ck.c.contract_id == cid) & ck.c.timeframe.in_(tfs) &
                        (ck.c.range_from <= b) & (ck.c.range_to >= a))
                predicates[ck.name] = pred; snapshots[ck.name] = self._rows(conn, ck, pred)
                harvest = tables['fno_harvest_state']
                # A high-water mark cannot represent a historical hole: discard this contract's state.
                pred = harvest.c.contract_id == cid
                predicates[harvest.name] = pred; snapshots[harvest.name] = self._rows(conn, harvest, pred)
            files = []
            for tf in tfs:
                if segment == 'CASH':
                    folder = root/('raw/1m' if tf == '1m' else 'processed/'+tf)/symbol.replace(':','_')
                    pattern = re.compile(r'(\d{4}-\d{2}-\d{2})\.parquet')
                else:
                    underlying = str(instrument['underlying'])
                    if not re.fullmatch(r'[A-Za-z0-9_\-]+', underlying):
                        raise ValueError('Unsupported underlying path identity')
                    expiry = str(instrument['expiry'])[:10]
                    dt.date.fromisoformat(expiry)
                    folder = root/'candles'/tf/('underlying='+underlying)/('expiry='+expiry)
                    pattern = re.compile(r'date=(\d{4}-\d{2}-\d{2})\.parquet')
                if not folder.exists():
                    continue
                for path in sorted(folder.iterdir()):
                    match = pattern.fullmatch(path.name)
                    if not match:
                        if path.name.endswith('.lock') and path.is_file():
                            continue
                        raise ValueError('Unknown partition layout or temporary file; reconcile first')
                    day = dt.date.fromisoformat(match[1])
                    if not a <= day <= b:
                        continue
                    metadata = pq.ParquetFile(path).metadata if path.is_file() else None
                    if (metadata is None or path.stat().st_nlink != 1 or path.stat().st_size > MAX_FILE_BYTES
                        or sum(metadata.row_group(i).total_byte_size for i in range(metadata.num_row_groups)) > MAX_FILE_BYTES
                        or sum(f['expanded_bytes'] for f in files)+sum(metadata.row_group(i).total_byte_size for i in range(metadata.num_row_groups)) > MAX_SCOPE_BYTES
                        or metadata.num_rows > MAX_FILE_ROWS):
                        raise ValueError('Invalid or excessive partition')
                    validated_checksum = sha256_file(path)
                    frame = pd.read_parquet(path)
                    if sha256_file(path) != validated_checksum:
                        raise ValueError('Partition changed during preview; stop all writers')
                    required = {'timeframe','candle_timestamp', 'fyers_symbol' if segment == 'CASH' else 'contract_id'}
                    if not required <= set(frame.columns) or frame.empty:
                        raise ValueError('Unknown or empty candle partition')
                    stamps = pd.to_datetime(frame.candle_timestamp, errors='raise')
                    if segment == 'FNO' and (stamps.dt.tz is not None or
                        not pd.api.types.is_integer_dtype(frame.contract_id.dtype) or
                        frame.contract_id.isna().any() or not (frame.contract_id > 0).all()):
                        raise ValueError('Invalid FNO contract identity or timestamp convention')
                    if stamps.dt.tz is not None:
                        stamps = stamps.dt.tz_convert('Asia/Kolkata')
                    if not (stamps.dt.date == day).all() or not (frame.timeframe == tf).all():
                        raise ValueError('Mixed date/timeframe partition')
                    key = 'fyers_symbol' if segment == 'CASH' else 'contract_id'
                    value = symbol if segment == 'CASH' else cid
                    if frame.duplicated([key,'timeframe','candle_timestamp']).any():
                        raise ValueError('Duplicate partition identities')
                    if segment == 'CASH' and not (frame[key] == value).all():
                        raise ValueError('Mixed Cash symbol partition')
                    if segment == 'FNO':
                        ids = [int(v) for v in frame.contract_id.unique()]
                        peers = self._rows(conn, master, master.c.id.in_(ids))
                        if len(peers) != len(ids) or any(p['underlying'] != instrument['underlying'] or str(p['expiry'])[:10] != expiry for p in peers):
                            raise ValueError('Mixed or unknown FNO partition contracts')
                    matched = int((frame[key] == value).sum())
                    rel = path.relative_to(root).as_posix()
                    manifest = []
                    if segment == 'FNO':
                        mt = tables['fno_storage_manifest']
                        manifest = self._rows(conn, mt, mt.c.relative_path == rel)
                        if (len(manifest) != 1 or manifest[0]['status'] != 'VERIFIED' or
                            manifest[0]['dataset'] != 'candles' or manifest[0]['timeframe'] != tf or
                            manifest[0]['checksum'] != validated_checksum or manifest[0]['row_count'] != len(frame)):
                            raise ValueError('Partition manifest is not verified or differs from file')
                    files.append({'relative_path':rel, 'bytes':path.stat().st_size, 'expanded_bytes':sum(metadata.row_group(i).total_byte_size for i in range(metadata.num_row_groups)), 'sha256':validated_checksum, 'matched_rows':matched,
                                  'preserved_rows':len(frame)-matched, 'manifest':manifest})
            # Missing manifest-backed files must never be silently ignored.
            if segment == 'FNO':
                mt = tables['fno_storage_manifest']
                entries = self._rows(conn, mt, (mt.c.dataset == 'candles') & mt.c.timeframe.in_(tfs))
                for entry in entries:
                    rel = entry['relative_path']
                    expected_prefix = 'candles/'+str(entry['timeframe'])+'/underlying='+str(instrument['underlying'])+'/expiry='+str(instrument['expiry'])[:10]+'/date='
                    if rel.startswith(expected_prefix):
                        tail = rel[len(expected_prefix):]
                        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}\.parquet', tail):
                            raise ValueError('Unknown manifest path layout')
                        if a <= dt.date.fromisoformat(tail[:10]) <= b and not (root/rel).is_file():
                            raise ValueError('Manifest-backed partition is missing')
        return tables, predicates, snapshots, instrument, files, tfs

    def preview(self, segment, symbol, from_date, to_date, timeframe='1m', *, role):
        self._admin(role); segment = segment_name(segment)
        if not isinstance(symbol,str) or not re.fullmatch(r'[A-Za-z0-9:_&.\-]{1,80}', symbol):
            raise ValueError('Exact safe registered symbol required')
        if timeframe not in TIMEFRAMES:
            raise ValueError('Unsupported timeframe')
        a,b = date_scope(from_date,to_date,max_days=31)
        if b >= dt.datetime.now(dt.timezone(dt.timedelta(hours=5,minutes=30))).date():
            raise ValueError('Only completed historical days can be cleaned')
        engine = self.guard._engine(segment); root = self._root(segment)
        tables,predicates,snapshots,instrument,files,tfs = self._snapshot(segment,symbol,a,b,timeframe,engine,root)
        plan = {'segment':segment,'database':engine.url.database,'target':{'host':engine.url.host,'port':engine.url.port,'database':engine.url.database},
                'scope':{'symbol':symbol,'from_date':a.isoformat(),'to_date':b.isoformat(),'timeframe':timeframe},
                'timeframes':tfs,'parquet_root':str(root),'instrument_hash':_digest(instrument),
                'row_counts':{n:len(r) for n,r in snapshots.items()},
                'checkpoint_counts':{n:len(r) for n,r in snapshots.items() if 'candles' not in n},
                'rows_hash':_digest(snapshots),'files':files,
                'schema_hash':_digest(self._schema_snapshot(engine,tables)),
                'limitations':'Whole IST calendar days, one registered symbol; 1m includes every supported derived timeframe. All external writers must remain stopped. Originals retained; manual recovery only.'}
        plan['token'] = _digest(plan)
        return plan

    def _publish_file(self, source, destination):
        os.replace(source, destination)
        self._sync_dir(destination.parent)

    @staticmethod
    def _sync_dir(path):
        if os.name != 'nt':
            fd = os.open(path, os.O_RDONLY)
            try: os.fsync(fd)
            finally: os.close(fd)

    @contextmanager
    def _partition_locks(self, engine, root, segment, files):
        paths = sorted({entry['relative_path'] for entry in files})
        if segment == 'CASH':
            with ExitStack() as locks:
                for relative in paths:
                    locks.enter_context(file_lock(str(root/relative)+'.lock', timeout=0))
                yield
            return
        # Match Release3Repository.partition_lock's exact advisory namespace.
        # One session owns all locks: up to 31 days * 6 timeframes must not
        # consume one connection per partition and exhaust the engine pool.
        acquired = []
        with engine.connect() as conn:
            try:
                for relative in paths:
                    key = 'fno:'+hashlib.sha256((engine.url.database+':'+relative).encode()).hexdigest()[:55]
                    if conn.execute(text('SELECT GET_LOCK(:key, 0)'), {'key':key}).scalar() != 1:
                        raise RuntimeError('Another FNO operation holds this partition; retry after writers stop')
                    acquired.append(key)
                yield
            finally:
                failed = False
                for key in reversed(acquired):
                    try:
                        if conn.execute(text('SELECT RELEASE_LOCK(:key)'), {'key':key}).scalar() != 1:
                            failed = True
                    except Exception:
                        failed = True
                # Never return a session with uncertain named-lock ownership to
                # the pool. Closing its physical connection releases all locks.
                if failed:
                    conn.invalidate()

    def apply(self, plan, *, role, confirmation, backup_acknowledged=False, writers_stopped=False):
        self._admin(role)
        if not backup_acknowledged or not writers_stopped:
            raise ValueError('Acknowledge verified backup and stop all SQL/Parquet writers first')
        if confirmation != 'CLEANUP '+str(plan.get('database','')):
            raise ValueError('Type CLEANUP followed by exact database name')
        segment = segment_name(plan['segment']); engine = self.guard._engine(segment)
        with self.guard._database_lock(engine), ExitStack() as locks:
            # Global app lock plus compatible per-partition writer locks.
            root = self._root(segment)
            self.journal_root.mkdir(parents=True,exist_ok=True)
            locks.enter_context(file_lock(self.journal_root/'cleanup.lock', timeout=0))
            if any(self.journal_root.glob('*/RECOVERY_NEEDED')):
                raise ValueError('Unresolved cleanup recovery journal; review manually before retry')
            scope = plan['scope']
            current = self.preview(segment,scope['symbol'],scope['from_date'],scope['to_date'],scope['timeframe'],role=role)
            if current != plan:
                raise ValueError('Cleanup scope changed; create a fresh preview')
            locks.enter_context(self._partition_locks(engine,root,segment,current['files']))
            if current != self.preview(segment,scope['symbol'],scope['from_date'],scope['to_date'],scope['timeframe'],role=role):
                raise ValueError('Cleanup scope changed while acquiring locks')
            a,b = date_scope(scope['from_date'],scope['to_date'],max_days=31)
            tables,predicates,snapshots,instrument,files,tfs = self._snapshot(segment,scope['symbol'],a,b,scope['timeframe'],engine,root)
            operation = self.journal_root/uuid.uuid4().hex; operation.mkdir()
            self._sync_dir(self.journal_root)
            marker = operation/'RECOVERY_NEEDED'
            marker.write_text('Incomplete operation: review journal and verified backup before recovery.\n')
            with marker.open('r') as stream: os.fsync(stream.fileno())
            self._sync_dir(operation)
            with (operation/'journal.jsonl').open('x',encoding='utf-8') as journal:
                def record(event, **details):
                    journal.write(json.dumps({'event':event,**details},default=str,sort_keys=True)+'\n')
                    journal.flush(); os.fsync(journal.fileno())
                record('START',plan=current,sql_original_rows=snapshots)
                try:
                    staged = []
                    for index,entry in enumerate(files):
                        if not entry['matched_rows']:
                            continue
                        path = root/entry['relative_path']; original = operation/(str(index)+'.original.parquet')
                        shutil.copyfile(path,original)
                        with original.open('rb') as f: os.fsync(f.fileno())
                        if sha256_file(original) != entry['sha256']:
                            raise ValueError('Source changed during quarantine copy')
                        frame = pd.read_parquet(original)
                        key,value = ('fyers_symbol',scope['symbol']) if segment == 'CASH' else ('contract_id',instrument['id'])
                        kept = frame.loc[frame[key] != value].copy()
                        replacement = None
                        if len(kept):
                            replacement = operation/(str(index)+'.replacement.parquet')
                            kept.to_parquet(replacement,index=False)
                            with replacement.open('rb') as f: os.fsync(f.fileno())
                            pd.testing.assert_frame_equal(pd.read_parquet(replacement),kept.reset_index(drop=True))
                        staged.append((entry,path,replacement,kept,original))
                        record('STAGED',relative_path=entry['relative_path'],original=str(original),original_sha256=entry['sha256'])
                    self._sync_dir(operation)
                    # Last full revalidation before the first mutation.
                    if current != self.preview(segment,scope['symbol'],scope['from_date'],scope['to_date'],scope['timeframe'],role=role):
                        raise ValueError('Cleanup scope changed during staging')
                    with engine.begin() as conn:
                        for name,predicate in predicates.items():
                            result = conn.execute(tables[name].delete().where(predicate))
                            if result.rowcount != len(snapshots[name]):
                                raise ValueError('SQL rows changed during cleanup')
                        for entry,path,replacement,kept,original in staged:
                            if sha256_file(path) != entry['sha256']:
                                raise ValueError('Partition changed during cleanup')
                            record('FILE_MUTATION_INTENT',relative_path=entry['relative_path'])
                            if replacement is None:
                                path.unlink(); self._sync_dir(path.parent)
                            else:
                                # Copy to same filesystem before atomic publication.
                                temp = path.with_name('.'+path.name+'.cleanup-'+operation.name)
                                record('TEMP_INTENT',path=str(temp))
                                shutil.copyfile(replacement,temp)
                                with temp.open('rb') as f: os.fsync(f.fileno())
                                self._publish_file(temp,path)
                            record('FILE_PUBLISHED',relative_path=entry['relative_path'])
                            if segment == 'FNO':
                                mt = tables['fno_storage_manifest']; pred = mt.c.relative_path == entry['relative_path']
                                if replacement is None:
                                    conn.execute(mt.delete().where(pred))
                                else:
                                    conn.execute(mt.update().where(pred).values(row_count=len(kept),checksum=sha256_file(path),
                                        min_timestamp=kept.candle_timestamp.min().to_pydatetime(),
                                        max_timestamp=kept.candle_timestamp.max().to_pydatetime(),status='VERIFIED',note='Scoped candle cleanup; originals in admin journal'))
                        record('SQL_COMMIT_INTENT')
                    record('COMPLETED')
                    marker.unlink(); self._sync_dir(operation)
                    return {'status':'SUCCESS','journal':str(operation/'journal.jsonl'),'row_counts':current['row_counts'],
                            'files_changed':len(staged),'originals_retained':True}
                except Exception as exc:
                    record('RECOVERY_NEEDED',error_type=type(exc).__name__,note='SQL transaction may have rolled back; files may be changed. Do not resume writers; inspect originals and backup manually.')
                    return {'status':'RECOVERY_NEEDED','journal':str(operation/'journal.jsonl'),'error_type':type(exc).__name__,'error':'Cleanup did not complete. Keep writers stopped and review the recovery journal and verified backup.','originals_retained':True}
