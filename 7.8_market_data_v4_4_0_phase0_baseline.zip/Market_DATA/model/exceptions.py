"""
model/exceptions.py
Shared exception types used across the configuration and authentication
layers. Kept in one place so Part 2 modules (historical.py, websocket.py,
etc.) can catch/raise the same error types without redefining them.
"""


class ConfigurationError(Exception):
    """Raised when required configuration (env vars, YAML files/keys,
    instrument definitions, timeframe settings) is missing or invalid.
    Startup must fail loudly with this, never continue silently."""


class InstrumentValidationError(ConfigurationError):
    """Raised for instrument-registry-specific problems: duplicate
    internal names, empty symbols, malformed entries."""


class HistoricalProviderError(Exception):
    """A sanitized provider rejection with request context and field diagnostics."""

    category = "provider_error"
    retryable = False

    def __init__(self, symbol, range_from, range_to, code, message, details=None):
        self.symbol = symbol
        self.range_from = range_from
        self.range_to = range_to
        self.code = code
        self.message = message
        self.details = details or {}
        diagnostics = "; ".join(f"{key}: {value}" for key, value in self.details.items())
        suffix = f"; {diagnostics}" if diagnostics else ""
        super().__init__(
            f"FYERS {self.category} for {symbol} {range_from}..{range_to} "
            f"(code {code}): {message}{suffix}"
        )


class HistoricalAvailabilityError(HistoricalProviderError):
    """The provider explicitly rejected the requested historical availability."""

    category = "history_unavailable"
