"""Reviewed provider promotion: preserve SQL-only rows and journal cross-store repair."""
import datetime as dt
import os
import uuid
from collections import Counter
from pathlib import Path
from sqlalchemy import text
from model.cash_recovery import (identity,enrich,source_rows,equal,quality,write_json_new,FIELDS)
from model.cash_resolution import classify_session
from model.cash_restore import guard,require,digest,destination,append_event
from model.storage_inventory import safe_root,fingerprint
from model.storage.locking import file_lock
from model.quality import stamp,canonical
from model.config.market_calendar import IST


def repair_metadata(store,symbol,conn=None):
    meta=store.metadata(symbol,conn)
    return {k:meta[k] for k in ('id','fyers_symbol','internal_name','exchange','instrument_type')}


def canonical_rows(rows,meta):
    out=[];seen=set()
    for r in rows:
        ts=stamp(r['candle_timestamp']);require(ts not in seen,'duplicate_timestamp');seen.add(ts)
        out.append(dict(candle_timestamp=ts.isoformat(),timeframe='1m',
            **{k:meta[k] for k in ('fyers_symbol','internal_name','exchange','instrument_type')},
            **{k:str(canonical(r[k],k)) if k in ('open','high','low','close') else canonical(r[k],k) for k in FIELDS}))
    return sorted(out,key=lambda r:r['candle_timestamp'])


def target_state(target,root):
    if not target.exists():return None,[]
    sha,size=fingerprint(target)
    rows=source_rows({'source':str(target),'sha256':sha,'bytes':size})
    return {'sha256':sha,'bytes':size},rows


def plan_repair(result,root,store,now=None):
    require(result.get('status')=='REVIEW_READY','resolution_report_required')
    root=safe_root(root);now=now or dt.datetime.now(IST);entries=[];seen=set()
    for outcome in result['outcomes']:
        rel=outcome['relative_path'];require(rel not in seen,'duplicate_partition');seen.add(rel)
        e={'relative_path':rel,'status':'DEFERRED'};entries.append(e)
        if outcome['status']!='PROVIDER_CANDIDATE_STAGED':
            e['reason']='session_or_provider_review_not_promoted';continue
        try:
            symbol,day=identity(rel);meta=repair_metadata(store,symbol)
            source={'source':outcome['candidate'],'sha256':outcome['sha256'],'bytes':outcome['bytes']}
            provider=source_rows(source);quality(provider,symbol,day,now,meta)
            require(all(r['source']=='FYERS_HISTORICAL' for r in provider),'not_historical_candidate')
            sql=enrich(store.rows(meta['id'],day),symbol)
            classify_session(sql,symbol,day,now)
            before=canonical_rows(sql,meta);candidate=canonical_rows(provider,meta)
            old={r['candle_timestamp']:r for r in before};new={r['candle_timestamp']:r for r in candidate}
            extras=[r for k,r in old.items() if k not in new]
            after=sorted(candidate+extras,key=lambda r:r['candle_timestamp'])
            target=destination(root,e);state,pq=target_state(target,root)
            if state:require(equal(pq,sql),'target_not_equal_to_SQL_requires_review')
            # Re-read to reject a moving SQL snapshot; apply checks it again.
            require(before==canonical_rows(enrich(store.rows(meta['id'],day),symbol),meta),'SQL_changed_during_plan')
            e.update(status='READY',source=source,metadata=meta,before=before,after=after,target_before=state,
                inserted=sum(k not in old for k in new),updated=sum(k in old and old[k]!=v for k,v in new.items()),
                preserved_sql_only=len(extras),sql_before_hash=digest(before),sql_after_hash=digest(after))
        except Exception as exc:e.update(status='BLOCKED',reason=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
    return {'format_version':1,'operation':'CASH_PROVIDER_REPAIR','target_root':str(root),'entries':entries,
        'summary':{'statuses':dict(Counter(e['status'] for e in entries)),
            **{k:sum(e.get(k,0) for e in entries if e['status']=='READY') for k in ('inserted','updated','preserved_sql_only')}},
        'policy':'Explicit provider preference on matching timestamps. No SQL deletes; extras preserved. Session cases deferred. Higher timeframe rebuild remains required.'}


def write_parquet_new(path,rows):
    import pandas as pd
    data=[dict(r,candle_timestamp=stamp(r['candle_timestamp']),
        **{k:float(r[k]) for k in ('open','high','low','close')}) for r in rows]
    # Windows FlushFileBuffers requires a writable handle. Keep ownership of
    # the exclusive staging handle through serialization, flush and fsync.
    with open(path,'xb') as stream:
        pd.DataFrame(data).to_parquet(stream,index=False)
        stream.flush()
        os.fsync(stream.fileno())


def apply_repair(plan,root,store,operations_root,*,writers_stopped=False,accept_provider=False,now=None,progress=None):
    require(writers_stopped and accept_provider,'writers_stopped_and_accept_provider_required')
    root=safe_root(root);now=now or dt.datetime.now(IST)
    require(plan.get('operation')=='CASH_PROVIDER_REPAIR' and plan.get('format_version')==1,'invalid_plan')
    require(root==Path(plan['target_root']).resolve(),'configured_root_changed')
    require(len({e['relative_path'] for e in plan['entries']})==len(plan['entries']),'duplicate_partition')
    op=guard(operations_root);require(root!=op and root not in op.parents and op not in root.parents,'operation_directory_overlaps_data')
    store.ensure_insert_schema()
    run=guard(op/digest(plan));run.mkdir(parents=True,exist_ok=True)
    journal=run/'events.jsonl';out=[]
    ready=[e for e in plan['entries'] if e['status']=='READY']
    with file_lock(run/'operation.lock',timeout=0):
        if not (run/'plan.json').exists():write_json_new(run/'plan.json',plan)
        for index,e in enumerate(ready,1):
            result={'relative_path':e['relative_path']};out.append(result);temp=None;commit_attempted=False;stage='preflight'
            try:
                symbol,day=identity(e['relative_path']);target=destination(root,e);target.parent.mkdir(parents=True,exist_ok=True)
                with file_lock(guard(str(target)+'.lock'),timeout=0):
                    meta=repair_metadata(store,symbol);require(meta==e['metadata'],'metadata_changed')
                    provider=source_rows(e['source']);quality(provider,symbol,day,now,meta)
                    before=e['before'];after=e['after']
                    require(digest(before)==e['sql_before_hash'] and digest(after)==e['sql_after_hash'],'plan_row_hash_mismatch')
                    old={r['candle_timestamp']:r for r in before};new={r['candle_timestamp']:r for r in canonical_rows(provider,meta)}
                    expected=sorted(list(new.values())+[r for k,r in old.items() if k not in new],key=lambda r:r['candle_timestamp'])
                    require(after==expected,'candidate_plan_mismatch')
                    current=canonical_rows(enrich(store.rows(meta['id'],day),symbol),meta)
                    require(current in (before,after),'SQL_changed_replan')
                    state,pq=target_state(target,root)
                    if state and equal(pq,after) and current==after:
                        result.update(status='ALREADY_APPLIED');continue
                    require(state==e['target_before'],'target_changed_replan')
                    stage='backup'
                    attempt=run/('attempt-'+uuid.uuid4().hex);attempt.mkdir()
                    full_before=store.rows(meta['id'],day)
                    require(canonical_rows(enrich(full_before,symbol),meta)==current,'SQL_changed_before_backup')
                    write_json_new(attempt/'sql_before.json',{'metadata':meta,'rows':full_before})
                    if state:
                        with target.open('rb') as src,(attempt/'target_before.parquet').open('xb') as dst:
                            import shutil
                            shutil.copyfileobj(src,dst);dst.flush();os.fsync(dst.fileno())
                        require(fingerprint(attempt/'target_before.parquet')==(state['sha256'],state['bytes']),'backup_changed')
                    stage='stage_parquet'
                    temp=guard(target.parent/('.repair-'+uuid.uuid4().hex+'.tmp'));write_parquet_new(temp,after)
                    sha,size=fingerprint(temp)
                    require(equal(source_rows({'source':str(temp),'sha256':sha,'bytes':size}),after),'staged_parquet_readback_failed')
                    append_event(journal,{'event':'PREPARED','path':e['relative_path'],'backup':str(attempt)})
                    stage='sql_transaction'
                    with store.engine.begin() as conn:
                        locked=canonical_rows(enrich(store.rows(meta['id'],day,conn,True),symbol),meta)
                        require(locked in (before,after),'SQL_changed_under_lock')
                        require(repair_metadata(store,symbol,conn)==meta,'metadata_changed_under_lock')
                        if locked!=after:
                            missing=[]
                            for row in after:
                                key=row['candle_timestamp']
                                if key not in old:missing.append(row);continue
                                if row==old[key]:continue
                                values={k:canonical(row[k],k) for k in FIELDS}
                                if store.engine.dialect.name=='sqlite':
                                    for k in ('open','high','low','close'):values[k]=float(values[k])
                                values.update(i=meta['id'],ts=stamp(key).replace(tzinfo=None))
                                changed=conn.execute(text('UPDATE candles SET '+','.join(k+'=:'+k for k in FIELDS)+
                                    " WHERE instrument_id=:i AND timeframe='1m' AND candle_timestamp=:ts"),values)
                                require(changed.rowcount==1,'unexpected_update_count')
                            store.insert_missing(conn,meta['id'],missing)
                        require(canonical_rows(enrich(store.rows(meta['id'],day,conn,True),symbol),meta)==after,'SQL_readback_failed')
                        require(target_state(target,root)[0]==state,'target_changed_before_commit')
                        commit_attempted=True
                    stage='publish_parquet'
                    append_event(journal,{'event':'SQL_COMMITTED','path':e['relative_path']})
                    require(target_state(target,root)[0]==state,'target_changed_before_publish')
                    if state is None:os.link(temp,target);temp.unlink()
                    else:os.replace(temp,target)
                    temp=None
                    stage='postcheck'
                    require(equal(target_state(target,root)[1],after),'parquet_postcheck_failed')
                    require(canonical_rows(enrich(store.rows(meta['id'],day),symbol),meta)==after,'SQL_postcheck_failed')
                    result.update(status='VERIFIED',inserted=e['inserted'],updated=e['updated'],preserved_sql_only=e['preserved_sql_only'])
                    append_event(journal,dict(event='VERIFIED',**result))
            except Exception as exc:
                result.update(status='REVIEW_REQUIRED',stage=stage,sql_may_have_committed=commit_attempted,error=str(exc) if isinstance(exc,ValueError) else type(exc).__name__)
                if isinstance(exc,OSError):
                    result['os_error']={'errno':exc.errno,'winerror':getattr(exc,'winerror',None),
                        'message':exc.strerror,'filename':str(exc.filename) if exc.filename else None}
                append_event(journal,dict(event='REVIEW_REQUIRED',**result))
            finally:
                if temp is not None and temp.exists():temp.unlink()
                if progress:progress(index,len(ready))
        result={'status':'PARTIAL' if any(e['status']!='READY' for e in plan['entries']) or any(o['status']=='REVIEW_REQUIRED' for o in out) else 'BASE_REPAIR_VERIFIED',
            'applied_statuses':dict(Counter(e['status'] for e in out)),'outcomes':out,'journal':str(journal),
            'deferred_or_blocked':sum(e['status']!='READY' for e in plan['entries']),
            'aggregation_status':'NOT_REBUILT','affected_partitions':[e['relative_path'] for e in ready],
            'scope':'Raw 1m storage parity only. Preserved SQL-only/session rows are not regular-session certified. No atomic SQL/Parquet transaction claimed.'}
        report=run/('result-'+uuid.uuid4().hex+'.json');result['report']=str(report);write_json_new(report,result)
        return result
