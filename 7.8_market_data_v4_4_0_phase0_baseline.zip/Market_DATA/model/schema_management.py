"""Explicit, preview-bound schema setup using repository-owned definitions only.

No user SQL, database switching, row deletion or automatic startup migration.
MySQL DDL commits implicitly: journal each completed statement; never claim rollback.
"""
from model.config.runtime_paths import state_path
import datetime as dt
import hashlib
import json
import re
import threading
import uuid
from contextlib import contextmanager
from pathlib import Path
from sqlalchemy import inspect, text
from model.read_contracts import segment_name
from model.fno.migrations import list_sql_files, split_statements
from model.fno.db import is_fno_engine
from model.quality_store import QUALITY_DDL, EVENT_DDL, migration_plan

ROOT = Path(__file__).resolve().parents[1]
_LOCK = threading.Lock()


def owned_definitions(segment):
    """Extract CREATE TABLE only; intentionally exclude USE, database DDL and DML."""
    segment = segment_name(segment)
    files = [ROOT/'database/schema.sql'] if segment == 'CASH' else list_sql_files()
    statements = [s for p in files for s in split_statements(p.read_text(encoding='utf-8'))]
    if segment == 'CASH':
        statements += [QUALITY_DDL, EVENT_DDL]
    definitions = {}
    for sql in statements:
        match = re.match(r'^CREATE TABLE\s+(?:IF NOT EXISTS\s+)?([a-z_]+)\s*\(', sql, re.I)
        if not match:
            continue
        name = match.group(1)
        if (segment == 'FNO') != name.startswith('fno_'):
            raise ValueError('Schema definition violates segment ownership')
        definitions[name] = sql
    return definitions


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,default=str).encode()).hexdigest()


class SchemaManager:
    def __init__(self, catalog, journal_root=None):
        self.catalog = catalog
        self.journal_root = Path(journal_root or state_path('logs/schema_operations'))

    @staticmethod
    def _admin(role):
        if role != 'admin':
            raise PermissionError('Administrator access required')

    def _engine(self, segment):
        engine = self.catalog.engine(segment)
        if engine.dialect.name != 'mysql':
            raise ValueError('Schema changes require MySQL')
        if segment == 'FNO' and not is_fno_engine(engine):
            raise ValueError('FNO requires the guarded engine factory')
        with engine.connect() as conn:
            actual = conn.execute(text('SELECT DATABASE()')).scalar()
        if not actual or actual != engine.url.database:
            raise ValueError('Connected database identity differs from configuration')
        # Check names across both registered segments without opening the other database.
        if segment == 'CASH' and any(n.startswith('fno_') for n in inspect(engine).get_table_names()):
            raise ValueError('FNO tables found in Cash database; review isolation before schema changes')
        return engine

    @contextmanager
    def _database_lock(self, engine):
        # Serializes this manager across app processes; external tools must still be stopped.
        name = 'tios_schema_' + _digest(engine.url.database)[:40]
        with engine.connect() as conn:
            acquired = conn.execute(text('SELECT GET_LOCK(:name, 0)'), {'name':name}).scalar()
            if acquired != 1:
                raise ValueError('Another schema manager is using this database')
            try:
                yield
            finally:
                conn.execute(text('SELECT RELEASE_LOCK(:name)'), {'name':name})

    def preview(self, segment, operation='missing_tables', *, role):
        self._admin(role)
        segment = segment_name(segment)
        if operation not in ('missing_tables','cash_pipeline') or (operation == 'cash_pipeline' and segment != 'CASH'):
            raise ValueError('Unsupported schema operation')
        engine = self._engine(segment)
        inspector = inspect(engine)
        names = sorted(inspector.get_table_names())
        # Bind preview to current schema, including indexes; never snapshot market rows.
        snapshot = {n: {'columns':inspector.get_columns(n), 'indexes':inspector.get_indexes(n),
                        'pk':inspector.get_pk_constraint(n), 'fk':inspector.get_foreign_keys(n)} for n in names}
        definitions = owned_definitions(segment)
        missing = [n for n in definitions if n not in names]
        if operation == 'cash_pipeline' and 'audit_log' not in names:
            raise ValueError('Create the missing audit_log table before pipeline metadata migration')
        sql = [definitions[n] for n in missing] if operation == 'missing_tables' else migration_plan(engine)
        compatibility = self.compatibility(segment, role=role)
        blockers = [f for f in compatibility['findings'] if f['severity'] in ('BLOCKING','UNVERIFIED')]
        # An existing active_key column can contain duplicates before the unique
        # index exists. Return only a boolean, never job keys or row contents.
        if operation == 'cash_pipeline' and any(s.startswith('CREATE UNIQUE INDEX uq_pipeline_active ') for s in sql):
            if 'active_key' in {c['name'] for c in inspector.get_columns('ingestion_jobs')}:
                with engine.connect() as conn:
                    duplicate = conn.execute(text('SELECT 1 FROM ingestion_jobs WHERE active_key IS NOT NULL '
                        'GROUP BY active_key HAVING COUNT(*) > 1 LIMIT 1')).first()
                if duplicate:
                    blockers.append({'table':'ingestion_jobs','kind':'duplicate_active_key','severity':'BLOCKING',
                                     'expected':'Unique non-null active keys','actual':'Duplicates exist; review jobs manually'})
        plan = {'segment':segment,'database':engine.url.database,'operation':operation,
                'missing_tables':missing,'statements':sql,'schema_hash':_digest(snapshot),
                'target': {'host':engine.url.host,'port':engine.url.port,'database':engine.url.database},
                'existing_tables':names, 'compatibility':compatibility,
                'blockers':blockers, 'can_apply':not blockers}
        plan['token'] = _digest(plan)
        return plan

    def compatibility(self, segment, *, role):
        """Read-only repository contract check; never starts a migration or broker."""
        self._admin(role)
        segment = segment_name(segment)
        from model.schema_compatibility import compatibility_report
        return compatibility_report(inspect(self._engine(segment)), owned_definitions(segment), segment)

    def apply(self, preview, *, role, confirmation, backup_acknowledged=False):
        self._admin(role)
        if not backup_acknowledged:
            raise ValueError('Acknowledge a verified database backup before schema changes')
        if confirmation != 'APPLY '+str(preview.get('database','')):
            raise ValueError('Type APPLY followed by the exact database name')
        if not _LOCK.acquire(blocking=False):
            raise ValueError('Another schema operation is running in this process')
        try:
            engine = self._engine(segment_name(preview['segment']))
            with self._database_lock(engine):
                return self._apply_locked(preview, role)
        finally:
            _LOCK.release()

    def _apply_locked(self, preview, role):
        current = self.preview(preview['segment'],preview['operation'],role=role)
        if preview != current:
            raise ValueError('Schema, target or plan changed; create a fresh preview')
        if current['blockers']:
            raise ValueError('Schema compatibility or data preflight failed; resolve the reported blockers before applying')
        engine = self._engine(current['segment'])
        self.journal_root.mkdir(parents=True,exist_ok=True)
        path = self.journal_root/(uuid.uuid4().hex+'.jsonl')
        completed = 0
        # Open journal before executing DDL; fail closed if audit location is unavailable.
        with path.open('x',encoding='utf-8') as journal:
            def record(event, **details):
                import os
                journal.write(json.dumps({'time':dt.datetime.now(dt.timezone.utc).isoformat(),
                                          'event':event,**details},default=str)+'\n')
                journal.flush(); os.fsync(journal.fileno())
            record('START',plan=current,actor_role=role)
            try:
                for index, sql in enumerate(current['statements']):
                    record('STATEMENT_START',index=index)
                    with engine.begin() as conn:
                        conn.execute(text(sql))
                    completed += 1
                    record('STATEMENT_DONE',index=index)
                record('SUCCESS',completed=completed)
            except Exception as exc:
                record('FAILED',completed=completed,error_type=type(exc).__name__)
                return {'status':'PARTIAL_OR_FAILED','completed':completed,'total':len(current['statements']),
                        'journal':str(path),'message':'DDL may already be committed. Inspect the journal and database, then preview again.'}
        return {'status':'SUCCESS','completed':completed,'total':len(current['statements']),'journal':str(path)}
