"""One invocation: fresh scoped planning, durable plan, guarded apply, result."""
import uuid
from collections import Counter
from pathlib import Path
from model.cash_recovery import make_plan, apply_plan, write_json_new
from model.cash_restore import guard, require
from model.storage_inventory import safe_root


def run_recovery(report,root,store,operations_root,*,writers_stopped=False,scope_plan=None,now=None,progress=None):
    require(writers_stopped,'writers_stopped_ack_required')
    root=safe_root(root)
    skipped=0
    if scope_plan is not None:
        require(scope_plan.get('operation')=='INSERT_ONLY_CASH_RECOVERY' and scope_plan.get('format_version')==1,'invalid_scope_plan')
        require(Path(scope_plan['target_root']).resolve()==root,'configured_root_changed')
        entries=scope_plan['entries']
        require(all(e['status'] in ('READY','UNRESOLVED','ALREADY_CONSISTENT') for e in entries),'invalid_scope_status')
        wanted={e['relative_path'] for e in entries if e['status']!='ALREADY_CONSISTENT'}
        available=Counter(p['relative_path'] for p in report['partitions'])
        require(all(available[p]==1 for p in wanted),'scope_partitions_missing_or_duplicate')
        skipped=sum(e['status']=='ALREADY_CONSISTENT' for e in entries)
        report=dict(report,partitions=[p for p in report['partitions'] if p['relative_path'] in wanted])
    op=guard(operations_root)
    require(root!=op and root not in op.parents and op not in root.parents,'operation_directory_overlaps_data')
    run=guard(op/('run-'+uuid.uuid4().hex));run.mkdir(parents=True,exist_ok=False)
    plan=make_plan(report,root,store,progress,now,prefer_sql_exact=True)
    write_json_new(run/'plan.json',plan)
    if plan['summary']['statuses'].get('READY',0):
        result=apply_plan(plan,root,store,op,writers_stopped=True,now=now,progress=progress)
    else:
        unresolved=plan['summary']['statuses'].get('UNRESOLVED',0)
        result={'status':'PARTIAL' if unresolved else 'COMPLETE','applied_statuses':{},'inserted_rows':0,
                'restored_files':0,'unresolved_plan_entries':unresolved,'outcomes':[]}
    result.update(plan_summary=plan['summary'],previously_consistent_not_rechecked=skipped,
                  plan=str(run/'plan.json'),report=str(run/'result.json'),
                  scope='Supplied preview candidates only; skipped previously consistent partitions are not freshly certified.')
    write_json_new(run/'result.json',result)
    return result
