"""
controller/sinks.py
Part 3 integration contract (spec Section 29). Neither controller
implements database/Parquet/CSV storage -- they only write to a
CandleSink, which Part 3 will implement for real. NoOpCandleSink is the
default used until then: it logs counts and does nothing durable.

Both single-candle and batch writes are part of the interface (spec
Section 29: "should be able to accept single candle / batch of
candles") -- historical_controller naturally has full batches;
live_controller calls write_one() per completed candle to keep latency
low, matching "the live path should preferably support batching...
without introducing unacceptable latency."
"""

import logging
from typing import Optional, Protocol

from model.processing.models import Candle

log = logging.getLogger("market_data.controller.sinks")


class CandleSink(Protocol):
    """Interface Part 3's storage layer (MySQL/Parquet/CSV) must
    implement."""

    def write_one(self, candle: Candle) -> None:
        ...

    def write_batch(self, candles: list) -> None:
        ...


class NoOpCandleSink:
    """Default sink until Part 3 exists. Durably stores nothing --
    logs what WOULD have been written, so historical/live runs are
    still fully observable without a storage layer."""

    def write_one(self, candle: Candle) -> None:
        log.debug(f"NoOpCandleSink: would write 1 candle: {candle.fyers_symbol} {candle.timestamp}")

    def write_batch(self, candles: list) -> None:
        log.info(f"NoOpCandleSink: would write {len(candles)} candle(s) (no storage layer configured yet)")


class CompositeCandleSink:
    """Fans out every write to multiple sinks (e.g. MySQL + Parquet
    simultaneously, per data_settings.yaml storage.* toggles). Spec
    Section 29: MySQL and Parquet must represent the same canonical
    dataset -- writing to both from the SAME already-aggregated/
    validated candle (not two independent aggregation runs) is how
    this module guarantees that."""

    def __init__(self, sinks: list):
        self._sinks = sinks

    def write_one(self, candle: Candle) -> None:
        return self.write_batch([candle])

    def write_batch(self, candles: list):
        self.last_conflicts = 0
        self.last_stored = 0
        accepted = candles
        for sink in self._sinks:
            from controller.worker_lifecycle import check
            check()
            result = sink.write_batch(accepted)
            self.last_conflicts += getattr(sink, "last_conflicts", 0)
            if hasattr(sink,"last_stored"):self.last_stored = sink.last_stored
            if isinstance(result, list):
                accepted = result
        return accepted


class JobRecorder(Protocol):
    """Interface for recording ingestion job history (the
    ingestion_jobs table). Kept separate from CandleSink since job
    records and candle data have completely different shapes and
    lifecycles."""

    def record(
        self, job_type: str, fyers_symbol: Optional[str], timeframe: Optional[str],
        from_date: Optional[str], to_date: Optional[str], status: str,
        raw_count: Optional[int] = None, valid_count: Optional[int] = None,
        invalid_count: Optional[int] = None, error_message: Optional[str] = None,
    ) -> int:
        ...


class NoOpJobRecorder:
    """Default recorder when MySQL storage is disabled -- job history
    is then only visible in log files, which is an explicit, known
    limitation rather than a silent gap."""

    def record(self, job_type, fyers_symbol, timeframe, from_date, to_date, status,
               raw_count=None, valid_count=None, invalid_count=None, error_message=None) -> int:
        log.debug(f"NoOpJobRecorder: not persisting job record ({job_type}, {fyers_symbol}, {status})")
        return -1
