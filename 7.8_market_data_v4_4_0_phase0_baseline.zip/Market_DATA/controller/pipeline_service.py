"""UI-independent services for persisted Cash verification and operations."""
import datetime as dt
import json
import threading
from pathlib import Path
from model.config.market_calendar import IST, expected_starts, calendar_verified
from model.quality import compare_rows, integrity, stamp
from model.quality_store import QualityStore
from controller.verification_controller import CashReader, run_verification
from controller.fno_jobs import FnoJobRunner, JobOutcome
from model.pipeline_errors import FetchPreflightError


def require_admin(role):
    if role!='admin':raise PermissionError('Administrator access required')


class PipelineService:
    def __init__(self,env=None,data_settings=None,timeframes=None,instruments=None,engine=None,root=None):
        from model.config.env_loader import load_env_config
        from model.config.data_settings import load_data_settings
        from model.config.timeframe_settings import load_timeframe_settings
        from model.config.instrument_loader import load_instrument_registry
        from model.storage.mysql import get_engine,build_db_url
        self.env=env or load_env_config();self.settings=data_settings or load_data_settings()
        self.timeframes=timeframes or load_timeframe_settings();self.instruments=instruments or load_instrument_registry()
        if not self.settings.storage.mysql_enabled:raise ValueError('Persisted pipeline operations require MySQL enabled')
        cfg=self.env.db
        self.engine=engine or get_engine(build_db_url(cfg.host,cfg.port,cfg.name,cfg.user,cfg.password))
        self.store=QualityStore(self.engine);self.reader=CashReader(self.engine,root)
        from model.monitoring import configure
        try:configure(self.engine)
        except Exception:pass
    def validate(self,params):
        a,b=dt.date.fromisoformat(params['from']),dt.date.fromisoformat(params['to'])
        if a>b or (b-a).days>3660:raise ValueError('Use an ordered range of at most 3661 days')
        names=params.get('symbols') or []
        if not names:raise ValueError('Select at least one instrument')
        for n in names:self.instruments.get(n)
        return a,b
    def submit(self,role,kind,params):
        require_admin(role);self.validate(params)
        params={**params,'symbols':sorted(set(params['symbols'])),'use_parquet':self.settings.storage.parquet_enabled}
        if kind=='WORKFLOW':
            from controller.unified_workflow import validate_spec
            validate_spec(params,'CASH')
        if kind in ('SMART_FETCH','WORKFLOW'):
            preview=self.smart_preview(params)
            if preview['blocked']:raise FetchPreflightError(preview)
        return self.store.submit(kind,params)
    def action(self,role,action,jid):
        require_admin(role)
        if action=='reload_credentials':
            from model.config.env_loader import load_env_config
            self.env=load_env_config(reload=True)
            return 'Credentials reloaded; provider authentication is checked on the next request'
        if action=='cancel':return self.store.request_cancel(jid)
        if action=='resume':return self.store.resume(jid)
        if action=='run':return self.runner().run_until_empty()
        raise ValueError('Unknown action')
    def smart_preview(self,params,now=None):
        a,b=self.validate(params);now=now or dt.datetime.now(IST)
        items=[];complete=0;blocked=[];inspected=0;warnings=[]
        # Plan is bounded by selected symbol-days; no provider call in a preview.
        if len(params['symbols'])*((b-a).days+1)>5000:raise ValueError('Preview at most 5000 symbol-days at a time')
        for name in params['symbols']:
            inst=self.instruments.get(name);meta=self.reader.instrument(inst.fyers_symbol)
            day=a
            while day<=b:
                inspected+=1;expected=set(expected_starts(day,now=now,lag_seconds=60))
                if not calendar_verified(day):
                    warnings.append({'symbol':name,'date':str(day),'reason':'Calendar not verified; request provider data without session certification'})
                    start=dt.datetime.combine(day,dt.time.min,IST)
                    expected={start+dt.timedelta(minutes=m) for m in range(1440)
                              if start+dt.timedelta(minutes=m+1)<=now}
                if not expected:day+=dt.timedelta(days=1);continue
                sql=self.reader.sql_day(meta['id'] if meta else None,'1m',day)
                pq,_=self.reader.parquet_day(inst.fyers_symbol,'1m',day) if self.settings.storage.parquet_enabled else (sql,None)
                try:comparison=compare_rows(sql,pq)
                except Exception:comparison={'malformed':1}
                if any(v for k,v in comparison.items() if isinstance(v,int)):
                    blocked.append({'symbol':name,'date':str(day),'reason':'Storage conflict; verification only, no automatic repair',
                                    'details':comparison,'next_action':'Stop live writers and run MySQL vs Parquet verification for this symbol/date. No automatic overwrite.'})
                elif any(self._stored_integrity(rows,inst.fyers_symbol,day,now) for rows in (sql,pq)):
                    blocked.append({'symbol':name,'date':str(day),'reason':'Invalid stored data'})
                else:
                    present={stamp(r['candle_timestamp']) for r in sql if r['status']=='CLOSED'}
                    missing=sorted(expected-present)
                    if not missing:complete+=1
                    else:
                        from controller.coverage_controller import compress_ranges
                        for start,end,n in compress_ranges(missing):
                            items.append({'symbol':name,'from':start.isoformat(),'to':end.isoformat(),'missing':n})
                day+=dt.timedelta(days=1)
        return {'items':items,'requests_estimate':len(items),'complete_symbol_days':complete,'inspected':inspected,'blocked':blocked,'warnings':warnings,
                'note':'Only missing closed minutes are requested. Quiet instruments may remain sparse.'}
    @staticmethod
    def _stored_integrity(rows,symbol,day,now):
        if calendar_verified(day):
            result=integrity(rows,'1m',day,now)
            return result['invalid'] or result['duplicates']
        if not rows:return False
        from model.cash_inventory_preview import check_rows
        checked=check_rows([dict(r,fyers_symbol=symbol,timeframe='1m') for r in rows],symbol,day,now)
        return bool(checked['issues'])

    def smart_fetch(self,handle):
        from model.fyers.auth import get_authenticated_client
        from model.processing.normalizer import normalize_historical_candle
        from model.processing.validator import validate_candles
        from model.storage.mysql import MySQLCandleSink
        from model.storage.parquet import ParquetCandleSink
        from controller.sinks import CompositeCandleSink
        plan=self.smart_preview(handle.params)
        if plan['blocked']:return JobOutcome('PARTIAL',plan,'Preview contains unresolved findings')
        out={'done':0,'total':len(plan['items']),'current':'','stored':0,'remaining_missing':0,'errors':[],'warnings':plan.get('warnings',[])}
        if not plan['items']:return JobOutcome('SUCCESS',{**out,'reason':'Requested range already covered'})
        client=get_authenticated_client(self.env.fyers)
        sinks=[MySQLCandleSink(self.engine,self.instruments)]
        if self.settings.storage.parquet_enabled:sinks.append(ParquetCandleSink(str(self.reader.root)))
        sink=CompositeCandleSink(sinks)
        from model.fno.history_client import classify_response,AUTH,RATE_LIMIT,OK,NO_DATA
        from model.fno.config import load_fno_settings
        hs=load_fno_settings().history
        from model.fyers.rate_limiter import acquire_shared
        for item in plan['items']:
            stop=handle.stop_outcome(out)
            if stop:return stop
            inst=self.instruments.get(item['symbol']);start=stamp(item['from']);end=stamp(item['to'])
            out['current']=item['symbol']+' '+item['from'];self.store.progress(handle.id,out)
            response=None
            for attempt in range(hs.max_retries+1):
                stop=handle.stop_outcome(out)
                if stop:return stop
                acquire_shared()
                stop=handle.stop_outcome(out)
                if stop:return stop
                handle.add(requests_made=1)
                try:
                    response=client.history(data={'symbol':inst.fyers_symbol,'resolution':'1','date_format':'0',
                        'range_from':str(int(start.timestamp())),'range_to':str(int(end.timestamp())),'cont_flag':'0'})
                    kind,msg,code=classify_response(response,hs)
                except (OSError,TimeoutError) as exc:kind,msg='NETWORK',type(exc).__name__
                if kind==AUTH:
                    from model.monitoring import emit
                    emit('TOKEN_EXPIRED',{},severity='ERROR')
                    return JobOutcome('INTERRUPTED',out,'FYERS authentication required; update token and explicitly resume')
                if kind not in (RATE_LIMIT,'NETWORK'):break
                if attempt<hs.max_retries:
                    handle.add(retry_count=1)
                    import time
                    handle._shutdown.wait(min(8,hs.initial_backoff_seconds*hs.backoff_multiplier**attempt))
            if kind not in (OK,NO_DATA):
                out['errors'].append({'scope':out['current'],'error':kind});out['done']+=1;continue
            stop=handle.stop_outcome(out)
            if stop:return stop
            raw=(response or {}).get('candles') or [];valid=[];invalid=0
            for r in raw:
                try:
                    c=normalize_historical_candle(r,inst,'1m')
                    results=validate_candles([c],self.instruments)
                    if start<=c.timestamp<=end and results[0].status!='invalid':valid.append(c)
                    else:invalid+=1
                except Exception:invalid+=1
            stop=handle.stop_outcome(out)
            if stop:return stop
            if valid:
                sink.write_batch(valid)
            else:
                sink.last_stored=0; sink.last_conflicts=0
            handle.add(rows_raw=len(raw),rows_valid=len(valid),rows_invalid=invalid,rows_stored=sink.last_stored)
            out['stored']+=sink.last_stored;out['done']+=1
            if invalid or getattr(sink,'last_conflicts',0):out['errors'].append({'scope':out['current'],'error':'Rejected/conflicting rows'})
            self.store.progress(handle.id,out)
        # Read-only post-check; never delete/rebuild derived bars as a side effect.
        remaining=self.smart_preview(handle.params)
        out['remaining_missing']=sum(x['missing'] for x in remaining['items'])
        out['post_fetch_blocked']=remaining['blocked']
        return JobOutcome('PARTIAL' if out['errors'] or out['remaining_missing'] or remaining['blocked'] else 'SUCCESS',out)
    def aggregate(self,handle):
        from controller.timeframe_controller import generate_timeframe_for_instrument
        from model.storage.mysql import MySQLCandleSink,read_1m_candles,MySQLJobRecorder
        from model.storage.parquet import ParquetCandleSink
        from controller.sinks import CompositeCandleSink
        tfs=handle.params.get('timeframes') or [t.name for t in self.timeframes.derived_timeframes]
        out={'done':0,'total':len(handle.params['symbols'])*len(tfs),'current':'','results':[]}
        sinks=[MySQLCandleSink(self.engine,self.instruments)]
        if self.settings.storage.parquet_enabled:sinks.append(ParquetCandleSink(str(self.reader.root)))
        sink=CompositeCandleSink(sinks)
        reader=lambda symbol,a,b,inst:read_1m_candles(self.engine,symbol,a,b,inst)
        for name in handle.params['symbols']:
            for tf in tfs:
                stop=handle.stop_outcome(out)
                if stop:return stop
                out['current']=name+' '+tf
                r=generate_timeframe_for_instrument(self.instruments.get(name),tf,handle.params['from'],handle.params['to'],reader,
                    self.instruments,self.settings,sink,job_recorder=MySQLJobRecorder(self.engine))
                detail={'symbol':name,'timeframe':tf,'status':r.status,'error':r.error}
                for field in ('reason','source_1m_count','derived_count','valid_count','invalid_count',
                              'missing_1m_count','expected_1m_count','incomplete_bucket_count','pending_bucket_count',
                              'skipped_bucket_count','rejected_source_count','unknown_calendar_days'):
                    if hasattr(r,field):detail[field]=getattr(r,field)
                out['results'].append(detail);out['done']+=1;self.store.progress(handle.id,out)
        state='SUCCESS' if out['results'] and all(x['status']=='success' for x in out['results']) else 'PARTIAL'
        if not out['results'] or all(x['status']=='no_source_data' for x in out['results']):state='NO_DATA'
        return JobOutcome(state,out)
    def end_of_day(self,handle):
        fetched=self.smart_fetch(handle)
        if fetched.state!='SUCCESS':return fetched
        return self.aggregate(handle)
    def runner(self):
        from controller.unified_workflow import cash_workflow
        return FnoJobRunner(self.store,{'VERIFY':lambda h:run_verification(h,self.reader,self.instruments,self.store),
            'SMART_FETCH':self.smart_fetch,'AGGREGATION':self.aggregate,'SCHEDULE_EOD':self.end_of_day,'WORKFLOW':lambda h:cash_workflow(self,h)},10,90,segment='CASH')


_threads={}
_lock=threading.Lock()
def start_worker(service):
    from controller import worker_lifecycle as lifecycle
    lifecycle.check()
    key=str(service.engine.url)
    with _lock:
        if key in _threads and _threads[key].is_alive():return
        runner=service.runner()
        def work():runner.recover();runner.run_until_empty()
        thread=threading.Thread(target=work,daemon=True,name='cash-pipeline-worker')
        lifecycle.register(runner.shutdown,thread)
        _threads[key]=thread;thread.start()
