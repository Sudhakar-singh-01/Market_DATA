"""One-password GET integration probe; writes only a unique diagnostic JSON report."""
import argparse
import datetime as dt
import getpass
import json
import os
import uuid


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--date',required=True,type=dt.date.fromisoformat)
    p.add_argument('--cash-symbol',required=True)
    p.add_argument('--fno-symbol')
    p.add_argument('--underlying')
    p.add_argument('--port',type=int,default=8000)
    args=p.parse_args(argv)
    if not 1<=args.port<=65535:p.error('Invalid port')
    from client import MarketDataClient
    from client.read_probe import run_probe
    from model.config.runtime_paths import state_path
    from model.cash_restore import guard
    folder=guard(state_path('recovery/read_checks'));folder.mkdir(parents=True,exist_ok=True)
    report=folder/('read-check-'+uuid.uuid4().hex+'.json')
    try:
        password=getpass.getpass('Tool admin password: ')
        with MarketDataClient(base_url=f'http://127.0.0.1:{args.port}',username='admin',password=password,
                              timeout=120,max_retries=0) as client:
            result=run_probe(client,str(args.date),args.cash_symbol,fno_symbol=args.fno_symbol,
                             underlying=args.underlying,progress=lambda r:print(json.dumps(r),flush=True))
    except Exception as exc:
        result=dict(status='STOPPED',error=type(exc).__name__,http_status=getattr(exc,'status_code',None),
                    market_data_modified=False,sql_modified=False)
    result['report']=str(report)
    with report.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2);stream.flush();os.fsync(stream.fileno())
    print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
    return 0 if result['status']=='SCOPED_READ_CHECK_PASS' else 2


if __name__=='__main__':raise SystemExit(main())
