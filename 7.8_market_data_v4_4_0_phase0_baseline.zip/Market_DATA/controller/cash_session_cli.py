"""One-run SQL-exact session preservation restore; no quality certification."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--result',type=Path,required=True)
    p.add_argument('--writers-stopped',action='store_true');args=p.parse_args(argv)
    if not args.writers_stopped:p.error('--writers-stopped required')
    if not args.result.is_file():p.error(f'Resolution report not found: {args.result}')
    catalog=None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.config.runtime_paths import state_path
        from model.cash_recovery import RecoveryStore
        from model.cash_session_restore import restore_sessions
        catalog=configured_catalog();root=catalog.roots['CASH']
        if root is None:raise ValueError('Cash Parquet disabled')
        result=restore_sessions(json.loads(args.result.read_text(encoding='utf-8-sig')),root,
            RecoveryStore(catalog.engine('CASH')),state_path('recovery/cash_session_restore'),writers_stopped=True)
        print(json.dumps({k:v for k,v in result.items() if k not in ('session_entries','outcomes')}))
        return 2 if result['status']=='PARTIAL' else 0
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error':type(exc).__name__}));return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
