"""One-time, non-destructive copy into an opt-in permanent runtime profile."""
import argparse
import hashlib
import json
from itertools import chain
import os
from pathlib import Path
import shutil
import tempfile

import yaml
from model.storage_scope import owned_paths, validate_storage_roots

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _safe(path):
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink() or getattr(part, 'is_junction', lambda: False)():
            raise ValueError('Symlinks and junctions are not supported')
    return path.resolve()


def _metadata(path):
    stat = path.stat()
    return (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino, stat.st_dev)


def _digest(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _inventory(trees):
    result = {}
    for source, destination, excluded in trees:
        for path in owned_paths(source, excluded):
            if path.is_file():
                target = destination / path.relative_to(source)
                if target in result:
                    raise ValueError('Duplicate destination path')
                result[target] = (path, _metadata(path))
            elif not path.is_dir():
                raise ValueError('Only regular files and directories are supported')
    return result


def _directories(trees):
    return {destination / path.relative_to(source): (path, _metadata(path))
            for source, destination, excluded in trees
            for path in chain((source,), owned_paths(source, excluded)) if path.is_dir()}


def initialize_profile(home, cash_source, fno_source, *, apply=False,
                       writers_stopped=False, project_root=None, authenticate=None):
    """Validate/preview by default; apply requires stopped writers and admin auth.

    Sources are read only. A private sibling staging directory is published only
    after checksum and inventory checks. This copies state, not DB/data parity.
    """
    project = _safe(project_root or PROJECT_ROOT)
    target = _safe(home)
    cash, fno = _safe(cash_source), _safe(fno_source)
    if target.exists():
        raise ValueError('Target profile already exists; choose a new directory')
    for source in (project, cash, fno):
        if target == source or target in source.parents or source in target.parents:
            raise ValueError('Target must be disjoint from project and data sources')
    if not cash.is_dir() or not fno.is_dir():
        raise ValueError('Both exact existing data source directories are required')
    roots = validate_storage_roots({'CASH': cash, 'FNO': fno})
    required = ('config/.env', 'config/data_settings.yaml', 'config/timeframe_settings.yaml',
                'config/fno_settings.yaml', 'config/holidays.yaml',
                'instruments/stocks.yaml', 'instruments/indices.yaml')
    for relative in required:
        if not _safe(project / relative).is_file():
            raise ValueError('Required source configuration is missing')
    settings = yaml.safe_load((project / 'config/fno_settings.yaml').read_text(encoding='utf-8'))
    if not isinstance(settings, dict) or not isinstance(settings.get('parquet'), dict):
        raise ValueError('FNO configuration requires parquet settings')
    trees = [(project / 'config', Path('config'), ()),
             (project / 'instruments', Path('instruments'), ()),
             (cash, Path('data/cash'), roots['CASH']['excluded_subtrees']),
             (fno, Path('data/fno'), ())]
    for name in ('runtime', 'backups', 'recovery', 'logs'):
        source = _safe(project / name)
        if source.exists():
            if not source.is_dir():
                raise ValueError('Runtime state source must be a directory')
            trees.append((source, Path(name), ()))
    inventory = _inventory(trees)
    directories = _directories(trees)
    report = {'status': 'PREVIEW_ONLY', 'home': str(target), 'files': len(inventory),
              'bytes': sum(item[1][0] for item in inventory.values()),
              'state': 'State will be copied; parity is not verified.',
              'enable_windows': 'setx TIOS_HOME "' + str(target) + '"'}
    if not apply:
        return report
    if not writers_stopped:
        raise ValueError('--writers-stopped is required: stop all writers before applying')
    if authenticate is None:
        from controller.workflow_cli import authenticate_admin
        authenticate = authenticate_admin
    authenticate()
    # Do not create an arbitrary chain of parent directories as a side effect.
    if not target.parent.is_dir():
        raise ValueError('Target parent directory must already exist')
    lock = target.parent / ('.' + target.name + '.init.lock')
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    staging = None
    try:
        os.close(descriptor)
        if target.exists():
            raise ValueError('Target profile already exists')
        staging = Path(tempfile.mkdtemp(prefix='.' + target.name + '.staging-', dir=target.parent))
        for destination in directories:
            (staging / destination).mkdir(parents=True, exist_ok=True)
        for relative, (source, before) in inventory.items():
            if _metadata(source) != before:
                raise RuntimeError('Source changed during initialization')
            destination = staging / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            if _digest(source) != _digest(destination) or _metadata(source) != before:
                raise RuntimeError('Source changed or checksum verification failed')
        if _inventory(trees) != inventory or _directories(trees) != directories:
            raise RuntimeError('Source inventory changed during initialization')
        from dotenv import set_key
        set_key(str(staging / 'config/.env'), 'CASH_DATA_ROOT', (target / 'data/cash').as_posix())
        settings['parquet']['root'] = (target / 'data/fno').as_posix()
        (staging / 'config/fno_settings.yaml').write_text(yaml.safe_dump(settings, sort_keys=False), encoding='utf-8')
        for name in ('runtime', 'backups', 'recovery', 'logs'):
            (staging / name).mkdir(exist_ok=True)
        if _inventory(trees) != inventory or _directories(trees) != directories:
            raise RuntimeError('Source inventory changed before publication')
        if target.exists():
            raise ValueError('Target profile already exists')
        staging.rename(target)
        staging = None
        report.update(status='INITIALIZED', checksums_verified=len(inventory),
                      state='State copied; parity is not verified.')
        return report
    finally:
        if staging is not None:
            shutil.rmtree(staging)
        lock.unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init')
    init.add_argument('--home', required=True, type=Path)
    init.add_argument('--cash-source', required=True, type=Path)
    init.add_argument('--fno-source', required=True, type=Path)
    init.add_argument('--apply', action='store_true')
    init.add_argument('--writers-stopped', action='store_true')
    args = parser.parse_args(argv)
    try:
        result = initialize_profile(args.home, args.cash_source, args.fno_source,
                                    apply=args.apply, writers_stopped=args.writers_stopped)
        print(json.dumps(result))
        return 0
    except Exception as exc:
        # Configuration/provider error text can contain credentials.
        print(json.dumps({'status': 'FAILED', 'error': type(exc).__name__,
                          'message': 'Initialization failed; check source paths, stopped writers, authentication, and a new target directory.'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
