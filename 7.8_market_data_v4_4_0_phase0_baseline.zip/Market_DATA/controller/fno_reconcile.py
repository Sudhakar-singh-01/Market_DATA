"""
controller/fno_reconcile.py
MySQL and Parquet are NOT one transaction (order: MySQL, then Parquet, then checkpoint).
Reconcile finds, and with repair=True fixes, disagreement:

  manifest vs files   VERIFIED row, file missing / checksum differs -> quarantined
                      WRITING row (crash window) -> file validated, promoted or quarantined
                      file with no manifest row (orphan)             -> moved to quarantine/
                      stale temp files                               -> removed
  MySQL vs Parquet    per (contract, day): rows only in one store are copied to the other
                      (through the normal write policies, so conflicts stay reported)
  checkpoints         a VERIFIED range with no candle in MySQL is REPORTED (never auto-fixed:
                      the remedy is a separate, confirmed checkpoint reset)
Dry-run by default. Only touches fno_* tables and files under the FNO root.
"""
import datetime
import logging
import os
import uuid
from dataclasses import dataclass, field

import pandas as pd

from model.fno.parquet_store import FnoParquetStore, frame_to_candles, candles_to_frame, KEY, COLUMNS, CHAIN_COLUMNS, CHAIN_KEY, _typed
from model.fno.comparison import frames_equal

log = logging.getLogger("market_data.fno.reconcile")


@dataclass
class ReconcileReport:
    findings: list = field(default_factory=list)       # dicts: kind, target, detail, repaired(bool)
    repaired: int = 0

    def add(self, kind, target, detail="", repaired=False):
        self.findings.append({"kind": kind, "target": str(target), "detail": detail, "repaired": repaired})
        self.repaired += bool(repaired)

    @property
    def ok(self) -> bool:
        return all(f["repaired"] for f in self.findings)

    def kinds(self) -> dict:
        out = {}
        for f in self.findings:
            out[f["kind"]] = out.get(f["kind"], 0) + 1
        return out


def _quarantine_file(store: FnoParquetStore, rel: str) -> None:
    src = store.abs_path(rel)
    q = store._guard(store.root / "quarantine"); q.mkdir(parents=True, exist_ok=True)
    os.replace(src, q / f"{uuid.uuid4().hex[:8]}_{src.name}")


def _check_manifest_vs_files(repo, store, report, repair):
    known = set()
    offset = 0
    while True:
        page = repo.manifest_list(limit=500, offset=offset)             # every dataset: candles AND option_chain
        if not page:
            break
        offset += len(page)
        for m in page:
            rel = m["relative_path"]; known.add(rel)
            path = store.abs_path(rel)
            if m["status"] == "QUARANTINED":
                continue
            if not path.exists():
                fixed = False
                if repair:
                    repo.manifest_quarantine(rel, "reconcile: file missing"); fixed = True
                report.add("manifest_file_missing", rel, f"status {m['status']}", fixed)
                continue
            if m["status"] == "VERIFIED":
                if FnoParquetStore.sha256(path) != m["checksum"]:
                    fixed = False
                    if repair:
                        _quarantine_file(store, rel); repo.manifest_quarantine(rel, "reconcile: checksum mismatch"); fixed = True
                    report.add("checksum_mismatch", rel, "file changed after it was verified", fixed)
            elif m["status"] == "WRITING":
                try:
                    chain = m["dataset"] == "option_chain"
                    df = pd.read_parquet(path) if chain else _typed(pd.read_parquet(path))
                    ts_col = "captured_at" if chain else "candle_timestamp"
                    if chain:
                        if list(df.columns) != CHAIN_COLUMNS or df.duplicated(subset=CHAIN_KEY).any():
                            raise ValueError("chain snapshot file failed validation")
                    else:
                        FnoParquetStore._validate(path, df)
                    fixed = False
                    if repair:
                        repo.manifest_verify(rel, df[ts_col].min().to_pydatetime(), df[ts_col].max().to_pydatetime(), len(df),
                                             FnoParquetStore.sha256(path)); fixed = True
                    report.add("interrupted_write_valid", rel, "WRITING row with a valid file", fixed)
                except Exception as exc:
                    fixed = False
                    if repair:
                        _quarantine_file(store, rel); repo.manifest_quarantine(rel, f"reconcile: invalid file ({exc})"); fixed = True
                    report.add("interrupted_write_invalid", rel, str(exc), fixed)
    for rel in store.list_candle_files() + store.list_chain_files():
        if rel not in known:
            fixed = False
            if repair:
                _quarantine_file(store, rel); fixed = True
            report.add("orphan_file", rel, "no manifest row", fixed)
    for rel in store.stale_temp_files():
        fixed = False
        if repair:
            store._guard(store.root / rel).unlink(); fixed = True
        report.add("stale_temp_file", rel, "", fixed)


def _parquet_rows_by_contract_day(store, repo, from_date, to_date, report) -> dict:
    out: dict = {}
    for rel in store.list_candle_files():
        m = repo.manifest_get(rel)
        if not m or m["status"] != "VERIFIED" or m["timeframe"] != "1m":
            continue
        day = datetime.date.fromisoformat(rel.rsplit("date=", 1)[1][:10])
        if (from_date and day < from_date) or (to_date and day > to_date):
            continue
        try:
            df = store.read_partition(rel)
        except Exception as exc:                       # corrupted file: report, never crash the diagnosis
            report.add("unreadable_file", rel, f"{type(exc).__name__}: {exc}")
            continue
        if df is None:
            continue
        for cid, g in df.groupby("contract_id"):
            out[(int(cid), day)] = g
    return out


def _check_mysql_vs_parquet(repo, store, report, repair, from_date, to_date):
    pq = _parquet_rows_by_contract_day(store, repo, from_date, to_date, report)
    my = repo.daily_counts_all("1m", from_date, to_date)
    for key in sorted(set(pq) | set(my)):
        cid, day = key
        n_pq = len(pq[key]) if key in pq else 0
        n_my = my.get(key, 0)
        if n_pq == n_my and key in pq and key in my:
            if frames_equal(candles_to_frame(repo.fetch_candles(cid,"1m",day,day)),pq[key]):
                continue
        fixed = False
        if repair:
            my_c = repo.fetch_candles(cid, "1m", day, day)
            my_ts = {c.naive_ist() for c in my_c}
            pq_c = frame_to_candles(pq[key]) if key in pq else []
            pq_ts = {c.naive_ist() for c in pq_c}
            only_pq = [c for c in pq_c if c.naive_ist() not in my_ts]
            only_my = [c for c in my_c if c.naive_ist() not in pq_ts]
            if only_pq:
                repo.upsert_candles(only_pq)
            if only_my:
                store.write_candles(only_my, repo.contract_meta({cid}))
            meta = repo.contract_meta({cid})
            if cid in meta:
                und,expiry = meta[cid]
                rel = store.relative_candle_path("1m",und,expiry,day)
                fixed = frames_equal(candles_to_frame(repo.fetch_candles(cid,"1m",day,day)),store.read_partition(rel))
        report.add("mysql_parquet_mismatch", f"contract={cid} date={day}", f"mysql={n_my} parquet={n_pq}", fixed)


def _check_chain_mysql_vs_parquet(repo, store, report, repair):
    """Option-chain snapshots: per (underlying, day) MySQL and Parquet must hold the same rows."""
    import re
    pq = {}
    for rel in store.list_chain_files():
        m = repo.manifest_get(rel)
        if not m or m["status"] != "VERIFIED":
            continue
        try:
            df = store.read_chain_partition(rel)
        except Exception as exc:
            report.add("unreadable_file", rel, f"{type(exc).__name__}: {exc}"); continue
        und = re.search(r"underlying=([^/]+)/", rel).group(1)
        pq[(und, datetime.date.fromisoformat(rel.rsplit("date=", 1)[1][:10]))] = df
    my = repo.chain_counts_by_day()
    for key in sorted(set(pq) | set(my)):
        und, day = key
        n_pq, n_my = (len(pq[key]) if key in pq else 0), my.get(key, 0)
        if n_pq == n_my:
            continue
        fixed = False
        if repair:
            mine = repo.chain_rows_for_day(und, day)
            have = {(r["batch_id"], r["contract_id"]) for r in mine}
            if key in pq:
                missing_in_mysql = pq[key][[(b, c) not in have for b, c in zip(pq[key]["batch_id"], pq[key]["contract_id"])]]
                for batch, g in missing_in_mysql.groupby("batch_id"):
                    rows = g.astype(object).where(g.notna(), None).to_dict("records")
                    repo.insert_chain_snapshot(batch, und, rows[0]["captured_at"], rows)
            if mine:
                store.write_chain_snapshot(mine, und, day)          # merges on (batch_id, contract_id): fills what Parquet lacks
            fixed = True
        report.add("chain_mysql_parquet_mismatch", f"underlying={und} date={day}", f"mysql={n_my} parquet={n_pq}", fixed)


def _check_checkpoint_claims(repo, report):
    for cid, job_type, tf, a, b, status in repo.all_checkpoint_ranges("VERIFIED"):
        if job_type != "HISTORICAL":
            continue
        have = repo.daily_counts_all(tf, a, b)
        if not any(k[0] == cid for k in have):
            report.add("checkpoint_claims_absent_data", f"contract={cid} {a}..{b}",
                       "VERIFIED range but no candle in MySQL; remedy = confirmed checkpoint reset")


def reconcile(repo, store, repair: bool = False, from_date=None, to_date=None) -> ReconcileReport:
    report = ReconcileReport()
    _check_manifest_vs_files(repo, store, report, repair)
    _check_mysql_vs_parquet(repo, store, report, repair, from_date, to_date)
    _check_chain_mysql_vs_parquet(repo, store, report, repair)
    _check_checkpoint_claims(repo, report)
    return report
