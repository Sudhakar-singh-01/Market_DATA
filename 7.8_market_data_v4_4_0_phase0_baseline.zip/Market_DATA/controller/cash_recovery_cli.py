"""Combined read-only recovery plan and explicit insert-only apply."""
import argparse
import json
import sys
from pathlib import Path


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    plan=sub.add_parser('plan');plan.add_argument('--preview',type=Path,required=True)
    plan.add_argument('--output',type=Path,required=True)
    plan.add_argument('--prefer-sql-exact',action='store_true',help='For conflicting sources, select only a usable full match to nonempty current SQL; preserve all originals')
    apply=sub.add_parser('apply');apply.add_argument('--plan',type=Path,required=True)
    apply.add_argument('--output',type=Path,required=True)
    apply.add_argument('--writers-stopped',action='store_true')
    run=sub.add_parser('run',help='Fresh plan, eligible repairs and final report in one invocation')
    run.add_argument('--preview',type=Path,required=True)
    run.add_argument('--scope-plan',type=Path,help='Recheck only READY/UNRESOLVED entries of this prior plan')
    run.add_argument('--writers-stopped',action='store_true')
    args=parser.parse_args(argv)
    if args.command!='run' and (args.output.suffix.lower()!='.json' or args.output.exists()):parser.error('--output must be a new JSON filename')
    if args.command in ('apply','run') and not args.writers_stopped:parser.error('--writers-stopped is required')
    input_path=args.plan if args.command=='apply' else args.preview
    if not input_path.is_file():parser.error(f'Input JSON file not found: {input_path}')
    if args.command!='run' and not args.output.parent.is_dir():parser.error(f'Output directory not found: {args.output.parent}')
    if args.command=='run' and args.scope_plan and not args.scope_plan.is_file():parser.error(f'Scope plan not found: {args.scope_plan}')
    catalog=None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.config.runtime_paths import state_path
        from model.cash_recovery import RecoveryStore,make_plan,apply_plan,write_json_new
        catalog=configured_catalog();root=catalog.roots['CASH']
        if root is None:raise ValueError('Cash Parquet storage is disabled')
        store=RecoveryStore(catalog.engine('CASH'))
        if args.command=='run':
            from model.cash_recovery_run import run_recovery
            report=json.loads(args.preview.read_text(encoding='utf-8-sig'))
            scope=json.loads(args.scope_plan.read_text(encoding='utf-8-sig')) if args.scope_plan else None
            result=run_recovery(report,root,store,state_path('recovery/cash_insert_only'),
                writers_stopped=True,scope_plan=scope,progress=lambda n,t:print(f'Checked/recovered {n}/{t}',file=sys.stderr))
            print(json.dumps({k:v for k,v in result.items() if k!='outcomes'}))
            return 0 if result['status']=='COMPLETE' else 2
        if args.command=='plan':
            report=json.loads(args.preview.read_text(encoding='utf-8-sig'))
            result=make_plan(report,root,store,lambda n,t:print(f'Checked {n}/{t}',file=sys.stderr),prefer_sql_exact=args.prefer_sql_exact)
            write_json_new(args.output,result)
            print(json.dumps({'status':'PLAN_CREATED','summary':result['summary'],'plan':str(args.output.absolute())}))
            return 0
        plan=json.loads(args.plan.read_text(encoding='utf-8-sig'))
        result=apply_plan(plan,root,store,state_path('recovery/cash_insert_only'),
            writers_stopped=True,progress=lambda n,t:print(f'Recovery {n}/{t}',file=sys.stderr))
        write_json_new(args.output,result)
        print(json.dumps({k:v for k,v in result.items() if k!='outcomes'}))
        return 0 if result['status']=='COMPLETE' else 2
    except FileNotFoundError as exc:
        print(json.dumps({'status':'STOPPED','error':'FileNotFoundError',
            'missing_path':str(exc.filename) if exc.filename else None,
            'message':'Required file or directory is missing. Check the reported path and TIOS_HOME configuration; do not reset the database.'}))
        return 1
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error':type(exc).__name__,
            'message':'Keep writers stopped; review the plan and recovery journal. Earlier completed partitions are retained. No automatic rollback across stores is claimed.'}))
        return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
