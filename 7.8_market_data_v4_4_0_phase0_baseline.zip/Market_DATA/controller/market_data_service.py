"""Explicit pipeline commands over existing Cash/FNO application services.

Other Python modules can share one facade without reimplementing fetching,
normalization, validation, persistence or jobs. This is intentionally separate
from the GET-only read API. Previewing FNO history may request ATM quotes.
"""
from model.read_contracts import segment_name, ReadRequestError


class MarketDataService:
    def __init__(self, reads=None, cash_factory=None, fno_factory=None):
        self._reads = reads
        self._cash_factory = cash_factory
        self._fno_factory = fno_factory
        self._services = {}

    @property
    def reads(self):
        if self._reads is None:
            from model.database_catalog import configured_catalog
            from model.market_read_service import MarketReadService
            self._reads = MarketReadService(configured_catalog())
        return self._reads

    def _service(self, segment):
        segment = segment_name(segment)
        if segment not in self._services:
            if segment == 'CASH':
                from controller.pipeline_service import PipelineService
                self._services[segment] = (self._cash_factory or PipelineService)()
            else:
                from ui.fno.service import FnoService
                self._services[segment] = (self._fno_factory or FnoService)()
        return self._services[segment]

    @staticmethod
    def _admin(role):
        if role != 'admin':
            raise PermissionError('Administrator access required')

    def preview_fetch(self, segment, params, *, role):
        self._admin(role)
        segment = segment_name(segment)
        service = self._service(segment)
        if segment == 'CASH':
            return {'segment': segment, 'params': dict(params), 'plan': service.smart_preview(params)}
        normalized, estimate, quota = service.historical_preview(params)
        return {'segment': segment, 'params': normalized, 'plan': estimate, 'quota': quota,
                'note': 'ATM preview may call FYERS quotes; submit the returned params to retain the selection'}

    def submit_fetch(self, segment, params, *, role):
        return self._submit(segment, 'SMART_FETCH', 'HISTORICAL_HARVEST', params, role)

    def submit_aggregation(self, segment, params, *, role):
        return self._submit(segment, 'AGGREGATION', 'AGGREGATION', params, role)

    def submit_verification(self, segment, params, *, role):
        return self._submit(segment, 'VERIFY', 'VERIFY', params, role)

    def _submit(self, segment, cash_kind, fno_kind, params, role):
        self._admin(role)
        segment = segment_name(segment)
        service = self._service(segment)
        jid = service.submit(role, cash_kind if segment == 'CASH' else fno_kind, dict(params))
        if segment == 'CASH':
            from controller.pipeline_service import start_worker
            start_worker(service)
        return {'segment': segment, 'job_id': jid, 'submitted': True}

    def job_action(self, segment, action, job_id, *, role):
        self._admin(role)
        if action not in ('cancel', 'resume', 'run'):
            raise ReadRequestError('action must be cancel, resume or run')
        segment = segment_name(segment)
        service = self._service(segment)
        if segment == 'FNO':
            return service.job_action(role, action, job_id)
        if action == 'run':
            from controller.pipeline_service import start_worker
            start_worker(service)
            return 'Worker started'
        result = service.action(role, action, job_id)
        if action == 'resume':
            from controller.pipeline_service import start_worker
            start_worker(service)
        return result

    def preview_workflow(self, segment, params, *, role, timeframes=None):
        """Freeze historical targets before submitting one durable WORKFLOW job."""
        import datetime as dt
        import copy
        from controller.unified_workflow import validate_spec, fingerprint
        from model.read_contracts import date_scope, TIMEFRAMES
        from model.config.market_calendar import IST
        self._admin(role)
        segment=segment_name(segment)
        a,b=date_scope(params.get('from'),params.get('to'),31)
        if b>=dt.datetime.now(IST).date(): raise ValueError('Workflow supports closed historical days only')
        requested=list(timeframes) if timeframes is not None else ['1m']
        if not requested or any(t not in TIMEFRAMES for t in requested): raise ValueError('Select valid workflow timeframes')
        tfs=['1m']+[t for t in TIMEFRAMES[1:] if t in requested]
        service=self._service(segment)
        if segment=='CASH' and not service.settings.storage.parquet_enabled:
            raise ValueError('Workflow requires SQL and Parquet enabled')
        preview=self.preview_fetch(segment,params,role=role)
        p=copy.deepcopy(preview['params'])
        if segment=='CASH':
            if preview['plan'].get('blocked'):
                from model.pipeline_errors import FetchPreflightError
                raise FetchPreflightError(preview['plan'])
            names=sorted(set(p['symbols']))
            targets=[{'internal_name':n,'symbol':service.instruments.get(n).fyers_symbol} for n in names]
            p['symbols']=names
        else:
            from controller.fno_historical import select_contracts,params_to_selection,build_plan
            from controller.unified_workflow import ScopedRepo
            now=dt.datetime.now(IST)
            contracts=select_contracts(service.ctx.repo.get_contracts(status=None),today=now.date(),
                atm=p.get('atm') or {},**params_to_selection(p,service.settings))
            contracts=sorted(contracts,key=lambda c:c.contract_id)
            targets=[{'contract_id':c.contract_id,'symbol':c.fyers_symbol} for c in contracts]
            p['contract_ids']=[t['contract_id'] for t in targets]
            # Estimate exactly the frozen active-contract scope, not unrelated expired contracts.
            plan=build_plan(ScopedRepo(service.ctx.repo,p['contract_ids']),contracts,a,b,now.date(),now,
                            service.settings,all_universe_contracts=contracts)
            limits=service.settings.rate_limits
            preview['plan']=plan.estimate(limits.per_second,limits.per_day,limits.fno_reserve_fraction)
        p.update({'from':str(a),'to':str(b),'timeframes':tfs[1:],'use_parquet':True})
        p['workflow']={'version':1,'segment':segment,'targets':targets,'timeframes':tfs,'from':str(a),'to':str(b)}
        validate_spec(p,segment)
        result={'segment':segment,'params':p,'fetch_plan':preview['plan'],
                'stages':['FETCH']+(['AGGREGATE'] if len(tfs)>1 else [])+['VERIFY','READY'],
                'note':'READY requires strict complete coverage; FNO option silence may block readiness'}
        result['token']=fingerprint(result)
        return result

    def submit_workflow(self, preview, *, role):
        import copy
        from controller.unified_workflow import validate_spec,fingerprint
        self._admin(role)
        reviewed=copy.deepcopy(preview)
        token=reviewed.pop('token',None)
        if token!=fingerprint(reviewed): raise ValueError('Workflow preview changed; preview again')
        segment=segment_name(reviewed['segment'])
        validate_spec(reviewed['params'],segment)
        return self._submit(segment,'WORKFLOW','WORKFLOW',reviewed['params'],role)
