"""Read-only verification after manual import into an isolated recovery database."""
import argparse
import json
from controller.workflow_cli import authenticate_admin
from model.recovery_config import configured_verifier,staged_recoveries


def main():
    parser=argparse.ArgumentParser(description='Verify a manually restored isolated SQL/Parquet recovery copy; never imports SQL')
    parser.add_argument('--list-staged',action='store_true')
    parser.add_argument('--backup-id')
    parser.add_argument('--recovery-id')
    parser.add_argument('--confirmation',help='Exact text: VERIFY tios_recovery_<name>')
    args=parser.parse_args()
    try:
        authenticate_admin()
        service=configured_verifier()
        if args.list_staged:
            print(json.dumps({'recovery_ids':staged_recoveries(service.backup_service,role='admin')}))
            return 0
        if not all((args.backup_id,args.recovery_id,args.confirmation)):
            raise ValueError('Backup ID, recovery ID and exact target confirmation are required')
        report=service.verify(args.backup_id,args.recovery_id,role='admin',confirmation=args.confirmation)
        print(json.dumps(report,default=str,indent=2))
        return 0 if report['status']=='VERIFIED' else 2
    except KeyboardInterrupt:
        print(json.dumps({'status':'INTERRUPTED','message':'Verification interrupted. No import was performed.'}))
        return 130
    except Exception as exc:
        print(json.dumps({'status':'FAILED','error_type':type(exc).__name__,
                         'message':'Check recovery configuration, administrator authentication and review identifiers. No import was performed.'}))
        return 1


if __name__=='__main__':raise SystemExit(main())
