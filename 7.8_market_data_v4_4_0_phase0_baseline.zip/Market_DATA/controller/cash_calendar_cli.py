"""Backed-up Cash calendar update and bounded Parquet-only review; no provider calls."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--apply',action='store_true',help='Apply reviewed Cash 2024/25 calendar additions')
    p.add_argument('--writers-stopped',action='store_true')
    p.add_argument('--check-report',type=Path)
    args=p.parse_args(argv)
    if args.apply and not args.writers_stopped:p.error('--apply requires --writers-stopped')
    if args.check_report and not args.check_report.is_file():p.error('Check report not found')
    stage='admin_auth'
    try:
        from controller.workflow_cli import authenticate_admin
        from model.config.runtime_paths import config_path, state_path
        from model.config.cash_calendar_patch import update_calendar
        from model.cash_calendar_review import review
        from model.storage_scope import cash_data_root
        authenticate_admin();stage='calendar_update'
        result=update_calendar(config_path('config/holidays.yaml'),apply=args.apply,writers_stopped=args.writers_stopped)
        print(json.dumps(result))
        if args.check_report:
            if result['status']=='CALENDAR_PREVIEW_READY':
                print(json.dumps(dict(status='NOT_REVIEWED',reason='apply_calendar_first')));return 2
            stage='parquet_calendar_review'
            report=json.loads(args.check_report.read_text(encoding='utf-8-sig'))
            reviewed=review(report,cash_data_root(),state_path('recovery/cash_calendar_review'),
                            progress=lambda n,t: print(f'Calendar review {n}/{t}',flush=True))
            print(json.dumps({k:v for k,v in reviewed.items() if k!='results'}))
        return 0
    except Exception as exc:
        print(json.dumps(dict(status='STOPPED',stage=stage,error=type(exc).__name__,
            reason=str(exc) if isinstance(exc,ValueError) else 'Inspect configuration/access; retain backup and report.',
            market_data_modified=False,sql_modified=False)))
        return 1


if __name__=='__main__':raise SystemExit(main())
