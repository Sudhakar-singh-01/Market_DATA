"""Admin headless workflow preview/run. Existing job records survive restarts."""
import argparse
import getpass
import json
import os
from pathlib import Path
import time
from controller.market_data_service import MarketDataService
from controller.unified_workflow import public_result
from model.pipeline_errors import FetchPreflightError


def authenticate_admin():
    from dotenv import load_dotenv
    from ui.password_hashing import verify_password
    from model.config.runtime_paths import env_path
    load_dotenv(env_path())
    password=os.environ.get('MARKET_DATA_ADMIN_PASSWORD') or getpass.getpass('Admin password: ')
    if not verify_password(password,os.environ.get('ADMIN_PASSWORD_HASH','')):
        raise PermissionError('Admin authentication failed')


def main():
    parser=argparse.ArgumentParser(description='Unified historical workflow: preview, then explicit run')
    sub=parser.add_subparsers(dest='action',required=True)
    preview=sub.add_parser('preview')
    preview.add_argument('--segment',choices=['CASH','FNO'],required=True)
    preview.add_argument('--params',type=Path,required=True,help='Existing segment fetch parameters as a JSON object')
    preview.add_argument('--timeframes',nargs='+',default=['1m'])
    preview.add_argument('--output',type=Path,required=True,help='New review-plan JSON file')
    run=sub.add_parser('run')
    run.add_argument('--preview',type=Path,required=True)
    run.add_argument('--confirm',action='store_true',help='Submit reviewed workflow and keep process alive until completion')
    args=parser.parse_args()
    try:
        authenticate_admin()
        service=MarketDataService()
        if args.action=='preview':
            if args.output.exists(): raise ValueError('Preview output exists; choose a new path')
            params=json.loads(args.params.read_text(encoding='utf-8'))
            plan=service.preview_workflow(args.segment,params,role='admin',timeframes=args.timeframes)
            with args.output.open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2,default=str)
            print(json.dumps({'status':'PREVIEW_ONLY','path':str(args.output),'stages':plan['stages']}))
            return 0
        if not args.confirm: raise ValueError('--confirm is required to run the reviewed workflow')
        plan=json.loads(args.preview.read_text(encoding='utf-8'))
        submitted=service.submit_workflow(plan,role='admin')
        segment,jid=submitted['segment'],submitted['job_id']
        backend=service._service(segment)
        store=backend.store if segment=='CASH' else backend.jobs
        print(json.dumps({'status':'SUBMITTED','segment':segment,'job_id':jid}),flush=True)
        cancel_requested=False
        while True:
            try:
                job=store.get(jid)
                if not job:raise RuntimeError('Submitted job could not be read')
                if job['state'] not in ('PENDING','RUNNING'):
                    result=public_result(job.get('result'))
                    ready=bool(result and result.get('ready') and job['state']=='SUCCESS')
                    if result is not None: result['ready']=ready
                    print(json.dumps({'job_id':jid,'state':job['state'],'ready':ready,'workflow':result},default=str))
                    return 0 if ready else 2
                time.sleep(1)
            except KeyboardInterrupt:
                if cancel_requested: raise
                service.job_action(segment,'cancel',jid,role='admin')
                cancel_requested=True
                print('Cancellation requested; waiting for the active stage to stop. Press Ctrl+C again to exit immediately.',flush=True)
    except FetchPreflightError as exc:
        print(json.dumps({'status':'BLOCKED','blocked':exc.blocked,'message':str(exc)},default=str))
        return 2
    except KeyboardInterrupt:
        print('Process interrupted. Inspect the persisted job; recover/resume explicitly before retrying.')
        return 130
    except Exception as exc:
        # Avoid printing provider/database exceptions or credentials.
        print(json.dumps({'status':'FAILED','error':type(exc).__name__,
                          'message':'Workflow command failed. Inspect configuration, reviewed scope and persisted job details.'}))
        return 1


if __name__=='__main__':raise SystemExit(main())
