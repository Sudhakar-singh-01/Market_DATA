"""
controller/timeframe_controller.py
Generates higher-timeframe candles from STORED 1m data (spec Section
14) -- distinct from the live incremental path (which lives inline in
live_controller.py using LiveTimeframeAggregator).

Supports initial generation, regeneration, backfill, and rebuilding
after corrections, because it always re-reads 1m from a source of
truth (a Reader callable, backed by MySQL or Parquet) rather than
holding any of its own state between runs.
"""

import logging
import datetime as dt
import math
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from model.config.instrument_loader import InstrumentRegistry, Instrument
from model.config.data_settings import DataSettings
from model.config.timeframe_settings import TimeframeSettings
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe, _complete, _TIMEFRAME_SECONDS
from model.config.market_calendar import IST, calendar_verified, session_window
from model.processing.validator import validate_candles
from controller.sinks import CandleSink, NoOpCandleSink, JobRecorder, NoOpJobRecorder
from controller.historical_controller import select_instruments

log = logging.getLogger("market_data.controller.timeframe")

# Callable signature: (fyers_symbol, from_date, to_date, instrument) -> list[Candle]
OneMinuteReader = Callable


@dataclass
class TimeframeGenerationResult:
    fyers_symbol: str
    timeframe: str
    status: str  # success, partial, pending, no_complete_buckets, failed, no_source_data
    source_1m_count: int = 0
    derived_count: int = 0
    valid_count: int = 0
    invalid_count: int = 0
    error: Optional[str] = None
    reason: Optional[str] = None
    expected_1m_count: int = 0  # elapsed, closed minutes on verified calendar days
    missing_1m_count: int = 0
    rejected_source_count: int = 0
    skipped_bucket_count: int = 0
    incomplete_bucket_count: int = 0
    pending_bucket_count: int = 0
    unknown_calendar_days: int = 0


@dataclass
class TimeframeBatchSummary:
    results: list = field(default_factory=list)
    started_at: float = field(default_factory=time.monotonic)

    def log_report(self):
        elapsed = time.monotonic() - self.started_at
        log.info("=" * 70)
        log.info("TIMEFRAME AGGREGATION SUMMARY")
        successful = sum(1 for r in self.results if r.status == "success")
        log.info(f"Total: {len(self.results)}   Successful: {successful}   Failed: {sum(1 for r in self.results if r.status == 'failed')}")
        for r in self.results:
            if r.status == "failed":
                log.info(f"  FAILED  {r.fyers_symbol} [{r.timeframe}]: {r.error}")
            else:
                log.info(
                    f"  {r.status.upper():8s} {r.fyers_symbol} [{r.timeframe}]: "
                    f"source_1m={r.source_1m_count} derived={r.derived_count} "
                    f"valid={r.valid_count} invalid={r.invalid_count} "
                    f"missing_1m={r.missing_1m_count} skipped_buckets={r.skipped_bucket_count}"
                    + (f" reason={r.reason}" if r.reason else "")
                )
        log.info(f"Elapsed: {elapsed:.1f}s")
        log.info("=" * 70)


def _aggregation_coverage(rows, timeframe, from_date, to_date, symbol, now=None):
    """Report gaps only against verified sessions; unfinished buckets stay pending.

    Count unique valid source minutes, not raw rows. Duplicate or malformed
    rows remain in the aggregator input so its strict rejection policy holds.
    """
    from model.processing.timeframe_aggregator import _bucket_start, bucket_minutes
    from model.config.market_calendar import expected_starts, in_session
    now = now or dt.datetime.now(IST)
    if timeframe != '1d' and timeframe not in _TIMEFRAME_SECONDS:
        raise ValueError(f'Unsupported timeframe: {timeframe}')
    minutes = 1440 if timeframe == '1d' else _TIMEFRAME_SECONDS[timeframe] // 60
    a, b = dt.date.fromisoformat(from_date), dt.date.fromisoformat(to_date)
    if a > b:
        raise ValueError('Aggregation range must be ordered')
    known = {}; unknown_days = set()
    day = a
    while day <= b:
        if not calendar_verified(day):
            unknown_days.add(day)
        else:
            window = session_window(day)
            if window:
                known[day] = window
        day += dt.timedelta(days=1)
    buckets = {}; rejected = 0
    for row in rows:
        try:
            row_day = row.timestamp.date()
            if not a <= row_day <= b:
                rejected += 1
                continue
            window = known.get(row_day)
            # Unknown calendar data cannot establish coverage, but is not malformed.
            if row_day in unknown_days:
                continue
            valid = (row.fyers_symbol == symbol
                and window and in_session(row.timestamp)
                and row.timestamp.second == 0 and row.timestamp.microsecond == 0
                and row.timeframe == '1m' and row.status == 'CLOSED'
                and math.isfinite(float(row.volume)) and row.volume >= 0
                and all(math.isfinite(float(v)) and v > 0 for v in (row.open,row.high,row.low,row.close))
                and row.low <= min(row.open,row.close) <= max(row.open,row.close) <= row.high)
            if not valid:
                rejected += 1
                continue
            start = _bucket_start(row.timestamp, timeframe)
            bucket = buckets.setdefault(start, [])
            if any(c.timestamp == row.timestamp for c in bucket):
                rejected += 1
            bucket.append(row)
        except (AttributeError, TypeError, ValueError, OverflowError):
            rejected += 1
    expected = missing = incomplete = pending = skipped = 0
    for day in known:
        starts = sorted({_bucket_start(ts, timeframe) for ts in expected_starts(day)})
        for start in starts:
            all_stamps, end = bucket_minutes(start, timeframe)
            cutoff = now.replace(second=0, microsecond=0)
            stamps = {ts for ts in all_stamps if ts < cutoff}
            present = {c.timestamp for c in buckets.get(start, [])}
            absent = len(stamps - present)
            expected += len(stamps); missing += absent
            if start < now:
                if not _complete(buckets.get(start, []), start, timeframe, now=now):
                    skipped += 1
                    if absent or (end <= now):
                        incomplete += 1
                    else:
                        pending += 1
    return dict(expected_1m_count=expected, missing_1m_count=missing,
        rejected_source_count=rejected, skipped_bucket_count=skipped,
        incomplete_bucket_count=incomplete, pending_bucket_count=pending,
        unknown_calendar_days=len(unknown_days))


def generate_timeframe_for_instrument(
    instrument: Instrument,
    timeframe: str,
    from_date: str,
    to_date: str,
    read_1m: OneMinuteReader,
    instruments: InstrumentRegistry,
    data_settings: DataSettings,
    sink: CandleSink,
    job_recorder: Optional[JobRecorder] = None,
) -> TimeframeGenerationResult:
    fyers_symbol = instrument.fyers_symbol
    job_recorder = job_recorder or NoOpJobRecorder()
    log.info(f"Generating {timeframe} for {fyers_symbol}, source range {from_date}..{to_date}")

    coverage = {}
    one_minute_candles = []
    try:
        one_minute_candles = read_1m(fyers_symbol, from_date, to_date, instrument)
        if not one_minute_candles:
            log.info(f"{fyers_symbol}: no stored 1m data in range, nothing to aggregate")
            job_recorder.record(
                job_type="timeframe", fyers_symbol=fyers_symbol, timeframe=timeframe,
                from_date=from_date, to_date=to_date, status="no_data",
            )
            return TimeframeGenerationResult(fyers_symbol=fyers_symbol, timeframe=timeframe, status="no_source_data",
                reason="No stored 1m data in the requested range")

        coverage = _aggregation_coverage(one_minute_candles, timeframe, from_date, to_date, fyers_symbol)
        derived = aggregate_1m_to_timeframe(one_minute_candles, timeframe)

        if data_settings.validation_enabled:
            results = validate_candles(derived, instruments=instruments)
            valid = [r.candle for r in results if r.status in ("valid", "warning")]
            invalid_count = sum(1 for r in results if r.status == "invalid")
            for r in results:
                if r.status == "invalid":
                    log.warning(f"{fyers_symbol} [{timeframe}]: invalid derived candle at {r.candle.timestamp}: {r.errors}")
        else:
            valid, invalid_count = derived, 0

        if not derived:
            status = 'no_complete_buckets'
        elif (coverage['missing_1m_count'] or coverage['rejected_source_count']
                or coverage['incomplete_bucket_count'] or coverage['unknown_calendar_days'] or invalid_count):
            status = 'partial'
        elif coverage['pending_bucket_count']:
            status = 'pending'
        else:
            status = 'success'
        reason = None if status == 'success' else (
            f"{coverage['missing_1m_count']} missing elapsed source minutes; "
            f"{coverage['rejected_source_count']} rejected source rows; "
            f"{coverage['incomplete_bucket_count']} incomplete buckets; "
            f"{coverage['pending_bucket_count']} unfinished buckets pending; "
            f"{coverage['unknown_calendar_days']} days without verified calendar; "
            f"{invalid_count} invalid derived candles")
        sink.write_batch(valid)

        log.info(f"{fyers_symbol} [{timeframe}]: status={status} source_1m={len(one_minute_candles)} derived={len(derived)} valid={len(valid)} invalid={invalid_count}" + (f" reason={reason}" if reason else ""))
        job_recorder.record(
            job_type="timeframe", fyers_symbol=fyers_symbol, timeframe=timeframe,
            from_date=from_date, to_date=to_date, status="success" if status == "success" else "partial",
            error_message=reason, raw_count=len(one_minute_candles), valid_count=len(valid), invalid_count=invalid_count,
        )
        return TimeframeGenerationResult(
            fyers_symbol=fyers_symbol, timeframe=timeframe, status=status, reason=reason, **coverage,
            source_1m_count=len(one_minute_candles), derived_count=len(derived),
            valid_count=len(valid), invalid_count=invalid_count,
        )

    except Exception as exc:
        log.error(f"{fyers_symbol} [{timeframe}]: aggregation failed: {exc}")
        job_recorder.record(
            job_type="timeframe", fyers_symbol=fyers_symbol, timeframe=timeframe,
            from_date=from_date, to_date=to_date, status="failed", error_message=str(exc),
        )
        return TimeframeGenerationResult(fyers_symbol=fyers_symbol, timeframe=timeframe, status="failed",
            error=str(exc), reason=str(exc), source_1m_count=len(one_minute_candles), **coverage)


def run_timeframe_generation(
    instruments: InstrumentRegistry,
    timeframe_settings: TimeframeSettings,
    data_settings: DataSettings,
    read_1m: OneMinuteReader,
    from_date: str,
    to_date: str,
    symbol_filter: Optional[list] = None,
    timeframes: Optional[list] = None,
    sink: Optional[CandleSink] = None,
    job_recorder: Optional[JobRecorder] = None,
) -> TimeframeBatchSummary:
    """
    Batch entry point (spec Section 14): supports initial generation,
    regeneration, and backfill identically -- there is no separate
    "regenerate" code path, because re-running this with the same
    range always re-reads 1m and re-derives from scratch. Idempotent
    storage (MySQL's UNIQUE KEY + INSERT IGNORE, Parquet's dedup-on-
    write) means re-running is always safe.
    """
    sink = sink or NoOpCandleSink()
    job_recorder = job_recorder or NoOpJobRecorder()
    timeframes = timeframes or [tf.name for tf in timeframe_settings.derived_timeframes]

    selected = select_instruments(instruments, symbol_filter)
    if not selected:
        log.error("No matching active instruments to process.")
        return TimeframeBatchSummary()

    log.info(f"Generating {timeframes} for {len(selected)} instrument(s), range {from_date}..{to_date}")

    summary = TimeframeBatchSummary()
    for instrument in selected:
        for timeframe in timeframes:
            result = generate_timeframe_for_instrument(
                instrument, timeframe, from_date, to_date, read_1m, instruments, data_settings, sink,
                job_recorder=job_recorder,
            )
            summary.results.append(result)

    summary.log_report()
    return summary
