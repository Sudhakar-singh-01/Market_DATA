"""
controller/historical_controller.py
Orchestrates historical 1-minute ingestion (spec Section 19). Does NOT
implement storage -- writes to a CandleSink (controller/sinks.py),
which Part 3 will back with real persistence.
"""

from controller import worker_lifecycle as lifecycle
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from model.config.instrument_loader import InstrumentRegistry, Instrument
from model.config.data_settings import DataSettings
from model.config.timeframe_settings import TimeframeSettings
from model.fyers.historical import fetch_historical_1m, CheckpointStore, NullCheckpointStore
from model.processing.normalizer import normalize_historical_candle, NormalizationError
from model.processing.validator import validate_candles
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe
from controller.sinks import CandleSink, NoOpCandleSink, JobRecorder, NoOpJobRecorder

log = logging.getLogger("market_data.controller.historical")


@dataclass
class InstrumentIngestionResult:
    fyers_symbol: str
    status: str  # 'success' | 'failed' | 'no_data'
    raw_count: int = 0
    normalized_count: int = 0
    valid_count: int = 0
    invalid_count: int = 0
    warning_count: int = 0
    derived_counts: dict = field(default_factory=dict)  # {timeframe: valid_derived_count}
    error: Optional[str] = None


@dataclass
class HistoricalBatchSummary:
    results: list = field(default_factory=list)
    started_at: float = field(default_factory=time.monotonic)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def successful(self) -> int:
        return sum(1 for r in self.results if r.status == "success")

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.status == "failed")

    def log_report(self):
        elapsed = time.monotonic() - self.started_at
        log.info("=" * 70)
        log.info("HISTORICAL 1M INGESTION SUMMARY")
        log.info(f"Total instruments : {self.total}   Successful: {self.successful}   Failed: {self.failed}")
        log.info(
            f"Raw: {sum(r.raw_count for r in self.results)}   "
            f"Normalized: {sum(r.normalized_count for r in self.results)}   "
            f"Valid: {sum(r.valid_count for r in self.results)}   "
            f"Invalid: {sum(r.invalid_count for r in self.results)}   "
            f"Warnings: {sum(r.warning_count for r in self.results)}"
        )
        log.info(f"Elapsed: {elapsed:.1f}s")
        for r in self.results:
            if r.status == "failed":
                log.info(f"  FAILED  {r.fyers_symbol}: {r.error}")
            else:
                derived_str = f" derived={r.derived_counts}" if r.derived_counts else ""
                log.info(
                    f"  {r.status.upper():8s} {r.fyers_symbol}: raw={r.raw_count} "
                    f"valid={r.valid_count} invalid={r.invalid_count} warnings={r.warning_count}{derived_str}"
                )
        log.info("=" * 70)


def select_instruments(instruments: InstrumentRegistry, symbol_filter: Optional[list]) -> list:
    """
    symbol_filter: None or ['all'] -> every active stock + active index.
    ['stocks'] -> active stocks only. ['indices'] -> active indices only.
    Otherwise: explicit internal_name list.
    """
    if not symbol_filter or symbol_filter == ["all"]:
        return instruments.active_instruments()
    if symbol_filter == ["stocks"]:
        return instruments.active_stocks()
    if symbol_filter == ["indices"]:
        return instruments.active_indices()

    selected = []
    for name in symbol_filter:
        try:
            instrument = instruments.get(name)
        except KeyError:
            log.warning(f"Requested instrument '{name}' not found in registry, skipping")
            continue
        if not instrument.active:
            log.warning(f"Requested instrument '{name}' is inactive, skipping")
            continue
        selected.append(instrument)
    return selected


class _StubResult:
    def __init__(self, candle):
        self.status = "valid"
        self.candle = candle
        self.errors = []
        self.warnings = []


def process_instrument(
    client,
    instrument: Instrument,
    from_date: str,
    to_date: str,
    data_settings: DataSettings,
    instruments: InstrumentRegistry,
    sink: CandleSink,
    checkpoint_store: CheckpointStore,
    timeframe_settings: Optional[TimeframeSettings] = None,
    derived_sink: Optional[CandleSink] = None,
    job_recorder: Optional[JobRecorder] = None,
    job_type: str = "historical",
) -> InstrumentIngestionResult:
    fyers_symbol = instrument.fyers_symbol
    job_recorder = job_recorder or NoOpJobRecorder()
    log.info(f"Historical fetch started: {fyers_symbol} 1m {from_date}..{to_date}")

    try:
        raw_rows = fetch_historical_1m(
            client, fyers_symbol, from_date, to_date,
            retry_settings=data_settings.retry,
            checkpoint_store=checkpoint_store,
        )

        if not raw_rows:
            log.info(f"{fyers_symbol}: no data returned")
            job_recorder.record(
                job_type=job_type, fyers_symbol=fyers_symbol, timeframe="1m",
                from_date=from_date, to_date=to_date, status="no_data", raw_count=0,
            )
            return InstrumentIngestionResult(fyers_symbol=fyers_symbol, status="no_data")

        candles = []
        normalization_errors = 0
        for row in raw_rows:
            try:
                candles.append(normalize_historical_candle(row, instrument, timeframe="1m"))
            except NormalizationError as exc:
                normalization_errors += 1
                log.warning(f"{fyers_symbol}: skipping row that failed normalization: {exc}")

        if data_settings.validation_enabled:
            results = validate_candles(candles, instruments=instruments)
        else:
            results = [_StubResult(c) for c in candles]

        valid_candles = [r.candle for r in results if r.status in ("valid", "warning")]
        invalid_count = normalization_errors + sum(1 for r in results if r.status == "invalid")
        warning_count = sum(1 for r in results if r.status == "warning")

        for r in results:
            if r.status == "invalid":
                ts = r.candle.timestamp if r.candle else "?"
                log.warning(f"{fyers_symbol}: invalid candle at {ts}: {r.errors}")

        lifecycle.check()
        accepted = sink.write_batch(valid_candles)
        lifecycle.check()
        conflicts = getattr(sink, "last_conflicts", 0)
        if isinstance(accepted, list):
            valid_candles = accepted
        complete = False
        if valid_candles and not invalid_count and not conflicts:
            import datetime
            from model.config.market_calendar import expected_starts, calendar_verified, IST
            start,end = datetime.date.fromisoformat(from_date),datetime.date.fromisoformat(to_date)
            present = {c.timestamp for c in valid_candles if c.status == "CLOSED"}
            complete = end < datetime.datetime.now(IST).date()
            day = start
            while day <= end:
                complete = complete and calendar_verified(day) and set(expected_starts(day)) <= present
                day += datetime.timedelta(days=1)
            if complete:
                lifecycle.check()
                checkpoint_store.save_checkpoint(fyers_symbol,"1m",to_date)
        outcome_status = "success" if complete else "partial"

        log.info(
            f"{fyers_symbol}: fetch completed. raw={len(raw_rows)} normalized={len(candles)} "
            f"valid={len(valid_candles)} invalid={invalid_count} warnings={warning_count}"
        )

        # Generate + store derived timeframes from the 1m batch just
        # fetched (spec Section 18: "Generate higher timeframes ->
        # Validate derived data -> Store derived data" as part of the
        # same historical run, not a separate pass). Uses the SAME
        # aggregate_1m_to_timeframe() that controller/timeframe_controller.py
        # uses for regeneration, so a fresh fetch and a later regenerate
        # can never compute different derived values (spec Section 29).
        derived_counts = {}
        if timeframe_settings is not None and valid_candles:
            target_sink = derived_sink if derived_sink is not None else sink
            for tf_config in timeframe_settings.derived_timeframes:
                timeframe = tf_config.name
                derived = aggregate_1m_to_timeframe(valid_candles, timeframe)
                if not derived:
                    continue
                if data_settings.validation_enabled:
                    derived_results = validate_candles(derived, instruments=instruments)
                    valid_derived = [r.candle for r in derived_results if r.status in ("valid", "warning")]
                    for r in derived_results:
                        if r.status == "invalid":
                            log.warning(f"{fyers_symbol} [{timeframe}]: invalid derived candle at {r.candle.timestamp}: {r.errors}")
                else:
                    valid_derived = derived
                target_sink.write_batch(valid_derived)
                derived_counts[timeframe] = len(valid_derived)
                log.info(f"{fyers_symbol} [{timeframe}]: derived={len(derived)} valid={len(valid_derived)}")

        job_recorder.record(
            job_type=job_type, fyers_symbol=fyers_symbol, timeframe="1m",
            from_date=from_date, to_date=to_date, status=outcome_status,
            raw_count=len(raw_rows), valid_count=len(valid_candles), invalid_count=invalid_count,
        )

        return InstrumentIngestionResult(
            fyers_symbol=fyers_symbol,
            status=outcome_status,
            raw_count=len(raw_rows),
            normalized_count=len(candles),
            valid_count=len(valid_candles),
            invalid_count=invalid_count,
            warning_count=warning_count,
            derived_counts=derived_counts,
        )

    except lifecycle.WorkerInterrupted:
        raise
    except Exception as exc:
        log.error(f"{fyers_symbol}: historical fetch failed: {exc}")
        job_recorder.record(
            job_type=job_type, fyers_symbol=fyers_symbol, timeframe="1m",
            from_date=from_date, to_date=to_date, status="failed", error_message=str(exc),
        )
        return InstrumentIngestionResult(fyers_symbol=fyers_symbol, status="failed", error=str(exc))


def run_historical_ingestion(
    client,
    instruments: InstrumentRegistry,
    data_settings: DataSettings,
    from_date: str,
    to_date: str,
    symbol_filter: Optional[list] = None,
    sink: Optional[CandleSink] = None,
    checkpoint_store: Optional[CheckpointStore] = None,
    timeframe_settings: Optional[TimeframeSettings] = None,
    derived_sink: Optional[CandleSink] = None,
    job_recorder: Optional[JobRecorder] = None,
) -> HistoricalBatchSummary:
    sink = sink or NoOpCandleSink()
    checkpoint_store = checkpoint_store or NullCheckpointStore()
    job_recorder = job_recorder or NoOpJobRecorder()

    selected = select_instruments(instruments, symbol_filter)
    if not selected:
        log.error("No matching active instruments to process.")
        return HistoricalBatchSummary()

    log.info(f"Resolved {len(selected)} instrument(s) for historical 1m ingestion, range={from_date}..{to_date}")

    summary = HistoricalBatchSummary()
    for instrument in selected:
        result = process_instrument(
            client, instrument, from_date, to_date, data_settings, instruments, sink, checkpoint_store,
            timeframe_settings=timeframe_settings, derived_sink=derived_sink, job_recorder=job_recorder,
        )
        summary.results.append(result)
        # One instrument's failure never stops the batch.

    summary.log_report()

    # Batch-level summary row (fyers_symbol=None distinguishes it from
    # the per-instrument rows above -- spec Section 4: "ingestion
    # metadata" at the job level, not just per-instrument).
    job_recorder.record(
        job_type="historical", fyers_symbol=None, timeframe="1m",
        from_date=from_date, to_date=to_date,
        status="success" if summary.successful == summary.total else "no_data" if all(r.status=="no_data" for r in summary.results) else "partial",
        raw_count=sum(r.raw_count for r in summary.results),
        valid_count=sum(r.valid_count for r in summary.results),
        invalid_count=sum(r.invalid_count for r in summary.results),
    )

    return summary
