"""
controller/fno_cli.py
Implements the `fno-*` modes of main.py. FNO modes bootstrap independently of Subsystem A: they do
not load A's instruments or open A's database. Each command returns an exit status:
    0 success   1 failure / configuration error   2 completed with unresolved findings or partial result
    3 an identical job is already active
"""
import dataclasses
import datetime
import logging
import os
import sys
from pathlib import Path

from controller import fno_historical as fh
from controller.fno_jobs import FnoJobRunner
from controller.fno_reconcile import reconcile
from model.exceptions import ConfigurationError
from model.fno import migrations, symbol_master as sm
from model.fno.config import (FnoSettings, load_fno_database_config, load_fno_settings, PROJECT_ROOT)
from model.fno.db import get_fno_engine
from model.fno.errors import DuplicateJobError, IsolationError, TokenExpiredError
from model.fno.history_client import FnoHistoryFetcher
from model.fno.job_store import FnoJobStore
from model.fno.models import IST
from model.fno.parquet_store import FnoParquetStore
from model.fno.repository import FnoRepository
from model.fyers.rate_limiter import SlidingWindowLimiter, RateLimitedClient, LOW, configure_shared_limiter

log = logging.getLogger("market_data.fno.cli")
FNO_MODES = ("fno-migrate", "fno-probe", "fno-sync-contracts", "fno-historical", "fno-jobs", "fno-reconcile", "fno-cleanup",
             "fno-live", "fno-chain-snapshot", "fno-aggregate", "fno-verify")


def add_fno_subparsers(sub):
    m = sub.add_parser("fno-migrate", help="FNO: list (default) or apply (--apply) the SQL files in database/fno/")
    m.add_argument("--apply", action="store_true", help="actually run the SQL against the FNO database")
    p = sub.add_parser("fno-probe", help="FNO P0: check FYERS behaviour with a real token; writes docs/FNO_API_FINDINGS.md")
    p.add_argument("--expired-symbol", default=None, help="a REAL recently expired symbol, to test the -300 assumption")
    p.add_argument("--ws-limit", action="store_true", help="also probe the WebSocket subscription limit (market hours)")
    p.add_argument("--rate-limit", action="store_true", help="also fire a small burst to observe throttling")
    p.add_argument("--write-report", action="store_true", help="write docs/FNO_API_FINDINGS.md (otherwise print only)")
    c = sub.add_parser("fno-sync-contracts", help="FNO: download the F&O symbol master and update the contract master")
    c.add_argument("--force-download", action="store_true")
    h = sub.add_parser("fno-historical", help="FNO: harvest 1m history of ACTIVE contracts")
    h.add_argument("--underlyings", nargs="+", default=None)
    h.add_argument("--expiries", type=int, default=None, help="next N expiries per underlying")
    h.add_argument("--from", dest="from_date", default=None, help="YYYY-MM-DD (default: today - lookback)")
    h.add_argument("--to", dest="to_date", default=None, help="YYYY-MM-DD (default: today)")
    h.add_argument("--atm", nargs="*", default=None, metavar="UNDERLYING=PRICE", help="override the ATM reference price")
    h.add_argument("--no-parquet", action="store_true", help="MySQL only")
    h.add_argument("--submit-only", action="store_true", help="queue the job; run it later with fno-jobs --run")
    j = sub.add_parser("fno-jobs", help="FNO: list, run, resume or cancel persisted jobs")
    j.add_argument("--list", action="store_true"); j.add_argument("--run", action="store_true", help="run pending jobs until none are left")
    j.add_argument("--worker", action="store_true", help="headless worker: poll until Ctrl+C")
    j.add_argument("--resume", type=int, default=None, metavar="ID"); j.add_argument("--cancel", type=int, default=None, metavar="ID")
    r = sub.add_parser("fno-reconcile", help="FNO: compare MySQL, Parquet and the manifest (repair with --repair)")
    r.add_argument("--repair", action="store_true"); r.add_argument("--from", dest="from_date", default=None)
    r.add_argument("--to", dest="to_date", default=None)
    lv = sub.add_parser("fno-live", help="FNO: stream live ticks into 1m candles (MySQL + Parquet) until Ctrl+C")
    lv.add_argument("--underlyings", nargs="+", default=None); lv.add_argument("--expiries", type=int, default=None)
    lv.add_argument("--atm", nargs="*", default=None, metavar="UNDERLYING=PRICE"); lv.add_argument("--no-parquet", action="store_true")
    lv.add_argument("--max-subscriptions", type=int, default=None, help="override subscriptions.max_subscriptions for this run")
    cs = sub.add_parser("fno-chain-snapshot", help="FNO: capture option-chain snapshots (once, or --loop during market hours)")
    cs.add_argument("--underlyings", nargs="+", default=None); cs.add_argument("--loop", action="store_true")
    cs.add_argument("--no-parquet", action="store_true")
    k = sub.add_parser("fno-cleanup", help="FNO: delete old FNO Parquet day-files (dry-run unless --confirm)")
    k.add_argument("--retain-days", type=int, default=None); k.add_argument("--dry-run", action="store_true")
    k.add_argument("--confirm", action="store_true", help="really delete (never combined with --dry-run)")
    k.add_argument("--chain-retain-days", type=int, default=None, help="option-chain Parquet retention (default from config)")
    for name, help_text in (("fno-aggregate", "FNO: rebuild derived candles from stored canonical 1m"),
                            ("fno-verify", "FNO: read-only data verification, persisted findings")):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("--from", dest="from_date", required=True)
        p.add_argument("--to", dest="to_date", required=True)
        p.add_argument("--underlyings", nargs="+", default=None)
        p.add_argument("--contract-ids", nargs="+", type=int, default=None)
        p.add_argument("--submit-only", action="store_true")
        p.add_argument("--no-parquet", action="store_true")
        if name == "fno-aggregate":
            p.add_argument("--timeframes", nargs="+", choices=["5m","15m","30m","1h","1d"], default=None)


# ---------------------------------------------------------------- bootstrap
class Ctx:
    pass


def _setup_logging():
    try:
        from model.config.data_settings import load_data_settings
        from model.logging_setup import configure_logging
        ds = load_data_settings()
        configure_logging(level=ds.log_level, log_dir=ds.log_dir, log_file=ds.log_file)
    except Exception:
        logging.basicConfig(level="INFO", format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")


def bootstrap(need_fyers: bool = False) -> Ctx:
    from dotenv import load_dotenv
    from model.config.runtime_paths import env_path as selected_env_path
    env_path = selected_env_path()
    if env_path.exists():
        load_dotenv(env_path)
    _setup_logging()
    c = Ctx()
    c.settings = load_fno_settings()
    c.dbcfg = load_fno_database_config()
    a_name = os.environ.get("DB_NAME", "")
    c.engine = get_fno_engine(c.dbcfg, a_name)
    c.repo, c.jobs = FnoRepository(c.engine), FnoJobStore(c.engine)
    c.store = FnoParquetStore(c.settings.parquet_root, c.repo)
    c.client = c.raw_client = c.creds = None
    try:
        sample = c.repo.manifest_list(status="VERIFIED", limit=1)
        if sample and not c.store.abs_path(sample[0]["relative_path"]).exists():
            msg = (f"WARNING: the database says Parquet files are VERIFIED (e.g. {sample[0]['relative_path']}) but they are not under "
                   f"{c.settings.parquet_root}. Did you unzip into a new project folder? Run `fno-reconcile --repair` to rebuild from MySQL, "
                   f"and set an ABSOLUTE `parquet.root` in config/fno_settings.yaml so upgrades keep the data.")
            print(msg); log.warning(msg)
    except Exception:
        pass
    from model.fyers.rate_limiter import configure_account_limiter
    c.limiter = configure_account_limiter(os.environ.get("FYERS_CLIENT_ID","unconfigured"),c.settings)
    configure_shared_limiter(c.limiter)          # Subsystem A's REST call sites now draw from the same budget
    if need_fyers:
        from model.config.env_loader import load_env_config
        from model.fyers.auth import get_authenticated_client
        env = load_env_config()
        c.creds = env.fyers
        c.raw_client = get_authenticated_client(env.fyers)
        c.client = RateLimitedClient(c.raw_client, c.limiter, LOW)
    return c


def _today() -> datetime.date:
    return datetime.datetime.now(tz=IST).date()


def _harvest_ctx(c: Ctx, use_parquet: bool = True) -> fh.HarvestContext:
    return fh.HarvestContext(c.repo, FnoHistoryFetcher(c.client, c.settings.history), c.store if use_parquet else None, c.settings)


# ----------------------------------------------------------------- commands
def cmd_migrate(args) -> int:
    from model.fno.config import load_fno_database_config as _l
    from dotenv import load_dotenv
    from model.config.runtime_paths import env_path
    load_dotenv(env_path())
    steps = migrations.plan()
    print("FNO SQL files (database/fno/):")
    for name, n in steps:
        print(f"  {name}  ({n} statements)")
    if not args.apply:
        print("\nDry run: nothing applied. Re-run with --apply to create/update the FNO tables.")
        return 0
    c = bootstrap()
    done = migrations.apply_all(c.engine)
    print(f"\nApplied {len(done)} file(s) to database '{c.dbcfg.name}'. All statements are idempotent.")
    return 0


def cmd_sync_contracts(args) -> int:
    c = bootstrap()
    s = c.settings.symbol_master
    cache = c.settings.parquet_root / "symbol_master" / f"NSE_FO.{s.format}"
    text = sm.download_symbol_master(s.url, cache, s.max_age_hours, s.timeout_seconds, force=args.force_download)
    report = sm.parse_master(text, s.format, s.csv_columns)
    if not report.contracts:
        print(f"ERROR: parsed 0 contracts from {report.total_rows} rows (skipped: {report.skipped}). "
              f"The symbol-master layout in fno_settings.yaml probably does not match; run fno-probe.")
        return 1
    out = sm.sync_contracts(c.repo, report, c.settings.universe.underlyings, _today())
    print("Contract sync complete: " + ", ".join(f"{k}={v}" for k, v in out.items()))
    return 0


def cmd_historical(args) -> int:
    c = bootstrap(need_fyers=True)
    st = c.settings
    today = _today()
    to_d = args.to_date or today.isoformat()
    from_d = args.from_date or (today - datetime.timedelta(days=st.history.default_lookback_days)).isoformat()
    params = {"underlyings": [u.upper() for u in (args.underlyings or st.universe.underlyings)], "from": from_d, "to": to_d,
              "expiries_ahead": args.expiries or st.universe.expiries_ahead, "strike_window": st.universe.strike_window,
              "include_futures": st.universe.include_futures, "include_options": st.universe.include_options,
              "use_parquet": not args.no_parquet}
    atm = {}
    for item in (args.atm or []):
        k, _, v = item.partition("=")
        atm[k.upper()] = float(v)
    if params["include_options"]:
        missing = [u for u in params["underlyings"] if u not in atm]
        if missing:
            atm.update(fh.fetch_atm(c.client, st, missing))
    params["atm"] = {k: round(v, 2) for k, v in atm.items()}
    hctx = _harvest_ctx(c, params["use_parquet"])
    try:
        plan = fh.make_plan_from_params(hctx, params)
    except fh.AtmUnavailable as exc:
        print(f"ERROR: {exc}")
        return 1
    est = plan.estimate(st.rate_limits.per_second, st.rate_limits.per_day, st.rate_limits.fno_reserve_fraction)
    print(f"Plan: {est['contracts']} contract(s), {est['requests']} request(s), >= {est['min_seconds']}s at the FNO rate share, "
          f"{est['share_of_daily_budget_pct']}% of the FNO daily budget; {est['expired_unrecoverable_ranges']} range(s) of expired contracts "
          f"can no longer be fetched. Range {from_d}..{plan.effective_to} (today only counts after the session is complete).")
    try:
        jid = c.jobs.submit(fh.JOB_TYPE, params)
    except DuplicateJobError as exc:
        print(f"An identical job is already active: id={exc.job_id}. Use `fno-jobs --list`.")
        return 3
    print(f"Job {jid} queued.")
    if args.submit_only:
        return 0
    return _run_jobs(c, hctx_factory=lambda use_pq: _harvest_ctx(c, use_pq))


def _run_jobs(c: Ctx, hctx_factory=None) -> int:
    handlers = local_handlers(c)
    if c.client is not None and hctx_factory is not None:
        def h(handle):
            return fh.run_harvest(handle, hctx_factory(bool(handle.params.get("use_parquet", True))))
        handlers[fh.JOB_TYPE] = h
    runner = FnoJobRunner(c.jobs, handlers, c.settings.jobs.heartbeat_seconds, c.settings.jobs.stale_after_seconds)
    runner.recover()
    ids = runner.run_until_empty()
    worst = 0
    for jid in ids:
        j = c.jobs.get(jid)
        print(f"Job {jid} {j['state']}: requests={j['requests_made']} raw={j['rows_raw']} valid={j['rows_valid']} invalid={j['rows_invalid']} "
              f"stored={j['rows_stored']} duplicate={j['rows_duplicate']} no_data={j['no_data_count']} retries={j['retry_count']}")
        if j["error"]:
            print(f"   {j['error']}")
        if j.get("result"):
            import json
            print(json.dumps(j["result"], default=str, sort_keys=True))
        worst = max(worst, {"SUCCESS": 0, "NO_DATA": 0, "PARTIAL": 2, "CANCELLED": 2, "INTERRUPTED": 2}.get(j["state"], 1))
    if not ids:
        print("No pending jobs.")
    return worst


def cmd_jobs(args) -> int:
    need = bool(args.run or args.worker)
    c = bootstrap()
    if args.cancel is not None:
        print(f"Job {args.cancel}: {c.jobs.request_cancel(args.cancel)}")
        return 0
    if args.resume is not None:
        try:
            print(f"Resume queued as job {c.jobs.resume(args.resume)}")
        except (ValueError, KeyError, DuplicateJobError) as exc:
            print(f"ERROR: {exc}")
            return 1
        if not need:
            return 0
    if args.worker:
        runner = FnoJobRunner(c.jobs, worker_handlers(c),
                              c.settings.jobs.heartbeat_seconds, c.settings.jobs.stale_after_seconds)
        print("FNO worker running; Ctrl+C for a graceful stop (running job becomes INTERRUPTED and can be resumed).")
        try:
            runner.worker_loop(concurrency=c.settings.jobs.concurrency)
        except KeyboardInterrupt:
            runner.shutdown.set()
        return 0
    if args.run:
        return run_worker_jobs(c)
    jobs = c.jobs.list(limit=30)
    print(f"{'id':>5} {'type':<20} {'state':<12} {'req':>5} {'stored':>8} {'created':<20} error")
    for j in jobs:
        print(f"{j['id']:>5} {j['job_type']:<20} {j['state']:<12} {j['requests_made']:>5} {j['rows_stored']:>8} {str(j['created_at']):<20} {(j['error'] or '')[:60]}")
    if not jobs:
        print("No jobs yet.")
    return 0


def local_handlers(c):
    from controller.fno_aggregate import run_aggregation
    from controller.fno_verify import run_verification
    return {"AGGREGATION": lambda h: run_aggregation(h,c.repo,c.store if h.params.get("use_parquet",True) else None,c.settings),
            "VERIFY": lambda h: run_verification(h,c.repo,c.store if h.params.get("use_parquet",True) else None,c.settings)}


def ensure_fyers(c):
    """Local jobs never require an access token. Keep the current process limiter."""
    if c.client is None:
        from model.config.env_loader import load_env_config
        from model.fyers.auth import get_authenticated_client
        c.creds = load_env_config().fyers
        c.raw_client = get_authenticated_client(c.creds)
        c.client = RateLimitedClient(c.raw_client,c.limiter,LOW)
    return c


def worker_handlers(c):
    handlers = local_handlers(c)
    from controller.fno_operations import extra_handlers
    handlers.update(extra_handlers(c))
    def harvest(h):
        ensure_fyers(c)
        return fh.run_harvest(h,_harvest_ctx(c,bool(h.params.get("use_parquet",True))))
    handlers[fh.JOB_TYPE] = harvest
    from controller.unified_workflow import fno_workflow
    handlers["WORKFLOW"] = lambda h: fno_workflow(c,h)
    return handlers


def run_worker_jobs(c):
    runner = FnoJobRunner(c.jobs,worker_handlers(c),c.settings.jobs.heartbeat_seconds,c.settings.jobs.stale_after_seconds)
    runner.recover()
    ids = runner.run_until_empty()
    code = 0
    import json
    for jid in ids:
        j = c.jobs.get(jid)
        print(f"Job {jid} {j['state']}: {json.dumps(j['result'],default=str)}")
        if j["error"]: print(j["error"])
        code = max(code,{"SUCCESS":0,"NO_DATA":0,"PARTIAL":2,"CANCELLED":2,"INTERRUPTED":2}.get(j["state"],1))
    if not ids: print("No pending jobs.")
    return code


def cmd_local_job(args):
    from model.fno.release3_repository import date_range
    c = bootstrap()
    params = {"from":args.from_date,"to":args.to_date,"use_parquet":not args.no_parquet}
    date_range(params)
    if args.underlyings: params["underlyings"] = sorted(set(u.upper() for u in args.underlyings))
    if args.contract_ids: params["contract_ids"] = sorted(set(args.contract_ids))
    kind = "AGGREGATION" if args.mode=="fno-aggregate" else "VERIFY"
    if kind=="AGGREGATION": params["timeframes"] = sorted(set(args.timeframes or ["5m","15m","30m","1h","1d"]))
    try:
        jid = c.jobs.submit(kind,params)
    except DuplicateJobError as exc:
        print(f"An identical job is already active: id={exc.job_id}")
        return 3
    print(f"Job {jid} queued ({kind}).")
    return 0 if args.submit_only else _run_jobs(c)


def cmd_reconcile(args) -> int:
    c = bootstrap()
    d = lambda v: datetime.date.fromisoformat(v) if v else None
    rep = reconcile(c.repo, c.store, repair=args.repair, from_date=d(args.from_date), to_date=d(args.to_date))
    if not rep.findings:
        print("Reconcile: MySQL, Parquet and the manifest agree. Nothing to do.")
        return 0
    for f in rep.findings[:50]:
        print(f"  [{'repaired' if f['repaired'] else 'open'}] {f['kind']}: {f['target']} {f['detail']}")
    print(f"{len(rep.findings)} finding(s), {rep.repaired} repaired. " + ("" if args.repair else "Dry run: re-run with --repair to fix."))
    return 0 if rep.ok else 2


def cmd_cleanup(args) -> int:
    c = bootstrap()
    days = args.retain_days if args.retain_days is not None else c.settings.retention.candles_1m_days
    dry = args.dry_run or not args.confirm
    chain_days = getattr(args,"chain_retain_days",None)
    if chain_days is None: chain_days = c.settings.retention.option_chain_days
    victims = c.store.cleanup_old_files(days, dry_run=dry, confirm=args.confirm and not args.dry_run,chain_retain_days=chain_days)
    print(f"{'Would delete' if dry else 'Deleted'} {len(victims)} FNO Parquet file(s) older than {days} days (only under {c.store.root}).")
    for v in victims[:20]:
        print("  ", v)
    if dry and victims:
        print("Dry run: add --confirm to delete. MySQL candles are never touched by cleanup.")
    return 0


def cmd_probe(args) -> int:
    from model.fno import probe as P
    import importlib.metadata as md
    c = bootstrap(need_fyers=True)
    ws_factory = None
    if args.ws_limit:
        token = f"{c.creds.client_id}:{c.creds.access_token}"
        def ws_factory(on_message):
            from fyers_apiv3.FyersWebsocket import data_ws
            class Sock:
                def __init__(s):
                    s.sock = data_ws.FyersDataSocket(access_token=token, log_path="", litemode=False, write_to_file=False,
                                                     reconnect=False, on_connect=lambda: None, on_close=lambda m: None,
                                                     on_error=on_message, on_message=on_message)
                def connect(s): s.sock.connect(); s.sock.keep_running()
                def subscribe(s, syms): s.sock.subscribe(symbols=syms, data_type="SymbolUpdate")
                def close(s): s.sock.close_connection()
            return Sock()
    import requests
    probe = P.FnoProbe(c.client, c.settings, lambda u, t: requests.get(u, timeout=t), today=_today(),
                       ws_factory=ws_factory, raw_client=c.raw_client)
    results = probe.run_all(expired_symbol=args.expired_symbol, ws_limit=args.ws_limit, rate_limit=args.rate_limit)
    try:
        sdk = md.version("fyers-apiv3")
    except Exception:
        sdk = "unknown"
    md_text = P.render_findings(results, datetime.datetime.now(tz=IST).strftime("%Y-%m-%d %H:%M"), sdk)
    for r in results:
        print(f"  {r.check:<20} {r.status:<14} {r.summary}")
    if args.write_report:
        out = PROJECT_ROOT / "docs" / "FNO_API_FINDINGS.md"
        out.write_text(md_text, encoding="utf-8")
        print(f"\nWrote {out}")
    return 0 if all(r.status in (P.CONFIRMED, P.SKIPPED, P.NOT_CONFIRMED) for r in results) else 1


def _atm_from_args(c: Ctx, underlyings, given) -> dict:
    atm = {}
    for item in (given or []):
        k, _, v = item.partition("=")
        atm[k.upper()] = float(v)
    missing = [u for u in underlyings if u not in atm]
    if missing and c.settings.universe.include_options:
        atm.update(fh.fetch_atm(c.client, c.settings, missing))
    return atm


def cmd_live(args) -> int:
    from controller import fno_live as fl
    c = bootstrap(need_fyers=True)
    st = c.settings
    unds = [u.upper() for u in (args.underlyings or st.universe.underlyings)]
    if args.expiries:
        st = dataclasses.replace(st, universe=dataclasses.replace(st.universe, expiries_ahead=args.expiries))
    st = dataclasses.replace(st, universe=dataclasses.replace(st.universe, underlyings=tuple(unds)))
    atm = _atm_from_args(c, unds, args.atm)
    try:
        contracts, meta = fl.select_live_universe(c.repo.get_contracts(status="ACTIVE"), st, _today(), atm, args.max_subscriptions)
    except fh.AtmUnavailable as exc:
        print(f"ERROR: {exc}"); return 1
    if not contracts:
        print("ERROR: no ACTIVE contracts selected. Run fno-sync-contracts first."); return 1
    print(f"Live universe: {meta['subscribed']} contract(s) of {meta['eligible']} eligible (cap {meta['cap']}, dropped by cap {meta['dropped_by_cap']}).")
    ing = fl.FnoLiveIngestor(c.repo, None if args.no_parquet else c.store, st, contracts,
                             fetcher=FnoHistoryFetcher(c.client, st.history))
    token = f"{c.creds.client_id}:{c.creds.access_token}"
    # Subsystem A's builder logs every closed candle at INFO (one line per contract per minute); FNO logs one summary per flush.
    logging.getLogger("market_data.processing.candle_builder").setLevel(logging.WARNING)

    def factory(on_tick, on_reconnect, symbols):
        from model.fyers.websocket import FyersWebSocketClient
        return FyersWebSocketClient(access_token=token, symbols=symbols, on_tick=on_tick, on_reconnect=on_reconnect)
    import threading
    stop = threading.Event()
    print("Streaming. Ctrl+C stops: buffered candles are flushed and open minutes are closed.")
    try:
        from model.fno.release3_repository import Release3Repository
        with Release3Repository(c.engine).partition_lock("live_socket"):
            decision = fl.run_live(ing, factory, stop)
            if decision and not decision["open"]:
                print("NO_DATA: " + decision["reason"]); return 0
    except KeyboardInterrupt:
        stop.set(); ing.shutdown()
    s = ing.stats
    print(f"Stopped. ticks={s.ticks_received} (late={s.ticks_late}, duplicate={s.ticks_duplicate}, outside_session={s.ticks_outside_session}, "
          f"unknown={s.ticks_unknown_symbol}) candles_closed={s.candles_closed} persisted={s.candles_persisted} "
          f"flush_failures={s.flush_failures} dropped={s.candles_dropped_buffer_full} reconnects={s.reconnects}")
    return 0 if s.flush_failures == 0 and ing.buffered == 0 else 2


def cmd_chain_snapshot(args) -> int:
    from controller import fno_chain as fc
    c = bootstrap(need_fyers=True)
    unds = [u.upper() for u in (args.underlyings or c.settings.universe.underlyings)]
    store = None if args.no_parquet else c.store
    if args.loop:
        import threading
        stop = threading.Event()
        print(f"Chain snapshots every {c.settings.chain.interval_minutes} min during market hours. Ctrl+C to stop.")
        try:
            taken = fc.run_loop(c.repo, store, c.client, dataclasses.replace(c.settings, universe=dataclasses.replace(c.settings.universe, underlyings=tuple(unds))), stop)
        except KeyboardInterrupt:
            stop.set(); taken = 0
        print(f"Stopped after {taken} snapshot(s).")
        return 0
    results = fc.snapshot_all(c.repo, store, c.client, c.settings, underlyings=unds)
    bad = 0
    for r in results:
        if r.error:
            bad += 1
            print(f"  {r.underlying}: ERROR {r.error}")
        else:
            print(f"  {r.underlying} expiry {r.chain_expiry}: stored {r.rows_stored}/{r.rows_received} rows at {r.captured_at} "
                  f"(unknown symbols {r.unknown_symbols}, batch {r.batch_id[:8]})")
    return 0 if bad == 0 else 2


COMMANDS = {"fno-aggregate": cmd_local_job, "fno-verify": cmd_local_job,
            "fno-live": cmd_live, "fno-chain-snapshot": cmd_chain_snapshot, "fno-migrate": cmd_migrate, "fno-probe": cmd_probe, "fno-sync-contracts": cmd_sync_contracts,
            "fno-historical": cmd_historical, "fno-jobs": cmd_jobs, "fno-reconcile": cmd_reconcile, "fno-cleanup": cmd_cleanup}


def run_fno_mode(args) -> int:
    try:
        return COMMANDS[args.mode](args)
    except (ConfigurationError, IsolationError) as exc:
        print(f"CONFIGURATION ERROR: {exc}")
        return 1
    except TokenExpiredError as exc:
        print(f"TOKEN ERROR: {exc}")
        return 1
    except Exception as exc:
        from model.fyers.auth import FyersAuthError
        if isinstance(exc, FyersAuthError):
            print(f"FYERS AUTH ERROR: {exc}")
            return 1
        log.exception("FNO command failed")
        print(f"ERROR: {type(exc).__name__}: {exc}")
        return 1
