"""Preview or apply guarded session-filtered derived rebuilds."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--reports', nargs='+', type=Path)
    mode.add_argument('--apply-plan', type=Path)
    p.add_argument('--writers-stopped', action='store_true')
    p.add_argument('--accept-derived-replacement', action='store_true')
    args = p.parse_args(argv)
    for path in (args.reports or [args.apply_plan]):
        if not path.is_file(): p.error(f'Recovery report not found: {path}')
    if args.apply_plan and not (args.writers_stopped and args.accept_derived_replacement):
        p.error('--apply-plan requires --writers-stopped and --accept-derived-replacement')
    catalog = None
    try:
        from controller.workflow_cli import authenticate_admin
        from model.database_catalog import configured_catalog
        from model.cash_recovery import RecoveryStore
        from model.cash_rebuild import plan_rebuild
        from model.config.runtime_paths import state_path
        authenticate_admin(); catalog = configured_catalog()
        if args.apply_plan:
            from model.cash_rebuild_apply import apply_rebuild
            result = apply_rebuild(json.loads(args.apply_plan.read_text(encoding='utf-8-sig')),
                                   catalog.roots['CASH'], RecoveryStore(catalog.engine('CASH')),
                                   state_path('recovery/cash_derived_apply'), writers_stopped=True,
                                   accept_replacement=True,
                                   progress=lambda n,t: print(f'Derived rebuild {n}/{t}', flush=True))
            print(json.dumps({k:v for k,v in result.items() if k != 'outcomes'}))
            return 0 if result['status'] == 'SCOPED_DERIVED_REBUILD_VERIFIED' else 2
        reports = [json.loads(path.read_text(encoding='utf-8-sig')) for path in args.reports]
        result = plan_rebuild(reports, catalog.roots['CASH'], RecoveryStore(catalog.engine('CASH')),
                              state_path('recovery/cash_derived_rebuild'),
                              progress=lambda n, t: print(f'Rebuild preview {n}/{t}', flush=True))
        print(json.dumps(result)); return 0
    except Exception as exc:
        print(json.dumps({'status': 'STOPPED', 'error': type(exc).__name__,
                          'message': 'Keep the plan, backups and journal. If apply started, some commits may be complete.'})); return 1
    finally:
        if catalog:
            for engine in catalog._engines.values(): engine.dispose()


if __name__ == '__main__': raise SystemExit(main())
