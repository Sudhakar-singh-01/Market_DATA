"""
controller/scheduler.py
Automatic, unattended operation: starts live ingestion at market open,
stops it at market close, then runs a historical backfill (+ aggregate)
for the day that just finished -- so a fully "set and forget" process
can be left running (`python main.py schedule`) instead of requiring
manual `historical`/`live` commands every day.

Design principle: the TIME-DECISION logic (should we start/stop right
now) is pure and injectable-clock-testable (should_be_live_now,
is_just_after_close). The actual thread/loop orchestration around it
is thin and not unit-tested in the traditional sense, matching how
live_controller.py's blocking loop is handled -- only its components
are tested directly, not the infinite loop itself.

SESSION-WINDOW ASSUMPTION (same limitation as model/processing/gap_detector.py):
    Fixed 09:15-15:30 IST on trading days (Mon-Fri minus config/holidays.yaml).
    A weekday holiday NOT listed there will still "start live" at 9:15 -- FYERS's own
    WebSocket simply won't produce ticks on a non-trading day, so this
    degrades safely (no ticks -> no candles -> nothing incorrect gets
    stored) rather than fabricating anything, but it does mean the
    scheduler will spend a holiday "waiting" instead of skipping it
    outright. Documented, not silently handled.
"""

import datetime
import logging
import threading
from typing import Callable, Optional

from model.config.market_calendar import is_trading_day, session_window, live_session_status
from model.processing.models import IST

log = logging.getLogger("market_data.controller.scheduler")

MARKET_OPEN = datetime.time(9, 15)
MARKET_CLOSE = datetime.time(15, 30)

# How often the scheduler loop wakes up to check the clock. 30s is
# frequent enough that "start at 9:15" won't drift by more than that,
# without spinning the CPU.
POLL_INTERVAL_SECONDS = 30


def _is_trading_day(date: datetime.date) -> bool:
    # Monday-Friday minus holidays in config/holidays.yaml
    return is_trading_day(date)


def should_be_live_now(now: datetime.datetime) -> bool:
    """Pure function: True if `now` (IST) falls within today's
    configured trading session on a trading day (weekday, not listed in
    config/holidays.yaml).

    Upper bound is EXCLUSIVE (< MARKET_CLOSE, not <=) so that at the
    exact close instant this correctly reports "not live" -- letting
    on_market_close fire in the same tick that is_just_after_close()
    (which IS inclusive at MARKET_CLOSE) triggers the EOD job. If both
    were inclusive at the same instant, the scheduler would think it's
    still supposed to be live and never call on_market_close until a
    full poll interval later.
    """
    return live_session_status(now)["open"]


def is_just_after_close(now: datetime.datetime, grace_minutes: int = 2) -> bool:
    """True during a short window right after market close -- used to
    trigger the once-per-day EOD historical/aggregate run exactly
    once, not on every 30s poll for the rest of the evening."""
    if not _is_trading_day(now.date()):
        return False
    window = session_window(now.date())
    if window is None:
        return False
    close_dt = window[1].replace(tzinfo=None) if now.tzinfo is None else window[1]
    return close_dt <= now <= close_dt + datetime.timedelta(minutes=grace_minutes)


class DataEngineScheduler:
    """
    on_market_open: callable, no args, called ONCE when the session
        transitions from "not live" to "should be live". Expected to
        start live ingestion on a background thread and return quickly
        (not block) -- see main.py's wiring for the expected shape.
    on_market_close: callable, no args, called ONCE per day, shortly
        after MARKET_CLOSE, to stop live ingestion.
    on_end_of_day: callable, no args, called ONCE per day, right after
        on_market_close, to run historical backfill + aggregate for
        the day that just finished.
    now_fn: injectable clock for testability -- defaults to real IST
        "now", but tests pass a fixed/fake function instead of sleeping
        through a real trading day.
    """

    def __init__(
        self,
        on_market_open: Callable[[], None],
        on_market_close: Callable[[], None],
        on_end_of_day: Callable[[], None],
        now_fn: Optional[Callable[[], datetime.datetime]] = None,
    ):
        self._on_market_open = on_market_open
        self._on_market_close = on_market_close
        self._on_end_of_day = on_end_of_day
        self._now_fn = now_fn or (lambda: datetime.datetime.now(tz=IST))

        self._live_active = False
        self._eod_done_for_date: Optional[datetime.date] = None
        self._stop_event = threading.Event()

    def tick(self):
        """
        Runs exactly one decision cycle against the current clock.
        Exposed separately from run_forever() so tests can call tick()
        repeatedly with a controlled clock instead of sleeping through
        real time.
        """
        now = self._now_fn()

        if should_be_live_now(now) and not self._live_active:
            log.info(f"Market open ({now.time()}) -- starting live ingestion")
            self._on_market_open()
            self._live_active = True

        elif not should_be_live_now(now) and self._live_active:
            log.info(f"Market closed ({now.time()}) -- stopping live ingestion")
            self._on_market_close()
            self._live_active = False

        window=session_window(now.date())
        if window and now>=window[1]+datetime.timedelta(minutes=2) and self._eod_done_for_date != now.date():
            log.info(f"Running end-of-day historical backfill for {now.date()}")
            self._on_end_of_day()
            self._eod_done_for_date = now.date()

    def run_forever(self):
        log.info("Scheduler started. Press Ctrl+C to stop.")
        while not self._stop_event.is_set():
            try:
                self.tick()
            except Exception:
                log.exception("Scheduler tick failed -- will retry on next poll")
            self._stop_event.wait(POLL_INTERVAL_SECONDS)

    def stop(self):
        self._stop_event.set()
