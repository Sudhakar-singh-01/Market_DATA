"""Read-only final Cash recovery consistency report."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--preview',type=Path,required=True)
    p.add_argument('--derived-plans',type=Path,nargs='+',required=True)
    args=p.parse_args(argv)
    for path in [args.preview,*args.derived_plans]:
        if not path.is_file():p.error(f'Input not found: {path}')
    catalog=None;stage='admin_auth'
    try:
        from controller.workflow_cli import authenticate_admin
        from model.database_catalog import configured_catalog
        from model.cash_recovery import RecoveryStore
        from model.cash_final_check import final_check
        from model.config.runtime_paths import state_path
        authenticate_admin();stage='load_inputs'
        preview=json.loads(args.preview.read_text(encoding='utf-8-sig'))
        plans=[json.loads(path.read_text(encoding='utf-8-sig')) for path in args.derived_plans]
        catalog=configured_catalog();stage='consistency_check'
        result=final_check(preview,plans,catalog.roots['CASH'],RecoveryStore(catalog.engine('CASH')),
                           state_path('recovery/cash_final_check'),progress=lambda n,t:print(f'Checked {n}/{t}',flush=True))
        print(json.dumps({k:v for k,v in result.items() if k not in ('raw_results','derived_results')}))
        return 0 if result['status']=='SCOPED_STORAGE_PASS' else 2
    except Exception as exc:
        output={'status':'STOPPED','stage':stage,'error':type(exc).__name__,'market_data_modified':False,'sql_modified':False}
        if isinstance(exc,PermissionError):output['reason']='Admin authentication failed' if stage=='admin_auth' and str(exc)=='Admin authentication failed' else 'File or resource access denied'
        if isinstance(exc,OSError):output.update(errno=exc.errno,winerror=getattr(exc,'winerror',None),filename=str(exc.filename) if exc.filename else None)
        print(json.dumps(output));return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
