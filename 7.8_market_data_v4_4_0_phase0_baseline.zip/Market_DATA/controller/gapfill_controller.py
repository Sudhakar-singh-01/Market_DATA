"""
controller/gapfill_controller.py
Finds and fills missing 1-minute candles (after a live disconnect, an app
restart, or a skipped day) -- WITHOUT fabricating anything: only candles
that FYERS's historical API really returns are stored.

Two kinds of gap are detected per instrument:
  * tail gap     -- newest stored 1m candle is older than it should be
                    (live stopped / app was down).
  * internal gap -- missing session minutes between stored candles
                    (websocket dropped and reconnected). Uses the project's
                    own model/processing/gap_detector.find_gaps_1m.

Limitations (same as gap_detector.py, documented not hidden):
  * fixed 09:15-15:30 session on trading days (Mon-Fri minus config/holidays.yaml).
    A weekday holiday NOT listed there can show up as a tail gap; fetching it
    just returns no data and is harmless (the auto-filler also backs off).
  * minutes in which an instrument genuinely had no trades may not exist
    in FYERS history either -- those stay missing; the fill report says
    how many minutes remain missing after a fill.
Pure planning logic (plan_fills) is separated from the SQL (scan_mysql)
so it can be unit-tested without a database.
"""

import datetime
import logging
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Optional

from sqlalchemy import text, bindparam

from model.config.market_calendar import is_trading_day, previous_trading_day
from model.processing.models import IST
from model.processing.gap_detector import find_gaps_1m, _session_minutes_for_date, SESSION_START, SESSION_END

log = logging.getLogger("market_data.controller.gapfill")

# A candle for minute M closes when the first tick of M+1 arrives, then is written.
# Don't call a tail "missing" until it is older than this many minutes.
TAIL_GRACE_MINUTES = 3
MAX_TAIL_DAYS = 60  # cap one fill so a long-dead symbol can't trigger a huge pull


@dataclass
class FillTarget:
    internal_name: str
    fyers_symbol: str
    from_date: str
    to_date: str
    reason: str                 # 'tail' | 'internal' | 'tail+internal'
    missing_minutes: int
    gap_count: int = 0
    last_stored: Optional[str] = None


@dataclass
class SymbolData:
    internal_name: str
    fyers_symbol: str
    last_ts: Optional[datetime.datetime]            # newest stored 1m candle (naive IST), None = never ingested
    window_timestamps: list = field(default_factory=list)  # 1m timestamps inside the lookback window (naive IST)


def now_ist_naive() -> datetime.datetime:
    return datetime.datetime.now(IST).replace(tzinfo=None, second=0, microsecond=0)


def expected_last_candle(now: datetime.datetime) -> datetime.datetime:
    """Start time of the newest 1m candle that SHOULD already be stored at `now`."""
    d = now.date()
    t = now.time()
    if is_trading_day(d) and t >= SESSION_START:
        if t <= SESSION_END:
            return (now - datetime.timedelta(minutes=2)).replace(second=0, microsecond=0)
        return datetime.datetime.combine(d, datetime.time(15, 29))
    # weekend/holiday, or before today's open -> last trading day's final candle
    d = previous_trading_day(d)
    return datetime.datetime.combine(d, datetime.time(15, 29))


def _missing_in_range(start: datetime.datetime, end: datetime.datetime) -> int:
    """Session minutes strictly after `start` up to and including `end` (estimate of a tail gap)."""
    n = 0
    d = start.date()
    while d <= end.date():
        for m in _session_minutes_for_date(d):
            mm = m.replace(tzinfo=None)
            if start < mm <= end and mm.time() <= datetime.time(15, 29):
                n += 1
        d += datetime.timedelta(days=1)
    return n


def plan_fills(symbols: list, now: Optional[datetime.datetime] = None) -> tuple:
    """symbols: list[SymbolData]. Returns (targets, no_baseline_names)."""
    now = now or now_ist_naive()
    expected_last = expected_last_candle(now)
    targets, no_baseline = [], []

    for sd in symbols:
        if sd.last_ts is None:
            no_baseline.append(sd.internal_name)   # never ingested: needs an initial historical load, not a gap-fill
            continue

        reasons, dates, missing = [], [], 0
        gap_count = 0

        # ---- tail gap
        if sd.last_ts < expected_last - datetime.timedelta(minutes=TAIL_GRACE_MINUTES):
            est = _missing_in_range(sd.last_ts, expected_last)
            if est > 0:
                reasons.append("tail")
                missing += est
                dates += [sd.last_ts.date(), expected_last.date()]

        # ---- internal gaps inside the lookback window
        if sd.window_timestamps:
            fake = [SimpleNamespace(timestamp=t.replace(tzinfo=IST)) for t in sd.window_timestamps]
            gaps = find_gaps_1m(fake)
            if gaps:
                reasons.append("internal")
                gap_count = len(gaps)
                missing += sum(g.missing_minutes for g in gaps)
                dates += [min(g.date for g in gaps), max(g.date for g in gaps)]

        if not reasons:
            continue

        from_d, to_d = min(dates), max(dates)
        if (to_d - from_d).days > MAX_TAIL_DAYS:
            from_d = to_d - datetime.timedelta(days=MAX_TAIL_DAYS)
        targets.append(FillTarget(
            internal_name=sd.internal_name, fyers_symbol=sd.fyers_symbol,
            from_date=from_d.isoformat(), to_date=to_d.isoformat(),
            reason="+".join(reasons), missing_minutes=missing, gap_count=gap_count,
            last_stored=str(sd.last_ts),
        ))
    return targets, no_baseline


# ------------------------------------------------------------------ SQL side

def load_symbol_data(engine, instruments: list, lookback_days: int, now: Optional[datetime.datetime] = None) -> list:
    """One query for last_ts of every instrument + one for the lookback-window timestamps."""
    now = now or now_ist_naive()
    start = datetime.datetime.combine(now.date() - datetime.timedelta(days=lookback_days), datetime.time(0, 0))
    by_symbol = {i.fyers_symbol: SymbolData(i.internal_name, i.fyers_symbol, None) for i in instruments}
    if not by_symbol:
        return []
    names = list(by_symbol)

    last_q = text("""
        SELECT i.fyers_symbol AS s, MAX(c.candle_timestamp) AS last_ts
        FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.fyers_symbol IN :names
        GROUP BY i.id, i.fyers_symbol
    """).bindparams(bindparam("names", expanding=True))
    win_q = text("""
        SELECT i.fyers_symbol AS s, c.candle_timestamp AS ts
        FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.fyers_symbol IN :names AND c.candle_timestamp >= :start
        ORDER BY i.id, c.candle_timestamp
    """).bindparams(bindparam("names", expanding=True))

    with engine.connect() as conn:
        for row in conn.execute(last_q, {"names": names}):
            by_symbol[row.s].last_ts = row.last_ts
        for row in conn.execute(win_q, {"names": names, "start": start}):
            by_symbol[row.s].window_timestamps.append(row.ts)
    return list(by_symbol.values())


def scan_mysql(engine, instruments: list, lookback_days: int = 3, now: Optional[datetime.datetime] = None) -> tuple:
    """Returns (targets, no_baseline_names)."""
    return plan_fills(load_symbol_data(engine, instruments, lookback_days, now), now)


def count_missing(engine, instrument, from_date: str, to_date: str) -> int:
    """Remaining missing session minutes (internal gaps) for one instrument in a date range."""
    start = datetime.datetime.strptime(from_date, "%Y-%m-%d")
    end = datetime.datetime.strptime(to_date, "%Y-%m-%d") + datetime.timedelta(days=1)
    q = text("""
        SELECT c.candle_timestamp AS ts FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.fyers_symbol = :s AND c.candle_timestamp >= :a AND c.candle_timestamp < :b
        ORDER BY c.candle_timestamp
    """)
    with engine.connect() as conn:
        stamps = [r.ts for r in conn.execute(q, {"s": instrument.fyers_symbol, "a": start, "b": end})]
    gaps = find_gaps_1m([SimpleNamespace(timestamp=t.replace(tzinfo=IST)) for t in stamps])
    return sum(g.missing_minutes for g in gaps)


def delete_derived_range(engine, fyers_symbol: str, from_date: str, to_date: str) -> int:
    """Deprecated destructive entry point retained only to fail closed for old callers."""
    raise RuntimeError(
        "Delete-first derived rebuild is disabled. Use the guarded cash gap recovery and derived rebuild workflow."
    )
