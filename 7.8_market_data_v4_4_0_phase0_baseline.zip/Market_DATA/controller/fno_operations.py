"""Additional persisted handlers shared by CLI and the FNO dashboard."""
import dataclasses
import datetime as dt
import threading
from contextlib import contextmanager

from controller.fno_jobs import JobOutcome
from model.fno.models import IST
from model.fno.release3_repository import Release3Repository


@contextmanager
def stop_signal(handle):
    stop, done = threading.Event(),threading.Event()
    def monitor():
        while not done.wait(.5):
            if handle.shutdown_requested or handle.cancel_requested:
                stop.set()
                return
    t=threading.Thread(target=monitor,daemon=True)
    t.start()
    try: yield stop
    finally:
        done.set(); stop.set(); t.join(timeout=2)


def extra_handlers(c):
    from controller.fno_cli import ensure_fyers
    def sync(h):
        from model.fno import symbol_master as sm
        s=c.settings.symbol_master
        content=sm.download_symbol_master(s.url,c.settings.parquet_root/"symbol_master"/f"NSE_FO.{s.format}",s.max_age_hours,s.timeout_seconds)
        report=sm.parse_master(content,s.format,s.csv_columns)
        if not report.contracts: raise ValueError("No contracts parsed; check the symbol master format")
        return JobOutcome("SUCCESS",sm.sync_contracts(c.repo,report,c.settings.universe.underlyings,dt.datetime.now(IST).date()))
    def chain(h):
        from controller.fno_chain import snapshot_all,run_loop
        ensure_fyers(c)
        settings=dataclasses.replace(c.settings,universe=dataclasses.replace(c.settings.universe,
            underlyings=tuple(h.params.get("underlyings") or c.settings.universe.underlyings)))
        with Release3Repository(c.engine).partition_lock("chain_loop"):
            if h.params.get("loop"):
                with stop_signal(h) as stop:
                    count=run_loop(c.repo,c.store,c.client,settings,stop)
                return h.stop_outcome({"snapshots":count}) or JobOutcome("SUCCESS",{"snapshots":count})
            results=snapshot_all(c.repo,c.store,c.client,settings)
        return JobOutcome("PARTIAL" if any(r.error for r in results) else "SUCCESS",{"snapshots":[dataclasses.asdict(r) for r in results]})
    def live(h):
        from controller.fno_live import select_live_universe,FnoLiveIngestor,run_live
        from model.fno.history_client import FnoHistoryFetcher
        from model.fyers.websocket import FyersWebSocketClient
        from controller.fno_historical import fetch_atm
        ensure_fyers(c)
        st=dataclasses.replace(c.settings,universe=dataclasses.replace(c.settings.universe,
            underlyings=tuple(h.params.get("underlyings") or c.settings.universe.underlyings),
            expiries_ahead=int(h.params.get("expiries_ahead",c.settings.universe.expiries_ahead))))
        with Release3Repository(c.engine).partition_lock("live_socket"):
            atm=fetch_atm(c.client,st,st.universe.underlyings)
            contracts,meta=select_live_universe(c.repo.get_contracts(status="ACTIVE"),st,dt.datetime.now(IST).date(),atm)
            if not contracts: return JobOutcome("NO_DATA",{"universe":meta})
            ing=FnoLiveIngestor(c.repo,c.store,st,contracts,fetcher=FnoHistoryFetcher(c.client,st.history))
            token=f"{c.creds.client_id}:{c.creds.access_token}"
            def factory(on_tick,on_reconnect,symbols):
                return FyersWebSocketClient(access_token=token,symbols=symbols,on_tick=on_tick,on_reconnect=on_reconnect)
            with stop_signal(h) as stop: decision=run_live(ing,factory,stop)
            if decision and not decision["open"]:
                return JobOutcome("NO_DATA", {"reason":decision["reason"], "universe":meta})
        result={"universe":meta,"stats":dataclasses.asdict(ing.stats)}
        return h.stop_outcome(result) or JobOutcome("PARTIAL" if ing.buffered or ing.stats.flush_failures else "SUCCESS",result)
    def reconcile(h):
        from controller.fno_reconcile import reconcile as run
        report=run(c.repo,c.store,repair=False,from_date=dt.date.fromisoformat(h.params["from"]),to_date=dt.date.fromisoformat(h.params["to"]))
        return JobOutcome("SUCCESS" if report.ok else "PARTIAL",{"findings":report.findings[:100],"total_findings":len(report.findings)})
    return {"CONTRACT_SYNC":sync,"CHAIN_SNAPSHOT":chain,"LIVE":live,"RECONCILE":reconcile}
