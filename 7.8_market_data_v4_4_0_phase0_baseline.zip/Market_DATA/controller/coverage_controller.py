"""
controller/coverage_controller.py
Coverage heatmap logic: for every symbol and every trading day, how many of
the expected 1-minute candles are actually stored -- and exactly WHICH minutes
are missing.

Expected minutes: 09:15 .. 15:29 (375 candle-start times) on trading days
(Monday-Friday minus holidays in config/holidays.yaml; listed holidays are left out of the heatmap).
Today only counts up to the newest candle that should already exist (the last
minute or two are still forming). Same assumptions/limits as gap_detector.py:
unlisted holidays are not known. Because of that, a weekday on which NO selected
symbol has a single candle is treated as a probable holiday (greyed out, not
counted as missing) when `treat_empty_days_as_holiday` is on; turn it off to
see such days as 0% coverage (useful to spot a day that was never fetched).

Pure logic (build_matrix, missing_for_day, compress_ranges, build_fill_targets)
is separate from the SQL helpers so it can be unit-tested.
"""

import datetime
from dataclasses import dataclass
from typing import Optional

from sqlalchemy import text, bindparam

from model.config.market_calendar import is_trading_day
from controller.gapfill_controller import FillTarget, expected_last_candle, now_ist_naive

SESSION_FIRST = datetime.time(9, 15)
SESSION_MINUTES = 375  # 09:15 .. 15:29 inclusive


@dataclass
class DayCell:
    stored: int
    expected: int
    holiday: bool = False

    @property
    def missing(self) -> int:
        return 0 if self.holiday else max(self.expected - self.stored, 0)

    @property
    def pct(self) -> Optional[float]:
        if self.holiday or self.expected <= 0:
            return None
        return min(100.0 * self.stored / self.expected, 100.0)


def session_minutes(day: datetime.date) -> list:
    from model.config.market_calendar import expected_starts
    return [t.replace(tzinfo=None) for t in expected_starts(day)]


def expected_minutes(day: datetime.date, now: Optional[datetime.datetime] = None) -> list:
    cap = expected_last_candle(now or now_ist_naive())
    return [m for m in session_minutes(day) if m <= cap]


def weekdays_between(from_day: datetime.date, to_day: datetime.date) -> list:
    out, d = [], from_day
    while d <= to_day:
        if is_trading_day(d):
            out.append(d)
        d += datetime.timedelta(days=1)
    return out


def build_matrix(counts: dict, names: list, days: list, now: Optional[datetime.datetime] = None,
                 treat_empty_days_as_holiday: bool = False) -> dict:
    """counts: {(internal_name, date): stored_1m_count}. Returns {name: {day: DayCell}}.
    Days with no expected minutes yet (future / today pre-open) are dropped from the matrix."""
    now = now or now_ist_naive()
    days = [d for d in days if expected_minutes(d, now)]
    empty_days = set()
    if treat_empty_days_as_holiday:
        empty_days = {d for d in days if all(counts.get((n, d), 0) == 0 for n in names)}
    return {n: {d: DayCell(stored=counts.get((n, d), 0), expected=len(expected_minutes(d, now)),
                           holiday=d in empty_days) for d in days} for n in names}


def summarize(matrix: dict) -> dict:
    cells = [c for row in matrix.values() for c in row.values() if not c.holiday]
    expected = sum(c.expected for c in cells)
    stored = sum(min(c.stored, c.expected) for c in cells)
    return {
        "expected": expected, "stored": stored, "missing": expected - stored,
        "completeness_pct": (100.0 * stored / expected) if expected else None,
        "symbol_days": len(cells), "symbol_days_with_gaps": sum(1 for c in cells if c.missing > 0),
        "holiday_days": len({d for row in matrix.values() for d, c in row.items() if c.holiday}),
    }


def worst_symbols(matrix: dict, top: int = 10) -> list:
    rows = []
    for name, row in matrix.items():
        cells = [c for c in row.values() if not c.holiday]
        miss = sum(c.missing for c in cells)
        exp = sum(c.expected for c in cells)
        if miss:
            rows.append({"Symbol": name, "Missing minutes": miss,
                         "Days with gaps": sum(1 for c in cells if c.missing > 0),
                         "Coverage %": round(100.0 * (exp - miss) / exp, 2) if exp else None})
    return sorted(rows, key=lambda r: -r["Missing minutes"])[:top]


def missing_for_day(day: datetime.date, present: set, now: Optional[datetime.datetime] = None) -> list:
    """Expected minutes of `day` that are not in `present` (a set of naive minute timestamps)."""
    have = {p.replace(second=0, microsecond=0, tzinfo=None) for p in present}
    return [m for m in expected_minutes(day, now) if m not in have]


def compress_ranges(missing: list) -> list:
    """[(start, end, n_minutes)] for runs of consecutive missing minutes."""
    out, run = [], []
    for m in sorted(missing):
        if run and m - run[-1] == datetime.timedelta(minutes=1):
            run.append(m)
        else:
            if run:
                out.append((run[0], run[-1], len(run)))
            run = [m]
    if run:
        out.append((run[0], run[-1], len(run)))
    return out


def build_fill_targets(matrix: dict, fyers_by_name: dict) -> list:
    """One FillTarget per symbol covering its first..last day with gaps (feeds the gap-fill job)."""
    targets = []
    for name, row in matrix.items():
        gap_days = sorted(d for d, c in row.items() if c.missing > 0)
        if not gap_days:
            continue
        targets.append(FillTarget(
            internal_name=name, fyers_symbol=fyers_by_name[name],
            from_date=gap_days[0].isoformat(), to_date=gap_days[-1].isoformat(),
            reason="coverage", missing_minutes=sum(c.missing for c in row.values()),
            gap_count=len(gap_days)))
    return targets


# ------------------------------------------------------------------ SQL side

def _as_date(d) -> datetime.date:
    return d if isinstance(d, datetime.date) and not isinstance(d, datetime.datetime) else datetime.date.fromisoformat(str(d)[:10])


def load_daily_counts(engine, instruments: list, from_day: datetime.date, to_day: datetime.date) -> dict:
    """{(internal_name, date): number of 1m candles inside the 09:15-15:29 session window}."""
    if not instruments:
        return {}
    by_fyers = {i.fyers_symbol: i.internal_name for i in instruments}
    q = text("""
        SELECT i.fyers_symbol AS s, DATE(c.candle_timestamp) AS d, COUNT(*) AS k
        FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.fyers_symbol IN :names
          AND c.candle_timestamp >= :a AND c.candle_timestamp < :b
          AND TIME(c.candle_timestamp) >= '09:15:00' AND TIME(c.candle_timestamp) <= '15:29:59'
        GROUP BY i.fyers_symbol, DATE(c.candle_timestamp)
    """).bindparams(bindparam("names", expanding=True))
    a = datetime.datetime.combine(from_day, datetime.time(0, 0))
    b = datetime.datetime.combine(to_day + datetime.timedelta(days=1), datetime.time(0, 0))
    out = {}
    with engine.connect() as conn:
        for r in conn.execute(q, {"names": list(by_fyers), "a": a, "b": b}):
            out[(by_fyers[r.s], _as_date(r.d))] = int(r.k)
    return out


def load_day_minutes(engine, fyers_symbol: str, day: datetime.date) -> set:
    q = text("""
        SELECT c.candle_timestamp AS ts FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.fyers_symbol = :s AND c.candle_timestamp >= :a AND c.candle_timestamp < :b
    """)
    a = datetime.datetime.combine(day, datetime.time(0, 0))
    with engine.connect() as conn:
        rows = conn.execute(q, {"s": fyers_symbol, "a": a, "b": a + datetime.timedelta(days=1)}).fetchall()
    out = set()
    for r in rows:
        ts = r.ts if isinstance(r.ts, datetime.datetime) else datetime.datetime.fromisoformat(str(r.ts))
        out.add(ts.replace(second=0, microsecond=0, tzinfo=None))
    return out
