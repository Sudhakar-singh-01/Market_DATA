"""
controller/health_controller.py
Health check for the market-data engine's dependencies: FYERS API
reachability, MySQL connectivity, Parquet/exports directory
writability, and log directory writability.

Deliberately lightweight -- one cheap call per dependency, not a full
diagnostic suite. Intended for a quick "is everything reachable right
now" check before running historical/live, and for the dashboard's
health display.
"""

import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("market_data.controller.health")


@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str


@dataclass
class HealthReport:
    checks: list = field(default_factory=list)

    @property
    def all_ok(self) -> bool:
        return all(c.ok for c in self.checks)

    def log_report(self):
        log.info("=" * 60)
        log.info("HEALTH CHECK")
        for c in self.checks:
            log.info(f"  [{'OK' if c.ok else 'FAIL'}] {c.name}: {c.detail}")
        log.info(f"Overall: {'HEALTHY' if self.all_ok else 'UNHEALTHY'}")
        log.info("=" * 60)


def check_fyers(env) -> CheckResult:
    """
    Verifies the configured FYERS credentials/token actually work by
    calling get_profile() -- a real, lightweight, verified fyers-apiv3
    method (confirmed against multiple independent fyers-apiv3 usage
    examples) that returns account info without placing any order or
    fetching market data.
    """
    try:
        from model.fyers.auth import get_authenticated_client
        client = get_authenticated_client(env.fyers)
        from model.fyers.rate_limiter import acquire_shared
        acquire_shared()
        response = client.get_profile()
        if response.get("s") == "ok":
            return CheckResult("FYERS API", True, "Authenticated, profile fetched successfully")
        return CheckResult("FYERS API", False, f"Unexpected response: {response.get('message', response)}")
    except Exception as exc:
        # Never include the token/secret in the reported detail.
        return CheckResult("FYERS API", False, f"{type(exc).__name__}: could not authenticate or reach FYERS")


def check_mysql(env, data_settings) -> CheckResult:
    if not data_settings.storage.mysql_enabled:
        return CheckResult("MySQL", True, "Disabled in config (not checked)")
    try:
        from model.storage.mysql import build_db_url, get_engine
        from sqlalchemy import text
        engine = get_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        with engine.begin() as conn:
            conn.execute(text("SELECT 1"))
        return CheckResult("MySQL", True, f"Connected to {env.db.host}:{env.db.port}/{env.db.name}")
    except Exception as exc:
        return CheckResult("MySQL", False, f"{type(exc).__name__}: {exc}")


def check_parquet_writable(data_settings) -> CheckResult:
    if not data_settings.storage.parquet_enabled:
        return CheckResult("Parquet storage", True, "Disabled in config (not checked)")
    try:
        from model.storage_scope import cash_data_root
        root = cash_data_root()
        test_dir = root / "_health_check_tmp"
        test_dir.mkdir(parents=True, exist_ok=True)
        test_file = test_dir / "write_test.tmp"
        test_file.write_text("ok")
        test_file.unlink()
        test_dir.rmdir()
        return CheckResult("Parquet storage", True, f"{root} is writable (Cash; data parity not checked)")
    except Exception as exc:
        return CheckResult("Parquet storage", False, f"{type(exc).__name__}: {exc}")


def check_disk_space(min_free_gb: float = 1.0) -> CheckResult:
    try:
        usage = shutil.disk_usage(".")
        free_gb = usage.free / (1024 ** 3)
        ok = free_gb >= min_free_gb
        return CheckResult("Disk space", ok, f"{free_gb:.1f} GB free (minimum {min_free_gb} GB)")
    except Exception as exc:
        return CheckResult("Disk space", False, f"{type(exc).__name__}: {exc}")


def check_logs_writable(data_settings) -> CheckResult:
    try:
        log_dir = Path(data_settings.log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        test_file = log_dir / "_health_check_tmp.log"
        test_file.write_text("ok")
        test_file.unlink()
        return CheckResult("Logging", True, f"{log_dir} is writable")
    except Exception as exc:
        return CheckResult("Logging", False, f"{type(exc).__name__}: {exc}")


def run_health_check(env, data_settings, check_fyers_api: bool = True) -> HealthReport:
    """
    check_fyers_api=False skips the FYERS call -- useful when you only
    want to check storage/disk without spending an API call or without
    a configured token yet.
    """
    checks = [
        check_mysql(env, data_settings),
        check_parquet_writable(data_settings),
        check_disk_space(),
        check_logs_writable(data_settings),
    ]
    if check_fyers_api:
        checks.insert(0, check_fyers(env))

    report = HealthReport(checks=checks)
    report.log_report()
    return report
