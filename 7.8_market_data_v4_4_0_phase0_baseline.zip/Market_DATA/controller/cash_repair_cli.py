"""Plan/apply reviewed provider corrections with preserved SQL-only rows."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('plan');p.add_argument('--result',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=sub.add_parser('apply');a.add_argument('--plan',type=Path,required=True)
    a.add_argument('--writers-stopped',action='store_true');a.add_argument('--accept-provider',action='store_true')
    args=parser.parse_args(argv)
    source=args.result if args.command=='plan' else args.plan
    if not source.is_file():parser.error(f'Input file not found: {source}')
    if args.command=='plan' and (args.output.exists() or not args.output.parent.is_dir() or args.output.suffix!='.json'):parser.error('--output must be a new .json file in an existing directory')
    if args.command=='apply' and not(args.writers_stopped and args.accept_provider):parser.error('--writers-stopped and --accept-provider required')
    catalog=None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.cash_recovery import RecoveryStore,write_json_new
        from model.cash_repair import plan_repair,apply_repair
        from model.config.runtime_paths import state_path
        catalog=configured_catalog();root=catalog.roots['CASH']
        if root is None:raise ValueError('Cash storage disabled')
        store=RecoveryStore(catalog.engine('CASH'));data=json.loads(source.read_text(encoding='utf-8-sig'))
        if args.command=='plan':
            result=plan_repair(data,root,store);write_json_new(args.output,result)
            print(json.dumps({'status':'PLAN_CREATED','summary':result['summary'],'plan':str(args.output)}));return 0
        result=apply_repair(data,root,store,state_path('recovery/cash_provider_repair'),
            writers_stopped=True,accept_provider=True,progress=lambda n,t:print(f'Repair {n}/{t}'))
        print(json.dumps({k:v for k,v in result.items() if k not in ('outcomes','affected_partitions')}))
        return 2 if result['status']=='PARTIAL' else 0
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error':type(exc).__name__,
            'message':'Keep writers stopped. Retain the plan and repair journal; prior partitions or SQL commits may be complete.'}));return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
