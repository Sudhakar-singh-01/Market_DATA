"""Plan, then explicitly restore only absent SQL-identical Cash minute files."""
import argparse
import json
import sys
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    plan = sub.add_parser('plan')
    plan.add_argument('--preview', type=Path, required=True)
    plan.add_argument('--output', type=Path, required=True)
    apply = sub.add_parser('apply')
    apply.add_argument('--plan', type=Path, required=True)
    apply.add_argument('--writers-stopped', action='store_true')
    args = parser.parse_args(argv)
    if args.command == 'plan' and (args.output.exists() or args.output.suffix.lower() != '.json'):
        parser.error('--output must be a new .json file')
    if args.command == 'apply' and not args.writers_stopped:
        parser.error('--writers-stopped is required')
    catalog = None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.config.runtime_paths import state_path
        from controller.verification_controller import CashReader
        from model.cash_restore import make_plan, apply_plan
        catalog = configured_catalog()
        root = catalog.roots['CASH']
        if root is None: raise ValueError('Cash Parquet storage is disabled')
        reader = CashReader(catalog.engine('CASH'), root)
        if args.command == 'plan':
            preview = json.loads(args.preview.read_text(encoding='utf-8-sig'))
            result = make_plan(preview, root, reader,
                progress=lambda n,t: print(f'Plan checked {n}/{t}', file=sys.stderr))
            with args.output.open('x', encoding='utf-8') as stream:
                json.dump(result, stream, indent=2)
            print(json.dumps({'status': 'PLAN_READY' if result['ready'] else 'BLOCKED',
                              'summary': result['summary'], 'plan': str(args.output.absolute())}))
            return 0 if result['ready'] else 2
        plan = json.loads(args.plan.read_text(encoding='utf-8-sig'))
        result = apply_plan(plan, root, reader, state_path('logs/cash_restore'),
            writers_stopped=args.writers_stopped,
            progress=lambda phase,n,t: print(f'{phase}: {n}/{t}', file=sys.stderr))
        print(json.dumps(result))
        return 0
    except Exception as exc:
        print(json.dumps({'status': 'STOPPED', 'error': type(exc).__name__,
            'message': str(exc) if isinstance(exc, ValueError) else
                'Operation stopped. Keep writers stopped and inspect the plan/journal; earlier successful files are retained.'}))
        return 1
    finally:
        if catalog:
            for engine in catalog._engines.values(): engine.dispose()


if __name__ == '__main__':
    raise SystemExit(main())
