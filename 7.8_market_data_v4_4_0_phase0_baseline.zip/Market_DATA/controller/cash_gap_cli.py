"""Recover scoped incomplete sessions; optionally rebuild derived candles."""
import argparse
import datetime as dt
import json
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument('--result', type=Path)
    source.add_argument('--check-report', type=Path)
    p.add_argument('--date', type=dt.date.fromisoformat)
    p.add_argument('--apply', action='store_true')
    p.add_argument('--writers-stopped', action='store_true')
    p.add_argument('--accept-provider', action='store_true')
    p.add_argument('--rebuild', action='store_true')
    p.add_argument('--accept-derived-replacement', action='store_true')
    args = p.parse_args(argv)
    input_path = args.check_report or args.result
    if not input_path.is_file(): p.error(f'Result file not found: {input_path}')
    if args.check_report and not args.date: p.error('--check-report requires --date to bound recovery scope')
    if args.apply and not (args.writers_stopped and args.accept_provider):
        p.error('--apply requires --writers-stopped and --accept-provider')
    if args.rebuild and not(args.apply and args.accept_derived_replacement):
        p.error('--rebuild requires --apply and --accept-derived-replacement')
    catalog = None; stage = 'admin_auth'
    try:
        from controller.workflow_cli import authenticate_admin
        from controller.cash_resolution_cli import historical_fetcher
        from model.database_catalog import configured_catalog
        from model.cash_recovery import RecoveryStore
        from model.cash_gap_recovery import stage_gaps
        from model.config.runtime_paths import state_path
        authenticate_admin(); stage = 'stage_candidates'; catalog = configured_catalog()
        result = stage_gaps(json.loads(input_path.read_text(encoding='utf-8-sig')), catalog.roots['CASH'],
                            RecoveryStore(catalog.engine('CASH')), state_path('recovery/cash_session_gaps'),
                            historical_fetcher(), progress=lambda n, t: print(f'Session gap {n}/{t}', flush=True),
                            from_check=bool(args.check_report), day_filter=args.date)
        print(json.dumps(result), flush=True)
        if args.apply:
            # Never partially auto-apply a batch with failed validation.
            if result['selected_partitions'] == 0 or result['summary']['statuses'] != {'READY': result['selected_partitions']}:
                print(json.dumps({'status': 'NOT_APPLIED', 'reason': 'all_selected_partitions_must_be_ready',
                                  'plan': result['plan']})); return 2
            from model.cash_repair import apply_repair
            stage = 'raw_apply'
            applied = apply_repair(json.loads(Path(result['plan']).read_text()), catalog.roots['CASH'],
                                   RecoveryStore(catalog.engine('CASH')), state_path('recovery/cash_provider_repair'),
                                   writers_stopped=True, accept_provider=True,
                                   progress=lambda n, t: print(f'Gap repair {n}/{t}', flush=True))
            print(json.dumps({k: v for k, v in applied.items() if k not in ('outcomes', 'affected_partitions')}))
            if applied['status'] not in ('COMPLETE', 'BASE_REPAIR_VERIFIED'): return 2
            if args.rebuild:
                stage = 'derived_plan'
                from model.cash_rebuild import plan_rebuild
                from model.cash_rebuild_apply import apply_rebuild
                derived = plan_rebuild([applied], catalog.roots['CASH'], RecoveryStore(catalog.engine('CASH')),
                                       state_path('recovery/cash_derived_rebuild'),
                                       progress=lambda n,t: print(f'Derived plan {n}/{t}',flush=True))
                print(json.dumps(derived),flush=True)
                derived_plan = json.loads(Path(derived['plan']).read_text())
                if (any(s['status'] != 'SOURCE_VERIFIED' for s in derived_plan['sources']) or
                    any(e['status'] not in ('NEEDS_REBUILD','ALREADY_CONSISTENT') for e in derived_plan['entries'])):
                    print(json.dumps({'status':'DERIVED_NOT_APPLIED','plan':derived['plan'],
                                      'raw_report':applied['report'],'reason':'derived_plan_has_review_findings'})); return 2
                stage = 'derived_apply'
                rebuilt = apply_rebuild(derived_plan, catalog.roots['CASH'], RecoveryStore(catalog.engine('CASH')),
                                        state_path('recovery/cash_derived_apply'),writers_stopped=True,accept_replacement=True,
                                        progress=lambda n,t: print(f'Derived rebuild {n}/{t}',flush=True))
                print(json.dumps({k:v for k,v in rebuilt.items() if k != 'outcomes'}),flush=True)
                return 0 if rebuilt['status'] == 'SCOPED_DERIVED_REBUILD_VERIFIED' else 2
            return 0
        return 0
    except Exception as exc:
        failure = {'status': 'STOPPED', 'stage': stage, 'error': type(exc).__name__,
                   'message': 'Retain the generated plan and journal. If apply started, prior commits may be complete.'}
        if isinstance(exc, PermissionError) and stage == 'admin_auth' and str(exc) == 'Admin authentication failed':
            failure['reason'] = 'Admin authentication failed'
        if isinstance(exc, OSError):
            failure.update(errno=exc.errno, winerror=getattr(exc,'winerror',None), filename=str(exc.filename) if exc.filename else None)
        print(json.dumps(failure)); return 1
    finally:
        if catalog:
            for engine in catalog._engines.values(): engine.dispose()


if __name__ == '__main__': raise SystemExit(main())
