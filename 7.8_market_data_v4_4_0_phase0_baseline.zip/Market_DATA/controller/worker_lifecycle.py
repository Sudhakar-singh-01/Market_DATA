"""Cooperative process shutdown before CPython tears down executor pools.

CPython 3.13 has no public pre-thread-shutdown hook. Its threading hook is also
used by concurrent.futures; registering after that module ensures workers are
signalled before executor shutdown (callbacks run in reverse registration order).
No database or storage work is performed by the hook itself.
"""
import concurrent.futures.thread  # register the executor hook first
import threading
import time
import weakref
from contextlib import contextmanager

_stopping = threading.Event()
_events = weakref.WeakSet()
_threads = weakref.WeakSet()
_lock = threading.RLock()
_local = threading.local()


class WorkerInterrupted(Exception):
    pass


def register(event, thread=None):
    with _lock:
        if _stopping.is_set():
            event.set()
            raise WorkerInterrupted("Process is shutting down; new work refused")
        _events.add(event)
        if thread is not None:
            _threads.add(thread)


def stopping():
    event = getattr(_local, 'event', None)
    return _stopping.is_set() or (event is not None and event.is_set())


def check():
    if stopping():
        raise WorkerInterrupted("Worker shut down; resume to continue")


@contextmanager
def scope(event):
    previous = getattr(_local, 'event', None)
    _local.event = event
    try:
        yield
    finally:
        _local.event = previous


def shutdown(timeout=5.0):
    _stopping.set()
    with _lock:
        events, threads = list(_events), list(_threads)
    for event in events:
        event.set()
    deadline = time.monotonic() + timeout
    for thread in threads:
        if thread is not threading.current_thread() and thread.ident is not None:
            thread.join(max(0.0, deadline - time.monotonic()))


threading._register_atexit(shutdown)
