"""
controller/fno_chain.py
Option-chain snapshot scheduler, INDEPENDENT of candle building. FYERS returns only the CURRENT chain (the
`timestamp` parameter selects an EXPIRY, not a past moment) and no capture time, so every row is stamped with
OUR clock (IST) as captured_at; a historical chain exists only for snapshots this system captured. FYERS refreshes
chain data every few minutes: nothing here promises per-minute history.
One call per underlying and expiry (max 50 strikes each side, confirmed: 51 is clamped to 50), through the shared
low-priority rate limiter. Rows map to contracts by the REAL symbol in the response; symbols missing from the
contract master are counted and skipped, never inserted or constructed.
Order: MySQL (+count verification) first, then Parquet.
"""
import datetime
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from model.fno.chain import parse_chain
from model.fno.errors import TokenExpiredError
from model.fno.history_client import classify_response, AUTH, RATE_LIMIT, TransientFetchError
from model.fno.models import IST

log = logging.getLogger("market_data.fno.chain")


@dataclass
class SnapshotResult:
    underlying: str
    batch_id: Optional[str] = None
    captured_at: Optional[datetime.datetime] = None
    rows_received: int = 0
    rows_stored: int = 0
    unknown_symbols: int = 0
    skipped: dict = field(default_factory=dict)
    expiries_available: list = field(default_factory=list)
    chain_expiry: Optional[datetime.date] = None
    error: Optional[str] = None


def _call(client, payload: dict, settings, sleep=time.sleep):
    backoff = settings.history.initial_backoff_seconds
    for attempt in range(settings.history.max_retries + 1):
        try:
            resp = client.optionchain(data=payload)
            kind = classify_response(resp, settings.history)[0] if isinstance(resp, dict) and resp.get("s") != "ok" else "OK"
            msg = (resp or {}).get("message", "") if isinstance(resp, dict) else ""
        except (TimeoutError, ConnectionError, OSError) as exc:
            kind, msg, resp = "NETWORK", str(exc), None
        if kind == AUTH:
            raise TokenExpiredError(f"FYERS rejected the access token ({msg}). Run `python -m model.fyers.auth`.")
        if kind in (RATE_LIMIT, "NETWORK"):
            if attempt >= settings.history.max_retries:
                raise TransientFetchError(f"option chain {payload.get('symbol')}: {kind} after {attempt} retries ({msg})")
            sleep(backoff); backoff *= settings.history.backoff_multiplier
            continue
        return resp, kind, msg


def snapshot_once(repo, store, client, settings, underlying: str, expiry_timestamp: str = "",
                  clock=lambda: datetime.datetime.now(tz=IST), sleep=time.sleep) -> SnapshotResult:
    out = SnapshotResult(underlying)
    spot_symbol = settings.universe.spot_symbols.get(underlying)
    if not spot_symbol:
        out.error = f"no spot symbol configured for {underlying}"; return out
    payload = {"symbol": spot_symbol, "strikecount": settings.chain.strikecount, "timestamp": expiry_timestamp}
    if settings.chain.greeks:
        payload["greeks"] = "1"
    resp, kind, msg = _call(client, payload, settings, sleep)
    if kind != "OK":
        out.error = f"chain request failed: {kind} {msg}"; return out
    captured_at = clock().astimezone(IST).replace(tzinfo=None, microsecond=0)          # OUR clock: the response has none
    parsed = parse_chain(resp)
    out.rows_received, out.skipped, out.captured_at = len(parsed.rows), dict(parsed.skipped), captured_at
    out.expiries_available = [(d, ts) for d, ts in parsed.expiries]      # (date, timestamp-string)
    known = repo.contracts_by_symbol(r["symbol"] for r in parsed.rows)
    rows = []
    for r in parsed.rows:
        hit = known.get(r["symbol"])
        if hit is None:
            out.unknown_symbols += 1; continue
        rows.append({**r, "contract_id": hit[0], "chain_expiry": hit[1]})
    if not rows:
        out.error = "chain returned no rows that match the contract master (run fno-sync-contracts)"; return out
    out.batch_id = uuid.uuid4().hex
    out.chain_expiry = rows[0]["chain_expiry"]
    stored = repo.insert_chain_snapshot(out.batch_id, underlying, captured_at, rows)
    if stored != len(rows):
        raise RuntimeError(f"MySQL verification failed: stored {stored} of {len(rows)} chain rows")
    out.rows_stored = stored
    if store is not None:
        store.write_chain_snapshot([{**{k: r[k] for k in ("contract_id", "chain_expiry", "strike", "side", "ltp", "bid", "ask", "volume",
                                                           "oi", "oi_change", "iv", "delta", "gamma", "theta", "vega")},
                                     "batch_id": out.batch_id, "underlying": underlying, "captured_at": captured_at} for r in rows],
                                   underlying, captured_at.date())
    return out


def snapshot_all(repo, store, client, settings, underlyings=None, clock=lambda: datetime.datetime.now(tz=IST), sleep=time.sleep) -> list:
    """Nearest expiry first (empty timestamp), then up to expiries_ahead-1 further expiries using the timestamps FYERS
    lists in expiryData. If that list is missing or has an unexpected shape, only the nearest expiry is captured."""
    results = []
    for und in (u.upper() for u in (underlyings or settings.universe.underlyings)):
        try:
            first = snapshot_once(repo, store, client, settings, und, "", clock, sleep)
        except (TokenExpiredError, TransientFetchError) as exc:
            r = SnapshotResult(und); r.error = str(exc); results.append(r)
            if isinstance(exc, TokenExpiredError):
                break
            continue
        results.append(first)
        extra = [ts for d, ts in first.expiries_available if first.chain_expiry and d > first.chain_expiry][: max(0, settings.universe.expiries_ahead - 1)]
        for ts in extra:
            try:
                results.append(snapshot_once(repo, store, client, settings, und, ts, clock, sleep))
            except (TokenExpiredError, TransientFetchError) as exc:
                r = SnapshotResult(und); r.error = str(exc); results.append(r)
    return results


def run_loop(repo, store, client, settings, stop_event, clock=lambda: datetime.datetime.now(tz=IST), idle_seconds: float = 30.0) -> int:
    """During market hours: snapshot every chain.interval_minutes. Outside them: idle. Returns snapshots taken."""
    taken, next_due = 0, None
    sess = settings.session
    while not stop_event.is_set():
        now = clock().astimezone(IST)
        open_ = datetime.datetime.combine(now.date(), sess.open, tzinfo=IST)
        close = datetime.datetime.combine(now.date(), sess.close, tzinfo=IST)
        if open_ <= now <= close and now.weekday() < 5 and (next_due is None or now >= next_due):
            res = snapshot_all(repo, store, client, settings, clock=clock)
            taken += sum(1 for r in res if r.rows_stored)
            for r in res:
                if r.error:
                    log.warning("chain snapshot %s: %s", r.underlying, r.error)
            if any("rejected the access token" in (r.error or "") for r in res):
                break
            next_due = now + datetime.timedelta(minutes=settings.chain.interval_minutes)
        stop_event.wait(idle_seconds if not (open_ <= now <= close) else min(idle_seconds, 5.0))
    return taken
