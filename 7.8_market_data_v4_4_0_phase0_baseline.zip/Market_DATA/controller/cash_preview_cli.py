"""Read-only validation of Cash raw/1m inventory candidates."""
import argparse
import json
import sys
from pathlib import Path
from model.cash_inventory_preview import preview


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--with-sql', action='store_true', help='Authenticate admin and compare configured Cash SQL')
    parser.add_argument('--limit', type=int, help='Bounded trial; report remains partial')
    args = parser.parse_args(argv)
    if args.output.suffix.lower() != '.json' or args.output.exists():
        parser.error('--output must be a new .json file')
    if args.limit is not None and args.limit < 1: parser.error('--limit must be positive')
    catalog = None
    try:
        report = json.loads(args.inventory.read_text(encoding='utf-8-sig'))
        reader = None
        if args.with_sql:
            from controller.workflow_cli import authenticate_admin
            authenticate_admin()
            from model.database_catalog import configured_catalog
            from controller.verification_controller import CashReader
            catalog = configured_catalog()
            reader = CashReader(catalog.engine('CASH'), catalog.roots['CASH'])
        result = preview(report, reader, args.limit,
            lambda n, total: print(f'Validated {n}/{total} partitions...', file=sys.stderr))
        with args.output.open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2, default=str)
        print(json.dumps({'report': str(args.output.absolute()), 'complete': result['complete'],
                          'summary': result['summary'], 'import_allowed': False}))
        return 0 if result['complete'] else 2
    except Exception as exc:
        print(json.dumps({'status': 'ERROR', 'error': type(exc).__name__,
            'message': 'Check input report, output path, configuration and optional database access.'}))
        return 1
    finally:
        if catalog:
            for engine in catalog._engines.values(): engine.dispose()


if __name__ == '__main__':
    raise SystemExit(main())
