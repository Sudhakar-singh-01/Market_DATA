"""Read-only field-level audit of unresolved Cash partitions."""
import argparse
import json
import uuid
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--preview',type=Path,required=True)
    p.add_argument('--scope-plan',type=Path,required=True)
    args=p.parse_args(argv)
    for path in (args.preview,args.scope_plan):
        if not path.is_file():p.error(f'Input JSON file not found: {path}')
    catalog=None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.config.runtime_paths import state_path
        from model.cash_recovery import RecoveryStore,write_json_new
        from model.cash_conflict_audit import audit_conflicts
        from model.cash_restore import guard,require
        catalog=configured_catalog();root=catalog.roots['CASH']
        require(root is not None,'Cash_Parquet_disabled')
        report=audit_conflicts(json.loads(args.preview.read_text(encoding='utf-8-sig')),
            json.loads(args.scope_plan.read_text(encoding='utf-8-sig')),root,RecoveryStore(catalog.engine('CASH')),
            progress=lambda n,t:print(f'Audit {n}/{t}'))
        folder=guard(state_path('recovery/cash_conflicts'));folder.mkdir(parents=True,exist_ok=True)
        path=folder/('audit-'+uuid.uuid4().hex+'.json');write_json_new(path,report)
        print(json.dumps({'status':'AUDIT_COMPLETE' if report['complete'] else 'AUDIT_PARTIAL',
            'data_modified':False,'summary':report['summary'],'report':str(path)}))
        return 0 if report['complete'] else 2
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error':type(exc).__name__,'data_modified':False}))
        return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
