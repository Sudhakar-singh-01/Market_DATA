"""Offline inventory, deliberately independent of database and broker bootstrap."""
import argparse
import json
import sys
from pathlib import Path
from model.storage_inventory import inventory


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', action='append', required=True, help='Repeat for additional old-folder roots')
    parser.add_argument('--cash-root', required=True, help='Exact current Cash root containing raw/processed')
    parser.add_argument('--fno-root', required=True, help='Exact current FNO root containing candles/option_chain')
    parser.add_argument('--output', type=Path, help='New JSON report; existing files are never overwritten')
    args = parser.parse_args(argv)
    if args.output and args.output.suffix.lower() != '.json':
        parser.error('--output must be a new .json file')
    if args.output and args.output.exists():
        parser.error('--output already exists; use a new report filename')
    try:
        report = inventory(args.source, args.cash_root, args.fno_root,
            progress=lambda n: print(f'Scanned {n} Parquet paths...', file=sys.stderr))
        payload = json.dumps(report, indent=2, ensure_ascii=False)
        if args.output:
            with args.output.open('x', encoding='utf-8') as stream:
                stream.write(payload + '\n')
            print(json.dumps({'report': str(args.output.absolute()),
                'complete': report['complete'], 'summary': report['summary']}))
        else:
            print(payload)
        return 0 if report['complete'] else 2
    except (OSError, ValueError) as exc:
        print(json.dumps({'status': 'ERROR', 'error': type(exc).__name__,
                          'message': str(exc)}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
