"""Preserve session findings and stage historical candidates in one run."""
import argparse
import json
from dataclasses import asdict
from pathlib import Path


def historical_fetcher():
    client=None
    def fetch(meta,day):
        nonlocal client
        from model.config.env_loader import load_env_config
        from model.config.data_settings import load_data_settings
        from model.fyers.auth import get_authenticated_client
        from model.fyers.historical import fetch_historical_1m
        from model.config.instrument_loader import Instrument
        from model.processing.normalizer import normalize_historical_candle
        if client is None:client=get_authenticated_client(load_env_config().fyers)
        inst=Instrument(internal_name=meta['internal_name'],fyers_symbol=meta['fyers_symbol'],
            exchange=meta['exchange'],instrument_type=meta['instrument_type'],active=True,category='recovery')
        raw=fetch_historical_1m(client,inst.fyers_symbol,day.isoformat(),day.isoformat(),load_data_settings().retry)
        rows=[]
        for r in raw:
            row=asdict(normalize_historical_candle(r,inst));row['candle_timestamp']=row.pop('timestamp');rows.append(row)
        return rows
    return fetch


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--audit',type=Path,required=True)
    args=p.parse_args(argv)
    if not args.audit.is_file():p.error(f'Audit file not found: {args.audit}')
    catalog=None
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.cash_recovery import RecoveryStore
        from model.cash_resolution import resolve_candidates
        from model.config.runtime_paths import state_path
        catalog=configured_catalog()
        fetch=historical_fetcher()
        result=resolve_candidates(json.loads(args.audit.read_text(encoding='utf-8-sig')),catalog.roots['CASH'],
            RecoveryStore(catalog.engine('CASH')),state_path('recovery/cash_resolution'),fetch,
            progress=lambda n,t:print(f'Resolution {n}/{t}'))
        print(json.dumps({k:v for k,v in result.items() if k!='outcomes'}));return 0
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error':type(exc).__name__,'market_data_modified':False}));return 1
    finally:
        if catalog:
            for engine in catalog._engines.values():engine.dispose()


if __name__=='__main__':raise SystemExit(main())
