import datetime as dt
import json
import pandas as pd
import pytest
from model.config.market_calendar import IST
from model.storage_inventory import inventory
from model.cash_inventory_preview import preview

DAY=dt.date(2026,10,23)
REL='raw/1m/NSE_SBIN-EQ/2026-10-23.parquet'
NOW=dt.datetime(2026,10,27,tzinfo=IST)


def rows():
    return [dict(fyers_symbol='NSE:SBIN-EQ',timeframe='1m',
        candle_timestamp=dt.datetime(2026,10,23,9,15,tzinfo=IST),
        open=100.,high=102.,low=99.,close=101.,volume=10,source='FYERS',status='CLOSED')]


@pytest.fixture
def setup(tmp_path,monkeypatch):
    import model.cash_inventory_preview as m
    monkeypatch.setattr(m,'calendar_verified',lambda day:True)
    monkeypatch.setattr(m,'expected_starts',lambda day:[rows()[0]['candle_timestamp']])
    old,cash,fno=[tmp_path/n for n in ('old','cash','fno')]
    for p in (old,cash,fno):p.mkdir()
    def make(data=None):
        path=old/REL;path.parent.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(rows() if data is None else data).to_parquet(path,index=False)
        return inventory([old],cash,fno),path
    return make,old,cash,fno


class Reader:
    def instrument(self,symbol):return {'id':1}
    def sql_day(self,*args):
        r=rows()[0].copy();r.pop('fyers_symbol');r['candle_timestamp']=r['candle_timestamp'].replace(tzinfo=None)
        return [r]


def test_offline_never_approves_import(setup):
    make,*_=setup;report,path=make();before=path.read_bytes()
    result=preview(report,now=NOW)
    p=result['partitions'][0]
    assert p['status']=='REVIEW_REQUIRED'
    assert p['variants'][0]['status']=='VALIDATED_CANDIDATE'
    assert p['sql_status']=='NOT_CHECKED'
    assert result['import_allowed'] is False
    assert path.read_bytes()==before


def test_sql_matches_existing_naive_storage_contract(setup):
    make,*_=setup;report,_=make()
    p=preview(report,Reader(),now=NOW)['partitions'][0]
    assert p['status']=='VALIDATED_CANDIDATE'
    assert p['variants'][0]['sql_comparison']['value_mismatches']==0


@pytest.mark.parametrize('field,value,reason',[
 ('fyers_symbol','NSE:WRONG-EQ','identity_mismatch'),
 ('high',50.,'integrity_findings'),
 ('volume',-1,'integrity_findings'),
 ('status','OPEN','not_closed'),
 ('source','','missing_source')])
def test_invalid_rows(setup,field,value,reason):
    make,*_=setup;data=rows();data[0][field]=value;report,_=make(data)
    p=preview(report,now=NOW)['partitions'][0]
    assert p['status']=='REJECTED'
    assert reason in p['variants'][0]['quality']['issues']


def test_duplicates_rejected(setup):
    make,*_=setup;report,_=make(rows()*2)
    assert preview(report,now=NOW)['partitions'][0]['status']=='REJECTED'


def test_stale_inventory_blocks(setup):
    make,*_=setup;report,path=make();path.write_bytes(b'changed')
    assert preview(report,now=NOW)['partitions'][0]['status']=='UNAVAILABLE'


def test_calendar_and_naive_require_review(setup,monkeypatch):
    import model.cash_inventory_preview as m
    make,*_=setup;data=rows();data[0]['candle_timestamp']=data[0]['candle_timestamp'].replace(tzinfo=None)
    report,_=make(data);monkeypatch.setattr(m,'calendar_verified',lambda day:False)
    p=preview(report,Reader(),now=NOW)['partitions'][0]
    assert p['status']=='REVIEW_REQUIRED'
    assert len(p['variants'][0]['quality']['review_reasons'])==2


def test_variants_value_conflict(setup):
    make,old,cash,fno=setup;make();data=rows();data[0]['close']=100.
    other=old/'v2'/REL;other.parent.mkdir(parents=True);pd.DataFrame(data).to_parquet(other,index=False)
    p=preview(inventory([old],cash,fno),Reader(),now=NOW)['partitions'][0]
    assert p['comparisons'][0]['value_mismatches']==1
    assert p['status']=='REVIEW_REQUIRED'


def test_sql_unavailable_not_empty_success(setup):
    class Fail(Reader):
        def sql_day(self,*args):raise RuntimeError('no db')
    make,*_=setup;report,_=make()
    result=preview(report,Fail(),now=NOW)
    assert not result['complete']
    assert result['partitions'][0]['status']=='UNAVAILABLE'


def test_path_escape_and_schema_rejected(setup):
    make,*_=setup;report,path=make();report['roots']=[]
    assert preview(report,now=NOW)['partitions'][0]['status']=='UNAVAILABLE'
    report,_=make([{'x':1}])
    assert preview(report,now=NOW)['partitions'][0]['status']=='UNAVAILABLE'


def test_cli_no_overwrite(setup,tmp_path):
    from controller.cash_preview_cli import main
    make,*_=setup;report,_=make();src=tmp_path/'input.json';src.write_text(json.dumps(report))
    out=tmp_path/'output.json'
    args=['--inventory',str(src),'--output',str(out)]
    assert main(args)==0
    data=out.read_bytes()
    with pytest.raises(SystemExit):main(args)
    assert out.read_bytes()==data


def test_unverified_session_cannot_reject_by_session_alone(setup,monkeypatch):
    import model.cash_inventory_preview as m
    make,*_=setup;data=rows();data[0]['candle_timestamp']=dt.datetime(2026,10,23,16,0,tzinfo=IST)
    report,_=make(data);monkeypatch.setattr(m,'calendar_verified',lambda day:False)
    p=preview(report,now=NOW)['partitions'][0]
    assert p['status']=='REVIEW_REQUIRED'
    assert not p['variants'][0]['quality']['issues']


def test_partial_limit_is_incomplete(setup):
    make,old,cash,fno=setup;make()
    other=old/'raw/1m/NSE_SBIN-EQ/2026-10-22.parquet'
    pd.DataFrame(rows()).to_parquet(other,index=False)
    result=preview(inventory([old],cash,fno),limit=1,now=NOW)
    assert result['summary']['available_partitions']==2
    assert not result['complete']


def test_missing_minutes_require_review(setup,monkeypatch):
    import model.cash_inventory_preview as m
    make,*_=setup;report,_=make()
    ts=rows()[0]['candle_timestamp']
    monkeypatch.setattr(m,'expected_starts',lambda day:[ts,ts+dt.timedelta(minutes=1)])
    p=preview(report,Reader(),now=NOW)['partitions'][0]
    assert p['status']=='REVIEW_REQUIRED'
    assert p['variants'][0]['quality']['coverage']['missing']==1
