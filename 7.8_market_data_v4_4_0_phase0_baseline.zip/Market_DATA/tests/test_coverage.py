import datetime
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text

sys.path.insert(0, str(Path(__file__).parent))

from controller.coverage_controller import (
    DayCell, session_minutes, expected_minutes, weekdays_between, build_matrix, summarize, worst_symbols,
    missing_for_day, compress_ranges, build_fill_targets, load_daily_counts, load_day_minutes, SESSION_MINUTES,
)

D = datetime.datetime
FRI, MON, TUE = datetime.date(2026, 10, 9), datetime.date(2026, 10, 12), datetime.date(2026, 10, 13)
AFTER_CLOSE = D(2026, 10, 13, 18, 0)


def test_session_is_375_minutes_weekdays_only():
    m = session_minutes(FRI)
    assert len(m) == SESSION_MINUTES == 375 and m[0] == D(2026, 10, 9, 9, 15) and m[-1] == D(2026, 10, 9, 15, 29)
    assert session_minutes(datetime.date(2026, 10, 10)) == []          # Saturday


def test_today_only_counts_minutes_that_should_exist():
    now = D(2026, 10, 13, 10, 0)
    exp = expected_minutes(TUE, now)
    assert exp[-1] == D(2026, 10, 13, 9, 58)                           # last 2 minutes still forming
    assert expected_minutes(TUE, D(2026, 10, 13, 8, 0)) == []          # before the open: nothing expected yet


def test_matrix_pct_missing_and_summary():
    counts = {("A", FRI): 375, ("A", MON): 372, ("B", FRI): 375, ("B", MON): 0}
    mx = build_matrix(counts, ["A", "B"], [FRI, MON], AFTER_CLOSE)
    assert mx["A"][FRI].pct == 100 and mx["A"][MON].missing == 3
    assert mx["B"][MON].pct == 0 and mx["B"][MON].missing == 375
    s = summarize(mx)
    assert s["expected"] == 1500 and s["missing"] == 378 and s["symbol_days_with_gaps"] == 2
    assert worst_symbols(mx)[0]["Symbol"] == "B"


def test_day_with_no_data_for_any_symbol_is_a_holiday_when_enabled():
    counts = {("A", FRI): 375, ("B", FRI): 375}                         # MON: nobody has data
    on = build_matrix(counts, ["A", "B"], [FRI, MON], AFTER_CLOSE, treat_empty_days_as_holiday=True)
    off = build_matrix(counts, ["A", "B"], [FRI, MON], AFTER_CLOSE, treat_empty_days_as_holiday=False)
    assert on["A"][MON].holiday and on["A"][MON].pct is None and on["A"][MON].missing == 0
    assert summarize(on)["missing"] == 0 and summarize(on)["holiday_days"] == 1
    assert not off["A"][MON].holiday and off["A"][MON].missing == 375


def test_future_days_are_dropped():
    mx = build_matrix({}, ["A"], [FRI, datetime.date(2026, 10, 20)], AFTER_CLOSE, treat_empty_days_as_holiday=False)
    assert list(mx["A"].keys()) == [FRI]


def test_missing_minutes_and_ranges():
    present = set(session_minutes(FRI)) - {D(2026, 10, 9, 11, 0), D(2026, 10, 9, 11, 1), D(2026, 10, 9, 11, 2), D(2026, 10, 9, 13, 30)}
    miss = missing_for_day(FRI, present, AFTER_CLOSE)
    assert len(miss) == 4
    assert compress_ranges(miss) == [(D(2026, 10, 9, 11, 0), D(2026, 10, 9, 11, 2), 3), (D(2026, 10, 9, 13, 30), D(2026, 10, 9, 13, 30), 1)]
    assert compress_ranges([]) == []


def test_fill_targets_span_first_to_last_gap_day():
    counts = {("A", FRI): 300, ("A", MON): 375, ("A", TUE): 370, ("B", FRI): 375, ("B", MON): 375, ("B", TUE): 375}
    mx = build_matrix(counts, ["A", "B"], [FRI, MON, TUE], AFTER_CLOSE)
    t = build_fill_targets(mx, {"A": "NSE:A-EQ", "B": "NSE:B-EQ"})
    assert len(t) == 1 and t[0].internal_name == "A" and t[0].from_date == "2026-10-09" and t[0].to_date == "2026-10-13"
    assert t[0].missing_minutes == 75 + 5 and t[0].gap_count == 2


# ---------------------------------------------------------------- SQL (sqlite understands DATE()/TIME() too)

@pytest.fixture
def db(tmp_path):
    e = create_engine(f"sqlite:///{tmp_path / 'c.db'}")
    with e.begin() as c:
        c.execute(text("CREATE TABLE instruments (id INTEGER PRIMARY KEY, internal_name TEXT, fyers_symbol TEXT)"))
        c.execute(text("CREATE TABLE candles (id INTEGER PRIMARY KEY, instrument_id INT, timeframe TEXT, candle_timestamp TIMESTAMP)"))
        c.execute(text("INSERT INTO instruments VALUES (1,'A','NSE:A-EQ'),(2,'B','NSE:B-EQ')"))
        def add(inst, tf, ts):
            c.execute(text("INSERT INTO candles (instrument_id, timeframe, candle_timestamp) VALUES (:i,:t,:ts)"), {"i": inst, "t": tf, "ts": ts})
        for ts in session_minutes(FRI):
            add(1, "1m", ts)
        for ts in session_minutes(MON):
            if ts.time() not in (datetime.time(11, 0), datetime.time(11, 1)):
                add(1, "1m", ts)
        add(1, "1m", D(2026, 10, 9, 15, 30))     # outside the 09:15-15:29 window -> ignored
        add(1, "1m", D(2026, 10, 9, 9, 14))      # outside -> ignored
        add(1, "5m", D(2026, 10, 9, 10, 0))      # derived timeframe -> ignored
        add(2, "1m", D(2026, 10, 9, 10, 0))
    return e


class I:
    def __init__(self, n): self.internal_name, self.fyers_symbol = n, f"NSE:{n}-EQ"


def test_daily_counts_sql(db):
    counts = load_daily_counts(db, [I("A"), I("B")], FRI, MON)
    assert counts[("A", FRI)] == 375 and counts[("A", MON)] == 373 and counts[("B", FRI)] == 1
    assert ("B", MON) not in counts


def test_day_minutes_sql_gives_exact_missing(db):
    present = load_day_minutes(db, "NSE:A-EQ", MON)
    miss = missing_for_day(MON, present, AFTER_CLOSE)
    assert compress_ranges(miss) == [(D(2026, 10, 12, 11, 0), D(2026, 10, 12, 11, 1), 2)]


# ---------------------------------------------------------------- the page

def test_page_renders_heatmap_and_drilldown(db, monkeypatch):
    import ui.engine_bootstrap as eb
    from test_dashboard_layer import _authed_apptest
    from test_job_pages import _fake_config
    _fake_config(monkeypatch, mysql_enabled=True)
    monkeypatch.setattr(eb, "get_mysql_engine_or_none", lambda env, ds: db)

    # seed the instruments table with real registry names so the page's lookups match
    with db.begin() as c:
        c.execute(text("UPDATE instruments SET internal_name='RELIANCE', fyers_symbol='NSE:RELIANCE-EQ' WHERE id=1"))
        c.execute(text("UPDATE instruments SET internal_name='SBIN', fyers_symbol='NSE:SBIN-EQ' WHERE id=2"))
    if (datetime.date.today() - FRI).days + 1 > 180:
        pytest.skip("seeded dates fell out of the page's 180-day look-back limit")

    at = _authed_apptest("ui/pages/11_Coverage_Heatmap.py", "user", monkeypatch)
    assert not at.exception, [e.value for e in at.exception]
    assert any("Select at least one" in i.value for i in at.info)

    at.multiselect(key="cov_stocks").set_value(["RELIANCE", "SBIN"])
    at.number_input(key="cov_days").set_value(min(180, (datetime.date.today() - FRI).days + 1))
    at = at.run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(at.get("plotly_chart")) >= 2                        # heatmap + minute grid
    labels = {m.label: m.value for m in at.metric}
    assert labels["Missing minutes"] != "0"
    assert any(b.label == "Preview gap fill" for b in at.button)
