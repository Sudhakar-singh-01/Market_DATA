import datetime
import pytest

from model.config import market_calendar as mc
from model.exceptions import ConfigurationError
from model.processing.gap_detector import _session_minutes_for_date
from controller.coverage_controller import session_minutes, weekdays_between, build_matrix
from controller.gapfill_controller import expected_last_candle
from controller.scheduler import should_be_live_now, is_just_after_close
from model.processing.models import IST

D = datetime.date


@pytest.fixture
def hol(tmp_path):
    p = tmp_path / "holidays.yaml"
    p.write_text("verified_years: {CASH: [2026]}\nholidays:\n  - date: 2026-10-14\n    name: Test Holiday\n  - 2026-10-16\n")
    mc.reload_holidays(p)
    yield
    mc.reload_holidays()


def test_missing_file_means_plain_weekdays(tmp_path):
    mc.reload_holidays(tmp_path / "nope.yaml")
    assert mc.is_trading_day(D(2026, 10, 14)) and not mc.is_trading_day(D(2026, 10, 17))
    mc.reload_holidays()


def test_listed_holiday_is_not_trading_day(hol):
    assert not mc.is_trading_day(D(2026, 10, 14))
    assert mc.holiday_name(D(2026, 10, 14)) == "Test Holiday"
    assert mc.holiday_name(D(2026, 10, 16)) == "Holiday"
    assert mc.is_trading_day(D(2026, 10, 15))


def test_previous_trading_day_skips_holiday_and_weekend(hol):
    assert mc.previous_trading_day(D(2026, 10, 19)) == D(2026, 10, 15)  # Mon -> skip Sun, Sat, Fri(hol)
    assert mc.previous_trading_day(D(2026, 10, 15)) == D(2026, 10, 13)


@pytest.mark.parametrize("bad", ["holidays: 5", "holidays:\n  - date: not-a-date", "holidays:\n  - name: x"])
def test_malformed_raises(bad, tmp_path):
    p = tmp_path / "h.yaml"
    p.write_text(bad)
    with pytest.raises(ConfigurationError):
        mc.reload_holidays(p)
    mc.reload_holidays()


def test_gap_detector_and_coverage_skip_holiday(hol):
    assert _session_minutes_for_date(D(2026, 10, 14)) == []
    assert len(_session_minutes_for_date(D(2026, 10, 15))) == 375
    assert session_minutes(D(2026, 10, 14)) == []
    assert len(session_minutes(D(2026, 10, 15))) == 375
    assert weekdays_between(D(2026, 10, 12), D(2026, 10, 16)) == [D(2026, 10, 12), D(2026, 10, 13), D(2026, 10, 15)]


def test_heatmap_drops_holiday_column(hol):
    now = datetime.datetime(2026, 10, 18, 12, 0)
    m = build_matrix({}, ["X"], weekdays_between(D(2026, 10, 12), D(2026, 10, 16)), now, treat_empty_days_as_holiday=False)
    assert D(2026, 10, 14) not in m["X"] and D(2026, 10, 15) in m["X"]


def test_expected_last_candle_on_monday_after_holiday_friday(hol):
    now = datetime.datetime(2026, 10, 19, 8, 0)  # Monday before open; Fri 16th is a holiday
    assert expected_last_candle(now) == datetime.datetime(2026, 10, 15, 15, 29)


def test_scheduler_does_not_go_live_on_holiday(hol):
    assert not should_be_live_now(datetime.datetime(2026, 10, 14, 10, 0, tzinfo=IST))
    assert should_be_live_now(datetime.datetime(2026, 10, 15, 10, 0, tzinfo=IST))
    assert not is_just_after_close(datetime.datetime(2026, 10, 14, 15, 31, tzinfo=IST))
