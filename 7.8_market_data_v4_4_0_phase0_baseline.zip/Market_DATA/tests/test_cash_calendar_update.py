import copy
import datetime as dt
from dataclasses import asdict
from pathlib import Path
import pandas as pd
import pytest
import yaml
from model.config import market_calendar as mc
from model.config.cash_calendar_patch import merged_calendar, update_calendar, SPECIALS
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe, LiveTimeframeAggregator
from model.cash_calendar_review import review
from controller.timeframe_controller import _aggregation_coverage

BASE = {'verified_years':{'CASH':[2026],'FNO':[2026]}, 'holidays':['2026-10-20'],
        'verified_from':{'FNO':'2026-08-03'},'special_sessions':{
            '2026-02-01':{'verified':True,'open':'09:15','close':'15:30'},
            '2026-11-08':{'verified':False,'open':None,'close':None}}}
NOW=dt.datetime(2026,10,29,tzinfo=mc.IST)

@pytest.fixture
def calendar(tmp_path):
    path=tmp_path/'holidays.yaml';path.write_text(yaml.safe_dump(merged_calendar(BASE)))
    mc.reload_holidays(path)
    yield path
    mc.reload_holidays()


def candles(day):
    return [Candle('SBIN','NSE:SBIN-EQ','EQUITY','NSE',ts,'1m',100,102,99,101,10,'FYERS_HISTORICAL')
            for ts in mc.expected_starts(dt.date.fromisoformat(day))]


def test_patch_preserves_runtime_and_fno_and_is_idempotent(tmp_path):
    original=copy.deepcopy(BASE);updated=merged_calendar(BASE)
    assert BASE==original and merged_calendar(updated)==updated
    assert updated['verified_years']['FNO']==[2026]
    assert updated['verified_from']==BASE['verified_from']
    assert updated['holidays']==BASE['holidays']
    assert updated['special_sessions']['2026-02-01']==BASE['special_sessions']['2026-02-01']
    assert updated['special_sessions']['2026-11-08']==BASE['special_sessions']['2026-11-08']
    path=tmp_path/'holidays.yaml';old=yaml.safe_dump(BASE);path.write_text(old)
    preview=update_calendar(path);assert not preview['config_modified'] and path.read_text()==old
    with pytest.raises(ValueError):update_calendar(path,apply=True)
    result=update_calendar(path,apply=True,writers_stopped=True)
    assert Path(result['backup']).read_text()==old
    assert update_calendar(path,apply=True,writers_stopped=True)['status']=='CALENDAR_ALREADY_CURRENT'


def test_patch_conflict_has_no_config_write(tmp_path):
    data=copy.deepcopy(BASE);data['special_sessions']['2024-03-02']={'open':'09:00','close':'15:30'}
    path=tmp_path/'holidays.yaml';path.write_text(yaml.safe_dump(data));before=path.read_bytes()
    with pytest.raises(ValueError,match='conflict'):update_calendar(path,apply=True,writers_stopped=True)
    assert path.read_bytes()==before and not list(tmp_path.glob('*.bak'))


@pytest.mark.parametrize('day,count',[('2024-01-20',375),('2024-03-02',105),('2024-05-18',105),
    ('2024-11-01',60),('2025-02-01',375),('2025-10-21',60),('2026-02-01',375),
    ('2024-01-22',0),('2024-05-20',0),('2024-11-20',0),('2025-02-26',0)])
def test_expected_minutes(calendar,day,count):
    d=dt.date.fromisoformat(day);assert mc.calendar_verified(d)
    assert len(mc.expected_starts(d))==count


def test_fno_not_extended_by_cash_patch(calendar):
    assert not mc.calendar_verified(dt.date(2025,2,1),'FNO')
    assert mc.expected_starts(dt.date(2025,2,1),'FNO')==[]
    assert not mc.is_holiday(dt.date(2024,1,22),'FNO')
    assert mc.is_holiday(dt.date(2024,1,22),'CASH')
    assert len(mc.expected_starts(dt.date(2026,10,26),'FNO'))==385


def test_split_break_boundaries_and_live_status(calendar):
    day=dt.date(2024,3,2)
    for time,active in [('09:15',True),('09:59',True),('10:00',False),('11:29',False),('11:30',True),('12:30',False)]:
        ts=dt.datetime.fromisoformat(str(day)+'T'+time).replace(tzinfo=mc.IST)
        assert mc.in_session(ts)==active
        assert mc.live_session_status(ts)['open']==active
    assert len(mc.expected_starts(day,now=dt.datetime(2024,3,2,11,0,tzinfo=mc.IST)))==45


@pytest.mark.parametrize('tf,count',[('5m',21),('15m',7),('30m',4),('1h',2),('1d',1)])
def test_split_aggregation_daily_and_intraday(calendar,tf,count):
    rows=candles('2024-03-02');bars=aggregate_1m_to_timeframe(rows,tf)
    assert len(bars)==count and sum(c.volume for c in bars)==1050
    assert bars[0].timestamp.hour==9 and bars[0].timestamp.minute==15
    assert all(mc.in_session(c.timestamp) for c in bars)
    cov=_aggregation_coverage(rows,tf,'2024-03-02','2024-03-02','NSE:SBIN-EQ',now=NOW)
    assert cov['expected_1m_count']==105 and cov['missing_1m_count']==cov['incomplete_bucket_count']==0
    live=LiveTimeframeAggregator([tf]);got=[]
    for row in rows:got.extend(live.on_1m_candle(row))
    got.extend(live.flush_all());assert got==bars


def test_missing_minute_cannot_hide_in_break_or_daily(calendar):
    rows=candles('2024-03-02');rows.pop(46)
    assert aggregate_1m_to_timeframe(rows,'1d')==[]
    cov=_aggregation_coverage(rows,'1d','2024-03-02','2024-03-02','NSE:SBIN-EQ',now=NOW)
    assert cov['expected_1m_count']==105 and cov['missing_1m_count']==1
    from model.quality import integrity
    row=asdict(rows[0]);row['candle_timestamp']=dt.datetime(2024,3,2,10,30,tzinfo=mc.IST)
    assert integrity([row],'1m',dt.date(2024,3,2),NOW)['samples'][0]['reasons']==['outside_session']


def test_malformed_split_interval_fails(calendar):
    data=yaml.safe_load(calendar.read_text());data['special_sessions']['2024-03-02']['intervals'][1]['open']='09:30'
    calendar.write_text(yaml.safe_dump(data))
    with pytest.raises(Exception,match='Invalid special-session interval'):mc.expected_starts(dt.date(2024,3,2))


def test_fast_review_only_special_files_preserves_bytes(calendar,tmp_path):
    root=tmp_path/'cash';root.mkdir();rel='raw/1m/NSE_SBIN-EQ/2025-10-21.parquet'
    rows=[]
    for c in candles('2025-10-21'):
        r=asdict(c);r['candle_timestamp']=r.pop('timestamp');rows.append(r)
    rows.append(dict(rows[-1],candle_timestamp=dt.datetime(2025,10,21,14,45,tzinfo=mc.IST)))
    path=root/rel;path.parent.mkdir(parents=True);pd.DataFrame(rows).to_parquet(path,index=False);before=path.read_bytes()
    report=dict(status='SCOPED_STORAGE_PASS',complete=True,raw_results=[
        dict(relative_path=rel,rows=61,quality_review_reasons=['calendar_not_verified']),
        dict(relative_path='raw/1m/NSE_SBIN-EQ/2024-01-01.parquet',rows=375,quality_review_reasons=['calendar_not_verified'])])
    result=review(report,root,tmp_path/'reports',now=NOW)
    assert result['summary']['parquet_files_checked']==1 and result['summary']['report_only_partitions']==1
    actual=next(r for r in result['results'] if r['fresh_rows_checked'])
    assert actual['status']=='REVIEW_REQUIRED' and actual['missing_minutes']==0 and actual['outside_minutes']==1
    assert path.read_bytes()==before and result['sql_modified'] is False


def test_cli_updates_then_reviews_without_database(tmp_path,monkeypatch,capsys):
    import json
    from controller.cash_calendar_cli import main
    import controller.workflow_cli as workflow
    import model.config.runtime_paths as paths
    import model.storage_scope as storage
    monkeypatch.setattr(workflow,'authenticate_admin',lambda:None)
    cfg=tmp_path/'holidays.yaml';cfg.write_text(yaml.safe_dump(BASE))
    monkeypatch.setattr(paths,'config_path',lambda _:cfg)
    monkeypatch.setattr(paths,'state_path',lambda _:tmp_path/'reports')
    root=tmp_path/'cash';root.mkdir();monkeypatch.setattr(storage,'cash_data_root',lambda:root)
    mc.reload_holidays(cfg)
    try:
        report=tmp_path/'check.json'
        report.write_text(json.dumps(dict(status='SCOPED_STORAGE_PASS',complete=True,raw_results=[
            dict(relative_path='raw/1m/NSE_SBIN-EQ/2024-01-01.parquet',rows=375,quality_review_reasons=['calendar_not_verified'])])))
        assert main(['--apply','--writers-stopped','--check-report',str(report)])==0
        output=[json.loads(s) for s in capsys.readouterr().out.splitlines()]
        assert output[0]['status']=='CALENDAR_UPDATED'
        assert output[1]['summary']['statuses']=={'REPORT_ONLY_CALENDAR_MATCH':1}
        assert 'NSE-CASH-2024-2025' in mc.calendar_metadata()['version']
        assert main(['--check-report',str(report)])==0
        assert json.loads(capsys.readouterr().out.splitlines()[0])['status']=='CALENDAR_ALREADY_CURRENT'
    finally:
        mc.reload_holidays()
