"""Schema orchestration tests with disposable SQLite; MySQL guard is not bypassed in production."""
import copy
import json
from contextlib import nullcontext
import pytest
from sqlalchemy import create_engine, text, inspect
from model.database_catalog import DatabaseCatalog
from model.schema_management import SchemaManager, owned_definitions


@pytest.fixture
def manager(tmp_path, monkeypatch):
    engine = create_engine('sqlite:///'+str(tmp_path/'test.db'))
    catalog = DatabaseCatalog({'CASH':lambda:engine})
    class LocalManager(SchemaManager):
        def _engine(self,segment): return engine
        def _database_lock(self,engine): return nullcontext()
        # These orchestration fixtures deliberately use SQLite-only definitions.
        # MySQL contract comparison is covered separately.
        def compatibility(self,segment,*,role):
            return {'status':'COMPATIBLE','findings':[]}
    monkeypatch.setattr('model.schema_management.owned_definitions',lambda segment:{
        'instruments':'CREATE TABLE instruments (id INTEGER PRIMARY KEY, name TEXT)',
        'candles':'CREATE TABLE candles (id INTEGER PRIMARY KEY, instrument_id INTEGER REFERENCES instruments(id))'})
    return LocalManager(catalog,tmp_path/'journal'),engine


def apply(manager, plan):
    return manager.apply(plan,role='admin',confirmation='APPLY '+plan['database'],backup_acknowledged=True)


def test_owned_manifest_excludes_database_switch_and_dml():
    cash=owned_definitions('CASH'); fno=owned_definitions('FNO')
    assert set(cash)=={'instruments','candles','checkpoints','ingestion_jobs','audit_log','error_logs','data_quality_results','pipeline_events'}
    assert len(fno)==10
    assert all(n.startswith('fno_') for n in fno)
    assert all(s.startswith('CREATE TABLE ') for s in [*cash.values(),*fno.values()])
    assert 'UPDATE fno_instruments' not in '\n'.join(fno.values())


def test_preview_readonly_apply_missing_and_preserve_existing_rows(manager):
    service,engine=manager
    with engine.begin() as c:
        c.execute(text('CREATE TABLE instruments (id INTEGER PRIMARY KEY, name TEXT)'))
        c.execute(text("INSERT INTO instruments VALUES (1,'SBIN')"))
    plan=service.preview('CASH',role='admin')
    assert plan['missing_tables']==['candles']
    assert inspect(engine).get_table_names()==['instruments']
    result=apply(service,plan)
    assert result['status']=='SUCCESS' and result['completed']==1
    with engine.connect() as c: assert c.execute(text('SELECT name FROM instruments')).scalar()=='SBIN'
    assert service.preview('CASH',role='admin')['statements']==[]
    events=[json.loads(line) for line in open(result['journal'])]
    assert [e['event'] for e in events]==['START','STATEMENT_START','STATEMENT_DONE','SUCCESS']


def test_schema_change_invalidates_preview(manager):
    service,engine=manager
    plan=service.preview('CASH',role='admin')
    with engine.begin() as c: c.execute(text('CREATE TABLE external_change (id INTEGER PRIMARY KEY)'))
    with pytest.raises(ValueError,match='changed'): apply(service,plan)
    assert 'instruments' not in inspect(engine).get_table_names()


def test_tampered_statement_cannot_execute(manager):
    service,engine=manager
    plan=service.preview('CASH',role='admin')
    tampered=copy.deepcopy(plan); tampered['statements']=['DROP TABLE instruments']
    with pytest.raises(ValueError,match='changed'): apply(service,tampered)
    assert inspect(engine).get_table_names()==[]


def test_role_confirmation_backup_fail_closed(manager):
    service,engine=manager
    with pytest.raises(PermissionError): service.preview('CASH',role='user')
    plan=service.preview('CASH',role='admin')
    with pytest.raises(PermissionError): service.apply(plan,role='user',confirmation='x')
    with pytest.raises(ValueError,match='backup'): service.apply(plan,role='admin',confirmation='x')
    with pytest.raises(ValueError,match='Type APPLY'): service.apply(plan,role='admin',confirmation='x',backup_acknowledged=True)
    assert inspect(engine).get_table_names()==[]


def test_partial_failure_reports_completed_and_can_repreview(manager,monkeypatch):
    service,engine=manager
    monkeypatch.setattr('model.schema_management.owned_definitions',lambda segment:{
        'instruments':'CREATE TABLE instruments (id INTEGER PRIMARY KEY)',
        'broken':'CREATE TABLE broken (INVALID SQL !)'})
    result=apply(service,service.preview('CASH',role='admin'))
    assert result['status']=='PARTIAL_OR_FAILED' and result['completed']==1
    assert inspect(engine).get_table_names()==['instruments']
    assert json.loads(open(result['journal']).readlines()[-1])['event']=='FAILED'
    assert service.preview('CASH',role='admin')['missing_tables']==['broken']


def test_journal_failure_prevents_ddl(manager,tmp_path):
    service,engine=manager
    blocked=tmp_path/'file'; blocked.write_text('not a directory'); service.journal_root=blocked
    with pytest.raises(OSError): apply(service,service.preview('CASH',role='admin'))
    assert inspect(engine).get_table_names()==[]


def test_real_manager_refuses_non_mysql(manager):
    service,engine=manager
    with pytest.raises(ValueError,match='MySQL'):
        SchemaManager(service.catalog).preview('CASH',role='admin')


def test_pipeline_requires_audit_dependency(manager):
    service,_=manager
    with pytest.raises(ValueError,match='audit_log'): service.preview('CASH','cash_pipeline',role='admin')
    with pytest.raises(ValueError,match='Unsupported'): service.preview('FNO','cash_pipeline',role='admin')


def test_compatibility_blocker_prevents_any_ddl(manager,monkeypatch):
    service,engine=manager
    monkeypatch.setattr(service,'compatibility',lambda *a,**k:{'status':'INCOMPATIBLE','findings':[
        {'table':'instruments','kind':'column_type','severity':'BLOCKING'}]})
    plan=service.preview('CASH',role='admin')
    assert not plan['can_apply']
    with pytest.raises(ValueError,match='preflight'): apply(service,plan)
    assert inspect(engine).get_table_names()==[]


def test_duplicate_active_keys_block_index_without_exposing_values(manager,monkeypatch):
    service,engine=manager
    with engine.begin() as c:
        c.execute(text('CREATE TABLE audit_log (id INTEGER)'))
        c.execute(text('CREATE TABLE ingestion_jobs (active_key TEXT)'))
        c.execute(text("INSERT INTO ingestion_jobs VALUES ('private-key'),('private-key'),(NULL),(NULL)"))
    monkeypatch.setattr('model.schema_management.migration_plan',lambda e:[
        'CREATE UNIQUE INDEX uq_pipeline_active ON ingestion_jobs (active_key)'])
    plan=service.preview('CASH','cash_pipeline',role='admin')
    assert plan['blockers'][0]['kind']=='duplicate_active_key'
    assert 'private-key' not in json.dumps(plan)
    with pytest.raises(ValueError,match='preflight'): apply(service,plan)
    with engine.begin() as c:
        c.execute(text("DELETE FROM ingestion_jobs WHERE rowid=1"))
    fresh=service.preview('CASH','cash_pipeline',role='admin')
    assert fresh['can_apply']
    assert apply(service,fresh)['status']=='SUCCESS'
