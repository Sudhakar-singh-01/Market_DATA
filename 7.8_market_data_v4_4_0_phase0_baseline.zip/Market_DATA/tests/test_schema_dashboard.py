"""Exercise actual schema page controls without opening a database."""
from pathlib import Path
from types import SimpleNamespace
import pytest
import streamlit as st
from streamlit.testing.v1 import AppTest


@pytest.fixture
def page(monkeypatch):
    from model import schema_management, database_catalog
    from ui import auth
    st.cache_resource.clear()
    class Service:
        catalog = SimpleNamespace(factories={'CASH':None,'FNO':None})
        calls = []
        blocked = True
        def compatibility(self,segment,**kwargs):
            self.calls.append('check')
            return {'status':'INCOMPATIBLE','findings':[], 'limitations':[]}
        def preview(self,segment,operation,**kwargs):
            self.calls.append('preview')
            return {'segment':segment,'operation':operation,'database':'test_db','token':'abcdef',
                    'missing_tables':['candles'],'statements':['CREATE TABLE candles (id INT)'],
                    'compatibility':{'status':'INCOMPATIBLE' if self.blocked else 'MISSING'},
                    'blockers':[{'kind':'column'}] if self.blocked else [],'can_apply':not self.blocked}
        def apply(self,*args,**kwargs):
            self.calls.append('apply')
            return {'status':'SUCCESS'}
    service=Service()
    monkeypatch.setattr(schema_management,'SchemaManager',lambda c:service)
    monkeypatch.setattr(database_catalog,'configured_catalog',lambda:None)
    monkeypatch.setattr(auth,'require_auth',lambda role:True)
    monkeypatch.setattr(auth,'current_role',lambda:'admin')
    app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'ui/pages/30_Admin_Schema_Manager.py')).run()
    yield app,service
    st.cache_resource.clear()


def button(app,label):
    return next(b for b in app.button if b.label==label)


def test_compatibility_is_readonly_and_blocked_plan_has_no_apply(page):
    app,service=page
    button(app,'Check schema compatibility (read only)').click().run()
    assert not app.exception and service.calls==['check']
    button(app,'Preview schema changes').click().run()
    assert not app.exception
    assert not any(b.label=='Apply reviewed plan' for b in app.button)
    assert 'apply' not in service.calls


def test_allowed_plan_requires_confirmation_and_segment_switch_hides_plan(page):
    app,service=page
    service.blocked=False
    button(app,'Preview schema changes').click().run()
    assert not app.exception and button(app,'Apply reviewed plan').disabled
    next(s for s in app.selectbox if s.label=='Segment').select('FNO').run()
    assert not app.exception
    assert not any(b.label=='Apply reviewed plan' for b in app.button)
    assert 'apply' not in service.calls
