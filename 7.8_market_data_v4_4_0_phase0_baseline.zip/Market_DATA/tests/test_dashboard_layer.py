"""
Tests for the dashboard/control layer (ui/*). Run from the project root:
    pip install pytest
    pytest tests -q
Covers the security-critical pieces that can be verified without a live
Streamlit session, FYERS, or MySQL: hashing, role gates, lockout, file
explorer restrictions, bulk-delete filter safety, live restart, API helpers.
"""

import ast
import dataclasses
import datetime
import inspect
import json
import re
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

import pandas as pd
import pytest
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session", autouse=True)
def _dummy_env_for_config_loading():
    """A handful of tests need load_config_or_stop() to succeed (to reach
    widgets *after* the auth gate) without a real FYERS/MySQL setup. This
    provisions a throwaway config/.env for the test session only and
    removes it afterwards -- the shipped project must NOT include a
    config/.env (the person creates their own from .env.example)."""
    env_path = ROOT / "config" / ".env"
    pre_existing = env_path.exists()
    if not pre_existing:
        env_path.write_text(
            "FYERS_CLIENT_ID=TEST-100\nFYERS_SECRET_KEY=testsecret\nFYERS_REDIRECT_URI=http://localhost\n"
            "FYERS_ACCESS_TOKEN=\nDB_HOST=localhost\nDB_PORT=3306\nDB_NAME=market_data_test\n"
            "DB_USER=test\nDB_PASSWORD=test\nUSER_PASSWORD_HASH=\nADMIN_PASSWORD_HASH=\nSESSION_TIMEOUT_MINUTES=480\n"
        )
    yield
    if not pre_existing:
        env_path.unlink(missing_ok=True)


# ------------------------------------------------------------------ password hashing
def test_password_hash_roundtrip_and_no_plaintext():
    from ui.password_hashing import hash_password, verify_password
    h = hash_password("s3cret!")
    assert "s3cret!" not in h
    assert verify_password("s3cret!", h)
    assert not verify_password("wrong", h)
    assert not verify_password("s3cret!", "malformed-value")  # fails closed


def test_same_password_gets_different_salts():
    from ui.password_hashing import hash_password
    assert hash_password("x") != hash_password("x")


# ------------------------------------------------------------------ auth / roles / lockout
@pytest.fixture
def auth(monkeypatch):
    import ui.auth as auth_mod
    from ui.password_hashing import hash_password
    fake_st = MagicMock()
    fake_st.session_state = {}
    fake_st.form_submit_button.return_value = False  # "haven't clicked Log in yet" by default
    fake_st.text_input.return_value = ""
    monkeypatch.setattr(auth_mod, "st", fake_st)
    monkeypatch.setattr(auth_mod, "_load_env", lambda: None)
    monkeypatch.setattr(auth_mod, "_try_audit_log", lambda *a, **k: None)
    monkeypatch.setenv("USER_PASSWORD_HASH", hash_password("userpw"))
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", hash_password("adminpw"))
    return auth_mod, fake_st


def test_not_logged_in_is_rejected(auth):
    mod, _ = auth
    assert mod.require_auth("user") is False
    assert mod.require_auth("admin") is False


def test_user_role_cannot_pass_admin_gate(auth):
    mod, st = auth
    st.session_state.update({"auth_role": "user", "auth_login_time": time.time()})
    assert mod.require_auth("user") is True
    assert mod.require_auth("admin") is False      # user must NOT reach admin pages


def test_admin_role_passes_both_gates(auth):
    mod, st = auth
    st.session_state.update({"auth_role": "admin", "auth_login_time": time.time()})
    assert mod.require_auth("user") is True
    assert mod.require_auth("admin") is True


def test_session_expiry(auth, monkeypatch):
    mod, st = auth
    monkeypatch.setenv("SESSION_TIMEOUT_MINUTES", "1")
    st.session_state.update({"auth_role": "admin", "auth_login_time": time.time() - 120})
    assert mod.current_role() is None
    assert mod.require_auth("user") is False


def test_login_with_correct_passwords_sets_role(auth):
    mod, st = auth
    st.form_submit_button.return_value = True
    st.text_input.return_value = "userpw"
    mod.require_auth("user")
    assert st.session_state["auth_role"] == "user"
    st.session_state.clear()
    st.text_input.return_value = "adminpw"
    mod.require_auth("admin")
    assert st.session_state["auth_role"] == "admin"


def test_user_password_never_grants_admin(auth):
    mod, st = auth
    st.form_submit_button.return_value = True
    st.text_input.return_value = "userpw"
    assert mod.require_auth("admin") is False
    assert st.session_state.get("auth_role") == "user"   # logged in as user only
    assert mod.require_auth("admin") is False


def test_lockout_after_five_failures(auth):
    mod, st = auth
    st.form_submit_button.return_value = True
    st.text_input.return_value = "wrong"
    for _ in range(5):
        mod.require_auth("user")
    assert mod._is_locked_out() is not None
    st.text_input.return_value = "userpw"          # even the right password is refused while locked
    assert mod.require_auth("user") is False
    assert st.session_state.get("auth_role") is None


def test_no_passwords_configured_fails_closed(auth, monkeypatch):
    mod, _ = auth
    monkeypatch.delenv("USER_PASSWORD_HASH")
    monkeypatch.delenv("ADMIN_PASSWORD_HASH")
    assert mod.require_auth("user") is False


def test_every_page_gates_before_touching_config():
    """Backend enforcement: on every page, the auth gate must be the first thing that EXECUTES --
    no config load / DB access / engine call may run at module level before it."""
    risky_calls = {"load_config_or_stop", "load_config", "get_mysql_engine", "get_mysql_engine_or_none",
                   "get_mysql_storage_engine", "get_repository", "build_sink", "read_candles", "fetch_table"}

    def call_names(node):
        for n in ast.walk(node):
            if isinstance(n, ast.Call):
                f = n.func
                yield f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else "")

    for page in sorted((ROOT / "ui" / "pages").glob("*.py")) + [ROOT / "ui" / "dashboard.py"]:
        src = page.read_text()
        body = ast.parse(src).body
        gate_idx = next((i for i, stmt in enumerate(body)
                         if any(c in ("require_auth", "require_admin_auth") for c in call_names(stmt))), None)
        assert gate_idx is not None, f"{page.name} has no auth gate"
        for stmt in body[:gate_idx]:
            if isinstance(stmt, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.ClassDef)):
                continue  # definitions/imports don't execute data access
            bad = risky_calls & set(call_names(stmt))
            assert not bad, f"{page.name}: {bad} executes before the auth gate"
        if "_Admin_" in page.name or page.name == "1_Admin.py":
            assert 'require_auth("admin")' in src or "require_admin_auth()" in src, f"{page.name} must require ADMIN"
        else:
            assert 'require_auth("user")' in src or page.name == "1_Admin.py", f"{page.name} must require a login"


# ------------------------------------------------------------------ file explorer restrictions
@pytest.fixture
def secret_files():
    env = ROOT / "config" / ".env"
    existed = env.exists()
    if not existed:
        env.write_text("FYERS_ACCESS_TOKEN=SECRET\n")
    link = ROOT / "config" / "escape_link.txt"
    try:
        link.symlink_to("/etc/passwd")
    except (OSError, NotImplementedError, FileExistsError):
        pass
    yield
    if not existed:
        env.unlink()
    if link.is_symlink():
        link.unlink()


def test_file_explorer_blocks_traversal_absolute_and_secrets(secret_files):
    from ui import file_explorer as fe
    assert fe.read_text_preview("../../etc/passwd") is None
    assert fe.read_text_preview("/etc/passwd") is None
    assert fe.read_text_preview("config/escape_link.txt") is None      # symlink escape
    assert fe.read_text_preview("config/.env") is None
    assert fe.read_text_preview("main.py") is None                      # outside approved dirs
    assert fe.list_dir("..") is None
    listed = [e["name"] for e in fe.list_dir("config")]
    assert ".env" not in listed and not any(".env" in n for n in listed)


def test_file_explorer_still_reads_normal_config():
    from ui import file_explorer as fe
    assert "storage" in fe.read_text_preview("config/data_settings.yaml")


# ------------------------------------------------------------------ bulk delete safety
def _candle_db():
    e = create_engine("sqlite://")
    rows = [(1, "1m", "2024-01-01 09:15:00", "CLOSED", "FYERS_LIVE"), (1, "1m", "2024-01-02 09:15:00", "CLOSED", "FYERS_HISTORICAL"),
            (1, "5m", "2024-01-02 09:15:00", "CLOSED", "FYERS_HISTORICAL"), (1, "1m", "2024-01-03 09:15:00", "OPEN", "FYERS_LIVE"),
            (2, "1m", "2024-01-02 09:15:00", "CLOSED", "FYERS_LIVE")]
    with e.begin() as c:
        c.execute(text("CREATE TABLE candles (id INTEGER PRIMARY KEY, instrument_id INT, timeframe TEXT, "
                       "candle_timestamp TEXT, status TEXT, source TEXT)"))
        for r in rows:
            c.execute(text("INSERT INTO candles (instrument_id,timeframe,candle_timestamp,status,source) VALUES (:a,:b,:c,:d,:e)"),
                      dict(zip("abcde", r)))
    return e


@pytest.mark.parametrize("filters", [
    {}, {"timeframe": "1m"}, {"status": "OPEN"}, {"source": "FYERS_LIVE"},
    {"timeframe": "1m", "source": "FYERS_LIVE"}, {"from_date": "2024-01-02", "to_date": "2024-01-02"},
    {"timeframe": "1m", "status": "CLOSED", "source": "FYERS_LIVE", "from_date": "2024-01-01"},
])
def test_bulk_delete_preview_equals_delete_and_is_scoped(filters):
    import ui.admin_data_access as admin
    e = _candle_db()
    preview = admin.count_candles_filtered(e, 1, **filters)
    deleted = admin.delete_candles_filtered(e, 1, **filters)
    assert preview == deleted
    with e.begin() as c:
        assert c.execute(text("SELECT COUNT(*) FROM candles WHERE instrument_id = 2")).scalar() == 1  # other instrument untouched


def test_bulk_delete_requires_an_instrument():
    import ui.admin_data_access as admin
    assert "instrument_id" in inspect.signature(admin.delete_candles_filtered).parameters
    assert inspect.signature(admin.delete_candles_filtered).parameters["instrument_id"].default is inspect._empty


def test_bulk_delete_page_has_preview_confirm_reauth_and_audit():
    src = (ROOT / "ui/pages/24_Admin_Bulk_Delete.py").read_text()
    for needle in ("PREVIEW DELETE", "CONFIRM DELETE", 'typed != "DELETE"', "verify_password(admin_pw", '"BULK_DELETE"'):
        assert needle in src
    assert src.index("admin.count_candles_filtered(") < src.index("admin.delete_candles_filtered(")   # preview happens before delete


def test_no_one_click_bulk_delete_left_in_admin_page():
    assert "delete_candles_filtered" not in (ROOT / "ui/pages/1_Admin.py").read_text()


# ------------------------------------------------------------------ data cleanup (Section 27)
def _stale_open_db():
    e = create_engine("sqlite://")
    rows = [(1, "1m", "2024-01-01 09:15:00", "OPEN"), (1, "1m", "2024-01-01 09:16:00", "CLOSED"),
            (2, "1m", "2024-01-01 09:15:00", "OPEN"), (1, "5m", "2024-01-01 09:15:00", "OPEN"),
            (1, "1m", "2024-01-10 09:15:00", "OPEN")]
    with e.begin() as c:
        c.execute(text("CREATE TABLE candles (id INTEGER PRIMARY KEY, instrument_id INT, timeframe TEXT, candle_timestamp TEXT, status TEXT)"))
        for r in rows:
            c.execute(text("INSERT INTO candles (instrument_id,timeframe,candle_timestamp,status) VALUES (:a,:b,:c,:d)"), dict(zip("abcd", r)))
    return e


def test_cleanup_only_touches_stale_open_never_closed():
    import ui.admin_data_access as admin
    e = _stale_open_db()
    n = admin.count_stale_open_candles(e, older_than_date="2024-01-05")
    d = admin.delete_stale_open_candles(e, older_than_date="2024-01-05")
    assert n == d == 3   # the two 1m/5m stale OPEN rows for instrument 1 + the stale OPEN for instrument 2
    with e.begin() as c:
        remaining = c.execute(text("SELECT status, candle_timestamp FROM candles ORDER BY id")).fetchall()
    assert ("CLOSED", "2024-01-01 09:16:00") in remaining        # CLOSED candle survives
    assert ("OPEN", "2024-01-10 09:15:00") in remaining          # recent OPEN (not yet stale) survives
    assert len(remaining) == 2


def test_cleanup_scoped_to_one_instrument_and_timeframe():
    import ui.admin_data_access as admin
    e = _stale_open_db()
    n = admin.count_stale_open_candles(e, older_than_date="2024-01-05", instrument_id=1, timeframe="1m")
    assert n == 1
    d = admin.delete_stale_open_candles(e, older_than_date="2024-01-05", instrument_id=1, timeframe="1m")
    assert d == 1
    with e.begin() as c:
        assert c.execute(text("SELECT COUNT(*) FROM candles WHERE instrument_id = 2")).scalar() == 1  # untouched
        assert c.execute(text("SELECT COUNT(*) FROM candles WHERE timeframe = '5m'")).scalar() == 1   # untouched


def test_data_operations_page_has_scope_estimate_confirm_result():
    src = (ROOT / "ui/pages/28_Admin_Data_Operations.py").read_text()
    for needle in ("ESTIMATE", "RUN VALIDATION", "count_stale_open_candles", "CONFIRM CLEANUP",
                  'typed != "CLEANUP"', "st.progress", '"SYSTEM_OPERATION"'):
        assert needle in src


# ------------------------------------------------------------------ error display (Section 33)
def test_show_error_gives_admin_detail_and_hides_it_from_users(monkeypatch):
    import ui.error_display as ed
    calls = {"caption": []}
    fake_st = MagicMock()
    fake_st.error = MagicMock()
    fake_st.caption = lambda msg: calls["caption"].append(msg)
    fake_st.columns.return_value = [MagicMock(), MagicMock()]
    monkeypatch.setattr(ed, "st", fake_st)
    exc = ValueError("db connection refused")

    ed.show_error("Historical fetch", "SBIN", exc, role="admin")
    assert any("db connection refused" in c for c in calls["caption"])

    calls["caption"].clear()
    ed.show_error("Historical fetch", "SBIN", exc, role="user")
    assert not any("db connection refused" in c for c in calls["caption"])


# ------------------------------------------------------------------ table wrapping only applies where actually needed
def test_wrapped_dataframe_skips_short_columns_no_excess_height():
    import pandas as pd
    from unittest.mock import patch
    import ui.table_display as td
    short_df = pd.DataFrame({
        "id": [7, 6], "internal_name": ["ITC", "NIFTYBANK"],
        "fyers_symbol": ["NSE:ITC-EQ", "NSE:NIFTYBANK-INDEX"], "exchange": ["NSE", "NSE"],
    })
    with patch.object(td, "st") as mock_st:
        mock_st.column_config.TextColumn = lambda **kw: kw
        td.wrapped_dataframe(short_df, wrap_columns=list(short_df.columns))
        call_kwargs = mock_st.dataframe.call_args.kwargs
    assert call_kwargs["column_config"] == {}
    assert call_kwargs["row_height"] is None  # no artificial tall rows for short content


def test_wrapped_dataframe_still_wraps_genuinely_long_text():
    import pandas as pd
    from unittest.mock import patch
    import ui.table_display as td
    long_df = pd.DataFrame({"message": ["x" * 80, "short"]})
    with patch.object(td, "st") as mock_st:
        mock_st.column_config.TextColumn = lambda **kw: kw
        td.wrapped_dataframe(long_df, wrap_columns=["message"])
        call_kwargs = mock_st.dataframe.call_args.kwargs
    assert "message" in call_kwargs["column_config"]
    assert call_kwargs["row_height"] == 70


# ------------------------------------------------------------------ live restart
def test_restart_does_not_mark_new_session_stopped():
    from ui.data_access import LiveRunManager

    class Fake:
        subscribed_instrument_count = 1

        def __init__(self):
            self._ev = threading.Event()

        def start(self):
            self._ev.wait()

        def stop(self):
            threading.Timer(0.3, self._ev.set).start()

    m = LiveRunManager()
    m.start(Fake)
    old = m.state.thread
    m.stop()
    m.start(Fake)
    old.join(timeout=3)
    assert not old.is_alive()
    assert m.state.running is True
    m.stop()


# ------------------------------------------------------------------ API monitor + logs helpers
def _load_page_functions(page: str, names: set, extra_ns: dict):
    src = (ROOT / "ui/pages" / page).read_text()
    tree = ast.parse(src)
    ns = dict(extra_ns)
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and n.name in names:
            exec(ast.get_source_segment(src, n), ns)
        if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") in ("_SYMBOL_RE", "_LINE_RE", "_JOB_RE"):
            exec(ast.get_source_segment(src, n), ns)
    return ns


def test_api_monitor_discovers_real_repository_methods_read_only():
    from model.repository import MarketDataRepository
    ns = _load_page_functions("10_API_Monitor.py", {"discover_methods"},
                              {"inspect": inspect, "MarketDataRepository": MarketDataRepository})
    found = set(ns["discover_methods"]())
    assert {"get_candles", "get_candles_df", "get_candles_multi", "get_latest_candle", "list_instruments", "has_storage_backend"} <= found
    assert all(n.startswith(("get_", "list_", "has_")) for n in found)        # nothing that writes


def test_api_monitor_serialisation_and_counts():
    from model.processing.models import Candle
    ns = _load_page_functions("10_API_Monitor.py", {"to_jsonable", "count_records", "as_table"},
                              {"dataclasses": dataclasses, "datetime": datetime, "pd": pd})
    c = Candle(internal_name="SBIN", fyers_symbol="NSE:SBIN-EQ", instrument_type="stock", exchange="NSE",
               timestamp=datetime.datetime(2024, 1, 1, 9, 15), timeframe="1m", open=1, high=2, low=1, close=2, volume=10,
               source="FYERS_LIVE", status="CLOSED")
    payload = ns["to_jsonable"]([c])
    assert payload[0]["timestamp"] == "2024-01-01T09:15:00"
    assert ns["count_records"]([c]) == 1 and ns["count_records"](None) == 0
    assert ns["as_table"](payload).shape[0] == 1


def test_api_metrics_are_real_counters():
    from ui import api_metrics
    api_metrics._stats.clear()
    api_metrics.record_call("get_candles", 10.0, True, 5)
    api_metrics.record_call("get_candles", 30.0, False, None)
    s = api_metrics.snapshot()["get_candles"]
    assert s["count"] == 2 and s["errors"] == 1 and s["records"] == 5 and s["total_ms"] == 40.0
    assert api_metrics.total_requests() == 2


def test_log_parser_extracts_symbol_and_job_and_keeps_tracebacks():
    ns = _load_page_functions("9_Logs.py", {"_parse"}, {"re": re, "pd": pd})
    lines = ["2026-09-25 14:52:59,482 | INFO     | market_data.candle | closed: NSE:NIFTY50-INDEX vol=0\n",
             "2026-09-25 14:53:00,050 | ERROR    | market_data.ws | boom\n", "Traceback (most recent call last):\n",
             "2026-09-25 14:53:01,000 | INFO     | market_data | Ingestion job 42 finished\n"]
    df = ns["_parse"](lines)
    assert list(df["symbol"]) == ["NSE:NIFTY50-INDEX", "-", "-"]
    assert list(df["job_id"]) == ["-", "-", "42"]
    assert "Traceback" in df.iloc[1]["message"]


# ------------------------------------------------------------------ audit log
def test_audit_log_is_append_only_and_never_takes_secrets():
    src = (ROOT / "ui/audit_log.py").read_text()
    assert "UPDATE audit_log" not in src and "DELETE FROM audit_log" not in src
    e = create_engine("sqlite://")
    with e.begin() as c:
        c.execute(text("CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_at TEXT DEFAULT CURRENT_TIMESTAMP, "
                       "actor_role TEXT, action TEXT, target TEXT, parameters TEXT, records_affected INT, result TEXT, "
                       "error_message TEXT, ip_address TEXT, session_id TEXT)"))
    from ui.audit_log import record_action, fetch_audit_log
    record_action(e, "admin", "BULK_DELETE", target="candles:X", parameters={"timeframe": "1m"}, records_affected=3,
                  ip_address="10.0.0.5", session_id="sess1")
    df = fetch_audit_log(e)
    assert len(df) == 1 and df.iloc[0]["action"] == "BULK_DELETE" and df.iloc[0]["records_affected"] == 3
    assert df.iloc[0]["ip_address"] == "10.0.0.5" and df.iloc[0]["session_id"] == "sess1"


def test_ensure_audit_table_creates_table_with_ip_and_session_columns():
    """MySQL-style: CREATE TABLE IF NOT EXISTS is native there; here we just
    check the DDL string itself declares both new columns (sqlite's
    information_schema differs from MySQL's, so ensure_audit_table's
    ADD-COLUMN branch is exercised against real MySQL, not asserted here)."""
    from ui.audit_log import AUDIT_TABLE_DDL
    assert "ip_address" in AUDIT_TABLE_DDL and "session_id" in AUDIT_TABLE_DDL


def test_audit_log_failure_never_crashes_caller():
    from ui.audit_log import record_action
    record_action(create_engine("sqlite://"), "admin", "X")     # table doesn't exist -> swallowed, no exception


def _authed_apptest(page_path: str, role: str, monkeypatch):
    from streamlit.testing.v1 import AppTest
    from ui.password_hashing import hash_password
    monkeypatch.setenv("USER_PASSWORD_HASH", hash_password("userpw"))
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", hash_password("adminpw"))
    at = AppTest.from_file(str(ROOT / page_path), default_timeout=30)
    at.session_state["auth_role"] = role
    at.session_state["auth_login_time"] = time.time()
    return at.run()


def test_today_button_sets_date_to_today(monkeypatch):
    """Real click-through: change a date away from today, click Today,
    confirm it snaps back -- and that no session-state warning/crash
    happens (a real Streamlit anti-pattern this implementation avoids)."""
    at = _authed_apptest("ui/pages/7_Data_Quality.py", "admin", monkeypatch)
    assert not at.exception
    at.date_input[0].set_value(datetime.date(2020, 1, 1)).run()
    assert at.date_input[0].value == datetime.date(2020, 1, 1)
    today_buttons = [b for b in at.button if b.label == "Today"]
    assert today_buttons, "no Today button found next to the date picker"
    today_buttons[0].click().run()
    assert not at.exception
    assert at.date_input[0].value == __import__("model.config.market_calendar",fromlist=["today_ist"]).today_ist()


def test_pages_with_quick_links_never_use_fragile_page_link():
    """st.page_link() with a raw file-path string only resolves inside a
    fully-booted multipage app; it throws StreamlitPageNotFoundError when
    a page is exercised on its own (as this test suite, and some
    deployment setups, do). Assert none of our pages depend on it."""
    for page in (ROOT / "ui" / "pages").glob("*.py"):
        assert "page_link(" not in page.read_text(), f"{page.name} uses the fragile st.page_link(path) pattern"
    assert "page_link(" not in (ROOT / "ui" / "error_display.py").read_text()


def test_data_quality_page_survives_mysql_being_down(monkeypatch):
    """Section 33: a broken backend must show a handled error, not crash
    the whole page. This exercises the real code path with a real
    (refused) MySQL connection attempt."""
    at = _authed_apptest("ui/pages/7_Data_Quality.py", "admin", monkeypatch)
    assert not at.exception, [e.value for e in at.exception]
    assert any("Verification service unavailable" in e.value for e in at.error)
    assert any(t.value == "Data Quality & Verification" for t in at.title)   # rest of the page still rendered


def test_live_market_instrument_detail_works_without_a_live_session(monkeypatch):
    """Regression: this page used to st.stop() the ENTIRE page (including
    the search/historical-chart section) whenever no live session was
    running -- meaning you could never look up an instrument's stored
    data unless live happened to be on. Now only the top auto-refresh
    table is gated on live; the search/detail section always works."""
    at = _authed_apptest("ui/pages/2_Live_Market.py", "user", monkeypatch)
    assert not at.exception
    assert any("No live session is running" in i.value for i in at.info)
    instrument_selects = [sb for sb in at.selectbox if sb.label == "Instrument"]
    assert instrument_selects and len(instrument_selects[0].options) > 0, \
        "Instrument Detail section did not render even though it doesn't need a live session"


def test_live_market_search_filters_instrument_list(monkeypatch):
    at = _authed_apptest("ui/pages/2_Live_Market.py", "user", monkeypatch)
    search_boxes = [ti for ti in at.text_input if "Search instrument" in ti.label]
    assert search_boxes
    all_options = [sb for sb in at.selectbox if sb.label == "Instrument"][0].options
    search_boxes[0].set_value("NIFTY").run()
    assert not at.exception
    filtered_options = [sb for sb in at.selectbox if sb.label == "Instrument"][0].options
    assert 0 < len(filtered_options) < len(all_options)
    assert all("nifty" in o.lower() for o in filtered_options)


def test_live_market_table_is_an_auto_refreshing_fragment():
    src = (ROOT / "ui/pages/2_Live_Market.py").read_text()
    assert "@st.fragment(run_every=" in src


def test_logs_page_survives_mysql_down_on_db_tab(monkeypatch):
    at = _authed_apptest("ui/pages/9_Logs.py", "admin", monkeypatch)
    assert not at.exception, [e.value for e in at.exception]
    assert [t.label for t in at.tabs] == ["File Log (everything)", "Database -- WARNING and above"]
    assert any("Connect to MySQL failed" in e.value for e in at.error)


def test_db_log_handler_writes_warning_and_above_only(tmp_path):
    import logging
    from ui.db_log_handler import DatabaseLogHandler
    from sqlalchemy import create_engine, text
    # file-based sqlite: the handler now writes from a worker thread, and an in-memory sqlite DB is per-thread
    e = create_engine(f"sqlite:///{tmp_path / 'logs.db'}")
    with e.begin() as c:
        c.execute(text("CREATE TABLE error_logs (id INTEGER PRIMARY KEY, occurred_at TEXT, level TEXT, module TEXT, message TEXT)"))
    handler = DatabaseLogHandler(lambda: e)
    logger = logging.getLogger("test_db_log_handler")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.propagate = False
    logger.info("this should NOT be written (below WARNING)")
    logger.warning("disk getting full")
    logger.error("candle write failed")
    handler.flush()   # DB writes are asynchronous now
    with e.begin() as c:
        rows = c.execute(text("SELECT level, message FROM error_logs ORDER BY id")).fetchall()
    assert [r[0] for r in rows] == ["WARNING", "ERROR"]
    assert "disk getting full" in rows[0][1]


def test_db_log_handler_never_crashes_the_caller_if_db_is_down():
    import logging
    from ui.db_log_handler import DatabaseLogHandler
    handler = DatabaseLogHandler(lambda: (_ for _ in ()).throw(ConnectionError("no db")))
    logger = logging.getLogger("test_db_log_handler_down")
    logger.addHandler(handler)
    logger.propagate = False
    logger.error("this must not raise even though the DB is unreachable")  # would raise if unhandled


# ------------------------------------------------------------------ ad-hoc symbol search (quotes, symbol master, add-to-instruments)
def test_quotes_parses_documented_fyers_response_shape():
    from model.fyers.quotes import get_quote

    class FakeClient:
        def __init__(self, response):
            self._response = response

        def quotes(self, data=None):
            return self._response

    good = {"s": "ok", "d": [{"n": "NSE:TCS-EQ", "s": "ok", "v": {
        "lp": 3500.5, "ch": 25.5, "chp": 0.73, "open_price": 3480.0, "high_price": 3510.0,
        "low_price": 3475.0, "prev_close_price": 3475.0, "volume": 1234567, "short_name": "TCS-EQ"}}]}
    r = get_quote(FakeClient(good), "NSE:TCS-EQ")
    assert r.ok and r.ltp == 3500.5 and r.change == 25.5 and r.volume == 1234567

    r2 = get_quote(FakeClient(good), "NSE:NOT-IN-RESPONSE-EQ")
    assert not r2.ok

    r3 = get_quote(FakeClient({"s": "error", "message": "invalid symbol"}), "NSE:BAD-EQ")
    assert not r3.ok and "invalid symbol" in r3.error


def test_quotes_derives_change_when_ch_chp_absent():
    from model.fyers.quotes import get_quote

    class FakeClient:
        def quotes(self, data=None):
            return {"s": "ok", "d": [{"n": "NSE:INFY-EQ", "s": "ok",
                    "v": {"ltp": 1500.0, "prev_close_price": 1490.0}}]}

    r = get_quote(FakeClient(), "NSE:INFY-EQ")
    assert r.ok and r.change == 10.0 and round(r.change_pct, 2) == 0.67


def test_quotes_never_raises_on_network_failure():
    from model.fyers.quotes import get_quote

    class ThrowingClient:
        def quotes(self, data=None):
            raise ConnectionError("no network")

    r = get_quote(ThrowingClient(), "NSE:TCS-EQ")
    assert not r.ok and "no network" in r.error


@pytest.fixture
def symbol_master_cache(tmp_path, monkeypatch):
    import model.fyers.symbol_master as sm
    monkeypatch.setattr(sm, "_CACHE_DIR", tmp_path)
    return sm


def test_symbol_master_search_matches_name_and_symbol(symbol_master_cache):
    sm = symbol_master_cache
    sm._cache_path("NSE").write_text(json.dumps({
        "NSE:TCS-EQ": {"symbol_desc": "TATA CONSULTANCY SERV LT", "exchange": "NSE", "instrument_type": "EQ"},
        "NSE:NIFTY50-INDEX": {"symbol_desc": "NIFTY 50", "exchange": "NSE", "instrument_type": "10"},
    }))
    sm._cache_path("BSE").write_text(json.dumps({
        "BSE:TATAMOTORS-A": {"symbol_desc": "TATA MOTORS LTD", "exchange": "BSE", "instrument_type": "EQ"},
    }))

    tata_results = sm.search_symbols("tata")
    assert {r["fyers_symbol"] for r in tata_results} == {"NSE:TCS-EQ", "BSE:TATAMOTORS-A"}

    nifty_results = sm.search_symbols("nifty", exchange="NSE")
    assert len(nifty_results) == 1 and nifty_results[0]["category"] == "index"

    assert sm.search_symbols("t") == []            # below min length
    assert sm.search_symbols("zzz_no_match") == []  # no match


def test_symbol_master_cache_status_reflects_missing_and_present(symbol_master_cache):
    sm = symbol_master_cache
    status = sm.cache_status()
    assert status["NSE"]["cached"] is False and status["BSE"]["cached"] is False
    sm._cache_path("NSE").write_text("{}")
    status2 = sm.cache_status()
    assert status2["NSE"]["cached"] is True and status2["NSE"]["stale"] is False


@pytest.fixture
def instrument_editor_sandbox(tmp_path, monkeypatch):
    import ui.instrument_editor as ed
    shutil_copy_stocks = tmp_path / "stocks.yaml"
    shutil_copy_indices = tmp_path / "indices.yaml"
    shutil_copy_stocks.write_text(ed._STOCKS_PATH.read_text())
    shutil_copy_indices.write_text(ed._INDICES_PATH.read_text())
    monkeypatch.setattr(ed, "_STOCKS_PATH", shutil_copy_stocks)
    monkeypatch.setattr(ed, "_INDICES_PATH", shutil_copy_indices)
    return ed


def test_add_instrument_rejects_duplicate_internal_name_and_symbol(instrument_editor_sandbox):
    ed = instrument_editor_sandbox
    from model.config.instrument_loader import load_instrument_registry
    import model.config.instrument_loader as il
    monkeypatch_paths = (il._STOCKS_PATH, il._INDICES_PATH)
    il._STOCKS_PATH, il._INDICES_PATH = ed._STOCKS_PATH, ed._INDICES_PATH
    try:
        registry = load_instrument_registry()
        assert ed.validate_new_instrument(registry, "RELIANCE", "NSE:SOMETHING-EQ") is not None
        assert ed.validate_new_instrument(registry, "NEWNAME", "NSE:RELIANCE-EQ") is not None
        assert ed.validate_new_instrument(registry, "TCS", "NSE:TCS-EQ") is None
    finally:
        il._STOCKS_PATH, il._INDICES_PATH = monkeypatch_paths


def test_add_instrument_appends_preserves_header_and_reloads(instrument_editor_sandbox):
    ed = instrument_editor_sandbox
    import model.config.instrument_loader as il
    monkeypatch_paths = (il._STOCKS_PATH, il._INDICES_PATH)
    il._STOCKS_PATH, il._INDICES_PATH = ed._STOCKS_PATH, ed._INDICES_PATH
    try:
        before = ed._STOCKS_PATH.read_text()
        ed.append_instrument("stock", "TCS", "NSE:TCS-EQ", "NSE", "EQUITY", active=True)
        after = ed._STOCKS_PATH.read_text()
        assert after.startswith("# instruments/stocks.yaml")  # header comment preserved
        assert before in after                                  # original content untouched
        reloaded = il.load_instrument_registry()
        tcs = reloaded.get("TCS")
        assert tcs.fyers_symbol == "NSE:TCS-EQ" and tcs.category == "stock"
    finally:
        il._STOCKS_PATH, il._INDICES_PATH = monkeypatch_paths


def test_live_market_has_search_nse_bse_mode_and_add_instrument_gate():
    src = (ROOT / "ui/pages/2_Live_Market.py").read_text()
    assert "Search NSE / BSE" in src
    assert 'current_role() != "admin"' in src   # add-to-instruments gated to admin
    assert "get_quote(" in src and "search_symbols(" in src


def test_live_market_search_mode_never_crashes_with_bad_credentials(monkeypatch):
    """Exercises the real get_authenticated_client -> get_quote path with
    throwaway (invalid) FYERS creds -- the point is graceful error
    handling, not a successful quote (that needs a real account)."""
    at = _authed_apptest("ui/pages/2_Live_Market.py", "admin", monkeypatch)
    at.radio[0].set_value("Search NSE / BSE (any symbol)").run()
    symbol_inputs = [ti for ti in at.text_input if ti.label == "FYERS symbol"]
    assert symbol_inputs
    symbol_inputs[0].set_value("NSE:TCS-EQ").run()
    assert not at.exception, [e.value for e in at.exception]


def test_live_market_search_mode_fills_symbol_from_dropdown_match(symbol_master_cache, monkeypatch):
    symbol_master_cache._cache_path("NSE").write_text(json.dumps({
        "NSE:TCS-EQ": {"symbol_desc": "TATA CONSULTANCY SERV LT", "exchange": "NSE", "instrument_type": "EQ"},
    }))
    symbol_master_cache._cache_path("BSE").write_text(json.dumps({}))
    monkeypatch.setattr("model.fyers.symbol_master._CACHE_DIR", symbol_master_cache._CACHE_DIR)
    at = _authed_apptest("ui/pages/2_Live_Market.py", "admin", monkeypatch)
    at.radio[0].set_value("Search NSE / BSE (any symbol)").run()
    search_boxes = [ti for ti in at.text_input if "min 2 characters" in ti.label]
    search_boxes[0].set_value("tcs").run()
    assert not at.exception, [e.value for e in at.exception]
    symbol_inputs = [ti for ti in at.text_input if ti.label == "FYERS symbol"]
    assert symbol_inputs[0].value == "NSE:TCS-EQ"


def test_login_form_submits_on_enter_not_just_button_click():
    """st.form() + st.form_submit_button() is what makes Enter submit --
    a bare st.text_input + st.button requires an explicit click."""
    src = (ROOT / "ui/auth.py").read_text()
    assert "st.form(" in src and "st.form_submit_button(" in src
    assert 'if st.button("Log in")' not in src  # the old non-Enter-submitting pattern is gone


def test_long_values_use_write_not_metric_to_avoid_truncation():
    """st.metric() truncates long values with '...' and never wraps --
    this was cutting off timestamps/source text. Long-text fields must
    use st.write() instead; only short values may still use st.metric()."""
    src = (ROOT / "ui/pages/2_Live_Market.py").read_text()
    assert 'q_cols[0].metric("Name"' not in src   # company names can be long -- fixed to st.markdown
    assert 'info_cols[0].metric("Latest candle"' not in src  # timestamp was getting cut off
    assert 'info_cols[1].metric("Source"' not in src


def test_live_market_candle_chart_includes_real_source_and_status():
    """The 'Source' field used to be a hardcoded placeholder string
    instead of the candle's actual source/status -- must come from data."""
    src = (ROOT / "ui/pages/2_Live_Market.py").read_text()
    assert '"source": c.source, "status": c.status' in src
    assert "FYERS_LIVE/HISTORICAL (see candles.source)" not in src  # the old hardcoded placeholder


def test_search_mode_auto_downloads_symbol_master_on_first_use(symbol_master_cache, monkeypatch):
    """Regression: previously, searching before ever clicking 'Refresh'
    silently returned zero matches with an easy-to-miss hint. Now a
    first-time search triggers the download automatically."""
    monkeypatch.setattr("model.fyers.symbol_master._CACHE_DIR", symbol_master_cache._CACHE_DIR)
    assert not symbol_master_cache._cache_path("NSE").exists()

    download_calls = []

    def fake_download(exchange, force=False):
        download_calls.append(exchange)
        return None  # simulate failure (no real network in tests) -- just prove it's CALLED

    monkeypatch.setattr("model.fyers.symbol_master.download_symbol_master", fake_download)
    at = _authed_apptest("ui/pages/2_Live_Market.py", "admin", monkeypatch)
    at.radio[0].set_value("Search NSE / BSE (any symbol)").run()
    search_boxes = [ti for ti in at.text_input if "min 2 characters" in ti.label]
    search_boxes[0].set_value("tata").run()
    assert not at.exception, [e.value for e in at.exception]
    assert set(download_calls) == {"NSE", "BSE"}
    assert any("Could not download the symbol list" in e.value for e in at.error)


def test_symbol_master_sends_a_browser_like_user_agent():
    src = (ROOT / "model/fyers/symbol_master.py").read_text()
    assert "User-Agent" in src and "Mozilla" in src


def test_api_monitor_has_preview_all_feature():
    src = (ROOT / "ui/pages/10_API_Monitor.py").read_text()
    assert "Preview all methods now" in src and "default_kwargs_for(" in src


def test_api_monitor_preview_all_runs_every_method_without_crashing(monkeypatch):
    """Real click-through: Preview all must handle both successful and
    failing methods gracefully (e.g. has_storage_backend takes no args,
    get_candles needs a real instrument -- different call shapes)."""
    at = _authed_apptest("ui/pages/10_API_Monitor.py", "admin", monkeypatch)
    buttons = [b for b in at.button if b.label == "Preview all methods now"]
    assert buttons
    buttons[0].click().run()
    assert not at.exception, [e.value for e in at.exception]


def test_today_button_spacer_is_not_a_bare_empty_write():
    """Regression: a plain st.write('') spacer didn't match the
    date_input label row's actual height, misaligning the Today button."""
    src = (ROOT / "ui/date_inputs.py").read_text()
    assert 'b_col.write("")' not in src
    assert "height: 1.8rem" in src


# ------------------------------------------------------------------ real Streamlit execution of every page
def _all_pages():
    return sorted((ROOT / "ui" / "pages").glob("*.py")) + [ROOT / "ui" / "dashboard.py"]


def _run_page(page, role, monkeypatch):
    from streamlit.testing.v1 import AppTest
    from ui.password_hashing import hash_password
    monkeypatch.setenv("USER_PASSWORD_HASH", hash_password("userpw"))
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", hash_password("adminpw"))
    at = AppTest.from_file(str(page), default_timeout=30)
    if role:
        at.session_state["auth_role"] = role
        at.session_state["auth_login_time"] = time.time()
    return at.run()


@pytest.mark.parametrize("page", _all_pages(), ids=lambda p: p.name)
def test_unauthenticated_visitor_only_sees_login(page, monkeypatch):
    at = _run_page(page, None, monkeypatch)
    assert not at.exception, f"{page.name} crashed: {[e.value for e in at.exception]}"
    assert any("Login" in t.value for t in at.title), f"{page.name} did not show the login form"
    assert len(at.dataframe) == 0 and len(at.metric) == 0, f"{page.name} leaked data to an unauthenticated visitor"


@pytest.mark.parametrize("page", [p for p in _all_pages() if "_Admin_" in p.name or p.name == "1_Admin.py"], ids=lambda p: p.name)
def test_normal_user_is_blocked_from_every_admin_page(page, monkeypatch):
    at = _run_page(page, "user", monkeypatch)
    assert not at.exception, f"{page.name} crashed: {[e.value for e in at.exception]}"
    assert any("Login" in t.value for t in at.title), f"{page.name}: user role was NOT blocked from an admin page"
    assert len(at.dataframe) == 0 and len(at.metric) == 0
