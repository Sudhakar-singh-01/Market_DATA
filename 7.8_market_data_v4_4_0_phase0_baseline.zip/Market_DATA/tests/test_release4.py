import dataclasses
import datetime as dt
import threading
from decimal import Decimal
from types import SimpleNamespace
import pandas as pd
import pytest
from model.config.market_calendar import IST,expected_starts,calendar_verified,session_window
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe
from model.quality import compare_rows,integrity,parquet_has_duplicate_keys

DAY=dt.date(2026,10,19)
NOW=dt.datetime(2026,10,24,17,tzinfo=IST)
def bars(n=375):
    return [Candle('T','NSE:T-EQ','EQ','NSE',t,'1m',100,102,99,101,10,'FYERS_HISTORICAL') for t in expected_starts(DAY)[:n]]


def test_cash_buckets_start_at_session_and_require_every_minute():
    rows=bars();out=aggregate_1m_to_timeframe(rows,'1h')
    assert [c.timestamp.strftime('%H:%M') for c in out]==['09:15','10:15','11:15','12:15','13:15','14:15','15:15']
    assert out[-1].volume==150
    assert len(aggregate_1m_to_timeframe(rows[:2]+rows[3:],'1d'))==0
    assert len(aggregate_1m_to_timeframe(rows+[rows[0]],'1d'))==0
    assert aggregate_1m_to_timeframe([dataclasses.replace(r,status='OPEN') for r in rows],'1d')==[]


def test_cash_calendar_no_close_tick_and_unknown_special_session():
    assert len(expected_starts(DAY))==375
    assert expected_starts(DAY)[-1].strftime('%H:%M')=='15:29'
    assert not calendar_verified(dt.date(2026,11,8))
    assert session_window(dt.date(2026,11,8)) is None
    assert expected_starts(dt.date(2026,10,20))==[]
    assert not calendar_verified(dt.date(2025,10,1))
    assert not calendar_verified(dt.date(2026,7,1),'FNO')


def test_record_compare_decimal_volume_source_and_timezone():
    row={'candle_timestamp':bars(1)[0].timestamp,'open':100,'high':102,'low':99,'close':101,'volume':10,'source':'FYERS_HISTORICAL','status':'CLOSED'}
    other={**row,'candle_timestamp':row['candle_timestamp'].astimezone(dt.timezone.utc),'close':Decimal('101.0000')}
    assert compare_rows([row],[other])['value_mismatches']==0
    assert compare_rows([row],[{**other,'volume':11}])['value_mismatches']==1
    assert integrity([{**row,'volume':.5}],'1m',DAY,NOW)['invalid']==1
    assert integrity([{**row,'high':float('nan')}],'1m',DAY,NOW)['invalid']==1


def test_unsorted_parquet_keys_detect_duplicates_across_batches(tmp_path):
    path=tmp_path/'chain.parquet'
    data=[{'batch_id':str(4000-i),'contract_id':i} for i in range(4000)]
    pd.DataFrame(data).to_parquet(path)
    assert not parquet_has_duplicate_keys(path,['batch_id','contract_id'])
    pd.DataFrame(data+[data[0]]).to_parquet(path)
    assert parquet_has_duplicate_keys(path,['batch_id','contract_id'])


def test_parquet_duplicate_scratch_database_is_closed(tmp_path, monkeypatch):
    import sqlite3
    real_connect = sqlite3.connect
    opened = []
    def tracked_connect(*args, **kwargs):
        db = real_connect(*args, **kwargs); opened.append(db); return db
    monkeypatch.setattr(sqlite3, 'connect', tracked_connect)
    path = tmp_path/'chain.parquet'
    pd.DataFrame([{'batch_id':'one','contract_id':1}]).to_parquet(path)
    assert not parquet_has_duplicate_keys(path,['batch_id','contract_id'])
    with pytest.raises(sqlite3.ProgrammingError, match='closed'):
        opened[0].execute('SELECT 1')


def test_account_quota_survives_new_limiter_and_fails_closed(tmp_path):
    from model.fyers.rate_limiter import PersistentLimiter,DailyQuotaExhausted
    a=PersistentLimiter(tmp_path/'q.json',10,100,2,0)
    a.acquire();b=PersistentLimiter(tmp_path/'q.json',10,100,2,0);b.acquire()
    with pytest.raises(DailyQuotaExhausted):a.acquire()
    assert b.stats()['used_today']==2
    (tmp_path/'q.json').write_text('not json')
    with pytest.raises(ValueError):b.acquire()


def test_expired_daily_budget_is_shared(tmp_path):
    from model.fyers.rate_limiter import PersistentLimiter,DailyQuotaExhausted
    a=PersistentLimiter(tmp_path/'q.json',10,100,100,0)
    for _ in range(10):a.acquire_expired()
    b=PersistentLimiter(tmp_path/'q.json',10,100,100,0)
    with pytest.raises(DailyQuotaExhausted):b.acquire_expired()


def test_lock_timeout_preserves_owner(tmp_path):
    from model.storage.locking import file_lock
    with file_lock(tmp_path/'owner'):
        with pytest.raises(TimeoutError):
            with file_lock(tmp_path/'owner',timeout=0):pass


def test_scheduler_retries_failed_callbacks_and_catches_late_close():
    from controller.scheduler import DataEngineScheduler
    attempts=[]
    def end():
        attempts.append(1)
        if len(attempts)==1:raise RuntimeError('temporary')
    s=DataEngineScheduler(lambda:None,lambda:None,end,now_fn=lambda:dt.datetime(2026,10,19,19,tzinfo=IST))
    with pytest.raises(RuntimeError):s.tick()
    s.tick();s.tick();assert len(attempts)==2


def test_optional_expired_columns_are_named_and_null_not_zero():
    from model.fno.normalizer import normalize_expired_rows
    row=[int(bars(1)[0].timestamp.timestamp()),100,102,99,101,10,None,1200,.3]
    cols=['timestamp','open','high','low','close','volume','iv','open_interest','delta']
    result=normalize_expired_rows([row],cols,1)
    assert not result.invalid and result.valid[0].iv is None
    assert result.valid[0].oi==1200 and result.valid[0].delta==Decimal('.3')
    assert normalize_expired_rows([row],None,1).invalid


def test_unsupported_expired_capability_never_calls_regular_history():
    from model.fno.history_client import FnoHistoryFetcher
    from model.fno.config import load_fno_settings
    from model.fno.capabilities import UnsupportedCapabilityError
    class Client:
        def history(self,**_):raise AssertionError('No regular-history fallback')
    fetcher=FnoHistoryFetcher(Client(),load_fno_settings().history)
    with pytest.raises(UnsupportedCapabilityError):fetcher.fetch_expired(SimpleNamespace(),DAY,DAY)


def test_fractional_volume_is_rejected_before_integer_coercion():
    from model.fno.normalizer import normalize_history_rows
    from model.processing.normalizer import normalize_historical_candle,NormalizationError
    from model.config.instrument_loader import Instrument
    raw=[int(bars(1)[0].timestamp.timestamp()),100,102,99,101,1.5]
    assert normalize_history_rows([raw],1).invalid
    with pytest.raises(NormalizationError):normalize_historical_candle(raw,Instrument('T','NSE:T-EQ','NSE','EQ',True,'stock'))


def test_historical_batch_partial_does_not_get_success_summary(monkeypatch):
    import controller.historical_controller as h
    from model.config.instrument_loader import Instrument,InstrumentRegistry
    from model.config.data_settings import load_data_settings
    monkeypatch.setattr(h,'process_instrument',lambda *a,**k:h.InstrumentIngestionResult('NSE:T-EQ','partial'))
    recorded=[]
    recorder=SimpleNamespace(record=lambda **kwargs:recorded.append(kwargs))
    h.run_historical_ingestion(None,InstrumentRegistry([Instrument('T','NSE:T-EQ','NSE','EQ',True,'stock')]),load_data_settings(),str(DAY),str(DAY),job_recorder=recorder)
    assert recorded[-1]['status']=='partial'


@pytest.mark.parametrize('value',['bad',float('nan'),True])
def test_malformed_cash_volume_reports_normalization_error(value):
    from model.processing.normalizer import normalize_historical_candle,NormalizationError
    from model.config.instrument_loader import Instrument
    raw=[int(bars(1)[0].timestamp.timestamp()),100,102,99,101,value]
    with pytest.raises(NormalizationError):normalize_historical_candle(raw,Instrument('T','NSE:T-EQ','NSE','EQ',True,'stock'))


def test_scheduler_waits_for_eod_buffer_before_marking_day_done():
    from controller.scheduler import DataEngineScheduler
    at=[dt.datetime(2026,10,19,15,30,tzinfo=IST)];calls=[]
    scheduler=DataEngineScheduler(lambda:None,lambda:None,lambda:calls.append(1),now_fn=lambda:at[0])
    scheduler.tick();assert not calls
    at[0]+=dt.timedelta(minutes=2);scheduler.tick();scheduler.tick();assert calls==[1]
