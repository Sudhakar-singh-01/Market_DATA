import datetime
from controller.gapfill_controller import (SymbolData, plan_fills, expected_last_candle, _missing_in_range, TAIL_GRACE_MINUTES)

D = datetime.datetime


def minutes(day, start="09:15", end="15:29", skip=()):
    h, m = map(int, start.split(":")); eh, em = map(int, end.split(":"))
    cur, out = D.combine(day, datetime.time(h, m)), []
    stop = D.combine(day, datetime.time(eh, em))
    while cur <= stop:
        if cur.time().strftime("%H:%M") not in skip:
            out.append(cur)
        cur += datetime.timedelta(minutes=1)
    return out


FRI = datetime.date(2026, 10, 9)
MON = datetime.date(2026, 10, 12)


def test_expected_last_candle_cases():
    assert expected_last_candle(D(2026, 10, 12, 11, 0)) == D(2026, 10, 12, 10, 58)      # in session
    assert expected_last_candle(D(2026, 10, 12, 16, 0)) == D(2026, 10, 12, 15, 29)      # after close
    assert expected_last_candle(D(2026, 10, 12, 8, 0)) == D(2026, 10, 9, 15, 29)        # before open -> Friday
    assert expected_last_candle(D(2026, 10, 11, 12, 0)) == D(2026, 10, 9, 15, 29)       # Sunday -> Friday


def test_complete_data_has_no_gaps():
    ts = minutes(FRI)
    targets, nb = plan_fills([SymbolData("A", "NSE:A-EQ", ts[-1], ts)], now=D(2026, 10, 9, 16, 0))
    assert targets == [] and nb == []


def test_internal_gap_detected_with_exact_minutes():
    ts = minutes(FRI, skip={"11:00", "11:01", "11:02"})
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", ts[-1], ts)], now=D(2026, 10, 9, 16, 0))
    assert len(targets) == 1
    t = targets[0]
    assert t.reason == "internal" and t.missing_minutes == 3 and t.gap_count == 1
    assert t.from_date == t.to_date == "2026-10-09"


def test_tail_gap_after_downtime():
    ts = minutes(FRI, end="12:00")                       # live died at 12:00 on Friday
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", ts[-1], ts)], now=D(2026, 10, 9, 16, 0))
    assert len(targets) == 1 and targets[0].reason == "tail"
    assert targets[0].missing_minutes == len(minutes(FRI, "12:01", "15:29"))
    assert targets[0].from_date == "2026-10-09"


def test_tail_spanning_weekend_goes_to_monday():
    ts = minutes(FRI)
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", ts[-1], ts)], now=D(2026, 10, 12, 16, 0))
    assert targets[0].from_date == "2026-10-09" and targets[0].to_date == "2026-10-12"
    assert targets[0].missing_minutes == len(minutes(MON))


def test_recent_candle_inside_grace_is_not_a_gap():
    now = D(2026, 10, 12, 11, 0)
    last = now - datetime.timedelta(minutes=2 + TAIL_GRACE_MINUTES - 1)
    day = minutes(MON, end=last.strftime("%H:%M"))
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", day[-1], day)], now=now)
    assert targets == []


def test_never_ingested_symbol_reported_not_filled():
    targets, nb = plan_fills([SymbolData("NEW", "NSE:NEW-EQ", None, [])], now=D(2026, 10, 12, 16, 0))
    assert targets == [] and nb == ["NEW"]


def test_holiday_with_no_candles_is_not_an_internal_gap():
    ts = minutes(FRI)                                     # Monday has zero candles, now is Friday evening
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", ts[-1], ts)], now=D(2026, 10, 9, 16, 0))
    assert targets == []


def test_tail_range_is_capped():
    old = D(2026, 5, 1, 15, 29)
    targets, _ = plan_fills([SymbolData("A", "NSE:A-EQ", old, [])], now=D(2026, 10, 12, 16, 0))
    from datetime import date
    assert (date.fromisoformat(targets[0].to_date) - date.fromisoformat(targets[0].from_date)).days <= 60
