import copy
from decimal import Decimal
from dataclasses import FrozenInstanceError
import httpx
import pytest
from client import MarketDataClient, ProtocolError, DataQualityError, ServiceUnavailableError
from client.consumer import load_verified_batch


def row(minute=15):
    return dict(candle_timestamp=f'2026-10-23T09:{minute}:00+05:30',timeframe='1m',status='CLOSED',
                open='100.123456789',high='102',low='99',close='101',volume=0,oi=None)


def page(rows, cursor=None, coverage='COMPLETE'):
    return dict(data=rows,meta=dict(returned=len(rows),next_cursor=cursor,segment='CASH',
        symbol='NSE:SBIN-EQ',timeframe='1m',session='regular',
        session_filter=dict(mode='regular',excluded_rows=0,scope_rows=2)),
        quality=dict(status='VERIFIED',coverage=coverage))


def run(responses, **kwargs):
    replies=iter(responses)
    def handle(request):
        assert request.method=='GET'
        assert request.url.params['quality']=='verified'
        assert request.url.params['session']=='regular'
        item=next(replies)
        return httpx.Response(item if isinstance(item,int) else 200,json={} if isinstance(item,int) else item)
    with MarketDataClient(password='test',max_retries=0,transport=httpx.MockTransport(handle)) as c:
        return load_verified_batch(c,'CASH','NSE:SBIN-EQ','1m','2026-10-23','2026-10-23',**kwargs)


def test_complete_exact_immutable_batch():
    b=run([page([row()], 'next'),page([row(16)])])
    assert len(b.candles)==2 and b.pages==2
    assert b.candles[0].open==Decimal('100.123456789')
    assert b.candles[0].oi is None and b.candles[0].timestamp.utcoffset().total_seconds()==19800
    with pytest.raises(FrozenInstanceError): b.candles[0].close=Decimal(1)


@pytest.mark.parametrize('field,value',[('open','NaN'),('high','Infinity'),('volume',-1),('oi',-1),
    ('close',True),('open','invalid'),('low','103'),('volume',None)])
def test_bad_numbers_rejected(field,value):
    r=row();r[field]=value
    with pytest.raises(ProtocolError):run([page([r])])


def test_later_page_failure_never_returns_partial_batch():
    with pytest.raises(ServiceUnavailableError):run([page([row()],'next'),503])


def test_duplicates_across_pages_rejected():
    with pytest.raises(ProtocolError):run([page([row()],'next'),page([row()])])


@pytest.mark.parametrize('coverage',['NO_SESSION','SPARSE_UNCONFIRMED'])
def test_empty_or_sparse_not_calculation_ready(coverage):
    with pytest.raises(DataQualityError):run([page([],coverage=coverage)])


def test_memory_bound():
    with pytest.raises(DataQualityError):run([page([row(),row(16)])],max_rows=1)


def test_float_wire_number_uses_decimal_text_value():
    r=row();r["open"]=100.1
    assert run([page([r])]).candles[0].open==Decimal("100.1")
