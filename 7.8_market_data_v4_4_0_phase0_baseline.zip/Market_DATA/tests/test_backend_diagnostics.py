import json
import subprocess
import sys
from types import SimpleNamespace

import pytest
from sqlalchemy import Column, MetaData, String, Table, create_engine

from controller import diagnostics_cli as cli
from model.database_catalog import DatabaseCatalog


def catalog(tmp_path, paths=()):
    engine = create_engine('sqlite://')
    table = Table('fno_storage_manifest', MetaData(), Column('relative_path', String, primary_key=True))
    table.metadata.create_all(engine)
    with engine.begin() as conn:
        if paths:
            conn.execute(table.insert(), [{'relative_path': p} for p in paths])
    return DatabaseCatalog({'FNO': lambda: engine}, {'CASH': tmp_path / 'data', 'FNO': tmp_path / 'data/fno'})


def test_offline_never_connects(tmp_path):
    cat = SimpleNamespace(roots={'CASH': tmp_path / 'data', 'FNO': tmp_path / 'data/fno'})
    report, code = cli.storage_report(cat, offline=True)
    assert code == 0
    assert report['layout']['CASH']['excluded_subtrees'] == ['fno']
    assert report['manifest']['complete'] is False
    assert report['manifest']['status'] == 'SKIPPED_OFFLINE'


def test_all_pages_missing_and_unsafe_are_findings(tmp_path):
    cat = catalog(tmp_path, ['a.parquet', 'b.parquet', 'c.parquet', '../escape'])
    root = tmp_path / 'data/fno'
    root.mkdir(parents=True)
    (root / 'a.parquet').write_bytes(b'no-content-read-needed')
    report, code = cli.storage_report(cat, page_size=1)
    manifest = report['manifest']
    assert code == 2
    assert manifest['checked_count'] == 4
    assert manifest['missing_count'] == 2
    assert manifest['invalid_path_count'] == 1
    assert manifest['complete'] and not manifest['parity_verified']
    with cat.engine('FNO').connect() as conn:
        assert len(list(conn.execute(cat.table('FNO', 'fno_storage_manifest').select()))) == 4


def test_missing_database_is_not_success(tmp_path, monkeypatch, capsys):
    import model.database_catalog
    import controller.workflow_cli
    monkeypatch.setattr(controller.workflow_cli, 'authenticate_admin', lambda: None)
    monkeypatch.setattr(model.database_catalog, 'configured_catalog', lambda: DatabaseCatalog({}, {'FNO': tmp_path/'fno'}))
    assert cli.main(['storage']) == 1
    output = json.loads(capsys.readouterr().out)
    assert output['status'] == 'UNAVAILABLE' and output['complete'] is False


def test_preview_blocked_no_submission(monkeypatch, capsys):
    import controller.market_data_service
    import controller.workflow_cli
    monkeypatch.setattr(controller.workflow_cli, 'authenticate_admin', lambda: None)
    class Service:
        def preview_fetch(self, segment, params, *, role):
            assert params['symbols'] == ['A', 'B']
            assert role == 'admin' and segment == 'CASH'
            return {'plan': {'blocked': [{'reason': 'MISSING_PARQUET'}]}}
    monkeypatch.setattr(controller.market_data_service, 'MarketDataService', Service)
    assert cli.main(['fetch-preview', '--segment', 'CASH', '--from', '2025-01-01', '--to', '2025-01-02', '--symbols', 'A,B']) == 2
    assert 'MISSING_PARQUET' in capsys.readouterr().out


def test_job_uses_read_service(monkeypatch, capsys):
    import controller.workflow_cli
    import model.database_catalog
    import model.market_read_service
    monkeypatch.setattr(controller.workflow_cli, 'authenticate_admin', lambda: None)
    monkeypatch.setattr(model.database_catalog, 'configured_catalog', lambda: None)
    class Reads:
        def __init__(self, catalog): pass
        def get_job_status(self, segment, jid):
            assert (segment, jid) == ('CASH', 313)
            return {'data': [{'id': jid, 'state': 'PARTIAL'}]}
    monkeypatch.setattr(cli, 'job_report', lambda catalog, segment, jid: Reads(catalog).get_job_status(segment, jid))
    assert cli.main(['job', '--segment', 'CASH', '--id', '313']) == 0
    assert 'PARTIAL' in capsys.readouterr().out


def test_help_is_headless():
    result = subprocess.run([sys.executable, '-m', 'controller.diagnostics_cli', '--help'], capture_output=True, text=True)
    assert result.returncode == 0
    assert 'fetch-preview' in result.stdout
    assert not result.stderr


def test_verify_job_reports_bounded_safe_findings(tmp_path):
    from sqlalchemy import Integer, Text
    engine = create_engine('sqlite://')
    metadata = MetaData()
    jobs = Table('ingestion_jobs', metadata, Column('id', Integer, primary_key=True),
                 Column('job_type', String), Column('state', String), Column('result', Text))
    findings = Table('data_quality_results', metadata, Column('id', Integer, primary_key=True),
                     Column('job_id', Integer), Column('check_name', String), Column('scope', String),
                     Column('status', String), Column('details', Text))
    metadata.create_all(engine)
    with engine.begin() as conn:
        conn.execute(jobs.insert(), {'id':313, 'job_type':'VERIFY', 'state':'PARTIAL',
             'result':json.dumps({'checks':{'FAIL':101},'rows_checked':30,'password':'secret'})})
        conn.execute(findings.insert(), [{'id':i,'job_id':313,'check_name':'storage',
            'scope':'NIFTY/2026-10-01/1m','status':'FAIL',
            'details':json.dumps({'sql_only':30,'parquet_rows':0,'reason':'mysql://user:secret@host'})}
            for i in range(1,102)])
    report = cli.job_report(DatabaseCatalog({'CASH':lambda:engine}), 'CASH', 313)
    assert report['diagnostic_result']['checks']['FAIL'] == 101
    assert report['findings']['total_count'] == 101
    assert report['findings']['returned_count'] == 100
    assert report['findings']['truncated']
    assert report['findings']['data'][0]['details']['sql_only'] == 30
    assert 'secret' not in json.dumps(report)


def test_online_missing_root_is_finding(tmp_path):
    report, code = cli.storage_report(catalog(tmp_path))
    assert code == 2
    assert report['manifest']['missing_count'] == 0
    assert 'FNO' in report['missing_roots']


def test_drive_relative_manifest_path_is_invalid(tmp_path):
    report, code = cli.storage_report(catalog(tmp_path, ['C:relative.parquet']))
    assert code == 2
    assert report['manifest']['invalid_path_count'] == 1
