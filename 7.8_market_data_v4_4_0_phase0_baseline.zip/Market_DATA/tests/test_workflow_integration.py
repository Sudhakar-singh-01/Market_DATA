"""Workflow final gate uses the real SQLite/Parquet read verifier."""
import json
import pandas as pd
import pytest
from sqlalchemy import text
from test_read_api import env,seed,DAY
from test_unified_workflow import handle
from controller.fno_jobs import JobOutcome
from controller.unified_workflow import run_workflow
from controller.verification_controller import CashReader


def test_real_strict_cash_readiness_and_later_mutation(env):
    rows=seed(env,n=375)
    path=CashReader(env[1]['CASH'],env[0].catalog.roots['CASH']).path('NSE:SBIN-EQ','1m',DAY)
    path.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame([{**r,'fyers_symbol':'NSE:SBIN-EQ'} for r in rows]).to_parquet(path,index=False)
    ready=run_workflow(handle(),'CASH',lambda h:JobOutcome('SUCCESS'),None,env[0])
    assert ready.state=='SUCCESS' and ready.result['ready'] and ready.result['verified_rows']==375
    with env[1]['CASH'].begin() as c:c.execute(text('UPDATE candles SET close=100 WHERE id=1'))
    blocked=run_workflow(handle(),'CASH',lambda h:JobOutcome('SUCCESS'),None,env[0])
    assert blocked.state=='PARTIAL' and not blocked.result['ready']


def test_public_job_status_only_exposes_safe_terminal_readiness(env):
    engine=env[1]['CASH']
    payload={'version':1,'stage':'READY','ready':True,'stage_progress':{'password':'private'},'stages':None}
    with engine.begin() as c:
        c.execute(text('ALTER TABLE ingestion_jobs ADD COLUMN result TEXT'))
        c.execute(text("UPDATE ingestion_jobs SET job_type='WORKFLOW',state='SUCCESS',result=:r WHERE id=4"),{'r':json.dumps(payload)})
    status=env[0].get_job_status('CASH',4)['data'][0]
    assert status['workflow']['ready'] is True and 'private' not in str(status) and 'result' not in status
    with engine.begin() as c:c.execute(text("UPDATE ingestion_jobs SET state='INTERRUPTED' WHERE id=4"))
    assert env[0].get_job_status('CASH',4)['data'][0]['workflow']['ready'] is False


def test_workflow_registered_without_removing_existing_fno_handlers():
    from controller.fno_cli import worker_handlers
    from types import SimpleNamespace
    handlers=worker_handlers(SimpleNamespace())
    assert {'WORKFLOW','HISTORICAL_HARVEST','AGGREGATION','VERIFY','LIVE','CHAIN_SNAPSHOT'}<=set(handlers)
