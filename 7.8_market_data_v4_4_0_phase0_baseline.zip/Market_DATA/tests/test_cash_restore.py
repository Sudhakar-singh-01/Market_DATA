import datetime as dt
import copy
import json
import pandas as pd
import pytest
from model.config.market_calendar import IST
from model.storage_inventory import inventory
from model.cash_inventory_preview import preview
from model.cash_restore import make_plan, apply_plan

NOW=dt.datetime(2026,10,27,tzinfo=IST)
REL='raw/1m/NSE_SBIN-EQ/2026-10-23.parquet'


@pytest.fixture
def setup(tmp_path,monkeypatch):
    import model.cash_inventory_preview as quality
    rows=[dict(internal_name='SBIN',exchange='NSE',instrument_type='EQUITY',
        fyers_symbol='NSE:SBIN-EQ',timeframe='1m',candle_timestamp=dt.datetime(2026,10,23,9,15,tzinfo=IST),
        open=100.,high=102.,low=99.,close=101.,volume=10,source='FYERS',status='CLOSED')]
    monkeypatch.setattr(quality,'calendar_verified',lambda d:True)
    monkeypatch.setattr(quality,'expected_starts',lambda d:[rows[0]['candle_timestamp']])
    old,cash,fno=[tmp_path/n for n in ('old','cash','fno')]
    for p in (old,cash,fno):p.mkdir()
    source=old/REL;source.parent.mkdir(parents=True);pd.DataFrame(rows).to_parquet(source,index=False)
    class Reader:
        def instrument(self,symbol):return dict(id=1,internal_name='SBIN',exchange='NSE',instrument_type='EQUITY')
        def sql_day(self,*args):return copy.deepcopy(rows)
    reader=Reader()
    report=preview(inventory([old],cash,fno),reader,now=NOW)
    journal=tmp_path/'journals'
    return report,source,cash,reader,journal


def test_plan_readonly_restore_and_resume(setup):
    report,source,root,reader,journal=setup
    original=source.read_bytes()
    plan=make_plan(report,root,reader,now=NOW)
    assert plan['ready'] and plan['summary']['planned']==1
    assert not list(root.iterdir()) and not journal.exists()
    r=apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert r['restored']==1 and (root/REL).read_bytes()==original
    assert source.read_bytes()==original
    r=apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert r['already_identical']==1 and r['restored']==0
    events=[json.loads(line)['event'] for line in open(r['journal'])]
    assert events.count('RESTORED_VERIFIED')==1


def test_conflicting_target_never_overwritten(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    p=root/REL;p.parent.mkdir(parents=True);p.write_bytes(b'keep me')
    with pytest.raises(ValueError,match='Destination conflict'):
        apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert p.read_bytes()==b'keep me' and not journal.exists()


def test_stale_source_blocks_before_mutation(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW);source.write_bytes(b'changed')
    with pytest.raises(ValueError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert not list(root.iterdir())


def test_changed_sql_blocks(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    reader.sql_day=lambda *args:[]
    with pytest.raises(ValueError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert not list(root.iterdir())


def test_tampered_relative_path_blocks(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW);plan['items'][0]['relative_path']='../escape.parquet'
    with pytest.raises(ValueError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert not list(root.iterdir())


def test_writers_ack_required(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    with pytest.raises(ValueError):apply_plan(plan,root,reader,journal,now=NOW)
    assert not journal.exists()


def test_publish_failure_keeps_source_and_no_partial_target(setup,monkeypatch):
    import model.cash_restore as m
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW);original=source.read_bytes()
    def fail(*args):raise OSError('hardlinks unsupported')
    monkeypatch.setattr(m.os,'link',fail)
    with pytest.raises(OSError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert not (root/REL).exists() and source.read_bytes()==original
    assert not list(root.rglob('*.tmp'))
    events=[json.loads(line)['event'] for line in next(journal.glob('*.jsonl')).read_text().splitlines()]
    assert events[-1]=='STOPPED_REVIEW'


def test_metadata_mismatch_blocks_plan(setup):
    report,source,root,reader,journal=setup
    reader.instrument=lambda *args:dict(id=1,internal_name='WRONG',exchange='NSE',instrument_type='EQUITY')
    plan=make_plan(report,root,reader,now=NOW)
    assert not plan['ready'] and plan['summary']['blocked']==1
    assert not list(root.iterdir())


def test_publication_race_no_clobber(setup,monkeypatch):
    import model.cash_restore as m
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    real=m.os.link
    def race(src,dst):
        dst.write_bytes(b'other writer')
        real(src,dst)
    monkeypatch.setattr(m.os,'link',race)
    with pytest.raises(FileExistsError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert (root/REL).read_bytes()==b'other writer'


def test_cli_requires_apply_ack():
    from controller.cash_restore_cli import main
    with pytest.raises(SystemExit):main(['apply','--plan','irrelevant.json'])


def test_interrupted_after_publish_resumes_without_rewrite(setup,monkeypatch):
    import model.cash_restore as m
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    original=m.append_event
    def fail(path,event):
        if event['event']=='RESTORED_VERIFIED':raise OSError('journal write interrupted')
        original(path,event)
    monkeypatch.setattr(m,'append_event',fail)
    with pytest.raises(OSError):apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    p=root/REL;before=(p.read_bytes(),p.stat().st_mtime_ns)
    monkeypatch.setattr(m,'append_event',original)
    result=apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert result['already_identical']==1
    assert (p.read_bytes(),p.stat().st_mtime_ns)==before


def test_linked_destination_parent_blocked(setup,monkeypatch):
    import model.cash_restore as m
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    monkeypatch.setattr(m,'linked',lambda p:p==root/'raw')
    with pytest.raises(ValueError,match='Linked path'):
        apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert not list(root.iterdir())


def test_unknown_calendar_is_warning_not_restore_block(setup,monkeypatch):
    import model.cash_inventory_preview as quality
    report,source,root,reader,journal=setup
    monkeypatch.setattr(quality,'calendar_verified',lambda day:False)
    report['partitions'][0]['status']='REVIEW_REQUIRED'
    report['partitions'][0]['variants'][0]['quality']['review_reasons']=['calendar_not_verified']
    plan=make_plan(report,root,reader,now=NOW)
    assert plan['ready']
    assert plan['items'][0]['warnings']==['calendar_not_verified']
    result=apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    assert result['restored']==1


def test_fresh_plan_skips_previously_restored_matching_files(setup):
    report,source,root,reader,journal=setup
    plan=make_plan(report,root,reader,now=NOW)
    apply_plan(plan,root,reader,journal,writers_stopped=True,now=NOW)
    again=make_plan(report,root,reader,now=NOW)
    assert again['summary']['planned']==0 and again['summary']['blocked']==0
