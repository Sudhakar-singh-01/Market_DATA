import threading
import time

from ui.job_manager import JobManager


def wait_for(cond, timeout=5):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


def test_job_runs_in_background_and_reports_progress():
    mgr, gate = JobManager(), threading.Event()

    def work(job):
        job.total = 3
        for i in range(3):
            job.current = f"s{i}"
            if i == 1:
                gate.wait(2)
            job.done += 1

    job = mgr.submit("historical", "t", work)
    assert wait_for(lambda: mgr.get(job.id)["status"] == "running")
    assert wait_for(lambda: mgr.get(job.id)["done"] == 1)
    gate.set()
    assert wait_for(lambda: mgr.get(job.id)["status"] == "done")
    assert mgr.get(job.id)["done"] == 3


def test_jobs_run_one_at_a_time_in_order():
    mgr, order, gate = JobManager(), [], threading.Event()
    j1 = mgr.submit("historical", "a", lambda j: (gate.wait(2), order.append("a")))
    j2 = mgr.submit("aggregation", "b", lambda j: order.append("b"))
    time.sleep(0.2)
    assert mgr.get(j2.id)["status"] == "queued"
    gate.set()
    assert wait_for(lambda: mgr.get(j2.id)["status"] == "done")
    assert order == ["a", "b"]


def test_failure_is_captured_and_worker_survives():
    mgr = JobManager()
    bad = mgr.submit("historical", "bad", lambda j: (_ for _ in ()).throw(RuntimeError("boom")))
    assert wait_for(lambda: mgr.get(bad.id)["status"] == "failed")
    assert "boom" in mgr.get(bad.id)["error"]
    ok = mgr.submit("historical", "ok", lambda j: None)
    assert wait_for(lambda: mgr.get(ok.id)["status"] == "done")


def test_cancel_stops_between_items_and_queued_job_never_starts():
    mgr, gate = JobManager(), threading.Event()
    ran = []

    def work(job):
        job.total = 100
        for _ in range(100):
            if job.cancel_requested:
                return
            ran.append(1)
            job.done += 1
            gate.wait(0.05)

    j1 = mgr.submit("historical", "long", work)
    j2 = mgr.submit("historical", "queued", lambda j: ran.append("never"))
    assert wait_for(lambda: mgr.get(j1.id)["done"] >= 1)
    assert mgr.cancel(j1.id) and mgr.cancel(j2.id)
    assert wait_for(lambda: mgr.get(j1.id)["status"] == "cancelled")
    assert wait_for(lambda: mgr.get(j2.id)["status"] == "cancelled")
    assert "never" not in ran


def test_partial_final_status_and_active_filter():
    mgr = JobManager()
    def work(job):
        job.final_status = "partial"
    j = mgr.submit("gapfill", "g", work)
    assert wait_for(lambda: mgr.get(j.id)["status"] == "partial")
    assert mgr.active("gapfill") == []
