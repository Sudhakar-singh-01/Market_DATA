"""Historical scheduling is independent from the verified live exchange session."""
import datetime as dt
import threading
from types import SimpleNamespace as NS

import pytest

from model.config import market_calendar as mc
from controller import historical_controller as history
from controller import fno_live
from controller.live_controller import LiveIngestionController


def at(day, h=10, m=0):
    return dt.datetime.fromisoformat(day).replace(hour=h, minute=m, tzinfo=mc.IST)


@pytest.fixture(autouse=True)
def calendar(tmp_path):
    p = tmp_path / 'calendar.yaml'
    p.write_text('''verified_years: {CASH: [2026], FNO: [2026]}
holidays: [2026-10-20]
special_sessions:
  "2026-10-25": {verified: true, open: "18:00", close: "19:00"}
  "2026-11-08": {verified: false, open: "18:00", close: "19:00"}
''')
    mc.reload_holidays(p)
    yield
    mc.reload_holidays()


@pytest.mark.parametrize('day,h', [('2026-10-24',10), ('2026-10-25',10), ('2026-10-20',10), ('2026-10-19',22)])
def test_closed_live_can_open_idle_cash_and_fno_socket(day, h):
    now = at(day,h)
    calls=[]
    cash = LiveIngestionController.__new__(LiveIngestionController)
    cash._clock=lambda:now;cash.session_reason=None
    cash._stop_event=threading.Event();cash._stop_lock=threading.Lock()
    cash._instruments_by_symbol={}
    cash._timeframe_aggregator=NS(flush_all=lambda:[])
    cash._ws_client=NS(connect_and_run=lambda:calls.append('cash'),stop=lambda:None)
    thread=threading.Thread(target=cash.start);thread.start();thread.join(2)
    assert not thread.is_alive() and calls==['cash']
    ing=NS(clock=lambda:now,settings=NS(session=None,live=NS(flush_seconds=1)),symbols=[],
           on_message=lambda m:None,on_reconnect=lambda:None,flush=lambda:None,
           report_freshness=lambda:None,shutdown=lambda:None)
    socket=NS(connect_and_run=lambda:calls.append('fno'),stop=lambda:None)
    fno_live.run_live(ing,lambda *a:socket,threading.Event())
    assert calls==['cash','fno']


@pytest.mark.parametrize('segment', ['CASH','FNO'])
def test_verified_special_session_and_missing_evidence_are_distinct(segment):
    assert mc.live_session_status(at('2026-10-25',18),segment)['open']
    assert mc.live_session_status(at('2026-10-25',19),segment)['reason']=='market_closed'
    assert mc.live_session_status(at('2026-11-08',18),segment)['reason']=='calendar_not_verified'
    assert mc.live_session_status(at('2027-01-04'),segment)['reason']=='calendar_not_verified'


def test_cash_and_fno_keep_distinct_exclusive_close():
    now=at('2026-10-19',15,35)
    assert not mc.live_session_status(now,'CASH')['open']
    assert mc.live_session_status(now,'FNO')['open']
    assert not mc.live_session_status(at('2026-10-19',15,40),'FNO')['open']


@pytest.mark.parametrize('invoked', [at('2026-10-24'),at('2026-10-25'),at('2026-10-20'),at('2026-10-19',22)])
def test_historical_past_target_is_fetched_even_when_invoked_closed(monkeypatch,invoked):
    calls=[];stored=[];checkpoints=[]
    class FrozenDateTime(dt.datetime):
        @classmethod
        def now(cls,tz=None):
            return invoked if tz else invoked.replace(tzinfo=None)
    monkeypatch.setattr(dt,'datetime',FrozenDateTime)
    rows=[NS(timestamp=t,status='CLOSED') for t in mc.expected_starts(dt.date(2026,10,16))]
    monkeypatch.setattr(history,'fetch_historical_1m',lambda *a,**kw: calls.append(a[2:4]) or rows)
    monkeypatch.setattr(history,'normalize_historical_candle',lambda row,*a,**kw:row)
    sink=NS(write_batch=lambda rows:stored.extend(rows),last_conflicts=0)
    checkpoint=NS(save_checkpoint=lambda *a:checkpoints.append(a))
    result=history.process_instrument(object(),NS(fyers_symbol='NSE:TEST-EQ'),'2026-10-16','2026-10-16',
        NS(retry=None,validation_enabled=False),None,sink,checkpoint)
    assert result.status=='success'
    assert calls==[('2026-10-16','2026-10-16')]
    assert len(stored)==375 and checkpoints==[('NSE:TEST-EQ','1m','2026-10-16')]


def test_fno_session_close_does_not_stop_idle_connection():
    now=[at('2026-10-19',15,39)];stop=threading.Event();stopped=threading.Event()
    calls=[]
    ing=NS(clock=lambda:now[0],settings=NS(session=None,live=NS(flush_seconds=.01)),symbols=[],
        on_message=lambda m:None,on_reconnect=lambda:None,flush=lambda:calls.append('flush'),
        report_freshness=lambda:None,shutdown=lambda:calls.append('shutdown'))
    class Socket:
        def connect_and_run(self):
            now[0]=at('2026-10-19',15,40)
            assert not stopped.wait(.05)
            stop.set()
            assert stopped.wait(2)
        def stop(self):stopped.set()
    fno_live.run_live(ing,lambda *a:Socket(),stop)
    assert calls[-1]=='shutdown'


def test_cash_stop_flushes_real_completed_bucket_once_and_preserves_partial_open():
    now=at('2026-10-19',10,1)
    cash=LiveIngestionController.__new__(LiveIngestionController)
    cash._clock=lambda:now;cash._stop_event=threading.Event();cash._stop_lock=threading.Lock()
    cash._ws_client=NS(stop=lambda:None)
    done=NS(period_start=now-dt.timedelta(minutes=1),fyers_symbol='DONE')
    partial=NS(period_start=now,fyers_symbol='PARTIAL')
    buckets={'DONE':done,'PARTIAL':partial};closed=[];written=[]
    cash._instruments_by_symbol={'DONE':object(),'PARTIAL':object()}
    cash._candle_builder=NS(current_bucket=buckets.get,flush=lambda symbol:closed.append(symbol))
    cash._timeframe_aggregator=NS(flush_all=lambda:[])
    cash._sink=NS(write_one=written.append)
    from unittest.mock import patch
    with patch('controller.live_controller.normalize_live_candle',lambda b,i,status:(b.fyers_symbol,status)):
        cash.stop();cash.stop()
    assert closed==['DONE']
    assert written==[('PARTIAL','OPEN')]


def test_scheduler_uses_special_session_close():
    from controller.scheduler import should_be_live_now, is_just_after_close
    assert should_be_live_now(at('2026-10-25',18,30))
    assert not should_be_live_now(at('2026-10-25',19))
    assert is_just_after_close(at('2026-10-25',19,1))


def test_verified_weekend_special_session_opens_fno_transport():
    calls=[]
    ing=NS(clock=lambda:at('2026-10-25',18,30),settings=NS(session=None,live=NS(flush_seconds=1)),symbols=['REAL'],
           on_message=lambda message:None,on_reconnect=lambda:None,
           maybe_end_of_session=lambda:None,flush=lambda:None,
           report_freshness=lambda:None,shutdown=lambda:calls.append('shutdown'))
    class Socket:
        def connect_and_run(self):calls.append('connected')
        def stop(self):pass
    fno_live.run_live(ing,lambda *a:Socket(),threading.Event())
    assert calls==['connected','shutdown']


def test_real_fno_ticks_are_not_rejected_by_configured_session_hours():
    from model.fno.config import load_fno_settings
    from dataclasses import replace
    settings=load_fno_settings()
    custom=replace(settings.session,open=dt.time(10),last_minute=dt.time(16,9),close=dt.time(16,10))
    settings=replace(settings,session=custom)
    contract=NS(fyers_symbol='CUSTOM',contract_id=1)
    ing=fno_live.FnoLiveIngestor(None,None,settings,[contract],clock=lambda:at('2026-10-19',16))
    def tick(when):
        ing.on_message({'symbol':'CUSTOM','ltp':100,'vol_traded_today':10,'exch_feed_time':int(when.timestamp())})
    tick(at('2026-10-19',9,45))
    assert ing.builder.current_bucket('CUSTOM') is not None
    tick(at('2026-10-19',16,9))
    assert ing.builder.current_bucket('CUSTOM').period_start==at('2026-10-19',16,9)
    tick(at('2026-10-19',16,10))
    assert ing.stats.ticks_outside_session==0
    assert mc.live_session_status(at('2026-10-19',16),'FNO',session=custom)['open']
    # A verified special exchange session overrides configured normal hours.
    assert mc.live_session_status(at('2026-10-25',18,30),'FNO',session=custom)['open']
