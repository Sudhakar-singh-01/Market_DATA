from pathlib import Path
import pytest
from model.storage_scope import validate_storage_roots, cash_data_root


def test_default_nested_layout_and_separate_roots(tmp_path):
    roots={'CASH':tmp_path/'data','FNO':tmp_path/'data/fno'}
    assert validate_storage_roots(roots)['CASH']['excluded_subtrees']==['fno']
    roots['FNO']=tmp_path/'other'
    assert validate_storage_roots(roots)['CASH']['excluded_subtrees']==[]


@pytest.mark.parametrize('peer',['.','raw','raw/1m/fno','processed','processed/5m','..'])
def test_unsafe_ownership_still_rejected(tmp_path,peer):
    cash=tmp_path/'data'
    with pytest.raises(ValueError,match='overlap'):
        validate_storage_roots({'CASH':cash,'FNO':cash/peer})


def _make_test_symlink(alias, target):
    try:
        alias.symlink_to(target,target_is_directory=True)
    except OSError as exc:
        if getattr(exc,'winerror',None)==1314:
            pytest.skip('Real symlink fixture requires Windows symlink privilege; simulated link guards run separately')
        raise


def test_symlink_ancestor_cannot_hide_overlap(tmp_path):
    root=tmp_path/'actual';root.mkdir()
    alias=tmp_path/'alias';_make_test_symlink(alias,root)
    with pytest.raises(ValueError,match='Symlink'):
        validate_storage_roots({'CASH':alias/'data'})


@pytest.mark.parametrize('link_kind',['is_symlink','is_junction'])
def test_link_ancestor_guard_without_os_privileges(tmp_path,monkeypatch,link_kind):
    alias=tmp_path/'alias'
    original=getattr(Path,link_kind,lambda self:False)
    monkeypatch.setattr(Path,link_kind,lambda self:self==alias or original(self),raising=False)
    with pytest.raises(ValueError,match='Symlink or junction'):
        validate_storage_roots({'CASH':alias/'data'})


def test_windows_privilege_failure_skips_only_fixture(tmp_path,monkeypatch):
    def denied(*args,**kwargs):
        error=OSError('Privilege not held');error.winerror=1314
        raise error
    monkeypatch.setattr(Path,'symlink_to',denied)
    with pytest.raises(pytest.skip.Exception,match='Windows symlink privilege'):
        _make_test_symlink(tmp_path/'alias',tmp_path/'actual')


def test_configured_cash_root_shared_by_catalog_readers_writers(tmp_path,monkeypatch):
    from controller.verification_controller import CashReader
    from model.storage.parquet import ParquetCandleSink
    from model.fno.config import resolve_parquet_root
    from model.exceptions import ConfigurationError
    stable=tmp_path/'stable-data'
    monkeypatch.setenv('CASH_DATA_ROOT',str(stable))
    monkeypatch.chdir(tmp_path)
    assert cash_data_root()==stable
    assert CashReader(None).root==stable
    assert Path(ParquetCandleSink()._data_root)==stable
    with pytest.raises(ConfigurationError,match='overlap'):
        resolve_parquet_root(str(stable/'raw/fno'))
    assert resolve_parquet_root(str(stable/'fno'))==stable/'fno'


def test_default_cash_root_independent_of_working_directory(tmp_path,monkeypatch):
    monkeypatch.delenv('CASH_DATA_ROOT',raising=False)
    monkeypatch.delenv('TIOS_HOME',raising=False)
    monkeypatch.chdir(tmp_path)
    from model.storage_scope import PROJECT_ROOT
    assert cash_data_root()==PROJECT_ROOT/'data'


def test_runtime_cash_root_independent_of_working_directory(tmp_path,monkeypatch):
    home=tmp_path/'runtime';home.mkdir()
    (home/'config').mkdir();(home/'config'/'.env').write_text('')
    monkeypatch.delenv('CASH_DATA_ROOT',raising=False)
    monkeypatch.setenv('TIOS_HOME',str(home))
    other=tmp_path/'new-build';other.mkdir();monkeypatch.chdir(other)
    assert cash_data_root()==home/'data'/'cash'
