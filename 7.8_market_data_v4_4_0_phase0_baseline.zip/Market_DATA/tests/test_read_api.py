"""Real SQLite/Parquet read-path tests; no provider account or production DB."""
import datetime as dt
from decimal import Decimal

import pandas as pd
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import (create_engine, MetaData, Table, Column, Integer, String,
                        DateTime, Date, Numeric, Boolean, select, event)
from sqlalchemy.pool import StaticPool

from api.app import create_app
from model.config.market_calendar import IST
from model.database_catalog import DatabaseCatalog
from model.market_read_service import MarketReadService
from model.read_contracts import ReadRequestError, DataNotVerifiedError

DAY = dt.date(2026, 10, 16)


@pytest.fixture
def env(tmp_path):
    engines, tables = {}, {}
    for segment in ('CASH', 'FNO'):
        engine = create_engine('sqlite://', connect_args={'check_same_thread': False}, poolclass=StaticPool)
        engines[segment] = engine
        md = MetaData()
        prefix = '' if segment == 'CASH' else 'fno_'
        master = Table(prefix+'instruments', md, Column('id', Integer, primary_key=True),
            Column('fyers_symbol', String, unique=True), Column('internal_name', String),
            Column('exchange', String), Column('instrument_type', String), Column('category', String),
            Column('is_active', Boolean), Column('status', String), Column('underlying', String), Column('expiry', Date))
        candles = Table(prefix+'candles', md, Column('id', Integer, primary_key=True),
            Column('instrument_id' if segment == 'CASH' else 'contract_id', Integer),
            Column('timeframe', String), Column('candle_timestamp', DateTime),
            *(Column(k, Numeric(14, 4)) for k in ('open', 'high', 'low', 'close')),
            Column('volume', Integer), Column('source', String), Column('status', String),
            *(Column(k, Numeric(18, 8)) for k in ('oi','iv','delta','gamma','theta','vega')))
        quality = Table(prefix+'data_quality_results', md, Column('id', Integer, primary_key=True),
            Column('scope', String), Column('status', String), Column('details', String), Column('job_id', Integer))
        jobs = Table(prefix+'ingestion_jobs', md, Column('id', Integer, primary_key=True),
            Column('job_type', String), Column('state', String), Column('error', String))
        if segment == 'FNO':
            Table('fno_storage_manifest', md, Column('id', Integer, primary_key=True),
                Column('relative_path', String), Column('status', String), Column('checksum', String), Column('row_count', Integer))
            Table('fno_option_chain_snapshots', md, Column('id', Integer, primary_key=True),
                Column('batch_id', String), Column('underlying', String), Column('captured_at', DateTime),
                Column('contract_id', Integer), Column('gamma', Numeric(18, 8)), Column('theta', Numeric(18, 8)),
                Column('vega', Numeric(18, 8)))
        Table(prefix+'extra_tool_table', md, Column('key', String, primary_key=True), Column('value', String))
        md.create_all(engine)
        with engine.begin() as conn:
            conn.execute(master.insert(), [{'id': 1, 'fyers_symbol': 'NSE:SBIN-EQ' if segment == 'CASH' else 'NSE:TEST-OPT',
                'internal_name': 'SBIN', 'exchange':'NSE', 'instrument_type':'EQUITY',
                'category':'stock' if segment == 'CASH' else 'OPTIONS', 'is_active':True,
                'status':'ACTIVE', 'underlying':'NIFTY', 'expiry':dt.date(2026,10,27)}])
            conn.execute(quality.insert(), {'id':1, 'scope':'test', 'status':'PASS', 'details':'{}', 'job_id':4})
            conn.execute(jobs.insert(), {'id':4, 'job_type':'VERIFY', 'state':'SUCCESS', 'error':'secret-do-not-expose'})
        tables[segment] = md.tables
    catalog = DatabaseCatalog({k:(lambda e=e:e) for k,e in engines.items()},
                              {'CASH':tmp_path/'cash', 'FNO':tmp_path/'fno'})
    service = MarketReadService(catalog, clock=lambda:dt.datetime(2026,10,25,12,tzinfo=IST))
    return service, engines, tables


def seed(env, segment='CASH', n=3, minute=0):
    service, engines, tables = env
    table = tables[segment]['candles' if segment=='CASH' else 'fno_candles']
    rows = [{'instrument_id' if segment=='CASH' else 'contract_id':1, 'timeframe':'1m',
             'candle_timestamp':dt.datetime(2026,10,16,9,15)+dt.timedelta(minutes=i+minute),
             'open':100, 'high':102, 'low':99, 'close':101, 'volume':10,
             'source':'FYERS_HISTORICAL', 'status':'CLOSED'} for i in range(n)]
    with engines[segment].begin() as conn:
        conn.execute(table.insert(), rows)
    return rows


def fno_parquet(env, rows):
    from model.fno.parquet_store import FnoParquetStore, COLUMNS
    service, engines, tables = env
    store = FnoParquetStore(service.catalog.roots['FNO'], None)
    rel = store.relative_candle_path('1m','NIFTY',dt.date(2026,10,27),DAY)
    path = store.abs_path(rel)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).reindex(columns=COLUMNS)
    frame.to_parquet(path, index=False)
    table = tables['FNO']['fno_storage_manifest']
    with engines['FNO'].begin() as conn:
        conn.execute(table.delete())
        conn.execute(table.insert(), {'relative_path':rel, 'status':'VERIFIED','checksum':store.sha256(path),'row_count':len(frame)})
    return path


@pytest.mark.parametrize('segment,symbol', [('CASH','NSE:SBIN-EQ'),('FNO','NSE:TEST-OPT')])
def test_keyset_reads_all_rows_without_duplicates_and_isolates_segments(env, segment, symbol):
    seed(env, segment, 5)
    service = env[0]
    page = service.get_candles(segment,symbol,'1m',str(DAY),str(DAY),limit=2)
    assert len(page['data']) == 2 and page['meta']['next_cursor']
    assert page['quality']['status'] == 'NOT_VERIFIED'
    assert page['data'][0]['candle_timestamp'].endswith('+05:30')
    rows = list(service.iter_candles(segment,symbol,'1m',str(DAY),str(DAY),limit=2))
    assert len(rows) == len({r['candle_timestamp'] for r in rows}) == 5
    assert rows[0]['open'] == '100.0000'
    with pytest.raises(ReadRequestError):
        service.get_candles(segment,symbol,'5m',str(DAY),str(DAY),cursor=page['meta']['next_cursor'])


@pytest.mark.parametrize('kwargs', [{'limit':0},{'limit':1001},{'quality':'guess'},{'cursor':'bad'}])
def test_invalid_requests_fail(env, kwargs):
    with pytest.raises(ReadRequestError):
        env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),**kwargs)


def test_latest_has_no_seven_day_cutoff_and_does_not_claim_verified(env):
    seed(env)
    result = env[0].get_latest_candles('CASH','NSE:SBIN-EQ')
    assert len(result['data']) == 1 and result['data'][0]['candle_timestamp'].startswith('2026-10-16T09:17')
    assert result['meta']['age_seconds'] > 7*86400
    assert result['quality']['status'] == 'NOT_VERIFIED'


def test_catalog_discovers_extra_tables_and_rejects_sql_identifiers(env):
    catalog = env[0].catalog
    assert 'extra_tool_table' in catalog.table_names('CASH')
    assert 'fno_extra_tool_table' in catalog.table_names('FNO')
    assert catalog.schema('CASH','extra_tool_table')['primary_key']['constrained_columns'] == ['key']
    with pytest.raises(ReadRequestError):
        catalog.rows('CASH','instruments; DROP TABLE candles')
    with pytest.raises(ReadRequestError):
        catalog.rows('CASH','instruments',filters={'bad SQL':'x'})
    assert catalog.count('CASH','instruments',{'fyers_symbol':"' OR 1=1 --"}) == 0


def test_read_requests_issue_no_data_writes(env):
    seed(env)
    statements = []
    for engine in env[1].values():
        event.listen(engine, 'before_cursor_execute', lambda c,cu,s,p,ctx,m: statements.append(s))
    service = env[0]
    service.get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY))
    service.get_coverage('CASH','NSE:SBIN-EQ',str(DAY),str(DAY))
    service.catalog.rows('CASH','instruments')
    service.catalog.schema('CASH','instruments')
    assert not any(s.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','ALTER','DROP')) for s in statements)


def test_coverage_options_sparse_does_not_claim_missing_trades(env):
    seed(env,'FNO')
    result=env[0].get_coverage('FNO','NSE:TEST-OPT',str(DAY),str(DAY))
    assert result['data'][0]['status']=='SPARSE_UNCONFIRMED'
    assert result['quality']['status']=='NOT_VERIFIED'


def test_fno_verified_sparse_values_with_null_optional_fields(env):
    rows=seed(env,'FNO')
    fno_parquet(env,rows)
    result=env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified')
    assert len(result['data'])==3
    assert result['quality']['status']=='VERIFIED'
    assert result['quality']['coverage']=='SPARSE_UNCONFIRMED'
    assert result['data'][0]['oi'] is None


def test_fno_verified_detects_same_key_changed_value_and_checksum(env):
    rows=seed(env,'FNO')
    rows[0]['close']=100
    path=fno_parquet(env,rows)
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified')
    path.write_bytes(b'broken')
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified')


def test_empty_fno_session_not_certified_and_futures_require_coverage(env):
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified')
    rows=seed(env,'FNO'); fno_parquet(env,rows)
    with env[1]['FNO'].begin() as c:
        c.execute(env[2]['FNO']['fno_instruments'].update().values(category='FUTURES'))
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified')


def test_cash_verified_reuses_existing_validator_and_rejects_missing_pq(env):
    seed(env)
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),quality='verified')


def test_strict_rechecks_between_pages_and_rejects_today(env):
    rows=seed(env,'FNO');path=fno_parquet(env,rows)
    page=env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified',limit=1)
    path.unlink()
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),quality='verified',cursor=page['meta']['next_cursor'])
    with pytest.raises(DataNotVerifiedError):
        env[0].get_candles('FNO','NSE:TEST-OPT','1m','2026-10-25','2026-10-25',quality='verified')


def test_chain_returns_all_greek_fields_and_filters_snapshot(env):
    table=env[2]['FNO']['fno_option_chain_snapshots']
    with env[1]['FNO'].begin() as c:
        c.execute(table.insert(), [{'batch_id':b,'underlying':'NIFTY','captured_at':dt.datetime(2026,10,16,10),
            'contract_id':1,'gamma':Decimal('.001'),'theta':None,'vega':Decimal('.2')} for b in ('a','b')])
    data=env[0].get_option_chain('NIFTY',str(DAY),str(DAY),batch_id='a')['data']
    assert len(data)==1 and data[0]['gamma']=='0.00100000' and data[0]['theta'] is None


def test_api_auth_and_admin_boundaries_before_db_access(env, monkeypatch):
    from ui.password_hashing import hash_password
    monkeypatch.setenv('USER_PASSWORD_HASH',hash_password('userpw'))
    monkeypatch.setenv('ADMIN_PASSWORD_HASH',hash_password('adminpw'))
    client=TestClient(create_app(env[0]))
    assert client.get('/api/v1/instruments').status_code==401
    assert client.get('/api/v1/instruments',auth=('user','wrong')).status_code==401
    assert client.get('/api/v1/instruments',auth=('user','userpw')).status_code==200
    assert client.get('/api/v1/databases',auth=('user','userpw')).status_code==403
    assert client.get('/api/v1/databases',auth=('admin','adminpw')).status_code==200
    assert client.post('/api/v1/candles',auth=('admin','adminpw')).status_code==405


def test_api_quality_conflict_and_parameter_errors(env):
    client=TestClient(create_app(env[0],auth_dependency=lambda:'admin'))
    params={'segment':'CASH','symbol':'NSE:SBIN-EQ','from':str(DAY),'to':str(DAY),'quality':'verified'}
    assert client.get('/api/v1/candles',params=params).status_code==409
    assert client.get('/api/v1/candles',params={**params,'limit':1001}).status_code==422
    assert client.get('/api/v1/databases/CASH/tables/instruments/rows',params={'filters':'[]'}).status_code==422
    job=client.get('/api/v1/jobs/4',params={'segment':'CASH'})
    assert job.status_code==200 and 'secret-do-not-expose' not in job.text


def test_configured_read_bootstrap_does_not_require_fyers_credentials(monkeypatch):
    from model.database_catalog import configured_catalog
    for key in ('FYERS_CLIENT_ID','FYERS_SECRET_KEY','FYERS_REDIRECT_URI','FYERS_ACCESS_TOKEN','FNO_DB_USER'):
        monkeypatch.delenv(key,raising=False)
    monkeypatch.setenv('DB_NAME','market_data');monkeypatch.setenv('DB_USER','reader')
    catalog=configured_catalog()
    assert 'CASH' in catalog.factories and not catalog._engines


def test_cash_verified_full_session_success(env):
    from controller.verification_controller import CashReader
    rows = seed(env, n=375)
    path = CashReader(env[1]['CASH'], env[0].catalog.roots['CASH']).path('NSE:SBIN-EQ', '1m', DAY)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([{**r, 'fyers_symbol':'NSE:SBIN-EQ'} for r in rows]).to_parquet(path, index=False)
    result = env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),quality='verified')
    assert len(result['data']) == 375
    assert result['quality']['status'] == 'VERIFIED'
    assert result['quality']['coverage'] == 'COMPLETE'


def test_before_open_is_not_a_holiday(env):
    env[0].clock = lambda: dt.datetime(2026,10,16,8,tzinfo=IST)
    result = env[0].get_coverage('CASH','NSE:SBIN-EQ',str(DAY),str(DAY))
    assert result['data'][0]['status'] == 'NO_EXPECTED_MINUTES_YET'


def test_command_facade_preserves_existing_jobs_and_checks_role_first(monkeypatch):
    from controller.market_data_service import MarketDataService
    calls = []
    class Fake:
        def submit(self, role, kind, params):
            calls.append((role,kind,params)); return 7
        def smart_preview(self, params): return {'blocked':[]}
        def historical_preview(self, params): return dict(params), {'count':1}, {'remaining':10}
    monkeypatch.setattr('controller.pipeline_service.start_worker', lambda service: calls.append('worker'))
    service = MarketDataService(cash_factory=Fake, fno_factory=Fake)
    with pytest.raises(PermissionError): service.submit_fetch('CASH',{},role='user')
    assert service._services == {}
    params = {'from':str(DAY),'to':str(DAY),'symbols':['SBIN']}
    assert service.submit_fetch('CASH',params,role='admin')['job_id'] == 7
    assert calls[0] == ('admin','SMART_FETCH',params) and calls[1] == 'worker'
    service.submit_fetch('FNO',params,role='admin')
    assert calls[-1][1] == 'HISTORICAL_HARVEST'
    service.submit_aggregation('CASH',params,role='admin')
    assert calls[-2][1] == 'AGGREGATION'
    service.submit_verification('FNO',params,role='admin')
    assert calls[-1][1] == 'VERIFY'
    assert service.preview_fetch('FNO',params,role='admin')['params'] == params


# Explicit regular-session reads preserve stored rows and validate before filtering.
def cash_snapshot(env, timeframe='1m', day=DAY):
    from controller.verification_controller import CashReader
    table=env[2]['CASH']['candles']
    with env[1]['CASH'].connect() as conn:
        rows=[dict(r) for r in conn.execute(select(table).where(table.c.timeframe==timeframe)).mappings()]
    path=CashReader(env[1]['CASH'],env[0].catalog.roots['CASH']).path('NSE:SBIN-EQ',timeframe,day)
    path.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame([{**r,'fyers_symbol':'NSE:SBIN-EQ'} for r in rows]).to_parquet(path,index=False)
    return path


def seed_cash_outside(env):
    rows=seed(env,n=375);table=env[2]['CASH']['candles']
    extra=[dict(rows[0],candle_timestamp=dt.datetime.combine(DAY,t)) for t in [dt.time(9,8),dt.time(15,30)]]
    with env[1]['CASH'].begin() as conn:conn.execute(table.insert(),extra)
    return cash_snapshot(env)


def test_regular_raw_pagination_counts_and_no_mutation(env):
    path=seed_cash_outside(env);before=path.read_bytes();queries=[]
    event.listen(env[1]['CASH'],'before_cursor_execute',lambda c,cu,s,p,ctx,m:queries.append(s))
    service=env[0];page=service.get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',limit=100)
    assert page['meta']['session_filter']['excluded_rows']==2
    assert page['meta']['session_filter']['scope_rows']==375
    assert page['quality']['status']=='NOT_VERIFIED'
    rows=list(service.iter_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',limit=100))
    assert len(rows)==len({r['candle_timestamp'] for r in rows})==375
    assert rows[0]['candle_timestamp'].endswith('09:15:00+05:30')
    assert rows[-1]['candle_timestamp'].endswith('15:29:00+05:30')
    assert len(service.get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY))['data'])==377
    with pytest.raises(ReadRequestError):service.get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),cursor=page['meta']['next_cursor'])
    assert path.read_bytes()==before
    assert not any(s.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','ALTER')) for s in queries)


def test_regular_verified_preserves_full_store_parity_checks(env):
    path=seed_cash_outside(env);before=path.read_bytes()
    page=env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',quality='verified')
    assert len(page['data'])==375 and page['quality']['status']=='VERIFIED'
    assert page['quality']['coverage']=='COMPLETE'
    assert page['meta']['session_filter']['excluded_rows']==2
    with pytest.raises(DataNotVerifiedError):env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),quality='verified')
    assert path.read_bytes()==before


@pytest.mark.parametrize('fault',['outside_mismatch','outside_bad_ohlc','outside_duplicate','missing_minute'])
def test_regular_cannot_hide_bad_or_missing_rows(env,fault):
    path=seed_cash_outside(env);table=env[2]['CASH']['candles']
    with env[1]['CASH'].begin() as conn:
        if fault=='outside_mismatch':
            conn.execute(table.update().where(table.c.candle_timestamp==dt.datetime.combine(DAY,dt.time(15,30))).values(close=100))
        elif fault=='outside_bad_ohlc':
            conn.execute(table.update().where(table.c.candle_timestamp==dt.datetime.combine(DAY,dt.time(15,30))).values(high=90))
        elif fault=='missing_minute':
            conn.execute(table.delete().where(table.c.candle_timestamp==dt.datetime.combine(DAY,dt.time(10,0))))
        else:
            row=dict(conn.execute(select(table).where(table.c.candle_timestamp==dt.datetime.combine(DAY,dt.time(15,30)))).mappings().one());row.pop('id');conn.execute(table.insert(),row)
    if fault!='outside_mismatch':cash_snapshot(env)
    with pytest.raises(DataNotVerifiedError):env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',quality='verified')


def test_regular_verified_derived_checks_full_base_then_aggregates_session(env):
    from controller.verification_controller import row_candles,candle_rows
    from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe
    from types import SimpleNamespace
    seed_cash_outside(env);table=env[2]['CASH']['candles']
    with env[1]['CASH'].begin() as conn:
        rows=[dict(r) for r in conn.execute(select(table)).mappings()]
        bars=aggregate_1m_to_timeframe(row_candles(rows,SimpleNamespace(internal_name='SBIN',fyers_symbol='NSE:SBIN-EQ',exchange='NSE',instrument_type='EQUITY')),'5m')
        values=[dict(instrument_id=1,timeframe='5m',candle_timestamp=c.timestamp.replace(tzinfo=None),open=c.open,high=c.high,low=c.low,close=c.close,volume=c.volume,source=c.source,status=c.status) for c in bars]
        conn.execute(table.insert(),values)
    cash_snapshot(env,'5m')
    page=env[0].get_candles('CASH','NSE:SBIN-EQ','5m',str(DAY),str(DAY),session='regular',quality='verified')
    assert len(page['data'])==75
    assert page['meta']['session_filter']['excluded_base_1m_rows']==2
    assert page['meta']['session_filter']['excluded_rows']==0


def test_regular_api_and_invalid_requests(env):
    seed_cash_outside(env)
    client=TestClient(create_app(env[0],auth_dependency=lambda:'admin'))
    params={'segment':'CASH','symbol':'NSE:SBIN-EQ','from':str(DAY),'to':str(DAY),'session':'regular','quality':'verified'}
    response=client.get('/api/v1/candles',params=params)
    assert response.status_code==200 and response.json()['meta']['session_filter']['excluded_rows']==2
    assert client.get('/api/v1/candles',params={**params,'session':'invalid'}).status_code==422
    assert client.get('/api/v1/candles',params={**params,'segment':'FNO','symbol':'NSE:TEST-OPT'}).status_code==422
    assert client.get('/api/v1/candles',params={**params,'closed_only':'false'}).status_code==422
    assert client.get('/api/v1/candles',params={**params,'from':'2026-01-01'}).status_code==422


def test_regular_split_session_and_calendar_cursor_change(env,tmp_path):
    import yaml
    from model.config import market_calendar as mc
    cfg=tmp_path/'calendar.yaml';cfg.write_text('''verified_years: {CASH: [2026]}
special_sessions:
  "2026-10-16":
    verified: true
    intervals: [{open: "09:15", close: "10:00"}, {open: "11:30", close: "12:30"}]
''')
    mc.reload_holidays(cfg)
    try:
        seed(env,n=375)
        page=env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',limit=50)
        rows=list(env[0].iter_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',limit=50))
        assert len(rows)==105 and page['meta']['session_filter']['excluded_rows']==270
        data=yaml.safe_load(cfg.read_text());data['version']='changed';cfg.write_text(yaml.safe_dump(data))
        with pytest.raises(ReadRequestError):env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',cursor=page['meta']['next_cursor'])
        data['verified_years']['CASH']=[];cfg.write_text(yaml.safe_dump(data))
        with pytest.raises(DataNotVerifiedError):env[0].get_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular')
    finally:mc.reload_holidays()
