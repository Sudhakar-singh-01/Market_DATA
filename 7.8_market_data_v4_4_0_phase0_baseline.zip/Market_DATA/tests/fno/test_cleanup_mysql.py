"""Optional destructive integration test ONLY on clean_fno's disposable database."""
import datetime as dt
from decimal import Decimal
import pandas as pd
from sqlalchemy import text
from model.cleanup_service import CleanupService
from model.database_catalog import DatabaseCatalog
from model.fno.models import FnoContract,FnoCandle,IST
from model.fno.repository import FnoRepository
from model.fno.parquet_store import FnoParquetStore


def test_mysql_shared_partition_cleanup(clean_fno,tmp_path):
    engine=clean_fno
    assert engine.url.database=='fno_market_data_test'
    repo=FnoRepository(engine)
    expiry=dt.date(2020,1,30); day=dt.date(2020,1,10)
    symbols=['NSE:CLEANUPONE20JANFUT','NSE:CLEANUPTWO20JANFUT']
    ids=[repo.upsert_contract(FnoContract(s,'NIFTY','NSE','FUTURES',expiry)) for s in symbols]
    rows=[FnoCandle(i,'1m',dt.datetime(2020,1,10,9,15,tzinfo=IST),
          Decimal('100'),Decimal('101'),Decimal('99'),Decimal('100'),10) for i in ids]
    repo.upsert_candles(rows)
    root=tmp_path/'fno'; root.mkdir()
    store=FnoParquetStore(root,repo)
    result=store.write_candles(rows,{i:('NIFTY',expiry) for i in ids})
    service=CleanupService(DatabaseCatalog({'FNO':lambda:engine},roots={'FNO':root}),tmp_path/'journals')
    plan=service.preview('FNO',symbols[0],str(day),str(day),role='admin')
    done=service.apply(plan,role='admin',confirmation='CLEANUP fno_market_data_test',
                       backup_acknowledged=True,writers_stopped=True)
    assert done['status']=='SUCCESS'
    with engine.connect() as c:
        assert c.execute(text('SELECT contract_id FROM fno_candles')).scalars().all()==[ids[1]]
    path=root/result.files[0]
    assert pd.read_parquet(path).contract_id.tolist()==[ids[1]]
    assert repo.manifest_get(result.files[0])['row_count']==1
