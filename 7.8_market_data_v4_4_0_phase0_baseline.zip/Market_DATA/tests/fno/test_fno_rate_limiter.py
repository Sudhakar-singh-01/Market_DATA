import datetime
import pytest

from model.fyers import rate_limiter as rl
from model.fyers.rate_limiter import (SlidingWindowLimiter, RateLimitedClient, DailyQuotaExhausted,
                                      LimiterTimeout, HIGH, LOW)


class FakeTime:
    def __init__(self):
        self.t = 1000.0
        self.slept = 0.0
    def clock(self):
        return self.t
    def sleep(self, s):
        self.t += s
        self.slept += s


def make(ft, **kw):
    args = dict(per_second=3, per_minute=1000, per_day=100000, low_priority_reserve=0.0)
    args.update(kw)
    return SlidingWindowLimiter(clock=ft.clock, sleep=ft.sleep, **args)


def test_per_second_window_blocks_then_releases():
    ft = FakeTime(); lim = make(ft)
    for _ in range(3):
        assert lim.acquire() == 0.0
    waited = lim.acquire()
    assert 0.99 <= waited <= 1.6          # had to wait for the first slot to leave the 1 s window


def test_per_minute_window_is_a_real_window_not_a_bursty_bucket():
    ft = FakeTime(); lim = make(ft, per_second=1000, per_minute=5)
    for _ in range(5):
        lim.acquire()
    # a 6th call inside the same minute must wait ~60 s; a token bucket with refill would not
    assert lim.acquire() >= 59.0
    # and never more than 5 grants inside any 60 s span
    assert lim.stats()["used_last_minute"] <= 5


def test_low_priority_cannot_consume_the_reserved_share():
    ft = FakeTime(); lim = make(ft, per_second=10, low_priority_reserve=0.3)
    for _ in range(7):
        assert lim.acquire(LOW) == 0.0           # 70% of 10
    assert lim.acquire(LOW) > 0.0                 # 8th low call has to wait
    # reset and prove HIGH still gets the reserved slots immediately
    ft2 = FakeTime(); lim2 = make(ft2, per_second=10, low_priority_reserve=0.3)
    for _ in range(7):
        lim2.acquire(LOW)
    for _ in range(3):
        assert lim2.acquire(HIGH) == 0.0          # Subsystem A is not starved by FNO


def test_daily_quota_low_stops_at_reserve_high_continues():
    ft = FakeTime(); lim = make(ft, per_second=1000, per_minute=1000, per_day=10, low_priority_reserve=0.3)
    for _ in range(7):
        lim.acquire(LOW)
    with pytest.raises(DailyQuotaExhausted):
        lim.acquire(LOW)
    for _ in range(3):
        lim.acquire(HIGH)
    with pytest.raises(DailyQuotaExhausted):
        lim.acquire(HIGH)


def test_daily_counter_resets_on_new_ist_day():
    ft = FakeTime(); day = {"d": datetime.date(2026, 10, 19)}
    lim = SlidingWindowLimiter(2, 1000, 2, 0.0, clock=ft.clock, sleep=ft.sleep, today=lambda: day["d"])
    lim.acquire(); lim.acquire()
    with pytest.raises(DailyQuotaExhausted):
        lim.acquire()
    day["d"] = datetime.date(2026, 10, 20)
    ft.t += 5
    lim.acquire()
    assert lim.stats()["used_today"] == 1


def test_timeout_raises_instead_of_blocking_forever():
    ft = FakeTime(); lim = make(ft, per_second=1, per_minute=1)
    lim.acquire()
    with pytest.raises(LimiterTimeout):
        lim.acquire(timeout=5.0)


def test_invalid_arguments():
    with pytest.raises(ValueError):
        SlidingWindowLimiter(0, 1, 1)
    with pytest.raises(ValueError):
        SlidingWindowLimiter(1, 1, 1, low_priority_reserve=1.0)
    with pytest.raises(ValueError):
        make(FakeTime()).acquire("urgent")


def test_rate_limited_client_counts_only_rest_methods():
    ft = FakeTime(); lim = make(ft, per_second=100)

    class Fake:
        def history(self, data=None): return {"s": "ok", "candles": []}
        def optionchain(self, data=None): return {"s": "ok"}
        def helper(self): return "x"

    c = RateLimitedClient(Fake(), lim, LOW)
    c.history(data={}); c.optionchain(data={}); assert c.helper() == "x"
    assert c.requests_made == 2
    assert lim.stats()["granted_low"] == 2


def test_shared_hook_is_noop_by_default_and_counts_when_configured():
    rl.configure_shared_limiter(None)
    assert rl.acquire_shared() == 0.0                       # Subsystem A unchanged
    ft = FakeTime(); lim = make(ft, per_second=100)
    rl.configure_shared_limiter(lim)
    try:
        rl.acquire_shared(); rl.acquire_shared(HIGH)
        assert lim.stats()["granted_high"] == 2
    finally:
        rl.configure_shared_limiter(None)


def test_subsystem_a_rest_call_sites_use_the_shared_limiter():
    """A's historical fetch and quotes both draw from the shared FYERS budget."""
    from model.fyers import historical, quotes
    ft = FakeTime(); lim = make(ft, per_second=100)
    rl.configure_shared_limiter(lim)

    class Client:
        def history(self, data=None): return {"s": "ok", "candles": []}
        def quotes(self, data=None): return {"s": "ok", "d": []}

    try:
        historical._fetch_chunk(Client(), "NSE:SBIN-EQ", "2026-10-01", "2026-10-02")
        quotes.get_quotes_bulk(Client(), ["NSE:SBIN-EQ"])
        assert lim.stats()["granted_high"] == 2
    finally:
        rl.configure_shared_limiter(None)
