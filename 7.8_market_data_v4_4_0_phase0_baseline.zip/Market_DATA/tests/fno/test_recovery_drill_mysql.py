"""Opt-in real restore drill, restricted to disposable test databases.

Unlike the product verifier, this test imports a dump it just generated from
clean_fno. It never imports a user-selected archive or reuses an existing target.
"""
import datetime as dt
import os
import uuid
from decimal import Decimal
from pathlib import Path
import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.pool import NullPool
from model.backup_service import BackupService
from model.database_catalog import DatabaseCatalog
from model.fno.models import FnoContract,FnoCandle,IST
from model.fno.repository import FnoRepository
from model.fno.parquet_store import FnoParquetStore
from model.fno.migrations import split_statements
from model.recovery_verification import RecoveryVerifier


@pytest.mark.skipif(os.environ.get('RUN_RECOVERY_MYSQL_TEST')!='1',reason='Opt-in disposable-MySQL restore drill: RUN_RECOVERY_MYSQL_TEST=1')
def test_fresh_database_restore_and_exhaustive_verification(clean_fno,tmp_path):
    source=clean_fno
    assert source.url.database=='fno_market_data_test'
    repo=FnoRepository(source)
    expiry=dt.date(2020,1,30)
    cid=repo.upsert_contract(FnoContract('NSE:RECOVERY20JANFUT','NIFTY','NSE','FUTURES',expiry))
    candle=FnoCandle(cid,'1m',dt.datetime(2020,1,10,9,15,tzinfo=IST),
                     Decimal('100.1234'),Decimal('101.0000'),Decimal('99.0000'),Decimal('100.5678'),10)
    repo.upsert_candles([candle])
    root=tmp_path/'source_parquet'; root.mkdir()
    FnoParquetStore(root,repo).write_candles([candle],{cid:('NIFTY',expiry)})
    backups=BackupService(DatabaseCatalog({'FNO':lambda:source},roots={'FNO':root}),tmp_path/'backups',tmp_path/'recovery')
    archive=backups.create(backups.preview('FNO',role='admin'),role='admin',writers_stopped=True)
    checked=backups.verify(archive['backup_id'],role='admin')
    stage=Path(backups.stage_recovery(checked,role='admin',confirmation='STAGE '+archive['backup_id'])['path'])
    target_name='tios_recovery_test_'+uuid.uuid4().hex[:12]
    quote=source.dialect.identifier_preparer.quote
    created=False; target=None
    try:
        with source.begin() as conn:
            conn.exec_driver_sql('CREATE DATABASE '+quote(target_name)+' CHARACTER SET utf8mb4')
        created=True
        target=create_engine(source.url.set(database=target_name),poolclass=NullPool)
        # Trusted fixture-generated dump only, imported into this fresh random DB.
        with target.begin() as conn:
            for sql in split_statements((stage/'database.sql').read_text(encoding='utf-8')):
                conn.exec_driver_sql(sql)
        verifier=RecoveryVerifier(backups,target,['market_data_test','fno_market_data_test'],tmp_path/'reports')
        report=verifier.verify(archive['backup_id'],stage.name,role='admin',confirmation='VERIFY '+target_name)
        assert report['status']=='VERIFIED',report
        assert report['market_parity']=='NOT_TESTED'
        assert report['restore_tested'] is False
        assert checked['manifest']['restore_tested'] is False
        assert list((stage/'parquet').rglob('*.parquet'))
    finally:
        if target is not None:target.dispose()
        if created:
            with source.begin() as conn:
                conn.exec_driver_sql('DROP DATABASE '+quote(target_name))
