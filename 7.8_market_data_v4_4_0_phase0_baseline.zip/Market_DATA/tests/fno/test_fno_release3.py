import dataclasses
import datetime as dt
import json
import threading
from decimal import Decimal
from types import SimpleNamespace

import pandas as pd
import pytest
from sqlalchemy import text

from controller.fno_aggregate import run_aggregation
from controller.fno_verify import run_verification, coverage
from controller.fno_jobs import FnoJobRunner
from model.fno.aggregation import aggregate_day,MINUTES
from model.fno.config import load_fno_settings,DEFAULT_SESSION
from model.fno.job_store import FnoJobStore
from model.fno.models import IST
from model.fno.parquet_store import FnoParquetStore,candles_to_frame,merge_candle_frames
from model.fno.repository import FnoRepository,_UPSERT_SQL,_row_values
from model.fno.release3_repository import Release3Repository
from model.fno.comparison import frames_equal
from tests_support import make_candle,sample_contract,a_fingerprint,tree_fingerprint

DAY=dt.date(2026,10,19)
NOW=dt.datetime(2026,10,19,16,5,tzinfo=IST)


@pytest.mark.parametrize("tf,n,last_start,last_volume",[("5m",77,"15:35",50),("15m",26,"15:30",100),
    ("30m",13,"15:15",250),("1h",7,"15:15",250),("1d",1,"09:15",3850)])
def test_session_anchored_full_day_decimal_ohlcv_oi(tf,n,last_start,last_volume):
    rows=[make_candle(1,i,oi=i if i%7 else None,iv=Decimal("19.5"),delta=Decimal(".3")) for i in range(385)]
    rows[2]=dataclasses.replace(rows[2],high=Decimal("105"))
    r=aggregate_day(rows,DAY,tf,now=NOW)
    assert len(r.candles)==n and r.skipped==0
    assert r.candles[0].timestamp.strftime("%H:%M")=="09:15"
    assert r.candles[-1].timestamp.strftime("%H:%M")==last_start
    assert r.candles[-1].volume==last_volume
    assert sum(c.volume for c in r.candles)==3850
    assert r.candles[0].high==Decimal("105") and r.candles[-1].oi==384
    assert all(c.iv is c.delta is c.gamma is c.theta is c.vega is None for c in r.candles)


def test_missing_minute_open_duplicate_and_invalid_buckets_are_not_fabricated():
    rows=[make_candle(1,i) for i in range(385) if i!=2]
    rows[9]=dataclasses.replace(rows[9],status="OPEN")
    rows.append(rows[20])
    rows.append(make_candle(1,-1))
    r=aggregate_day(rows,DAY,"5m",now=NOW)
    assert len(r.candles)==74 and r.incomplete_buckets==3 and r.invalid_rows==2
    assert all(c.timestamp.strftime("%H:%M") not in ("09:15","09:25","09:35") for c in r.candles)


def test_forming_bucket_never_closed_and_last_non_null_oi():
    rows=[make_candle(1,i,oi=123 if i==2 else None) for i in range(5)]
    r=aggregate_day(rows,DAY,"5m",now=NOW.replace(hour=9,minute=19))
    assert not r.candles and r.forming_buckets==77
    r=aggregate_day(rows,DAY,"5m",now=NOW.replace(hour=9,minute=20))
    assert len(r.candles)==1 and r.candles[0].oi==123


def test_options_silence_is_not_a_failure_futures_have_observed_gap_counts():
    rows=[make_candle(1,0),make_candle(1,384)]
    s,d=coverage(rows,DAY,"OPTIONS",DEFAULT_SESSION,NOW)
    assert s=="NOT_VERIFIED" and d["largest_silent_stretch_minutes"]==383
    s,d=coverage(rows,DAY,"FUTURES",DEFAULT_SESSION,NOW)
    assert s=="WARNING" and d["missing_minutes"]==383


@pytest.fixture()
def r3(clean_fno,tmp_path):
    repo=Release3Repository(clean_fno)
    contract=sample_contract(category="FUTURES",symbol="NSE:NIFTY26NOVFUT")
    cid=repo.upsert_contract(contract)
    settings=dataclasses.replace(load_fno_settings(),parquet_root=tmp_path/"fno")
    store=FnoParquetStore(settings.parquet_root,repo)
    jobs=FnoJobStore(clean_fno)
    params={"from":str(DAY),"to":str(DAY),"contract_ids":[cid],"use_parquet":True,"timeframes":list(MINUTES)}
    def seed(source="FYERS_HISTORICAL",count=385):
        rows=[make_candle(cid,i,oi=1000+i,source=source) for i in range(count)]
        repo.upsert_candles(rows);store.write_candles(rows,repo.contract_meta({cid}))
        return rows
    def run(kind="AGGREGATION",params_override=None,store_override="normal"):
        p=params if params_override is None else params_override
        jid=jobs.submit(kind,p)
        use=store if store_override=="normal" else store_override
        fn=run_aggregation if kind=="AGGREGATION" else run_verification
        runner=FnoJobRunner(jobs,{kind:lambda h:fn(h,repo,use,settings,now=NOW)},heartbeat_seconds=.05)
        assert runner.run_one()==jid
        return jobs.get(jid)
    return SimpleNamespace(repo=repo,store=store,settings=settings,jobs=jobs,cid=cid,params=params,seed=seed,run=run,engine=clean_fno)


def test_full_aggregate_both_stores_idempotent_verified_and_isolated(r3,a_engine):
    before=a_fingerprint(a_engine)
    r3.seed()
    j=r3.run()
    assert j["state"]=="SUCCESS",j
    for tf,n in (("5m",77),("15m",26),("30m",13),("1h",7),("1d",1)):
        rows=r3.repo.fetch_candles(r3.cid,tf,DAY,DAY)
        assert len(rows)==n and r3.repo.get_checkpoint_ranges(r3.cid,"AGGREGATION",tf)==[(DAY,DAY,"VERIFIED")]
        rel=r3.store.relative_candle_path(tf,"NIFTY",dt.date(2026,11,26),DAY)
        assert frames_equal(candles_to_frame(rows),r3.store.read_partition(rel))
    assert r3.run()["state"]=="SUCCESS"
    records=r3.repo.query("SELECT * FROM fno_aggregation_jobs")
    assert len(records)==10 and all(r["state"]=="SUCCESS" and r["heartbeat_at"] for r in records)
    assert a_fingerprint(a_engine)==before


def test_derived_rebuild_tracks_historical_correction_and_removes_stale_bucket(r3):
    r3.seed(source="FYERS_LIVE")
    assert r3.run()["state"]=="SUCCESS"
    r3.repo.upsert_candles([make_candle(r3.cid,1,h="109",v=50,oi=2000)])
    assert r3.run()["state"]=="SUCCESS"
    first=r3.repo.fetch_candles(r3.cid,"5m",DAY,DAY)[0]
    assert first.high==Decimal("109") and first.volume==90
    with r3.engine.begin() as c:
        c.execute(text("DELETE FROM fno_candles WHERE contract_id=:c AND timeframe='1m' AND candle_timestamp=:t"),
                  {"c":r3.cid,"t":make_candle(r3.cid,1).naive_ist()})
    assert r3.run()["state"]=="PARTIAL"
    assert len(r3.repo.fetch_candles(r3.cid,"5m",DAY,DAY))==76
    assert r3.repo.get_checkpoint_ranges(r3.cid,"AGGREGATION","5m")==[]
    assert r3.repo.fetch_candles(r3.cid,"1d",DAY,DAY)==[]


def test_failed_parquet_write_does_not_checkpoint_and_resume_rebuilds(r3,monkeypatch):
    r3.seed()
    original=r3.store.replace_derived_partition
    monkeypatch.setattr(r3.store,"replace_derived_partition",lambda *a,**k:(_ for _ in ()).throw(OSError("disk full")))
    j=r3.run()
    assert j["state"]=="FAILED" and "disk full" in j["error"]
    assert not r3.repo.get_checkpoint_ranges(r3.cid,"AGGREGATION","5m")
    monkeypatch.setattr(r3.store,"replace_derived_partition",original)
    jid=r3.jobs.resume(j["id"])
    runner=FnoJobRunner(r3.jobs,{"AGGREGATION":lambda h:run_aggregation(h,r3.repo,r3.store,r3.settings,now=NOW)})
    assert runner.run_one()==jid and r3.jobs.get(jid)["state"]=="SUCCESS"


def test_aggregate_cancelled_before_first_day_has_no_writes(r3):
    r3.seed()
    jid=r3.jobs.submit("AGGREGATION",r3.params)
    job=r3.jobs.claim_next();r3.jobs.request_cancel(jid)
    from controller.fno_jobs import JobHandle
    out=run_aggregation(JobHandle(r3.jobs,job,threading.Event()),r3.repo,r3.store,r3.settings,now=NOW)
    assert out.state=="CANCELLED" and not r3.repo.fetch_candles(r3.cid,"5m",DAY,DAY)


def test_quality_read_only_and_detects_same_keys_wrong_values(r3):
    rows=r3.seed()
    rel=r3.store.relative_candle_path("1m","NIFTY",dt.date(2026,11,26),DAY)
    df=r3.store.read_partition(rel);df.loc[0,"high"]=123
    df.to_parquet(r3.store.abs_path(rel),index=False)
    r3.repo.manifest_verify(rel,df.candle_timestamp.min(),df.candle_timestamp.max(),len(df),r3.store.sha256(r3.store.abs_path(rel)))
    before=tree_fingerprint(r3.store.root)
    j=r3.run("VERIFY")
    assert j["state"]=="PARTIAL" and j["result"]["checks"]["FAIL"]>=1
    assert any(s["check"]=="mysql_parquet_values" for s in j["result"]["samples"])
    assert tree_fingerprint(r3.store.root)==before
    assert r3.repo.fetch_candles(r3.cid,"1m",DAY,DAY)==rows


def test_quality_full_day_and_aggregation_pass_then_catches_tampering(r3):
    r3.seed(); assert r3.run()["state"]=="SUCCESS"
    j=r3.run("VERIFY")
    assert j["state"]=="SUCCESS",j
    with r3.engine.begin() as c:
        c.execute(text("UPDATE fno_candles SET high=1 WHERE contract_id=:c AND timeframe='1d'"),{"c":r3.cid})
    j=r3.run("VERIFY")
    assert j["state"]=="PARTIAL" and j["result"]["checks"]["FAIL"]>=2
    assert any(s["check"]=="aggregation_matches_source" for s in j["result"]["samples"])


def test_checkpoint_absent_and_missing_file_are_failures(r3):
    r3.seed()
    r3.repo.add_checkpoint_range(r3.cid,"AGGREGATION","5m",DAY,DAY,"VERIFIED")
    for rel in r3.store.list_candle_files():r3.store.abs_path(rel).unlink()
    j=r3.run("VERIFY")
    checks={s["check"] for s in j["result"]["samples"] if s["status"]=="FAIL"}
    assert {"checkpoint_data_present","manifest_file","mysql_parquet_values"}<=checks,(j,r3.repo.manifest_list())


def test_sql_race_guard_does_not_fill_conflicting_or_live_optional_fields(r3):
    r3.repo.upsert_candles([make_candle(r3.cid)])
    with r3.engine.begin() as c:
        c.execute(_UPSERT_SQL,_row_values(make_candle(r3.cid,h="999",oi=800)))
        c.execute(_UPSERT_SQL,_row_values(make_candle(r3.cid,source="FYERS_LIVE",oi=900)))
    row=r3.repo.fetch_candles(r3.cid,"1m",DAY,DAY)[0]
    assert row.high==Decimal("101") and row.oi is None


def test_parquet_live_never_fills_stored_history():
    old=candles_to_frame([make_candle(1)])
    new=candles_to_frame([make_candle(1,source="FYERS_LIVE",oi=900)])
    result,_=merge_candle_frames(old,new)
    assert pd.isna(result.iloc[0].oi)


def test_chain_retention_has_own_cutoff_is_dry_run_and_guarded(r3):
    p=r3.store.root/"option_chain"/"underlying=NIFTY"/"date=2026-01-01.parquet"
    p.parent.mkdir(parents=True);p.write_text("old")
    before=tree_fingerprint(r3.store.root)
    assert r3.store.cleanup_old_files(400,chain_retain_days=120,today=DAY)==[p.relative_to(r3.store.root).as_posix()]
    assert tree_fingerprint(r3.store.root)==before
    with pytest.raises(Exception): r3.store.cleanup_old_files(-1)
    r3.store.cleanup_old_files(400,chain_retain_days=120,today=DAY,dry_run=False,confirm=True)
    assert not p.exists()


def test_reconcile_reports_same_key_value_conflict_without_false_repair(r3):
    from controller.fno_reconcile import reconcile
    r3.seed(count=1)
    with r3.engine.begin() as c:c.execute(text("UPDATE fno_candles SET high=105"))
    report=reconcile(r3.repo,r3.store,repair=True)
    assert not report.ok
    assert any(f["kind"]=="mysql_parquet_mismatch" and not f["repaired"] for f in report.findings)


def test_rebuild_preserves_other_contracts_in_shared_partition(r3):
    r3.seed()
    cid2=r3.repo.upsert_contract(sample_contract(symbol='NSE:NIFTY26NOV25600CE',strike=Decimal('25600')))
    r3.repo.upsert_candles([make_candle(cid2,i,v=20) for i in range(385)])
    params={**r3.params,'contract_ids':[r3.cid,cid2],'timeframes':['5m']}
    assert r3.run(params_override=params)['state']=='SUCCESS'
    assert r3.run(params_override={**params,'contract_ids':[r3.cid]})['state']=='SUCCESS'
    rel=r3.store.relative_candle_path('5m','NIFTY',dt.date(2026,11,26),DAY)
    frame=r3.store.read_partition(rel)
    assert len(frame)==154 and set(frame[frame.contract_id==cid2].volume)=={100}


def test_verify_chain_values_and_mysql_only_chain(r3):
    from controller.fno_chain import snapshot_once
    from test_fno_chain import FakeChainClient,response,opt
    cid=r3.repo.upsert_contract(sample_contract())
    client=FakeChainClient(lambda d,n:response([opt('NSE:NIFTY26NOV25500CE',25500,'CE')]))
    s=snapshot_once(r3.repo,r3.store,client,r3.settings,'NIFTY',clock=lambda:NOW)
    assert not s.error
    j=r3.run('VERIFY',params_override={**r3.params,'contract_ids':[cid]})
    assert j['result']['checks']['FAIL']==0,j
    with r3.engine.begin() as c:
        c.execute(text('UPDATE fno_option_chain_snapshots SET gamma=1'))
    j=r3.run('VERIFY')
    assert j['result']['checks']['FAIL']>=1
    for p in (r3.store.root/'option_chain').rglob('*.parquet'):p.unlink()
    j=r3.run('VERIFY')
    assert any(s['check']=='chain_mysql_parquet_counts' and s['status']=='FAIL' for s in j['result']['samples'])


def test_live_stop_event_unblocks_socket_and_flushes():
    from controller.fno_live import run_live
    stopped=threading.Event();entered=threading.Event();stop=threading.Event()
    class Ingestor:
        clock=staticmethod(lambda:dt.datetime(2026,10,19,10,tzinfo=IST))
        settings=SimpleNamespace(session=None,live=SimpleNamespace(flush_seconds=.01))
        symbols=['S'];shutdown_called=False
        def on_message(self,*a):pass
        def on_reconnect(self,*a):pass
        def maybe_end_of_session(self):pass
        def flush(self):pass
        def report_freshness(self):pass
        def shutdown(self):self.shutdown_called=True
    class Socket:
        def connect_and_run(self):entered.set();stopped.wait(3)
        def stop(self):stopped.set()
    ing=Ingestor()
    t=threading.Thread(target=run_live,args=(ing,lambda *a:Socket(),stop))
    t.start();assert entered.wait(2)
    stop.set();t.join(timeout=2)
    assert not t.is_alive() and ing.shutdown_called


def test_parallel_partition_writes_keep_both_contracts(r3):
    from concurrent.futures import ThreadPoolExecutor
    cid2=r3.repo.upsert_contract(sample_contract())
    rows1=[make_candle(r3.cid,i) for i in range(10)]
    rows2=[make_candle(cid2,i) for i in range(10)]
    meta=r3.repo.contract_meta({r3.cid,cid2})
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(r3.store.write_candles,rows,meta) for rows in (rows1,rows2)]
        for f in futures:assert len(f.result().files)==1
    rel=r3.store.relative_candle_path('1m','NIFTY',dt.date(2026,11,26),DAY)
    assert len(r3.store.read_partition(rel))==20


def test_aggregation_recovery_updates_its_detail_job(r3):
    jid=r3.jobs.submit('AGGREGATION',r3.params)
    r3.jobs.claim_next()
    aid=r3.repo.start_aggregation(jid,'5m',r3.params)
    old=dt.datetime(2020,1,1)
    r3.jobs.heartbeat(jid,old)
    assert r3.repo.query('SELECT heartbeat_at FROM fno_aggregation_jobs WHERE id=:i',{'i':aid})[0]['heartbeat_at']==old
    assert jid in r3.jobs.recover_interrupted(90)
    assert r3.repo.query('SELECT state FROM fno_aggregation_jobs WHERE id=:i',{'i':aid})[0]['state']=='INTERRUPTED'
