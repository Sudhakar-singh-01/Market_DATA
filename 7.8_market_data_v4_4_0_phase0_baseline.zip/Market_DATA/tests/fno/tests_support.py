"""Shared helpers for FNO tests (imported by tests and by conftest.py)."""
import datetime
import hashlib
from decimal import Decimal
from pathlib import Path

from sqlalchemy import text

from model.fno.models import FnoContract, FnoCandle, IST

def a_fingerprint(engine) -> str:
    """Hash of every Subsystem A table's full content (the 'byte-for-byte' check)."""
    h = hashlib.sha256()
    with engine.connect() as conn:
        tables = sorted(r[0] for r in conn.execute(text("SHOW TABLES")))
        for t in tables:
            h.update(t.encode())
            rows = conn.execute(text(f"SELECT * FROM {t} ORDER BY 1")).fetchall()
            h.update(repr([tuple(map(str, r)) for r in rows]).encode())
    return h.hexdigest()


def tree_fingerprint(root: Path) -> str:
    h = hashlib.sha256()
    if not root.exists():
        return "absent"
    for p in sorted(root.rglob("*")):
        if p.is_file():
            h.update(str(p.relative_to(root)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def sample_contract(symbol="NSE:NIFTY26NOV25500CE", underlying="NIFTY", category="OPTIONS",
                    expiry=datetime.date(2026, 11, 26), strike=Decimal("25500"), option_type="CE", **kw):
    if category == "FUTURES":
        strike, option_type = None, None
    return FnoContract(fyers_symbol=symbol, underlying=underlying, exchange="NSE", category=category,
                       expiry=expiry, strike=strike, option_type=option_type, lot_size=kw.get("lot_size", 75),
                       tick_size=Decimal("0.05"), fytoken=kw.get("fytoken", "101126111234"))


def make_candle(contract_id, minute=0, day=datetime.date(2026, 10, 19), o="100", h="101", l="99", c="100.5",
                v=10, tf="1m", status="CLOSED", **kw):
    ts = datetime.datetime.combine(day, datetime.time(9, 15), tzinfo=IST) + datetime.timedelta(minutes=minute)
    return FnoCandle(contract_id=contract_id, timeframe=tf, timestamp=ts, open=Decimal(o), high=Decimal(h),
                     low=Decimal(l), close=Decimal(c), volume=v, status=status, **kw)
