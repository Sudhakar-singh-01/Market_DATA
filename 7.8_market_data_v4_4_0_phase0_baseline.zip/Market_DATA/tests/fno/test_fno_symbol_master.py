import datetime, os, time
from decimal import Decimal
import pytest
from model.fno import symbol_master as sm
from model.fno.repository import FnoRepository

COLS = {"fytoken": 0, "symbol_details": 1, "exchange_instrument_type": 2, "lot_size": 3, "tick_size": 4,
        "expiry": 8, "symbol": 9, "exchange": 10, "underlying": 13, "strike": 15, "option_type": 16}


def csv_row(sym, und, exp, strike, opt, lot=75, tok="1011"):
    r = [""] * 17
    r[0], r[3], r[4], r[8], r[9], r[10], r[13], r[15], r[16] = tok, lot, "0.05", exp, sym, "NSE", und, strike, opt
    return ",".join(map(str, r))


EPOCH = int(datetime.datetime(2026, 11, 26, 9, 0, tzinfo=datetime.timezone.utc).timestamp())   # 14:30 IST


def test_expiry_parsing_variants():
    assert sm.parse_expiry(EPOCH) == datetime.date(2026, 11, 26)
    assert sm.parse_expiry(str(EPOCH)) == datetime.date(2026, 11, 26)
    assert sm.parse_expiry("2026-11-26") == datetime.date(2026, 11, 26)
    assert sm.parse_expiry("26-11-2026") == datetime.date(2026, 11, 26)
    assert sm.parse_expiry("garbage") is None and sm.parse_expiry("") is None


def test_csv_weekly_and_monthly_symbols_use_fields_not_names():
    text = "\n".join([
        csv_row("NSE:NIFTY26NOV25500CE", "NIFTY", EPOCH, 25500, "CE"),
        csv_row("NSE:NIFTY2611325500PE", "NIFTY", EPOCH, 25500.5, "PE"),      # weekly layout
        csv_row("NSE:NIFTY26NOVFUT", "NIFTY", EPOCH, -1, "XX"),
    ])
    rep = sm.parse_csv_master(text, COLS)
    by = {c.fyers_symbol: c for c in rep.contracts}
    assert by["NSE:NIFTY26NOV25500CE"].category == "OPTIONS" and by["NSE:NIFTY26NOV25500CE"].strike == Decimal("25500")
    assert by["NSE:NIFTY2611325500PE"].option_type == "PE" and by["NSE:NIFTY2611325500PE"].strike == Decimal("25500.5")
    fut = by["NSE:NIFTY26NOVFUT"]
    assert fut.category == "FUTURES" and fut.strike is None and fut.option_type is None
    assert all(c.expiry == datetime.date(2026, 11, 26) and c.underlying == "NIFTY" for c in rep.contracts)


def test_bad_rows_are_skipped_and_counted_never_guessed():
    text = "\n".join([
        csv_row("NSE:A", "NIFTY", "bad", 100, "CE"), csv_row("NSE:B", "NIFTY", EPOCH, 0, "CE"),
        csv_row("NSE:C", "", EPOCH, 100, "CE"), csv_row("NSE:D", "NIFTY", EPOCH, 100, "ZZ"),
        csv_row("NSE:E", "NIFTY", EPOCH, 100, "XX"), "1,2,3", ""])
    rep = sm.parse_csv_master(text, COLS)
    assert rep.contracts == []
    assert rep.skipped == {"bad_expiry": 1, "option_without_strike": 1, "missing_underlying": 1,
                           "unknown_option_type": 1, "unclassifiable": 1, "short_row": 1}


def test_json_master_with_field_variants():
    data = {"NSE:BANKNIFTY26NOV55000CE": {"fyToken": "1", "underSym": "BANKNIFTY", "expiryDate": str(EPOCH),
                                          "strikePrice": 55000, "optType": "CE", "minLotSize": 30, "tickSize": 0.05},
            "NSE:BANKNIFTY26NOVFUT": {"underSym": "BANKNIFTY", "expiryDate": str(EPOCH), "strikePrice": -1, "optType": "XX"},
            "NSE:X": "not-a-dict"}
    rep = sm.parse_json_master(data)
    assert len(rep.contracts) == 2 and rep.skipped == {"malformed_row": 1}
    assert {c.category for c in rep.contracts} == {"OPTIONS", "FUTURES"}


def test_download_uses_fresh_cache_and_refreshes_stale(tmp_path):
    calls = []
    class R:
        status_code = 200; text = "fresh"
    get = lambda u, t: (calls.append(u), R())[1]
    p = tmp_path / "c" / "m.csv"
    assert sm.download_symbol_master("http://x", p, 20, 5, http_get=get) == "fresh" and len(calls) == 1
    assert sm.download_symbol_master("http://x", p, 20, 5, http_get=get) == "fresh" and len(calls) == 1   # cache hit
    old = time.time() - 48 * 3600; os.utime(p, (old, old))
    sm.download_symbol_master("http://x", p, 20, 5, http_get=get); assert len(calls) == 2
    class Bad:
        status_code = 503; text = ""
    with pytest.raises(RuntimeError):
        sm.download_symbol_master("http://x", p, 20, 5, force=True, http_get=lambda u, t: Bad())


def test_sync_filters_universe_tracks_first_last_seen_and_expires(clean_fno):
    repo = FnoRepository(clean_fno)
    d1 = datetime.date(2026, 10, 19)
    exp_old = int(datetime.datetime(2026, 10, 13, 9, 0, tzinfo=datetime.timezone.utc).timestamp())
    day1 = sm.parse_csv_master("\n".join([
        csv_row("NSE:NIFTY26OCT25000CE", "NIFTY", exp_old, 25000, "CE"),
        csv_row("NSE:NIFTY26NOV25500CE", "NIFTY", EPOCH, 25500, "CE"),
        csv_row("NSE:RELIANCE26NOVFUT", "RELIANCE", EPOCH, -1, "XX")]), COLS)
    out = sm.sync_contracts(repo, day1, ["NIFTY"], d1, now=datetime.datetime(2026, 10, 10, 8))
    # the Oct contract was still live on the first sync date? it expired 13 Oct < today(19 Oct) so it is not activated
    assert out["inserted"] == 1 and out["in_universe"] == 2
    day2 = sm.parse_csv_master(csv_row("NSE:NIFTY26NOV25500CE", "NIFTY", EPOCH, 25500, "CE"), COLS)
    out2 = sm.sync_contracts(repo, day2, ["NIFTY"], d1, now=datetime.datetime(2026, 10, 19, 8))
    assert out2["updated"] == 1 and out2["inserted"] == 0
    c = repo.get_contracts()[0]
    assert c.fyers_symbol == "NSE:NIFTY26NOV25500CE" and c.status == "ACTIVE"


def test_exchange_name_comes_from_the_symbol_prefix_not_the_numeric_code_column():
    """Regression: the real master's exchange column holds the code '10', which was stored as the exchange."""
    r = [""] * 17
    r[0], r[3], r[4], r[8], r[9], r[10], r[13], r[15], r[16] = "1", 75, "0.05", EPOCH, "NSE:NIFTY26NOVFUT", "10", "NIFTY", -1, "XX"
    rep = sm.parse_csv_master(",".join(map(str, r)), COLS)
    assert rep.contracts[0].exchange == "NSE"


def test_migration_006_repairs_rows_that_stored_the_numeric_exchange_code(clean_fno):
    from sqlalchemy import text
    from model.fno import migrations
    repo = FnoRepository(clean_fno)
    repo.upsert_contracts([sm.parse_csv_master(csv_row("NSE:NIFTY26NOVFUT", "NIFTY", EPOCH, -1, "XX"), COLS).contracts[0]])
    with clean_fno.begin() as c:
        c.execute(text("UPDATE fno_instruments SET exchange='10'"))
    migrations.apply_all(clean_fno)
    with clean_fno.connect() as c:
        assert c.execute(text("SELECT exchange FROM fno_instruments")).scalar() == "NSE"
    repo.upsert_contracts(sm.parse_csv_master(csv_row("NSE:NIFTY26NOVFUT", "NIFTY", EPOCH, -1, "XX"), COLS).contracts)
