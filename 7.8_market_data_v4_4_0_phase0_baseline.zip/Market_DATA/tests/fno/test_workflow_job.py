"""Optional persisted workflow resume check on the disposable MySQL fixture."""
from model.fno.job_store import FnoJobStore


def test_workflow_job_survives_claim_and_explicit_resume(clean_fno):
    store=FnoJobStore(clean_fno)
    params={'from':'2026-10-16','to':'2026-10-16','contract_ids':[7],
            'workflow':{'version':1,'segment':'FNO','targets':[{'contract_id':7,'symbol':'NSE:TEST'}]}}
    jid=store.submit('WORKFLOW',params)
    job=store.claim_next(['WORKFLOW'])
    assert job['id']==jid and job['params']==params
    progress={'version':1,'stage':'FETCH','ready':False}
    store.progress(jid,progress)
    assert store.get(jid)['result']==progress and store.get(jid)['heartbeat_at'] is not None
    store.finish(jid,'PARTIAL',result={'version':1,'stage':'BLOCKED','ready':False})
    resumed=store.resume(jid)
    assert store.get(resumed)['params']==params and store.get(resumed)['resumed_from']==jid
