"""Repository behaviour on a real MySQL-protocol server: write policy, checkpoints, separation of admin actions."""
import datetime
from decimal import Decimal

import pytest
from sqlalchemy import text

from model.fno.repository import FnoRepository
from model.fno.errors import IsolationError
from tests_support import sample_contract, make_candle

D = lambda n: datetime.date(2026, 10, n)


@pytest.fixture()
def repo(clean_fno):
    return FnoRepository(clean_fno)


@pytest.fixture()
def cid(repo):
    return repo.upsert_contract(sample_contract())


def row(engine, cid, minute=0, tf="1m"):
    ts = datetime.datetime(2026, 10, 19, 9, 15) + datetime.timedelta(minutes=minute)
    with engine.connect() as c:
        return c.execute(text("SELECT open,high,low,close,volume,oi,iv,delta,status FROM fno_candles "
                              "WHERE contract_id=:c AND timeframe=:t AND candle_timestamp=:ts"),
                         {"c": cid, "t": tf, "ts": ts}).fetchone()


def test_repository_rejects_foreign_engine():
    from sqlalchemy import create_engine
    with pytest.raises(IsolationError):
        FnoRepository(create_engine("sqlite://"))


# ----------------------------------------------------------------- contracts
def test_contract_upsert_keeps_first_seen_and_refreshes_last_seen(repo, clean_fno):
    t1, t2 = datetime.datetime(2026, 10, 1, 9, 0), datetime.datetime(2026, 10, 5, 9, 0)
    repo.upsert_contracts([sample_contract()], seen_at=t1)
    out = repo.upsert_contracts([sample_contract(lot_size=75)], seen_at=t2)
    assert out == {"inserted": 0, "updated": 1}
    with clean_fno.connect() as c:
        first, last = c.execute(text("SELECT first_seen_at,last_seen_at FROM fno_instruments")).fetchone()
    assert first == t1 and last == t2


def test_option_requires_strike_and_type_but_future_does_not(repo):
    repo.upsert_contract(sample_contract(symbol="NSE:NIFTY26NOVFUT", category="FUTURES"))
    bad = sample_contract(symbol="NSE:BAD")
    bad.strike = None
    with pytest.raises(Exception):
        repo.upsert_contracts([bad])


def test_mark_expired_needs_missing_from_sync_and_past_expiry(repo):
    old = sample_contract(symbol="NSE:NIFTY26SEP25000CE", expiry=D(1), strike=Decimal("25000"))
    keep_seen = sample_contract(symbol="NSE:NIFTY26SEP25100CE", expiry=D(1), strike=Decimal("25100"))
    future = sample_contract(symbol="NSE:NIFTY26DEC25000CE", expiry=datetime.date(2026, 12, 31))
    repo.upsert_contracts([old, keep_seen, future], seen_at=datetime.datetime(2026, 10, 1))
    sync_start = datetime.datetime(2026, 10, 19, 8, 0)
    repo.upsert_contracts([keep_seen, future], seen_at=sync_start)           # `old` is absent from today's master
    assert repo.mark_expired(D(19), sync_start) == 1
    st = {c.fyers_symbol: c.status for c in repo.get_contracts()}
    assert st["NSE:NIFTY26SEP25000CE"] == "EXPIRED"
    assert st["NSE:NIFTY26SEP25100CE"] == "ACTIVE" and st["NSE:NIFTY26DEC25000CE"] == "ACTIVE"
    assert len(repo.get_contracts()) == 3                                     # expired rows are kept


# ------------------------------------------------------------- write policy
def test_insert_then_identical_rewrite_is_a_counted_duplicate(repo, cid, clean_fno):
    assert repo.upsert_candles([make_candle(cid, 0), make_candle(cid, 1)]).inserted == 2
    r = repo.upsert_candles([make_candle(cid, 0), make_candle(cid, 1)])
    assert (r.inserted, r.duplicate, r.conflicts, r.filled) == (0, 2, 0, 0)


def test_closed_ohlcv_is_never_overwritten_conflict_counted_and_reported(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0, o="100", h="101", l="99", c="100.5", v=10)])
    r = repo.upsert_candles([make_candle(cid, 0, o="100", h="150", l="99", c="120", v=99, oi=500)])
    assert r.conflicts == 1 and r.inserted == 0 and r.filled == 0
    assert r.conflict_samples and r.conflict_samples[0]["stored"][1] == "101.0000"
    stored = row(clean_fno, cid, 0)
    assert (stored[1], stored[3], stored[4]) == (Decimal("101.0000"), Decimal("100.5000"), 10)
    assert stored[5] is None                      # nothing from a conflicting row is applied, not even oi


def test_null_columns_are_filled_but_existing_values_are_not_replaced(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0)])
    r = repo.upsert_candles([make_candle(cid, 0, oi=1200, iv=Decimal("0.18"), delta=Decimal("0.5"))])
    assert r.filled == 1 and r.conflicts == 0
    s = row(clean_fno, cid, 0)
    assert s[5] == 1200 and s[6] == Decimal("0.180000") and s[7] == Decimal("0.50000000")
    r2 = repo.upsert_candles([make_candle(cid, 0, oi=9999, iv=Decimal("0.99"))])      # values already present
    assert (r2.filled, r2.duplicate) == (0, 1)
    assert row(clean_fno, cid, 0)[5] == 1200


def test_unknown_stays_null_never_zero(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0)])
    s = row(clean_fno, cid, 0)
    assert s[5] is None and s[6] is None and s[7] is None


def test_open_candle_is_updated_then_closed_and_closed_is_final(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0, h="101", c="100.5", v=5, status="OPEN")])
    r = repo.upsert_candles([make_candle(cid, 0, h="102", c="101.5", v=8, status="OPEN")])
    assert r.filled == 1
    assert row(clean_fno, cid, 0)[1] == Decimal("102.0000")
    r = repo.upsert_candles([make_candle(cid, 0, h="103", c="102", v=12, status="CLOSED")])
    s = row(clean_fno, cid, 0)
    assert r.filled == 1 and s[8] == "CLOSED" and s[1] == Decimal("103.0000") and s[4] == 12
    r = repo.upsert_candles([make_candle(cid, 0, h="999", c="1", v=1, status="OPEN")])   # late OPEN after CLOSED
    s = row(clean_fno, cid, 0)
    assert s[8] == "CLOSED" and s[1] == Decimal("103.0000")
    assert (r.conflicts, r.inserted, r.filled) == (1, 0, 0)    # reported, never applied


def test_sql_level_policy_holds_even_if_python_check_is_bypassed(repo, cid, clean_fno):
    """Defence in depth: the ON DUPLICATE KEY UPDATE itself must not overwrite a CLOSED candle."""
    from model.fno.repository import _UPSERT_SQL, _row_values
    repo.upsert_candles([make_candle(cid, 0, h="101", v=10)])
    forged = _row_values(make_candle(cid, 0, h="555", v=777, oi=42))
    with clean_fno.begin() as c:
        c.execute(_UPSERT_SQL, [forged])
    s = row(clean_fno, cid, 0)
    assert s[1] == Decimal("101.0000") and s[4] == 10 and s[5] is None  # conflicting row cannot fill optional fields


def test_duplicates_inside_one_batch_are_counted_once(repo, cid):
    r = repo.upsert_candles([make_candle(cid, 0), make_candle(cid, 0), make_candle(cid, 1)])
    assert (r.inserted, r.duplicate) == (2, 1)


def test_verify_candles_present_detects_a_missing_row(repo, cid, clean_fno):
    cs = [make_candle(cid, 0), make_candle(cid, 1)]
    repo.upsert_candles(cs)
    assert repo.verify_candles_present(cs)
    with clean_fno.begin() as c:
        c.execute(text("DELETE FROM fno_candles WHERE candle_timestamp = '2026-10-19 09:16:00'"))
    assert not repo.verify_candles_present(cs)


# --------------------------------------------------------------- checkpoints
def test_checkpoint_ranges_merge_in_the_database(repo, cid, clean_fno):
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(1), D(5), "VERIFIED")
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(6), D(9), "VERIFIED")
    assert repo.get_checkpoint_ranges(cid, "HISTORICAL", "1m") == [(D(1), D(9), "VERIFIED")]
    with clean_fno.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM fno_checkpoint_ranges")).scalar() == 1


def test_a_max_timestamp_alone_never_implies_completeness(repo, cid):
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(1), D(2), "VERIFIED")
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(8), D(9), "VERIFIED")
    assert repo.missing_ranges(cid, "HISTORICAL", "1m", D(1), D(9)) == [(D(3), D(7))]


def test_failed_increments_retry_and_never_downgrades_verified(repo, cid, clean_fno):
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(1), D(3), "VERIFIED")
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(2), D(6), "FAILED", error="boom")
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(4), D(6), "FAILED", error="boom again")
    with clean_fno.connect() as c:
        rows = c.execute(text("SELECT range_from,range_to,status,retry_count,last_error FROM fno_checkpoint_ranges "
                              "ORDER BY range_from")).fetchall()
    assert rows[0][:3] == (D(1), D(3), "VERIFIED")
    assert rows[1][:3] == (D(4), D(6), "FAILED") and rows[1][3] == 2 and rows[1][4] == "boom again"


def test_reset_checkpoints_never_deletes_candles(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0)])
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(19), D(19), "VERIFIED")
    assert repo.count_checkpoint_ranges([cid]) == 1                       # preview
    assert repo.reset_checkpoints([cid]) == 1
    assert repo.count_checkpoint_ranges([cid]) == 0
    assert repo.count_candles(cid, "1m", datetime.datetime(2026, 10, 19), datetime.datetime(2026, 10, 20)) == 1


def test_delete_candles_never_resets_checkpoints(repo, cid):
    repo.upsert_candles([make_candle(cid, 0), make_candle(cid, 1)])
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(19), D(19), "VERIFIED")
    assert repo.count_candles_for_delete([cid], "1m") == 2                # preview
    assert repo.delete_candles([cid], "1m") == 2
    assert repo.get_checkpoint_ranges(cid, "HISTORICAL", "1m") == [(D(19), D(19), "VERIFIED")]


def test_empty_selection_deletes_nothing(repo, cid):
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", D(1), D(2), "VERIFIED")
    assert repo.reset_checkpoints([]) == 0 and repo.delete_candles([]) == 0
    assert repo.count_checkpoint_ranges([cid]) == 1


# ------------------------------------------------------------ harvest state
def test_harvest_queue_orders_soonest_expiry_first(repo):
    ids = []
    for sym, exp in (("NSE:A", D(30)), ("NSE:B", D(22)), ("NSE:C", D(26))):
        i = repo.upsert_contract(sample_contract(symbol=sym, expiry=exp)); ids.append((i, exp))
    for i, exp in ids:
        repo.upsert_harvest_state(i, exp, (exp - D(19)).days, "PENDING")
    assert [q[1] for q in repo.harvest_queue()] == ["NSE:B", "NSE:C", "NSE:A"]


# ----------------------------------------------------------------- manifest
def test_manifest_lifecycle(repo):
    repo.manifest_begin("candles/1m/underlying=N/expiry=2026-11-26/date=2026-10-19.parquet", "candles", "1m", "k", 5, 7)
    assert repo.manifest_get("candles/1m/underlying=N/expiry=2026-11-26/date=2026-10-19.parquet")["status"] == "WRITING"
    repo.manifest_verify("candles/1m/underlying=N/expiry=2026-11-26/date=2026-10-19.parquet",
                         datetime.datetime(2026, 10, 19, 9, 15), datetime.datetime(2026, 10, 19, 9, 20), 5, "ab" * 32)
    assert [m["status"] for m in repo.manifest_list(status="VERIFIED")] == ["VERIFIED"]


# --------------------------------------------- LIVE is provisional, HISTORICAL is authoritative
def test_history_supersedes_a_provisional_live_candle(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0, h="101", l="99.5", v=3, source="FYERS_LIVE")])
    r = repo.upsert_candles([make_candle(cid, 0, h="103", l="99", v=40, oi=777, source="FYERS_HISTORICAL")])
    assert (r.filled, r.conflicts, r.inserted) == (1, 0, 0)
    s = row(clean_fno, cid, 0)
    assert (s[1], s[2], s[4], s[5]) == (Decimal("103.0000"), Decimal("99.0000"), 40, 777)
    with clean_fno.connect() as c:
        assert c.execute(text("SELECT source FROM fno_candles")).scalar() == "FYERS_HISTORICAL"


def test_live_never_changes_stored_history_and_is_not_a_conflict(repo, cid, clean_fno):
    repo.upsert_candles([make_candle(cid, 0, h="103", v=40, source="FYERS_HISTORICAL")])
    r = repo.upsert_candles([make_candle(cid, 0, h="101", v=3, source="FYERS_LIVE")])
    assert (r.duplicate, r.conflicts, r.filled) == (1, 0, 0)
    assert row(clean_fno, cid, 0)[1] == Decimal("103.0000") and row(clean_fno, cid, 0)[4] == 40


def test_two_live_closed_candles_that_disagree_are_still_a_conflict(repo, cid):
    repo.upsert_candles([make_candle(cid, 0, h="101", source="FYERS_LIVE")])
    assert repo.upsert_candles([make_candle(cid, 0, h="150", source="FYERS_LIVE")]).conflicts == 1


def test_sql_level_precedence_holds_without_the_python_check(repo, cid, clean_fno):
    from model.fno.repository import _UPSERT_SQL, _row_values
    repo.upsert_candles([make_candle(cid, 0, h="103", v=40, source="FYERS_HISTORICAL")])
    with clean_fno.begin() as c:
        c.execute(_UPSERT_SQL, [_row_values(make_candle(cid, 0, h="999", v=1, source="FYERS_LIVE"))])
    assert row(clean_fno, cid, 0)[1] == Decimal("103.0000")


def test_superseding_live_counts_how_many_live_candles_history_actually_changed(repo, cid):
    repo.upsert_candles([make_candle(cid, 0, h="101", v=3, source="FYERS_LIVE"), make_candle(cid, 1, h="101", v=3, source="FYERS_LIVE")])
    hist = [make_candle(cid, 0, h="103", v=40, source="FYERS_HISTORICAL"),         # differs from live
            make_candle(cid, 1, h="101", v=3, source="FYERS_HISTORICAL")]          # identical to live
    r = repo.upsert_candles(hist)
    assert (r.filled, r.superseded_live, r.superseded_changed) == (2, 2, 1)


def test_live_error_is_measured_per_field_on_closed_live_candles_only(repo, cid):
    repo.upsert_candles([make_candle(cid, 0, h="101", v=3, source="FYERS_LIVE"),                        # high and volume differ
                         make_candle(cid, 1, o="100", h="101", l="99", c="100.5", v=10, source="FYERS_LIVE"),   # identical
                         make_candle(cid, 2, h="101", v=1, status="OPEN", source="FYERS_LIVE")])        # partial: not "error"
    hist = [make_candle(cid, 0, h="103", v=40, source="FYERS_HISTORICAL"), make_candle(cid, 1, source="FYERS_HISTORICAL"),
            make_candle(cid, 2, h="104", v=50, source="FYERS_HISTORICAL")]
    r = repo.upsert_candles(hist)
    assert (r.superseded_live, r.superseded_changed) == (2, 1)
    assert r.superseded_fields == {"high": 1, "volume": 1}
