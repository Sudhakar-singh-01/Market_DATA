import datetime, threading, time
import pytest
from sqlalchemy import text
from controller.fno_jobs import FnoJobRunner, JobOutcome
from model.fno.errors import DuplicateJobError, IsolationError
from model.fno.job_store import FnoJobStore, dedupe_key
from model.fno.models import IST


@pytest.fixture()
def store(clean_fno):
    return FnoJobStore(clean_fno)


def test_foreign_engine_rejected():
    from sqlalchemy import create_engine
    with pytest.raises(IsolationError):
        FnoJobStore(create_engine("sqlite://"))


def test_dedupe_key_is_order_independent():
    assert dedupe_key("H", {"a": 1, "b": [1, 2]}) == dedupe_key("H", {"b": [1, 2], "a": 1})
    assert dedupe_key("H", {"a": 1}) != dedupe_key("X", {"a": 1})


def test_duplicate_active_job_is_refused_but_allowed_after_it_finishes(store):
    a = store.submit("HARVEST", {"x": 1})
    with pytest.raises(DuplicateJobError) as e:
        store.submit("HARVEST", {"x": 1})
    assert e.value.job_id == a
    assert store.submit("HARVEST", {"x": 2})                      # different params -> fine
    store.claim_next(); store.finish(a, "SUCCESS")
    assert store.submit("HARVEST", {"x": 1}) != a                 # finished -> may run again


def test_claim_is_atomic_one_winner(store):
    store.submit("HARVEST", {"x": 1})
    wins = []
    def go():
        j = store.claim_next()
        if j: wins.append(j["id"])
    ts = [threading.Thread(target=go) for _ in range(6)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert len(wins) == 1


def test_state_transitions_and_counters(store):
    jid = store.submit("HARVEST", {"x": 1})
    assert store.get(jid)["state"] == "PENDING"
    j = store.claim_next(); assert j["state"] == "RUNNING" and j["started_at"] and j["heartbeat_at"]
    store.add_counters(jid, requests_made=3, rows_raw=100, rows_valid=98, rows_invalid=2)
    store.add_counters(jid, requests_made=1)
    store.finish(jid, "PARTIAL", error="one contract failed", result={"k": 1})
    g = store.get(jid)
    assert (g["state"], g["requests_made"], g["rows_raw"], g["rows_invalid"]) == ("PARTIAL", 4, 100, 2)
    assert g["result"] == {"k": 1} and g["finished_at"] and g["params"] == {"x": 1}
    with pytest.raises(ValueError):
        store.finish(jid, "RUNNING")
    with pytest.raises(ValueError):
        store.add_counters(jid, bogus=1)


def test_stale_running_job_becomes_interrupted_and_is_resumable(store, clean_fno):
    jid = store.submit("HARVEST", {"x": 1}); store.claim_next()
    with clean_fno.begin() as c:
        c.execute(text("UPDATE fno_ingestion_jobs SET heartbeat_at = :h WHERE id=:i"),
                  {"h": datetime.datetime.now(IST).replace(tzinfo=None) - datetime.timedelta(minutes=10), "i": jid})
    fresh = store.submit("HARVEST", {"x": 2}); store.claim_next()                 # heartbeat is current
    assert store.recover_interrupted(90) == [jid]
    assert store.get(jid)["state"] == "INTERRUPTED" and store.get(fresh)["state"] == "RUNNING"
    new = store.resume(jid)
    n = store.get(new)
    assert n["state"] == "PENDING" and n["resumed_from"] == jid and n["params"] == {"x": 1}
    with pytest.raises(ValueError):
        store.resume(fresh)                                                      # RUNNING cannot be resumed


def test_cancel_pending_immediately_and_running_after_current_contract(store):
    p = store.submit("HARVEST", {"x": 1})
    assert store.request_cancel(p) == "CANCELLED" and store.get(p)["state"] == "CANCELLED"
    r = store.submit("HARVEST", {"x": 2}); store.claim_next()
    assert store.request_cancel(r) == "CANCEL_REQUESTED" and store.cancel_requested(r)
    assert store.request_cancel(p) == "NOT_ACTIVE"


def test_runner_runs_handler_records_outcome_and_heartbeats(store):
    seen = {}
    def handler(h):
        seen["params"] = h.params; time.sleep(0.35); h.add(requests_made=2)
        return JobOutcome("SUCCESS", {"ok": True})
    jid = store.submit("HARVEST", {"x": 1})
    r = FnoJobRunner(store, {"HARVEST": handler}, heartbeat_seconds=0.1, stale_after_seconds=60)
    assert r.run_until_empty() == [jid]
    g = store.get(jid)
    assert g["state"] == "SUCCESS" and g["requests_made"] == 2 and seen["params"] == {"x": 1}
    assert g["heartbeat_at"] >= g["started_at"]


def test_runner_converts_crash_to_failed_with_message(store):
    def bad(h): raise RuntimeError("kaboom")
    jid = store.submit("HARVEST", {"x": 1})
    FnoJobRunner(store, {"HARVEST": bad}).run_until_empty()
    g = store.get(jid)
    assert g["state"] == "FAILED" and "kaboom" in g["error"]


def test_runner_honours_cancel_and_graceful_shutdown(store):
    def loops(h):
        for i in range(50):
            stop = h.stop_outcome({"done": i})
            if stop: return stop
            time.sleep(0.02)
        return JobOutcome("SUCCESS")
    a = store.submit("HARVEST", {"x": "cancel"})
    r = FnoJobRunner(store, {"HARVEST": loops}, heartbeat_seconds=0.1)
    t = threading.Thread(target=r.run_one); t.start(); time.sleep(0.1)
    store.request_cancel(a); t.join()
    assert store.get(a)["state"] == "CANCELLED"
    b = store.submit("HARVEST", {"x": "shutdown"})
    t = threading.Thread(target=r.run_one); t.start(); time.sleep(0.1)
    r.shutdown.set(); t.join()
    g = store.get(b)
    assert g["state"] == "INTERRUPTED" and store.resume(b)             # resumable after graceful stop


def test_runner_only_claims_job_types_it_handles(store):
    other = store.submit("SOMETHING_ELSE", {})
    assert FnoJobRunner(store, {"HARVEST": lambda h: JobOutcome("SUCCESS")}).run_until_empty() == []
    assert store.get(other)["state"] == "PENDING"
