"""P1: config, engine guard, migrations, ranges."""
import datetime
from pathlib import Path

import pytest
import yaml

from model.exceptions import ConfigurationError
from model.fno import config as fcfg, db as fdb, migrations, ranges
from model.fno.config import FnoDatabaseConfig, resolve_parquet_root, assert_within_fno_root
from model.fno.errors import IsolationError

PROJECT = Path(__file__).resolve().parents[2]


# ------------------------------------------------------------------ config
def test_shipped_settings_file_loads_and_is_conservative():
    s = fcfg.load_fno_settings()
    assert s.parquet_root == (PROJECT / "data" / "fno").resolve()
    assert s.rate_limits.per_second < 5          # probe: Standard plan allows 5 requests/second (-360 beyond that)
    assert s.rate_limits.per_minute <= 200 and s.rate_limits.per_day <= 100000
    assert -360 in s.history.rate_limit_codes
    assert s.history.oi_flag is True and s.chain.greeks is True       # both confirmed by the 2026-10-22 probe
    assert (s.session.open, s.session.last_minute) == (datetime.time(9, 15), datetime.time(15, 39))   # 385 candles/day, seen in real data
    assert s.expired_history_enabled is True and s.expired_history_max_age_days == 14   # attempt-and-learn policy (availability unknown)
    assert set(s.universe.underlyings) >= {"NIFTY", "BANKNIFTY"}


def test_fno_database_config_env_and_redaction():
    cfg = FnoDatabaseConfig.from_env({"FNO_DB_USER": "u", "FNO_DB_PASSWORD": "secret-pw"})
    assert cfg.name == "fno_market_data" and cfg.port == 3306
    assert "secret-pw" not in repr(cfg) and "secret-pw" not in str(cfg)
    with pytest.raises(ConfigurationError):
        FnoDatabaseConfig.from_env({"FNO_DB_PORT": "abc"})
    with pytest.raises(ConfigurationError):
        FnoDatabaseConfig.from_env({}).require_credentials()


@pytest.mark.parametrize("bad", ["data", "data/raw", "data/processed", "data/raw/fno", "data/processed/5m", ".", ""])
def test_parquet_root_overlapping_subsystem_a_is_refused(bad):
    with pytest.raises(ConfigurationError):
        resolve_parquet_root(bad, PROJECT)


def test_parquet_root_ok_and_relative_to_project(tmp_path):
    assert resolve_parquet_root("data/fno", tmp_path) == (tmp_path / "data" / "fno").resolve()
    assert resolve_parquet_root("fno_store", tmp_path) == (tmp_path / "fno_store").resolve()


def test_assert_within_fno_root(tmp_path):
    root = tmp_path / "fno"; root.mkdir()
    assert assert_within_fno_root(root / "candles" / "x.parquet", root)
    for outside in (root, tmp_path / "raw" / "x", root / ".." / "raw" / "x"):
        with pytest.raises(ConfigurationError):
            assert_within_fno_root(outside, root)


@pytest.mark.parametrize("mutate", [
    lambda r: r["rate_limits"].update(fno_reserve_fraction=1.0),
    lambda r: r["rate_limits"].update(per_second=0),
    lambda r: r["history"].update(max_days_per_request=0),
    lambda r: r["symbol_master"].update(format="xml"),
    lambda r: r["universe"].update(underlyings=[]),
    lambda r: r["jobs"].update(stale_after_seconds=1, heartbeat_seconds=5),
    lambda r: r["session"].update(last_minute="15:45"),         # last_minute must be before close
    lambda r: r["session"].update(open="16:00"),
    lambda r: r.pop("history"),
])
def test_invalid_settings_rejected(mutate):
    raw = yaml.safe_load((PROJECT / "config" / "fno_settings.yaml").read_text())
    mutate(raw)
    with pytest.raises(ConfigurationError):
        fcfg.parse_fno_settings(raw, PROJECT)


# --------------------------------------------------------- engine isolation
@pytest.mark.parametrize("fno,a", [("market_data", "market_data"), ("Market_Data", "market_data"), (" x ", "x")])
def test_factory_refuses_same_database_as_subsystem_a(fno, a):
    cfg = FnoDatabaseConfig("127.0.0.1", 3306, fno, "u", "p")
    with pytest.raises(IsolationError):
        fdb.get_fno_engine(cfg, a)


def test_factory_refuses_when_a_name_unknown_or_fno_name_empty():
    with pytest.raises(IsolationError):
        fdb.get_fno_engine(FnoDatabaseConfig("h", 1, "fno_market_data", "u", "p"), "")
    with pytest.raises(IsolationError):
        fdb.get_fno_engine(FnoDatabaseConfig("h", 1, "", "u", "p"), "market_data")


def test_factory_engine_is_marked_and_foreign_engine_is_not(fno_engine):
    from sqlalchemy import create_engine
    assert fdb.is_fno_engine(fno_engine)
    assert not fdb.is_fno_engine(create_engine("sqlite://"))


def test_migrations_refuse_non_factory_engine():
    from sqlalchemy import create_engine
    with pytest.raises(IsolationError):
        migrations.apply_all(create_engine("sqlite://"))


def test_migration_plan_lists_numbered_files_without_applying():
    names = [n for n, _ in migrations.plan()]
    assert names == sorted(names) and len(names) == 7 and names[0].startswith("001_")
    assert names[-1] == "007_audit_log.sql"


def test_split_statements_ignores_comments():
    assert migrations.split_statements("-- c;\nCREATE TABLE a (x INT); -- tail;\nCREATE TABLE b (y INT);") == \
        ["CREATE TABLE a (x INT)", "CREATE TABLE b (y INT)"]


def test_migrations_are_idempotent_and_create_all_ten_tables(fno_engine):
    from sqlalchemy import text
    migrations.apply_all(fno_engine)
    migrations.apply_all(fno_engine)
    with fno_engine.connect() as c:
        tables = {r[0] for r in c.execute(text("SHOW TABLES"))}
    assert tables >= {"fno_instruments", "fno_candles", "fno_option_chain_snapshots", "fno_checkpoint_ranges",
                      "fno_harvest_state", "fno_ingestion_jobs", "fno_aggregation_jobs",
                      "fno_data_quality_results", "fno_storage_manifest", "fno_audit_log"}
    assert all(t.startswith("fno_") for t in tables)     # nothing un-prefixed lives in the FNO DB


# ------------------------------------------------------------------ ranges
D = lambda n: datetime.date(2026, 10, n)


def test_ranges_merge_adjacent_and_overlapping():
    r = ranges.merge_ranges([(D(1), D(3), "VERIFIED"), (D(4), D(6), "VERIFIED"), (D(5), D(9), "VERIFIED"),
                             (D(12), D(13), "VERIFIED")])
    assert r == [(D(1), D(9), "VERIFIED"), (D(12), D(13), "VERIFIED")]


def test_failed_never_overwrites_verified_and_is_still_missing():
    r = ranges.apply_range([], D(1), D(8), "VERIFIED")
    r = ranges.apply_range(r, D(5), D(12), "FAILED")
    assert (D(1), D(8), "VERIFIED") in r and (D(9), D(12), "FAILED") in r
    assert ranges.missing_days(D(1), D(12), r) == [(D(9), D(12))]


def test_verified_overwrites_earlier_failed_and_no_data():
    r = ranges.apply_range([], D(1), D(10), "FAILED")
    r = ranges.apply_range(r, D(3), D(6), "NO_DATA")
    r = ranges.apply_range(r, D(1), D(10), "VERIFIED")
    assert r == [(D(1), D(10), "VERIFIED")]


def test_missing_days_splits_around_done_ranges():
    r = [(D(3), D(4), "VERIFIED"), (D(8), D(8), "NO_DATA")]
    assert ranges.missing_days(D(1), D(10), r) == [(D(1), D(2)), (D(5), D(7)), (D(9), D(10))]


def test_chunk_range_covers_exactly():
    ch = ranges.chunk_range(D(1), D(10), 4)
    assert ch == [(D(1), D(4)), (D(5), D(8)), (D(9), D(10))]
    with pytest.raises(ValueError):
        ranges.chunk_range(D(1), D(2), 0)
