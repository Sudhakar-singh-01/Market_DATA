"""Exercise MySQL identity, advisory locks and no-op plans on disposable fixtures."""
from model.database_catalog import DatabaseCatalog
from model.schema_management import SchemaManager
from sqlalchemy import text


def test_guarded_mysql_noop_schema_plan(fno_engine,tmp_path):
    service=SchemaManager(DatabaseCatalog({'FNO':lambda:fno_engine}),tmp_path/'journal')
    plan=service.preview('FNO',role='admin')
    assert plan['statements']==[]
    result=service.apply(plan,role='admin',confirmation='APPLY '+plan['database'],backup_acknowledged=True)
    assert result['status']=='SUCCESS' and result['completed']==0
    with fno_engine.connect() as conn:
        assert conn.execute(text('SELECT DATABASE()')).scalar()==plan['database']
