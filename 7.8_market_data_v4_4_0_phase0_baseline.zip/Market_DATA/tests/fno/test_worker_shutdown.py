"""No DB required: exercise shutdown ordering and interruption boundaries."""
import subprocess
import sys
import threading
from types import SimpleNamespace

from controller import worker_lifecycle as lifecycle
from controller.fno_jobs import FnoJobRunner, JobOutcome


class Store:
    def __init__(self):
        self.claims = 0
        self.finished = None
    def claim_next(self, kinds):
        self.claims += 1
        return {'id': 1, 'params': {}, 'job_type': 'TEST'}
    def cancel_requested(self, jid): return False
    def finish(self, jid, state, error, result): self.finished = state


def test_stopped_runner_does_not_claim():
    store = Store()
    runner = FnoJobRunner(store, {})
    runner.shutdown.set()
    assert runner.run_one() is None
    assert store.claims == 0


def test_stop_during_handler_cannot_report_success():
    store = Store()
    def handler(handle):
        handle._shutdown.set()
        return JobOutcome('SUCCESS')
    FnoJobRunner(store, {'TEST': handler}).run_one()
    assert store.finished == 'INTERRUPTED'


def test_stop_between_mysql_and_parquet_does_not_start_parquet():
    import pytest
    from controller.fno_historical import persist_chunk
    stop = threading.Event()
    class Repo:
        def upsert_candles(self, candles):
            stop.set()
            return SimpleNamespace()
        def verify_candles_present(self, candles): return True
        def fetch_candles(self, *args): return []
    class Parquet:
        def write_candles(self, *args, **kwargs):
            raise AssertionError('must not schedule storage during shutdown')
    item = SimpleNamespace(contract=SimpleNamespace(contract_id=1, underlying='X', expiry=None),range_from=None,range_to=None)
    ctx = SimpleNamespace(repo=Repo(),store=Parquet())
    with lifecycle.scope(stop), pytest.raises(lifecycle.WorkerInterrupted):
        persist_chunk(ctx,item,[],1)


def test_process_exit_signals_and_joins_before_executor_shutdown(tmp_path):
    marker = tmp_path / 'stopped'
    code = '''
import threading, time, sys
from concurrent.futures import ThreadPoolExecutor
from controller import worker_lifecycle as lifecycle
pool = ThreadPoolExecutor(1)
event = threading.Event()
ready = threading.Event()
def worker():
    ready.set()
    while not event.wait(.01):
        pool.submit(lambda: 1).result()
    pool.submit(lambda: 1).result()
    open(sys.argv[1], 'w').write('stopped before pool shutdown')
thread = threading.Thread(target=worker, daemon=True)
lifecycle.register(event, thread)
thread.start()
ready.wait()
'''
    result = subprocess.run([sys.executable, '-c', code, str(marker)], capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert not result.stderr
    assert marker.read_text() == 'stopped before pool shutdown'


def test_history_response_after_stop_never_reaches_storage():
    import datetime
    import pytest
    from model.fno.config import load_fno_settings
    from model.fno.history_client import FnoHistoryFetcher
    event = threading.Event()
    class Client:
        def history(self, data):
            event.set()
            return {'s': 'ok', 'candles': [[1, 2, 3]]}
    fetcher = FnoHistoryFetcher(Client(), load_fno_settings().history)
    with lifecycle.scope(event), pytest.raises(lifecycle.WorkerInterrupted):
        fetcher.fetch('NSE:X', datetime.date(2026, 1, 1), datetime.date(2026, 1, 1))


def test_shutdown_join_has_one_bounded_deadline():
    code = """
import threading, time
from controller import worker_lifecycle as lifecycle
event = threading.Event()
thread = threading.Thread(target=lambda: threading.Event().wait(60), daemon=True)
lifecycle.register(event, thread)
thread.start()
started = time.monotonic()
lifecycle.shutdown(timeout=.05)
assert event.is_set()
assert time.monotonic() - started < .5
"""
    result = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True, timeout=7)
    assert result.returncode == 0, result.stderr


def test_legacy_late_history_response_is_interrupted():
    import pytest
    from model.fyers.historical import _fetch_chunk
    event = threading.Event()
    class Client:
        def history(self, data):
            event.set()
            return {'s': 'ok', 'candles': [[1, 2, 3]]}
    with lifecycle.scope(event), pytest.raises(lifecycle.WorkerInterrupted):
        _fetch_chunk(Client(), 'NSE:X', '2026-01-01', '2026-01-01')


def test_legacy_manager_records_interrupted_and_refuses_new_work():
    import time
    import pytest
    from ui.job_manager import JobManager
    manager = JobManager()
    started = threading.Event()
    def work(job):
        started.set()
        manager._shutdown.wait(2)
    job = manager.submit('historical', 'test', work)
    assert started.wait(2)
    manager._shutdown.set()
    manager._worker.join(2)
    assert job.status == 'interrupted'
    assert manager.active() == []
    with pytest.raises(lifecycle.WorkerInterrupted):
        manager.submit('historical', 'late', work)


def test_composite_sink_stops_between_stores():
    import pytest
    from controller.sinks import CompositeCandleSink
    event = threading.Event()
    class First:
        def write_batch(self, rows):
            event.set()
            return rows
    class Second:
        def write_batch(self, rows):
            raise AssertionError('second storage write must not start')
    with lifecycle.scope(event), pytest.raises(lifecycle.WorkerInterrupted):
        CompositeCandleSink([First(), Second()]).write_batch([])


def test_stop_while_acquiring_rate_limit_prevents_request():
    import pytest
    from model.fyers.rate_limiter import RateLimitedClient
    event = threading.Event()
    class Limiter:
        def acquire(self, priority): event.set()
    class Client:
        def history(self, **kwargs): raise AssertionError('request started after stop')
    with lifecycle.scope(event), pytest.raises(lifecycle.WorkerInterrupted):
        RateLimitedClient(Client(), Limiter()).history(data={})
