"""
Shared fixtures for the FNO test-suite.

The suite needs a real MySQL-protocol server (MariaDB/MySQL) because the FNO
write policy uses INSERT ... ON DUPLICATE KEY UPDATE. It uses two scratch
databases, never real data:
    market_data_test       -- stands in for Subsystem A (seeded with A's schema)
    fno_market_data_test   -- the FNO database
If no server is reachable the DB-backed tests are SKIPPED with a clear reason
(and the run summary says so) -- they are never silently counted as passed.
Override with FNO_TEST_DB_HOST/PORT/USER/PASSWORD.
"""
import os
import re
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from model.fno.config import FnoDatabaseConfig  # noqa: E402
from model.fno import db as fno_db  # noqa: E402
from model.fno import migrations  # noqa: E402
from tests_support import a_fingerprint, tree_fingerprint  # noqa: E402,F401

A_DB = "market_data_test"
FNO_DB = "fno_market_data_test"
_H = os.getenv("FNO_TEST_DB_HOST", "127.0.0.1")
_P = int(os.getenv("FNO_TEST_DB_PORT", "3306"))
_U = os.getenv("FNO_TEST_DB_USER", "fnotest")
_W = os.getenv("FNO_TEST_DB_PASSWORD", "fnotest")

FNO_TABLES_DELETE_ORDER = [
    "fno_audit_log",
    "fno_option_chain_snapshots", "fno_candles", "fno_checkpoint_ranges", "fno_harvest_state",
    "fno_ingestion_jobs", "fno_aggregation_jobs", "fno_data_quality_results", "fno_storage_manifest",
    "fno_instruments",
]


@pytest.fixture(scope="session")
def fno_cfg():
    return FnoDatabaseConfig(host=_H, port=_P, name=FNO_DB, user=_U, password=_W)


@pytest.fixture(scope="session")
def fno_engine(fno_cfg):
    fno_db.reset_engine_cache()
    try:
        engine = fno_db.get_fno_engine(fno_cfg, A_DB)
    except Exception as exc:  # no server -> skip, loudly
        pytest.skip(f"No MySQL/MariaDB test server reachable ({type(exc).__name__}); DB-backed FNO tests NOT run.")
    migrations.apply_all(engine)
    yield engine
    fno_db.reset_engine_cache()


@pytest.fixture()
def clean_fno(fno_engine):
    def wipe():
        with fno_engine.begin() as conn:
            conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
            for t in FNO_TABLES_DELETE_ORDER:
                conn.execute(text(f"DELETE FROM {t}"))
            conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))
    wipe()
    yield fno_engine
    wipe()


def _a_engine():
    url = f"mysql+pymysql://{_U}:{_W}@{_H}:{_P}/{A_DB}"
    return create_engine(url)


@pytest.fixture(scope="session")
def a_engine(fno_engine):
    """Subsystem A stand-in: A's real schema.sql applied to market_data_test, then seeded."""
    engine = _a_engine()
    sql = (ROOT / "database" / "schema.sql").read_text(encoding="utf-8")
    sql = re.sub(r"--[^\n]*", "", sql)
    stmts = [s.strip() for s in sql.split(";") if s.strip()]
    stmts = [s for s in stmts if not s.upper().startswith(("CREATE DATABASE", "USE "))]
    with engine.begin() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
        for t in ("candles", "checkpoints", "ingestion_jobs", "audit_log", "error_logs", "instruments"):
            conn.execute(text(f"DROP TABLE IF EXISTS {t}"))
        conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))
        for s in stmts:
            conn.execute(text(s))
        conn.execute(text("INSERT INTO instruments (internal_name, fyers_symbol, exchange, instrument_type, category) "
                          "VALUES ('SBIN','NSE:SBIN-EQ','NSE','EQ','stock'),('NIFTY50','NSE:NIFTY50-INDEX','NSE','INDEX','index')"))
        conn.execute(text("INSERT INTO candles (instrument_id,timeframe,candle_timestamp,open,high,low,close,volume,source,status) "
                          "VALUES (1,'1m','2026-10-16 09:15:00',100,101,99,100.5,1000,'FYERS_HISTORICAL','CLOSED'),"
                          "(1,'1m','2026-10-16 09:16:00',100.5,102,100,101,900,'FYERS_HISTORICAL','CLOSED')"))
    yield engine
    engine.dispose()
