import dataclasses
import datetime
import threading
from decimal import Decimal

import pytest
from sqlalchemy import text

from controller import fno_chain as fc
from model.fno import chain as ch
from model.fno.config import load_fno_settings
from model.fno.errors import TokenExpiredError
from model.fno.models import IST
from model.fno.parquet_store import FnoParquetStore
from model.fno.repository import FnoRepository
from tests_support import sample_contract

S = load_fno_settings()
EXP, EXP2 = datetime.date(2026, 10, 27), datetime.date(2026, 11, 3)
EP = lambda d: str(int(datetime.datetime(d.year, d.month, d.day, 9, 0, tzinfo=datetime.timezone.utc).timestamp()))


def underlying_row():                                     # shaped exactly like the probe's first entry
    return {"ask": 0, "bid": 0, "description": "NIFTY50-INDEX", "ex_symbol": "NIFTY", "exchange": "NSE", "fp": 22628.9, "fpch": -114.4,
            "fpchp": -0.5, "fyToken": "x", "ltp": 22618.5, "ltpch": -192.85, "ltpchp": -0.85, "option_type": "", "strike_price": -1,
            "symbol": "NSE:NIFTY50-INDEX"}


def opt(sym, strike, side, ltp=66.4, bid=66.5, ask=66.7, oi=1944280, greeks=True, volume=11760450):
    e = {"ask": ask, "bid": bid, "fyToken": "x", "ltp": ltp, "ltpch": 23.3, "ltpchp": 54.06, "oi": oi, "oich": 491140, "oichp": 33.8,
         "option_type": side, "prev_oi": 1453140, "strike_price": strike, "symbol": sym, "volume": volume}
    if greeks:
        e["greeks"] = {"delta": -0.26 if side == "PE" else 0.74, "gamma": 0.0007, "theta": -13.27, "vega": 8.7, "iv": 15.96}
    return e


def response(rows, expiry_data=None):
    return {"s": "ok", "code": 200, "message": "", "data": {"optionsChain": [underlying_row()] + rows, "callOi": 1, "putOi": 2,
            "indiavixData": {}, "expiryData": expiry_data if expiry_data is not None else []}}


class FakeChainClient:
    def __init__(self, responder):
        self.responder, self.calls = responder, []
    def optionchain(self, data=None):
        self.calls.append(dict(data)); return self.responder(data, len(self.calls))


# -------------------------------------------------------------------- parsing
def test_parse_separates_the_underlying_row_and_reads_confirmed_fields():
    p = ch.parse_chain(response([opt("NSE:NIFTY26OCT22350PE", 22350, "PE"), opt("NSE:NIFTY26OCT22350CE", 22350, "CE", greeks=False)]))
    assert p.underlying_ltp == Decimal("22618.5000") and len(p.rows) == 2
    pe, ce = p.rows
    assert (pe["side"], pe["strike"], pe["oi"], pe["oi_change"], pe["volume"]) == ("PE", Decimal("22350.0000"), 1944280, 491140, 11760450)
    assert pe["iv"] == Decimal("15.960000") and pe["delta"] == Decimal("-0.26000000")           # iv stays in percent
    assert ce["iv"] is None and ce["delta"] is None                                              # no greeks -> NULL, not 0


def test_zero_quotes_are_null_never_zero_and_garbage_is_counted():
    p = ch.parse_chain(response([opt("NSE:A", 1, "CE", ltp=0, bid=0, ask=0, oi=0)] + ["junk", {"option_type": "XX", "symbol": "NSE:B"}]))
    r = p.rows[0]
    assert (r["ltp"], r["bid"], r["ask"]) == (None, None, None) and r["oi"] == 0                # OI 0 is a real value
    assert p.skipped == {"malformed_entry": 1, "unclassifiable_entry": 1}


def test_expiry_data_parsing_is_tolerant():
    items = [{"date": "03-11-2026", "expiry": EP(EXP2)}, {"date": "27-10-2026", "expiry": EP(EXP)}, "x", {"foo": 1}]
    assert [d for d, _ in ch.parse_expiry_data(items)] == [EXP, EXP2]
    assert ch.parse_expiry_data(None) == [] and ch.parse_expiry_data("garbage") == []


# ------------------------------------------------------------------ snapshots
@pytest.fixture()
def env(clean_fno, tmp_path):
    repo = FnoRepository(clean_fno)
    repo.upsert_contracts([sample_contract("NSE:NIFTY26OCT22350PE", expiry=EXP, strike=Decimal("22350"), option_type="PE"),
                           sample_contract("NSE:NIFTY26OCT22350CE", expiry=EXP, strike=Decimal("22350")),
                           sample_contract("NSE:NIFTY26NOV22350CE", expiry=EXP2, strike=Decimal("22350"))])
    class E: pass
    e = E(); e.repo, e.engine = repo, clean_fno
    e.store = FnoParquetStore(tmp_path / "fno", repo)
    e.clock = lambda: datetime.datetime(2026, 10, 22, 10, 15, 30, tzinfo=IST)
    e.rows = [opt("NSE:NIFTY26OCT22350PE", 22350, "PE"), opt("NSE:NIFTY26OCT22350CE", 22350, "CE", oi=186355)]
    return e


def test_snapshot_stamps_our_clock_stores_mysql_and_parquet_and_maps_by_real_symbol(env):
    client = FakeChainClient(lambda d, n: response(env.rows))
    r = fc.snapshot_once(env.repo, env.store, client, S, "NIFTY", clock=env.clock)
    assert (r.rows_received, r.rows_stored, r.unknown_symbols, r.error) == (2, 2, 0, None)
    assert r.captured_at == datetime.datetime(2026, 10, 22, 10, 15, 30)                       # our clock, IST wall-clock
    p = client.calls[0]
    assert p == {"symbol": "NSE:NIFTY50-INDEX", "strikecount": 50, "timestamp": "", "greeks": "1"}
    rows = env.repo.chain_snapshot_rows(r.batch_id)
    assert [x[2] for x in rows] == ["CE", "PE"] and rows[0][7] == 186355 and rows[1][10] == Decimal("-0.26000000")
    assert all(x[11] == r.captured_at and x[12] == EXP for x in rows)
    rel = "option_chain/underlying=NIFTY/date=2026-10-22.parquet"
    assert env.store.list_candle_files() == []                                                # chain files are not candle files
    m = env.repo.manifest_get(rel)
    assert m["status"] == "VERIFIED" and m["row_count"] == 2 and m["partition_key"] == "underlying=NIFTY/date=2026-10-22"


def test_unknown_symbols_are_skipped_and_counted_never_inserted(env):
    env.rows.append(opt("NSE:NIFTY26OCT99999CE", 99999, "CE"))
    r = fc.snapshot_once(env.repo, env.store, FakeChainClient(lambda d, n: response(env.rows)), S, "NIFTY", clock=env.clock)
    assert (r.rows_received, r.rows_stored, r.unknown_symbols) == (3, 2, 1)
    with env.engine.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM fno_instruments WHERE fyers_symbol LIKE '%99999%'")).scalar() == 0


def test_two_snapshots_are_separate_batches_and_the_parquet_day_file_accumulates(env):
    client = FakeChainClient(lambda d, n: response(env.rows))
    a = fc.snapshot_once(env.repo, env.store, client, S, "NIFTY", clock=env.clock)
    b = fc.snapshot_once(env.repo, env.store, client, S, "NIFTY", clock=lambda: env.clock() + datetime.timedelta(minutes=5))
    assert a.batch_id != b.batch_id
    df = env.store.abs_path("option_chain/underlying=NIFTY/date=2026-10-22.parquet")
    import pandas as pd
    assert len(pd.read_parquet(df)) == 4 and env.repo.manifest_get("option_chain/underlying=NIFTY/date=2026-10-22.parquet")["row_count"] == 4
    with env.engine.connect() as c:
        assert c.execute(text("SELECT COUNT(DISTINCT captured_at) FROM fno_option_chain_snapshots")).scalar() == 2


def test_greeks_flag_follows_config(env):
    client = FakeChainClient(lambda d, n: response(env.rows))
    s = dataclasses.replace(S, chain=dataclasses.replace(S.chain, greeks=False))
    fc.snapshot_once(env.repo, None, client, s, "NIFTY", clock=env.clock)
    assert "greeks" not in client.calls[0]


def test_failures_are_reported_clearly(env):
    tok = FakeChainClient(lambda d, n: {"s": "error", "code": -16, "message": "Could not authenticate"})
    with pytest.raises(TokenExpiredError):
        fc.snapshot_once(env.repo, None, tok, S, "NIFTY", clock=env.clock)
    bad = FakeChainClient(lambda d, n: {"s": "error", "code": -99, "message": "weird"})
    assert "chain request failed" in fc.snapshot_once(env.repo, None, bad, S, "NIFTY", clock=env.clock).error
    empty = FakeChainClient(lambda d, n: response([]))
    assert "no rows" in fc.snapshot_once(env.repo, None, empty, S, "NIFTY", clock=env.clock).error
    assert "no spot symbol" in fc.snapshot_once(env.repo, None, empty, S, "UNKNOWN", clock=env.clock).error


def test_plan_limit_minus_360_is_retried_with_backoff(env):
    plan = {"s": "error", "code": -360, "message": "You've reached the Standard plan limit of 5 requests/second."}
    client = FakeChainClient(lambda d, n: plan if n <= 2 else response(env.rows))
    sleeps = []
    r = fc.snapshot_once(env.repo, None, client, S, "NIFTY", clock=env.clock, sleep=sleeps.append)
    assert r.rows_stored == 2 and len(client.calls) == 3 and len(sleeps) == 2


def test_snapshot_all_uses_expiry_data_timestamps_for_further_expiries(env):
    exp_data = [{"date": "27-10-2026", "expiry": EP(EXP)}, {"date": "03-11-2026", "expiry": EP(EXP2)}]
    def responder(d, n):
        if d["timestamp"] == "":
            return response(env.rows, exp_data)
        return response([opt("NSE:NIFTY26NOV22350CE", 22350, "CE")], exp_data)
    client = FakeChainClient(responder)
    s = dataclasses.replace(S, universe=dataclasses.replace(S.universe, expiries_ahead=2))
    res = fc.snapshot_all(env.repo, env.store, client, s, underlyings=["NIFTY"], clock=env.clock)
    assert [c["timestamp"] for c in client.calls] == ["", EP(EXP2)]
    assert [r.chain_expiry for r in res] == [EXP, EXP2] and all(r.rows_stored for r in res)


def test_snapshot_all_without_expiry_data_captures_only_the_nearest_expiry(env):
    client = FakeChainClient(lambda d, n: response(env.rows, None))
    s = dataclasses.replace(S, universe=dataclasses.replace(S.universe, expiries_ahead=3))
    assert len(fc.snapshot_all(env.repo, None, client, s, underlyings=["NIFTY"], clock=env.clock)) == 1


def test_token_expiry_stops_the_whole_round(env):
    client = FakeChainClient(lambda d, n: {"s": "error", "code": -16, "message": "expired"})
    res = fc.snapshot_all(env.repo, None, client, S, underlyings=["NIFTY", "BANKNIFTY"], clock=env.clock)
    assert len(res) == 1 and "access token" in res[0].error and len(client.calls) == 1


# ------------------------------------------------------------------ scheduling
def test_loop_snapshots_only_inside_market_hours_and_respects_the_interval(env):
    client = FakeChainClient(lambda d, n: response(env.rows))
    s = dataclasses.replace(S, universe=dataclasses.replace(S.universe, underlyings=("NIFTY",), expiries_ahead=1),
                            chain=dataclasses.replace(S.chain, interval_minutes=5))
    now = {"t": datetime.datetime(2026, 10, 22, 8, 0, tzinfo=IST)}                           # Thursday, before the open
    stop = threading.Event()
    class FakeStop:
        def is_set(self): return stop.is_set()
        def wait(self, secs):
            now["t"] += datetime.timedelta(minutes=1)
            if now["t"] > datetime.datetime(2026, 10, 22, 17, 0, tzinfo=IST): stop.set()
    taken = fc.run_loop(env.repo, None, client, s, FakeStop(), clock=lambda: now["t"])
    with env.engine.connect() as c:
        stamps = [r[0] for r in c.execute(text("SELECT DISTINCT captured_at FROM fno_option_chain_snapshots ORDER BY 1"))]
    assert taken == len(stamps) and stamps[0] >= datetime.datetime(2026, 10, 22, 9, 15)
    assert stamps[-1] <= datetime.datetime(2026, 10, 22, 15, 40)
    assert all((b - a) >= datetime.timedelta(minutes=5) for a, b in zip(stamps, stamps[1:]))
    assert 70 <= taken <= 80                                                                 # ~(15:40-09:15)/5 = 77
