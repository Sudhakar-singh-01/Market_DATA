"""Optional real-MySQL export/literal checks against disposable test fixtures."""
import decimal
from model.backup_service import BackupService,sql_literal
from model.database_catalog import DatabaseCatalog


def test_mysql_dump_and_literal_fidelity(fno_engine,tmp_path):
    service=BackupService(DatabaseCatalog({'FNO':lambda:fno_engine}),tmp_path/'backup',tmp_path/'recovery')
    path=tmp_path/'database.sql'
    counts=service._dump_database(fno_engine,path)
    sql=path.read_text()
    assert 'CREATE TABLE' in sql and 'SET FOREIGN_KEY_CHECKS=1;' in sql
    assert "time_zone='+00:00'" in sql
    assert 'fno_instruments' in counts
    with fno_engine.connect() as conn:
        for value in [None,decimal.Decimal('123456.12345678'),"quote' slash\\ Unicode नमस्ते",b'\x00\xff']:
            got=conn.exec_driver_sql('SELECT '+sql_literal(value)).scalar()
            assert got==value
