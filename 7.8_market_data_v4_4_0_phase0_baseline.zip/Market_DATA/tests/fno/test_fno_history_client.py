import datetime
import pytest
from model.fno.config import load_fno_settings
from model.fno.errors import TokenExpiredError
from model.fno.history_client import FnoHistoryFetcher, TransientFetchError, classify_response, OK, NO_DATA, INVALID_SYMBOL, RATE_LIMIT, AUTH, ERROR

S = load_fno_settings().history
A, B = datetime.date(2026, 10, 1), datetime.date(2026, 10, 5)


class Client:
    def __init__(self, *responses):
        self.responses, self.calls = list(responses), []
    def history(self, data=None):
        self.calls.append(data)
        r = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
        if isinstance(r, Exception): raise r
        return r


def fetcher(*resp, settings=S):
    sleeps = []
    return FnoHistoryFetcher(Client(*resp), settings, sleep=sleeps.append), sleeps


@pytest.mark.parametrize("resp,kind", [
    ({"s": "ok", "candles": [[1, 1, 1, 1, 1, 1]]}, OK), ({"s": "ok", "candles": []}, NO_DATA),
    ({"s": "no_data"}, NO_DATA), ({"s": "error", "code": -300, "message": "Invalid symbol"}, INVALID_SYMBOL),
    ({"s": "error", "message": "invalid symbol provided"}, INVALID_SYMBOL),
    ({"s": "error", "code": 429, "message": "x"}, RATE_LIMIT),
    ({"s": "error", "code": -360, "message": "You've reached the Standard plan limit of 5 requests/second."}, RATE_LIMIT),
    ({"s": "error", "code": -1, "message": "plan limit of 5 requests/second"}, RATE_LIMIT), ({"s": "error", "message": "Rate limit exceeded"}, RATE_LIMIT),
    ({"s": "error", "code": -16, "message": "Could not authenticate"}, AUTH),
    ({"s": "error", "message": "Token expired"}, AUTH), ({"s": "error", "code": -99, "message": "weird"}, ERROR), ("junk", ERROR)])
def test_classification(resp, kind):
    assert classify_response(resp, S)[0] == kind


def test_payload_never_requests_continuous_series_and_oi_follows_the_config_flag():
    import dataclasses
    off = FnoHistoryFetcher(None, dataclasses.replace(S, oi_flag=False)).payload("NSE:X", A, B)
    on = FnoHistoryFetcher(None, dataclasses.replace(S, oi_flag=True)).payload("NSE:X", A, B)
    assert off["cont_flag"] == "0" and on["cont_flag"] == "0"              # real contract only, never stitched
    assert "oi_flag" not in off and on["oi_flag"] == "1"
    assert off["range_from"] == "2026-10-01" and off["symbol"] == "NSE:X"


def test_ok_and_no_data_return_without_retry():
    f, sl = fetcher({"s": "ok", "candles": [[1, 1, 1, 1, 1, 1]]})
    r = f.fetch("NSE:X", A, B); assert (r.status, r.requests, r.retries, len(r.rows)) == (OK, 1, 0, 1) and sl == []
    f, _ = fetcher({"s": "no_data"}); assert f.fetch("NSE:X", A, B).status == NO_DATA


def test_invalid_symbol_is_not_retried():
    f, sl = fetcher({"s": "error", "code": -300, "message": "Invalid symbol"})
    r = f.fetch("NSE:X", A, B)
    assert r.status == INVALID_SYMBOL and r.requests == 1 and sl == [] and r.code == -300


def test_429_retries_with_exponential_backoff_then_succeeds():
    f, sl = fetcher({"s": "error", "code": 429}, {"s": "error", "code": 429}, {"s": "ok", "candles": [[1, 1, 1, 1, 1, 1]]})
    r = f.fetch("NSE:X", A, B)
    assert r.status == OK and r.requests == 3 and r.retries == 2
    assert sl == [S.initial_backoff_seconds, S.initial_backoff_seconds * S.backoff_multiplier]


def test_network_errors_retry_then_raise_transient_when_exhausted():
    f, sl = fetcher(ConnectionError("down"))
    with pytest.raises(TransientFetchError):
        f.fetch("NSE:X", A, B)
    assert len(f.client.calls) == S.max_retries + 1 and len(sl) == S.max_retries
    f, _ = fetcher(TimeoutError("slow"), {"s": "no_data"})
    assert f.fetch("NSE:X", A, B).status == NO_DATA


def test_token_expiry_raises_immediately_with_clear_message_and_no_retry():
    f, sl = fetcher({"s": "error", "code": -16, "message": "Could not authenticate the user"})
    with pytest.raises(TokenExpiredError) as e:
        f.fetch("NSE:X", A, B)
    assert "model.fyers.auth" in str(e.value) and len(f.client.calls) == 1 and sl == []


def test_plan_limit_minus_360_is_retried_not_treated_as_a_permanent_error():
    plan = {"s": "error", "code": -360, "message": "You've reached the Standard plan limit of 5 requests/second."}
    f, sl = fetcher(plan, plan, {"s": "ok", "candles": [[1, 1, 1, 1, 1, 1]]})
    r = f.fetch("NSE:X", A, B)
    assert r.status == OK and r.retries == 2 and len(sl) == 2
