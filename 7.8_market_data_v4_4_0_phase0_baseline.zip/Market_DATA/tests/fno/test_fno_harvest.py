import dataclasses
import datetime
import threading
from decimal import Decimal

import pytest
from sqlalchemy import text

from controller import fno_historical as fh
from controller.fno_jobs import JobHandle, FnoJobRunner
from model.fno.config import load_fno_settings
from model.fno.history_client import FnoHistoryFetcher
from model.fno.job_store import FnoJobStore
from model.fno.models import IST
from model.fno.parquet_store import FnoParquetStore
from model.fno.repository import FnoRepository
from model.fyers.rate_limiter import DailyQuotaExhausted
from tests_support import sample_contract

D = lambda n: datetime.date(2026, 10, n)
EXP = datetime.date(2026, 10, 27)
NOW = datetime.datetime(2026, 10, 19, 16, 30, tzinfo=IST)           # Monday, after close + buffer
SETTINGS = load_fno_settings()
FUT, OPT = "NSE:NIFTY26OCTFUT", "NSE:NIFTY26OCT25500CE"


def rows_for(d_from, d_to, minutes=5, base=100.0):
    out, d = [], d_from
    while d <= d_to:
        if d.weekday() < 5:
            for m in range(minutes):
                ts = int(datetime.datetime.combine(d, datetime.time(9, 15 + m), tzinfo=IST).timestamp())
                out.append([ts, base, base + 1, base - 1, base + 0.5, 10 + m])
        d += datetime.timedelta(days=1)
    return out


class FakeFyers:
    """responder(symbol, payload, call_no) -> response dict or raises."""
    def __init__(self, responder):
        self.responder, self.calls = responder, []
    def history(self, data=None):
        self.calls.append(dict(data))
        return self.responder(data["symbol"], data, len(self.calls))

    def fno_historical_data(self,data=None):
        result=self.history(data)
        return {**result,'columns':['timestamp','open','high','low','close','volume']}

    def symbols_called(self):
        return [c["symbol"] for c in self.calls]


def ok_responder(sym, p, n):
    a, b = datetime.date.fromisoformat(p["range_from"]), datetime.date.fromisoformat(p["range_to"])
    return {"s": "ok", "candles": rows_for(a, b)}


@pytest.fixture()
def env(clean_fno, tmp_path):
    repo = FnoRepository(clean_fno)
    repo.upsert_contracts([sample_contract(FUT, category="FUTURES", expiry=EXP),
                           sample_contract(OPT, expiry=EXP)], seen_at=datetime.datetime(2026, 10, 14))
    class E: pass
    e = E()
    e.repo, e.engine, e.tmp = repo, clean_fno, tmp_path
    e.store = FnoParquetStore(tmp_path / "fno", repo)
    e.jobs = FnoJobStore(clean_fno)
    e.sleeps = []
    e.params = {"underlyings": ["NIFTY"], "from": "2026-10-15", "to": "2026-10-19", "atm": {"NIFTY": 25500},
                "expiries_ahead": 1, "strike_window": 0}
    e.settings = SETTINGS
    def make_ctx(responder=ok_responder, settings=None, with_parquet=True):
        e.client = FakeFyers(responder)
        s = settings or e.settings
        return fh.HarvestContext(repo, FnoHistoryFetcher(e.client, s.history, sleep=e.sleeps.append),
                                 e.store if with_parquet else None, s, clock=lambda: NOW)
    e.ctx = make_ctx
    def run(ctx, params=None, shutdown=None):
        jid = e.jobs.submit(fh.JOB_TYPE, params or e.params)
        job = e.jobs.claim_next()
        out = fh.run_harvest(JobHandle(e.jobs, job, shutdown or threading.Event()), ctx)
        e.jobs.finish(jid, out.state, out.error, out.result)
        return out, e.jobs.get(jid)
    e.run = run
    e.cid = lambda sym: repo.get_contract_id(sym)
    e.count = lambda sym: repo.count_candles(repo.get_contract_id(sym), "1m", datetime.datetime(2026, 10, 1), datetime.datetime(2026, 10, 31))
    return e


# ----------------------------------------------------------- selection / planning
def test_selection_expiry_window_atm_window_and_exclusions():
    mk = lambda sym, exp, k, ot, **kw: sample_contract(sym, expiry=exp, strike=Decimal(k), option_type=ot, **kw)
    cs = [mk(f"O{k}{ot}", EXP, k, ot) for k in range(25000, 26100, 100) for ot in ("CE", "PE")]
    cs += [mk("FAR", datetime.date(2026, 11, 26), "25500", "CE")]
    stale = mk("STALE", D(1), "25500", "CE"); cs.append(stale)
    exp_status = mk("EXPST", EXP, "25500", "CE"); exp_status.status = "EXPIRED"; cs.append(exp_status)
    cs += [sample_contract("F1", category="FUTURES", expiry=EXP), sample_contract("F2", category="FUTURES", expiry=datetime.date(2026, 11, 26))]
    got = fh.select_contracts(cs, ["NIFTY"], 1, 2, True, True, D(19), {"NIFTY": 25520})
    syms = {c.fyers_symbol for c in got}
    assert {"O25300CE", "O25700PE", "O25500CE"} <= syms and "O25200CE" not in syms and "O25800CE" not in syms
    assert "FAR" not in syms and "STALE" not in syms and "EXPST" not in syms     # expiry window, expired, status
    assert "F1" in syms and "F2" not in syms
    assert len([c for c in got if c.category == "OPTIONS"]) == 10


def test_selection_without_spot_for_options_fails_clearly():
    with pytest.raises(fh.AtmUnavailable):
        fh.select_contracts([sample_contract("X")], ["NIFTY"], 1, 2, True, True, D(19), {})
    assert fh.select_contracts([sample_contract("X")], ["NIFTY"], 1, 2, False, False, D(19), {}) == []


def test_today_is_only_complete_after_close_plus_buffer():
    mk = lambda h, m: datetime.datetime(2026, 10, 19, h, m, tzinfo=IST)
    assert fh.last_complete_day(mk(10, 0), 20) == D(18)
    assert fh.last_complete_day(mk(15, 45), 20) == D(18)        # session closes 15:40; +20 min buffer = 16:00
    assert fh.last_complete_day(mk(15, 59), 20) == D(18)
    assert fh.last_complete_day(mk(16, 0), 20) == D(19)


def test_plan_orders_by_expiry_chunks_skips_done_and_never_plans_expired(env):
    near = sample_contract("NSE:NIFTY26OCT25600CE", expiry=D(20), strike=Decimal("25600"))
    env.repo.upsert_contracts([near], seen_at=datetime.datetime(2026, 10, 14))
    s = dataclasses.replace(SETTINGS, history=dataclasses.replace(SETTINGS.history, max_days_per_request=2))
    cons = [c for c in env.repo.get_contracts()]
    env.repo.add_checkpoint_range(env.cid(FUT), "HISTORICAL", "1m", D(15), D(16), "VERIFIED")
    plan = fh.build_plan(env.repo, cons, D(15), D(19), D(19), NOW, s)
    assert plan.items[0].contract.fyers_symbol == "NSE:NIFTY26OCT25600CE" and plan.items[0].days_to_expiry == 1
    assert plan.items[0].range_to <= D(19) and all(i.range_to <= i.contract.expiry for i in plan.items)
    fut_items = [(i.range_from, i.range_to) for i in plan.items if i.contract.fyers_symbol == FUT]
    assert fut_items == [(D(17), D(18)), (D(19), D(19))]                        # verified days skipped, chunked by 2
    gone = sample_contract("NSE:OLD", expiry=D(10)); env.repo.upsert_contracts([gone])
    plan2 = fh.build_plan(env.repo, env.repo.get_contracts(), D(1), D(19), D(19), NOW, s)
    assert all(i.contract.fyers_symbol != "NSE:OLD" for i in plan2.items)       # expiry < today -> never fetched
    est = plan.estimate(8, 90000, 0.3)
    assert est["requests"] == len(plan.items) and est["min_seconds"] > 0


# ----------------------------------------------------------------- happy path
def ckpt(env, sym):
    return env.repo.get_checkpoint_ranges(env.cid(sym), "HISTORICAL", "1m")


def test_successful_harvest_persists_both_stores_then_checkpoints(env):
    out, job = env.run(env.ctx())
    assert out.state == "SUCCESS", out.error
    for sym in (FUT, OPT):
        assert env.count(sym) == 15                                         # weekdays 15, 16, 19 x 5 minutes
        assert ckpt(env, sym) == [(D(15), D(19), "VERIFIED")]
    assert job["requests_made"] == 2 and job["rows_raw"] == 30 and job["rows_valid"] == 30 and job["rows_stored"] == 30
    assert job["rows_invalid"] == 0 and job["rows_duplicate"] == 0 and job["state"] == "SUCCESS"
    files = env.store.list_candle_files()
    assert len(files) == 3                                                  # 1 underlying x 1 expiry x 3 dates
    assert all(m["status"] == "VERIFIED" for m in env.repo.manifest_list())
    df = env.store.read_partition(files[0]); assert set(df["contract_id"]) == {env.cid(FUT), env.cid(OPT)}
    assert env.client.symbols_called() == [FUT, OPT] or sorted(env.client.symbols_called()) == sorted([FUT, OPT])
    assert all(c["cont_flag"] == "0" for c in env.client.calls)             # real contracts only, never stitched
    st = {q[1]: q[4] for q in env.repo.harvest_queue()}                     # nothing pending after success
    assert st == {}


def test_second_run_has_nothing_to_fetch(env):
    env.run(env.ctx())
    ctx = env.ctx()
    out, job = env.run(ctx, dict(env.params, note="again"))
    assert out.state == "SUCCESS" and "nothing to fetch" in out.result["note"]
    assert ctx.fetcher.client.calls == [] and job["requests_made"] == 0


def test_checkpoint_is_written_only_after_mysql_and_parquet_are_verified(env, monkeypatch):
    order = []
    orig_up, orig_pq, orig_ck = env.repo.upsert_candles, env.store.write_candles, env.repo.add_checkpoint_range
    monkeypatch.setattr(env.repo, "upsert_candles", lambda c: (order.append("mysql"), orig_up(c))[1])
    monkeypatch.setattr(env.store, "write_candles", lambda *a, **k: (order.append("parquet"), orig_pq(*a, **k))[1])
    monkeypatch.setattr(env.repo, "add_checkpoint_range",
                        lambda *a, **k: (order.append("ckpt:" + a[5]), orig_ck(*a, **k))[1])
    env.run(env.ctx())
    for first in range(len(order)):
        if order[first] == "ckpt:VERIFIED":
            assert order[first - 2:first] == ["mysql", "parquet"]


def test_empty_response_records_no_data_for_exactly_the_requested_range(env):
    out, job = env.run(env.ctx(lambda s, p, n: {"s": "no_data"}))
    assert out.state == "NO_DATA" and job["no_data_count"] == 2
    assert ckpt(env, FUT) == [(D(15), D(19), "NO_DATA")] and env.count(FUT) == 0
    assert env.store.list_candle_files() == []


def test_malformed_rows_are_counted_invalid_and_never_stored(env):
    good = rows_for(D(16), D(16))
    bad = [[1, 2], "junk", [good[0][0], 100, 90, 95, 100, 1]]               # high < open
    out, job = env.run(env.ctx(lambda s, p, n: {"s": "ok", "candles": good + bad}))
    assert out.state == "PARTIAL"  # valid rows survive, but rejected rows cannot justify VERIFIED
    assert all(r[2] == "FAILED" for r in ckpt(env,FUT))
    assert job["rows_raw"] == 16 and job["rows_valid"] == 10 and job["rows_invalid"] == 6
    assert env.count(FUT) == 5


def test_provider_error_diagnostics_redact_tokens(env):
    secret = 'do-not-print-this-token'
    out, _ = env.run(env.ctx(lambda s, p, n: {
        's': 'error', 'code': -999, 'message': f'access_token={secret}', 'access_token': secret,
    }))
    assert out.state == 'FAILED'
    assert secret not in str(out.result) and secret not in str(out.error)


def test_all_rows_invalid_fails_the_range_and_does_not_advance_the_checkpoint(env):
    out, job = env.run(env.ctx(lambda s, p, n: {"s": "ok", "candles": [[1, 2], "junk"]}))
    assert out.state == "FAILED" and env.count(FUT) == 0
    assert ckpt(env, FUT) == [(D(15), D(19), "FAILED")]
    assert env.repo.missing_ranges(env.cid(FUT), "HISTORICAL", "1m", D(15), D(19)) == [(D(15), D(19))]


def test_invalid_symbol_code_300_on_active_contract_is_failed_not_retried_others_continue(env):
    def r(sym, p, n):
        return {"s": "error", "code": -300, "message": "Invalid symbol"} if sym == OPT else ok_responder(sym, p, n)
    out, job = env.run(env.ctx(r))
    assert out.state == "PARTIAL" and out.result["invalid_symbol"] == 1
    assert env.client.symbols_called().count(OPT) == 1 and env.sleeps == []     # no retry loop
    assert ckpt(env, OPT) == [(D(15), D(19), "FAILED")] and ckpt(env, FUT) == [(D(15), D(19), "VERIFIED")]
    assert "ACTIVE contract rejected" in out.result["failures"][0]


def test_rate_limit_429_is_retried_then_succeeds_and_counted(env):
    def r(sym, p, n):
        return {"s": "error", "code": 429, "message": "slow down"} if n <= 2 else ok_responder(sym, p, n)
    out, job = env.run(env.ctx(r))
    assert out.state == "SUCCESS" and job["retry_count"] == 2 and job["requests_made"] == 4
    assert len(env.sleeps) == 2


def test_network_failure_marks_range_failed_and_a_later_run_retries_it(env):
    out, job = env.run(env.ctx(lambda s, p, n: (_ for _ in ()).throw(ConnectionError("down"))))
    assert out.state == "FAILED" and ckpt(env, FUT) == [(D(15), D(19), "FAILED")]
    out2, job2 = env.run(env.ctx(), dict(env.params, retry="yes"))
    assert out2.state == "SUCCESS" and ckpt(env, FUT) == [(D(15), D(19), "VERIFIED")] and env.count(FUT) == 15


def test_token_expiry_fails_clearly_stops_at_once_and_leaves_unprocessed_ranges_untouched(env):
    out, job = env.run(env.ctx(lambda s, p, n: {"s": "error", "code": -16, "message": "Could not authenticate"}))
    assert out.state == "FAILED" and "model.fyers.auth" in out.error
    assert len(env.client.calls) == 1                                       # no retry loop
    assert env.repo.count_checkpoint_ranges() == 0 and env.count(FUT) == 0


def test_token_expiry_after_progress_is_partial_and_keeps_verified_work(env):
    def r(sym, p, n):
        return ok_responder(sym, p, n) if n == 1 else {"s": "error", "code": -16, "message": "expired"}
    out, job = env.run(env.ctx(r))
    assert out.state == "PARTIAL" and "token" in out.error.lower()
    assert sum(1 for s_ in (FUT, OPT) if ckpt(env, s_) == [(D(15), D(19), "VERIFIED")]) == 1


def test_partial_storage_failure_never_checkpoints_then_recovers_idempotently(env, monkeypatch):
    real = env.store.write_candles
    monkeypatch.setattr(env.store, "write_candles", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    out, job = env.run(env.ctx())
    assert out.state == "FAILED" and "storage failed" in out.error
    assert env.count(FUT) == 15                                            # MySQL is written first ...
    assert ckpt(env, FUT) == [(D(15), D(19), "FAILED")]                    # ... but the checkpoint did NOT advance
    monkeypatch.setattr(env.store, "write_candles", real)
    out2, job2 = env.run(env.ctx(), dict(env.params, retry=1))
    assert out2.state == "SUCCESS" and env.count(FUT) == 15                # no duplicate rows
    assert job2["rows_duplicate"] == 30 and job2["rows_stored"] == 0
    assert ckpt(env, FUT) == [(D(15), D(19), "VERIFIED")] and len(env.store.list_candle_files()) == 3


def test_duplicate_response_is_idempotent_and_conflicting_values_are_reported_not_applied(env):
    env.run(env.ctx())
    env.repo.reset_checkpoints()
    out, job = env.run(env.ctx(), dict(env.params, again=1))
    assert out.state == "SUCCESS" and job["rows_duplicate"] == 30 and out.result["conflicts"] == 0
    env.repo.reset_checkpoints()
    shifted = lambda s, p, n: {"s": "ok", "candles": [[r[0], r[1] + 50, r[2] + 50, r[3] + 50, r[4] + 50, r[5]] for r in ok_responder(s, p, n)["candles"]]}
    out, job = env.run(env.ctx(shifted), dict(env.params, again=2))
    assert out.result["conflicts"] == 30
    with env.engine.connect() as c:
        assert c.execute(text("SELECT MAX(high) FROM fno_candles")).scalar() == Decimal("101.0000")   # stored values untouched


def test_resume_after_graceful_shutdown_fetches_only_the_remainder(env):
    stop = threading.Event()
    def r(sym, p, n):
        resp = ok_responder(sym, p, n)
        if n == 1: stop.set()                                              # shutdown arrives after the first contract
        return resp
    out, job = env.run(env.ctx(r), shutdown=stop)
    assert out.state == "INTERRUPTED" and job["state"] == "INTERRUPTED"
    first_done = [s_ for s_ in (FUT, OPT) if ckpt(env, s_)]
    assert len(first_done) == 1
    new_id = env.jobs.resume(job["id"])
    jb = env.jobs.claim_next(); ctx = env.ctx()
    out2 = fh.run_harvest(JobHandle(env.jobs, jb, threading.Event()), ctx)
    assert out2.state == "SUCCESS" and len(ctx.fetcher.client.calls) == 1   # only the unfinished contract
    assert ctx.fetcher.client.calls[0]["symbol"] not in first_done
    assert env.count(FUT) == env.count(OPT) == 15


def test_cancel_stops_after_the_current_contract(env):
    def r(sym, p, n):
        if n == 1: env.jobs.request_cancel(env.jobs.list(limit=1)[0]["id"])
        return ok_responder(sym, p, n)
    out, job = env.run(env.ctx(r))
    assert out.state == "CANCELLED" and len(env.client.calls) == 1


OLD = "NSE:NIFTY26SEP25500CE"


def tracked_expired(env, expiry=D(8), checked=((D(1), D(3)),)):
    """An expired contract we were already tracking (it has a harvest_state row)."""
    old = sample_contract(OLD, expiry=expiry); env.repo.upsert_contracts([old])
    oid = env.repo.get_contract_id(OLD)
    env.repo.upsert_harvest_state(oid, expiry, 5, "PENDING")
    for a, b in checked:
        env.repo.add_checkpoint_range(oid, "HISTORICAL", "1m", a, b, "VERIFIED")
    with env.engine.begin() as c:
        c.execute(text("UPDATE fno_instruments SET status='EXPIRED' WHERE id=:i"), {"i": oid})
    return oid


def old_ok(sym, p, n):
    return ok_responder(sym, p, n)


def test_recently_expired_tracked_contract_is_attempted_and_stored_when_fyers_still_serves_it(env):
    """Expired history availability is UNKNOWN on this account, so the harvest attempts it and lets FYERS decide."""
    oid = tracked_expired(env)
    params = dict(env.params, **{"from": "2026-10-01"})
    out, job = env.run(env.ctx(old_ok), params)
    assert OLD in env.client.symbols_called()                               # attempted: FYERS decides, we do not assume
    assert out.result["expired_requests"] >= 1 and out.result["failed"] == 0
    r = env.repo.get_checkpoint_ranges(oid, "HISTORICAL", "1m")
    assert r == [(D(1), D(8), "VERIFIED")]
    assert env.repo.count_candles(oid, "1m", datetime.datetime(2026, 10, 1), datetime.datetime(2026, 10, 31)) > 0


def test_expired_symbol_rejected_with_300_stays_retryable(env):
    oid = tracked_expired(env)
    gone = lambda s, p, n: ({"s": "error", "code": -300, "message": "Invalid symbol"} if s == OLD else ok_responder(s, p, n))
    params = dict(env.params, **{"from": "2026-10-01"})
    out, job = env.run(env.ctx(gone), params)
    assert out.state == "PARTIAL" and out.result["failed"] == 1
    assert out.result["unrecoverable_marked"] == 0
    assert (D(4), D(8), "FAILED") in env.repo.get_checkpoint_ranges(oid, "HISTORICAL", "1m")
    ctx2 = env.ctx(gone)
    out2, _ = env.run(ctx2, dict(params, again=1))
    assert OLD in ctx2.fetcher.client.symbols_called() # explicit subsequent job can retry


def test_expired_contract_age_is_not_proof_of_unavailability(env):
    oid = tracked_expired(env, expiry=D(2), checked=())
    s = dataclasses.replace(SETTINGS, expired_history_max_age_days=5)        # expired 17 days ago
    ctx = env.ctx(old_ok, settings=s)
    out, _ = env.run(ctx, dict(env.params, **{"from": "2026-10-01"}))
    assert OLD in ctx.fetcher.client.symbols_called()
    assert out.result['unrecoverable_marked']==0
    assert env.repo.get_checkpoint_ranges(oid, "HISTORICAL", "1m") == [(D(1), D(2), "VERIFIED")]


def test_expired_history_can_be_switched_off(env):
    oid = tracked_expired(env)
    s = dataclasses.replace(SETTINGS, expired_history_enabled=False)
    ctx = env.ctx(old_ok, settings=s)
    env.run(ctx, dict(env.params, **{"from": "2026-10-01"}))
    assert OLD not in ctx.fetcher.client.symbols_called()
    assert env.repo.get_checkpoint_ranges(oid, "HISTORICAL", "1m") == [(D(1),D(3),"VERIFIED")]


def test_expired_contracts_we_never_tracked_are_not_fetched_symbols_are_never_constructed(env):
    old = sample_contract("NSE:NIFTY26AUG25500CE", expiry=D(3)); env.repo.upsert_contracts([old])
    with env.engine.begin() as c:
        c.execute(text("UPDATE fno_instruments SET status='EXPIRED' WHERE fyers_symbol='NSE:NIFTY26AUG25500CE'"))
    ctx = env.ctx(old_ok)
    env.run(ctx, dict(env.params, **{"from": "2026-10-01"}))
    assert "NSE:NIFTY26AUG25500CE" not in ctx.fetcher.client.symbols_called()


def test_expired_contracts_are_planned_before_active_ones(env):
    tracked_expired(env)
    plan = fh.build_plan(env.repo, [c for c in env.repo.get_contracts() if c.status == "ACTIVE"], D(1), D(19), D(19), NOW, SETTINGS,
                         all_universe_contracts=env.repo.get_contracts())
    assert plan.items[0].contract.fyers_symbol == OLD and plan.items[0].days_to_expiry < 0


def test_daily_quota_exhaustion_stops_with_partial(env):
    def r(sym, p, n):
        if n == 2: raise DailyQuotaExhausted("Daily FYERS request budget used up")
        return ok_responder(sym, p, n)
    out, job = env.run(env.ctx(r))
    assert out.state == "PARTIAL" and "Daily" in out.error


def test_today_is_not_checkpointed_while_the_session_is_open(env):
    open_now = datetime.datetime(2026, 10, 19, 11, 0, tzinfo=IST)
    ctx = env.ctx(); ctx.clock = lambda: open_now
    out, _ = env.run(ctx)
    assert ckpt(env, FUT) == [(D(15), D(18), "VERIFIED")] and out.result["effective_to"] == "2026-10-18"


def test_runner_end_to_end_with_persisted_job(env):
    ctx = env.ctx()
    runner = FnoJobRunner(env.jobs, {fh.JOB_TYPE: lambda h: fh.run_harvest(h, ctx)}, heartbeat_seconds=0.1)
    jid = env.jobs.submit(fh.JOB_TYPE, env.params)
    assert runner.run_until_empty() == [jid]
    assert env.jobs.get(jid)["state"] == "SUCCESS" and env.count(OPT) == 15


def test_harvest_reports_how_far_provisional_live_candles_were_from_history(env):
    from tests_support import make_candle
    cid = env.cid(FUT)
    env.repo.upsert_candles([make_candle(cid, 0, day=D(15), v=3, source="FYERS_LIVE"),                # history says volume 10: differs
                             make_candle(cid, 1, day=D(15), o="100", h="101", l="99", c="100.5", v=11, source="FYERS_LIVE")])   # identical to history minute 1
    out, job = env.run(env.ctx())
    assert out.result["live_superseded"] == 2 and out.result["live_superseded_changed"] == 1
    assert out.result["conflicts"] == 0


def test_harvest_separates_response_duplicates_from_already_stored_rows(env):
    def doubled(s, p, n):
        r = ok_responder(s, p, n); return {"s": "ok", "candles": r["candles"] + r["candles"]}
    out, job = env.run(env.ctx(doubled))
    assert out.result["response_duplicates"] == 30 and job["rows_raw"] == 60 and job["rows_valid"] == 30
    assert job["rows_stored"] == 30 and job["rows_duplicate"] == 0 and env.count(FUT) == 15


def test_harvest_reports_per_field_live_error_and_parquet_quarantine_count(env):
    from tests_support import make_candle
    cid = env.cid(FUT)
    env.repo.upsert_candles([make_candle(cid, 0, day=D(15), h="150", v=3, source="FYERS_LIVE")])
    out, _ = env.run(env.ctx())
    assert out.result["live_diff_fields"] == {"high": 1, "volume": 1} and out.result["parquet_quarantined"] == 0
