import argparse
import dataclasses
import datetime
import subprocess
import sys
from pathlib import Path

import pytest

from controller import fno_cli
from model.fno.config import load_fno_settings
from model.fno.models import IST
from test_fno_harvest import FakeFyers, ok_responder, FUT, OPT, EXP
from test_fno_symbol_master import csv_row, EPOCH
from tests_support import sample_contract

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture()
def cli(clean_fno, fno_cfg, tmp_path, monkeypatch):
    import model.fno.db as fdb
    monkeypatch.setenv("FNO_DB_HOST", fno_cfg.host); monkeypatch.setenv("FNO_DB_PORT", str(fno_cfg.port))
    monkeypatch.setenv("FNO_DB_NAME", fno_cfg.name); monkeypatch.setenv("FNO_DB_USER", fno_cfg.user)
    monkeypatch.setenv("FNO_DB_PASSWORD", fno_cfg.password); monkeypatch.setenv("DB_NAME", "market_data_test")
    s = load_fno_settings()
    s = dataclasses.replace(s, parquet_root=(tmp_path / "fno").resolve())
    monkeypatch.setattr(fno_cli, "load_fno_settings", lambda: s)
    monkeypatch.setattr(fno_cli, "_setup_logging", lambda: None)
    class E: pass
    e = E(); e.settings, e.tmp, e.engine = s, tmp_path, clean_fno
    e.fake = {"resp": ok_responder}
    class Creds: client_id, access_token = "ID", "TOKEN"
    class Env: fyers = Creds()
    monkeypatch.setattr("model.config.env_loader.load_env_config", lambda: Env())
    monkeypatch.setattr("model.fyers.auth.get_authenticated_client", lambda creds: e.client)
    class C(FakeFyers):
        def quotes(self, data=None):
            return {"s": "ok", "d": [{"n": sym, "v": {"lp": 25510.0}} for sym in data["symbols"].split(",")]}
    e.client = C(lambda sym, p, n: e.fake["resp"](sym, p, n))
    def run(*argv):
        parser = argparse.ArgumentParser(); sub = parser.add_subparsers(dest="mode", required=True)
        fno_cli.add_fno_subparsers(sub)
        return fno_cli.run_fno_mode(parser.parse_args(list(argv)))
    e.run = run
    from model.fno.repository import FnoRepository
    e.repo = FnoRepository(clean_fno)
    e.repo.upsert_contracts([sample_contract(FUT, category="FUTURES", expiry=EXP), sample_contract(OPT, expiry=EXP)])
    return e


def test_main_registers_all_release1_modes_and_fno_modes_skip_subsystem_a_startup():
    out = subprocess.run([sys.executable, "main.py", "--help"], cwd=ROOT, capture_output=True, text=True).stdout
    for m in fno_cli.FNO_MODES:
        assert m in out
    bare = {"PATH": "/usr/bin:/bin", "HOME": "/tmp"}
    # Keep this subprocess isolation check independent of a real local .env or
    # the dashboard suite's temporary .env. Do not rename or mutate user files.
    isolated = [sys.executable, "-c", "import dotenv,runpy,sys; dotenv.load_dotenv=lambda *a,**k:False; sys.argv=['main.py','fno-jobs']; runpy.run_path('main.py',run_name='__main__')"]
    r = subprocess.run(isolated, cwd=ROOT, capture_output=True, text=True, env=bare)
    assert r.returncode == 1 and "isolation cannot be proven" in r.stdout          # no A name -> refuses, clearly
    r = subprocess.run(isolated, cwd=ROOT, capture_output=True, text=True,
                       env={**bare, "DB_NAME": "market_data"})
    assert r.returncode == 1 and "FNO_DB_USER" in r.stdout                          # then asks for FNO credentials


def test_migrate_dry_run_changes_nothing_and_apply_is_idempotent(cli, capsys):
    assert cli.run("fno-migrate") == 0 and "Dry run" in capsys.readouterr().out
    assert cli.run("fno-migrate", "--apply") == 0 and cli.run("fno-migrate", "--apply") == 0


def test_cli_refuses_to_run_when_fno_db_equals_subsystem_a_db(cli, monkeypatch, capsys):
    monkeypatch.setenv("DB_NAME", "fno_market_data_test")
    assert cli.run("fno-jobs") == 1 and "same as Subsystem A" in capsys.readouterr().out


def test_sync_contracts_from_cached_master(cli, capsys, monkeypatch):
    cache = cli.settings.parquet_root / "symbol_master" / "NSE_FO.csv"; cache.parent.mkdir(parents=True)
    cache.write_text("\n".join([csv_row("NSE:NIFTY26NOV25500CE", "NIFTY", EPOCH, 25500, "CE"),
                                csv_row("NSE:NIFTY26NOVFUT", "NIFTY", EPOCH, -1, "XX")]))
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    assert cli.run("fno-sync-contracts") == 0
    assert "inserted=2" in capsys.readouterr().out
    cache.write_text("garbage,line")
    assert cli.run("fno-sync-contracts") == 1 and "layout" in capsys.readouterr().out


def hist_args(*extra):
    return ["fno-historical", "--underlyings", "NIFTY", "--expiries", "1", "--from", "2026-10-15", "--to", "2026-10-16", *extra]


def test_historical_end_to_end_prints_estimate_runs_and_exits_zero(cli, capsys, monkeypatch):
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    code = cli.run(*hist_args("--atm", "NIFTY=25500"))
    out = capsys.readouterr().out
    assert code == 0 and "Plan: 2 contract(s), 2 request(s)" in out and "SUCCESS" in out
    assert cli.repo.count_candles(cli.repo.get_contract_id(FUT), "1m", datetime.datetime(2026, 10, 1), datetime.datetime(2026, 10, 31)) == 10
    assert len(list((cli.settings.parquet_root / "candles").rglob("*.parquet"))) == 2
    assert cli.run("fno-jobs", "--list") == 0 and "HISTORICAL_HARVEST" in capsys.readouterr().out


def test_historical_reads_atm_from_quotes_when_not_given(cli, monkeypatch):
    from model.fno.job_store import FnoJobStore
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    assert cli.run(*hist_args("--submit-only")) == 0
    job = FnoJobStore(cli.engine).list(limit=1)[0]
    assert job["params"]["atm"] == {"NIFTY": 25510.0}                          # taken from the (fake) spot quote


def test_historical_without_any_atm_fails_clearly_and_queues_nothing(cli, capsys, monkeypatch):
    from model.fno.job_store import FnoJobStore
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    cli.client.quotes = lambda data=None: {"s": "ok", "d": []}                 # spot unavailable
    assert cli.run(*hist_args("--submit-only")) == 1
    assert "ATM" in capsys.readouterr().out
    assert FnoJobStore(cli.engine).list() == []


def test_duplicate_submission_exits_3_and_submit_only_leaves_job_pending(cli, capsys, monkeypatch):
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    assert cli.run(*hist_args("--atm", "NIFTY=25500", "--submit-only")) == 0
    assert cli.run(*hist_args("--atm", "NIFTY=25500", "--submit-only")) == 3
    assert "already active" in capsys.readouterr().out
    assert cli.client.calls == []                                               # submit-only fetched nothing
    assert cli.run("fno-jobs", "--run") == 0 and len(cli.client.calls) == 2


def test_token_expiry_gives_failed_job_and_nonzero_exit(cli, capsys, monkeypatch):
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    cli.fake["resp"] = lambda s, p, n: {"s": "error", "code": -16, "message": "Could not authenticate"}
    assert cli.run(*hist_args("--atm", "NIFTY=25500")) == 1
    assert "model.fyers.auth" in capsys.readouterr().out


def test_jobs_cancel_and_resume_messages(cli, capsys, monkeypatch):
    monkeypatch.setattr(fno_cli, "_today", lambda: datetime.date(2026, 10, 19))
    cli.run(*hist_args("--atm", "NIFTY=25500", "--submit-only")); capsys.readouterr()
    assert cli.run("fno-jobs", "--cancel", "99999") == 0 and "NOT_ACTIVE" in capsys.readouterr().out
    assert cli.run("fno-jobs", "--resume", "99999") == 1


def test_reconcile_and_cleanup_commands(cli, capsys):
    assert cli.run("fno-reconcile") == 0 and "agree" in capsys.readouterr().out
    assert cli.run("fno-cleanup", "--retain-days", "30") == 0 and "Would delete 0" in capsys.readouterr().out
    assert cli.run("fno-cleanup", "--retain-days", "30", "--confirm") == 0


def test_cleanup_without_confirm_never_deletes(cli, capsys, monkeypatch):
    from model.fno.parquet_store import FnoParquetStore
    from tests_support import make_candle
    store = FnoParquetStore(cli.settings.parquet_root, cli.repo)
    cid = cli.repo.get_contract_id(FUT)
    store.write_candles([make_candle(cid, 0, day=datetime.date(2025, 1, 6))], {cid: ("NIFTY", EXP)})
    assert cli.run("fno-cleanup", "--retain-days", "30") == 0
    assert len(store.list_candle_files()) == 1 and "Dry run" in capsys.readouterr().out
    assert cli.run("fno-cleanup", "--retain-days", "30", "--dry-run", "--confirm") == 0
    assert len(store.list_candle_files()) == 1                                   # --dry-run wins over --confirm
    assert cli.run("fno-cleanup", "--retain-days", "30", "--confirm") == 0 and store.list_candle_files() == []


def _chain_resp(symbols):
    rows = [{"ask": 0, "bid": 0, "ltp": 25510.0, "option_type": "", "strike_price": -1, "symbol": "NSE:NIFTY50-INDEX"}]
    rows += [{"ask": 66.7, "bid": 66.5, "ltp": 66.4, "oi": 1000, "oich": 10, "volume": 5, "option_type": "CE", "strike_price": 25500,
              "symbol": s, "greeks": {"delta": 0.5, "gamma": 0.1, "theta": -1, "vega": 2, "iv": 15.0}} for s in symbols]
    return {"s": "ok", "code": 200, "message": "", "data": {"optionsChain": rows, "expiryData": []}}


def test_chain_snapshot_command_once(cli, capsys, monkeypatch):
    cli.client.optionchain = lambda data=None: _chain_resp([OPT])
    assert cli.run("fno-chain-snapshot", "--underlyings", "NIFTY") == 0
    out = capsys.readouterr().out
    assert "stored 1/1 rows" in out
    assert len(list((cli.settings.parquet_root / "option_chain").rglob("*.parquet"))) == 1


def test_chain_snapshot_command_reports_failures_with_exit_2(cli, capsys):
    cli.client.optionchain = lambda data=None: _chain_resp(["NSE:NIFTY26OCT99999CE"])
    assert cli.run("fno-chain-snapshot", "--underlyings", "NIFTY") == 2
    assert "no rows that match the contract master" in capsys.readouterr().out


def test_live_command_streams_ticks_into_candles_and_flushes_on_stop(cli, capsys, monkeypatch):
    import datetime as dt
    monkeypatch.setattr(fno_cli, "_today", lambda: dt.date(2026, 10, 19))
    monkeypatch.setattr("model.config.market_calendar.live_session_status", lambda *a, **k: {"open":True,"reason":None})
    monkeypatch.setattr("controller.fno_live.live_session_status", lambda *a, **k: {"open":True,"reason":None})
    seen = {}
    class FakeWs:
        def __init__(self, access_token, symbols, on_tick, on_reconnect=None, **kw):
            seen.update(token=access_token, symbols=symbols); self.on_tick = on_tick
        def connect_and_run(self):
            for m in range(3):
                ep = int(dt.datetime(2026, 10, 19, 9, 15 + m, 5, tzinfo=IST).timestamp())
                self.on_tick({"symbol": FUT, "ltp": 100 + m, "vol_traded_today": 10 * (m + 1), "exch_feed_time": ep})
        def stop(self): pass
    monkeypatch.setattr("model.fyers.websocket.FyersWebSocketClient", FakeWs)
    assert cli.run("fno-live", "--underlyings", "NIFTY", "--expiries", "1", "--atm", "NIFTY=25500") == 0
    out = capsys.readouterr().out
    assert "Live universe: 2 contract(s)" in out and "persisted=3" in out
    assert seen["token"] == "ID:TOKEN" and set(seen["symbols"]) == {FUT, OPT}
    assert cli.repo.count_candles(cli.repo.get_contract_id(FUT), "1m", dt.datetime(2026, 10, 1), dt.datetime(2026, 10, 31)) == 3


def test_live_command_honours_the_subscription_cap_and_fails_clearly_without_contracts(cli, capsys, monkeypatch):
    import datetime as dt
    monkeypatch.setattr(fno_cli, "_today", lambda: dt.date(2026, 10, 19))
    monkeypatch.setattr("model.config.market_calendar.live_session_status", lambda *a, **k: {"open":True,"reason":None})
    monkeypatch.setattr("controller.fno_live.live_session_status", lambda *a, **k: {"open":True,"reason":None})
    class FakeWs:
        def __init__(self, **kw): self.symbols = kw["symbols"]
        def connect_and_run(self): pass
        def stop(self): pass
    monkeypatch.setattr("model.fyers.websocket.FyersWebSocketClient", FakeWs)
    assert cli.run("fno-live", "--underlyings", "NIFTY", "--atm", "NIFTY=25500", "--max-subscriptions", "1") == 0
    assert "1 contract(s) of 2 eligible (cap 1, dropped by cap 1)" in capsys.readouterr().out
    assert cli.run("fno-live", "--underlyings", "BANKNIFTY", "--atm", "BANKNIFTY=55000") == 1
    assert "no ACTIVE contracts" in capsys.readouterr().out


def test_release3_local_jobs_need_no_fyers_token_and_queue_resume(cli,monkeypatch,capsys):
    from tests_support import make_candle
    from model.fno.job_store import FnoJobStore
    def unexpected(*args,**kw):raise AssertionError('Local operation tried to authenticate FYERS')
    monkeypatch.setattr('model.fyers.auth.get_authenticated_client',unexpected)
    cid=cli.repo.get_contract_id(FUT)
    cli.repo.upsert_candles([make_candle(cid,i) for i in range(385)])
    args=['--from','2026-10-19','--to','2026-10-19','--contract-ids',str(cid),'--no-parquet']
    assert cli.run('fno-aggregate',*args,'--timeframes','5m','--submit-only')==0
    assert cli.run('fno-aggregate',*args,'--timeframes','5m','--submit-only')==3
    assert cli.run('fno-jobs','--run')==0
    assert len(cli.repo.fetch_candles(cid,'5m',datetime.date(2026,10,19),datetime.date(2026,10,19)))==77
    assert cli.run('fno-verify',*args)==2  # Parquet explicitly unverified
    assert cli.run('fno-aggregate','--from','2026-10-20','--to','2026-10-19')==1
