import datetime
import json
import pytest
from model.fno.config import load_fno_settings
from model.fno import probe as P
from test_fno_symbol_master import csv_row, EPOCH

S = load_fno_settings()
TODAY = datetime.date(2026, 10, 19)
FUT_EPOCH = EPOCH


def master_text():
    rows = []
    for u in S.universe.underlyings:
        rows.append(csv_row(f"NSE:{u}26NOVFUT", u, EPOCH, -1, "XX"))
        for k in (25400, 25500, 25600):
            for ot in ("CE", "PE"):
                rows.append(csv_row(f"NSE:{u}26NOV{k}{ot}", u, EPOCH, k, ot))
    return "\n".join(rows)


class Resp:
    def __init__(self, text, status=200): self.text, self.status_code = text, status


class FakeClient:
    def __init__(self, oi_adds_column=True, chain_has_greeks=True, expired_has_data=False, history_ok=True):
        self.calls = []; self.oi, self.greeks, self.exp_data, self.hist_ok = oi_adds_column, chain_has_greeks, expired_has_data, history_ok
    def quotes(self, data=None): self.calls.append(("quotes", data)); return {"s": "ok", "d": [{"n": data["symbols"], "v": {"lp": 25510.0}}]}
    def history(self, data=None):
        self.calls.append(("history", data))
        if "EXPIRED" in data["symbol"]:
            return {"s": "ok", "candles": [[1, 1, 1, 1, 1, 1]]} if self.exp_data else {"s": "error", "code": -300, "message": "Invalid symbol"}
        if not self.hist_ok: return {"s": "no_data"}
        span = (datetime.date.fromisoformat(data["range_to"]) - datetime.date.fromisoformat(data["range_from"])).days
        if span > 100: return {"s": "error", "code": -1, "message": "range too large"}
        row = [1, 1, 2, 1, 1.5, 10] + ([777] if data.get("oi_flag") and self.oi else [])
        return {"s": "ok", "candles": [row]}
    def optionchain(self, data=None):
        self.calls.append(("optionchain", data))
        if data["strikecount"] > 50: return {"s": "error", "code": -50, "message": "strikecount too high", "data": {}}
        e = {"symbol": "X", "strike_price": 1, "ltp": 1}
        if data.get("greeks") and self.greeks: e.update(delta=0.5, gamma=0.1, theta=-1, vega=2, iv=0.2)
        return {"s": "ok", "data": {"optionsChain": [e] * min(data["strikecount"], 3)}}
    def expiry_dates(self, data=None): return {"s": "ok", "data": {"expiryDates": ["2026-10-13"]}}
    def get_profile(self): self.calls.append(("profile", None)); return {"s": "ok", "code": 200, "token": "SECRET"}


def probe(client=None, text=None, status=200, **kw):
    return P.FnoProbe(client or FakeClient(), S, lambda u, t: Resp(master_text() if text is None else text, status), today=TODAY, sleep=lambda s: None, **kw)


def test_symbol_master_confirmed_with_real_layout_and_evidence():
    r = probe().check_symbol_master()
    assert r.status == P.CONFIRMED and r.evidence["contracts_parsed"] == 4 * 7
    assert r.evidence["categories"] == {"FUTURES": 4, "OPTIONS": 24} and len(r.evidence["first_rows_raw"]) == 3


@pytest.mark.parametrize("text,status,expected", [("", 200, P.NOT_CONFIRMED), ("a,b\nc,d", 200, P.NOT_CONFIRMED), ("x", 503, P.NOT_CONFIRMED)])
def test_symbol_master_not_confirmed_when_layout_does_not_match(text, status, expected):
    assert probe(text=text, status=status).check_symbol_master().status == expected


def test_symbol_master_download_error_is_reported_as_error():
    def boom(u, t): raise ConnectionError("no network")
    r = P.FnoProbe(FakeClient(), S, boom, today=TODAY).check_symbol_master()
    assert r.status == P.ERROR and "no network" in r.summary


def test_history_detects_oi_column_and_span_limit():
    p = probe(); p.check_symbol_master()
    r = p.check_history("FUTURES")
    assert r.status == P.CONFIRMED and r.evidence["oi_flag_adds_a_column"] is True
    assert (r.evidence["row_length_plain"], r.evidence["row_length_with_oi_flag"]) == (6, 7)
    spans = r.evidence["span_days_tested"]
    assert spans[100]["s"] == "ok" and spans[200]["s"] == "error"
    ro = p.check_history("OPTIONS")
    assert ro.status == P.CONFIRMED and ro.evidence["symbol"] == "NSE:NIFTY26NOV25500CE"          # nearest to spot 25510


def test_history_without_oi_support_does_not_claim_it():
    p = probe(FakeClient(oi_adds_column=False)); p.check_symbol_master()
    assert p.check_history("FUTURES").evidence["oi_flag_adds_a_column"] is False


def test_history_with_no_candles_is_not_confirmed_and_without_master_is_skipped():
    p = probe(FakeClient(history_ok=False)); p.check_symbol_master()
    assert p.check_history("FUTURES").status == P.NOT_CONFIRMED
    assert probe().check_history("FUTURES").status == P.SKIPPED


def test_option_chain_greeks_and_strikecount_limit():
    r = probe().check_option_chain()
    assert r.status == P.CONFIRMED
    assert set(r.evidence["greek_fields_only_with_flag"]) == {"delta", "gamma", "theta", "vega", "iv"}
    assert r.evidence["captured_time_field_present"] is False
    assert r.evidence["strikecount_limit_test"][50]["s"] == "ok" and r.evidence["strikecount_limit_test"][51]["s"] == "error"
    assert probe(FakeClient(chain_has_greeks=False)).check_option_chain().evidence["greek_fields_only_with_flag"] == []


def test_expired_symbol_minus_300_confirms_and_data_on_expired_contradicts():
    assert probe().check_expired("NSE:EXPIRED1").status == P.CONFIRMED
    r = probe(FakeClient(expired_has_data=True)).check_expired("NSE:EXPIRED1")
    assert r.status == P.NOT_CONFIRMED and "WRONG" in r.summary
    assert probe().check_expired(None).status == P.SKIPPED
    assert "sdk_expiry_dates_endpoint" in probe().check_expired(None).evidence


class FakeSocket:
    def __init__(self, on_msg, limit): self.on, self.limit, self.total = on_msg, limit, 0
    def connect(self): pass
    def subscribe(self, syms):
        self.total += len(syms)
        if self.total > self.limit: self.on({"code": -351, "message": "symbol limit exceeded"})
        else: self.on({"type": "sf", "symbol": syms[0]})
    def close(self): pass


def test_ws_limit_finds_first_failing_step_and_skips_when_not_enabled():
    p = probe(ws_factory=lambda on: FakeSocket(on, 100)); p.check_symbol_master()
    big = [c for c in p.contracts] * 6
    p.contracts = big
    r = p.check_ws_limit(steps=(10, 50, 100, 150))
    assert r.status == P.CONFIRMED and r.evidence["first_total_with_limit_error"] == 150 and r.evidence["highest_total_without_error"] == 100
    p2 = probe(ws_factory=lambda on: FakeSocket(on, 10**9)); p2.check_symbol_master(); p2.contracts = p2.contracts * 6
    assert p2.check_ws_limit(steps=(10, 50)).status == P.NOT_CONFIRMED                     # never claims the ceiling was found
    assert probe().check_ws_limit().status == P.SKIPPED


def test_rate_limit_check_is_honest_about_a_small_burst():
    r = probe().check_rate_limit(burst=5)
    assert r.status == P.NOT_CONFIRMED and "NOT reproduced" in r.summary


def test_run_all_marks_optional_checks_skipped_by_default():
    res = {r.check: r.status for r in probe().run_all()}
    assert res["websocket_limit"] == P.SKIPPED and res["rate_limit"] == P.SKIPPED and res["symbol_master"] == P.CONFIRMED


def test_report_scrubs_secrets_and_never_overstates():
    p = probe(); results = p.run_all(expired_symbol="NSE:EXPIRED1", rate_limit=True)
    results[0].evidence["access_token"] = "ABC123SECRET"
    md = P.render_findings(results, "2026-10-19 10:00", "3.2.0")
    assert "ABC123SECRET" not in md and "SECRET" not in md.replace("***", "")
    assert "| websocket_limit | SKIPPED |" in md
    assert "you may set it to true" in md                       # both history checks showed the extra OI column
    assert "keep the conservative default; the real ceiling is unknown" in md        # ws check was skipped
    assert "### symbol_master - CONFIRMED" in md and "```json" in md
    nr = P.render_not_run()
    assert "NOT RUN" in nr and "/history/fno/expired/" in nr
    assert P.scrub({"a": {"password": "x", "token": "y", "ok": 1}}) == {"a": {"password": "***", "token": "***", "ok": 1}}


def test_probe_retries_throttled_answers_so_evidence_is_never_rate_limit_noise():
    class Throttling(FakeClient):
        n = 0
        def history(self, data=None):
            Throttling.n += 1
            if Throttling.n % 2:
                return {"s": "error", "code": -360, "message": "You've reached the Standard plan limit of 5 requests/second."}
            return super().history(data)
    p = probe(Throttling()); p.check_symbol_master()
    r = p.check_history("FUTURES")
    assert r.status == P.CONFIRMED and r.evidence["span_days_tested"][100]["s"] == "ok"
    assert r.evidence["throttled_retries_so_far"] > 0 and p.throttled_retries > 0


def test_candle_rows_and_field_names_are_not_truncated_in_the_report():
    row = [1792035900, 22671.0, 22725.0, 22671.0, 22724.8, 1200, 987654]
    assert P.scrub({"first_candle": row})["first_candle"] == row            # the 7th (OI) value must stay visible
    keys = [f"field{i}" for i in range(25)]
    assert P.scrub({"entry_keys": keys})["entry_keys"] == keys


def test_history_evidence_records_time_of_day_and_what_is_outside_the_session():
    IST = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    ep = lambda h, m: int(datetime.datetime(2026, 10, 19, h, m, tzinfo=IST).timestamp())
    class Evening(FakeClient):
        def history(self, data=None):
            if (datetime.date.fromisoformat(data["range_to"]) - datetime.date.fromisoformat(data["range_from"])).days == 30:
                return {"s": "ok", "candles": [[ep(9, 15), 1, 2, 1, 1, 1], [ep(15, 39), 1, 2, 1, 1, 1], [ep(18, 20), 1, 2, 1, 1, 1]]}
            return super().history(data)
    p = probe(Evening()); p.check_symbol_master()
    tod = p.check_history("FUTURES").evidence["time_of_day"]
    assert (tod["first_time"], tod["last_time"], tod["outside_configured_session"]) == ("09:15:00", "18:20:00", 1)


def test_option_chain_evidence_keeps_sample_entries_and_counts():
    ev = probe().check_option_chain().evidence
    assert ev["sample_entries_with_greeks_flag"][0]["delta"] == 0.5 and "entries_without_option_type" in ev


def test_expired_check_records_whether_this_sdk_has_the_expired_endpoints():
    class OldSdk(FakeClient):
        expiry_dates = None
    c = FakeClient(); del_attr = type("NoExpiry", (), {"quotes": c.quotes, "history": c.history})()
    r = P.FnoProbe(del_attr, S, lambda u, t: Resp(master_text()), today=TODAY, sleep=lambda s: None).check_expired(None)
    assert r.evidence["sdk_has_expiry_dates_method"] is False
    assert probe().check_expired(None).evidence["sdk_has_expiry_dates_method"] is True


def test_expired_test_with_a_still_listed_symbol_is_rejected_as_invalid():
    """Regression: a still-active symbol was once used as the 'expired' one and produced a false finding."""
    p = probe(); p.check_symbol_master()
    r = p.check_expired("NSE:NIFTY26NOV25500CE")                    # listed in the master, expiry Nov 26 > today
    assert r.status == P.ERROR and "INVALID TEST" in r.summary and r.evidence["listed_expiry"] == "2026-11-26"
    assert not any(c[0] == "history" and "NIFTY26NOV25500CE" in c[1]["symbol"] for c in p.client.calls)   # no request was made


def test_expired_test_with_an_unlisted_symbol_proceeds_but_states_what_it_could_not_prove():
    p = probe(); p.check_symbol_master()
    r = p.check_expired("NSE:EXPIRED1")
    assert r.status == P.CONFIRMED and "cannot be proven" in r.evidence["note"]


def test_chain_probe_records_the_real_expiry_data_shape_and_whether_our_parser_understands_it():
    class WithExpiry(FakeClient):
        def optionchain(self, data=None):
            r = super().optionchain(data)
            r["data"]["expiryData"] = [{"date": "27-10-2026", "expiry": "1793095800"}, {"date": "03-11-2026", "expiry": "1793700600"}]
            return r
    ev = probe(WithExpiry()).check_option_chain().evidence
    assert ev["expiry_data_entries"] == 2 and ev["expiry_data_parsed_by_our_parser"] == 2 and ev["expiry_data_sample"][0]["date"] == "27-10-2026"
    plain = probe().check_option_chain().evidence
    assert plain["expiry_data_parsed_by_our_parser"] == 0                            # unknown shape is reported, not assumed


def test_single_day_test_uses_the_last_trading_day_not_todays_date():
    """Regression: run at 00:02 on a Saturday the 'today' request was empty and told us nothing."""
    IST = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    last = datetime.datetime(2026, 10, 16, 15, 39, tzinfo=IST)             # Friday; TODAY (probe date) is Monday the 19th
    class Weekend(FakeClient):
        def history(self, data=None):
            a, b = datetime.date.fromisoformat(data["range_from"]), datetime.date.fromisoformat(data["range_to"])
            if (b - a).days == 30:
                return {"s": "ok", "candles": [[int(last.timestamp()), 1, 2, 1, 1, 1]]}
            if a == b:
                self.single = getattr(self, "single", []) + [a]
                return {"s": "ok", "candles": [[1, 1, 2, 1, 1, 1], [1, 1, 2, 1, 1, 1], [2, 1, 2, 1, 1, 1]]}   # one timestamp twice
            return super().history(data)
    c = Weekend(); p = probe(c); p.check_symbol_master()
    ev = p.check_history("FUTURES").evidence
    assert ev["single_day_tested_date"] == "2026-10-16" and set(c.single) == {datetime.date(2026, 10, 16)}
    assert ev["single_day_request"]["plain"] == {"s": "ok", "rows": 3, "unique_timestamps": 2, "duplicate_rows": 1,
                                                  "first": [1, 1, 2, 1, 1, 1], "last": [2, 1, 2, 1, 1, 1]}


def test_nested_greeks_dict_is_recognised_in_the_chain_summary():
    class Nested(FakeClient):
        def optionchain(self, data=None):
            r = super().optionchain(data)
            for e in (r.get("data") or {}).get("optionsChain", []):
                e.pop("delta", None)
                if data.get("greeks"): e["greeks"] = {"delta": 0.5, "gamma": 0.1, "theta": -1, "vega": 2, "iv": 15.0}
            return r
    r = probe(Nested()).check_option_chain()
    assert r.evidence["nested_greeks_keys"] == ["delta", "gamma", "iv", "theta", "vega"]
    assert "greeks.delta" in r.summary and "none" not in r.summary
