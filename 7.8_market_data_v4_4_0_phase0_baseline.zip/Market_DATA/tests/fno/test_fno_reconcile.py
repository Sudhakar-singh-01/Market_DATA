import datetime
import pytest
from sqlalchemy import text
from controller.fno_reconcile import reconcile
from model.fno.parquet_store import FnoParquetStore
from model.fno.repository import FnoRepository
from tests_support import make_candle, sample_contract

EXP = datetime.date(2026, 11, 26)
REL = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"


@pytest.fixture()
def env(clean_fno, tmp_path):
    repo = FnoRepository(clean_fno)
    cid = repo.upsert_contract(sample_contract())
    store = FnoParquetStore(tmp_path / "fno", repo)
    cs = [make_candle(cid, m) for m in range(5)]
    repo.upsert_candles(cs); store.write_candles(cs, {cid: ("NIFTY", EXP)})
    class E: pass
    e = E(); e.repo, e.store, e.cid, e.engine, e.cs = repo, store, cid, clean_fno, cs
    return e


def test_consistent_stores_report_nothing(env):
    assert reconcile(env.repo, env.store).findings == []


def test_rows_missing_from_parquet_are_found_and_repaired_from_mysql(env):
    extra = [make_candle(env.cid, 7)]
    env.repo.upsert_candles(extra)                                   # MySQL ahead of Parquet (crash after MySQL write)
    r = reconcile(env.repo, env.store)
    assert r.kinds() == {"mysql_parquet_mismatch": 1} and not r.ok and r.repaired == 0     # dry-run changes nothing
    assert len(env.store.read_partition(REL)) == 5
    r2 = reconcile(env.repo, env.store, repair=True)
    assert r2.ok and len(env.store.read_partition(REL)) == 6
    assert reconcile(env.repo, env.store).findings == []


def test_rows_missing_from_mysql_are_restored_from_parquet(env):
    with env.engine.begin() as c:
        c.execute(text("DELETE FROM fno_candles WHERE candle_timestamp >= '2026-10-19 09:18:00'"))
    r = reconcile(env.repo, env.store, repair=True)
    assert r.kinds() == {"mysql_parquet_mismatch": 1} and r.ok
    assert env.repo.count_candles(env.cid, "1m", datetime.datetime(2026, 10, 19), datetime.datetime(2026, 10, 20)) == 5


def test_whole_day_missing_from_parquet_is_rebuilt(env):
    env.store.abs_path(REL).unlink(); env.repo.manifest_delete(REL)
    r = reconcile(env.repo, env.store, repair=True)
    assert r.ok and len(env.store.read_partition(REL)) == 5


def test_manifest_pointing_at_missing_file_is_flagged_then_repaired(env):
    env.store.abs_path(REL).unlink()
    r = reconcile(env.repo, env.store)
    assert "manifest_file_missing" in r.kinds()
    reconcile(env.repo, env.store, repair=True)
    assert env.repo.manifest_get(REL)["status"] == "VERIFIED" and len(env.store.read_partition(REL)) == 5   # rebuilt from MySQL
    assert reconcile(env.repo, env.store).findings == []


def test_tampered_file_is_detected_by_checksum_and_quarantined_on_repair(env):
    p = env.store.abs_path(REL); p.write_bytes(p.read_bytes() + b"\x00")
    kinds = reconcile(env.repo, env.store).kinds()
    assert "checksum_mismatch" in kinds and "unreadable_file" in kinds      # diagnosis survives the corruption
    reconcile(env.repo, env.store, repair=True)
    assert len(list((env.store.root / "quarantine").glob("*.parquet"))) == 1
    assert reconcile(env.repo, env.store).findings == []                 # rebuilt from MySQL on the second pass


def test_interrupted_write_with_valid_file_is_promoted(env):
    with env.engine.begin() as c:
        c.execute(text("UPDATE fno_storage_manifest SET status='WRITING' WHERE relative_path=:p"), {"p": REL})
    assert "interrupted_write_valid" in reconcile(env.repo, env.store).kinds()
    assert reconcile(env.repo, env.store, repair=True).ok
    assert env.repo.manifest_get(REL)["status"] == "VERIFIED"


def test_orphans_and_stale_temp_files_only_touched_on_repair_and_only_inside_root(env, tmp_path):
    orphan = env.store.root / "candles/1m/underlying=X/expiry=2026-11-26/date=2026-10-19.parquet"
    orphan.parent.mkdir(parents=True); orphan.write_bytes(b"x")
    tmp = env.store.abs_path(REL).parent / ".date=2026-10-19.parquet.tmp-1-abc"; tmp.write_bytes(b"x")
    outside = tmp_path / "keep.txt"; outside.write_text("mine")
    r = reconcile(env.repo, env.store)
    assert {"orphan_file", "stale_temp_file"} <= set(r.kinds()) and orphan.exists() and tmp.exists()
    reconcile(env.repo, env.store, repair=True)
    assert not orphan.exists() and not tmp.exists() and outside.read_text() == "mine"


def test_checkpoint_claiming_absent_data_is_reported_never_auto_fixed(env):
    d = datetime.date(2026, 10, 5)
    env.repo.add_checkpoint_range(env.cid, "HISTORICAL", "1m", d, d, "VERIFIED")
    r = reconcile(env.repo, env.store, repair=True)
    assert r.kinds() == {"checkpoint_claims_absent_data": 1} and not r.ok
    assert env.repo.get_checkpoint_ranges(env.cid, "HISTORICAL", "1m") == [(d, d, "VERIFIED")]


# ------------------------------------------------ option-chain files are reconciled too
CHAIN_REL = "option_chain/underlying=NIFTY/date=2026-10-22.parquet"


@pytest.fixture()
def chain_env(env):
    from decimal import Decimal
    cap = datetime.datetime(2026, 10, 22, 10, 15, 30)
    rows = [{"contract_id": env.cid, "chain_expiry": EXP, "strike": Decimal("22350"), "side": "CE", "ltp": Decimal("66.4"), "bid": Decimal("66.3"),
             "ask": Decimal("66.5"), "volume": 5, "oi": 1000, "oi_change": 10, "iv": Decimal("15.96"), "delta": Decimal("0.5"),
             "gamma": None, "theta": None, "vega": None}]
    for batch in ("b1", "b2"):
        env.repo.insert_chain_snapshot(batch, "NIFTY", cap, rows)
        env.store.write_chain_snapshot([{**r, "batch_id": batch, "underlying": "NIFTY", "captured_at": cap} for r in rows], "NIFTY", cap.date())
    env.cap = cap
    return env


def test_consistent_chain_files_report_nothing(chain_env):
    assert reconcile(chain_env.repo, chain_env.store).findings == []


def test_chain_file_missing_after_moving_to_a_new_project_folder_is_found_and_rebuilt(chain_env):
    """Real case: a new project folder had no Parquet files while the shared database still called them VERIFIED."""
    chain_env.store.abs_path(CHAIN_REL).unlink()
    kinds = reconcile(chain_env.repo, chain_env.store).kinds()
    assert kinds["manifest_file_missing"] >= 1 and kinds["chain_mysql_parquet_mismatch"] == 1
    assert reconcile(chain_env.repo, chain_env.store, repair=True).ok
    import pandas as pd
    assert len(pd.read_parquet(chain_env.store.abs_path(CHAIN_REL))) == 2
    assert reconcile(chain_env.repo, chain_env.store).findings == []


def test_chain_rows_missing_from_mysql_are_restored_from_parquet(chain_env):
    with chain_env.engine.begin() as c:
        c.execute(text("DELETE FROM fno_option_chain_snapshots WHERE batch_id = 'b2'"))
    assert reconcile(chain_env.repo, chain_env.store).kinds() == {"chain_mysql_parquet_mismatch": 1}
    assert reconcile(chain_env.repo, chain_env.store, repair=True).ok
    with chain_env.engine.connect() as c:
        assert c.execute(text("SELECT COUNT(*) FROM fno_option_chain_snapshots")).scalar() == 2
    assert reconcile(chain_env.repo, chain_env.store).findings == []


def test_orphan_and_tampered_chain_files_are_handled(chain_env):
    orphan = chain_env.store.root / "option_chain/underlying=X/date=2026-10-22.parquet"
    orphan.parent.mkdir(parents=True); orphan.write_bytes(b"x")
    assert "orphan_file" in reconcile(chain_env.repo, chain_env.store).kinds() and orphan.exists()
    reconcile(chain_env.repo, chain_env.store, repair=True)
    assert not orphan.exists()
    p = chain_env.store.abs_path(CHAIN_REL); p.write_bytes(p.read_bytes() + b"\x00")
    assert "checksum_mismatch" in reconcile(chain_env.repo, chain_env.store).kinds()
