import datetime
from decimal import Decimal
from model.fno.normalizer import normalize_history_rows
from model.fno.models import IST


def ep(h, m, day=19, s=0):
    return int(datetime.datetime(2026, 10, day, h, m, s, tzinfo=IST).timestamp())


def test_valid_rows_oi_off_by_default_and_oi_when_enabled():
    rows = [[ep(9, 15), 100.1, 101, 99.5, 100.7, 120, 5000], [ep(9, 16), 100.7, 100.9, 100.2, 100.3, 0, 5100]]
    r = normalize_history_rows(rows, 7)
    assert len(r.valid) == 2 and not r.invalid and r.valid[0].oi is None
    assert r.valid[0].open == Decimal("100.1000") and r.valid[0].timestamp.hour == 9
    r2 = normalize_history_rows(rows, 7, oi_enabled=True)
    assert [c.oi for c in r2.valid] == [5000, 5100]
    assert normalize_history_rows([[ep(9, 15), 1, 2, 1, 1.5, 1]], 7, oi_enabled=True).valid[0].oi is None   # no 7th column -> None


def test_rejections_are_reported_with_reasons():
    rows = [[ep(9, 15), 100, 99, 98, 100, 1],            # high < open
            [ep(9, 16), 0, 1, 0, 1, 1],                   # zero price
            [ep(9, 10), 100, 101, 99, 100, 1],            # before session
            [ep(15, 40), 100, 101, 99, 100, 1],           # after last minute (15:39)
            [ep(9, 17, s=30), 100, 101, 99, 100, 1],      # not on a minute
            [ep(9, 19), 100, 101, 99, 100, -5],           # negative volume
            [ep(9, 20), "x", 101, 99, 100, 1], [1, 2], None]
    r = normalize_history_rows(rows, 1)
    assert not r.valid
    assert [x.reason for x in r.invalid] == ["invalid_ohlc", "non_positive_price", "outside_session", "outside_session",
        "timestamp_not_on_minute", "negative_volume", "unparseable_value", "malformed_row", "malformed_row"]
    assert r.raw_count == 9


def test_first_and_last_session_minutes_are_valid():
    r = normalize_history_rows([[ep(9, 15), 1, 2, 1, 1.5, 1], [ep(15, 39), 1, 2, 1, 1.5, 1]], 1)
    assert len(r.valid) == 2


def test_candles_between_1530_and_1539_are_valid_real_session_minutes():
    """Regression: the first draft rejected these (session end assumed 15:29); real data has 385 candles/day."""
    rows = [[ep(15, m), 100, 101, 99, 100, 1] for m in range(30, 40)]
    r = normalize_history_rows(rows, 1)
    assert len(r.valid) == 10 and not r.invalid


def test_weekend_rule_is_configurable_and_off_by_default():
    import dataclasses
    from model.fno.config import DEFAULT_SESSION
    sat = [[ep(9, 18, day=17), 100, 101, 99, 100, 1]]                      # Saturday 17 Oct 2026
    assert len(normalize_history_rows(sat, 1).valid) == 1
    strict = dataclasses.replace(DEFAULT_SESSION, reject_weekend_timestamps=True)
    assert normalize_history_rows(sat, 1, session=strict).invalid[0].reason == "weekend_timestamp"


def test_a_candle_repeated_inside_one_response_is_dropped_and_counted_separately():
    """Real FYERS output once showed raw == 2 x unique rows: that must not be confused with 'already stored'."""
    row = [ep(9, 15), 100, 101, 99, 100.5, 10, 777]
    r = normalize_history_rows([row, [ep(9, 16), 100, 101, 99, 100.5, 10, 778], row, row], 1, oi_enabled=True)
    assert len(r.valid) == 2 and r.response_duplicates == 2 and not r.invalid


def test_same_timestamp_with_different_values_is_invalid_not_silently_merged():
    a = [ep(9, 15), 100, 101, 99, 100.5, 10]; b = [ep(9, 15), 100, 105, 99, 100.5, 10]
    r = normalize_history_rows([a, b], 1)
    assert len(r.valid) == 1 and r.invalid[0].reason == "conflicting_duplicate_timestamp"
