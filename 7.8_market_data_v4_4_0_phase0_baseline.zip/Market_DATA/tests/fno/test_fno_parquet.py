import datetime
from decimal import Decimal

import pandas as pd
import pytest

from model.exceptions import ConfigurationError
from model.fno.errors import StorageVerificationError
from model.fno.parquet_store import FnoParquetStore, merge_candle_frames, candles_to_frame, KEY
from model.fno.repository import FnoRepository
from tests_support import make_candle, sample_contract

EXP = datetime.date(2026, 11, 26)


def frame(*cs):
    return candles_to_frame(list(cs))


# ------------------------------------------------------------- merge policy (no DB)
def test_merge_fresh_and_idempotent():
    f = frame(make_candle(1, 0), make_candle(1, 1))
    merged, st = merge_candle_frames(None, f)
    assert st["new_rows"] == 2
    again, st2 = merge_candle_frames(merged, f)
    assert st2["new_rows"] == 0 and st2["conflicts"] == 0
    pd.testing.assert_frame_equal(merged.reset_index(drop=True), again.reset_index(drop=True))


def test_merge_dedupes_inside_the_batch():
    merged, st = merge_candle_frames(None, frame(make_candle(1, 0), make_candle(1, 0), make_candle(1, 1)))
    assert len(merged) == 2 and st["duplicates"] == 1


def test_merge_closed_beats_open_and_open_never_beats_closed():
    ex, _ = merge_candle_frames(None, frame(make_candle(1, 0, h="101", status="OPEN")))
    m1, _ = merge_candle_frames(ex, frame(make_candle(1, 0, h="103", status="CLOSED", v=12)))
    assert m1.iloc[0]["status"] == "CLOSED" and m1.iloc[0]["high"] == 103.0
    m2, st = merge_candle_frames(m1, frame(make_candle(1, 0, h="999", status="OPEN")))
    assert m2.iloc[0]["high"] == 103.0 and m2.iloc[0]["status"] == "CLOSED"


def test_merge_conflicting_closed_is_dropped_counted_and_oi_not_taken():
    ex, _ = merge_candle_frames(None, frame(make_candle(1, 0, h="101", v=10)))
    m, st = merge_candle_frames(ex, frame(make_candle(1, 0, h="150", v=77, oi=500)))
    assert st["conflicts"] == 1 and m.iloc[0]["high"] == 101.0 and pd.isna(m.iloc[0]["oi"])


def test_merge_fills_null_optional_columns_only():
    ex, _ = merge_candle_frames(None, frame(make_candle(1, 0)))
    m, st = merge_candle_frames(ex, frame(make_candle(1, 0, oi=1200, iv=Decimal("0.18"))))
    assert m.iloc[0]["oi"] == 1200 and abs(m.iloc[0]["iv"] - 0.18) < 1e-9 and st["conflicts"] == 0
    m2, _ = merge_candle_frames(m, frame(make_candle(1, 0, oi=9999)))
    assert m2.iloc[0]["oi"] == 1200


# ------------------------------------------------------------- store with manifest
@pytest.fixture()
def store(tmp_path, clean_fno):
    return FnoParquetStore(tmp_path / "fno", FnoRepository(clean_fno))


META = {1: ("NIFTY", EXP), 2: ("NIFTY", EXP), 3: ("BANKNIFTY", EXP)}


def test_layout_one_file_per_underlying_expiry_date_with_many_contracts(store):
    cs = [make_candle(1, 0), make_candle(2, 0), make_candle(1, 1), make_candle(3, 0),
          make_candle(1, 0, day=datetime.date(2026, 10, 20))]
    res = store.write_candles(cs, META)
    assert sorted(res.files) == [
        "candles/1m/underlying=BANKNIFTY/expiry=2026-11-26/date=2026-10-19.parquet",
        "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet",
        "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-20.parquet"]
    df = store.read_partition("candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet")
    assert set(df["contract_id"]) == {1, 2} and len(df) == 3


def test_write_marks_manifest_verified_with_checksum_and_is_idempotent(store):
    rel = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"
    store.write_candles([make_candle(1, 0), make_candle(1, 1)], META)
    m = store.manifest.manifest_get(rel)
    assert m["status"] == "VERIFIED" and m["row_count"] == 2 and len(m["checksum"]) == 64
    assert m["checksum"] == FnoParquetStore.sha256(store.abs_path(rel))
    assert m["min_timestamp"] == datetime.datetime(2026, 10, 19, 9, 15) and m["max_timestamp"] == datetime.datetime(2026, 10, 19, 9, 16)
    r2 = store.write_candles([make_candle(1, 0), make_candle(1, 1)], META)
    assert r2.new_rows == 0 and store.manifest.manifest_get(rel)["row_count"] == 2


def test_failed_validation_leaves_previous_file_and_manifest_intact_and_no_temp(store, monkeypatch):
    rel = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"
    store.write_candles([make_candle(1, 0)], META)
    before = FnoParquetStore.sha256(store.abs_path(rel))

    def boom(path, expected):
        raise StorageVerificationError("simulated bad temp file")
    monkeypatch.setattr(FnoParquetStore, "_validate", staticmethod(boom))
    with pytest.raises(StorageVerificationError):
        store.write_candles([make_candle(1, 1)], META)
    assert FnoParquetStore.sha256(store.abs_path(rel)) == before            # old file untouched
    m = store.manifest.manifest_get(rel)
    assert m["status"] == "VERIFIED" and m["row_count"] == 1                # manifest restored
    assert store.stale_temp_files() == []


def test_first_write_failure_quarantines_the_manifest_row(store, monkeypatch):
    def boom(path, expected):
        raise StorageVerificationError("bad")
    monkeypatch.setattr(FnoParquetStore, "_validate", staticmethod(boom))
    with pytest.raises(StorageVerificationError):
        store.write_candles([make_candle(1, 0)], META)
    rel = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"
    assert store.manifest.manifest_get(rel)["status"] == "QUARANTINED"
    assert not store.abs_path(rel).exists()


def test_untrusted_existing_file_is_quarantined_not_merged(store):
    rel = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"
    path = store.abs_path(rel); path.parent.mkdir(parents=True)
    candles_to_frame([make_candle(1, 5, h="777")]).to_parquet(path, index=False)      # no manifest row
    res = store.write_candles([make_candle(1, 0)], META)
    assert res.quarantined_existing == [rel]
    df = store.read_partition(rel)
    assert len(df) == 1 and df.iloc[0]["high"] != 777.0
    assert len(list((store.root / "quarantine").glob("*.parquet"))) == 1


def test_readers_use_only_verified_entries(store):
    rel = "candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet"
    store.write_candles([make_candle(1, 0)], META)
    assert store.read_partition(rel) is not None
    store.manifest.manifest_quarantine(rel, "manual")
    assert store.read_partition(rel) is None


def test_cleanup_is_dry_run_by_default_and_needs_confirmation(store):
    store.write_candles([make_candle(1, 0, day=datetime.date(2026, 1, 5)), make_candle(1, 0)], META)
    today = datetime.date(2026, 10, 19)
    dry = store.cleanup_old_files(retain_days=30, today=today)
    assert dry == ["candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-01-05.parquet"]
    assert len(store.list_candle_files()) == 2                               # nothing deleted
    with pytest.raises(ConfigurationError):
        store.cleanup_old_files(retain_days=30, dry_run=False, today=today)   # no confirm
    assert len(store.list_candle_files()) == 2
    store.cleanup_old_files(retain_days=30, dry_run=False, confirm=True, today=today)
    assert len(store.list_candle_files()) == 1
    assert store.manifest.manifest_get(dry[0]) is None                        # manifest row removed with the file


def test_root_is_mandatory_and_guard_blocks_escape(tmp_path, clean_fno):
    with pytest.raises(ConfigurationError):
        FnoParquetStore("", None)
    s = FnoParquetStore(tmp_path / "fno", None)
    for bad in ("../outside.parquet", "/etc/passwd"):
        with pytest.raises(ConfigurationError):
            s.abs_path(bad)


def test_merge_history_supersedes_live_but_live_never_changes_history():
    live, _ = merge_candle_frames(None, frame(make_candle(1, 0, h="101", v=3, source="FYERS_LIVE")))
    m, st = merge_candle_frames(live, frame(make_candle(1, 0, h="103", v=40, oi=777, source="FYERS_HISTORICAL")))
    assert m.iloc[0]["high"] == 103.0 and m.iloc[0]["volume"] == 40 and m.iloc[0]["oi"] == 777 and st["conflicts"] == 0
    assert m.iloc[0]["source"] == "FYERS_HISTORICAL"
    m2, st2 = merge_candle_frames(m, frame(make_candle(1, 0, h="101", v=3, source="FYERS_LIVE")))
    assert m2.iloc[0]["high"] == 103.0 and st2["conflicts"] == 0 and m2.iloc[0]["source"] == "FYERS_HISTORICAL"


def test_merge_two_live_candles_that_disagree_is_a_conflict():
    live, _ = merge_candle_frames(None, frame(make_candle(1, 0, h="101", source="FYERS_LIVE")))
    assert merge_candle_frames(live, frame(make_candle(1, 0, h="150", source="FYERS_LIVE")))[1]["conflicts"] == 1


def test_history_merge_keeps_contracts_that_only_the_live_stream_had(store):
    """Regression for a reconcile question: a history write for SOME contracts must not drop other contracts' rows."""
    meta = {i: ("NIFTY", EXP) for i in range(1, 6)}
    store.write_candles([make_candle(i, m, source="FYERS_LIVE") for i in range(1, 6) for m in range(3)], meta)
    store.write_candles([make_candle(i, m, source="FYERS_HISTORICAL", oi=5) for i in range(1, 4) for m in range(6)], meta)
    df = store.read_partition(store.list_candle_files()[0])
    assert set(df["contract_id"]) == {1, 2, 3, 4, 5} and len(df[df.contract_id.isin([4, 5])]) == 6
