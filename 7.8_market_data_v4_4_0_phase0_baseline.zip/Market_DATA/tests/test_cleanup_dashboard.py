"""Actual Streamlit controls: no destructive dispatch without reviewed confirmation."""
from types import SimpleNamespace
import pytest
from streamlit.testing.v1 import AppTest

service=None

class FakeService:
    catalog=SimpleNamespace(factories={'CASH':None,'FNO':None})
    def __init__(self):
        self.calls=[]
        self.fail=False
        self.status='SUCCESS'
    def preview(self,**kwargs):
        self.calls.append(('preview',kwargs))
        return dict(kwargs,database='test_db',token='review-token',row_counts={'candles':2})
    def apply(self,plan,**kwargs):
        self.calls.append(('apply',plan,kwargs))
        if self.fail:raise RuntimeError('private database password')
        return {'status':self.status,'journal':'local journal'}


@pytest.fixture
def app():
    global service
    service=FakeService()
    return AppTest.from_string("from test_cleanup_dashboard import service\nfrom ui.cleanup_page import render_page\nrender_page(service,'admin',lambda pw: pw=='correct')",default_timeout=15).run()


def preview(app):
    app.text_input(key='cleanup_symbol').set_value('NSE:SBIN-EQ').run()
    app.button(key='cleanup_preview').click().run()
    assert not app.exception


def confirm(app,password='correct'):
    for c in app.checkbox:c.check()
    app.text_input(key='cleanup_confirmation_review-token').set_value('CLEANUP test_db')
    app.text_input(key='cleanup_password_review-token').set_value(password).run()


def test_no_apply_without_review_confirmation_and_password(app):
    assert service.calls==[]
    preview(app)
    assert app.button(key='cleanup_apply').disabled
    confirm(app,'wrong')
    app.button(key='cleanup_apply').click().run()
    assert not any(c[0]=='apply' for c in service.calls)
    confirm(app)
    app.button(key='cleanup_apply').click().run()
    assert not app.exception and len([c for c in service.calls if c[0]=='apply'])==1
    assert 'cleanup_plan' not in app.session_state


def test_changed_input_discards_review(app):
    preview(app)
    app.selectbox(key='cleanup_segment').select('FNO').run()
    assert not app.exception and 'cleanup_plan' not in app.session_state
    assert not any(b.key=='cleanup_apply' for b in app.button)


def test_uncertain_failure_consumes_plan_and_masks_provider_error(app):
    preview(app); confirm(app)
    service.fail=True
    app.button(key='cleanup_apply').click().run()
    assert not app.exception and 'cleanup_plan' not in app.session_state
    assert 'private database password' not in str([e.value for e in app.error])


def test_partial_result_is_not_success(app):
    preview(app); confirm(app)
    service.status='RECOVERY_NEEDED'
    app.button(key='cleanup_apply').click().run()
    assert not app.exception and app.error and not app.success


def test_non_admin_never_calls_service():
    global service
    service=FakeService()
    app=AppTest.from_string("from test_cleanup_dashboard import service\nfrom ui.cleanup_page import render_page\nrender_page(service,'user',lambda pw: True)").run()
    assert not app.exception and app.error and service.calls==[]
