from pathlib import Path
import pytest
from model.storage_inventory import inventory, fingerprint
from controller.inventory_cli import main

CASH = 'raw/1m/NSE_SBIN-EQ/2026-10-23.parquet'
FNO = 'candles/1m/underlying=NIFTY/expiry=2026-10-27/date=2026-10-23.parquet'


def put(root, rel, content=b'fixture bytes'):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(content)
    return p


@pytest.fixture
def roots(tmp_path):
    old, cash, fno = [tmp_path / name for name in ('old', 'cash', 'fno')]
    for p in (old, cash, fno): p.mkdir()
    return old, cash, fno


def test_duplicate_missing_and_conflict_are_distinct(roots):
    old, cash, fno = roots
    put(old / 'v1/data', CASH)
    put(old / 'v2/data', CASH)
    put(cash, CASH)
    put(old / 'v1/data/fno', FNO, b'a')
    put(old / 'v2/data/fno', FNO, b'b')
    report = inventory([old], cash, fno)
    a, b = report['partitions']
    assert a['status'] == 'TARGET_PRESENT'
    assert len(a['identical_byte_groups'][0]) == 3
    assert b['status'] == 'DIFFERENT_BYTES_REVIEW'
    assert not b['target_present']
    assert report['complete']


def test_missing_candidate_and_no_source_changes(roots):
    old, cash, fno = roots
    p = put(old, CASH)
    before = (p.read_bytes(), p.stat().st_mtime_ns)
    r = inventory([old], cash, fno)
    assert r['partitions'][0]['status'] == 'MISSING_TARGET_CANDIDATE'
    assert (p.read_bytes(), p.stat().st_mtime_ns) == before
    assert not list(cash.iterdir())


def test_overlapping_search_roots_are_deduplicated(roots):
    old, cash, fno = roots
    put(old / 'v1', CASH)
    put(cash, CASH)
    r = inventory([old.parent, old, old / 'v1'], cash, fno)
    assert r['summary']['classified_files'] == 2


def test_unrecognized_paths_make_report_incomplete(roots):
    old, cash, fno = roots
    put(old, 'unknown.parquet')
    put(old / 'backups', CASH)
    r = inventory([old], cash, fno)
    assert not r['complete']
    assert len(r['unclassified']) == 1
    assert len(r['excluded_directories']) == 1


def test_link_not_followed(roots, monkeypatch):
    import model.storage_inventory as module
    old, cash, fno = roots
    p = put(old / 'linked', CASH)
    monkeypatch.setattr(module, 'linked', lambda x: x == old / 'linked')
    r = inventory([old], cash, fno)
    assert not r['complete']
    assert r['summary']['classified_files'] == 0
    assert p.exists()


def test_hash_errors_reported(roots, monkeypatch):
    import model.storage_inventory as module
    old, cash, fno = roots
    put(old, CASH)
    def fail(path): raise PermissionError('test')
    monkeypatch.setattr(module, 'fingerprint', fail)
    r = inventory([old], cash, fno)
    assert not r['complete']
    assert r['issues'][0]['error'] == 'PermissionError'


def test_cli_report_and_no_overwrite(roots, tmp_path):
    old, cash, fno = roots
    put(old, CASH)
    out = tmp_path / 'inventory.json'
    args = ['--source', str(old), '--cash-root', str(cash), '--fno-root', str(fno), '--output', str(out)]
    assert main(args) == 0
    original = out.read_bytes()
    with pytest.raises(SystemExit): main(args)
    assert out.read_bytes() == original


def test_root_guards(roots):
    old, cash, fno = roots
    with pytest.raises(ValueError): inventory([old / 'missing'], cash, fno)
    with pytest.raises(ValueError): inventory([old], cash, cash)


def test_changed_file_detected(tmp_path, monkeypatch):
    p = put(tmp_path, 'test.parquet')
    real = Path.stat
    calls = []
    def stat(self, *args, **kwargs):
        if self == p:
            calls.append(1)
            if len(calls) == 2:
                p.write_bytes(b'changed and longer')
        return real(self, *args, **kwargs)
    monkeypatch.setattr(Path, 'stat', stat)
    with pytest.raises(ValueError, match='changed'):
        fingerprint(p)
