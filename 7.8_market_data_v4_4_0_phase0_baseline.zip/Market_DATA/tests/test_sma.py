from datetime import datetime,timedelta,timezone
from decimal import Decimal,localcontext
import pytest
from indicators.sma import Sma

START=datetime(2026,10,23,9,15,tzinfo=timezone(timedelta(hours=5,minutes=30)))

def replay(prices,period=3):
    calc=Sma(period)
    return [calc.update(START+timedelta(minutes=i),Decimal(str(p))) for i,p in enumerate(prices)]

def test_hand_calculated_warmup_and_rolling_values():
    out=replay([10,20,30,40,50])
    assert out[:2]==[None,None]
    assert [x.value for x in out[2:]]==[Decimal(20),Decimal(30),Decimal(40)]
    assert out[2].candle_timestamp==START+timedelta(minutes=2)


def test_prefix_invariance_no_future_leak():
    prices=[100,110,90,120,80,130,70]
    full=replay(prices)
    for end in range(1,len(prices)+1):assert replay(prices[:end])==full[:end]
    assert replay(prices[:4]+[9999]*3)[:4]==full[:4]


def test_context_independent_and_precise():
    with localcontext() as c:
        c.prec=3
        a=replay(['100.123456789','100.123456789','100.123456789'])[-1]
    assert a.value==Decimal('100.123456789')
    assert replay([1,2,2])[-1].value==Decimal('1.666666666666666666666666666666667')


@pytest.mark.parametrize('period',[0,-1,True,1.2,100001])
def test_bad_period(period):
    with pytest.raises(ValueError):Sma(period)


def test_period_one_and_constant_series():
    assert [x.value for x in replay([1,2,3],1)]==list(map(Decimal,[1,2,3]))
    assert all(x.value==Decimal(4) for x in replay([4]*50,20)[19:])


def test_rejected_update_does_not_mutate_state():
    calc=Sma(2)
    assert calc.update(START,Decimal(10)) is None
    for stamp,value in [(START,Decimal(99)),(START-timedelta(minutes=1),Decimal(1)),
        (START+timedelta(minutes=1),Decimal('NaN')),(START.replace(tzinfo=None),Decimal(1))]:
        with pytest.raises(ValueError):calc.update(stamp,value)
    assert calc.update(START+timedelta(minutes=1),Decimal(20)).value==Decimal(15)


def test_streams_are_isolated():
    a,b=Sma(2),Sma(2)
    a.update(START,Decimal(10));b.update(START,Decimal(100))
    assert a.update(START+timedelta(minutes=1),Decimal(20)).value==15
    assert b.update(START+timedelta(minutes=1),Decimal(200)).value==150
