from types import SimpleNamespace
import pytest
from model import recovery_config
from controller import recovery_cli


def test_config_builds_separate_engine_without_opening_live_database(monkeypatch):
    from model import recovery_verification
    monkeypatch.setenv('RECOVERY_DB_NAME','tios_recovery_example')
    monkeypatch.setenv('RECOVERY_DB_USER','recovery_reader')
    monkeypatch.setenv('RECOVERY_DB_PASSWORD','private')
    monkeypatch.setattr(recovery_config,'configured_catalog',lambda:SimpleNamespace(roots={}))
    captured={}
    def create(url,**kwargs):
        captured.update(url=url,kwargs=kwargs)
        return 'fresh-engine'
    monkeypatch.setattr(recovery_config,'create_engine',create)
    monkeypatch.setattr(recovery_verification,'RecoveryVerifier',lambda backup,engine,live:(backup,engine,live))
    result=recovery_config.configured_verifier()
    assert result[1]=='fresh-engine'
    assert captured['url'].database=='tios_recovery_example'
    assert captured['url'].username=='recovery_reader'
    assert captured['kwargs']['poolclass'].__name__=='NullPool'


@pytest.mark.parametrize('name',['market_data','fno_market_data','tios_recovery_demo;DROP DATABASE market_data',''])
def test_configuration_rejects_live_or_unsafe_targets(monkeypatch,name):
    monkeypatch.setenv('RECOVERY_DB_NAME',name)
    with pytest.raises(ValueError):recovery_config.configured_verifier()


def test_cli_auth_before_configuration(monkeypatch,capsys):
    monkeypatch.setattr('sys.argv',['recovery_cli','--list-staged'])
    def denied():raise PermissionError('secret password')
    monkeypatch.setattr(recovery_cli,'authenticate_admin',denied)
    monkeypatch.setattr(recovery_cli,'configured_verifier',lambda:pytest.fail('Must authenticate first'))
    assert recovery_cli.main()==1
    assert 'secret password' not in capsys.readouterr().out


@pytest.mark.parametrize('status,expected',[('VERIFIED',0),('FAILED',2)])
def test_cli_verification_exit_code(monkeypatch,status,expected):
    monkeypatch.setattr('sys.argv',['recovery_cli','--backup-id','a'*32,'--recovery-id','a'*32+'_12345678','--confirmation','VERIFY tios_recovery_demo'])
    monkeypatch.setattr(recovery_cli,'authenticate_admin',lambda:None)
    monkeypatch.setattr(recovery_cli,'configured_verifier',lambda:SimpleNamespace(verify=lambda *a,**k:{'status':status}))
    assert recovery_cli.main()==expected
