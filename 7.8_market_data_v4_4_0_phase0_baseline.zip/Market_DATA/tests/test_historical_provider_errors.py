from unittest.mock import Mock

import pytest

from model.config.data_settings import RetrySettings
from model.exceptions import HistoricalAvailabilityError, HistoricalProviderError
from model.fyers import historical


@pytest.fixture
def retry(monkeypatch):
    monkeypatch.setattr(historical.time, "sleep", Mock())
    return RetrySettings(max_retries=2, initial_backoff_seconds=0, backoff_multiplier=2)


def test_plan_rejection_preserves_diagnostic_and_stops_full_backfill(retry):
    client = Mock()
    client.history.return_value = {
        "s": "error", "code": -50, "message": "Invalid input",
        "data": {"range_from": "range_from exceeds the historical data available for your plan"},
    }
    with pytest.raises(HistoricalAvailabilityError) as raised:
        historical.fetch_historical_1m(client, "NSE:NIFTYBANK-INDEX", "2024-02-01", "2026-10-26", retry)
    error = raised.value
    assert error.code == -50
    assert error.category == "history_unavailable"
    assert not error.retryable
    assert error.range_from == "2024-02-01"
    assert error.range_to == "2024-04-30"
    assert "historical data available for your plan" in str(error)
    assert client.history.call_count == 1
    assert client.history.call_args.kwargs["data"]["range_from"] == "2024-02-01"


def test_validation_error_keeps_fields_without_account_payload_or_credentials(retry):
    client = Mock()
    client.history.return_value = {
        "s": "error", "code": -50, "message": "Invalid input access_token=secret Bearer private",
        "data": {"range_from": 'Invalid date "authorization": "quoted private"', "access_token": "hidden", "account": {"id": "private"}},
        "refresh_token": "also-hidden",
    }
    with pytest.raises(HistoricalProviderError) as raised:
        historical.fetch_historical_1m(client, "NSE:TEST", "2026-10-01", "2026-10-02", retry)
    error = raised.value
    assert type(error) is HistoricalProviderError
    assert error.details == {"range_from": 'Invalid date "authorization=[REDACTED]'}
    for secret in ("secret", "private", "hidden", "also-hidden"):
        assert secret not in str(error)
    assert client.history.call_count == 1


def test_real_rate_limit_still_retries_then_returns_candles(retry):
    rows = [[123, 1, 2, 0, 1, 10]]
    client = Mock()
    client.history.side_effect = [
        {"s": "error", "code": 429, "message": "Too many requests"},
        {"s": "ok", "candles": rows},
    ]
    assert historical.fetch_historical_1m(client, "NSE:TEST", "2026-10-01", "2026-10-02", retry) == rows
    assert client.history.call_count == 2


def test_unrelated_rate_substring_does_not_trigger_retry(retry):
    client = Mock()
    client.history.return_value = {"s": "error", "code": -50, "message": "Cannot generate history"}
    with pytest.raises(HistoricalProviderError):
        historical.fetch_historical_1m(client, "NSE:TEST", "2026-10-01", "2026-10-02", retry)
    assert client.history.call_count == 1


def test_successful_multichunk_request_preserves_original_ranges(retry, monkeypatch):
    monkeypatch.setattr(historical, "MAX_DAYS_PER_REQUEST_1M", 2)
    client = Mock()
    client.history.side_effect = [{"s": "ok", "candles": [[1]]}, {"s": "ok", "candles": []}]
    assert historical.fetch_historical_1m(client, "NSE:TEST", "2026-10-01", "2026-10-03", retry) == [[1]]
    assert [(call.kwargs["data"]["range_from"], call.kwargs["data"]["range_to"])
            for call in client.history.call_args_list] == [("2026-10-01", "2026-10-02"), ("2026-10-03", "2026-10-03")]


def test_malformed_provider_response_is_a_permanent_structured_error(retry):
    client = Mock()
    client.history.return_value = "private provider dump"
    with pytest.raises(HistoricalProviderError, match="Malformed historical response"):
        historical.fetch_historical_1m(client, "NSE:TEST", "2026-10-01", "2026-10-02", retry)
    assert client.history.call_count == 1
