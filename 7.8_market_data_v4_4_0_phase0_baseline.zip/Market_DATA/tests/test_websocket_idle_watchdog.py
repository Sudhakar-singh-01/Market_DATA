import logging
import threading
from model.fyers.websocket import FyersWebSocketClient


def client():
    c=FyersWebSocketClient.__new__(FyersWebSocketClient)
    c._watchdog_stop=threading.Event()
    c._last_message_time=0
    c._transport_state='CONNECTED'
    c._last_watchdog_state=None
    c._last_watchdog_log=0
    return c


def test_idle_info_is_throttled_and_not_critical(monkeypatch,caplog):
    c=client();now=[100.]
    monkeypatch.setattr('model.fyers.websocket.time.monotonic',lambda:now[0])
    with caplog.at_level(logging.INFO):
        c._watchdog_once();now[0]=110;c._watchdog_once()
    assert len(caplog.records)==1
    assert caplog.records[0].levelno==logging.INFO
    assert 'FEED_IDLE' in caplog.text and 'does not prove' in caplog.text


def test_recovered_activity_logged_without_healthy_claim(monkeypatch,caplog):
    c=client();monkeypatch.setattr('model.fyers.websocket.time.monotonic',lambda:100.)
    with caplog.at_level(logging.INFO):
        c._watchdog_once();c._last_message_time=99;c._watchdog_once()
    assert len(caplog.records)==2
    assert 'RECENT_MESSAGE' in caplog.text
    assert 'looks alive' not in caplog.text


def test_stop_interrupts_wait_without_post_stop_log(caplog):
    c=client()
    thread=threading.Thread(target=c._run_watchdog);thread.start()
    c._watchdog_stop.set();thread.join(.5)
    assert not thread.is_alive()
    with caplog.at_level(logging.INFO):c._watchdog_once()
    assert not caplog.records


def test_late_sdk_callbacks_ignored_after_stop():
    c=client();c._watchdog_stop.set()
    c._on_tick=lambda msg:(_ for _ in ()).throw(AssertionError('late tick forwarded'))
    c._handle_message({'symbol':'REAL','ltp':100})
    c._handle_connect();c._handle_error({'token':'not_logged'});c._handle_close({})
    assert c._last_message_time==0
