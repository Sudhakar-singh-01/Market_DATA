import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


import pytest
@pytest.fixture(autouse=True)
def isolated_runtime_budget(tmp_path,monkeypatch):
    """Tests cannot spend/reset the installation's persisted account allowance."""
    from model.fyers.rate_limiter import configure_shared_limiter
    monkeypatch.setenv('TIOS_RUNTIME_DIR',str(tmp_path/'runtime'))
    configure_shared_limiter(None)
    yield
    configure_shared_limiter(None)
