"""Dashboard adapter against isolated SQL tables; no implicit worker/provider calls."""
import json
from types import SimpleNamespace
import pytest
from sqlalchemy import text
from test_read_api import env
from ui.workflow_service import WorkflowDashboardService
from model.fno.errors import DuplicateJobError


@pytest.fixture
def service(env):
    calls=[]
    def action(*args,**kwargs):calls.append(args);return 88
    commands=SimpleNamespace(job_action=action)
    result=WorkflowDashboardService(env[0].catalog,commands)
    result.test_calls=calls
    with env[1]['CASH'].begin() as conn:
        conn.execute(text('ALTER TABLE ingestion_jobs ADD COLUMN params TEXT'))
        conn.execute(text('ALTER TABLE ingestion_jobs ADD COLUMN result TEXT'))
        conn.execute(text("UPDATE ingestion_jobs SET job_type='WORKFLOW',state='PARTIAL',params=:p,result=:r WHERE id=4"),{
            'p':json.dumps({'password':'private','workflow':{'segment':'CASH','from':'2026-10-16','to':'2026-10-16',
                'targets':[{'symbol':'NSE:SBIN-EQ','internal_name':'SBIN','secret':'hidden'}],'timeframes':['1m']}}),
            'r':json.dumps({'version':1,'stage':'BLOCKED','ready':False,'stage_progress':{'token':'private'}})})
    return result


def test_monitor_readonly_and_bounded_with_safe_scope(service):
    page=service.list_jobs('CASH',role='admin',state='PARTIAL',limit=1)
    assert [r['id'] for r in page['data']]==[4]
    job=service.get_job('CASH',4,role='admin')
    assert job['reviewed_scope']['targets']==[{'symbol':'NSE:SBIN-EQ','internal_name':'SBIN'}]
    assert 'private' not in str(job) and 'hidden' not in str(job)
    assert service.test_calls==[]
    with pytest.raises(ValueError):service.list_jobs('CASH',role='admin',limit=51)
    with pytest.raises(ValueError):service.list_jobs('CASH',role='admin',offset=-1)


def test_backend_rechecks_job_kind_state_and_role(service,env):
    with pytest.raises(PermissionError):service.action('CASH','resume',4,role='user')
    assert service.test_calls==[]
    assert service.action('CASH','resume',4,role='admin')['new_job_id']==88
    assert service.test_calls==[('CASH','resume',4)]
    with env[1]['CASH'].begin() as c:c.execute(text("UPDATE ingestion_jobs SET state='CANCELLED' WHERE id=4"))
    with pytest.raises(ValueError):service.action('CASH','resume',4,role='admin')
    with env[1]['CASH'].begin() as c:c.execute(text("UPDATE ingestion_jobs SET job_type='VERIFY',state='PARTIAL' WHERE id=4"))
    with pytest.raises(ValueError,match='not a unified'):service.action('CASH','resume',4,role='admin')


def test_duplicate_submission_reports_existing_job():
    def duplicate(*a,**k):raise DuplicateJobError(99)
    service=WorkflowDashboardService(commands=SimpleNamespace(submit_workflow=duplicate))
    assert service.submit({'segment':'FNO'},role='admin')=={'segment':'FNO','job_id':99,'existing':True}


def test_role_gate_precedes_lazy_configuration():
    service=WorkflowDashboardService()
    for operation in (lambda:service.options('CASH',role='user'),lambda:service.list_jobs('CASH',role='user'),
                      lambda:service.submit({},role='user'),lambda:service.preview('CASH',{},[],role='user')):
        with pytest.raises(PermissionError):operation()
    assert service._catalog is None and service._commands is None
