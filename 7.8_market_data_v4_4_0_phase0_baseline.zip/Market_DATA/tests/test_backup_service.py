"""Archive recovery safety and exact scalar encoding; no production databases."""
import datetime as dt
import decimal
import hashlib
import json
import stat
import zipfile
from contextlib import nullcontext
from types import SimpleNamespace
import pytest
from model.backup_service import BackupService,sql_literal


@pytest.fixture
def service(tmp_path):
    data=tmp_path/'data'; data.mkdir(); (data/'one.parquet').write_bytes(b'parquet-test-content')
    catalog=SimpleNamespace(roots={'CASH':data})
    class LocalBackup(BackupService):
        def preview(self,segment,*,role):
            self._admin(role)
            _,files=self._files(segment)
            return {'segment':segment,'database':'test_cash','files':files}
        def _dump_database(self,engine,path):
            path.write_text('CREATE TABLE sample (id INT);\nINSERT INTO sample VALUES (1);\n')
            return {'sample':1}
    result=LocalBackup(catalog,tmp_path/'backups',tmp_path/'recovery')
    result.guard=SimpleNamespace(_engine=lambda segment:object(),_database_lock=lambda engine:nullcontext())
    return result


def create(service):
    return service.create(service.preview('CASH',role='admin'),role='admin',writers_stopped=True)


def test_backup_verify_and_stage_preserves_live_source(service):
    result=create(service)
    verified=service.verify(result['backup_id'],role='admin')
    assert verified['manifest']['tables']=={'sample':1}
    assert verified['manifest']['restore_tested'] is False
    assert len(service.list_backups(role='admin'))==1
    before=(service.catalog.roots['CASH']/'one.parquet').read_bytes()
    staged=service.stage_recovery(verified,role='admin',confirmation='STAGE '+result['backup_id'])
    from pathlib import Path
    dest=Path(staged['path'])
    assert (dest/'parquet/one.parquet').read_bytes()==before
    assert (dest/'database.sql').is_file()
    assert staged['database_modified'] is False
    assert (service.catalog.roots['CASH']/'one.parquet').read_bytes()==before


def test_roles_and_writer_ack_required(service):
    plan=service.preview('CASH',role='admin')
    with pytest.raises(PermissionError): service.create(plan,role='user',writers_stopped=True)
    with pytest.raises(ValueError,match='Stop all'): service.create(plan,role='admin')
    with pytest.raises(PermissionError): service.list_backups(role='user')
    with pytest.raises(PermissionError): service.verify('bad',role='user')
    with pytest.raises(PermissionError): service.stage_recovery({},role='user',confirmation='x')
    assert not service.backup_root.exists()


def test_stale_source_plan_rejected(service):
    plan=service.preview('CASH',role='admin')
    (service.catalog.roots['CASH']/'one.parquet').write_bytes(b'changed')
    with pytest.raises(ValueError,match='scope changed'): service.create(plan,role='admin',writers_stopped=True)


def test_writer_during_dump_leaves_no_completed_backup(service,monkeypatch):
    original=service._dump_database
    def changed(engine,path):
        result=original(engine,path)
        (service.catalog.roots['CASH']/'added.parquet').write_bytes(b'late')
        return result
    monkeypatch.setattr(service,'_dump_database',changed)
    with pytest.raises(ValueError,match='files changed'): create(service)
    assert list(service.backup_root.iterdir())==[]


def test_dump_failure_cleans_partial_files(service,monkeypatch):
    def fail(*args): raise RuntimeError('failure')
    monkeypatch.setattr(service,'_dump_database',fail)
    with pytest.raises(RuntimeError): create(service)
    assert list(service.backup_root.iterdir())==[]


def test_changed_archive_rejected_after_preview(service):
    result=create(service); verified=service.verify(result['backup_id'],role='admin')
    path=service._archive(result['backup_id'])
    with path.open('ab') as f: f.write(b'changed')
    with pytest.raises(ValueError,match='changed'): service.stage_recovery(verified,role='admin',confirmation='STAGE '+result['backup_id'])
    assert list(service.recovery_root.iterdir())==[]


def write_archive(service,extra_name=None,bad_checksum=False):
    service.backup_root.mkdir(exist_ok=True)
    ident='a'*32; path=service.backup_root/(ident+'.zip')
    contents={'database.sql':b'SELECT 1;'}
    if extra_name: contents[extra_name]=b'x'
    manifest={'format':'tios-backup-v1','segment':'CASH','members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in contents.items()}}
    if bad_checksum: manifest['members']['database.sql']['sha256']='0'*64
    with zipfile.ZipFile(path,'w') as z:
        for n,b in contents.items(): z.writestr(n,b)
        z.writestr('manifest.json',json.dumps(manifest))
    return ident


@pytest.mark.parametrize('name',['../outside','parquet/../../outside','parquet/a\\b','parquet/C:/x','parquet/CON.txt','parquet/a.','parquet/a/./b','parquet/a?b'])
def test_unsafe_archive_paths_rejected(service,name):
    ident=write_archive(service,name)
    with pytest.raises(ValueError,match='Unsafe'): service.verify(ident,role='admin')


def test_corrupt_checksum_rejected(service):
    ident=write_archive(service,bad_checksum=True)
    with pytest.raises(ValueError,match='checksum'): service.verify(ident,role='admin')


def test_archive_size_limit_and_identifier_validation(service,monkeypatch):
    ident=write_archive(service)
    monkeypatch.setattr('model.backup_service.MAX_EXPANDED_BYTES',1)
    with pytest.raises(ValueError,match='size limit'): service.verify(ident,role='admin')
    with pytest.raises(ValueError,match='identifier'): service.verify('../outside',role='admin')


def test_symlink_sources_and_overlapping_roots_rejected(service,tmp_path):
    root=service.catalog.roots['CASH']
    (root/'linked').symlink_to(root/'one.parquet')
    with pytest.raises(ValueError,match='Symlinks'): service._files('CASH')
    (root/'linked').unlink()
    service.catalog.roots['FNO']=root/'raw'
    with pytest.raises(ValueError,match='overlap'): service._files('CASH')


def test_literals_preserve_numeric_binary_and_text():
    assert sql_literal(None)=='NULL'
    assert sql_literal(decimal.Decimal('123456789.12345678'))=='123456789.12345678'
    assert sql_literal(b'\x00\xff')=="X'00ff'"
    assert sql_literal("a'\\\n") == "CONVERT(X'61275c0a' USING utf8mb4)"
    assert sql_literal(dt.datetime(2026,10,25,9,15,0,123456))=="'2026-10-25 09:15:00.123456'"
    assert sql_literal(dt.timedelta(microseconds=-1))=="'-00:00:00.000001'"
    with pytest.raises(ValueError): sql_literal(float('nan'))
    with pytest.raises(ValueError): sql_literal(dt.datetime.now(dt.timezone.utc))


def test_output_path_symlink_cannot_hide_overlap(service,tmp_path):
    alias=tmp_path/'alias'; alias.symlink_to(service.catalog.roots['CASH'],target_is_directory=True)
    service.backup_root=alias/'backups'
    with pytest.raises(ValueError,match='outside'): service._files('CASH')


def test_nested_fno_is_excluded_from_cash_backup(service):
    cash=service.catalog.roots['CASH']; fno=cash/'fno'
    fno.mkdir(); (fno/'contract.parquet').write_bytes(b'fno-only')
    service.catalog.roots['FNO']=fno
    result=create(service)
    with zipfile.ZipFile(result['path']) as archive:
        assert 'parquet/one.parquet' in archive.namelist()
        assert not any('/fno/' in name for name in archive.namelist())
    assert set(service._files('FNO')[1]) == {'contract.parquet'}
    assert (fno/'contract.parquet').read_bytes()==b'fno-only'
