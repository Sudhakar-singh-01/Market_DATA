import pytest
from sqlalchemy.dialects.mysql import BIGINT, INTEGER, TINYINT, VARCHAR, DECIMAL
from model.schema_compatibility import compatibility_report, parse_definition, _type
from model.schema_management import owned_definitions

DDL = '''CREATE TABLE instruments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 symbol VARCHAR(80) NOT NULL, price DECIMAL(14,4) NULL,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE KEY uq_symbol (symbol), INDEX idx_price (price)
) ENGINE=InnoDB'''


class Inspector:
    def __init__(self):
        self.columns = [dict(name='id', type=BIGINT(unsigned=True), nullable=False, autoincrement=True),
                        dict(name='symbol', type=VARCHAR(80), nullable=False),
                        dict(name='price', type=DECIMAL(14, 4), nullable=True),
                        dict(name='active', type=TINYINT(display_width=1), nullable=False, default='1')]
        self.indexes = [dict(name='uq_symbol', column_names=['symbol'], unique=True),
                        dict(name='idx_price', column_names=['price'], unique=False)]
        self.names = ['instruments']
        self.pk = ['id']
        self.fks = []
    def get_table_names(self): return self.names
    def get_columns(self, table): return self.columns
    def get_indexes(self, table): return self.indexes
    def get_unique_constraints(self, table): return []
    def get_pk_constraint(self, table): return {'constrained_columns': self.pk}
    def get_foreign_keys(self, table): return self.fks
    def get_table_options(self, table): return {'mysql_engine': 'InnoDB'}
    def get_check_constraints(self, table): return []


def report(inspector):
    return compatibility_report(inspector, {'instruments': DDL}, 'CASH')


def test_every_owned_definition_is_supported():
    for segment in ('CASH', 'FNO'):
        definitions = owned_definitions(segment)
        assert definitions
        for sql in definitions.values():
            assert parse_definition(sql)['columns']


def test_matching_reflection_and_boolean_alias():
    assert report(Inspector())['status'] == 'COMPATIBLE'
    assert _type('INTEGER(11) UNSIGNED') == 'INTUNSIGNED'
    assert _type('DATETIME(0)') == 'DATETIME'
    assert _type('DATETIME(3)') != _type('DATETIME')


def test_type_nullable_unsigned_precision_and_primary_drift():
    inspector = Inspector()
    inspector.columns[0]['type'] = BIGINT()
    inspector.columns[1]['nullable'] = True
    inspector.columns[2]['type'] = DECIMAL(18, 4)
    inspector.pk = ['symbol']
    result = report(inspector)
    assert result['status'] == 'INCOMPATIBLE'
    assert {f['name'] for f in result['findings']} == {'id', 'symbol', 'price', 'PRIMARY'}
    assert all(f['severity'] == 'BLOCKING' for f in result['findings'])


def test_missing_objects_and_extensions_are_distinct_and_deterministic():
    inspector = Inspector()
    inspector.columns.pop()
    inspector.columns.append(dict(name='custom', type=INTEGER(), nullable=True))
    inspector.names += ['custom_table']
    result = report(inspector)
    assert result['status'] == 'MISSING'
    assert [f['severity'] for f in result['findings']] == ['EXTENSION', 'MISSING', 'EXTENSION']
    assert result == report(inspector)
    inspector.names = []
    assert report(inspector)['findings'][0]['kind'] == 'table'


def test_wrong_index_same_name_blocks_and_missing_index_is_missing():
    inspector = Inspector()
    inspector.indexes[0]['unique'] = False
    inspector.indexes.pop()
    findings = report(inspector)['findings']
    assert {(f['name'], f['severity']) for f in findings} == {('uq_symbol', 'BLOCKING'), ('idx_price', 'MISSING')}


def test_foreign_key_target_and_order_are_checked():
    sql = DDL.replace('INDEX idx_price (price)', 'INDEX idx_price (price), CONSTRAINT fk_parent FOREIGN KEY (id) REFERENCES parents(id)')
    inspector = Inspector()
    inspector.fks = [dict(name='fk_parent', constrained_columns=['id'], referred_table='wrong', referred_columns=['id'])]
    result = compatibility_report(inspector, {'instruments': sql}, 'CASH')
    assert result['findings'][0]['kind'] == 'foreign_key'
    assert result['status'] == 'INCOMPATIBLE'


def test_pipeline_additions_are_expected_without_generating_ddl():
    sql = 'CREATE TABLE ingestion_jobs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY) ENGINE=InnoDB'
    inspector = Inspector()
    inspector.names = ['ingestion_jobs']
    inspector.columns = inspector.columns[:1]
    inspector.indexes = []
    result = compatibility_report(inspector, {'ingestion_jobs': sql}, 'CASH')
    missing = {f['name'] for f in result['findings']}
    assert {'active_key', 'params', 'cancel_requested', 'uq_pipeline_active'} <= missing
    assert result['status'] == 'MISSING'
    assert all(f['severity'] == 'MISSING' for f in result['findings'])


@pytest.mark.parametrize('sql', [DDL.replace('VARCHAR(80)', 'ENUM(1,2)'), DDL.replace('NOT NULL, price', 'NOT NULL FROB, price'), DDL + '; DROP TABLE instruments'])
def test_unknown_repository_grammar_fails_closed(sql):
    with pytest.raises(ValueError): parse_definition(sql)


def test_segment_ownership_fails_closed():
    with pytest.raises(ValueError): compatibility_report(Inspector(), {'instruments': DDL}, 'FNO')


def test_definition_key_must_match_declared_table():
    with pytest.raises(ValueError):
        compatibility_report(Inspector(), {'wrong': DDL}, 'CASH')


def test_extra_required_column_blocks_existing_insert_contract():
    inspector=Inspector()
    inspector.columns.append(dict(name='mandatory_extension',type=INTEGER(),nullable=False))
    result=report(inspector)
    assert result['status']=='INCOMPATIBLE'
    assert next(f for f in result['findings'] if f['name']=='mandatory_extension')['severity']=='BLOCKING'


def test_default_autoincrement_and_engine_drift():
    inspector = Inspector()
    inspector.columns[0]['autoincrement'] = False
    inspector.columns[3]['default'] = '0'
    inspector.get_table_options = lambda table: {'mysql_engine': 'MyISAM'}
    result = report(inspector)
    assert result['status'] == 'INCOMPATIBLE'
    assert {f['name'] for f in result['findings']} == {'id', 'active', 'instruments'}


def test_timestamp_default_on_update_normalization():
    from sqlalchemy.dialects.mysql import DATETIME
    sql = '''CREATE TABLE instruments (stamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB'''
    inspector = Inspector()
    inspector.columns = [dict(name='stamp', type=DATETIME(), nullable=False,
                             default='current_timestamp() ON UPDATE current_timestamp()')]
    inspector.pk = []
    inspector.indexes = []
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['compatible']
    inspector.columns[0]['default'] = 'current_timestamp()'
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['status'] == 'INCOMPATIBLE'


def test_unavailable_engine_metadata_is_unverified():
    inspector = Inspector()
    inspector.get_table_options = lambda table: {}
    result = report(inspector)
    assert result['status'] == 'CHECKED_WITH_LIMITATIONS'
    assert not result['compatible']
    assert result['findings'][0]['severity'] == 'UNVERIFIED'


def test_index_prefix_drift_and_extra_restrictive_index():
    inspector = Inspector()
    inspector.indexes[0]['dialect_options'] = {'mysql_length': {'symbol': 20}}
    inspector.indexes.append(dict(name='custom_unique', column_names=['price'], unique=True))
    result = report(inspector)
    assert {f['name'] for f in result['findings']} == {'uq_symbol', 'custom_unique'}
    assert all(f['severity'] == 'BLOCKING' for f in result['findings'])


def test_foreign_key_default_schema_normalizes_and_cross_database_blocks():
    sql = DDL.replace('INDEX idx_price (price)', 'INDEX idx_price (price), CONSTRAINT fk_parent FOREIGN KEY (id) REFERENCES parents(id)')
    inspector = Inspector()
    inspector.default_schema_name = 'cash'
    inspector.fks = [dict(name='fk_parent', constrained_columns=['id'], referred_table='parents', referred_columns=['id'], referred_schema='cash')]
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['compatible']
    inspector.fks[0]['referred_schema'] = 'other'
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['status'] == 'INCOMPATIBLE'
    inspector.fks.append(dict(name='custom', constrained_columns=['id'], referred_table='parents', referred_columns=['id']))
    assert all(f['severity'] == 'BLOCKING' for f in compatibility_report(inspector, {'instruments': sql}, 'CASH')['findings'])


def test_check_missing_changed_and_unavailable_reflection():
    sql = DDL.replace('INDEX idx_price (price)', 'INDEX idx_price (price), CONSTRAINT chk_price CHECK (price > 0)')
    inspector = Inspector()
    inspector.get_check_constraints = lambda table: [{'name': 'chk_price', 'sqltext': '(`price` > 0)'}]
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['compatible']
    inspector.get_check_constraints = lambda table: [{'name': 'chk_price', 'sqltext': 'price > 1'}]
    assert compatibility_report(inspector, {'instruments': sql}, 'CASH')['status'] == 'INCOMPATIBLE'


def test_foreign_key_cascade_blocks():
    sql = DDL.replace('INDEX idx_price (price)', 'INDEX idx_price (price), CONSTRAINT fk_parent FOREIGN KEY (id) REFERENCES parents(id)')
    inspector = Inspector()
    inspector.fks = [dict(name='fk_parent', constrained_columns=['id'], referred_table='parents', referred_columns=['id'], options={'ondelete': 'CASCADE'})]
    result = compatibility_report(inspector, {'instruments': sql}, 'CASH')
    assert result['status'] == 'INCOMPATIBLE'
    assert result['findings'][0]['actual']['ondelete'] == 'CASCADE'
