from pathlib import Path
from types import SimpleNamespace
import pytest
from sqlalchemy.engine import URL
from streamlit.testing.v1 import AppTest

service=None

class FakeService:
    def __init__(self,root):
        self.backup_service=SimpleNamespace(recovery_root=root)
        self.recovery_engine=SimpleNamespace(url=URL.create('mysql+pymysql',host='localhost',port=3306,database='tios_recovery_demo',password='hidden-secret'))
        self.calls=[];self.status='VERIFIED'
    def verify(self,*args,**kwargs):
        self.calls.append((args,kwargs))
        return {'status':self.status,'market_parity':'NOT_TESTED','restore_tested':False}


@pytest.fixture
def app(tmp_path):
    global service
    for name in ['a'*32+'_12345678','b'*32+'_12345678']:(tmp_path/name).mkdir()
    service=FakeService(tmp_path)
    return AppTest.from_string("from test_recovery_dashboard import service\nfrom ui.recovery_page import render_page\nrender_page(service,'admin',lambda pw: pw=='correct')",default_timeout=15).run()


def confirm(app,password='correct'):
    app.checkbox[0].check()
    next(w for w in app.text_input if w.key.startswith('recovery_confirm_')).set_value('VERIFY tios_recovery_demo')
    next(w for w in app.text_input if w.key.startswith('recovery_password_')).set_value(password).run()


def test_review_authentication_then_scoped_result(app):
    assert not app.exception and service.calls==[]
    assert app.button(key='recovery_verify').disabled
    confirm(app,'wrong')
    app.button(key='recovery_verify').click().run()
    assert service.calls==[]
    confirm(app)
    app.button(key='recovery_verify').click().run()
    assert not app.exception and len(service.calls)==1
    assert 'market-data parity' in app.success[0].value


def test_switch_stage_hides_prior_report_and_confirmation(app):
    confirm(app)
    app.button(key='recovery_verify').click().run()
    app.selectbox(key='recovery_stage').select('b'*32+'_12345678').run()
    assert not app.exception and not app.success
    assert app.button(key='recovery_verify').disabled


def test_failed_report_is_not_success(app):
    service.status='FAILED'
    confirm(app)
    app.button(key='recovery_verify').click().run()
    assert not app.exception and app.error and not app.success


def test_non_admin_never_reaches_service(app):
    before=list(service.calls)
    view=AppTest.from_string("from test_recovery_dashboard import service\nfrom ui.recovery_page import render_page\nrender_page(service,'user',lambda pw: True)").run()
    assert not view.exception and view.error and service.calls==before
