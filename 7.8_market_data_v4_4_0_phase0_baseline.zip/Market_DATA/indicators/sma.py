"""SMA v1: close-price, trailing N observed verified candles, no session reset.

This calculation kernel owns no fetching, storage, scheduling or event routing.
Caller supplies one chronological verified stream per instance. A timestamp is
candle START, not signal availability: output may only be used after candle close.
"""
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, Context, localcontext, ROUND_HALF_EVEN


@dataclass(frozen=True)
class SmaValue:
    candle_timestamp: datetime
    period: int
    value: Decimal
    version: str = 'SMA_CLOSE_V1'


class Sma:
    def __init__(self, period=20):
        if type(period) is not int or not 1 <= period <= 100000:
            raise ValueError('period must be an integer from 1 to 100000')
        self.period = period
        self._window = deque(maxlen=period)
        self._last = None

    def update(self, timestamp, close):
        if not isinstance(timestamp, datetime) or timestamp.utcoffset() is None:
            raise ValueError('Timestamp must be timezone-aware')
        if self._last is not None and timestamp <= self._last:
            raise ValueError('Duplicate or unordered candle; replay corrected data in a fresh instance')
        if not isinstance(close, Decimal) or not close.is_finite():
            raise ValueError('Close must be a finite Decimal')
        # Stage first: failed arithmetic must not advance the stream.
        window = list(self._window)
        window.append(close)
        window = window[-self.period:]
        output = None
        if len(window) == self.period:
            # Explicit context gives repeatable output independent of caller context.
            with localcontext(Context(prec=34, rounding=ROUND_HALF_EVEN)):
                value = sum(window, Decimal(0)) / Decimal(self.period)
            if not value.is_finite():
                raise ValueError('Non-finite SMA')
            output = SmaValue(timestamp, self.period, value)
        self._window.append(close)
        self._last = timestamp
        return output
