"""Consumer smoke check/export: python -m client --help."""
import argparse
import getpass
import json
import os
from pathlib import Path
import tempfile
from .market_data import MarketDataClient,MarketDataClientError


def main():
    parser=argparse.ArgumentParser(description='Read TIOS candles through GET only; optional atomic JSONL page export')
    parser.add_argument('--segment',choices=['CASH','FNO'],required=True)
    parser.add_argument('--symbol',required=True)
    parser.add_argument('--timeframe',default='1m')
    parser.add_argument('--from-date',required=True)
    parser.add_argument('--to-date',required=True)
    parser.add_argument('--quality',choices=['verified','raw'],default='verified')
    parser.add_argument('--allow-sparse',action='store_true')
    parser.add_argument('--page-size',type=int,default=1000)
    parser.add_argument('--output',type=Path,help='New JSONL file, one complete API page per line; existing files are never overwritten')
    args=parser.parse_args()
    password=os.environ.get('MARKET_DATA_API_PASSWORD') or getpass.getpass('Market data API password: ')
    temporary=None; output=None
    try:
        if args.output:
            if args.output.exists(): raise ValueError('Output already exists; choose a new path')
            args.output.parent.mkdir(parents=True,exist_ok=True)
            output=tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',newline='\n',prefix='.market-data-',suffix='.tmp',dir=args.output.parent,delete=False)
            temporary=Path(output.name)
        pages=rows=0
        with MarketDataClient(os.environ.get('MARKET_DATA_API_URL','http://127.0.0.1:8000'),
                username=os.environ.get('MARKET_DATA_API_USER','user'),password=password) as client:
            for page in client.iter_candle_pages(args.segment,args.symbol,args.timeframe,args.from_date,args.to_date,
                    quality=args.quality,allow_sparse=args.allow_sparse,limit=args.page_size):
                pages+=1; rows+=len(page['data'])
                if output: output.write(json.dumps(page,ensure_ascii=False)+'\n')
        if output:
            output.flush(); os.fsync(output.fileno()); output.close()
            # Publish only after every page succeeds; hard-link creation refuses existing paths.
            os.link(temporary,args.output)
        print(json.dumps({'status':'COMPLETE','pages':pages,'rows':rows,'quality_requested':args.quality,
                          'allow_sparse':args.allow_sparse,'output':str(args.output) if args.output else None,
                          'note':'Live-view pagination; complete download does not imply a cross-request snapshot'}))
        return 0
    except (MarketDataClientError,ValueError,OSError) as exc:
        print(json.dumps({'status':'FAILED','error':type(exc).__name__,
                          'message':str(exc) if isinstance(exc,(MarketDataClientError,ValueError)) else 'Local export operation failed'}))
        return 1
    finally:
        if output and not output.closed: output.close()
        if temporary: temporary.unlink(missing_ok=True)


if __name__=='__main__':
    raise SystemExit(main())
