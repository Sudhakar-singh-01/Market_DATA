"""Bounded, fully materialized verified input. No database/provider imports."""
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from .market_data import DataQualityError, ProtocolError, _timestamp


@dataclass(frozen=True)
class ConsumerCandle:
    timestamp: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    oi: Decimal | None


@dataclass(frozen=True)
class CandleBatch:
    segment: str
    symbol: str
    timeframe: str
    session: str
    candles: tuple[ConsumerCandle, ...]
    pages: int
    # These are page-level observations, never an atomic snapshot certificate.
    coverage: tuple[str, ...]
    checked_at: tuple[str | None, ...]


def _number(value, field):
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise ProtocolError(f'{field} must be a numeric string or number')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ProtocolError(f'Invalid {field}') from None
    if not result.is_finite():
        raise ProtocolError(f'Non-finite {field}')
    return result


def load_verified_batch(client, segment, symbol, timeframe, start, end, *,
                        session=None, page_size=1000, max_pages=1000, max_rows=100000):
    """Return only after ALL pages succeed; no sorting, filling or deduplication.

    CASH defaults to regular sessions; FNO uses the API's all-session policy.
    Sparse data and empty batches are rejected. Caller owns client lifetime.
    Bounded in memory; multi-request reads remain a live view.
    """
    if type(max_rows) is not int or max_rows < 1:
        raise ValueError('max_rows must be a positive integer')
    segment = str(segment).upper()
    if session is None:
        session = 'regular' if segment == 'CASH' else 'all'
    rows, coverage, checked = [], [], []
    previous = None
    for page in client.iter_candle_pages(segment, symbol, timeframe, start, end,
            quality='verified', closed_only=True, allow_sparse=False, session=session,
            limit=page_size, max_pages=max_pages):
        q = page['quality']
        if q.get('status') != 'VERIFIED' or q.get('coverage') not in ('COMPLETE', 'NO_SESSION'):
            raise DataQualityError('Complete verified coverage required')
        coverage.append(q['coverage']); checked.append(q.get('checked_at'))
        for row in page['data']:
            if len(rows) >= max_rows:
                raise DataQualityError('Consumer row limit exceeded; reduce date range')
            timestamp = _timestamp(row.get('candle_timestamp'))
            if previous is not None and timestamp <= previous:
                raise ProtocolError('Duplicate or unordered consumer candles')
            numbers = {key: _number(row.get(key), key) for key in ('open','high','low','close','volume')}
            if not (numbers['low'] <= min(numbers['open'], numbers['close']) <=
                    max(numbers['open'], numbers['close']) <= numbers['high']) or numbers['volume'] < 0:
                raise ProtocolError('Invalid consumer OHLCV')
            oi = None if row.get('oi') is None else _number(row['oi'], 'oi')
            if oi is not None and oi < 0:
                raise ProtocolError('Negative open interest')
            rows.append(ConsumerCandle(timestamp=timestamp, oi=oi, **numbers))
            previous = timestamp
    if not rows:
        raise DataQualityError('No candles available for calculation')
    return CandleBatch(segment, symbol, timeframe, session, tuple(rows), len(coverage), tuple(coverage), tuple(checked))
