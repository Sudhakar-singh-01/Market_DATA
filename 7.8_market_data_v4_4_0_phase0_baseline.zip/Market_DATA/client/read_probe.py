"""Bounded GET-only integration checks; timing is observation, not a benchmark."""
import datetime as dt
from decimal import Decimal
from time import perf_counter
from .market_data import AuthenticationError

FIELDS=('open','high','low','close','volume')


class ProbeFinding(ValueError):
    pass


def require(value,message):
    if not value:raise ProbeFinding(message)


def candle_values(rows):
    return [(r['candle_timestamp'],r['timeframe'],*(Decimal(str(r[k])) for k in FIELDS),r['source'],r['status']) for r in rows]


def run_probe(client, day, cash_symbol, *, fno_symbol=None, underlying=None, progress=None):
    day=dt.date.fromisoformat(day).isoformat()
    checks=[]; baseline=None; started=perf_counter()
    def run(name,fn):
        t=perf_counter()
        try:
            details=fn();result=dict(check=name,status='PASS',**details)
        except AuthenticationError:
            raise  # Never repeat all checks with invalid credentials.
        except Exception as exc:
            result=dict(check=name,status='FINDINGS',error=type(exc).__name__)
            if isinstance(exc,ProbeFinding):result['reason']=str(exc)
            code=getattr(exc,'status_code',None)
            if code is not None:result['http_status']=code
        result['seconds']=round(perf_counter()-t,3);checks.append(result)
        if progress:progress(result)
        return result
    def cash(tf):
        nonlocal baseline
        p=client.get_candles('CASH',cash_symbol,tf,day,day,quality='verified',session='regular',limit=1000)
        require(p['data'] and p['meta']['next_cursor'] is None,'Expected a nonempty complete single-day page')
        require(p['quality']['coverage']=='COMPLETE','Cash coverage must be complete')
        if tf=='1m':baseline=p
        return dict(rows=len(p['data']),quality=p['quality'],session_filter=p['meta']['session_filter'])
    for tf in ('1m','5m','15m','30m','1h','1d'):
        run('cash_verified_'+tf,lambda tf=tf:cash(tf))
    def pagination():
        require(baseline is not None,'Fresh verified 1m baseline unavailable')
        # Small 200-row pages exercise keyset paging without repeatedly re-verifying stores.
        rows=[];pages=0
        for p in client.iter_candle_pages('CASH',cash_symbol,'1m',day,day,quality='raw',session='regular',limit=200,max_pages=10):
            pages+=1;rows.extend(p['data'])
            require(p['meta']['session_filter']['scope_rows']==len(baseline['data']),'Scope changed during pagination')
            require(p['meta']['session_filter']['excluded_rows']==baseline['meta']['session_filter']['excluded_rows'],'Exclusion count changed during pagination')
        require(candle_values(rows)==candle_values(baseline['data']),'Paged values differ from fresh verified baseline; possible concurrent writes')
        return dict(rows=len(rows),pages=pages,evidence='Raw SQL pages matched fresh verified baseline; not an atomic snapshot')
    run('cash_pagination',pagination)
    if fno_symbol:
        def fno_raw():
            p=client.get_candles('FNO',fno_symbol,'1m',day,day,quality='raw',limit=2)
            require(bool(p['data']),'FNO raw sample empty')
            return dict(rows=len(p['data']),quality=p['quality'],evidence='Sample only')
        def fno_verified():
            p=client.get_candles('FNO',fno_symbol,'1m',day,day,quality='verified',allow_sparse=True,limit=1000)
            require(bool(p['data']) and p['meta']['next_cursor'] is None,'FNO verified page empty or exceeds probe bound')
            if p['quality']['coverage']=='SPARSE_UNCONFIRMED':
                raise ProbeFinding('FNO values verified but option coverage remains sparse/unconfirmed')
            require(p['quality']['coverage']=='COMPLETE','FNO coverage must be complete')
            return dict(rows=len(p['data']),quality=p['quality'])
        run('fno_raw_sample',fno_raw);run('fno_verified_1m',fno_verified)
    if underlying:
        def chain():
            p=client.get_option_chain(underlying,day,day,limit=2)
            require(bool(p['data']),'No stored option-chain sample in requested scope')
            require(all(r.get('underlying')==underlying and r.get('batch_id') for r in p['data']), 'Option-chain identity/batch missing')
            return dict(rows=len(p['data']),quality=p['quality'],evidence='Stored snapshot sample only; not verified historical option coverage')
        run('option_chain_sample',chain)
    return dict(status='SCOPED_READ_CHECK_PASS' if all(x['status']=='PASS' for x in checks) else 'FINDINGS',
        date=day,cash_symbol=cash_symbol,fno_symbol=fno_symbol,underlying=underlying,
        checks=checks,seconds=round(perf_counter()-started,3),
        market_data_modified=False,sql_modified=False,
        scope='Selected symbol/date and endpoints only. No provider request, write, repair, or full-database certification. Timings include client/server/storage/auth overhead.')
