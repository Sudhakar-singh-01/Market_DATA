# FYERS / NSE integration evidence — 24 October 2026

The implementation separates provider documentation, installed SDK capability and real-account evidence. Current documentation does not prove that a particular token/plan has returned data successfully. No live FYERS request was made during this build.

## Account policy

The current Standard Data API documentation gives 5 requests/second, 50/minute and 5,000/day, and 100 DataSocket symbols in total. The app uses margins of 4/45/4,500 and a shared local account budget. Other applications' requests cannot be measured by this ledger. Regular intraday lookback is limited to one year; Smart Fetch does not bulk-probe older ranges.

Source: https://fyers.in/api-docs/v3/getting-started/plans-and-limits/

## Method mapping

| Need | Documented SDK method | Installed 3.1.10 | App behavior |
|---|---|---|---|
| Regular active-contract / Cash candles | `history` | Present | Existing adapter; canonical 1m |
| Option-chain snapshot | `optionchain` | Present | Existing FNO chain adapter and nullable optional fields |
| Expiry discovery | `expiry_dates` | Absent | Capability check; no guessed endpoint |
| Contracts for an expired expiry | `history_underlying_symbols` | Absent | Capability check, exact returned symbols required |
| Expired contract candles | `fno_historical_data` | Absent | Explicit adapter; unsupported SDK reports unavailable |
| Current futures chain | `futures_chain` | Absent | Capability check; existing master still lists futures |

`model/fno/capabilities.py` implements the capability/discovery boundary. `FnoHistoryFetcher.fetch_expired` uses the expired method, not regular history as a fallback. No SDK installation/upgrade occurs automatically. Official change log documents newer SDK support; validate a compatible upgrade in a separate environment before changing a working installation.

Source: https://fyers.in/api-docs/v3/changelog/

## Regular history and option-chain scope

History requests use exact broker symbols. Intraday requests are bounded to 100 days by the existing FNO chunk planner; Cash Smart Fetch narrows to missing minute ranges. Regular optional OI is distinct from expired-schema optional columns. A forming minute must not certify a completed session. Continuous/stitched futures are not substituted for an actual contract.

Source: https://fyers.in/api-docs/v3/api/market-data/historical-data/

Option-chain data is a snapshot. Its timestamp/expiry selection is not evidence of an arbitrary multi-year historical chain API. IV/Greeks are nullable; unavailable values remain NULL. Current documentation describes the `greeks` flag and strike-window limits. Existing supplied account reports remain historical evidence, not a guarantee for every contract/date.

Source: https://fyers.in/api-docs/v3/api/market-data/option-chain/

## Expired flow

Discovery starts from the exact underlying, an ordered date range (at most 366 days), then an expiry. The contract-list response supplies futures/options symbols. These symbols alone do not establish missing lot/tick/listing metadata; the app does not invent it or create duplicate masters.

Sources:

- https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expiry-dates/
- https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expired-contracts/
- https://fyers.in/api-docs/v3/api/market-data/futures-chain/

Expired intraday has a separate Standard allowance of 10 requests/day; the local shared limiter reserves one for each attempt. The expired response must provide named `columns`; optional fields are mapped by name, with `iv` and `implied_volatility` accepted as IV aliases. Null remains null. Greeks are requested only for options, and not MCX. Missing/unrecognized layout rejects rows instead of guessing optional positions. Invalid-symbol errors remain reviewable failures; neither age nor disabled retrieval proves irrecoverability. The retained `expired_history.max_age_days` setting is compatibility metadata, not an availability cutoff.

Source: https://fyers.in/api-docs/v3/api/market-data/expired-fo-data/get-expired-fo-data/

## Authentication

Current FYERS documentation describes daily token expiry around 06:30 IST and authentication errors including -8/-15/-16/-17. The app classifies rejection, stops automatic retries and exposes credential reload/resume. Individual-account automatic OAuth refresh is not assumed. Secrets stay in the existing environment configuration; no report needs an access token.

Source: https://fyers.in/api-docs/v3/api/authentication/

## Exchange calendar evidence

The committed 2026 holiday list is based on separate Cash and FNO circulars. November 8 Muhurat session timing remains unknown in this version; it is not interpreted as an ordinary Sunday or assumed standard session. FNO current normal timing is 09:15–15:40, with the documented change effective August 3, 2026. FNO dates before that effective point remain unverified by this release's calendar evidence. Cash policy covers the configured normal session; auction/CAS instrument eligibility is not modeled in the supplied schema.

Sources:

- https://nsearchives.nseindia.com/content/circulars/CMTR71775.pdf
- https://nsearchives.nseindia.com/content/circulars/FAOP71777.pdf
- https://nsearchives.nseindia.com/content/circulars/FAOP75472.pdf
- https://www.nseindia.com/static/market-data/market-timings

Do not treat unchanged older account reports (`FNO_API_FINDINGS.md`) or old comments about larger subscription/daily limits as the current Standard entitlement. The Release 4 configuration and this specification supersede those policy defaults while retaining the original reports for traceability.
