# Step 5: unified historical workflow

`MarketDataService` now previews/submits one durable WORKFLOW job for Cash or FNO:

1. FETCH: existing smart fetch/harvest performs provider access, normalization,
   cleaning, validation and dual-store persistence using its current quota/retry rules.
2. AGGREGATE (optional): existing canonical-1m aggregation builds requested derived
   timeframes. 1m is always included in the final verification scope.
3. VERIFY: strict consumer read verification checks every frozen symbol/day/timeframe
   against SQL and Parquet, market calendar and canonical source where applicable.
4. READY: only after every required check passes complete coverage and at least one
   candle exists. Job state is SUCCESS, with result.ready=true and verified_at.

No new job tables, migrations or child-job dispatcher are required. Existing stores,
deduplication, claims, heartbeat, counters and explicit resume continue to manage
one parent job. Stage progress lives in that job's result JSON. Existing standalone
fetch, aggregation and broad diagnostic VERIFY jobs keep their previous behavior.
The broad diagnostic report has observations (such as live telemetry) that do not
prove historical readiness; workflow readiness uses the stricter read boundary.

## Scope and limitations

- Both SQL and Parquet are required. Only historical days before today are accepted.
- Maximum 31 inclusive days, 200 explicit targets, 5000 target-days per workflow.
- Verified calendar evidence is required throughout the requested range.
- Cash targets are explicit configured internal names; their FYERS mappings are
  checked again before work starts.
- FNO preview freezes the currently selected active contracts and ATM reference.
  Fetch and aggregation cannot expand into unrelated/new contracts. Contract ID to
  symbol mappings are checked again at execution. Expired retrieval still obeys the
  existing harvester's capability rules; this is not a multi-year options archive.
- A fetch/aggregation PARTIAL, FAILED, NO_DATA, CANCELLED or INTERRUPTED outcome stops
  the workflow. No silent success is inferred from an empty fetch plan; it must pass
  strict verification of the requested stored data.
- Sparse options that lack complete coverage remain BLOCKED/PARTIAL. Their values
  can still be read through the existing verified client with explicit allow_sparse;
  this workflow does not call sparse coverage complete. Missing minutes are not
  fabricated or filled with zeros.
- An entirely empty holiday scope returns NO_DATA with ready=false.
- Verification runs across multiple reads, not one immutable database/filesystem
  snapshot. READY is job evidence at verified_at, not a durable certificate. Consumers
  must keep requesting quality=verified so later modifications are checked again.
- Cancellation is terminal under existing job rules. Resume supports FAILED, PARTIAL
  or INTERRUPTED jobs; resume reuses the frozen params and reruns the existing stages.
  To retry a deliberately CANCELLED workflow, create/review a fresh workflow.

## Python service

```python
from controller.market_data_service import MarketDataService
service = MarketDataService()
plan = service.preview_workflow(
    'CASH',
    {'from':'2026-10-16', 'to':'2026-10-16', 'symbols':['SBIN']},
    role='admin', timeframes=['1m', '5m'],
)
# Review plan['fetch_plan'], plan['params']['workflow'], and plan['stages'].
submitted = service.submit_workflow(plan, role='admin')
```

For FNO, use the existing historical selection parameters, e.g. underlyings,
expiries_ahead, strike_window, include_futures and include_options. ATM preview may
make a provider quote request. Empty contract selections are rejected. The workflow
preview is fingerprinted; editing the returned plan invalidates submission. This
fingerprint is an integrity check, not remote authentication. Python role arguments
remain trusted internal contracts; the headless command authenticates the admin.

Do not launch a submit-only short script and immediately exit: the existing UI
workers are process-local daemon threads. Keep the service host alive or use the
headless run command below, which waits for the terminal state.

## Headless preview/run

Prepare your existing fetch params in a JSON file, such as:

```json
{"from":"2026-10-16","to":"2026-10-16","symbols":["SBIN"]}
```

From the repository root:

```sh
python -m controller.workflow_cli preview --segment CASH --params cash_params.json --timeframes 1m 5m --output reviewed_workflow.json
python -m controller.workflow_cli run --preview reviewed_workflow.json --confirm
```

Commands prompt for the existing admin password. For noninteractive local use,
MARKET_DATA_ADMIN_PASSWORD supplies it through the process environment. Database/
FYERS configuration remains in existing config/.env. Preview does not submit a job.
Run prints the durable job ID and waits; exit code 0 means ready, 2 means a terminal
non-ready outcome, 1 command failure, 130 forced interruption. Ctrl+C first requests
cancellation and waits for the active stage boundary; a second Ctrl+C exits. Abrupt
termination can leave RUNNING until heartbeat recovery marks it INTERRUPTED.
Inspect that persisted job before explicitly resuming or submitting again.

## Status for other modules

The existing authenticated endpoint stays GET-only:

```text
GET /api/v1/jobs/42?segment=CASH
```

For WORKFLOW jobs, each status row includes a small `workflow` summary: stage, ready,
verified_at, coverage, completed_checks, total_checks, verified_rows and stage states.
Nested stage/provider errors and original params are not exposed. Public ready is
forced false unless the persisted job state is SUCCESS, even if interruption left
an earlier ready marker in progress JSON. Use `MarketDataClient.get_job_status`.

Step 6 adds Administration → Unified Workflow for reviewed submission, progress and
confirmed cancel/resume/queue controls. See WORKFLOW_DASHBOARD.md. The headless command
and read-only status endpoint remain available.

## Validation

Tests cover stage ordering, propagation of all terminal states, cancellation at
stage boundaries, sparse/empty outcomes, immutable target scope, modified-preview
rejection, role checks, existing FNO handler registration, safe public status, and
actual Cash SQL/Parquet readiness followed by mutation rejection. A disposable-MySQL
persistence/resume test is included and skips without its test server. Real FYERS
fetching, MySQL full workflow execution and Windows CLI remain deployment checks.
