# Combined Cash recovery: one plan, explicit insert-only apply

This stage revisits every Cash raw/1m partition in cash_preview_01.json using
current source bytes, current SQL and the permanent destination. It does not
trust old preview statuses as permission. Previously restored consistent
partitions are reported ALREADY_CONSISTENT. Reported remaining scope was 203
partitions, including 122 Parquet-only partitions; fresh results determine the
actual eligible and unresolved counts.

Windows CMD, in the new extracted directory containing main.py:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_recovery_cli plan --preview "F:/TIOS_Runtime/cash_preview_01.json" --output "F:/TIOS_Runtime/cash_recovery_plan_01.json"
```

Enter the existing application administrator password. Stop dashboards, live
feeds, ingestion, cleanup and schema writers for a stable preview/apply.
Planning writes only this new JSON report; no locks, backup, SQL writes or market
files are created. Current source files must still exist at the preview paths.
New report files never overwrite existing reports.

The plan has three categories:
- ALREADY_CONSISTENT: current source, SQL and destination match at the existing
  comparison precision; no action required.
- READY: a usable source contains all existing SQL rows with equal values,
  optional missing rows can be inserted, and the target file is either absent
  or already row-equivalent. Only these entries can be applied.
- UNRESOLVED: metadata/schema/file failures, conflicting usable variants,
  existing SQL conflicts/extra/invalid rows, or a different destination file.
  Reasons, SQL quality and per-variant quality/comparison details are retained.

The selector never chooses a conflicting source by date, filename or size. It
can use a valid alternate instead of an invalid old variant, but the selected
variant must be a value-consistent superset of every other usable variant. It
does not synthesize a union of incomparable partial variants. No source is
deleted. Unknown calendar and incomplete minute coverage are preserved as
warnings, not automatic blockers. Naive timezone ambiguity, malformed records,
wrong symbol/metadata, duplicate keys and known outside-session records still
need review. Partial valid data is not presented as a complete trading day.
OHLC comparison uses existing four-decimal storage precision; volume/source/
status are compared too. No new holiday/special-session calendar is asserted.

After reviewing this concrete plan, explicit apply:

```bat
python -m controller.cash_recovery_cli apply --plan "F:/TIOS_Runtime/cash_recovery_plan_01.json" --writers-stopped --output "F:/TIOS_Runtime/cash_recovery_result_01.json"
```

Apply inserts missing 1m rows only; it never issues UPDATE, DELETE, REPLACE,
INSERT IGNORE, schema changes, checkpoint changes or instrument creation.
The existing instrument must map exactly. A nonnullable unique key on
(instrument_id,timeframe,candle_timestamp) is required, plus transactional
InnoDB on MySQL. SQLite is supported only for disposable local tests.

Each READY partition receives a compatible Cash file lock, fresh checks and an
fsynced recovery bundle under TIOS_HOME/recovery/cash_insert_only/<plan-digest>:
- exact source Parquet bytes, SHA256-checked;
- before.json: selected metadata, original scoped SQL rows (possibly empty),
  destination-presence flag, candidate identity and warnings;
- events.jsonl: durable preparation/SQL-commit/completion/failure events.
This is a scoped recovery preimage, not a whole-database disaster backup.
Existing destination bytes are not changed, so no replacement rollback is needed.

The plan freezes the exact allowed missing timestamp keys. If further SQL rows
are removed after planning, apply reports scope drift rather than silently
reimporting them. Already-added matching rows are safe to skip on resume.

Inside a DB transaction, locked SQL rows are reread and compared, only absent
keys inserted, and all resulting scoped rows read back before commit. The
candidate is staged/fsynced, and hard-link support tested before SQL commit.
After commit an absent Parquet file is published atomically without overwriting
any existing file, then both stores are verified again. Local NTFS normally
supports the required hard links; unsupported storage fails closed.

MySQL and the filesystem are NOT one transaction. If file publication fails
after SQL commit, inserted rows remain and the journal records review status;
no automatic cross-store rollback is claimed. The same plan can be reapplied
with a NEW result filename: already consistent partitions are checked/skipped,
missing files can finish publication, and matching SQL keys are never reinserted.
Externally changed values cause review, not overwrite. A committed insert whose
acknowledgment was lost may not appear in inserted_rows; inspect journal/current
state and reapply safely. A hard process kill may leave named .recovery-*.tmp or
probe files; no automatic sweeping/deletion of unrelated files is performed.

Per-partition failures are reported and other READY entries continue. A journal
write failure stops the operation. PARTIAL can mean the READY entries succeeded
while original UNRESOLVED entries remain; inspect applied_statuses separately.
The report and journal retain exact scope. The source files, FNO data, aggregates,
existing SQL values and checkpoints are untouched. Only confirmed missing keys
and absent target files can be added.

Do not mark a partial result globally verified or delete old folders. After
recovery, use a fresh inventory/preview before further repairs. Existing SQL
conflicts and aggregate regeneration require separately reviewed changes; this
tool does not silently "repair" them by destroying a competing version.

Validation uses disposable SQLite/Parquet fixtures for insert-only preservation,
rollback, duplicate prevention, source/SQL drift, alternate variants, publication
race, recovery after commit, backup failure and continuing after a failed
partition. Production Windows/MySQL apply must be validated by the returned
plan/result; no actual user database is available in the build environment.

Build validation: 724 passed / 194 skipped in the full suite. Final focused
recovery/restore/preview/inventory/scope suite: 68 passed after report-detail and
missing-key scope guards. Production Windows/MySQL run remains pending.


## Explicit SQL-exact selection for conflicting old sources

`plan --prefer-sql-exact` may select a quality-checked source whose complete normalized rows match nonempty current SQL, even when other old variants disagree. Default planning still rejects those conflicts. All source variants and their diagnostics remain in the plan; source files are never changed. This proves storage agreement, not provider correctness.

The selected item requires exact SQL equality again during apply, inside the transaction and at postcheck. A deleted or changed SQL row blocks this restoration instead of causing a new insert. Existing destination conflicts still block publication. The option does not loosen timestamp, metadata, record-quality or no-overwrite checks. Other partitions continue through the existing insert-only policy, so inspect fresh summary totals before applying.

Windows CMD, from the extracted build folder containing main.py:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m pytest -q tests/test_cash_recovery.py tests/test_cash_restore.py tests/test_cash_inventory_preview.py tests/test_storage_inventory.py tests/test_storage_scope.py
python -m controller.cash_recovery_cli plan --preview "F:/TIOS_Runtime/cash_preview_01.json" --prefer-sql-exact --output "F:/TIOS_Runtime/cash_recovery_plan_02.json"
```

For the supplied result snapshot, expected fresh plan: 2206 ALREADY_CONSISTENT, 13 READY, 61 UNRESOLVED, 0 SQL insert rows, 13 files to restore. Actual live state can change these totals. Use a new output filename if one already exists.

Only after checking the actual plan and stopping all writers:

```bat
python -m controller.cash_recovery_cli apply --plan "F:/TIOS_Runtime/cash_recovery_plan_02.json" --writers-stopped --output "F:/TIOS_Runtime/cash_recovery_result_02.json"
```

Expected successful batch: 13 VERIFIED, 0 inserted rows, 13 restored files, PARTIAL because 61 plan entries remain unresolved. Do not run automatically after a failed test or unexpected plan totals.

See CASH_REMAINING_REVIEW.md for the path-wise remaining assessment based on the uploaded prior plan.


## Fast single-run workflow

`python -m controller.cash_recovery_cli run --preview "F:/TIOS_Runtime/cash_preview_01.json" --scope-plan "F:/TIOS_Runtime/cash_recovery_plan_02.json" --writers-stopped`

Authenticate once. Rechecks READY and UNRESOLVED entries from the scope plan against fresh source/SQL/target data, saves a new plan, applies eligible entries with existing backup/locking/no-overwrite guards, and saves one result. Prior ALREADY_CONSISTENT partitions are skipped, explicitly counted as not rechecked; this is not full certification. Omitting --scope-plan checks all preview partitions. It does not discover sources absent from the preview or resolve conflicting prices automatically. Writers must remain stopped for the run. Output files get unique paths under TIOS_HOME/recovery/cash_insert_only/run-*/. Keep the plan and journal after interruptions; the existing apply command can resume the saved plan. No-ready runs return a valid report without attempting apply. PARTIAL/exit 2 is expected when unresolved entries remain.

For the latest supplied production result, scope-plan_02 contains 74 selected partitions: expected fresh state is 13 ALREADY_CONSISTENT and 61 UNRESOLVED, zero writes. This command reduces repeated full scans and manual plan/apply handoffs; it does not itself repair the outstanding 61 conflicts.


## Read-only unresolved field audit

`python -m controller.cash_conflict_cli --preview "F:/TIOS_Runtime/cash_preview_01.json" --scope-plan "F:/TIOS_Runtime/recovery/cash_insert_only/run-aa3e395db58049b6a7a43a0e828822bd/plan.json"`

Requires admin authentication but performs no SQL or market-data writes. Only one new JSON report is written under TIOS_HOME/recovery/cash_conflicts. The supplied scope selects unresolved partitions only. Source hashes are checked against the preview. SQL is re-read to detect changes during each partition audit; keep writers stopped for stable results. This is not an atomic database-wide snapshot.

Categories distinguish market-value differences (OHLC/volume), metadata-only differences (source/status), timestamp-key differences, exact comparisons and uncomparable values. Per-field counts cover every common unique timestamp; examples and missing-key samples are bounded to 20 per variant. Counts are per variant, not distinct partitions/rows across the whole report. A metadata-only comparison still requires quality and provenance review; it is not permission to discard source/status. Invalid-quality source rows are included diagnostically when structurally readable. Duplicate timestamps are reported as ambiguous, never silently collapsed. Source/SQL quality findings retain the configured calendar interpretation and do not independently prove an exchange closure. No winner is chosen and no repair is performed.

Upload the generated audit JSON, not just the console summary, to review actual field values. This avoids repeating full recovery scans for the same 61 conflicts.


## Session preservation and provider resolution staging

`python -m controller.cash_resolution_cli --audit "F:/TIOS_Runtime/recovery/cash_conflicts/audit-9d1fe322939a41949829ceeffc366839.json"`

Admin authentication is required; broker authentication is loaded lazily only for conflicting partitions. Reuses existing historical fetch/retry/rate-limit and normalization functions. Keep writers stopped for stable comparisons. Exact prior matches are hash checked and compared to fresh SQL; if only configured-session findings remain, complete source bytes are preserved in a unique recovery directory with full regular/outside-session row counts. No rows are removed, no session records are relabeled as regular, and canonical_certified stays false. No global calendar or quality gates are loosened.

Non-exact partitions request the relevant historical day from FYERS, without a current-market-open gate. Nonempty quality-checked responses are staged as provider_candidate.parquet, with SQL comparison and SQL preimage. Empty responses create only an outcome record, never an empty market-data file. Provider errors are recorded per partition; provider availability is not guaranteed. Existing SQL, canonical Parquet, checkpoints and original source files remain unchanged. This is candidate preparation, not final repair/promotion. No default source wins a price conflict.

One report is generated under TIOS_HOME/recovery/cash_resolution/resolution-*/result.json. Expected scopes from the supplied audit: 16 session preservation cases and 45 provider requests. Actual outcomes depend on fresh source/SQL checks and provider responses. Interrupted runs leave per-partition outcomes and snapshots; no automatic resumable provider cache is claimed. SQL snapshots and candidates are recovery evidence, not a full database backup. Real FYERS/Windows/MySQL execution must be checked on the owner machine; local tests use disposable SQLite and stub provider responses.


## SQL-exact session preservation restoration

`python -m controller.cash_session_cli --result "F:/TIOS_Runtime/recovery/cash_resolution/resolution-766f2dab32c447fba9edb630dd132cd9/result.json" --writers-stopped`

Selects only SESSION_PRESERVED_REVIEW outcomes (16 in the supplied resolution report). Fresh checks require nonempty SQL and complete normalized SQL/source equality, matching instrument metadata, unique timestamps, closed records and valid prices/volume. Only outside-session integrity findings may be preserved; every row is checked, not just bounded samples. No new SQL rows may be inserted because exact SQL equality is required both before and inside the apply transaction. Existing different targets are blocked. Prior originals remain untouched. Uses existing backups/journals/exclusive publication and same file locks. Fresh plan and result paths are generated automatically under recovery/cash_session_restore.

Expected when missing targets remain: 16 restored files, 0 inserted rows. Repeated runs with identical current targets report ALREADY_CONSISTENT. If a source/SQL changes, it remains UNRESOLVED rather than weakening checks. The result's COMPLETE refers only to this restoration scope, not project completion or data quality. `canonical_certified` is false and `aggregation_status` remains NOT_REBUILT. Session classifications are retained in session_entries, while default quality checks and verified-read eligibility remain strict. No holiday/weekend exception is added by this command. It does not regenerate aggregates or change the 45 provider repairs.

Latest owner evidence before this addition: 45 provider repairs VERIFIED; 552 SQL inserts, 2770 updates, 231 SQL-only rows preserved. Journal includes earlier failed attempts plus 45 successful PREPARED/SQL_COMMITTED/VERIFIED sequences. Do not rerun provider repair unnecessarily.
