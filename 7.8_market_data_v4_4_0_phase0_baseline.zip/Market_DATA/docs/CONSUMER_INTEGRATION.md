# Step 4: one GET client for downstream modules

Use `client.MarketDataClient` from indicators, strategy analysis, backtesting,
forward testing and paper-trading modules. It has no SQL, FYERS or Streamlit imports
and never fetches from the broker, submits jobs or changes storage. Existing
`MarketReadService` remains available for trusted in-process callers.

## Setup

Start the API from the repository root as before:

```sh
python -m pip install -r requirements-api.txt
python -m api --port 8000
```

Consumer-only environments need the `client/` package on their Python import path
and `python -m pip install -r requirements-client.txt`. No database/provider secrets
are required. Configure these environment variables in the consumer process:

- MARKET_DATA_API_URL: default http://127.0.0.1:8000 (origin only, no /api/v1 suffix).
- MARKET_DATA_API_USER: default user; use admin only for quality report access.
- MARKET_DATA_API_PASSWORD: the corresponding existing dashboard/API password.

`from_env()` reads these variables explicitly; it does not load .env automatically.
The CLI prompts privately when a password variable is missing. Passwords are never
accepted as command-line flags or embedded URLs. HTTP is allowed only for loopback;
remote origins require HTTPS. Environment proxy settings and redirects are disabled.
The local server deployment is unchanged; this SDK does not configure remote hosting.

## Historical candles for indicators/backtests

```python
from decimal import Decimal
from client import MarketDataClient

with MarketDataClient.from_env() as data:
    for page in data.iter_candle_pages(
        'CASH', 'NSE:SBIN-EQ', '1m', '2026-10-01', '2026-10-16'
    ):
        quality = page['quality']
        for row in page['data']:
            close = Decimal(str(row['close']))
            # Pass the row to your module's staging/input layer.
```

Historical requests default to `quality='verified'`, closed candles and complete
coverage. `get_candles` returns one page; `iter_candle_pages` automatically follows
cursors and splits verified histories into scopes of at most 31 inclusive days.
`iter_candles` yields just the rows. Overall date scope is limited to 3661 days.
Default page size is 1000; page and response-size limits fail explicitly rather
than silently truncating. Symbols must be existing provider symbols from instruments.

Data types stay on the wire contract: Decimal strings remain strings; Cash strict
reads retain their existing float values; optional OI/IV/Greeks remain null. Explicit
Decimal(str(value)) conversion avoids introducing an extra binary-float conversion,
but cannot recover precision already lost in an upstream float. The SDK checks
scope, timezone-aware timestamps, ordering and page overlap; business candle
validation continues to belong to the server's existing verification logic.

### Sparse options

```python
with MarketDataClient.from_env() as data:
    for page in data.iter_candle_pages(
        'FNO', actual_contract_symbol, '1m', start_date, end_date,
        allow_sparse=True,
    ):
        # Values may be VERIFIED while coverage remains SPARSE_UNCONFIRMED.
        consume_with_coverage_policy(page['data'], page['quality'])
```

`allow_sparse=True` is an explicit consumer decision. No missing option minute is
filled, interpolated or converted to a zero-volume trade. Default consumers reject
sparse coverage. `quality='raw'` is an explicit opt-out of strict verification and
retains NOT_VERIFIED in metadata. NO_SESSION with empty data is a valid holiday
result; it is not permission to fabricate candles.

### Partial iteration and reproducibility

Pages yielded before an exception are provisional. A later page or date chunk can
fail. Do not finalize a backtest, publish indicators or persist a completed dataset
until the iterator finishes successfully. Consumers with their own databases should
use staging/transactional commit. Cursor pagination is a live view, not a snapshot;
stop writers for a reproducible historical analysis or use a tested recovery copy.
Do not discard page quality if your strategy depends on coverage completeness.

## Latest data for forward/paper testing

```python
with MarketDataClient.from_env() as data:
    latest = data.get_latest_candles(
        'CASH', 'NSE:SBIN-EQ', '1m', max_age_seconds=180
    )
```

Latest stored data is NOT_VERIFIED. Freshness checks compare reported age, as_of,
latest timestamp and the consumer's current clock. Keep client/server clocks in
sync. Missing/stale/future or inconsistent data raises FreshnessError. Age is measured
from the candle's start timestamp; allow for candle duration and ingestion lag.
This is not a live subscription or an order-execution feature. On nontrading periods,
choose a market-aware policy in the consuming module; the client does not silently
relax the caller's age threshold. Without max_age_seconds there is no freshness gate.

## Other shared methods

| Method | Returns | Notes |
| --- | --- | --- |
| get_instruments / iter_instruments | Page / all instrument rows | Cash or FNO, active/category filters |
| get_coverage | Coverage page | SQL observations, never a certificate |
| get_option_chain / iter_option_chain | Page / all snapshot rows | Local captures only; preserve batch_id |
| get_job_status | Safe job-status page | No credentials/operational error payloads |
| get_quality_report | Findings page | Admin credentials required; historical findings |

## Standalone consumer check/export

Run from the repository root:

```sh
python -m client --segment CASH --symbol NSE:SBIN-EQ --from-date 2026-10-01 --to-date 2026-10-16
python -m client --segment CASH --symbol NSE:SBIN-EQ --from-date 2026-10-01 --to-date 2026-10-16 --output exports/sbin_verified.jsonl
```

Output uses JSONL, one complete page including quality/meta per line. A temporary
file is published only after every page succeeds. Existing destinations are never
overwritten; choose a new filename. Atomic publication requires hard-link support
(e.g. NTFS). On unsupported filesystems export fails explicitly and cleans temporary
files; summary-only mode remains available. A crash may leave a hidden temporary
file, which is not a completed dataset. This export does not modify the source data.

Runnable Python example: `python -m examples.read_verified_candles`.
Adapt dates/symbols to data you actually fetched and verified.

## Failure contracts

- AuthenticationError: 401/403; fix credentials/role, no retry.
- DataQualityError: 409 or consumer coverage-policy failure; fix/verify data or
  explicitly choose a documented sparse/raw policy. No automatic fallback to raw.
- FreshnessError: latest-data age policy failed.
- ProtocolError: malformed/oversized/mis-scoped page, repeated cursor, timestamp
  overlap or page limit. Do not mark the dataset complete.
- ServiceUnavailableError: connection/timeout or transient server failures after
  bounded retries. GET retries never submit ingestion jobs.
- MarketDataClientError: other rejected HTTP status, such as 422. status_code is
  retained; server bodies and credentials are omitted from exception messages.

Defaults: 30-second HTTP timeout, at most two retries, 16 MiB decompressed response
limit, 100,000 pages per iterator. Retry-After numeric delays are capped at five
seconds. Only network/timeouts and 429/502/503/504 are retried. Full validation of
MySQL/FYERS remains a deployment-side task; SDK/API integration tests use disposable
SQLite/Parquet and the real FastAPI application without external network calls.
