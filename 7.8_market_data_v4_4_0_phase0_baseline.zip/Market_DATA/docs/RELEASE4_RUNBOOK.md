# Release 4 operations and recovery

Run from the extracted project root. Keep Cash and FNO database identities and Parquet roots separate. All source verification remains read-only; do not interpret findings as approval to delete, reset or overwrite data.

## Metadata upgrade and rollback

Use `quality-migrate` to inspect pending statements, then `quality-migrate --apply` explicitly. It extends existing ingestion jobs and creates report/event metadata only. It is idempotent; a failed MySQL DDL step can leave earlier statements applied. Rerun preview and apply remaining steps. Do not run `database/schema.sql` over an existing database. Back up your installation before upgrading.

For application rollback, stop all processes and restore the previous code/config backup. New nullable/defaulted metadata columns and tables can remain; old candle readers do not depend on them. Do not drop report tables automatically. Restore source data only from a separately reviewed backup if an operator has changed it.

## Read-only verification

Use UI scope selectors or `verify --symbols ... --from ... --to ... --run`. Inspect finding status and reasons, not only the job state. A completed verification with gaps normally has `PARTIAL`. Unsupported/unknown metrics say `NOT_VERIFIED` or `NOT AVAILABLE`.

Source SQL/PQ equality is checked by values, not row counts alone. Current mutable data cannot receive a durable snapshot guarantee. For a stable comparison, stop writers and choose completed dates. Verification will not repair mismatches, reload history or reset checkpoints.

## Job lifecycle

`PENDING → RUNNING → SUCCESS / PARTIAL / FAILED / NO_DATA / CANCELLED / INTERRUPTED`.

An active identical request is deduplicated by a unique key. Heartbeats expire after 90 seconds; recovery marks stale workers interrupted. Resume creates a new job linked to the prior ID. Smart Fetch replans from actual stored missing minutes, aggregation retries its requested scope, and verification rechecks its requested scope. Results remain tied to their own job IDs.

`pipeline-worker --once` drains existing queued work once. Without `--once`, it polls headlessly. `--schedule-eod --symbols ...` opts into durable scheduling for the most recent completed verified session within the last eight dates. It catches a late start for that session, not every historical day ever missed. A failed/partial scheduled job requires explicit resume. Older gaps are handled through Smart Fetch preview.

The legacy `schedule` command retains automatic live start/stop and uses the durable EOD queue. Keep one scheduler instance. Default Cash continuous session is 09:15–15:30 exclusive; known 2026 holidays are excluded. Unknown special sessions and unverified years need a reviewed calendar update. Cash auction/CAS-specific eligibility is not modeled by the supplied instrument schema; quality scope is the configured continuous-session policy.

## Resource bounds

- Cash verification: one symbol/day/timeframe; maximum 20,000 rows per partition, 2,000-row Arrow batches. Oversized partitions are not certified.
- Job scope: ordered date range up to 3,661 days; Smart Fetch preview up to 5,000 symbol-days. Jobs cancel between units.
- FNO verification: contract/day processing; manifests paginated by 200 and Arrow batches by 2,000. Duplicate keys use a scratch SQLite unique index, removed on completion. Source Parquet is untouched.
- Finding UI pages: 200 rows. Complete browser JSON: at most 100,000 findings; CLI export streams all rows in pages of 2,000.
- FNO heatmap: selected contract, at most 366 days. It includes dates without records and labels uncertainty.
- Telemetry queue: 2,000 events; dashboard shows latest 5,000 for the chosen day. Delay stats describe those displayed observations, not all historical traffic.

Large verification still incurs database reads and disk I/O. Run broad scans off-hours. Runtime quota/lock files and temporary verification indexes are operational metadata, not parallel market-data storage.

## Storage and recovery

SQL accepted canonical rows feed Parquet. CLOSED history remains immutable on conflicting OHLCV; historical CLOSED data can supersede provisional LIVE. Parquet writes use file locks, temporary files, readback and atomic replace. SQL and Parquet are not one atomic transaction. If a second sink fails, report the partial write and inspect read-only findings before an explicit repair decision.

Existing bad legacy buckets are not silently rebuilt. Strict aggregation skips missing/invalid/duplicate/OPEN source minutes. Historical max-date checkpoints no longer skip older holes by themselves. Smart Fetch first checks both stores, then requests exact missing closed-minute ranges; it will not claim zero gaps for partially covered instruments.

## Credentials, quota and sockets

The persistent quota ledger is shared by dashboard/CLI processes in the same installation/account. Standard defaults: 4 data requests/sec, 45/min, 4,500/day, with a separate maximum 10 expired-intraday calls/day. FNO reserves part of the normal budget for Cash. A corrupted ledger fails closed; never delete it during a trading day merely to obtain more calls. Calls from other apps/installations are outside this ledger; use one shared absolute `TIOS_RUNTIME_DIR` when appropriate and respect the broker's actual account limit.

One account OS lock owns the data socket. Cash/FNO modes cannot independently open concurrent sockets. There is no cross-process tick fan-out. A hung SDK shutdown retains ownership until the process closes. Normal operation should stop the current feed before switching. Standard subscriptions are capped at 100 symbols in the app. Optional multi-socket probing is not part of the daily workflow.

Tokens are supplied through the existing `.env`/manual OAuth flow. A rejected token is not retried in a tight loop. Update the token, use the explicit reload control, then resume. New CLI processes read the new file. No real account probe was run during this release.

## Telemetry and alerts

Cash `TICK_RECEIVED` is sampled at most once per symbol/30 seconds. `SQL_COMMIT` and `PARQUET_COMMIT` are emitted only after those sink operations acknowledge a live closed candle. Delay is commit time minus candle end. They are separate observations; reception is not storage success. Queue overflow/DB failure can lose telemetry and cannot prove loss of market candles. FNO retains its own jobs/freshness diagnostics; the new Cash event table is not cross-written from FNO.

Errors are deduplicated by kind/symbol within a five-minute bucket. Preview pending delivery:

```bat
python main.py alerts-dispatch
```

For optional Telegram delivery set `TIOS_TELEGRAM_BOT_TOKEN` and `TIOS_TELEGRAM_CHAT_ID` in the operator environment (keep secrets out of shared reports), then explicitly run:

```bat
python main.py alerts-dispatch --send
```

Up to 20 pending/retry events are attempted, one dispatcher holds the local lock, failed sends remain `RETRY`. Delivery is at least once; a process crash after network success but before recording `SENT` may duplicate an alert. Messages contain event category/symbol/time, no credentials or raw broker error payload. No notifications are sent merely by opening the dashboard. SMTP/email is not implemented here.

## Acceptance checklist before CODE/TEST/FREEZE

- [ ] Backups complete; preserve real `.env`, instruments and data roots.
- [ ] Migration preview points to the intended Cash/FNO databases; no candle/checkpoint DDL.
- [ ] Windows/Python/MySQL 8.0 startup and new report tables work.
- [ ] Actual browser login with Enter and mouse both work; normal user cannot mutate.
- [ ] Today reflects IST; known holiday and incomplete current-day states are correct.
- [ ] Read-only verification preserves sample source-table counts/checksums and Parquet hashes.
- [ ] Covered Smart Fetch makes zero requests; one deliberate test gap requests only its range in a test dataset.
- [ ] Real account limits/token rejection and supported FNO methods are probed without an uncontrolled burst.
- [ ] SQL and Parquet live commit observations are present after migration/ingestion restart.
- [ ] Optional Telegram delivery tested only after operator opts in.
- [ ] Full TIOS consumers adopt `MarketDataRepository.iter_verified_days` where strict historical data is required.

Local validation and all remaining platform/account limitations are in `RELEASE4_TEST_REPORT.md`. Existing Release 3 reports are historical, not proof that these new features were tested on the user's Windows machine.
