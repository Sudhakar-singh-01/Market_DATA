# Scoped incomplete-session repair from final-check evidence

Confirmed final-check result (2026-10-29): 2,280 raw partitions / 850,883 rows
and 305 derived partitions / 7,381 rows pass current storage parity. There are
no storage findings in that supplied scope. Quality remains separate: 1,374
partitions have unverified calendars, six have incomplete coverage, and 39
contain configured off-session rows (categories overlap; 1,405 unique reviews).

The six incomplete partitions are HDFCBANK, ICICIBANK, NIFTY50, NIFTYBANK,
RELIANCE and SBIN on 2026-10-26, each with 29 stored regular-session candles.
This command targets only that date's parity-verified incomplete partitions.
It does not select calendar-review cases or already-complete sessions.

Stop live ingestion, scheduler and other data writers. Run from the latest
extracted project folder, in Windows CMD (each command one line):

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_gap_cli --check-report "F:/TIOS_Runtime/recovery/cash_final_check/check-9b1b96405cb54a92889abe29c9896895.json" --date 2026-10-26 --apply --writers-stopped --accept-provider --rebuild --accept-derived-replacement
```

Without apply/rebuild flags this only stages and plans. The existing --result
off-session-only mode retains its insert-only restriction. New --check-report
mode explicitly permits preferred provider values on matching timestamps,
using the existing backup/journal repair engine; no raw rows are deleted.
The date is mandatory to prevent an accidental broad backfill.

The workflow:

1. Select incomplete records from the supplied successful final-check report.
2. Recheck current SQL session coverage. Complete or calendar-changed sessions
   do not trigger a new fetch. Fetch through the existing authenticated client,
   retry helper and normalizer; no duplicated auth flow or session gate.
3. Require a complete valid provider session, exact symbol/metadata, CLOSED
   status, valid prices, unique aligned timestamps, valid volume and historical
   provenance. Empty, partial or malformed results cannot be applied. Every
   selected raw partition must be READY before auto-apply begins.
4. Back up current SQL/Parquet, preserve SQL-only keys, correct matching keys
   using accepted provider values, insert missing timestamps, publish Parquet
   and verify parity. Expected fresh inserts: 6*(375-29)=2,076; up to 174
   matching rows may be updated for prices/volume/source/status. Actual counts
   depend on fresh data. Expected final regular rows: 2,250.
5. Only after ALL raw repairs succeed, create a derived plan for this applied
   scope, then guarded apply with backups. Expected scope: 30 derived partitions
   / 726 candles (5m,15m,30m,1h,1d). Previously rebuilt 305 paths are untouched.

All stages print plan/report paths. Recovery and application reports are under
the existing cash_session_gaps, cash_provider_repair, cash_derived_rebuild and
cash_derived_apply recovery folders. No old-version inventory rescan is needed.

There is no atomic transaction across all partitions or stores. If raw apply
is partial, derived application does not start. If derived planning has review
findings, derived apply does not start. If later stages fail, successful raw
repairs remain committed. Retain every printed plan, report and journal.
Do not rerun the full fetch command blindly after partial application: resume
the printed raw plan with cash_repair_cli apply or the printed derived plan
with cash_rebuild_cli --apply-plan, using their existing acknowledgement flags.
The same-plan resume paths revalidate current source and target state.

Admin authentication failures are now identified separately from file-access
errors. A successful BASE_REPAIR_VERIFIED raw result is treated as successful
by this CLI (the former COMPLETE-only exit check could return exit code 2 even
after successful raw repair).

Validation: 147 focused regression tests passed, including a 29-row partial
session repaired to 375 with preserved backups, malformed provider rejection,
explicit date selection, exclusion of calendar-review cases, and the combined
CLI raw-repair/derived-rebuild flow. Existing raw/derived recovery regression
tests also pass. Local Linux/Python 3.12/SQLite tests are not a substitute for
the user's Windows/MySQL application result. The broader 787-pass/194-skip
suite result belongs to the preceding final-check build, not this new revision.
