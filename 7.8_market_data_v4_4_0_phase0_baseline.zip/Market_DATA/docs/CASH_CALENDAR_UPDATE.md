# Cash calendar update and fast review — 2026-10-29

This build adds Cash-only 2024/2025 holiday and special-session metadata through an explicit profile update. It preserves existing common holidays, all existing 2026 session entries (including February 1 and unknown Muhurat hours), FNO verified years and its verified_from date. The bundled default holidays.yaml is not replaced. Existing conflicting special-date overrides cause a stop, not silent replacement.

## Run from the extracted project folder in CMD
Stop live ingestion, schedulers and other writers before updating configuration. Keep the existing TIOS runtime; do not copy old data or reset databases.

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m pytest -q tests/test_cash_calendar_update.py tests/test_aggregation_reporting.py tests/test_market_session_policy.py
python -m controller.cash_calendar_cli --apply --writers-stopped --check-report "F:/TIOS_Runtime/recovery/cash_final_check/check-9b1b96405cb54a92889abe29c9896895.json"
```

The tool requests the existing tool-admin password. It does not request broker credentials or call FYERS. An expired broker token does not affect this command.

Optional preview: `python -m controller.cash_calendar_cli`.

The update stores a byte-identical backup beside the existing holidays.yaml; serializes valid YAML; checks for intervening edits; and publishes by replacement. The updater is idempotent. It does not claim all editors obey its lock; writers and manual editing must remain stopped during the update. YAML formatting/comments may change; source references are stored in calendar_reviews and original comments remain in the backup.

## Review scope and expected output
For the supplied report, the fast review selects 41 Parquet files: 16 special-session partitions and 25 partitions with outside-session rows in 2026. It reads only those files, verifies bounded schema/identity/OHLC/timestamps/coverage, checks that the file did not change, and writes a JSON report under TIOS_HOME/recovery/cash_calendar_review. No SQL connection, market-data write, derived rebuild, source-folder scan, or historical fetch occurs.

Other 1,358 previously calendar-unverified partitions get REPORT_ONLY_CALENDAR_MATCH only if their recorded count matches the newly configured expected minutes. This is a comparison against the old report, NOT fresh timestamp, value, SQL/Parquet parity, or full-year data certification. Other report partitions (including the six already repaired October 26 sessions) are not rechecked.

Fresh file results are PARQUET_SESSION_PASS or REVIEW_REQUIRED. CALENDAR_REVIEW_COMPLETE means the review ran, not that all data passed. The report contains quality issues, exact missing/outside counts, and bounded timestamp samples. Preserve all raw data even if outside the configured normal session. In particular October 21, 2025 has 61 reported rows against a 60-minute normal session; inspect the report before taking any data action.

If configuration update succeeds but file review fails, the calendar remains updated and its backup remains available. Rerunning this command recognizes the same calendar without changing it again. Review output is Parquet-only and makes no fresh SQL parity claim.

## Session semantics
- Ordinary Cash session remains 09:15–15:30; close exclusive.
- 2024-01-20 and 2025-02-01: normal Saturday sessions, 375 expected minutes.
- 2024-03-02 and 2024-05-18: 09:15–10:00 plus 11:30–12:30, 105 minutes.
- 2024-11-01: 18:00–19:00, 60 minutes.
- 2025-10-21: 13:45–14:45, 60 minutes.
- Intraday buckets restart at each interval opening and clip to its close. Daily OHLCV combines all valid session intervals, excluding the break. Missing minutes are not filled or invented.
- session_window remains a compatibility envelope for opening/final close and EOD timing. session_windows/in_session handle actual membership. Cash quality, rebuild, aggregation, coverage, and live-status checks use actual intervals.
- Newly added exceptions and holidays are scoped to Cash. FNO configuration and verification dates are not extended by this update. Existing shared 2026 exceptions keep their semantics.
- Historical fetch remains allowed 24/7. Manual live startup remains allowed when closed; this change does not reintroduce a startup gate or persist empty live messages.
- Existing derived files on newly recognized special dates are not rebuilt automatically; that requires a separately reviewed scope.

## Official evidence
All calendar additions are from NSE circulars; reviewed 2026-10-29.

- https://nsearchives.nseindia.com/content/circulars/CMTR59722.pdf — 2024 annual holidays
- https://nsearchives.nseindia.com/content/circulars/CMTR60338.pdf — January 22 holiday (also referenced in NCL CMPT60343)
- https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf — May 20 holiday
- https://nsearchives.nseindia.com/content/circulars/CMTR64960.pdf — November 20 holiday
- https://nsearchives.nseindia.com/content/circulars/MSD60340.pdf — January 20 regular trading; supersedes earlier split-session notice
- https://nsearchives.nseindia.com/content/circulars/MSD60677.pdf — March 2 split session
- https://nsearchives.nseindia.com/content/circulars/MSD61893.pdf — May 18 split session
- https://nsearchives.nseindia.com/content/circulars/CMTR64628.pdf — November 1 Muhurat
- https://nsearchives.nseindia.com/content/circulars/CMTR65587.pdf — 2025 annual holidays
- https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf — February 1 Budget session
- https://nsearchives.nseindia.com/content/circulars/CMTR70319.pdf — October 21 Muhurat
