# Scoped Cash derived rebuild preview

Current milestone: repaired raw data must be used to recompute derived candles.
The ordinary aggregate command is not a recovery overwrite command: its sinks
can reject conflicting CLOSED values and do not remove obsolete bucket starts.
The preview records actual changes before the guarded apply step.

`python -m controller.cash_rebuild_cli --reports REPORT1 REPORT2 REPORT3`

Use the successful 45-partition provider repair, 16-file session restoration,
and 4-partition session-gap repair result JSON files. Only verified/already
applied outcomes enter scope; repeated raw partitions are deduplicated. The
expected scope is 61 unique raw partitions. With the current calendar, two
February 1 partitions remain review cases; up to 59 sources / 295 derived
partitions can be planned. These are expectations, not hardcoded results.

Run against stable stores (pause ingestion and scheduler for a reliable
snapshot). No broker calls or whole-repository inventory scan are performed.
The CLI performs authenticated, bounded reads and writes only unique recovery
workspace candidates and plan.json under TIOS_HOME/recovery/cash_derived_rebuild.
In preview mode canonical raw/processed Parquet and SQL are not written.
The apply mode below requires explicit replacement flags.

Each source requires current SQL/Parquet equality, valid record metadata,
unique timestamps, a configured verified calendar session, closed day, and
complete regular-session minute coverage. Outside-session rows remain in raw
storage and are excluded from aggregation. Unknown/closed calendar sessions
remain review cases; no special session is invented.

The existing shared aggregator produces 5m, 15m, 30m, 1h, and 1d candidates.
For a 375-minute session these have 75, 25, 13, 7, and 1 rows respectively.
Session-clipped final 30m/1h buckets are intentional. Generated Parquet is
read back. Existing derived SQL and Parquet are compared independently using
timestamp, timeframe, OHLC, volume, source and status; missing, changed, and
extra keys are reported. Duplicate/wrong-date/metadata findings remain review
cases. Source/target changes during reads invalidate affected plan entries.

The plan is a preview, not a backup or permission to delete extra rows. It
contains scoped SQL preimages, fingerprints, expected rows and candidate
paths. Application revalidates sources/targets, takes fsynced
backups, journals commits, supports post-commit recovery, and verifies both stores.
No atomic cross-store snapshot or transaction is claimed. A successful preview
does not mean higher timeframes have been rebuilt.


## Guarded apply of the existing preview

Run with ingestion, live workers, scheduler and other data writers stopped.
Use the same permanent TIOS_HOME from the latest extracted code folder. CMD,
one line per command:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_rebuild_cli --apply-plan "F:/TIOS_Runtime/recovery/cash_derived_rebuild/rebuild-d644cfcb97bd430bb0c2add413e2e33e/plan.json" --writers-stopped --accept-derived-replacement
```

The uploaded preview contains 295 derived partitions (59 verified sources),
7,139 expected candles, and two deferred calendar-review sources. Its SQL
changes are 1,743 inserts, 926 updates and 1,264 obsolete derived timestamps
removed from canonical storage AFTER archiving the full preimage. Existing
Parquet comparison: 6,851 missing keys, 64 changed rows, no extra keys, and
279 missing files. Raw 1m and its off-session rows are never mutated.

Apply recomputes each candidate from the fresh source and compares with the
preview, validates its archived candidate fingerprint, checks target preimages,
keeps matching SQL row IDs, inserts missing keys and deletes only obsolete keys
within the selected instrument/timeframe/date. Full SQL preimages and existing
Parquet copies are fsynced and read back before any SQL mutation. Transactions
lock/read raw and derived records; target locks use the existing writer lock
convention. Writers-stopped remains necessary for a stable recovery run.

A same-directory hardlink probe runs before SQL commit. SQL commits first;
Parquet is then published and both stores read back. There is no atomic
cross-store rollback. If interrupted or a publish fails, keep all recovery
folders and rerun the SAME apply command with the same plan after resolving the
reported issue. Completed partitions return ALREADY_APPLIED; SQL-after/file-before
partitions publish without reinserting data. Unexpected changes block that
partition for review; they are not silently overwritten. Earlier committed
partitions remain in place. Totals count writes verified in the current attempt;
retain earlier journals when resuming a partial operation.

Backups, journals and unique result JSON files are under
TIOS_HOME/recovery/cash_derived_apply/<plan-digest>/. Do not delete these folders.
SCOPED_DERIVED_REBUILD_VERIFIED certifies only the selected partitions at their
checks. The two February 1 calendar reviews and global verification remain
pending. PARTIAL means inspect per-partition errors before proceeding.

Validation: 136 focused tests passed on Linux/Python 3.12 using disposable
SQLite. Includes rollback, backup/hardlink failures, changed source/candidate/
target rejection, resume after SQL commit, idempotency, matching-ID preservation,
and unrelated date/instrument/timeframe preservation. All 295 uploaded plan
before/after schemas were checked locally. Windows/MySQL application is not
claimed until the user's execution reports it.
