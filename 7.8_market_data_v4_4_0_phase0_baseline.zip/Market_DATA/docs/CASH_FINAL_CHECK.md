# Final read-only Cash recovery check

Run from the latest project folder with the permanent TIOS_HOME configured.
Pause writers for a stable check. No admin OS elevation is required; the tool
uses its existing application admin authentication.

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_final_check_cli --preview "F:/TIOS_Runtime/cash_preview_01.json" --derived-plans "F:/TIOS_Runtime/recovery/cash_derived_rebuild/rebuild-d644cfcb97bd430bb0c2add413e2e33e/plan.json" "F:/TIOS_Runtime/recovery/cash_derived_rebuild/rebuild-f40e5fe82200469cb71b4d9b42f340e0/plan.json"
```

The original preview supplies the 2,280 raw paths only. Its old hashes/statuses
are not treated as current evidence. The two plans supply the 305 derived paths;
old pending statuses do not prevent fresh checks after the calendar fix. The
tool reads current SQL and Parquet and recomputes derived candles from current
regular-session minutes. No candidate files are generated and no existing
market data, manifests, checkpoints or database rows are written. Only a unique
JSON report is created under TIOS_HOME/recovery/cash_final_check.

Raw checks: file existence, bounded schema reads, metadata, date/timeframe,
duplicate keys, exact canonical SQL/Parquet field equality, unchanged source
fingerprints and a repeated SQL read. Record quality, configured calendar
coverage and off-session preservation are reported separately. Each SQL read
is limited to one instrument/day/timeframe; prior version folders are not
scanned, and FYERS is never called.

Derived checks: current raw parity, verified calendar, complete regular session,
recomputed OHLCV/source/status, actual SQL and Parquet equality, target stability.
Expected repaired scope: 305 partitions / 7,381 derived candles. The raw scope
is 2,280 partitions. Counts and outcomes must come from the current run.

SCOPED_STORAGE_PASS means only supplied Cash paths passed storage checks.
FINDINGS identifies missing, mismatched, unstable or non-recomputable paths.
The full report retains quality_issues, quality_review_reasons and configured
off-session row counts. Matching invalid rows or unverified historical calendars
are not certified market data. canonical_quality_certified remains false; raw
parity and usable-session quality are deliberately distinct.

The opt-in raw-preservation integrity mode does not skip OHLC, volume, timestamp,
duplicate or status checks. Default validation behavior remains strict. This
avoids one calendar read per minute when checking preserved raw data.

This is not full-database discovery, an FNO audit, or an atomic cross-store
snapshot. Additional paths created since the original inventory are outside
scope. Report creation success is not proof that every scope check passed.
No repair happens automatically. Keep all previous recovery backups/journals.

Completed production milestones before this final check:

- 295 derived partitions / 7,139 rows verified: 1,743 SQL inserts, 926 updates,
  1,264 obsolete derived timestamps archived and removed.
- February 1 special-session calendar configured and checked in the user's
  persistent runtime profile. Remaining 10 partitions / 242 rows verified:
  42 SQL inserts, zero updates, 42 old timestamps archived and removed.
- Combined rebuilt scope: 305 derived partitions / 7,381 rows. No pending
  calendar case in these two completed application reports. Fresh global Cash
  inventory-scope verification is still pending the user's final-check run.

The bundled default calendar does not overwrite the runtime profile. Preserve
the user's verified February 1 entry in F:/TIOS_Runtime/config/holidays.yaml.

Validation: 140 focused tests passed with a disposable TIOS_HOME profile; full
suite in the standard environment passed 787 tests, with 194 skipped. Running
all legacy tests with a global runtime override initially exposed 13 path/UI
fixture assumptions; affected files passed 141 tests (2 skipped) without that
override. No production runtime setting needs to be removed. Tests use local
Linux/Python 3.12 and disposable stores; actual Windows/MySQL check is pending.
