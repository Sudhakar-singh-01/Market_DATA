# Cash minute validation preview

This adds a read-only stage after STORAGE_INVENTORY.md. It does not import,
merge, delete, rebuild aggregates, clear quarantine or change SQL/checkpoints.
It writes only the requested new report (never overwrites an existing report).
Keep workers stopped; this is not an atomic filesystem/SQL snapshot.

From the new extracted project folder in Windows CMD:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_preview_cli --inventory "F:/TIOS_Runtime/inventory_01.json" --with-sql --output "F:/TIOS_Runtime/cash_preview_01.json"
```

Enter the application admin password when prompted. PowerShell users should
use `$env:TIOS_HOME = 'F:\TIOS_Runtime'` for the environment line; the python
command is the same. MySQL must be available. No FYERS connection is created.
For a 25-partition trial add `--limit 25` and use a separate report filename.
A limit smaller than the full scope is explicitly incomplete. Without
--with-sql the SQL status is NOT_CHECKED and partitions require review.

The supplied inventory has 2,280 Cash raw/1m partitions (including six already
present partitions). Every Cash raw/1m partition is considered; FNO and Cash
processed files are deliberately excluded from this stage. Inventory paths
must still refer to their original existing locations on this Windows machine.

Checks:
- One readable representative per SHA256 variant, preferring the target if
  present. Hash and size must still match inventory, and a second hash after
  reading detects changes. Other identical copies are not all revalidated.
- Reject linked ancestors and paths outside declared inventory roots.
- Required schema, symbol/timeframe identity, date/minute alignment, positive
  finite OHLC and OHLC bounds, integral nonnegative volume, source, CLOSED
  status, duplicate timestamps, verified calendar session and minute coverage.
- Bound 20,000 rows per partition before loading, and 20 variants per partition.
- Unverified calendar dates never pass calendar-dependent certification.
  Naive Parquet timestamps are interpreted using the existing IST convention
  but require explicit review. SQL naive timestamps use its established IST
  storage contract. Missing minutes require review, not invented candles.
- Pairwise variant comparison distinguishes unique timestamp rows from value
  differences; compares OHLC at existing four-decimal precision and includes
  volume/source/status. Different compression alone is not a candle conflict.
- Optional SQL checks use the existing authenticated Cash catalog/reader,
  parameterized SELECTs and bounded reads; SQL unavailable is not treated as
  empty data. Missing SQL instrument registration requires review via an
  UNAVAILABLE result. No instruments are auto-created or modified.

Statuses:
- VALIDATED_CANDIDATE: single variant passed current checks with SQL comparison;
  it is NOT import permission. SQL may lack some/all candidate rows.
- REVIEW_REQUIRED: missing calendar/timezone/coverage evidence, multiple
  variants, SQL differences/invalidity, or SQL check omitted.
- REJECTED: identity/record-integrity/duplicate/status/source findings in at
  least one variant. Other variants are still listed; nothing is deleted.
- UNAVAILABLE: cannot safely complete the check (stale/missing/unreadable file,
  unsupported schema, bounds, missing SQL instrument or failed SQL read).

`complete` means every selected partition was processed within scope without
UNAVAILABLE and the input inventory was complete; it does not mean all passed.
Exit 0: processing complete, possibly REJECTED/REVIEW results. Exit 2: partial
or unavailable partitions. Exit 1: CLI/input/config/auth/output failure.
Reports contain local paths and bounded timestamp samples, not credentials.
Targets are described by the prior inventory, not recertified as absent for
future imports. Any eventual apply must recheck source/target/SQL, back up and
use a separate reviewed plan. Current files and databases remain unchanged.

Tests: 65 focused tests passed on Python 3.12 (preview, inventory, profile,
setup, storage scope, calendar). Actual Windows/Python 3.13 and production DB
scan remain to run on the user's machine. A preview is not a provider-data
accuracy, YAML metadata alignment, corporate-action or backtest certification.
