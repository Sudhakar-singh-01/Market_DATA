# Release 3 changes

## Added behavior

Session-aware FNO aggregation and read-only verification are available in CLI and persisted jobs. The independent FNO dashboard has twelve lazy sections, request planning, live/chain controls, job progress, storage previews, CSV page exports, checkpoint management, data quality and settings. The new audit table stays in the FNO database.

## Bugs corrected

1. Historical ranges with rejected/conflicting rows no longer advance fresh VERIFIED checkpoints; valid rows survive with a PARTIAL result.
2. Historical Parquet writes use accepted MySQL values instead of rejected API conflicts.
3. SQL conflict guards protect optional columns even if a concurrent write bypasses the Python classification; Parquet ignores LIVE optional values after historical data.
4. Reconcile compares candle values, not only counts/timestamp keys, and no longer calls unresolved value conflicts repaired.
5. Live cancellation now closes a blocking socket from a stop watcher, allowing shutdown/flush to complete.
6. Per-partition locks prevent cooperating concurrent FNO writers from losing rows during read/merge/rename.
7. Option-chain Parquet retention is enforced with its separate configured window. Negative retention input is rejected.
8. Local jobs do not require FYERS authentication. Harvest results print their full diagnostic counters.
9. Derived candles have an explicit range rebuild path; later historical corrections and newly missing source minutes cannot leave stale aggregates silently intact.
10. Aggregation detail jobs receive heartbeat/recovery updates; dashboard actions enforce roles and confirmation at the service boundary.

Cash-market source files/pages and the supplied `FNO_API_FINDINGS.md` are unchanged. The original market-data log is restored. Compiled caches, virtual environments, test databases and temporary build files are excluded.

## Final source layout

| Path | Purpose |
|---|---|
| `main.py`, `controller/` | Existing entry point plus FNO CLI/job handlers |
| `model/fno/` | Isolated FNO storage/config, aggregation adapter and bounded analytics queries |
| `model/processing/` | Existing shared processing; unchanged |
| `database/fno/001..007_*.sql` | Ten FNO tables, explicit migrations |
| `config/` | Existing settings and credential example |
| `ui/pages/30_FNO.py`, `ui/fno/` | Thin FNO entry page, renderer, service, background workers |
| `tests/fno/` | Existing and new FNO regression/integration/page tests |
| `docs/` | Runbook, test evidence, audit and supplied findings |
| `START_HERE.md` | Windows setup and first commands |

## New files (18)

- `START_HERE.md`
- `controller/fno_aggregate.py`
- `controller/fno_operations.py`
- `controller/fno_verify.py`
- `database/fno/007_audit_log.sql`
- `docs/FNO_RELEASE3_CHANGES.md`
- `docs/FNO_TEST_OUTPUT.txt`
- `docs/FNO_TEST_REPORT.md`
- `model/fno/aggregation.py`
- `model/fno/comparison.py`
- `model/fno/release3_repository.py`
- `tests/fno/test_fno_dashboard.py`
- `tests/fno/test_fno_release3.py`
- `ui/fno/__init__.py`
- `ui/fno/page.py`
- `ui/fno/service.py`
- `ui/fno/worker.py`
- `ui/pages/30_FNO.py`

## Modified files (15)

- `controller/fno_cli.py`
- `controller/fno_historical.py`
- `controller/fno_jobs.py`
- `controller/fno_live.py`
- `controller/fno_reconcile.py`
- `docs/FNO_RUNBOOK.md`
- `model/fno/job_store.py`
- `model/fno/parquet_store.py`
- `model/fno/repository.py`
- `tests/fno/conftest.py`
- `tests/fno/test_fno_cli.py`
- `tests/fno/test_fno_foundation.py`
- `tests/fno/test_fno_harvest.py`
- `tests/fno/test_fno_jobs.py`
- `tests/fno/test_fno_repository.py`

## Unchanged supplied files (133)

- `config/.env.example`
- `config/data_settings.yaml`
- `config/fno_settings.yaml`
- `config/holidays.yaml`
- `config/timeframe_settings.yaml`
- `controller/coverage_controller.py`
- `controller/fno_chain.py`
- `controller/gapfill_controller.py`
- `controller/health_controller.py`
- `controller/historical_controller.py`
- `controller/live_controller.py`
- `controller/scheduler.py`
- `controller/sinks.py`
- `controller/timeframe_controller.py`
- `database/add_audit_log.sql`
- `database/add_error_logs.sql`
- `database/fno/001_instruments_candles.sql`
- `database/fno/002_option_chain.sql`
- `database/fno/003_progress.sql`
- `database/fno/004_jobs.sql`
- `database/fno/005_quality_storage.sql`
- `database/fno/006_fix_exchange_codes.sql`
- `database/schema.sql`
- `docs/DASHBOARD.md`
- `docs/FNO_API_FINDINGS.md`
- `docs/FNO_AUDIT.md`
- `fyersApi.log`
- `fyersRequests.log`
- `instruments/indices.yaml`
- `instruments/stocks.yaml`
- `logs/market_data.log`
- `main.py`
- `model/config/data_settings.py`
- `model/config/env_loader.py`
- `model/config/instrument_loader.py`
- `model/config/market_calendar.py`
- `model/config/timeframe_settings.py`
- `model/config/yaml_loader.py`
- `model/exceptions.py`
- `model/fno/__init__.py`
- `model/fno/chain.py`
- `model/fno/config.py`
- `model/fno/db.py`
- `model/fno/errors.py`
- `model/fno/history_client.py`
- `model/fno/migrations.py`
- `model/fno/models.py`
- `model/fno/normalizer.py`
- `model/fno/probe.py`
- `model/fno/ranges.py`
- `model/fno/symbol_master.py`
- `model/fyers/auth.py`
- `model/fyers/historical.py`
- `model/fyers/quotes.py`
- `model/fyers/rate_limiter.py`
- `model/fyers/symbol_master.py`
- `model/fyers/websocket.py`
- `model/logging_setup.py`
- `model/processing/candle_builder.py`
- `model/processing/gap_detector.py`
- `model/processing/models.py`
- `model/processing/normalizer.py`
- `model/processing/timeframe_aggregator.py`
- `model/processing/validator.py`
- `model/repository.py`
- `model/storage/csv.py`
- `model/storage/mysql.py`
- `model/storage/parquet.py`
- `model/validation.py`
- `requirements.txt`
- `tests/conftest.py`
- `tests/fno/test_fno_chain.py`
- `tests/fno/test_fno_history_client.py`
- `tests/fno/test_fno_isolation.py`
- `tests/fno/test_fno_live.py`
- `tests/fno/test_fno_normalizer.py`
- `tests/fno/test_fno_parquet.py`
- `tests/fno/test_fno_probe.py`
- `tests/fno/test_fno_rate_limiter.py`
- `tests/fno/test_fno_reconcile.py`
- `tests/fno/test_fno_symbol_master.py`
- `tests/fno/tests_support.py`
- `tests/test_coverage.py`
- `tests/test_dashboard_layer.py`
- `tests/test_gapfill.py`
- `tests/test_gapfill_job.py`
- `tests/test_job_manager.py`
- `tests/test_job_pages.py`
- `tests/test_market_calendar.py`
- `tools/hash_password.py`
- `ui/admin_data_access.py`
- `ui/api_metrics.py`
- `ui/audit_log.py`
- `ui/auth.py`
- `ui/components.py`
- `ui/dashboard.py`
- `ui/data_access.py`
- `ui/date_inputs.py`
- `ui/db_log_handler.py`
- `ui/engine_bootstrap.py`
- `ui/error_display.py`
- `ui/file_explorer.py`
- `ui/instrument_editor.py`
- `ui/job_manager.py`
- `ui/job_panel.py`
- `ui/logging_bootstrap.py`
- `ui/pages/10_API_Monitor.py`
- `ui/pages/11_Coverage_Heatmap.py`
- `ui/pages/1_Admin.py`
- `ui/pages/20_Admin_Database.py`
- `ui/pages/21_Admin_Files.py`
- `ui/pages/22_Admin_Jobs.py`
- `ui/pages/23_Admin_Checkpoints.py`
- `ui/pages/24_Admin_Bulk_Delete.py`
- `ui/pages/25_Admin_Operations_Center.py`
- `ui/pages/26_Admin_Audit_Log.py`
- `ui/pages/27_Admin_Security.py`
- `ui/pages/28_Admin_Data_Operations.py`
- `ui/pages/2_Live_Market.py`
- `ui/pages/3_Data_Explorer.py`
- `ui/pages/4_Historical_Data.py`
- `ui/pages/5_Aggregation.py`
- `ui/pages/6_Data_Flow.py`
- `ui/pages/7_Data_Quality.py`
- `ui/pages/8_Storage.py`
- `ui/pages/9_Logs.py`
- `ui/password_hashing.py`
- `ui/session_context.py`
- `ui/table_display.py`
- `ui/table_inspector.py`
- `ui/ux_helpers.py`
- `view/api_view.py`
- `view/console_view.py`

