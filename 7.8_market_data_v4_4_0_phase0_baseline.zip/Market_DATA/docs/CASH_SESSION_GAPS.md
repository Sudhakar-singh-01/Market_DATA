# Missing regular sessions after raw restoration

The completed 16-file session restoration preserved raw rows; it did not fill
missing regular sessions. `controller.cash_gap_cli` selects restored entries
whose report has zero regular rows and a positive expected/missing session.
It does not select full sessions or closed-calendar dates requiring review.

Run from the latest extracted project folder in Windows CMD:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_gap_cli --result "F:/TIOS_Runtime/recovery/cash_session_restore/session-138d6282868d44408ddb2154e1c6de00/result.json" --apply --writers-stopped --accept-provider
```

Stop data writers before using the flags. Omit the three flags for staging and
planning only. No full inventory rescan or prior provider-repair rerun is needed.

The expected current scope is HDFCBANK, ICICIBANK, RELIANCE and SBIN on
2026-10-23: 1,500 inserted rows, zero updates, four existing SQL-only rows
preserved. These are expectations, not hardcoded assumptions.

Fresh provider data must pass identity, OHLC, duplicates, source, closed-day,
calendar and full regular-session coverage checks. Current SQL must still be
off-session-only. Existing Parquet must match SQL. Auto-apply requires all
selected partitions READY and zero updates to existing rows. Existing shared
repair applies source hashes, backups, SQL preimages, locks, transactional SQL,
Parquet staging, readback and journaling. No cross-store atomic rollback is
claimed; retain the printed plan and journal if interrupted. Resume that exact
plan with `controller.cash_repair_cli apply --plan PATH --writers-stopped
--accept-provider`; do not blindly refetch after partial application.

Candidates and unique plans are under `TIOS_HOME/recovery/cash_session_gaps`.
Application reports are under `TIOS_HOME/recovery/cash_provider_repair`.
Raw data continues to include the off-session rows. Higher-timeframe rebuild,
regular-session read policy, February 1 special-calendar review and fresh global
verification remain separate steps. Historical fetching has no current-session
gate. Empty provider responses create no candle files or database rows.

Local focused validation: 109 tests passed on Linux/Python 3.12 with disposable
SQLite. Production Windows/MySQL verification requires the user's run.
