# Audit Phase 0 — baseline evidence

Recorded: 2026-10-30. This phase changes no application behavior, database schema,
market data, configuration, or runtime state. It establishes the evidence that later
audit phases must preserve.

## Accepted runtime baseline

The following production observations were supplied by the operator and were not
replayed against production during this phase:

- CASH `SBIN`, 2026-10-23, regular session: 1m 375, 5m 75, 15m 25,
  30m 13, 1h 7, 1d 1; 1m pagination returns two pages and 375 unique rows.
- One off-session CASH row is excluded by `session=regular` and remains stored.
- FNO `BANKNIFTY26NOVFUT`: 385 1m rows for 09:15–15:39 under the existing
  all-session policy. This does not certify FNO regular-session filtering.
- Consumer adapter checks passed for the reviewed scopes.
- SMA20 replay: CASH 375 inputs / 19 warm-up / 356 outputs; FNO 385 / 19 / 366.

These are point-in-time observations, not a permanent data certificate. Current data
must still pass the verified read boundary.

## Cloud baseline executed

Completed deterministic suites:

```text
tests/test_release4.py                 17 passed
tests/test_consumer_adapter.py         15 passed
tests/test_market_data_client.py       31 passed
tests/test_unified_workflow.py         21 passed
tests/test_workflow_integration.py      3 passed
tests/test_sma.py                      11 passed
tests/fno/test_quality_release4.py     29 skipped (disposable MySQL unavailable)
Total completed                         98 passed, 29 skipped
```

`tests/test_read_api.py` and `tests/test_client_api_integration.py` cannot complete
in this executor. The first API request blocks before application assertions execute.
The same failure reproduces with a minimal FastAPI application and with a raw
cross-thread asyncio wake-up, after testing both the resolved dependency versions and
a known compatible FastAPI/Starlette/HTTPX/AnyIO set. This is an executor limitation,
not evidence that the API tests pass or fail on Windows.

## Required Windows CMD validation

Run from the extracted project directory. These commands use local SQLite/Parquet
fixtures unless a test explicitly reports that MySQL configuration is required.

```bat
py -3.13 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt -r requirements-api.txt -r requirements-client.txt
.venv\Scripts\python.exe -m pytest -q tests\test_release4.py tests\test_consumer_adapter.py tests\test_market_data_client.py tests\test_unified_workflow.py tests\test_workflow_integration.py tests\test_sma.py
.venv\Scripts\python.exe -m pytest -q tests\test_read_api.py tests\test_client_api_integration.py
```

Expected result: both pytest commands finish with no failures or hangs. The Windows
validation reported 40 API tests passing and exposed two cross-platform issues that
were corrected: test isolation from a configured `TIOS_HOME`, and explicit closure of
the scratch SQLite duplicate-key index before temporary-directory cleanup. MySQL-backed
FNO suites are a separate runtime check and must use a disposable test database, never
the production `market_data` or `fno_market_data` databases.

No recovery, cleanup, migration, provider request, full historical scan, or production
database write is part of this baseline.
