# Shared market data boundary — milestone 1

This additive release preserves the existing Cash/FNO ingestion, normalization,
validation, retry, quota, aggregation and persistence implementations. It adds
one Python command facade, one stored-data read service, a GET API and an admin
catalog covering every table in the configured Cash and FNO databases.

## Run

From the market_data directory, with your existing config/.env and data settings:

```sh
python -m pip install -r requirements-api.txt
python -m api --port 8000
```

Interactive API documentation: http://127.0.0.1:8000/docs
Use HTTP Basic username `user` or `admin` and the corresponding existing dashboard
password (USER_PASSWORD_HASH / ADMIN_PASSWORD_HASH). The server binds to loopback.
For remote service access, put authentication and TLS at the deployment boundary;
this release does not configure remote hosting.

Run the existing dashboard separately:

```sh
python -m streamlit run ui/dashboard.py
```

Admin navigation now includes **All Databases & Tables**: configured database
availability, discovered tables, columns, primary/foreign keys, indexes, filtered
row pages, explicit counts and CSV export of the displayed page. Catalog reads
never create or alter tables. Existing Operations, Checkpoints and FNO management
screens retain their current write actions. Step 2 adds an explicit Schema Manager for missing tables and Cash pipeline
metadata migrations; see SCHEMA_MANAGEMENT.md. Whole database creation and
deletion remain outside this release.

## Fetch, clean, validate and persist

`controller.market_data_service.MarketDataService` delegates commands to the
existing PipelineService (Cash) and FnoService (FNO). Administrator role is checked
before initializing either ingestion service. This is an internal Python facade;
its role argument is a trusted caller contract, not remote authentication.

```python
from controller.market_data_service import MarketDataService
service = MarketDataService()
params = {'from':'2026-10-16', 'to':'2026-10-16', 'symbols':['SBIN']}
preview = service.preview_fetch('CASH', params, role='admin')
job = service.submit_fetch('CASH', preview['params'], role='admin')
```

Use existing FNO job parameter shapes for FNO requests. FNO ATM preview may call
FYERS quotes; submit its returned params to retain that selection. Fetching and
verification are separate jobs: a successful fetch alone is not a certificate.
`submit_aggregation`, `submit_verification`, and `job_action` expose the existing
job types. Existing cancellation/resume behavior is retained. No fetch or repair
runs as a side effect of an HTTP GET.

## Read methods and endpoints

All endpoints below use the `/api/v1` prefix and require authentication.

| Endpoint | Purpose | Role |
| --- | --- | --- |
| GET /instruments | Cash/FNO instrument catalog, cursor pages | user/admin |
| GET /candles | Symbol/timeframe/date scope, raw or verified, cursor pages | user/admin |
| GET /candles/latest | Latest stored candles and age, without a seven-day cutoff | user/admin |
| GET /coverage | Calendar-aware observed minute coverage | user/admin |
| GET /fno/option-chain | Stored snapshot batches including available Greeks | user/admin |
| GET /jobs/{job_id} | Safe job progress/status fields | user/admin |
| GET /quality | Historical quality findings, not certificates | admin |
| GET /databases | Configured database availability | admin |
| GET /databases/{segment}/tables | All discovered tables | admin |
| GET /databases/{segment}/tables/{table}/schema | Structure and indexes | admin |
| GET /databases/{segment}/tables/{table}/rows | Bounded rows and equality filters | admin |
| GET /databases/{segment}/tables/{table}/count | Explicit exact count | admin |

Example request (supply credentials through your client's authentication option):

```text
GET /api/v1/candles?segment=CASH&symbol=NSE%3ASBIN-EQ&timeframe=1m&from=2026-10-16&to=2026-10-16&quality=verified&limit=1000
```

Responses include `data`, `meta` and `quality`. To retrieve all data, repeat the
same request with `meta.next_cursor` until it is null. Cursors are scope-bound;
a cursor for another symbol/timeframe/date scope is rejected. Page size is at most
1000. Candle pages are a live view, not a cross-request snapshot: concurrent
backfills/corrections require a new read after ingestion finishes. Table browsing
uses bounded offset pages with a primary-key order; tables without a primary key
are rejected for row browsing. Counts may be expensive on large tables.

Python consumers can reuse the same read service without HTTP:

```python
from controller.market_data_service import MarketDataService
reads = MarketDataService().reads
for candle in reads.iter_candles('CASH', 'NSE:SBIN-EQ', '1m',
                                '2026-10-16', '2026-10-16', quality='verified'):
    process(candle)  # Your module's function
```

Other methods: get_instruments, get_latest_candles, get_coverage,
get_option_chain, get_quality_report, get_job_status. See api/app.py for exact
query parameters and model/market_read_service.py for Python signatures.

## Quality and compatibility contracts

- Raw reads are explicitly NOT_VERIFIED. They expose stored data without silently
  cleaning it or claiming source completeness.
- Strict verified reads require SQL and Parquet, historical closed days and a
  verified market calendar. They compare stores, validate candles and coverage,
  and recompute derived candles from canonical minutes. FNO also checks the
  Parquet manifest checksum. Mismatch returns HTTP 409 with no partial data.
- Sparse option values can pass parity/validity while coverage stays
  SPARSE_UNCONFIRMED. An absent minute is not proof of no trades. Empty trading
  sessions cannot be certified without no-trade evidence. Futures require full
  expected coverage. Holidays report NO_SESSION, not market incompleteness.
- SQL coverage observations are never a verification certificate. Old quality
  reports do not certify later data; strict reads recheck the requested scope.
- Raw date scopes allow 3661 inclusive days; verified scopes allow 31; coverage
  allows 366. Each verified page rechecks its whole scope. Use small date chunks
  for large histories. This favors correctness over caching performance.
- Timestamps are ISO IST (+05:30). SQL Decimal values serialize as strings to
  preserve precision; Cash strict reads retain the existing Candle float values.
  Consumers should parse numeric fields explicitly. Optional FNO fields stay null.
- Option-chain pages are oldest ID first, contain locally captured snapshots only,
  and preserve batch_id. This does not reconstruct uncaptured historical chains.
- The new paginated API requires configured SQL storage. Existing Parquet-only CLI
  behavior is retained; strict verification requires both stores. Read-only API
  startup does not require FYERS credentials and does not consume broker quota.
- Cash and FNO factories remain isolated; the FNO database identity guard is reused.
  No schema migrations or existing data conversions are included.

## Validation and next steps

New regression tests exercise real SQLite queries and Parquet files: segment
isolation, cursor scope, bounded reads, Cash full-session verification, FNO sparse
verification, corruption/mismatch rejection, auth/roles, SQL read-only behavior,
calendar coverage and command delegation. Full test results are in RELEASE_NOTES.md.
Live MySQL, Windows launch and authenticated FYERS calls require deployment-side
validation; the development environment has no MySQL server or broker credentials.

Step 2 now adds previewed schema setup through existing ownership and migration
definitions (SCHEMA_MANAGEMENT.md). Next: broader database lifecycle operations
with dual-storage recovery and disposable-MySQL regression tests. Preserve separate Cash/FNO business rules;
then extract additional duplicated helpers only when behavior tests prove parity.
