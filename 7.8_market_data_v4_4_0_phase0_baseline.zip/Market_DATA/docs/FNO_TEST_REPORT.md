# Release 3 test report

Final validation date: 2026-10-23.

## Executed results

- Full suite: **431 passed, 0 skipped**, 2267 warnings, 34.34 seconds.
- Command: `python -m pytest tests -q` from the project root, with an isolated real MariaDB server available to the test fixtures.
- Raw final output: `FNO_TEST_OUTPUT.txt`.
- Python compile check passed for `controller`, `model`, `ui` and `tests`.
- Both new CLI help commands executed successfully.
- Streamlit server started on loopback; `/_stcore/health` returned HTTP 200 with `ok`.
- Five deliberate code mutations were detected by the targeted tests; each produced failing assertions, and original code was restored afterward.

## Environment

| Component | Tested version |
|---|---|
| OS / Python | Linux / 3.12.14 |
| Database | MariaDB 10.11.14 (real MySQL-protocol server) |
| FYERS SDK | 3.1.10 |
| Streamlit | 1.66.1 |
| pandas / PyArrow | 2.2.3 / 26.0.0 |
| SQLAlchemy / PyMySQL | 2.1.6 / 1.2.3 |
| pytest | 9.1.1 |
| python-dotenv / PyYAML | 1.2.4 / 6.0.3 |
| Plotly / requests | 7.1.0 / 2.31.0 |

The SDK import compatibility check uses the user's stated 3.1.10 version. FYERS network interactions in tests are fakes; no real account/token was used. Windows and the user's MySQL 8.0 server were not executed here. Existing dependency requirements are preserved; these versions document the validation environment, not a mandatory upgrade of a working installation.

## Coverage added

- Session start/end, all five targets, shortened final buckets, exact Decimal OHLCV, last non-null OI and NULL IV/Greeks.
- Missing/OPEN/duplicate/invalid inputs and still-forming buckets.
- Dual-store rebuilds, historical corrections, removal of stale derived buckets, other-contract preservation, idempotence and isolated Cash database fingerprint.
- Failed Parquet write leaves no VERIFIED checkpoint; persisted resume restores consistency.
- Job cancellation, recovery and aggregation-detail heartbeats; live stop closes a blocking fake socket and flushes.
- Full-day quality pass and negative tests for altered OHLCV, source mismatch, missing files, empty checkpoint claims, chain values and MySQL-only chain files.
- Read-only verification preserves data and files, with only job/findings records changing.
- SQL-level conflicting writes cannot fill OI, and ignored LIVE rows cannot fill historical Parquet fields.
- Concurrent same-partition writes preserve both contracts; option-chain retention uses its own cutoff.
- All 12 Streamlit sections render for both roles; lazy sections, empty/error states, request preview, confirmation gates and stale selections are exercised.
- Service permissions, stale delete preview, atomic database audit, pagination/filtering and secret-free settings.
- CLI local aggregation/verification run without FYERS authentication; queue duplicate prevention and ordered-date validation are tested.

## Mutation checks

| Deliberate defect | Result |
|---|---|
| Shift session buckets from 09:15 to 09:16 | Detected |
| Select first OI instead of last non-null OI | Detected |
| Accept buckets missing source minutes | Detected |
| Allow conflicting SQL rows to fill optional fields | Detected |
| Remove the admin role guard | Detected |

Two supplied tests originally encoded behavior corrected by this release: one allowed conflicting SQL OI fill, and one accepted a successful/verified harvest despite malformed rows. Their expectations now match the documented strict policy. The migration inventory test includes the new seventh SQL file/tenth table. The stale-heartbeat test now creates its fixture in IST, instead of assuming the host timezone.

Warnings are inherited SQLite datetime-adapter deprecations and the FYERS SDK's `pkg_resources` deprecation; they are shown in the raw output, not suppressed.

## Run locally

Use disposable databases `market_data_test` and `fno_market_data_test`, with a test-only account granted access to those databases. These fixtures clear their test tables; never point test settings at production data.

```bat
set FNO_TEST_DB_HOST=127.0.0.1
set FNO_TEST_DB_PORT=3306
set FNO_TEST_DB_USER=fnotest
set FNO_TEST_DB_PASSWORD=fnotest
python -m pytest tests -q
```

Without a reachable test server, DB tests explicitly skip; that is not equivalent to this full result. Live FYERS historical/OI and expired-contract acceptance remain pending as described in `FNO_RUNBOOK.md`.
