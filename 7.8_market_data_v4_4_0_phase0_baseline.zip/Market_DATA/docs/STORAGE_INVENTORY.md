# Read-only storage inventory

Run from the extracted project directory. This command does not connect to
MySQL/FYERS, import application credentials, change Parquet or update manifests.
Only the explicitly requested new JSON report is written; it is never overwritten.
Stop dashboards/workers before scanning for a stable result. Backup existing
MySQL databases and the permanent profile before any later consolidation.
This scanner does not create a database backup or perform consolidation.

Windows CMD (one line; also works in PowerShell):

```text
python -m controller.inventory_cli --source "F:/_software/_New_Trading_Tool/code/!!project" --cash-root "F:/TIOS_Runtime/data/cash" --fno-root "F:/TIOS_Runtime/data/fno" --output "F:/TIOS_Runtime/inventory_01.json"
```

The source parent includes !!versions and other project releases. Repeat
--source for additional locations outside that parent. Pass actual effective
storage roots if your configuration has custom overrides; this command
intentionally does not guess roots from credentials or config. Both target
roots must already exist and be separate. Use a new output filename on reruns.

Report meanings:

- TARGET_PRESENT: every discovered copy for this partition has identical bytes
  and the expected target exists. No content-quality guarantee.
- MISSING_TARGET_CANDIDATE: target absent, one byte variant discovered.
  It is a candidate for validation, not approved for automatic import.
- DIFFERENT_BYTES_REVIEW: multiple SHA256 variants for the same segment/relative
  partition. This may reflect different rows, metadata or compression, not
  necessarily conflicting candle values. target_present reports whether the
  destination is among the copies. Never choose the largest/newest blindly.
- identical_byte_groups: paths containing byte-identical copies.
- unclassified: Parquet filenames outside recognized current layouts; retained
  for manual review. No claim that old formats are absent.
- issues: inaccessible/changed files, traversal errors or skipped links/junctions.
- excluded_directories: backups, backup, quarantine, recovery, .git, .venv,
  venv, __pycache__, node_modules. Archived/quarantined data needs a separate
  recovery review and is intentionally not proposed as active data.

Cash keys preserve raw/processed; FNO keys preserve timeframe, underlying,
expiry and date. Different expiries are separate partitions. Every recognized
file is streamed through SHA256; no full dataset is loaded into memory.
Only active recognized Parquet layouts are compared. CSV/ZIP/MySQL data,
schemas, candle rows, timestamps, market sessions, aggregation and SQL/Parquet
parity are not inspected. No manifest status is changed.

Exit 0 means inventory completed for the stated scope, even if candidates or
byte differences were found. Exit 2 means incomplete (issues or unclassified
Parquet paths); inspect the JSON. Exit 1 means a root/output/scan failure.
Output parent must exist. Reports contain local paths but do not read secrets.
Report complete=true is not a data-quality or full-backup certification.
Concurrent writes are unsupported: per-file metadata changes during hashing
are detected, but the whole directory tree is not an atomic snapshot.

Validation:

```text
python -m pytest -q tests/test_storage_inventory.py tests/test_runtime_profile.py tests/test_runtime_setup.py tests/test_storage_scope.py
```

Build environment: Python 3.12, 38 focused tests passed. Actual Windows Python
3.13 execution and the user's full old-folder scan remain to be performed.
