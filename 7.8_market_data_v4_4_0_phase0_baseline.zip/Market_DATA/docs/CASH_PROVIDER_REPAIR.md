# Reviewed Cash provider repair

This operation applies the already staged historical candidates to raw 1m SQL/Parquet. It does not fetch again. It is an explicit provider-preference policy, not independent proof that every provider value is correct.

## Scope and invariants

- Provider timestamps replace matching SQL OHLC/volume/source/status values. Existing SQL row IDs and creation metadata remain unchanged.
- Missing provider timestamps are inserted. SQL-only timestamps are retained in both SQL and the resulting Parquet.
- The 16 session-preservation outcomes are DEFERRED. No calendar exception is invented; existing global quality gates are unchanged.
- A present destination must agree with SQL at planning time, otherwise that partition is BLOCKED. Unknown target-only records are never silently removed.
- Planning reads source hashes, SQL, instrument identity, and destination state. It saves complete normalized before/after records and exact expected counts.
- Apply requires writers stopped and --accept-provider. Source hashes, metadata, before/after hashes, SQL state and target bytes are rechecked.
- Before mutation, full scoped SQL rows (including IDs) and existing target bytes are backed up. Missing targets are recorded by the plan. The new Parquet is staged and read back before SQL commit.
- Each SQL partition updates/inserts in a transaction with readback. Target publication occurs after commit under the existing file lock. There is no atomic transaction spanning MySQL and filesystem.
- If publication fails after SQL commit, retain the SAME plan and rerun apply. Exact before/after-state checks permit resume; unrelated changes block the partition. No automatic rollback across stores is claimed. A later resume can report the original planned counts; they are not a count of new changes on that attempt.
- A stopped writer acknowledgement is essential: readers can otherwise see a brief SQL/Parquet mismatch, and a noncooperating writer cannot be controlled by a file lock.
- No SQL DELETE, schema changes, original-source deletion, checkpoint changes, FNO changes or automatic derived-timeframe writes occur.

## Commands (Windows CMD, latest build main.py directory)

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_repair_cli plan --result "F:/TIOS_Runtime/recovery/cash_resolution/resolution-766f2dab32c447fba9edb630dd132cd9/result.json" --output "F:/TIOS_Runtime/cash_provider_repair_plan_01.json"
```

Expected if production state is unchanged: READY 45, DEFERRED 16, inserted 552, updated 2770 (2060 market-value plus 710 metadata-only rows), preserved_sql_only 231. Existing targets may cause additional BLOCKED entries; inspect rather than bypass. Do not apply if counts differ unexpectedly.

```bat
python -m controller.cash_repair_cli apply --plan "F:/TIOS_Runtime/cash_provider_repair_plan_01.json" --writers-stopped --accept-provider
```

All writers must be stopped for apply. Expected successful base batch: 45 VERIFIED, 16 deferred, status PARTIAL. One unique report is saved automatically under recovery/cash_provider_repair/<plan digest>/. Previous results and backup attempts are retained.

## Completion limits

`VERIFIED` here means resulting raw SQL/Parquet agreement, including preserved SQL-only rows. It is not regular-session quality certification. The 16 session cases remain deferred. Aggregation status is NOT_REBUILT and affected partitions are recorded. Do not treat pre-existing higher-timeframe data as verified against repaired 1m until a separate rebuild/verification step succeeds. Rebuild is deliberately not wired into this mutation: existing strict quality checks may reject the preserved off-session rows and require a reviewed session policy first.

Tests cover insert/update preservation, existing/absent targets, stale SQL/target rejection, backup failure, transaction rollback, failed post-commit publication and same-plan resume. Local tests use Python 3.12 and disposable SQLite; actual Windows/MySQL execution is not claimed.
