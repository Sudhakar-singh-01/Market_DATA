# FNO runbook — Release 3

Release date: 2026-10-23. Local Python / Streamlit / MySQL-compatible database / Parquet system. No real-money execution. This release extends the supplied code; the Cash-market subsystem remains separate.

## Installation and migration

Follow `../START_HERE.md` from the project root. Preserve your existing credentials, database names and data directories. FNO requires its own database and explicit `FNO_DB_HOST`, `FNO_DB_PORT`, `FNO_DB_NAME`, `FNO_DB_USER`, `FNO_DB_PASSWORD`; the guarded engine refuses `FNO_DB_NAME == DB_NAME`.

```bat
python main.py fno-migrate
python main.py fno-migrate --apply
python -m streamlit run ui/dashboard.py --server.address 127.0.0.1
```

Migrations are explicit and idempotent. `001`–`006` are the supplied SQL files; `007_audit_log.sql` adds `fno_audit_log`. There are now ten FNO tables. The dashboard Settings section can apply these migrations only after an admin confirms the displayed plan. FNO operations never use the Cash-market tables or its audit table.

## Daily operating routine (IST)

1. Before 09:00: refresh the token, then sync real contract symbols.

   ```bat
   python -m model.fyers.auth
   python main.py fno-sync-contracts
   ```

2. From 09:15: start the FNO live socket. Stop any Cash-market live socket first. In another terminal, collect chain snapshots if needed.

   ```bat
   python main.py fno-live --underlyings NIFTY BANKNIFTY --expiries 2
   python main.py fno-chain-snapshot --loop
   ```

   The REST limiter is per process, not per account/machine. Two CLI processes have separate budgets. The dashboard shares one limiter among its FNO workers. Do not run bulk historical work during live ingestion. FNO live jobs and direct FNO live CLI use a database lock to prevent duplicate FNO sockets; this lock does not manage the existing Cash socket.

3. After 16:00: stop both live/chain processes first; harvest authoritative history. Replace the example date with the trading date being processed.

   ```bat
   python main.py fno-historical --underlyings NIFTY BANKNIFTY --expiries 2 --from 2026-10-23 --to 2026-10-23
   python main.py fno-reconcile --from 2026-10-23 --to 2026-10-23
   python main.py fno-aggregate --underlyings NIFTY BANKNIFTY --from 2026-10-23 --to 2026-10-23 --timeframes 5m 15m 30m 1h 1d
   python main.py fno-verify --underlyings NIFTY BANKNIFTY --from 2026-10-23 --to 2026-10-23
   ```

   Harvest now prints the full job result, including `live_superseded`, `live_superseded_changed`, `invalid_reasons` and `conflicts`. A response containing rejected/conflicting rows cannot advance a fresh VERIFIED checkpoint; accepted rows remain stored and the outcome is PARTIAL.

## Aggregation

`fno-aggregate` reads FNO canonical 1m candles and rebuilds the selected contract/date range. Optional `--contract-ids 123 456` selects exact IDs; `--submit-only` queues it; `--no-parquet` explicitly chooses MySQL-only output. Local aggregation/verification do not authenticate FYERS.

Buckets start at **09:15 IST**, end at **15:40 exclusive**, and include the last source minute **15:39**. Full sessions have 385 expected minutes. A full day yields:

| Target | Buckets | Last bucket |
|---|---:|---|
| 5m | 77 | 15:35–15:39 |
| 15m | 26 | 15:30–15:39 |
| 30m | 13 | 15:15–15:39 |
| 1h | 7 | 15:15–15:39 |
| 1d | 1 | 09:15–15:39 |

OHLCV uses the existing shared combiner without changing the Cash aggregator. OI is the last non-null source OI; IV/Greeks remain NULL. Every expected minute must exist, be valid and CLOSED. Missing, incomplete and still-forming buckets are counted separately; no synthetic bars are created. This conservative rule also applies to Options until real data supports a different policy.

Reprocessing intentionally recomputes the requested range, including already checkpointed days, so historical corrections replace stale derived values. It removes stale derived buckets that are no longer complete. Canonical 1m rows retain their original write policy. `AGGREGATION` checkpoints belong to the target timeframe and advance only for complete, verified days after the session buffer. A failed write leaves the day unverified; resume rebuilds it.

The generic persisted job has heartbeat/cancel/resume state in `fno_ingestion_jobs`. Each target also has a detailed row in `fno_aggregation_jobs` with input/output/skipped counts and a JSON link to the parent job. Stale-parent recovery marks its running aggregation details INTERRUPTED.

## Verification

`fno-verify --from DATE --to DATE [--underlyings ...] [--contract-ids ...] [--submit-only]` persists a job and findings in `fno_data_quality_results`. Verification never deletes data, resets checkpoints, refetches, repairs or rewrites files. Job/finding records are its only writes.

Checks cover candle values and session/bucket timestamps, duplicate keys, contract metadata, optional-field null counts/rates, source-vs-aggregate equality, live freshness, empty VERIFIED checkpoint claims, file status/checksum/schema/count/timestamp bounds, and MySQL/Parquet candle and chain values. Chain count checks catch MySQL-only snapshots too.

Futures gaps on days with observed contract data are WARNING findings. Options report first/last observation, observed count and largest silent stretch as NOT_VERIFIED, never FAIL merely for missing minutes. Days with no observed data are not assumed trading days. Listing dates, holiday completeness and actual tick-delivery completeness are not inferred.

Default contract scope is contracts with candles or checkpoints intersecting the date range; explicit IDs can inspect an otherwise empty contract. Queries process contract/day units, instrument/manifest pages and Parquet batches. Shared files are validated at partition scope, so a file finding can involve another contract in the same underlying/expiry/day. Run after writers stop for a stable storage comparison.

A FAIL means a detected inconsistency, not authorization to fix it. Read the results and choose a separate action. Reconcile repair copies missing canonical rows both ways; same-key value conflicts remain unresolved instead of being falsely reported repaired. Full all-time reconciliation retains the existing implementation and can be expensive; prefer bounded dates. Derived output can be repaired by rerunning aggregation. Option-chain repair is not implemented.

## Dashboard

Sidebar **FNO** opens one lazily rendered page with Overview, Option Chain, Futures, Options Contracts, Historical Fetch, Live Data, Aggregation, Storage Manager, Checkpoints, Jobs and Logs, Data Quality, Settings.

- Metrics come from FNO queries; tables have server-side pagination and available filters. CSV download exports the displayed page only.
- Historical Fetch displays the request estimate and current-process limiter usage before submission. The stored ATM selection is reused by the job.
- Long operations use persisted jobs. The dashboard runs finite work, one live worker and one chain worker in background threads. Closing a browser tab does not stop them while the Streamlit server stays alive. Jobs and Logs refreshes every three seconds, shows counters/results/errors, and lets admins cancel/resume or run pending work. There is no invented completion percentage.
- Live Stop/cancel closes the blocking socket and flushes the ingestor. An in-progress minute stays OPEN on mid-session shutdown; after session end it is CLOSED.
- Storage Manager reads only VERIFIED files and checks their checksum before preview. MySQL deletion is explicitly MySQL-only; Parquet and checkpoints remain. Reconcile repair may restore deleted rows from Parquet.
- Checkpoint reset never deletes candles. Data actions show the exact selection/count and require confirmation. A changed selection must be previewed again. Database deletion/reset and the FNO audit row commit together.
- Retention previews list the exact files. Cleanup removes old candle Parquet files and old option-chain Parquet files according to separate cutoffs. MySQL is not pruned. Audit records capture approval and successful completion; on an interrupted cleanup, inspect the approval record and rerun a preview.
- Settings exposes paths/limits/database host/port/name, excluding credentials. Edit local configuration files and restart Streamlit to reload cached settings.

## Jobs and CLI reference

```bat
python main.py fno-jobs --list
python main.py fno-jobs --run
python main.py fno-jobs --worker
python main.py fno-jobs --cancel 123
python main.py fno-jobs --resume 123
python main.py fno-cleanup --retain-days 400 --chain-retain-days 120 --dry-run
python main.py fno-cleanup --retain-days 400 --chain-retain-days 120 --confirm
```

Replace example IDs with actual job IDs. Cancel PENDING jobs immediately; running jobs stop cooperatively at work boundaries. INTERRUPTED/PARTIAL/FAILED jobs can resume. Worker startup recovers stale RUNNING jobs. Long-running LIVE/CHAIN jobs occupy worker threads; the dashboard gives them dedicated threads. A headless worker with concurrency 1 should be used for finite queued jobs or have concurrency configured for continuous jobs.

Exit codes: 0 success/no data, 1 error, 2 partial/unresolved/cancelled/interrupted, 3 identical active job. NOT_VERIFIED findings intentionally produce exit 2. `--no-parquet` verification records Parquet as NOT_VERIFIED.

## Storage and consistency

```text
data/fno/
  candles/<timeframe>/underlying=<U>/expiry=<YYYY-MM-DD>/date=<YYYY-MM-DD>.parquet
  option_chain/underlying=<U>/date=<YYYY-MM-DD>.parquet
  symbol_master/NSE_FO.csv
  quarantine/
```

Timestamps are IST wall-clock, naive in storage and aware in memory. Prices use Decimal at canonical/MySQL boundaries; existing Parquet representation remains numeric. Unknown optional values remain NULL.

Write order: MySQL/read-back → temporary Parquet file → validation → atomic rename → VERIFIED manifest → eligible checkpoint. These stores are not one transaction. Readers ignore non-VERIFIED manifests. Per-partition locks serialize cooperating FNO writers. A process crash or external/manual edit is still detected by verification/reconcile.

CLOSED historical data supersedes provisional live data; LIVE cannot modify CLOSED history. Conflicting same-source CLOSED candles neither replace OHLCV nor fill optional fields. Historical Parquet mirrors values accepted by MySQL. Derived data uses an explicit rebuild path, so historical corrections can change it without weakening the canonical 1m policy.

## Pending real-FYERS acceptance

The supplied handoff reports successful live and two-expiry chain runs. Those were not rerun against FYERS here. Three checks remain:

1. After 16:00 on a trading day, run historical harvest. Preserve the printed job result and examine live supersession/conflict/invalid counters.
2. Verify real OI and storage agreement:

   ```sql
   USE fno_market_data;
   SELECT source, COUNT(*) AS candles, SUM(oi IS NOT NULL) AS with_oi
   FROM fno_candles
   WHERE timeframe='1m' AND candle_timestamp >= '2026-10-23'
     AND candle_timestamp < '2026-10-24'
   GROUP BY source;
   ```

   Then run the bounded reconcile and verification commands above.
3. After an actually tracked contract expires (for the discussed 27-Oct expiry, on/after 28-Oct), sync contracts and choose a stored real symbol whose expiry has passed:

   ```sql
   SELECT fyers_symbol, expiry FROM fno_instruments
   WHERE expiry < CURDATE() ORDER BY expiry DESC LIMIT 10;
   ```

   Run `python main.py fno-probe --write-report --expired-symbol REAL_SYMBOL`. Repeat over subsequent weeks. An active monthly symbol is not an expired-contract test. Expired-history availability/retention remains unknown.

Do not overwrite the supplied `docs/FNO_API_FINDINGS.md` except when deliberately running a new real probe. This delivery preserves that file byte-for-byte.

## Limits and release status

The provided account probe established a 5 requests/second plan limit; configuration remains 4 with a reserved share. Minute/day limits remain unverified. Live ATM selection does not recenter intraday, `max_extra_sockets` remains unused, and sampled live volume may be attributed across a minute boundary until history supersedes it. No evening-session behavior or every-minute option-tick guarantee is assumed. `fno-cleanup` does not enforce MySQL retention.

| Phase | CODE | TEST | FREEZE |
|---|---|---|---|
| Existing foundation/master/harvest/live/chain | Preserved with documented bug fixes | Existing regressions run with real test DB; FYERS calls faked | Existing live/chain real evidence comes from handoff; harvest/expired acceptance pending |
| Release 3 aggregation | Complete | DB + Parquet, correction/rebuild, interruption/cancellation tests | Local validation complete; user-data acceptance pending |
| Release 3 verification | Complete | Positive/negative consistency and read-only tests | Local validation complete; user-data acceptance pending |
| Release 3 dashboard | Complete | Streamlit page/permission/confirmation tests | Local validation complete; Windows deployment acceptance pending |

See `FNO_TEST_REPORT.md` for exact test counts, versions, mutation checks and limitations. This release is not claimed to have been executed on the user's Windows/MySQL 8.0 server or live FYERS account.
