# Cash regular-session GET and Python reads

Adds an explicit `session=regular` option to `/api/v1/candles`, `MarketReadService.get_candles`, the HTTP SDK and the repository's strict iterator. No market data is rewritten. Existing defaults remain `session=all`. The latest-candle endpoint remains an unfiltered raw observation; it does not accept this new option.

## Run on Windows
Use the latest extracted project folder and existing runtime. The calendar update from the previous build must already be applied. Do not rerun recovery or reset either database.

CMD window 1:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m api --port 8000
```

If FastAPI/uvicorn are missing, first run `python -m pip install -r requirements-api.txt`. Restart any older API process before starting this build. The API binds only 127.0.0.1.

CMD window 2 (no API token or broker login needed):

```bat
curl -u admin "http://127.0.0.1:8000/api/v1/candles?segment=CASH&symbol=NSE:SBIN-EQ&timeframe=1m&from=2026-10-23&to=2026-10-23&quality=verified&session=regular&limit=1000" -o "F:\TIOS_Runtime\recovery\cash_session_read_01.json"
python -c "import json; d=json.load(open('F:/TIOS_Runtime/recovery/cash_session_read_01.json')); print(json.dumps({k:v for k,v in d.items() if k!='data'},indent=2))"
```

Enter the existing tool **admin password** at curl's password prompt, not the FYERS token or MySQL password. Do not place passwords in command text or share them. Expected on the previously checked, unchanged SBIN partition: returned=375, quality.status=VERIFIED, coverage=COMPLETE, meta.session_filter.excluded_rows=1. The stored 15:59 row remains in both stores. The response file contains all returned data for review.

HTTP 409 DATA_NOT_VERIFIED means the verification checks failed; it must not be bypassed by labeling a raw response verified. HTTP 401 concerns tool password authentication; 503 concerns connectivity/schema/configuration or unavailable source. No mutation is performed by these requests.

Optional focused tests:

```bat
python -m pytest -q tests/test_read_api.py tests/test_market_data_client.py tests/test_client_api_integration.py tests/test_cash_calendar_update.py
```

## Contract

- `session=all`: backward-compatible stored rows; existing strict validation rejects invalid/outside-session canonical history.
- `session=regular&quality=raw`: SQL session filter before pagination. Counts respect closed_only and span the full requested range before cursor/limit. Quality remains NOT_VERIFIED. This is not a cleaning or certification action.
- `session=regular&quality=verified`: requires CLOSED historical dates, a verified calendar, matching full SQL/Parquet records, non-session integrity and duplicate checks, and complete regular 1m coverage. Only after these checks are valid outside-session 1m rows excluded from the returned analysis view. Higher timeframes must match recomputation from regular base minutes; malformed or misaligned derived records are not silently hidden.
- Missing SQL or Parquet rows, mismatched prices even on excluded timestamps, invalid OHLC, duplicate timestamps, or missing regular minutes continue to fail verification.
- No-session days can return empty VERIFIED/NO_SESSION only when the strict stored-data checks pass. Unknown calendars fail regular mode even for raw reads. No filter decisions are guessed.
- Supported here for Cash only. `session=regular` with FNO returns a parameter error; default FNO behavior and sparse-option policy remain unchanged.
- Maximum 31 days per regular request. The SDK iterator automatically splits longer histories into <=31-day scopes.
- `meta.session_filter`: mode, excluded_rows, scope_rows, counts_scope, evidence. Verified results additionally expose excluded_base_1m_rows for derived consumers. Counts are per full request scope, not per page; do not sum repeated counts across pages. For 1m verified reads excluded_rows and excluded_base_1m_rows refer to the same excluded rows, not separate populations.
- Raw SQL counts and paginated rows are live observations and may change under concurrent writers. Verified reads check values against both stores but are not an atomic cross-store or cross-page snapshot.
- Regular cursors bind the mode and current calendar metadata; changing either invalidates the cursor. Old all-mode cursor contracts remain compatible.
- Calendar split sessions exclude the midday break. The close boundary is exclusive.

## Python consumers

```python
from getpass import getpass
from client import MarketDataClient

with MarketDataClient(username='admin', password=getpass('Tool admin password: ')) as client:
    for page in client.iter_candle_pages(
        'CASH', 'NSE:SBIN-EQ', '1m', '2026-10-23', '2026-10-23',
        session='regular', quality='verified', limit=1000,
    ):
        print(page['meta']['session_filter'])
        candles = page['data']
```

The SDK rejects a response that does not explicitly confirm the regular-session mode/count fields, so an older server cannot silently ignore this request. Existing user-role authentication can also read candle endpoints.

Direct in-process `MarketReadService.get_candles(..., session='regular', quality='verified')` has the same contract. `MarketDataRepository.iter_verified_days(..., session='regular', audit=[])` retains its original yielded (day, candles) shape; the optional caller-owned audit list receives per-day excluded counts. No broker flow is embedded in any read method.
