# Schema management: setup and compatibility checks (Steps 2 and 7)

Launch the existing dashboard and open Admin → Schema Manager.

1. Select configured CASH or FNO database.
2. Use **Check schema compatibility (read only)** and download its report.
   It checks all repository-owned tables in the selected database, including the
   Cash pipeline metadata additions. It does not fetch market data or run DDL.
   Choose `missing_tables` to create absent tables from existing repository SQL.
   For Cash, run `cash_pipeline` afterwards to add existing pipeline job columns
   and indexes. The audit table must exist first.
3. Preview and download the exact SQL plan, compatibility findings and blockers.
   Existing incompatible definitions require review; the manager does not generate
   ALTER TYPE, DROP, constraint repair, or data cleanup statements.
4. Stop ingestion and other schema writers. Take and verify a database backup.
   Check the acknowledgment, type `APPLY <database name>`, re-enter the admin
   password and apply the reviewed plan.
5. Inspect the result and journal. Re-run compatibility after each operation.
   SUCCESS means the reviewed statements completed, not that all schema issues
   were resolved. `missing_tables` can still require `cash_pipeline` afterwards.
   Remaining missing columns/keys outside those two operations require a separately
   reviewed migration; they are never silently repaired.

## Compatibility contract

The report derives its expected schema from the existing repository CREATE TABLE
definitions and `model.quality_store.ADDITIONS`; there is no second hand-maintained
schema copy. Unsupported repository DDL grammar raises an error before changes.

It compares column type/unsigned flag/length/precision, nullability, defaults,
AUTO_INCREMENT and ON UPDATE, primary keys, named indexes with ordered columns,
uniqueness and prefix lengths, foreign-key targets/actions, CHECK expressions and
the InnoDB table engine. It preserves Cash/FNO differences (for example decimal
precision and nullable derivatives fields).

Findings are `MISSING`, `BLOCKING`, `UNVERIFIED` or `EXTENSION`, with expected and
actual metadata. Extra ordinary indexes, nullable/defaulted columns and unrelated
tables are extensions; extra required columns and restrictive unique/FK/CHECK
constraints block because they can break existing writes. Unknown critical
reflection metadata blocks apply rather than certifying compatibility.

The report does not compare charset/collation, index algorithms/visibility, or
certify triggers, permissions, stored routines, row validity, SQL/Parquet parity,
or restore readiness. CHECK normalization is deliberately conservative: server
rewrites that cannot be matched safely require review, even if semantically equal.
Real MySQL/MariaDB version-specific reflection still needs deployment validation.

Both supported migration operations retain their fixed allowlist. Existing-schema
BLOCKING/UNVERIFIED findings disable apply in the dashboard and service. Before
adding the Cash active-job unique index, a bounded-result duplicate-key check
blocks conflicting existing keys without returning their values. NULL keys are
allowed. There is no automatic deletion, cancellation or deduplication of jobs.
This GROUP BY can scan the table; run maintenance with writers stopped.

Preview includes these findings and apply repeats the complete preflight under
the existing advisory lock. It rejects stale/tampered plans. Confirmation widgets
are bound to the plan token. A local journal records each attempted/completed
statement, including partial failure. External writers can still race preflight,
so stopping them and keeping a verified backup remain required.

The manager uses configured existing databases only. It does not run the hardcoded
`CREATE DATABASE` or `USE market_data` lines in the Cash script. It extracts only
owned CREATE TABLE definitions, preserves dependency order, and excludes FNO
exchange-code data updates. No arbitrary SQL/table names/file paths are accepted.
The existing FNO engine isolation guard remains mandatory. GET endpoints remain
read-only; schema actions are available through the admin dashboard/Python service.

`SchemaManager.preview` and `apply` require the trusted internal admin role.
The dashboard also requires password reauthentication. Plans are re-derived on
apply and compared against the reviewed plan, database target and schema snapshot.
This prevents modified SQL or stale preview reuse. A process lock plus MySQL
GET_LOCK serializes this manager across processes; external scripts are not bound
by that advisory lock and must be stopped separately.

MySQL DDL is **not rollback-safe**. Each completed statement is journaled to
`logs/schema_operations/<operation-id>.jsonl`. The journal is opened and flushed
before DDL; a journal failure blocks further work. If execution fails, already
committed statements remain. Inspect the journal and database, then preview again;
never assume a failed operation changed nothing. A crash after STATEMENT_START
without STATEMENT_DONE means the statement outcome is unknown: inspect the schema.
The journal is not a data backup or automatic restore mechanism. Restore verified
backups using your existing database administration process when required.

This step creates missing owned tables and reuses the existing Cash metadata
migration plan. It does not repair incompatible existing definitions, create/drop
whole databases, drop tables, or delete market data. Existing scoped data deletion,
checkpoint and FNO management screens remain unchanged. Further destructive
lifecycle actions require their own scope previews, dual-storage consistency and
recovery workflows before implementation.

Tests include disposable SQLite orchestration (not MySQL DDL compatibility),
real repository statement selection, role/confirmation checks, tampering, stale
plans, preserved rows, journal failures and partial DDL results. A separate MySQL
integration test exercises guarded identity and advisory locking; it skips when
no disposable MySQL test server is available.

Step 3 adds Admin → Backup & Recovery for SQL/Parquet archives and fresh-folder
recovery staging. See BACKUP_RECOVERY.md. Checksum verification is not a successful
MySQL restore test; complete the documented separate-database recovery drill before
acknowledging a verified backup here.
