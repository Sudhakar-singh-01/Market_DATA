# Scoped data cleanup (Step 8)

Open **Administration → Scoped Data Cleanup**. This is an explicit maintenance
operation for one stored FYERS symbol/contract and at most 31 completed historical
IST calendar days. Both a configured SQL database and a separate Parquet root are
required. It never deletes instrument masters, job history or option-chain data.

## Review and execution

1. Select CASH or FNO, enter the exact stored FYERS symbol, select timeframe and
   inclusive dates. Find symbols in All Databases & Tables if needed.
2. Preview. Review SQL counts, progress records, file paths, matched/preserved rows
   and affected timeframes. The preview reads metadata/data but does not delete.
3. Stop ingestion, aggregation, live collection, scheduled jobs, external scripts
   and readers. Active persisted jobs block the operation. That check cannot detect
   every external writer or reader; maintenance isolation is your responsibility.
4. Take and verify a SQL/Parquet backup using Backup & Recovery and the documented
   separate-database restore drill. Retained Parquet originals are not a replacement
   for a complete verified backup.
5. Acknowledge backup and maintenance, type `CLEANUP <database>` and re-enter the
   admin password. Apply only the reviewed plan. Changing any input discards it;
   an execution attempt consumes the review to avoid accidental blind retry.
6. On success inspect the journal, re-fetch/rebuild the affected scope and use
   strict verified reads before downstream analysis. Historical READY/job records
   remain historical evidence; they do not certify data after cleanup.

## Scope and consistency

- Selecting `1m` includes all supported derived timeframes for those dates:
  `5m`, `15m`, `30m`, `1h`, `1d`. Selecting a derived timeframe affects only that
  timeframe. Whole days avoid leaving derived buckets partly valid.
- Cash partitions belong to one symbol/day. FNO partitions can hold multiple
  contracts for the same underlying/expiry/day: only the selected contract's rows
  are removed, and other contracts are preserved. FNO manifest checksums/counts
  are updated for rewritten partitions, or entries removed for empty partitions.
- Cash checkpoint high-water marks at or beyond the cleanup start are removed for
  affected timeframes. FNO overlapping checkpoint ranges are removed in full, and
  the selected contract's harvest-state row is discarded conservatively. This can
  cause re-fetch of a wider range; it prevents a historical hole being skipped.
- One-sided SQL-only/Parquet-only candle data is within scope; this is not a parity
  certification. FNO files must still have valid matching VERIFIED manifests.
  Invalid/missing manifests, mixed identities/dates, unexpected temporary files,
  unsafe paths or overlapping roots require reconciliation/review first.
- Plans bind database identity, instrument, SQL content, progress, file hashes,
  manifests and relevant schema. Apply repeats preflight under maintenance and
  partition locks. A same-count content change invalidates the plan.

Bounds: at most 200,000 rows per SQL snapshot and Parquet file; 128 MiB per file
and 512 MiB total selected file bytes (compressed and declared expanded sizes
are checked before loading). Narrow the scope if a limit is reached.
FNO manifest discovery can reach its row bound on very large histories. Metadata
and hash checks may scan more than the selected rows; this is a maintenance tool.

## Failure and recovery

SQL transactions and filesystem changes cannot commit atomically. The operation
retains original affected Parquet files outside the live reader tree and writes a
flushed journal under `logs/cleanup_operations/<operation-id>/`. The journal also
records original SQL rows and the reviewed scope. Treat that directory as private
market-data/admin material and preserve it with the backup.

An incomplete operation retains `RECOVERY_NEEDED` and blocks further cleanup
execution. Do not delete the marker merely to retry. Keep workers/readers stopped.
The journal's file intent/publication and SQL commit events explain what was
attempted; a crash after an intent can leave its outcome unknown. A SQL rollback
does not undo file publications, and an uncertain commit must be checked against
the database. The service never reports a global rollback.

Recover manually in a separate staging/recovery database first: inspect current
SQL, checkpoints, manifests and file hashes against the verified backup and
retained originals, choose one coherent before/after state, and validate it.
Do not simply copy original FNO files back without reconciling their manifest and
SQL state. After the production stores are coherent and validated, archive the
resolved operation directory outside the active cleanup journal directory, then
create a fresh preview. No automatic restore/retry or marker-clear action is
provided in this step.

## Existing operations and deployment checks

Legacy SQL-only delete and file-retention methods remain available with their
original scope. The Cash bulk-delete and FNO delete screens now point to this
coordinated workflow; they have not been silently changed. Existing ingestion,
validation, aggregation, read APIs and consumer code are unchanged.

Offline tests use actual SQLite transactions and Parquet files plus fault
injection; they do not validate MySQL's live transaction/lock behavior. Run the
optional MySQL integration test only against the disposable test databases.
FNO partition locks share one dedicated MySQL connection across the full scope,
using the existing writer lock namespace. Participating MySQL tables must be
InnoDB; visible triggers and cascading-delete side effects block cleanup.
The database account must have sufficient metadata visibility for these checks;
they cannot certify objects hidden by database permissions.
Windows filesystem durability/locking and interruption recovery must also be
tested on the deployment machine before using cleanup on valuable data. On
Windows files are flushed but directory fsync is unavailable through this helper.
