# Step 6: unified workflow dashboard

Start the existing dashboard from the project root:

```sh
python -m streamlit run ui/dashboard.py
```

Sign in with the existing admin account, then open Administration → Unified Workflow.
The page uses the Step 5 service and job workers. No new schema or API write endpoint
is introduced. Cash/FNO processing, quota, strict verification and resume semantics
remain unchanged.

## New workflow

1. Choose CASH or FNO and a closed historical date range (up to 31 days).
2. Cash: select explicit configured instruments. FNO: select underlyings, nearest
   expiries, strike window, futures/options. FNO preview may make spot quote calls.
3. Optionally select derived timeframes; canonical 1m is always verified.
4. Click Preview workflow. Inspect frozen targets, stages, estimates and parameters;
   optionally download the plan JSON. Changing any input invalidates that preview.
5. Check the review confirmation and Submit workflow. The page switches to the new
   persisted job in Monitor jobs. An identical active job opens the existing job
   instead of pretending another job was created.

A preview is consumed before dispatch. If submission fails or its outcome is
uncertain, inspect Monitor jobs before preparing/submitting again. This prevents
reruns from blindly repeating an uncertain submission. SQL deduplication is still
the final guard against identical active jobs.

## Monitor jobs

- Select segment, state and page (25 rows). Monitoring displays WORKFLOW jobs only.
- Enter an exact workflow job ID, including older jobs outside the visible page.
- Inspect frozen targets/date scope, job state, current stage, available counters,
  heartbeat, verification checks, verified rows and verification time.
- Refresh manually, or enable read-only refresh every five seconds. Refresh never
  submits jobs, fetches provider data, starts workers or resumes work.
- A verification percentage appears only when the workflow reports a check total.
  Fetch/aggregation uses available counters; no synthetic whole-pipeline percentage.
- READY is shown only for persisted SUCCESS with ready=true. It remains historical
  job evidence: consuming modules must still use quality=verified to recheck data.
- Detailed provider errors/credentials and arbitrary job params are not rendered.
  Frozen scope is an allowlisted projection of the persisted workflow specification.

## Controls

| Persisted state | Available action | Behavior |
| --- | --- | --- |
| PENDING / RUNNING | Request cancellation | Existing boundary-based cancellation |
| PENDING / RUNNING | Start/recover queue worker | Starts existing segment queue; may process other queued jobs and recover stale heartbeats |
| FAILED / PARTIAL / INTERRUPTED | Resume as a new job | Same frozen scope, new linked job ID; selected automatically |
| SUCCESS / NO_DATA / CANCELLED | No retry button | Create a fresh reviewed workflow |

Every action needs explicit confirmation. The service re-reads the selected job,
checks its type/state and checks admin role before dispatch. Queue worker scope is
shown explicitly; it is not presented as execution of only the selected job.
The same process-local worker lifecycle applies as before: keep the dashboard host
running while its jobs run, or use the headless worker/workflow command. If provider
credentials/configuration change, the cached worker client may require a controlled
restart before explicit resume. Inspect other active jobs before restarting.

## Validation

Streamlit AppTest exercises the real widgets/reruns: admin gate, Cash/FNO preview,
confirmation, changed-input invalidation, failure cleanup, automatic monitor switch,
resume/new-ID focus, READY timestamp and read-only refresh. Separate SQL-backed
adapter tests cover filtering/bounds, safe scope, permission/type/state checks and
duplicate submissions. Live Windows browser behavior and real FYERS/MySQL execution
remain deployment validation tasks.
