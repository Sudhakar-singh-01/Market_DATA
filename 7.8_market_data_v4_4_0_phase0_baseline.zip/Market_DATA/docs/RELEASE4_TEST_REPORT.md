# Release 4 validation report

Validated: 24 October 2026. **477 passed, 0 failed, 0 skipped** in 41.12 seconds; 2267 warnings retained in the raw output.

Command: `python -m pytest tests -q`, with a real isolated MariaDB process and disposable `market_data_test` / `fno_market_data_test` databases. No production database or FYERS account was used. Raw output: `RELEASE4_TEST_OUTPUT.txt`.

## Environment

| Component | Executed environment |
|---|---|
| OS / Python | Linux / 3.12.14 |
| Database | MariaDB 10.11.14, MySQL protocol |
| Streamlit | 1.66.1 |
| FYERS SDK | 3.1.10 |
| pandas / PyArrow | 2.2.3 / 26.0.0 |
| SQLAlchemy / PyMySQL | 2.1.6 / 1.2.3 |
| pytest | 9.1.1 |

## What was executed

- Full existing regression suite plus Release 4 tests; no skipped database tests.
- Real SQL and real Parquet tests: explicit/idempotent metadata migration, historical supersession of LIVE, immutable conflicting history, exact accepted-row propagation, partial-write reporting and no silent duplicate deletion.
- Smart Fetch: complete scope makes zero broker requests; internal missing minute gives an exact request; SQL/PQ conflicts, malformed or duplicate Parquet block fetch; token rejection interrupts after one request.
- Verification fingerprints confirm source SQL rows and Parquet bytes are unchanged; missing whole derived targets, empty-day checkpoint claims, altered values and wrong Parquet identity are detected.
- Strict Cash aggregation: session start, shortened final bucket, missing/duplicate/OPEN inputs, malformed/fractional volumes, finite values and no fabricated output.
- Durable jobs: role enforcement, duplicate submission, cancellation, heartbeat recovery, linked resume, streamed export and nonzero headless status for partial results.
- Scheduler: delayed-start catch-up, restart deduplication, retry after callback failure, and post-close buffer before marking the day scheduled.
- Shared persistent quotas: repeated limiter instances, separate expired allowance, corrupt ledger rejection and lock contention.
- Exact cross-batch Parquet duplicate detection on unsorted 4,000-row fixtures; oversized partition is rejected before batch materialization. This is bounded-behavior evidence, not a billion-row performance benchmark.
- Optional expired OI/Greeks mapped by column name; null retained; absent SDK method does not fall back to regular history. Network responses are fixtures.
- All nine quality views against a real test database, Master Tables read-only role, grouped dashboard, persisted-job progress/cancel controls, existing twelve-section FNO UI regressions and Today button click.
- Master sync rejects stale previews and ignores caller-tampered change content; actual writes and audit are transactional.
- Cash alert deduplication/retry/SENT transitions with an injected sender; no real notification sent.
- Strict analysis read iterator accepts complete consistent data and rejects source changes on a later read.
- Python compile check for model/controller/UI/tests/main passed.
- New CLI help commands (`quality-migrate`, `pipeline-worker`, `smart-fetch`) executed.
- Streamlit server started on loopback; `/_stcore/health` returned HTTP 200, `ok`.

Warnings are inherited SQLite datetime-adapter and FYERS `pkg_resources` deprecations. They were not hidden. Prior tests expecting 376 Cash minute starts, 2,000 Standard subscriptions, terminal rejection of any expired symbol, or retired UI tab layouts were updated to the new documented behavior. Tests use isolated runtime directories so repeated fake API calls cannot consume the installation's persisted budget.

## Not executed / not claimed

- The user's Windows/Python 3.13/MySQL 8.0 installation.
- Real FYERS history/live/expired entitlement, actual account rate limits or OAuth refresh.
- A physical browser Enter-key event: the existing form now explicitly enables Enter submission; form/role tests pass, but no browser binary was available for a keyboard-event test.
- Real Telegram delivery, production network disruption or a million/billion-row benchmark.
- The full TIOS indicator/strategy/backtest/event-bus application, absent from the supplied repository.
- Simultaneous Cash/FNO socket fan-out. This release enforces one live socket owner and mode switching.

## Local reproduction

Use disposable databases and a test-only account; fixtures clear their own test tables. Never point test settings at production.

```bat
set FNO_TEST_DB_HOST=127.0.0.1
set FNO_TEST_DB_PORT=3306
set FNO_TEST_DB_USER=fnotest
set FNO_TEST_DB_PASSWORD=fnotest
python -m pytest tests -q
```

If the database server is unavailable, DB tests explicitly skip; that does not reproduce this result. See the acceptance checklist in `RELEASE4_RUNBOOK.md` before freeze.
