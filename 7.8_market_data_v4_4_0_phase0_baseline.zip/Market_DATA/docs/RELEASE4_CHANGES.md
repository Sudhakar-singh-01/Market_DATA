# Release 4 file inventory

Compared against the Release 3 working snapshot taken before this build. Existing source architecture is retained.

## Added

- `controller/pipeline_cli.py`
- `controller/pipeline_service.py`
- `controller/verification_controller.py`
- `docs/RELEASE4_API_SPEC.md`
- `docs/RELEASE4_IMPLEMENTATION.md`
- `docs/RELEASE4_RUNBOOK.md`
- `docs/RELEASE4_TEST_OUTPUT.txt`
- `docs/RELEASE4_TEST_REPORT.md`
- `model/fno/capabilities.py`
- `model/master_management.py`
- `model/monitoring.py`
- `model/quality.py`
- `model/quality_store.py`
- `model/storage/locking.py`
- `model/verified_reads.py`
- `tests/fno/test_quality_release4.py`
- `tests/test_release4.py`
- `ui/home.py`
- `ui/monitoring_page.py`
- `ui/pages/12_Master_Tables.py`
- `ui/pipeline_page.py`
- `ui/quality_page.py`

## Modified

- `START_HERE.md`
- `config/fno_settings.yaml`
- `config/holidays.yaml`
- `controller/coverage_controller.py`
- `controller/fno_cli.py`
- `controller/fno_historical.py`
- `controller/fno_verify.py`
- `controller/health_controller.py`
- `controller/historical_controller.py`
- `controller/live_controller.py`
- `controller/scheduler.py`
- `controller/sinks.py`
- `main.py`
- `model/config/env_loader.py`
- `model/config/market_calendar.py`
- `model/fno/history_client.py`
- `model/fno/normalizer.py`
- `model/fyers/auth.py`
- `model/fyers/historical.py`
- `model/fyers/rate_limiter.py`
- `model/fyers/websocket.py`
- `model/processing/gap_detector.py`
- `model/processing/normalizer.py`
- `model/processing/timeframe_aggregator.py`
- `model/processing/validator.py`
- `model/repository.py`
- `model/storage/mysql.py`
- `model/storage/parquet.py`
- `tests/conftest.py`
- `tests/fno/test_fno_harvest.py`
- `tests/fno/test_fno_live.py`
- `tests/test_dashboard_layer.py`
- `tests/test_job_pages.py`
- `tests/test_market_calendar.py`
- `ui/auth.py`
- `ui/dashboard.py`
- `ui/date_inputs.py`
- `ui/fno/page.py`
- `ui/fno/service.py`
- `ui/job_manager.py`
- `ui/pages/11_Coverage_Heatmap.py`
- `ui/pages/2_Live_Market.py`
- `ui/pages/4_Historical_Data.py`
- `ui/pages/5_Aggregation.py`
- `ui/pages/7_Data_Quality.py`

No baseline source files were removed. Runtime budgets, caches, environment secrets and test databases are excluded from the release.
