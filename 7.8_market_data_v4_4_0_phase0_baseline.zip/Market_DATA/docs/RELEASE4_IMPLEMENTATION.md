# Release 4 implementation and requirement matrix

Scope: the supplied `market_data` repository, extended in place. This document supersedes the Release 3 statement that Cash pages are unchanged. Prior reports remain historical evidence.

## Inspected architecture and resulting changes

The app remains Streamlit; `ui/dashboard.py` is the entry point. Existing MVC controllers, SQLAlchemy repositories, canonical Cash `Candle` and FNO `FnoCandle`, FYERS adapters and Parquet sinks remain. No FastAPI/React rewrite, separate repository or parallel candle store was introduced. The supplied repository does not contain the complete TIOS indicator/strategy/backtest/event-bus implementation.

Cash schema starts with `instruments`, `candles`, `checkpoints`, `ingestion_jobs`, `audit_log`, `error_logs`. The explicit metadata migration adds two report/telemetry tables and extends `ingestion_jobs`. FNO retains its existing ten tables and seven migrations. Existing Cash and FNO IDs remain independent; underlying mappings use configured broker symbols. There are no invented exchange, timeframe or calendar master tables: these views read existing fields/YAML.

## Unified status

“Implemented” means present and locally tested in this release, not validated against the user's production data or account.

| Requirement | Status | Implementation / evidence | Remaining limit |
|---|---|---|---|
| Sketch sidebar, summary and content areas | Implemented | `ui/dashboard.py`, `ui/home.py` | Sketch is approximate; ambiguous handwritten labels were not invented |
| Market Data / F&O / Master Tables navigation | Implemented | Grouped `st.navigation`, existing page entry points | Existing Streamlit framework retained |
| Nine quality views | Implemented | `ui/quality_page.py`, `ui/monitoring_page.py` | PASS is scoped; job completion is not data certification |
| Historical Smart Fetch | Implemented for Cash | `controller/pipeline_service.py`, CLI and UI preview | Requires verified calendar and consistent enabled stores; sparse instruments may remain incomplete |
| Durable jobs, progress, cancellation, recovery | Implemented | `model/quality_store.py`, reused `controller/fno_jobs.py` | Resume creates a linked run and rechecks scope; verification does not continue from an unchecked cursor |
| Login Enter-key investigation | Partially Implemented | Existing login form retained with explicit `enter_to_submit=True`; role/login tests | Physical browser Enter event not executed in this environment |
| Today button | Implemented | `ui/date_inputs.py`, AppTest click | Uses IST calendar date, not latest stored/trading date |
| NSE calendar and market scheduler | Partially Implemented | `market_calendar.py`, reviewed 2026 YAML, `scheduler.py`, durable EOD jobs | Unknown years and special-session times remain unverified; FNO timing evidence begins 2026-08-03 |
| FYERS token expiry | Implemented handling | Response classification, interrupt/resume, explicit credential reload | Real account refresh/login acceptance pending; no automatic OAuth refresh |
| Alerts and delay history | Implemented for Cash telemetry/Telegram dispatch | `model/monitoring.py`, `pipeline_events`, monitoring view | Actual delivery not exercised; SMTP/email not added; FNO has existing job diagnostics rather than Cash telemetry |
| Headless operation | Implemented | `controller/pipeline_cli.py`, existing FNO CLI | Host/scheduler process must stay running |
| SQL–Parquet consistency | Implemented | Accepted SQL rows passed to Parquet; guarded writes and record comparisons | Two stores are not a distributed transaction; failures surface mismatches for review |
| Validation and aggregation correctness | Implemented | Strict session buckets, finite/integral checks, recomputation | Missing source minutes cause skipped output, never invented prices |
| FNO metadata/search/coverage heatmap | Implemented | Existing `ui/fno/service.py`, `page.py`, existing master/repository | Exact-symbol search; missing options minutes are not automatically missing trades |
| Expired FNO API and optional OI/Greeks | Partially Implemented | Capability adapter, explicit expired method, column-name normalizer | Installed 3.1.10 SDK lacks methods; newer SDK/account probe required; discovery does not invent contract metadata |
| Shared account quota and one socket owner | Implemented for one local installation | Persistent limiter and OS file locks | Multiple installations must share `TIOS_RUNTIME_DIR`; no simultaneous Cash/FNO fan-out |
| Master status, safe updates and permissions | Implemented | `ui/pages/12_Master_Tables.py`, `model/master_management.py` | Cash YAML → DB preview/hash/validation/transaction/audit; FNO uses existing broker sync |
| Analysis-engine integration | Partially Implemented | Existing repository preserved; `iter_verified_days` strict opt-in API | Complete TIOS analysis engine was not supplied; its downstream adoption is Unknown |
| Verification history/export | Implemented | Persisted findings, page CSV, complete JSON UI/streamed CLI export | UI export bounded; large reports use CLI |
| Automatic repair | Excluded by requirement | Verification never imports repair operations | Existing explicit admin repair tools remain separate |

## Layout and interaction

Left sidebar contains grouped navigation. Main area has real summary cards above recent jobs/evidence panels. Quality views share instrument/date scope, persisted run selection, progress and finding filters. FNO retains its 12 lazily loaded sections; contract views add exact symbol, expiry, strike and CE/PE filters with observed-record heatmaps. Master Tables separates Cash instruments, F&O contracts, timeframe/exchange configuration and reviewed calendar evidence.

All query views display loading indicators, explicit empty states, handled backend errors and retry/refresh controls. Unavailable sources do not become zero counts. Long operations run as persisted jobs; progress counts completed units, continuous live work uses heartbeat. Cancellation is cooperative between bounded units. Success labels identify the completed operation, not a globally verified dataset.

## Verification mapping

All checks write only job/finding metadata. Candle, checkpoint, instrument and Parquet data remain unchanged.

| Check | Location / source | Rule and expected result | Important boundary |
|---|---|---|---|
| Historical coverage | `verification_controller.py`; Cash candles + calendar; `fno_verify.py` | Expected closed session starts vs observed unique timestamps; absent complete days included | Silent option/illiquid minutes may be legitimate; unknown calendar => NOT_VERIFIED |
| OHLC, volume, timestamp, timeframe, duplicates | `model/quality.py`, FNO normalizer/aggregation | Finite positive prices, low ≤ open/close ≤ high, integral nonnegative volume, aligned/in-session timestamps | Source field precision is normalized to stored price precision; timezone policy is IST |
| SQL vs Parquet | Cash reader/comparator; FNO verifier/manifest | Compare canonical identity, OHLCV, provenance/status; FNO nullable fields included | Current-day mutable partitions are not durable historical certificates; no distributed snapshot |
| Checkpoints | Existing Cash max-date / FNO range tables | Compare claims with actual selected-date evidence; empty claims fail, partial coverage flagged | A max date or any-row existence alone is never proof of full coverage |
| Ingestion diagnostics | Existing/new ingestion job records | Failed/partial states, counters, bounded historical samples | Uninstrumented legacy jobs may lack counters or telemetry |
| Aggregation | Existing shared combiner; Cash/FNO session adapters | Recompute from valid CLOSED 1m input; compare all expected outputs including missing entire targets | No interpolation; FNO unverified historical timing remains explicit |
| Live vs persisted | `pipeline_events` and Cash sinks/controller | Reception sample, SQL acknowledgement and Parquet acknowledgement shown separately | Historical candles alone cannot prove reception; samples are not total tick counts |
| Metadata | YAML versus existing instrument tables | Missing/inactive/drift, FNO expiry/category/lot/tick validation | Listing date/history availability may be unknown; no duplicate master tables |
| Files/manifest | FNO Parquet + storage manifest | Checksums/schema/row values, orphan candles/chains and interrupted temp files | Cross-batch key duplicate detection uses disposable disk index, bounded RAM |
| History/export | `data_quality_results`, `quality-export` | Scope, rule version, calendar version, as-of, status and details | CSV is current displayed page; CLI JSON includes whole run |

## API / service / database boundaries

`PipelineService` is shared by Streamlit and CLI. `QualityStore` implements the existing job runner contract. Jobs persist before workers execute. Migration is an explicit command/UI action; ordinary service startup performs no DDL. `CashReader` is read-only. Existing `MarketDataRepository.get_candles` remains compatible; `iter_verified_days` adds a strict analysis option and rechecks both stores per historical day rather than trusting old reports.

Metadata sync recomputes changes inside a locked transaction and rejects stale preview hashes. It does not trust caller-supplied change contents. It validates symbol/exchange/category and writes the audit in the same transaction. No instrument deletion occurs. Existing admin data-management tools remain separate from verification.

## Permission matrix

| Operation | Normal user | Admin / local CLI operator |
|---|---|---|
| Dashboard, tables, scoped quality/history/coverage | Read | Read |
| Preview stored Smart Fetch gaps | Yes | Yes |
| Export displayed/complete reports | Yes | Yes |
| Submit verification/fetch/aggregation | No | Yes |
| Cancel/resume jobs, reload credentials | No | Yes |
| Live feed start/stop | No | Yes |
| Master synchronization / migrations | No | Explicit reviewed action |
| Existing destructive data management | No | Existing confirmation + audit workflow |
| Alert dispatch | No UI send | Explicit CLI `--send` with configured channel |

This reuses the existing local shared-role authentication model. It is not a new multi-user identity system. CLI access is trusted local operator access, not a separate web authentication bypass.

## Implementation phases and remaining acceptance

P0 storage/calendar validation and P1 metadata/jobs foundation are delivered. P2 quality UI, P3 navigation/master/FNO extensions, P4 Smart Fetch, P5 headless/Cash telemetry and P6 strict read boundary are implemented to the available repository scope. External acceptance remains: Windows/MySQL 8.0, real FYERS entitlement/expired methods, browser Enter event, historical calendar expansion, optional notification delivery and the missing full TIOS analysis code. These are not reported as successful tests.
