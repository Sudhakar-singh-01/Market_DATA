> Current policy update: see IDLE_LIVE_POLICY.md. Manual live connections can run off-market; unknown calendar evidence is a warning for ingestion and SQL-identical restoration. Earlier session-gating descriptions below are historical.

# Restore SQL-identical missing Cash minute partitions

This stage consumes cash_preview_cli output, not the original byte inventory.
Only VALIDATED_CANDIDATE partitions originally marked MISSING_TARGET_CANDIDATE,
with a single variant and zero SQL/source differences, can enter a plan.
The supplied report identifies 825 candidates / 309,375 rows. These are already
in MySQL; no SQL candle insertion, update, schema change, checkpoint change,
FNO change or higher-timeframe write is performed.

Use a current backup of the permanent profile/databases before maintenance.
This command is NOT a full backup tool. It retains source files and refuses
to replace destination files; no existing target needs to be removed/restored.
Keep every dashboard, ingestion worker, cleanup and schema tool stopped while
planning/applying. The acknowledgment flag is not a process detector.

From the new code directory containing main.py, Windows CMD:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.cash_restore_cli plan --preview "F:/TIOS_Runtime/cash_preview_01.json" --output "F:/TIOS_Runtime/cash_restore_plan_01.json"
```

Both commands prompt for the existing application administrator password.
Planning writes only its new JSON plan, never market files or lock files.
It rechecks source hash/size, full-row quality/calendar/coverage, SQL equality,
instrument internal_name/exchange/type, and destination absence. Missing metadata
or changed sources/SQL may reduce readiness compared with the older preview.
All blocked candidates are reported. A blocked plan cannot be applied.
Use a new output filename for a new plan; existing plans are not overwritten.

After reviewing PLAN_READY and its counts, explicitly apply that exact plan:

```bat
python -m controller.cash_restore_cli apply --plan "F:/TIOS_Runtime/cash_restore_plan_01.json" --writers-stopped
```

PowerShell environment syntax is `$env:TIOS_HOME='F:\TIOS_Runtime'`; Python
commands are unchanged. No need to rerun runtime_cli init or reset MySQL.

Apply preflights the entire plan before creating any market file, then repeats
checks per partition under the existing Cash writer's .lock convention. It
copies into an exclusive temporary file, flushes/fsyncs, verifies the hash,
rechecks SQL/source, then uses a same-directory hard link for atomic no-overwrite
publication. Hard links require filesystem support (normally local NTFS on
Windows); unsupported filesystems fail closed without a copy/overwrite fallback.
The new destination is linked to the temporary copy, NOT to the old source;
the temporary link is removed after publication. Post-publication checks verify
checksum and SQL equality again. Writers must stay stopped; SQL and filesystem
operations cannot form one atomic transaction, so external concurrent SQL writes
can still invalidate a check. A later error retains earlier successful files.

An fsynced append-only operation journal is written under
TIOS_HOME/logs/cash_restore/<plan-digest>.jsonl with source/hash and phase events.
Locks and new destination directories are expected apply-side effects.
Error output is STOPPED, never a claim of rollback. Keep writers stopped and
inspect the journal if an error occurs. Nothing automatically deletes a final
file, even after a postcheck failure.

Resume by rerunning the SAME apply command after resolving the cause. Every
source, SQL scope and destination is freshly checked; byte-identical existing
files are verified/skipped, different files block. Resume does not blindly trust
journal success markers. A hard process kill can leave .restore-*.tmp files;
these are not live partitions and are not automatically swept by later runs.
Their names appear in PREPARED events for separate review. Do not manually edit
plans/journals or delete original sources during recovery.

Successful result fields: COMPLETE, restored, already_identical, journal,
sql_modified=false. No automatic downstream aggregation or checkpoint advance.
The previous input preview/inventory becomes stale after restoration; generate
a NEW inventory/preview for subsequent work. FNO storage diagnostics do not
certify restored Cash data: use these fresh per-partition SQL checks and the
existing Cash verification workflow for later comprehensive quality checks.

Validation: 77 focused tests passed on Python 3.12 (restore, preview, inventory,
profile, setup, storage scope, calendar). Includes SQL/source drift, destination
conflict, publication race, hard-link failure, metadata mismatch, linked parent,
source retention and interruption after publication followed by resume.
Windows Python 3.13/local MySQL/hard-link execution remains user-side validation.
