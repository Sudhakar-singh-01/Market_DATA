# Merge notes: release4 v4.3.4 (B) + FNO release2 v4.3.3 (A)

Base = B (Release 4). B already contains everything newer: durable Cash jobs, Data Quality & Verification, Smart Fetch,
Master Tables, partition/socket locking, expired-history via `fno_historical_data`, F&O aggregation/verify, verified
Standard-plan API limits, populated NSE holiday calendar, session-aware Cash aggregation. A's Cash-side code is an older
version of B's, so nothing was taken from it there.

## Ported from A into B
| Area | What | Files |
|---|---|---|
| F&O reconcile | Option-chain MySQL-vs-Parquet check + repair; chain files included in manifest/orphan/temp-file checks | controller/fno_reconcile.py, model/fno/parquet_store.py (`list_chain_files`, `read_chain_partition`, chain temp files), model/fno/repository.py (`chain_counts_by_day`, `chain_rows_for_day`) |
| F&O harvest diagnostics | Per-field live-vs-history error (CLOSED live candles only), response-duplicate counts, Parquet quarantine count | model/fno/models.py, repository.py, controller/fno_historical.py |
| F&O normalizer | Identical repeated candle in one FYERS response is dropped and counted; same timestamp with different values is rejected (also for expired rows) | model/fno/normalizer.py |
| F&O probe | Single-day request evidence on last real trading day; nested `greeks` dict detection | model/fno/probe.py |
| F&O CLI | Startup warning when DB says Parquet is VERIFIED but the files are missing (new project folder) | controller/fno_cli.py |
| Dashboard | "System status" badges (FYERS on demand, live engine, MySQL, Parquet, disk) on the Overview | ui/home.py |
| Historical page | Gap Fill panel restored under Smart Fetch | ui/pages/4_Historical_Data.py |
| Tests | 12 tests from A for the above | tests/fno/* |

## Deliberately kept from B (A's version dropped)
* Expired contracts: B calls `fno_historical_data` and never marks `EXPIRED_UNRECOVERABLE` on a missing capability. A's
  "attempt, then mark unrecoverable on -300" and 14-day max-age rule are not used; the 2 A tests for it are not carried over.
* LIVE can never overwrite or back-fill HISTORICAL rows (B's `_SAME_ALLOWED` guard, Parquet protection).
* Rate limits (45/min, 4500/day) and 100-symbol socket cap, populated holidays.yaml, Release 4 UI pages and CLI.

## Not carried over (superseded by B)
A's old Historical/Aggregation/Data Quality pages and the 5-tab dashboard (replaced by Smart Fetch, Aggregation,
Verification pages and Overview). The MySQL table browser, files and live controls remain on the Data Explorer,
Admin and Live Market pages.

## Verification
MariaDB 10.11 test server: A 409 passed, B 477 passed, merged 489 passed, 0 skipped. Not tested: real FYERS calls,
real MySQL 8 server, full Streamlit click-through (only the Overview was smoke-rendered).
