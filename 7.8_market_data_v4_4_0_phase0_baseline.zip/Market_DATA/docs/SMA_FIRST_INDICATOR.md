# First indicator: SMA_CLOSE_V1

Requirements reviewed: Documentation.zip, 02_Software_Requirement_Specification.md
section 13.2 and 13_Indicator_Engine.md sections 5, 7.5, 11, 13, 14, 15 and 17.
The specification requires centralized calculation and event-only production
communication. No production Event Bus exists in the supplied repository.

This release adds a calculation kernel under indicators/, plus an examples/
historical integration harness. It does NOT declare document 13 implemented or
frozen. The example imports the SDK and calculation kernel as test composition;
it is not a strategy module or a production communication path.

Chosen first implementation: SMA of the last N closed candle CLOSE prices;
configurable N (default 20). Equal weighting, first N-1 candles produce None,
no synthetic warm-up values. Continuous observed-candle lookback across sessions;
no daily reset. One state instance per segment/symbol/timeframe/session/period/
replay scope is required. The kernel does not independently certify calendar
coverage: the harness first completes the entire verified consumer batch.

Each output is immutable and associated with the input candle START timestamp.
It becomes available only after that candle closes; never execute a simulated
trade at the candle start using its eventual close. For 1m SMA20 beginning at
09:15, the first value belongs to 09:34 and is available no earlier than 09:35.
The close is included in its own trailing window. No future candles are read.
Decimal arithmetic uses explicit precision 34, ROUND_HALF_EVEN, independent of
ambient context. Repeating quotients are rounded to that precision. Summation
is recalculated over the bounded window for correctness (O(period) per candle);
large periods require profiling before live adoption. Float precision already
lost upstream cannot be recovered by Decimal conversion.

Duplicate/out-of-order timestamps and non-finite values raise before changing
state. Published values cannot be corrected in place: corrected historical input
requires a new replay scope. No persistence, provider fetch, SQL writes, orders,
signals or indicator cache is introduced.

## Run
Keep local API running. From the updated project directory in Windows CMD:

```
set "TIOS_HOME=F:\TIOS_Runtime"
python -m examples.indicator_check --date 2026-10-23 --period 20
python -m examples.indicator_check --date 2026-10-23 --segment FNO --symbol "NSE:BANKNIFTY26NOVFUT" --period 20
```

For the previously verified scopes, CASH has 375 inputs / 19 warm-up / 356
outputs; FNO all-session has 385 / 19 / 366. FNO all-session does not certify
regular-session filtering. Status SMA_REPLAY_COMPLETE means calculation ran;
it is not whole-project or trading certification. Runtime reads remain a live
view, not a cross-request immutable dataset snapshot.

## Tests and remaining architecture
Tests include hand-calculated rolling windows, period boundaries, invalid input
state preservation, isolated streams, fixed Decimal context, prefix invariance
and changed-future invariance, and SDK -> actual FastAPI -> SQLite/Parquet ->
consumer -> SMA integration. Live feed is not connected or certified.

Remaining before production Indicator Engine: shared event contracts and bounded
AsyncIO bus with ordering/failure policy; centralized registry/reference counting;
shared calculation and bounded cache per configuration; event publication;
historical/live handoff; metrics and lifecycle; other indicators. Existing
market data fetching/storage remains unchanged. Implement and test these against
the source documents before claiming full document 13 completion.
