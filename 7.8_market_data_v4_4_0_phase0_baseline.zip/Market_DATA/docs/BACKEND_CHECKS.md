# Backend checks (Windows CMD / PowerShell)

Open PowerShell or Command Prompt in the extracted project directory and activate your existing Python environment. The commands below use that environment's `python`; no particular environment folder name is required.

```powershell
python -m controller.diagnostics_cli --help
python -m controller.diagnostics_cli storage --offline
python -m controller.diagnostics_cli storage
python -m controller.diagnostics_cli fetch-preview --segment CASH --from 2026-10-19 --to 2026-10-23 --symbols NIFTYBANK SBIN
python -m controller.diagnostics_cli job --segment CASH --id 313
$LASTEXITCODE  # PowerShell; use echo %ERRORLEVEL% in Command Prompt
python -m pytest -q tests/test_backend_diagnostics.py tests/test_storage_scope.py
```

Use symbols from your configured instrument registry. Online commands require the existing administrator password, entered at the prompt (or supplied through `MARKET_DATA_ADMIN_PASSWORD`). The offline command inspects configuration without credentials or database connections. It explicitly marks the manifest check incomplete/skipped; offline success does not establish database health.

`storage` reports absolute roots, exclusions and directory existence. The Cash root is the parent of `raw` and `processed` (by default the project's `data` directory); the existing FNO root remains the project's `data/fno` unless configured otherwise. Cash excludes this nested FNO subtree. Never change Cash's root to `data/raw`, move FNO into Cash's `raw`/`processed` namespaces, or point the segments at the same root. The command does not create or move directories.

The online manifest check traverses every FNO manifest entry in bounded pages and checks safe paths and file existence. It reports checked, missing and invalid counts plus at most ten missing examples. A missing file is a finding even if its manifest status is VERIFIED. Zero missing files does **not** prove checksum, row-count, calendar coverage or SQL/Parquet parity; use the existing verification workflow for those checks. Concurrent writers can change results during a check. An unavailable database yields an incomplete error, never a successful manifest check.

`fetch-preview` checks CASH fetch preflight without submitting a job or calling a provider. It reports blocked symbol/day details and returns exit code 2 if blocked. FNO preview is intentionally excluded because ATM previews can request provider quotes. `job` reads the persisted public job summary, including state, safe workflow results and allowlisted diagnostic counters. For CASH it also shows up to 100 persisted quality findings, prioritizing non-PASS findings, with total count and explicit truncation. This exposes missing Parquet rows, SQL-only rows, coverage gaps and check totals for PARTIAL VERIFY jobs. Arbitrary stored error text and credentials are omitted; detail availability is explicit. It does not resume, retry or repair a PARTIAL job.

Exit codes: **0** requested checks passed (or configuration-only offline inspection completed), **2** findings/blocked preflight, **1** unavailable/error. Errors omit database/provider exception text and credentials. None of these commands repairs, imports, deletes or submits work.


## Installation and local regression tests

Stop the existing dashboard/workers first. Preserve your existing `config/.env`,
custom configuration, databases and data. Extract this cumulative build and run
these commands from its directory containing `main.py` using your existing
activated environment:

```text
python --version
python -m pip install -r requirements-api.txt pytest
python -m pytest -q tests/test_storage_scope.py tests/test_backup_service.py tests/test_cleanup_service.py tests/test_backend_diagnostics.py tests/test_historical_provider_errors.py tests/fno/test_worker_shutdown.py tests/test_unified_workflow.py
```

These tests use temporary test storage and mocked providers; they do not repair
or certify your live database. Disposable MySQL integration cases skip unless
explicitly configured. Run the new shutdown tests with your Windows Python 3.13
as well: the build environment used Python 3.12.

Save live diagnostic outputs for review (admin password prompt remains private):

```text
python -m controller.diagnostics_cli storage > storage_check.json
python -m controller.diagnostics_cli fetch-preview --segment CASH --from 2026-10-19 --to 2026-10-23 --symbols NIFTYBANK SBIN > fetch_preview.json
python -m controller.diagnostics_cli job --segment CASH --id 313 > job_313.json
```

An existing optional deeper FNO reconciliation check is:

```text
python main.py fno-reconcile --from 2026-10-19 --to 2026-10-23
```

Without `--repair`, reconciliation reports differences without fixing market
storage. Its date range bounds candle comparisons; manifest and chain checks
may cover a broader scope. Stop writers for a stable comparison. Do not add
`--repair` before reviewing paths and findings.

## Optional stable paths across upgrades

Only after identifying the old folders that actually contain your data, set
`CASH_DATA_ROOT` in `config/.env` to their absolute parent containing `raw` and
`processed`. Set `parquet.root` in `config/fno_settings.yaml` to the actual
existing FNO directory. Windows paths with forward slashes work, for example
`F:/your-existing-data/data` and `F:/your-existing-data/data/fno`; these are
illustrations, not folders the tool creates. Restart workers after configuration
changes. Empty `CASH_DATA_ROOT` retains project-relative `data/`.
