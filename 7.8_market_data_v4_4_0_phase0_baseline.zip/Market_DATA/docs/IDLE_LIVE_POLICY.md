# Always-startable live ingestion and calendar warnings

This release supersedes the older verified-session transport gating described
in PERMANENT_RUNTIME.md and the earlier release notes. Manual Cash live, FNO
live and the FNO live job handler can start on weekends, holidays, nights and
unverified calendar dates. The transport is not stopped solely at market close.
Authentication, provider availability and a nonempty subscription universe still
apply. The explicit `schedule` command retains its named market-open/EOD schedule;
use `live` or `fno-live` for an always-startable manually managed connection.
Only one selected live stream should run at a time under the existing deployment.

Empty/status-only/malformed responses do not reach candle builders. A usable
tick needs a nonempty symbol, explicit positive finite epoch timestamp and a
positive finite price. Provided cumulative volume must be finite, integral and
nonnegative. Zero volume remains valid (e.g. index quotes); it is not an empty
feed. No timestamp is fabricated for an acknowledgment or snapshot missing time.
Real off-session ticks are accepted rather than rejected by calendar evidence.
Quality reports can still identify out-of-session observations. This does not
certify every provider snapshot as a new trade or add a new feed-latency filter.

No empty feed creates a market candle or Parquet partition. FNO idle freshness
polls also avoid persistence until a real subscribed tick has been received.
Lifecycle/job/connection logs may still be recorded. Genuine buffered candles
from earlier ticks may flush on shutdown; a forming FNO candle remains OPEN
rather than being CLOSED merely because the market session ended. No synthetic
carry-forward bars or missing-minute fill is introduced. This change does not
add a Cash wall-clock candle flush timer; existing Cash bucket roll/stop behavior
is preserved.

Historical raw fetch remains independent of invocation time. Smart Fetch and
workflow submission no longer reject solely for unverified calendar evidence.
For an unknown target date Smart Fetch requests missing minutes over that date
rather than declaring a weekend empty from an unverified calendar. It retains
SQL/Parquet conflict and malformed-data checks. Provider history entitlement and
response errors remain authoritative. The former fixed 366-day Smart Fetch
preflight assumption has been removed; no available-history limit is invented.
Unknown calendar requests may return empty; empty batches are not sent to the
sink. A PARTIAL/NOT_VERIFIED result may remain because full coverage cannot be
certified; it is not a prohibition on data acquisition. Strict verified reads
and aggregation-quality certification still require evidence.

Cash restore plans now accept single-variant, SQL-identical preview candidates
whose ONLY review reason is calendar_not_verified. Source metadata, checksum,
SQL equality, duplicates, OHLC, closed status and other safety checks remain.
Warnings are kept on plan items; no verified-year configuration is changed.
Previously restored byte-identical destinations are freshly verified and skipped
when constructing another plan. SQL-missing candidates are not included: this
is still a Parquet restore tool, not a new SQL-import tool.

Windows CMD, from the new project folder:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m pytest -q tests/test_idle_live_policy.py tests/test_market_session_policy.py tests/test_cash_restore.py
python main.py live --symbols SBIN
```

Stop with Ctrl+C. Test FNO separately, after stopping Cash:

```bat
python main.py fno-live --underlyings NIFTY
```

Use configured active instruments; credentials/subscription selection may still
need provider access even off-market. Actual received valid ticks can be stored;
these commands are not read-only simulations. The unit tests use fake feeds and
verify no market writes for empty input.

To plan remaining SQL-identical calendar-warning restorations with the existing
preview (already-restored matches are skipped):

```bat
python -m controller.cash_restore_cli plan --preview "F:/TIOS_Runtime/cash_preview_01.json" --output "F:/TIOS_Runtime/cash_restore_plan_02.json"
```

Review the new actual summary/blocked entries before applying; do not reuse the
old completed plan for new candidates. The preview identified 1,252 SQL-matching
unknown-calendar partitions and 122 Parquet-only partitions. Fresh metadata and
source/SQL checks decide the actual plan, not those historical counts.

Validation: full regression 704 passed, 194 skipped on Python 3.12; subsequent
focused changes/tests 63 passed (idle feeds, sessions, restore and preview).
Windows/Python 3.13/live FYERS validation remains user-side. No external provider
schema claims or new market calendars were introduced.
