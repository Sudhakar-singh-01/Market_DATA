# Verified consumer input

`client.consumer.load_verified_batch(client, segment, symbol, timeframe, start, end)`
returns an immutable CandleBatch only after all API pages succeed. Candles have
IST-aware timestamps, Decimal OHLCV and nullable Decimal open interest.
Uses the existing GET SDK; no SQL, broker or dashboard dependencies.

CASH defaults to session=regular; FNO defaults to session=all. Complete verified
coverage is mandatory. Sparse options require a different explicit consumer
policy and are not accepted by this adapter. Empty batches do not trigger
calculations. No sorting, synthetic fills or silent deduplication is performed.
Memory is bounded by max_rows (default 100000); page_size/max_pages constrain
requests. Errors propagate and no partially accumulated batch is returned.
Each page's coverage and checked_at evidence is retained. The batch is a live
view over multiple requests, not an atomic snapshot or backtest reproducibility
guarantee. Store/export provenance separately if a reproducible dataset is needed.

```python
from client.consumer import load_verified_batch
batch = load_verified_batch(client, 'CASH', 'NSE:SBIN-EQ', '1m',
                            '2026-10-23', '2026-10-23', page_size=200)
# Only here may the consumer begin calculations.
closes = tuple(c.close for c in batch.candles)
```

With the API running, from Windows CMD in the project folder:

`python -m examples.consumer_check --date 2026-10-23`

Expected for the previously verified SBIN scope: CONSUMER_BATCH_READY, 375 rows,
2 pages, 09:15 through 15:29 +05:30. No market files or SQL rows are changed.
This is an input adapter; it does not implement indicators, backtesting or an
event bus. Raw wire-format SDK methods remain unchanged. Numeric strings, integers and finite JSON floats are accepted via Decimal(str(value)).
Existing float precision cannot be recovered; Decimal strings retain their precision.
