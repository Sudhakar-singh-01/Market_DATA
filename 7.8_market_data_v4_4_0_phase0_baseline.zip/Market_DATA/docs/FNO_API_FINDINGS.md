# FNO API findings

**Status: probe NOT RUN yet.**

Nothing in this repository has been verified against the real FYERS API. Run `python main.py fno-probe --write-report` with a valid token (during market hours for best results) and this file will be replaced with the real results. Until then every FYERS limit in `config/fno_settings.yaml` is a conservative default, not a confirmed fact.

Open question surfaced by the audit: the installed `fyers-apiv3` SDK (3.2.0) exposes `/history/fno/expired/*` endpoints (`expiry_dates`, `history_underlying_symbols`, `fno_historical_data`), which contradicts the design assumption that expired contracts have no history. The probe records what these endpoints return.
