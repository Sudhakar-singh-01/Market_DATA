# Recovery verification after an isolated import (Step 9)

This step adds an executable **read-only verifier** for a manually restored
database and the staged files from the same backup. It never executes dump SQL,
creates/drops a database, replaces live files or starts ingestion workers.
The optional test described below performs an import only in a fresh disposable
test database. No production recovery drill was run during development.

## Prepare an isolated copy

1. Create and verify a backup with writers stopped, then stage it through
   Administration → Backup & Recovery. Keep its archive SHA-256 separately.
2. As the database administrator, create a **new, empty** recovery database on a
   compatible MySQL server. Its name must begin `tios_recovery_`, for example
   `tios_recovery_cash_20261026`. It must differ from both configured live database
   names, regardless of hostname/case. Do not reuse a partly imported database.
3. Review the staged `database.sql` and import it manually using a dedicated
   account restricted to that one recovery schema. Do not import untrusted dumps
   using root or an account that can write the live schemas. Exported CREATE TABLE
   definitions may contain database-specific clauses; a statement-prefix filter
   cannot establish import safety.
4. Use a fresh MySQL client session connected explicitly to the recovery database:

   ```text
   mysql --host=localhost --port=3306 --user=recovery_importer --password --database=tios_recovery_cash_20261026
   ```

   Confirm `SELECT DATABASE();`, then run `SOURCE` with the actual staged file's
   full path, for example `SOURCE F:/TIOS/recovery/<recovery-id>/database.sql;`.
   Credentials/accounts and database creation are administrator-managed; this
   feature never creates them. Keep a successful import log. On any import error,
   stop and diagnose before using another fresh empty target.
5. Leave the staged `parquet/` directory intact. Do not point live applications or
   workers at either recovery copy. Restored job rows can contain pending/running
   jobs; the verifier reads them as historical data and never resumes them.

## Configure verification

Add these to local `config/.env`; they are independent from DB_/FNO_DB_ settings:

```dotenv
RECOVERY_DB_HOST=localhost
RECOVERY_DB_PORT=3306
RECOVERY_DB_NAME=tios_recovery_cash_20261026
RECOVERY_DB_USER=recovery_reader
RECOVERY_DB_PASSWORD=<set locally; do not share>
```

Use a separate account with read-only access to the recovery schema. Ensure an
administrator has audited its metadata visibility and confirmed that there are
no hidden stored objects. MySQL may hide triggers/routines/events from restricted
accounts, so the verifier cannot certify their absence without that visibility.
Database/server settings, users, grants and application configuration are not
restored by the backup. Configure and validate those separately.

## Run

Open **Administration → Recovery Verification**. Review the displayed target,
select the staged copy, acknowledge that its import completed and recovery writers
are stopped, type `VERIFY <recovery database>` and re-enter the admin password.

The equivalent CLI uses the existing admin-password authentication:

```text
python -m controller.recovery_cli --list-staged
python -m controller.recovery_cli --backup-id <32-hex-id> --recovery-id <32-hex-id>_<8-hex-suffix> --confirmation "VERIFY tios_recovery_cash_20261026"
```

Exit codes: 0 = all reported checks passed; 2 = checks failed; 1 = configuration,
authentication or command failure; 130 = interrupted. Passwords are prompted or
read using the existing `MARKET_DATA_ADMIN_PASSWORD` mechanism; never pass database
passwords as command-line arguments. Restart the dashboard after changing cached
recovery connection settings.

## What a passing report establishes

- Original archive inventory and SHA-256 checks pass, and the exact staged SQL,
  Parquet/sidecar files and manifest match. Extra files/directories, changed content,
  symlinks and overlaps with live roots fail the checks. Inputs are rechecked after
  database verification to detect changes during the run.
- `SELECT DATABASE()` matches the explicitly configured isolated target. The
  verifier uses a fresh connection, a read-only repeatable-read snapshot and UTC
  for TIMESTAMP comparison. DATETIME wall-clock values remain unchanged.
- Base-table inventory and exact server `SHOW CREATE TABLE` text match the dump,
  including empty tables. Only outer whitespace and a terminal semicolon are
  ignored. Server-version formatting, collation output or AUTO_INCREMENT changes
  can cause a conservative mismatch; the tool does not silently normalize them.
- Every insertable row matches the dump, including duplicate multiplicities,
  NULL, numeric precision, Unicode and binary encoding. Row order is irrelevant.
  This is a complete comparison, not a sample or a count-only check. Generated
  column definitions are included in DDL checks; their evaluated values are not
  exported and therefore are not compared independently.
- Reflected foreign keys have no orphan rows, including composite keys with
  MySQL's partial-NULL behavior. External-schema foreign keys are rejected.
  Merely re-enabling FOREIGN_KEY_CHECKS would not perform this validation.
- Participating tables are InnoDB; visible views, triggers, routines and events
  are rejected. Account visibility limitations still apply.

Rows are compared using a temporary disk-backed SQLite multiset. Large backups
need substantial temporary disk space and time; the verifier does not load all
rows into memory. Limits: 10,000 tables, 16 MiB per dump line, 64 MiB total schema
text, plus existing archive/staging limits. Unusual dump grammar/identifiers or
larger values fail closed and require a separately reviewed verification method.

## Reports and limits

Each run writes a new report under `recovery_reports/`, outside backup, staging
and live roots. It records the backup digest, target, timestamps, passed checks,
error codes and coverage. Reports are flushed and made read-only where supported;
they are local evidence, not cryptographically signed or administrator-proof.
Errors omit raw driver messages, credentials and row values.

`status=VERIFIED` is scoped to `SQL_AND_FILES_VERIFIED`. The original archive is
not rewritten, and `restore_tested` remains false because the tool does not certify
the complete application recovery process. `market_parity=NOT_TESTED` is explicit:
byte-identical Parquet copies may faithfully reproduce pre-existing invalid data.
File hashes do not establish Parquet readability, market-calendar completeness or
SQL/Parquet parity. Run the existing strict market-data verification against the
isolated recovery copies before considering a live replacement. This remains a
separate deployment check, as do Windows behavior and the final live cutover plan.

Keep both stores idle during the check. A passing report describes that recovery
snapshot; changes after verification invalidate its use as current evidence.
No automatic cutover, marker-clear, retry of a failed import or live rollback is
provided. Preserve the live stores and original backup until the full drill and
application checks have succeeded.

## Optional actual MySQL integration drill

The test uses only `market_data_test` / `fno_market_data_test` fixtures. It creates
a fresh randomly named `tios_recovery_test_*` database, imports a dump generated
from the test fixture, verifies it, then drops **only that new database**. The test
account needs permission to create/drop this disposable database. It never reads
RECOVERY_DB_ settings or imports a user-selected archive.

```text
set RUN_RECOVERY_MYSQL_TEST=1
python -m pytest tests/fno/test_recovery_drill_mysql.py -q
```

Set the existing FNO_TEST_DB_HOST/PORT/USER/PASSWORD variables for the disposable
server. Without the opt-in or a reachable server, the test skips; a skip is not
evidence of a successful restore. PowerShell uses `$env:RUN_RECOVERY_MYSQL_TEST="1"`
instead of the CMD `set` command above.
