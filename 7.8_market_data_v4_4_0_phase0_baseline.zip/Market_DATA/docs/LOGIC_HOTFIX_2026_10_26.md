# Step 9 hotfix 2 — backend logic

This cumulative build addresses the screenshots and logs reported on 26 October
2026. It preserves existing Cash/FNO normalization, OHLCV aggregation and dual
storage behavior. No UI presentation changes are included. `ui/fno/worker.py`
contains backend worker startup and is changed only for shutdown handling.

## Storage ownership and upgrades

The existing layout is supported without moving files:

- Cash: `<cash-root>/raw/1m` and `<cash-root>/processed/<timeframe>`.
- FNO: its own root, including the existing `<cash-root>/fno` layout.

Cash backup includes its files and sidecars but excludes a nested configured FNO
subtree. FNO backup includes only the FNO root. Cleanup validates ownership and
preserves peer data. Equal roots, FNO roots containing the Cash root, and any
FNO overlap with Cash `raw` or `processed` remain rejected. Symlinks/junctions
are rejected for these admin operations. Backup format and staged relative
paths are unchanged; no existing backup is rewritten.

All default Cash readers/writers now share `CASH_DATA_ROOT` from `config/.env`.
An empty value uses this project's `data` directory, independent of the shell's
working directory. Set an absolute path to the **existing directory containing
raw and processed** to retain storage across extracted upgrades. FNO already
supports an absolute `parquet.root` in `config/fno_settings.yaml`. Its isolation
check now uses the configured Cash root as well.

Stop workers before changing roots. Preserve `.env`, custom YAML, databases and
data when installing this build. Do not point at a new empty folder and assume
that data has been migrated. This build does not search the disk for old data,
copy files, alter database contents, run reconciliation repairs, or rewrite
existing VERIFIED/SUCCESS records automatically.

## Fetch diagnostics

Blocked Cash workflow previews retain symbol/date/reason/details through
`FetchPreflightError`. The workflow CLI prints these findings with status
`BLOCKED`, exits 2 and does not submit a job or create a runnable plan.

FYERS Cash history errors retain sanitized provider code, request range and
allowlisted field diagnostics. Explicit history availability/plan rejection is
classified as `history_unavailable`; it is not retried as a transient failure.
Supported successful chunking and rate-limit retries remain supported. Dates
are never silently clamped and missing candles are never fabricated. A provider
plan limitation cannot be removed by this patch or by smaller request chunks.

## Worker lifecycle

Cooperative shutdown signals workers before interpreter executor shutdown,
refuses new work, and checks stop requests between API calls and before writes.
Interrupted jobs remain resumable rather than being labelled successful. The
shutdown hook uses CPython's pre-thread-shutdown mechanism; Python 3.13 on the
user's Windows machine still requires an actual smoke test.

Joins are bounded. A killed process or an uninterruptible request/database write
cannot be guaranteed to finish. SQL and Parquet are not an atomic transaction;
after a forced stop, inspect persisted jobs and verify parity before resuming.
No storage verification checks have been disabled.

## Verification

See `BACKEND_CHECKS.md` for Windows commands. Automated tests cover nested
segment backup/cleanup isolation, invalid overlap/link rejection, shared Cash
root resolution, workflow blocker propagation, sanitized history rejection,
retry/success preservation, diagnostics and cooperative shutdown.

Production MySQL/FYERS, the user's old data folders and Windows are not available
in the build environment. Passing offline tests does not certify their live
data. Storage diagnostics check file existence, not SQL/Parquet value parity.
