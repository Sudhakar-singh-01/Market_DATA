# Remaining Cash recovery review

Based on uploaded cash_recovery_plan_01.json. This is a historical diagnostic snapshot, not a fresh production check.

13 of 74 unresolved partitions have a usable SQL-exact source candidate. The other 61 are listed below. No automatic merge, SQL update/delete, source deletion or target replacement is authorized by this report.

| Partition | Finding | Next assessment |
|---|---|---|
| raw/1m/NSE_HDFCBANK-EQ/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_HDFCBANK-EQ/2026-09-28.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-09-29.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-09-30.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-01.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-09.parquet | record_integrity_findings | Inspect SQL integrity/session findings; confirm special sessions before classifying rows as invalid. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-12.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-14.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-19.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_HDFCBANK-EQ/2026-10-23.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_ICICIBANK-EQ/2026-07-07.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_ICICIBANK-EQ/2026-07-08.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_ICICIBANK-EQ/2026-07-24.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_ICICIBANK-EQ/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_ICICIBANK-EQ/2026-09-28.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-09-29.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-09-30.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-01.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-09.parquet | record_integrity_findings | Inspect SQL integrity/session findings; confirm special sessions before classifying rows as invalid. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-12.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-14.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-19.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_ICICIBANK-EQ/2026-10-23.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-07.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-08.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-28.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-29.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTY50-INDEX/2026-09-30.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTY50-INDEX/2026-10-01.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTY50-INDEX/2026-10-12.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTY50-INDEX/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-02-01.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-07.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-08.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-28.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-29.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-09-30.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-10-01.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-10-12.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_NIFTYBANK-INDEX/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_RELIANCE-EQ/2026-02-01.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_RELIANCE-EQ/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_RELIANCE-EQ/2026-10-14.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_RELIANCE-EQ/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_RELIANCE-EQ/2026-10-19.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_RELIANCE-EQ/2026-10-23.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_SBIN-EQ/2026-09-09.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
| raw/1m/NSE_SBIN-EQ/2026-09-28.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-09-29.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-09-30.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-10-01.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-10-09.parquet | record_integrity_findings | Inspect SQL integrity/session findings; confirm special sessions before classifying rows as invalid. |
| raw/1m/NSE_SBIN-EQ/2026-10-12.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-10-14.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-10-16.parquet | usable_variants_conflict_or_need_union | Compare per-timestamp values and provenance; union only agreeing rows after a separate reviewed plan. |
| raw/1m/NSE_SBIN-EQ/2026-10-19.parquet | SQL_extra_or_conflicting_rows | Compare extra keys and differing values; preserve SQL and originals until repair decision. |
| raw/1m/NSE_SBIN-EQ/2026-10-23.parquet | no_usable_source_variant | Review source quality/session classification; consider provider refetch if available. |
