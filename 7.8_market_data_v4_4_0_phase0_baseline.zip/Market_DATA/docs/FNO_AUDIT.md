# FNO P0 audit (repository reading, not assumptions)

Re-confirmed by reading the code and running it. Differences from the master prompt are marked **DIFF**.

| Item | Finding |
|---|---|
| Stack | Python, Streamlit (`ui/dashboard.py`, `ui/pages/`), `main.py` argparse CLI. No REST API, no separate frontend. |
| Baseline tests | **DIFF:** 143 passing, not 133 (all pass with dependencies installed). |
| DB | One MySQL database; plain SQL files; `INSERT IGNORE` candles; `get_engine(url)` caches per URL. A stores IST wall-clock `DATETIME`. |
| Reuse | `get_authenticated_client` (auth), retry/chunk ideas from `fetch_historical_1m`, `model.processing.models.IST`, YAML loader, logging. |
| Not reusable as-is | `Instrument`/`Candle` (no expiry/strike/OI), `ParquetCandleSink` (default root `data`), checkpoint (single date per symbol), gap detector (assumes every minute has a candle), `ui/job_manager.py` persistence (in-memory). |
| **SDK (corrected)** | The build sandbox had `fyers-apiv3` 3.2.0, which exposes expired-F&O endpoints (`/history/fno/expired/*`). **Your install is 3.1.10** and the probe saw no `expiry_dates` evidence, so those endpoints are probably NOT available to you. Whether expired contracts have history is therefore still untested on your account: use `fno-probe --expired-symbol`. |
| Network | The build sandbox cannot reach FYERS, so **no FYERS behaviour was verified here**. Everything API-related is a conservative default until `fno-probe` runs on your account. |

## Risks found and how they are handled
- Shared quota across A and FNO -> one process-wide limiter, FNO capped at 70% of each window (config), A's REST call sites hooked (no-op unless FNO configured it).
- Limiter is per **process**, not per machine. Dashboard + a separate CLI worker each hold a budget: size `rate_limits` for the combined load.
- MySQL and Parquet are not transactional -> order MySQL, Parquet, checkpoint; `fno-reconcile`.

## Corrections made after the first real probe run (2026-10-20)
| Assumed | Real | Fix |
|---|---|---|
| Session ends 15:29 | 385 candles/day: 09:15 to **15:39** | `session` in config; validator + completeness rule use it (first draft would have rejected ~10 valid candles/day) |
| 10 requests/s | **Standard plan: 5/s**, code `-360` | `per_second: 4`, FNO share 75%, `-360` classified as retryable |
| `-360` is an unknown error | plan rate limit | added to `rate_limit_codes` and message sniffing |
| Probe span 200 / strikecount 51 failed | those were `-360` throttling, not limits | probe now retries throttled answers; re-run needed |
| Option chain `strikecount=N` returns N strikes | 5 -> 23 entries, 50 -> 203 entries = 4N+3 (inferred: N strikes each side of ATM, two sides, plus one underlying row) | to be confirmed from `sample_entries_base` after re-run |

## Second real probe run (2026-10-21, market hours)
| Check | Result | Consequence |
|---|---|---|
| Expired contract history | ~~returned 2582 candles~~ **RETRACTED: invalid test.** `NSE:NIFTY26OCT22900CE` is a monthly-format symbol expiring 27 Oct, still active (2582 > 6 days x 385, so it included 21 Oct). The SQL lookup for a truly expired symbol returned no rows. | **Unknown.** Harvest still ATTEMPTS tracked expired contracts and lets FYERS decide (-300 -> EXPIRED_UNRECOVERABLE once). The probe now rejects a still-listed symbol as an invalid test. |
| WebSocket | 5000 symbols on one socket, no `-351` / limit error (ceiling not found) | `max_subscriptions: 2000` |
| Ticks | Fields seen (futures samples): ltp, vol_traded_today, bid/ask price+size, tot_buy/sell_qty, avg_trade_price, ohlc, prev_close, ch, chp, last_traded_time, exch_feed_time. **No open-interest field** | Live 1m candles carry `oi = NULL`; OI comes from history (`oi_flag`) or chain snapshots, never from ticks |
| Rate limit | 5 of 15 calls refused in a 0.6 s burst | Consistent with a 5/s plan limit (10 passed, probably straddling a second boundary); our 4/s sliding window stays below it |
| History span | 100 days ok (future and option); 200 -> `-50 Invalid input` (genuine, no throttling this time) | `max_days_per_request: 90` is safe; limit lies between 100 and 200 |
| Option chain | `strikecount` 50 and 51 both gave 203 entries (the 50 call was throttled in this run) | Cap is 50 per side (51 is clamped); entries = 4N+3 |
| Probe version | Reports lack `time_of_day` / `throttled_retries_so_far`: the **old probe (v1)** was run | OI column value, Greeks field names and session hours still unseen: re-run with the v2/v3 build |

## Third real probe run (2026-10-22, v3 probe) -- all evidence visible
| Item | Result | Consequence |
|---|---|---|
| Open interest | 7th candle value with `oi_flag`: future 16,659,630; option 1,263,275; chain OI 186k to 1.9M (same magnitude) | `history.oi_flag: true`, `row[6]` read as OI |
| Option chain Greeks | `greeks=1` adds a nested `greeks` {delta, gamma, theta, vega, iv} to OPTION rows only; **iv is in percent** (15.96) | `chain.greeks: true`; underlying row has none |
| Chain rows | Fields: symbol (real FYERS symbol), strike_price, option_type, ltp, bid, ask, volume, oi, oich, oichp, prev_oi, fyToken. First row is the underlying (`option_type ""`, strike -1). `data` keys: optionsChain, callOi, putOi, expiryData, indiavixData. No capture time. | Snapshot rows map to contracts by real `symbol`; our own `captured_at` is stamped |
| Chain size | `strikecount` 50 and 51 both return 203 = 1 + 2 x (2N+1), N clamped at 50 | max 50 strikes each side |
| Session | 385 candles on every full day, 09:15 to 15:39, 0 outside, no weekends; no evening-session candles in 30 days | session window confirmed |
| Holiday | 20 Oct 2026 absent for both future and option | NSE holiday (inferred from data) |
| History span | 100 days ok, 200 days `-50 Invalid input` | `max_days_per_request: 90` kept |
| Symbol master | 86,655 contracts, 0 skipped; the exchange column is a numeric code ("10") | exchange now taken from the `NSE:` prefix; migration 006 repairs stored rows |
| SDK | 3.1.10 has no `expiry_dates` / `fno_historical_data` | the SDK's expired endpoints are not available here |
| Still open | Does FYERS serve history for a genuinely expired contract, and for how long? | test after the next expiry (27 Oct 15:40) with a symbol whose stored expiry has passed |

## Release 2 design decisions
| Decision | Why |
|---|---|
| LIVE candles are provisional; HISTORICAL supersedes them (never the reverse) | Ticks are sampled snapshots: tick-built high/low/volume are approximate, and ticks carry no OI. The old "never overwrite a CLOSED candle" rule would have frozen the approximation. Same-source disagreements are still conflicts. |
| Volume from previous-candle cumulative | A's builder drops the volume traded between the last tick of one minute and the first of the next (sparse options show 0). Untrusted baselines fall back to a lower bound. |
| `last_minute` compared at minute granularity | 15:39:05 > 15:39:00 would have dropped the day's final candle (caught by a test). |
| Chain rows keyed by real symbol, our `captured_at` | The response has no capture time and no expiry per row. |
