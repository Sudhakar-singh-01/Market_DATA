"""Start the local read API without changing the existing main.py CLI."""
import argparse


def main():
    parser = argparse.ArgumentParser(description='TIOS local read API (no broker calls)')
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error('port must be between 1 and 65535')
    import uvicorn
    uvicorn.run('api.app:app', host='127.0.0.1', port=args.port)


if __name__ == '__main__':
    main()
