"""Optional local HTTP interface. Existing CLI and Streamlit entry points remain."""
