"""Thin, authenticated GET API. Run on loopback: python -m api."""
import json
import logging
import os
import threading
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlalchemy.exc import SQLAlchemyError

from model.database_catalog import configured_catalog
from model.market_read_service import MarketReadService
from model.read_contracts import ReadRequestError, DataNotVerifiedError

security = HTTPBasic()
log = logging.getLogger('market_data.api')


def authenticate(credentials: HTTPBasicCredentials = Depends(security)):
    """Reuse dashboard password hashes; HTTP Basic is intended for loopback only."""
    from dotenv import load_dotenv
    from ui.password_hashing import verify_password
    from model.config.runtime_paths import env_path
    load_dotenv(env_path())
    role = credentials.username
    stored = os.environ.get({'user': 'USER_PASSWORD_HASH', 'admin': 'ADMIN_PASSWORD_HASH'}.get(role, ''), '')
    try:
        valid = bool(stored) and verify_password(credentials.password, stored)
    except (ValueError, TypeError):
        valid = False
    if not valid:
        raise HTTPException(401, 'Invalid credentials', headers={'WWW-Authenticate': 'Basic'})
    return role


def create_app(service=None, auth_dependency=authenticate):
    app = FastAPI(title='TIOS Market Data Read API', version='4.4.0',
                  description='Stored-data reads only. No broker requests, migrations or repairs on GET.')
    lock = threading.Lock()
    holder = [service]

    def get_service():
        with lock:
            if holder[0] is None:
                holder[0] = MarketReadService(configured_catalog())
            return holder[0]

    def require_admin(role=Depends(auth_dependency)):
        if role != 'admin':
            raise HTTPException(403, 'Administrator access required')
        return role

    @app.exception_handler(DataNotVerifiedError)
    async def quality_error(request, exc):
        return JSONResponse(status_code=409, content={'error': 'DATA_NOT_VERIFIED', 'detail': str(exc), 'data': []})

    @app.exception_handler(ReadRequestError)
    async def input_error(request, exc):
        return JSONResponse(status_code=422, content={'error': 'INVALID_READ_REQUEST', 'detail': str(exc)})

    @app.exception_handler(SQLAlchemyError)
    async def storage_error(request, exc):
        # Avoid DB URLs, SQL parameters or provider secrets in public error responses.
        log.warning('Read API storage unavailable (%s)', type(exc).__name__)
        return JSONResponse(status_code=503, content={'error': 'STORAGE_UNAVAILABLE', 'detail': 'Check configured database connectivity/schema'})

    @app.exception_handler(Exception)
    async def unexpected_error(request, exc):
        log.warning('Read API operation unavailable (%s)', type(exc).__name__)
        return JSONResponse(status_code=503, content={'error': 'READ_UNAVAILABLE', 'detail': 'Check local configuration and source data'})

    @app.get('/api/v1/instruments')
    def instruments(segment: str = 'CASH', category: str | None = None, active_only: bool = False,
                    limit: int = Query(100, ge=1, le=1000), cursor: str | None = None,
                    role=Depends(auth_dependency)):
        return get_service().get_instruments(segment, category=category, active_only=active_only, limit=limit, cursor=cursor)

    @app.get('/api/v1/candles')
    def candles(segment: str, symbol: str, timeframe: str = '1m', start: str = Query(alias='from'),
                end: str = Query(alias='to'), closed_only: bool = True, quality: str = 'raw', session: str = 'all',
                limit: int = Query(1000, ge=1, le=1000), cursor: str | None = None, role=Depends(auth_dependency)):
        return get_service().get_candles(segment, symbol, timeframe, start, end,
            closed_only=closed_only, quality=quality, limit=limit, cursor=cursor, session=session)

    @app.get('/api/v1/candles/latest')
    def latest(segment: str, symbol: str, timeframe: str = '1m', closed_only: bool = True,
               limit: int = Query(1, ge=1, le=100), role=Depends(auth_dependency)):
        return get_service().get_latest_candles(segment, symbol, timeframe, closed_only=closed_only, limit=limit)

    @app.get('/api/v1/coverage')
    def coverage(segment: str, symbol: str, start: str = Query(alias='from'), end: str = Query(alias='to'),
                 role=Depends(auth_dependency)):
        return get_service().get_coverage(segment, symbol, start, end)

    @app.get('/api/v1/fno/option-chain')
    def chain(underlying: str, start: str = Query(alias='from'), end: str = Query(alias='to'),
              batch_id: str | None = None, limit: int = Query(1000, ge=1, le=1000), cursor: str | None = None,
              role=Depends(auth_dependency)):
        return get_service().get_option_chain(underlying, start, end, batch_id=batch_id, limit=limit, cursor=cursor)

    @app.get('/api/v1/quality')
    def quality_reports(segment: str, scope: str | None = None, job_id: int | None = Query(None, ge=1),
                        limit: int = Query(100, ge=1, le=1000), cursor: str | None = None, role=Depends(require_admin)):
        return get_service().get_quality_report(segment, scope=scope, job_id=job_id, limit=limit, cursor=cursor)

    @app.get('/api/v1/jobs/{job_id}')
    def job(job_id: int, segment: str, role=Depends(auth_dependency)):
        return get_service().get_job_status(segment, job_id)

    @app.get('/api/v1/databases')
    def databases(role=Depends(require_admin)):
        return {'data': get_service().catalog.databases()}

    @app.get('/api/v1/databases/{segment}/tables')
    def tables(segment: str, role=Depends(require_admin)):
        return {'data': get_service().catalog.table_names(segment)}

    @app.get('/api/v1/databases/{segment}/tables/{table}/schema')
    def schema(segment: str, table: str, role=Depends(require_admin)):
        return get_service().catalog.schema(segment, table)

    def parse_filters(value):
        try:
            data = json.loads(value) if value else {}
            if not isinstance(data, dict):
                raise ValueError()
            return data
        except (ValueError, TypeError) as exc:
            raise ReadRequestError('filters must be a JSON object of column/value pairs') from exc

    @app.get('/api/v1/databases/{segment}/tables/{table}/rows')
    def rows(segment: str, table: str, filters: str | None = None, limit: int = Query(100, ge=1, le=1000),
             offset: int = Query(0, ge=0, le=100000), role=Depends(require_admin)):
        return get_service().catalog.rows(segment, table, filters=parse_filters(filters), limit=limit, offset=offset)

    @app.get('/api/v1/databases/{segment}/tables/{table}/count')
    def count(segment: str, table: str, filters: str | None = None, role=Depends(require_admin)):
        return {'count': get_service().catalog.count(segment, table, parse_filters(filters)), 'exact': True}

    return app


app = create_app()
