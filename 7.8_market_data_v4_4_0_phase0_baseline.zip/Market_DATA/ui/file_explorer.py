"""
ui/file_explorer.py
Restricted, read-only project file browser (spec Section 12).

Hard rules:
    - Only the whitelisted project directories below can be browsed --
      never an arbitrary OS path.
    - Path-traversal ("..", absolute paths, symlink escape) is rejected
      by resolving to an absolute path and checking it's still inside
      the project root.
    - Read-only: this module has no write/delete/execute function at all.
    - Binary files are not dumped as text (checked by extension + a
      raw-bytes decode attempt).
"""

from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parents[1]

ALLOWED_DIRS = [
    "config", "database", "model", "controller", "view", "ui",
    "data", "logs", "tests", "instruments",
]

_TEXT_EXTENSIONS = {".py", ".yaml", ".yml", ".sql", ".md", ".txt", ".json", ".cfg", ".ini", ".log", ".csv"}

_MAX_PREVIEW_BYTES = 200_000

# Credential-bearing files are blocked by NAME (not by luck of their extension)
# and are hidden from listings entirely. Spec Section 30: no .env content, no tokens.
_SENSITIVE_NAME_PARTS = (".env", "secret", "token", "credential", "password", "passwd", "apikey", "api_key", "private")
_SENSITIVE_SUFFIXES = {".pem", ".key", ".pfx", ".p12", ".crt"}


def _is_sensitive(path: Path) -> bool:
    name = path.name.lower()
    return any(part in name for part in _SENSITIVE_NAME_PARTS) or path.suffix.lower() in _SENSITIVE_SUFFIXES  # don't dump huge files into the browser


def _resolve_safe(relative_path: str) -> Optional[Path]:
    """Returns the resolved absolute path if it's inside an allowed
    directory under PROJECT_ROOT, else None (rejected)."""
    if not relative_path:
        return PROJECT_ROOT
    candidate = (PROJECT_ROOT / relative_path).resolve()
    try:
        candidate.relative_to(PROJECT_ROOT)
    except ValueError:
        return None  # escaped the project root -- reject
    # Must be the root itself or inside one of the allowed top-level dirs.
    if candidate == PROJECT_ROOT:
        return candidate
    top_level = candidate.relative_to(PROJECT_ROOT).parts[0] if candidate.relative_to(PROJECT_ROOT).parts else None
    if top_level not in ALLOWED_DIRS:
        return None
    return candidate


def list_allowed_roots() -> list:
    return [d for d in ALLOWED_DIRS if (PROJECT_ROOT / d).exists()]


def list_dir(relative_path: str) -> Optional[list]:
    """Returns a list of {name, type, size_bytes, modified, path} dicts
    for one directory level, or None if the path is disallowed/missing."""
    resolved = _resolve_safe(relative_path)
    if resolved is None or not resolved.exists() or not resolved.is_dir():
        return None
    entries = []
    for item in sorted(resolved.iterdir()):
        if _is_sensitive(item):
            continue  # never even list credential files
        try:
            stat = item.stat()
        except OSError:
            continue
        entries.append({
            "name": item.name,
            "type": "folder" if item.is_dir() else (item.suffix or "file"),
            "size_bytes": stat.st_size if item.is_file() else None,
            "modified": stat.st_mtime,
            "path": str(item.relative_to(PROJECT_ROOT)),
        })
    return entries


def read_text_preview(relative_path: str) -> Optional[str]:
    """Read-only text preview. Returns None if the path is disallowed,
    missing, a directory, or not a recognized text extension."""
    resolved = _resolve_safe(relative_path)
    if resolved is None or not resolved.is_file() or _is_sensitive(resolved):
        return None
    if resolved.suffix.lower() not in _TEXT_EXTENSIONS:
        return None
    try:
        data = resolved.read_bytes()[:_MAX_PREVIEW_BYTES]
        return data.decode("utf-8", errors="replace")
    except OSError:
        return None
