"""
ui/audit_log.py
Append-only audit logging against the audit_log table (see
database/schema.sql -- must be applied manually like every other
table in this project). Used for LOGIN/LOGOUT/BULK_DELETE/
RESET_CHECKPOINT/START_HISTORICAL_FETCH/START_AGGREGATION/EXPORT/
SYSTEM_OPERATION per the dashboard spec's audit requirement.

NEVER pass passwords, tokens, or API secrets into `parameters` --
callers are responsible for that; this module does not scrub input.
"""

import json
from typing import Optional

import pandas as pd
from sqlalchemy import inspect, text


def record_action(
    engine,
    actor_role: str,
    action: str,
    target: Optional[str] = None,
    parameters: Optional[dict] = None,
    records_affected: Optional[int] = None,
    result: str = "success",
    error_message: Optional[str] = None,
    ip_address: Optional[str] = None,
    session_id: Optional[str] = None,
    resolve_session: bool = True,
) -> None:
    """Best-effort: audit logging must never crash the calling page, so
    failures here are swallowed after being surfaced via the return
    value (callers may choose to st.warning() on False).

    ip_address/session_id are auto-filled from the current Streamlit
    session (ui/session_context.py) when not passed explicitly, so
    existing call sites get this for free. Outside a Streamlit session
    (e.g. tests) the lookup fails silently and both stay None. Background callers
    pass resolve_session=False and use context captured on the script thread."""
    if resolve_session and (ip_address is None or session_id is None):
        try:
            from ui.session_context import get_client_ip, get_session_id
            ip_address = get_client_ip() if ip_address is None else ip_address
            session_id = get_session_id() if session_id is None else session_id
        except Exception:
            pass
    try:
        with engine.begin() as conn:
            conn.execute(
                text("""
                    INSERT INTO audit_log
                        (actor_role, action, target, parameters, records_affected, result, error_message, ip_address, session_id)
                    VALUES
                        (:actor_role, :action, :target, :parameters, :records_affected, :result, :error_message, :ip_address, :session_id)
                """),
                {
                    "actor_role": actor_role,
                    "action": action,
                    "target": target,
                    "parameters": json.dumps(parameters) if parameters is not None else None,
                    "records_affected": records_affected,
                    "result": result,
                    "error_message": error_message,
                    "ip_address": ip_address,
                    "session_id": session_id,
                },
            )
    except Exception:
        pass  # audit logging is best-effort; never block the actual operation on it


def fetch_audit_log(engine, limit: int = 500, action_filter: Optional[str] = None) -> pd.DataFrame:
    query = "SELECT * FROM audit_log WHERE 1=1"
    params = {"limit": limit}
    if action_filter and action_filter != "(all)":
        query += " AND action = :action"
        params["action"] = action_filter
    query += " ORDER BY occurred_at DESC LIMIT :limit"
    with engine.begin() as conn:
        return pd.read_sql(text(query), conn, params=params)


AUDIT_TABLE_DDL = """CREATE TABLE IF NOT EXISTS audit_log (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actor_role          VARCHAR(20)     NOT NULL,
    action              VARCHAR(40)     NOT NULL,
    target              VARCHAR(100)    NULL,
    parameters          TEXT            NULL,
    records_affected    INT UNSIGNED    NULL,
    result              VARCHAR(20)     NOT NULL,
    error_message       TEXT            NULL,
    ip_address          VARCHAR(45)     NULL,
    session_id          VARCHAR(32)     NULL,
    INDEX idx_occurred_at (occurred_at),
    INDEX idx_action (action)
) ENGINE=InnoDB;"""


def audit_table_exists(engine) -> bool:
    return inspect(engine).has_table("audit_log")


def ensure_audit_table(engine) -> None:
    """Idempotent: CREATE TABLE IF NOT EXISTS, then ADD COLUMN for
    ip_address/session_id if the table already existed from before
    those columns were introduced. Only ever called from the
    admin-gated Audit Log page's explicit 'Create table' button."""
    with engine.begin() as conn:
        conn.execute(text(AUDIT_TABLE_DDL))
        for column, ddl in (("ip_address", "VARCHAR(45) NULL"), ("session_id", "VARCHAR(32) NULL")):
            exists = conn.execute(text(
                "SELECT COUNT(*) FROM information_schema.columns "
                "WHERE table_schema = DATABASE() AND table_name = 'audit_log' AND column_name = :c"),
                {"c": column}).scalar()
            if not exists:
                conn.execute(text(f"ALTER TABLE audit_log ADD COLUMN {column} {ddl}"))
