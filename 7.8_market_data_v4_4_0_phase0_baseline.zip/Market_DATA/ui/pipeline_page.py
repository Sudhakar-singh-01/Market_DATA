"""Persisted Cash operations. The same service is used by CLI workers."""
import datetime as dt
import json
import streamlit as st
from ui.auth import current_role
from ui.date_inputs import date_field
from ui.quality_page import get_service,records
from model.config.market_calendar import today_ist
from model.quality_store import ready
from controller.pipeline_service import start_worker
from model.pipeline_errors import FetchPreflightError


def render(kind):
    st.title('Historical Smart Fetch' if kind=='SMART_FETCH' else 'Aggregation')
    st.caption('Existing Cash ingestion and storage · persisted jobs · IST dates')
    c=st.columns(2)
    a=date_field(c[0],'Start date',default=str(today_ist()-dt.timedelta(days=7)),key=kind+'_from')
    b=date_field(c[1],'End date',default='today',key=kind+'_to')
    try:
        with st.spinner('Loading pipeline…'):service=get_service()
        names=st.multiselect('Instruments',[i.internal_name for i in service.instruments.all_instruments()],key=kind+'_symbols')
        params={'from':a,'to':b,'symbols':names}
        if kind=='AGGREGATION':
            params['timeframes']=st.multiselect('Target timeframes',[t.name for t in service.timeframes.derived_timeframes],key='agg_targets')
            st.caption('Only complete source buckets are closed. Existing conflicting CLOSED bars are reported; no automatic overwrite.')
        if not ready(service.engine):
            st.warning('Apply the metadata migration from Data Quality & Verification or quality-migrate CLI first.');return
        if kind=='SMART_FETCH':
            st.caption('Preview reads both stores and requests only missing closed minutes. Already-covered ranges make zero broker requests.')
            if st.button('Preview missing ranges',disabled=not names):
                with st.spinner('Checking stored coverage…'):plan=service.smart_preview(params)
                st.session_state['smart_preview']=(json.dumps(params,sort_keys=True),plan)
            saved=st.session_state.get('smart_preview')
            if saved and saved[0]==json.dumps(params,sort_keys=True):
                plan=saved[1];cols=st.columns(3)
                cols[0].metric('Estimated requests',plan['requests_estimate']);cols[1].metric('Covered symbol-days',plan['complete_symbol_days']);cols[2].metric('Blocked symbol-days',len(plan['blocked']))
                records(plan['blocked'] or plan['items'])
                allowed=not plan['blocked']
            else:allowed=False
        else:allowed=bool(names)
        if current_role()=='admin':
            if st.button('Reload credentials from .env'):
                st.info(service.action(current_role(),'reload_credentials',None))
            if st.button('Start job',type='primary',disabled=not allowed):
                jid=service.submit(current_role(),kind,params);start_worker(service);st.success(f'Job #{jid} queued.')
        else:st.info('View and preview access. An administrator can start or change jobs.')
        job_panel(service,kind)
    except FetchPreflightError as exc:
        from ui.fetch_review import show_blockers
        st.session_state.pop('smart_preview',None)
        show_blockers(exc.blocked)
    except (ValueError,PermissionError) as exc:st.error(str(exc))
    except Exception as exc:st.error(f'Pipeline unavailable ({type(exc).__name__}). No successful operation assumed.')


@st.fragment(run_every=3)
def job_panel(service,kind):
    jobs=[j for j in service.store.list(limit=100) if j['job_type']==kind]
    if not jobs:st.info('No jobs for this operation yet.');return
    records([{k:j.get(k) for k in ('id','state','started_at','heartbeat_at','rows_stored','error')} for j in jobs])
    jid=st.selectbox('Job details',[j['id'] for j in jobs],key=kind+'_job')
    job=next(j for j in jobs if j['id']==jid);result=job.get('result') or {}
    if result.get('total'):st.progress(min(1.,result.get('done',0)/result['total']),text=f"{result.get('done',0)}/{result['total']} · {result.get('current','')}")
    st.json({'state':job['state'],'params':job['params'],'result':result})
    if current_role()=='admin':
        if job['state'] in ('RUNNING','PENDING') and st.button('Cancel job',key=kind+'_cancel'):service.action('admin','cancel',jid)
        if job['state'] in ('PARTIAL','FAILED','INTERRUPTED') and st.button('Resume job',key=kind+'_resume'):
            service.action('admin','resume',jid);start_worker(service)
