"""Dashboard adapter: read-only monitoring, explicit role-checked workflow actions."""
import json
from sqlalchemy import select
from model.database_catalog import configured_catalog
from model.market_read_service import MarketReadService
from model.read_contracts import segment_name,page_limit,json_value
from controller.market_data_service import MarketDataService

STATES=('PENDING','RUNNING','SUCCESS','PARTIAL','FAILED','NO_DATA','CANCELLED','INTERRUPTED')


class WorkflowDashboardService:
    def __init__(self,catalog=None,commands=None):
        self._catalog=catalog; self._commands=commands
    @property
    def catalog(self):
        if self._catalog is None:self._catalog=configured_catalog()
        return self._catalog
    @property
    def commands(self):
        if self._commands is None:self._commands=MarketDataService()
        return self._commands
    @staticmethod
    def admin(role):
        if role!='admin':raise PermissionError('Administrator access required')
    def options(self,segment,*,role):
        self.admin(role);segment=segment_name(segment)
        if segment=='CASH':
            from model.config.instrument_loader import load_instrument_registry
            return {'symbols':sorted(i.internal_name for i in load_instrument_registry().all_instruments())}
        from model.fno.config import load_fno_settings
        u=load_fno_settings().universe
        return {'underlyings':list(u.underlyings),'expiries_ahead':u.expiries_ahead,
                'strike_window':u.strike_window,'include_futures':u.include_futures,'include_options':u.include_options}
    def preview(self,segment,params,timeframes,*,role):
        self.admin(role)
        return self.commands.preview_workflow(segment,params,timeframes=timeframes,role=role)
    def submit(self,plan,*,role):
        self.admin(role)
        from model.fno.errors import DuplicateJobError
        try:return self.commands.submit_workflow(plan,role=role)
        except DuplicateJobError as exc:
            return {'segment':segment_name(plan['segment']),'job_id':exc.job_id,'existing':True}
    def list_jobs(self,segment,*,role,state=None,limit=25,offset=0):
        self.admin(role);segment=segment_name(segment);page_limit(limit,50)
        if state is not None and state not in STATES:raise ValueError('Invalid workflow state')
        if type(offset) is not int or not 0<=offset<=100000:raise ValueError('Invalid page offset')
        table=self.catalog.table(segment,'ingestion_jobs' if segment=='CASH' else 'fno_ingestion_jobs')
        columns=[table.c[n] for n in ('id','state','started_at','finished_at','created_at','resumed_from') if n in table.c]
        query=select(*columns).where(table.c.job_type=='WORKFLOW')
        if state:query=query.where(table.c.state==state)
        with self.catalog.engine(segment).connect() as conn:
            rows=[dict(r) for r in conn.execute(query.order_by(table.c.id.desc()).limit(limit+1).offset(offset)).mappings()]
        return {'data':json_value(rows[:limit]),'has_more':len(rows)>limit}
    def get_job(self,segment,job_id,*,role):
        self.admin(role)
        if type(job_id) is not int or job_id<1:raise ValueError('Select a positive workflow job ID')
        row=MarketReadService(self.catalog).get_job_status(segment,job_id)['data'][0]
        if row['job_type']!='WORKFLOW':raise ValueError('This job is not a unified workflow')
        table=self.catalog.table(segment,'ingestion_jobs' if segment_name(segment)=='CASH' else 'fno_ingestion_jobs')
        if 'params' in table.c:
            with self.catalog.engine(segment).connect() as conn:
                params=conn.execute(select(table.c.params).where(table.c.id==job_id)).scalar()
            if isinstance(params,str):
                try:params=json.loads(params)
                except ValueError:params={}
            scope=params.get('workflow') if isinstance(params,dict) else None
            if isinstance(scope,dict):
                safe={k:scope[k][:256] for k in ('segment','from','to') if isinstance(scope.get(k),str)}
                safe['timeframes']=[t for t in scope.get('timeframes',[]) if t in ('1m','5m','15m','30m','1h','1d')] if isinstance(scope.get('timeframes'),list) else []
                targets=scope.get('targets')
                safe['targets']=[{k:(v[:256] if isinstance(v,str) else v) for k,v in t.items()
                    if k in ('symbol','internal_name','contract_id') and type(v) in (str,int)}
                    for t in targets[:200] if isinstance(t,dict)] if isinstance(targets,list) else []
                row['reviewed_scope']=safe
        return row
    def action(self,segment,action,job_id,*,role):
        self.admin(role)
        row=self.get_job(segment,job_id,role=role)
        allowed={'cancel':('PENDING','RUNNING'),'resume':('FAILED','PARTIAL','INTERRUPTED'),
                 'run':('PENDING','RUNNING')}
        if action not in allowed or row['state'] not in allowed[action]:
            raise ValueError('Action is unavailable for the current job state; refresh status')
        result=self.commands.job_action(segment,action,job_id,role=role)
        return {'segment':segment_name(segment),'action':action,'job_id':job_id,
                'new_job_id':result if action=='resume' and type(result) is int else None}
