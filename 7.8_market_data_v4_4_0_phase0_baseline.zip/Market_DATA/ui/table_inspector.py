"""
ui/table_inspector.py
Read-only database table inspection: schema (columns/types), indexes,
row counts, approximate size, oldest/newest record. Used by both the
user-facing Data Explorer page and the Admin Database page (same
underlying data -- Section 11 of the dashboard spec explicitly says
"Admin AND authorized users" should get this).

Deliberately does NOT expose an arbitrary SQL console (spec Section
11: "Do not expose destructive SQL operations through an unrestricted
SQL console") -- every query here is parameterized and fixed-shape.
"""


import pandas as pd
from sqlalchemy import text

from ui.data_access import KNOWN_TABLES

# Which column acts as this table's "time" column for oldest/newest --
# real column names from database/schema.sql, not guessed.
_TIME_COLUMN = {
    "instruments": "created_at",
    "candles": "candle_timestamp",
    "checkpoints": "updated_at",
    "ingestion_jobs": "started_at",
}


def table_schema(engine, table_name: str) -> pd.DataFrame:
    """Columns + data types + nullability, from information_schema --
    reflects the ACTUAL live schema, not an assumption."""
    query = """
        SELECT COLUMN_NAME AS column_name, COLUMN_TYPE AS data_type,
               IS_NULLABLE AS nullable, COLUMN_KEY AS key_type
        FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = :table_name
        ORDER BY ORDINAL_POSITION
    """
    with engine.begin() as conn:
        return pd.read_sql(text(query), conn, params={"table_name": table_name})


def table_indexes(engine, table_name: str) -> pd.DataFrame:
    query = """
        SELECT INDEX_NAME AS index_name, COLUMN_NAME AS column_name, NON_UNIQUE AS non_unique
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = :table_name
        ORDER BY INDEX_NAME, SEQ_IN_INDEX
    """
    with engine.begin() as conn:
        return pd.read_sql(text(query), conn, params={"table_name": table_name})


def table_summary(engine, table_name: str) -> dict:
    """row count, approximate size in MB (from information_schema --
    approximate for InnoDB, as MySQL itself documents), oldest/newest
    record if this table has a natural time column."""
    if table_name not in KNOWN_TABLES:
        raise ValueError(f"Unknown table '{table_name}'")

    with engine.begin() as conn:
        row_count = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}")).scalar()
        size_row = conn.execute(
            text("""
                SELECT ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS size_mb
                FROM information_schema.tables
                WHERE table_schema = DATABASE() AND table_name = :table_name
            """),
            {"table_name": table_name},
        ).scalar()

        oldest = newest = None
        time_col = _TIME_COLUMN.get(table_name)
        if time_col and row_count:
            oldest = conn.execute(text(f"SELECT MIN({time_col}) FROM {table_name}")).scalar()
            newest = conn.execute(text(f"SELECT MAX({time_col}) FROM {table_name}")).scalar()

    return {
        "row_count": row_count,
        "approx_size_mb": size_row if size_row is not None else "NOT AVAILABLE",
        "oldest_record": oldest if oldest is not None else "NOT AVAILABLE",
        "newest_record": newest if newest is not None else "NOT AVAILABLE",
    }
