"""
ui/engine_bootstrap.py
Shared "load config / build sink / build 1m reader" wiring, factored
out of ui/dashboard.py and ui/pages/1_Admin.py so every new page
doesn't repeat it. Pure wiring over existing model/controller code --
no new business logic (same rule as the rest of ui/*).
"""

import streamlit as st

from model.config.env_loader import load_env_config
from model.config.data_settings import load_data_settings
from model.config.timeframe_settings import load_timeframe_settings
from model.config.instrument_loader import load_instrument_registry
from model.exceptions import ConfigurationError
from model.storage.mysql import build_db_url, MySQLCandleSink, MySQLCheckpointStore, get_engine as get_mysql_storage_engine, read_1m_candles
from model.storage.parquet import ParquetCandleSink
from controller.sinks import CompositeCandleSink, NoOpCandleSink
from ui.logging_bootstrap import ensure_logging


@st.cache_resource
def load_config():
    env = load_env_config()
    data_settings = load_data_settings()
    timeframe_settings = load_timeframe_settings()
    instruments = load_instrument_registry()
    ensure_logging(data_settings, env)
    return env, data_settings, timeframe_settings, instruments


def load_config_or_stop():
    try:
        return load_config()
    except ConfigurationError as exc:
        st.error(f"Configuration error: {exc}")
        st.stop()


def build_sink(env, data_settings, instruments):
    sinks = []
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        sinks.append(MySQLCandleSink(engine, instruments))
    if data_settings.storage.parquet_enabled:
        sinks.append(ParquetCandleSink())
    if not sinks:
        return NoOpCandleSink()
    return sinks[0] if len(sinks) == 1 else CompositeCandleSink(sinks)


def build_checkpoint_store(env, data_settings):
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        return MySQLCheckpointStore(engine)
    return None


def build_1m_reader(env, data_settings):
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        return lambda fyers_symbol, from_date, to_date, instrument: read_1m_candles(engine, fyers_symbol, from_date, to_date, instrument)
    if data_settings.storage.parquet_enabled:
        parquet = ParquetCandleSink()
        return lambda fyers_symbol, from_date, to_date, instrument: parquet.read_candles(fyers_symbol, "1m", from_date, to_date)
    return None


def get_mysql_engine_or_none(env, data_settings):
    if not data_settings.storage.mysql_enabled:
        return None
    return get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))


@st.cache_resource
def get_repository():
    """The project's own read API (model/repository.py), built once."""
    from model.repository import MarketDataRepository
    env, data_settings, _tf, instruments = load_config()
    return MarketDataRepository(env, data_settings, instruments)
