"""
ui/ux_helpers.py
Shared UI polish used by every page:

1. apply_global_ui()  -- CSS so st.metric() text WRAPS instead of "...",
                         plus the global LIVE status pill.
2. task_guard(name)   -- "Task in progress" popup for long blocking tasks.
                         Driven by a small JS controller living in the browser
                         page itself, so the popup disappears on its own the
                         moment the task / script run ends (it no longer
                         depends on a server-side element being cleared).
                         Also: browser alert on tab close/refresh AND a
                         confirm() alert when the user clicks the sidebar
                         (page switch) or a page button while a task runs.
3. lazy_tabs()        -- renders ONLY the selected section (st.tabs runs the
                         code of every tab on every click -> slow).
4. cached_* helpers   -- short-TTL caches for heavy queries / health checks.
"""

import html as _html_lib
import json
from contextlib import contextmanager

import streamlit as st
from sqlalchemy import text

# ------------------------------------------------------------------ 1. Global CSS + LIVE pill

_GLOBAL_CSS = """
<style>
[data-testid="stMetric"] { overflow: visible !important; }
[data-testid="stMetricValue"], [data-testid="stMetricValue"] *,
[data-testid="stMetricLabel"], [data-testid="stMetricLabel"] * {
    white-space: normal !important; overflow: visible !important;
    text-overflow: clip !important; overflow-wrap: anywhere !important;
    word-break: normal !important; max-width: 100% !important;
}
[data-testid="stMetricValue"] {
    font-size: clamp(1.15rem, 1.7vw, 2rem) !important; line-height: 1.25 !important;
}
</style>
"""

_PILL_CSS = """
<style>
.live-pill { position: fixed; top: 58px; right: 18px; z-index: 99998;
    background: #10261a; color: #d7ffe6; border: 1px solid #2ecc71;
    border-radius: 999px; padding: 6px 14px; font-size: .82rem;
    box-shadow: 0 4px 14px rgba(0,0,0,.4); display: flex; gap: 8px; align-items: center; }
.live-dot { width: 9px; height: 9px; border-radius: 50%; background: #2ecc71;
    animation: live-blink 1.2s ease-in-out infinite; }
@keyframes live-blink { 50% { opacity: .25; } }
</style>
"""


def _render_jobs_pill():
    try:
        from ui.job_manager import job_manager
        active = job_manager.active()
        if not active:
            return
        running = [j for j in active if j["status"] == "running"]
        head = running[0] if running else active[0]
        queued = len(active) - (1 if running else 0)
        prog = f" {head['done']}/{head['total']}" if head["total"] else ""
        st.markdown(
            f"{_PILL_CSS}<div class='live-pill job-pill' style='top:96px;border-color:#f5a623;background:#2b2210;color:#ffe9c2'>"
            f"<b>JOB</b> #{head['id']} {head['kind']}{prog} {head['current']}"
            + (f" &nbsp;|&nbsp; +{queued} queued" if queued else "") + " &nbsp;|&nbsp; keeps running if you close the tab</div>",
            unsafe_allow_html=True)
    except Exception:
        pass


def _render_live_pill_once():
    _render_jobs_pill()
    try:
        from ui.data_access import live_run_manager
        state = live_run_manager.state
        if not state.running or state.controller is None:
            return
        stats = {}
        try:
            stats = state.controller.delay_stats()
        except Exception:
            pass
        extra = ""
        if stats.get("count"):
            extra = f" &nbsp;|&nbsp; candle delay last {stats['last_s']:.1f}s, avg {stats['avg_s']:.1f}s, max {stats['max_s']:.1f}s"
        n = state.controller.subscribed_instrument_count
        st.markdown(
            f"{_PILL_CSS}<div class='live-pill'><span class='live-dot'></span>"
            f"<b>LIVE running</b> &nbsp;|&nbsp; {n} symbols &nbsp;|&nbsp; since {state.started_at}{extra}</div>",
            unsafe_allow_html=True,
        )
    except Exception:
        pass


def apply_global_ui() -> None:
    st.markdown(_GLOBAL_CSS, unsafe_allow_html=True)
    if not st.session_state.get("_tg_js_installed"):
        try:
            _run_browser_js(_install_js())
            st.session_state["_tg_js_installed"] = True
        except Exception:
            pass
    try:
        @st.fragment(run_every=3)
        def _live_pill():
            _render_live_pill_once()
        _live_pill()
    except Exception:
        _render_live_pill_once()


# ------------------------------------------------------------------ 2. Task-in-progress guard

# Runs in the BROWSER PAGE realm (window.parent.eval), installed once per tab.
# Popup is visible only while BOTH are true:
#   - a .task-guard-marker element exists, and
#   - Streamlit says a script run is in progress (.stApp[data-teststate]).
# So it can never get "stuck" after the task is done.
_CONTROLLER_JS = r"""
(function () {
  if (window.__tgInstalled === 'v6') return;
  window.__tgInstalled = 'v6';
  var d = document;
  var style = d.createElement('style');
  style.textContent = [
    '#tg-popup{position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:999999;',
    'min-width:320px;max-width:90vw;background:#1b2330;color:#fff;border:1px solid #f5a623;',
    'border-left:6px solid #f5a623;border-radius:10px;padding:14px 18px;',
    'box-shadow:0 8px 30px rgba(0,0,0,.45);display:none;gap:14px;align-items:center;font-family:inherit}',
    '#tg-popup .tg-spin{width:26px;height:26px;flex:0 0 26px;border-radius:50%;',
    'border:4px solid rgba(255,255,255,.25);border-top-color:#f5a623;animation:tgspin .9s linear infinite}',
    '@keyframes tgspin{to{transform:rotate(360deg)}}',
    '#tg-popup .tg-title{font-weight:700;font-size:1rem}',
    '#tg-popup .tg-sub{font-size:.85rem;opacity:.85;margin-top:2px}'
  ].join('');
  d.head.appendChild(style);
  var popup = d.createElement('div');
  popup.id = 'tg-popup';
  popup.innerHTML = '<div class="tg-spin"></div><div><div class="tg-title"></div><div class="tg-sub"></div></div>';
  d.body.appendChild(popup);
  var title = popup.querySelector('.tg-title'), sub = popup.querySelector('.tg-sub');

  function active() {
    var m = d.querySelector('.task-guard-marker');
    if (!m) return null;
    var app = d.querySelector('.stApp');
    var s = app && app.getAttribute('data-teststate');
    if (s === 'notRunning' || s === 'stopped') return null;   // script finished -> not active
    return m;
  }
  var lastKey = '';
  function refresh() {
    // Only touch the DOM when something actually changed. (The old version re-wrote the
    // popup text on every call, which re-triggered its own MutationObserver -> infinite
    // loop -> "This page isn't responding".) No observer any more: a cheap poll is enough.
    var m = active();
    var key = m ? ((m.getAttribute('data-name') || '') + '|' + (m.getAttribute('data-sub') || '')) : '';
    if (key === lastKey) return;
    lastKey = key;
    if (m) {
      title.textContent = 'Task in progress: ' + (m.getAttribute('data-name') || '');
      sub.textContent = m.getAttribute('data-sub') || '';
      popup.style.display = 'flex';
    } else {
      popup.style.display = 'none';
    }
  }
  setInterval(function () { try { refresh(); } catch (err) {} }, 400);

  // Closing / refreshing the tab asks for confirmation while a task OR live ingestion is running.
  window.addEventListener('beforeunload', function (e) {
    var live = d.querySelector('.live-pill:not(.job-pill)');
    if (active() || live) { e.preventDefault(); e.returnValue = ''; return ''; }
  });
})();
"""


def _run_browser_js(script_html: str) -> None:
    """Run a <script> in the browser. st.components.v1.html is deprecated in newer
    Streamlit (removal announced after 2026-06-01), so prefer st.iframe."""
    if hasattr(st, "iframe"):
        st.iframe(script_html, height=1)
    else:
        import streamlit.components.v1 as components
        components.html(script_html, height=0)


def _install_js() -> str:
    code = json.dumps(_CONTROLLER_JS).replace("</", "<\\/")
    return f"<script>window.parent.eval({code});</script>"


@contextmanager
def task_guard(name: str, detail: str = "Please keep this tab open and don't switch pages until it finishes."):
    marker = st.empty()
    marker.markdown(
        f'<div class="task-guard-marker" data-name="{_html_lib.escape(name, quote=True)}" '
        f'data-sub="{_html_lib.escape(detail, quote=True)}" style="display:none"></div>',
        unsafe_allow_html=True,
    )
    hook = st.empty()
    try:
        with hook:
            _run_browser_js(_install_js())
    except Exception:
        pass
    try:
        yield
    finally:
        marker.empty()
        hook.empty()


# ------------------------------------------------------------------ 3. Lazy tabs

def lazy_tabs(labels: list, key: str) -> str:
    """Returns the selected label. Callers do `if sel == "X":` so ONLY the
    selected section's code (and DB queries) run -- st.tabs() runs all."""
    return st.radio("Section", labels, horizontal=True, key=key, label_visibility="collapsed")


# ------------------------------------------------------------------ 4. Caches

@st.cache_data(ttl=30, show_spinner=False)
def cached_health(_env, _data_settings, _key: str = "health"):
    from controller.health_controller import run_health_check
    return run_health_check(_env, _data_settings, check_fyers_api=False)


@st.cache_data(ttl=30, show_spinner=False)
def cached_row_counts(db_url: str) -> dict:
    from ui.data_access import get_mysql_engine, table_row_counts
    return table_row_counts(get_mysql_engine(db_url))


@st.cache_data(ttl=30, show_spinner=False)
def cached_summary_counts(db_url: str) -> dict:
    """Overview numbers in one connection. The duplicate scan was removed:
    UNIQUE(instrument_id, timeframe, candle_timestamp) in schema.sql makes
    duplicates impossible, so scanning the whole table for them on every
    click was pure cost. (Data Quality page still shows the count.)"""
    from ui.data_access import get_mysql_engine
    with get_mysql_engine(db_url).connect() as conn:
        return {
            "total_candles": conn.execute(text("SELECT COUNT(*) FROM candles")).scalar(),
            "running_jobs": conn.execute(text("SELECT COUNT(*) FROM ingestion_jobs WHERE finished_at IS NULL")).scalar(),
            "failed_jobs": conn.execute(text("SELECT COUNT(*) FROM ingestion_jobs WHERE status = 'failed'")).scalar(),
            "latest_ts": conn.execute(text("SELECT MAX(candle_timestamp) FROM candles")).scalar(),
            "dup_count": 0,
        }


@st.cache_data(ttl=30, show_spinner=False)
def cached_db_size_and_latest_write(db_url: str) -> tuple:
    from ui.data_access import get_mysql_engine
    with get_mysql_engine(db_url).connect() as conn:
        size_mb = conn.execute(text("""
            SELECT ROUND(SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2)
            FROM information_schema.tables WHERE table_schema = DATABASE()
        """)).scalar()
        latest = conn.execute(text("SELECT MAX(created_at) FROM candles")).scalar()
    return size_mb, latest


@st.cache_data(ttl=15, show_spinner=False)
def cached_read_candles(_reader, fyers_symbol: str, from_date: str, to_date: str, _instrument, cache_key: str):
    return _reader(fyers_symbol, from_date, to_date, _instrument)


# ------------------------------------------------------------------ 5. Candle delay panel (shared)

def render_delay_panel(controller, max_rows: int = 100) -> None:
    """Delay = time the closed candle reached us - candle end (candle timestamp + 1 min)."""
    import pandas as pd
    st.markdown("#### Candle delay (live)")
    st.caption("Delay = time the closed candle reached us minus candle end time (candle timestamp + 1 min). "
               "A 1m candle closes only when the first tick of the NEXT minute arrives, so quiet symbols show a larger delay.")
    records = controller.delay_records()
    if not records:
        st.info("No candle has closed yet in this session -- the first one appears after the next minute boundary.")
        return
    delays = [r["delay_s"] for r in records]
    stored = [r["store_delay_s"] for r in records]
    c = st.columns(5)
    c[0].metric("Last delay (s)", f"{delays[-1]:.2f}")
    c[1].metric("Average (s)", f"{sum(delays) / len(delays):.2f}")
    c[2].metric("Max (s)", f"{max(delays):.2f}")
    c[3].metric("Avg until stored (s)", f"{sum(stored) / len(stored):.2f}")
    c[4].metric("Candles measured", len(delays))
    st.dataframe(pd.DataFrame([{
        "Symbol": r["symbol"],
        "Candle start": r["candle_start"].strftime("%Y-%m-%d %H:%M:%S"),
        "Candle end": r["candle_end"].strftime("%H:%M:%S"),
        "Received at": r["received_at"].strftime("%H:%M:%S.%f")[:-3],
        "Stored at": r["stored_at"].strftime("%H:%M:%S.%f")[:-3],
        "Delay (s)": round(r["delay_s"], 2),
        "Delay until stored (s)": round(r["store_delay_s"], 2),
    } for r in reversed(records[-max_rows:])]), width="stretch")
