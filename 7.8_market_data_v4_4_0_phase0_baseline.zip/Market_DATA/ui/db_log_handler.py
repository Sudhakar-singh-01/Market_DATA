"""
ui/db_log_handler.py
Mirrors WARNING/ERROR/CRITICAL log records into the error_logs table
(spec Section 23/49: "should we store logs in the DB too"). INFO/DEBUG
stay file-only -- writing one DB row per tick-level INFO line would put
a database write on the live-tick hot path, which this project's own
Ctrl+C/shutdown-race fixes elsewhere were specifically about avoiding.

Best-effort and silent on failure (missing table, DB down): logging
must never crash the application it's trying to log for.
"""

import datetime
import logging
import queue
import threading


class DatabaseLogHandler(logging.Handler):
    def __init__(self, engine_factory):
        """engine_factory: a zero-arg callable returning a SQLAlchemy
        engine, called lazily on first use (and re-tried on failure) --
        not at handler-construction time, so a DB outage at dashboard
        startup doesn't block logging from working at all."""
        super().__init__(level=logging.WARNING)
        self._engine_factory = engine_factory
        self._engine = None
        self._queue: queue.Queue = queue.Queue(maxsize=5000)
        threading.Thread(target=self._worker, daemon=True).start()

    def emit(self, record: logging.LogRecord) -> None:
        # Never do the DB insert on the caller's thread (UI / live-tick path).
        try:
            msg = self.format(record) if self.formatter else record.getMessage()
            self._queue.put_nowait((record.created, record.levelname, record.name, msg))
        except Exception:
            pass

    def _worker(self) -> None:
        while True:
            item = self._queue.get()
            try:
                self._write(*item)
            finally:
                self._queue.task_done()

    def flush(self) -> None:
        """Wait until every queued record has been written (used on shutdown and in tests)."""
        try:
            self._queue.join()
        except Exception:
            pass

    def _write(self, created, levelname, name, message) -> None:
        try:
            if self._engine is None:
                self._engine = self._engine_factory()
            from sqlalchemy import text
            with self._engine.begin() as conn:
                conn.execute(
                    text("INSERT INTO error_logs (occurred_at, level, module, message) "
                        "VALUES (:occurred_at, :level, :module, :message)"),
                    {
                        "occurred_at": datetime.datetime.fromtimestamp(created),
                        "level": levelname,
                        "module": name,
                        "message": message,
                    },
                )
        except Exception:
            pass  # never let logging itself crash the app; file logging already captured this record
