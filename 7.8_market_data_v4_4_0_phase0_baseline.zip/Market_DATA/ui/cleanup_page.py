"""Explicit admin workflow for bounded dual-storage candle cleanup."""
import datetime as dt
import json
import streamlit as st
from model.config.market_calendar import today_ist
from model.read_contracts import TIMEFRAMES
from model.schema_management import _digest


def render_page(service, role, authenticate):
    if role != 'admin':
        st.error('Administrator access required')
        return
    st.title('Scoped Data Cleanup')
    st.caption('Cash/FNO candles, matching Parquet rows and progress invalidation in one reviewed operation.')
    st.warning('Stop all ingestion, aggregation, live writers and readers before applying. SQL and files cannot commit atomically. A verified backup is required; retained originals and an operation journal support manual recovery.')
    segments=list(service.catalog.factories)
    if not segments:
        st.info('Configure an existing database and separate Parquet root first.')
        return
    segment=st.selectbox('Segment',segments,key='cleanup_segment')
    symbol=st.text_input('Exact FYERS symbol',key='cleanup_symbol').strip()
    st.caption('Cash example: NSE:SBIN-EQ. FNO: use the exact stored contract symbol from All Databases & Tables.')
    timeframe=st.selectbox('Timeframe',TIMEFRAMES,key='cleanup_timeframe')
    if timeframe=='1m':
        st.info('Deleting canonical 1m data also invalidates derived candles for these dates. Review all affected timeframes below.')
    yesterday=today_ist()-dt.timedelta(days=1)
    start=st.date_input('From date (inclusive)',value=yesterday,max_value=yesterday,key='cleanup_start')
    end=st.date_input('To date (inclusive)',value=yesterday,max_value=yesterday,key='cleanup_end')
    inputs=dict(segment=segment,symbol=symbol,from_date=start.isoformat(),to_date=end.isoformat(),timeframe=timeframe)
    signature=_digest(inputs)
    if st.session_state.get('cleanup_inputs')!=signature:
        st.session_state.pop('cleanup_plan',None)
        st.session_state['cleanup_inputs']=signature
    if st.button('Preview cleanup',key='cleanup_preview',disabled=not symbol):
        st.session_state.pop('cleanup_plan',None)
        try:
            st.session_state['cleanup_plan']=service.preview(**inputs,role=role)
        except Exception as exc:
            _error(exc)
    plan=st.session_state.get('cleanup_plan')
    if not plan:
        return
    st.subheader('Review exact scope')
    st.json(plan)
    st.download_button('Download cleanup plan',json.dumps(plan,indent=2,default=str),'cleanup_plan.json','application/json')
    token=plan['token'][:16]
    backup=st.checkbox('I have verified a backup of both SQL and Parquet',key='cleanup_backup_'+token)
    stopped=st.checkbox('All writers and readers are stopped for this maintenance',key='cleanup_stopped_'+token)
    expected='CLEANUP '+plan['database']
    typed=st.text_input('Type '+expected,key='cleanup_confirmation_'+token)
    password=st.text_input('Re-enter admin password',type='password',key='cleanup_password_'+token)
    if st.button('Apply reviewed cleanup',key='cleanup_apply',disabled=not (backup and stopped and typed==expected and password)):
        if not authenticate(password):
            st.error('Admin password incorrect. Nothing changed.')
            return
        # Consume before calling: uncertain responses must never offer blind replay.
        st.session_state.pop('cleanup_plan',None)
        try:
            result=service.apply(plan,role=role,confirmation=typed,backup_acknowledged=backup,writers_stopped=stopped)
            st.json(result)
            if result['status']=='SUCCESS':
                st.success('Reviewed cleanup completed. Re-fetch and verify coverage before using this scope again.')
            else:
                st.error('Recovery review required. Keep workers/readers stopped; inspect the journal and retained originals before any retry.')
        except Exception as exc:
            _error(exc)


def _error(exc):
    if isinstance(exc,(ValueError,PermissionError)):
        st.error(str(exc))
    else:
        st.error(f'Cleanup unavailable ({type(exc).__name__}). Keep maintenance paused and inspect local operation journals before retrying.')
