"""Preview and explicit submission for Coverage's persisted Smart Fetch jobs."""
import json
import streamlit as st
from model.pipeline_errors import FetchPreflightError
from model.fno.errors import DuplicateJobError


def show_blockers(blocked):
    st.error('Fetch not submitted: resolve the blocked symbol-days below. Existing data has not been overwritten.')
    st.dataframe([{'symbol':r.get('symbol'),'date':r.get('date'),'reason':r.get('reason'),
                   'next_action':r.get('next_action') or 'Review this scope in Data Quality & Verification or narrow the date range.'}
                  for r in blocked],hide_index=True,width='stretch')
    with st.expander('Diagnostic details'):
        st.json(blocked)


def render_gap_fetch(params,role,get_service,start_worker):
    key=json.dumps(params,sort_keys=True)
    if st.session_state.get('cov_fetch_inputs')!=key:
        st.session_state.pop('cov_fetch_preview',None)
        st.session_state['cov_fetch_inputs']=key
    if st.button('Preview gap fill',key='cov_fill_all',disabled=role!='admin'):
        st.session_state.pop('cov_fetch_preview',None)
        try:
            plan=get_service().smart_preview(params)
            st.session_state['cov_fetch_preview']=plan
        except Exception as exc:
            _error(exc)
    plan=st.session_state.get('cov_fetch_preview')
    if not plan:return
    st.write({'scope':params,'estimated_requests':plan['requests_estimate'],
              'covered_symbol_days':plan['complete_symbol_days'],'blocked_symbol_days':len(plan['blocked'])})
    if plan['blocked']:
        show_blockers(plan['blocked']);return
    if not plan['items']:
        st.info('No missing closed minutes in this reviewed scope. No fetch job is needed.');return
    if st.button('Submit reviewed gap fill',key='cov_fetch_submit',disabled=role!='admin'):
        st.session_state.pop('cov_fetch_preview',None)
        try:
            service=get_service()
            jid=service.submit(role,'SMART_FETCH',params)
        except FetchPreflightError as exc:
            show_blockers(exc.blocked)
        except DuplicateJobError as exc:
            st.info(f'An identical active job already exists: #{exc.job_id}. Open Historical Smart Fetch for its status.')
        except Exception as exc:
            _error(exc)
        else:
            try:
                start_worker(service)
                st.success(f'Job #{jid} queued. Track its result in Historical Smart Fetch; queued does not mean complete.')
            except Exception as exc:
                st.warning(f'Job #{jid} was queued, but worker start failed ({type(exc).__name__}). Inspect the existing job before retrying.')


def _error(exc):
    st.error(str(exc) if isinstance(exc,(ValueError,PermissionError)) else
             f'Gap-fill operation unavailable ({type(exc).__name__}). Check configuration and stored job status before retrying.')
