"""
ui/instrument_editor.py
Appends a new entry to instruments/stocks.yaml or indices.yaml (spec:
search results for a symbol not yet in the instrument file should offer
an "add to instruments" option).

Deliberately does NOT load-then-yaml.dump-then-rewrite the whole file
-- that would silently strip the header comments these files already
have (see Section 41: "do not remove working functionality"). Instead
this appends a new block in the exact same hand-written format as the
existing entries, which is validated as parseable YAML before the
write is confirmed.
"""

from pathlib import Path
from typing import Optional

import yaml

from model.config.instrument_loader import InstrumentRegistry

_STOCKS_PATH = Path(__file__).resolve().parents[1] / "instruments" / "stocks.yaml"
_INDICES_PATH = Path(__file__).resolve().parents[1] / "instruments" / "indices.yaml"


def _target_path(category: str) -> Path:
    if category == "stock":
        from model.config.runtime_paths import config_path
        return config_path(_STOCKS_PATH)
    if category == "index":
        from model.config.runtime_paths import config_path
        return config_path(_INDICES_PATH)
    raise ValueError(f"category must be 'stock' or 'index', got {category!r}")


def validate_new_instrument(registry: InstrumentRegistry, internal_name: str, fyers_symbol: str) -> Optional[str]:
    """Returns an error message if this would be invalid to add, else None."""
    internal_name = internal_name.strip()
    fyers_symbol = fyers_symbol.strip()
    if not internal_name:
        return "internal_name cannot be empty."
    if not fyers_symbol:
        return "fyers_symbol cannot be empty."
    try:
        registry.get(internal_name)
        return f"'{internal_name}' already exists as an internal_name -- pick a different one."
    except KeyError:
        pass
    existing_symbols = {i.fyers_symbol for i in registry.all_instruments()}
    if fyers_symbol in existing_symbols:
        return f"'{fyers_symbol}' is already configured under a different internal_name."
    return None


def append_instrument(category: str, internal_name: str, fyers_symbol: str, exchange: str,
                      instrument_type: str, active: bool = True) -> None:
    """Appends one new instrument block. Caller is responsible for
    calling validate_new_instrument() first (kept separate so the UI
    can show the error before attempting a write)."""
    path = _target_path(category)
    block = (
        f"\n  - internal_name: {internal_name.strip()}\n"
        f"    fyers_symbol: \"{fyers_symbol.strip()}\"\n"
        f"    exchange: {exchange.strip()}\n"
        f"    instrument_type: {instrument_type.strip()}\n"
        f"    active: {'true' if active else 'false'}\n"
    )
    original = path.read_text(encoding="utf-8")
    updated = original.rstrip("\n") + "\n" + block

    # Validate the result actually still parses as YAML with the new
    # entry present, before committing it -- never leave the file in a
    # state that would make load_instrument_registry() start failing.
    parsed = yaml.safe_load(updated)
    list_key = "stocks" if category == "stock" else "indices"
    names_in_result = [e.get("internal_name") for e in parsed.get(list_key, [])]
    if internal_name.strip() not in names_in_result:
        raise ValueError("Internal consistency check failed -- the new entry didn't parse back out; nothing was written.")

    path.write_text(updated, encoding="utf-8")
