"""
ui/data_access.py
Non-UI logic for the dashboard: reading MySQL tables, listing
Parquet/export files, and managing a background live-ingestion thread.
Kept separate from ui/dashboard.py so this logic is independently
testable without a Streamlit runtime.

Deliberately reuses existing model/controller code rather than
duplicating it -- this is a thin read/control layer on top of the
same engine main.py drives.
"""

import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd
from sqlalchemy import create_engine, text

# Known tables from database/schema.sql -- deliberately NOT a fully
# generic "any table" browser, since only these four exist.
KNOWN_TABLES = ["instruments", "candles", "checkpoints", "ingestion_jobs"]


_ENGINES: dict = {}
_ENGINES_LOCK = threading.Lock()


def get_mysql_engine(db_url: str):
    """One shared engine (and connection pool) per URL for the whole
    process. Previously a brand-new engine was created on EVERY Streamlit
    rerun, i.e. a fresh pool + fresh MySQL handshake per click."""
    with _ENGINES_LOCK:
        engine = _ENGINES.get(db_url)
        if engine is None:
            engine = create_engine(db_url, pool_pre_ping=True, pool_recycle=1800, connect_args={"connect_timeout": 5})
            _ENGINES[db_url] = engine
        return engine


def fetch_table(engine, table_name: str, limit: int = 200) -> pd.DataFrame:
    if table_name not in KNOWN_TABLES:
        raise ValueError(f"Unknown table '{table_name}'. Expected one of {KNOWN_TABLES}.")
    with engine.begin() as conn:
        return pd.read_sql(text(f"SELECT * FROM {table_name} ORDER BY id DESC LIMIT :limit"), conn, params={"limit": limit})


def fetch_candles_filtered(
    engine,
    fyers_symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    limit: int = 500,
) -> pd.DataFrame:
    """Filtered view of `candles` (joined to instrument symbol) --
    the plain `candles` table alone isn't very readable since it only
    has instrument_id, not the symbol string."""
    query = """
        SELECT i.fyers_symbol, i.internal_name, c.timeframe, c.candle_timestamp,
               c.open, c.high, c.low, c.close, c.volume, c.source, c.status
        FROM candles c
        JOIN instruments i ON i.id = c.instrument_id
        WHERE 1=1
    """
    params = {}
    if fyers_symbol:
        query += " AND i.fyers_symbol = :fyers_symbol"
        params["fyers_symbol"] = fyers_symbol
    if timeframe:
        query += " AND c.timeframe = :timeframe"
        params["timeframe"] = timeframe
    if from_date:
        query += " AND DATE(c.candle_timestamp) >= :from_date"
        params["from_date"] = from_date
    if to_date:
        query += " AND DATE(c.candle_timestamp) <= :to_date"
        params["to_date"] = to_date
    query += " ORDER BY c.candle_timestamp DESC LIMIT :limit"
    params["limit"] = limit

    with engine.begin() as conn:
        return pd.read_sql(text(query), conn, params=params)


def existing_1m_coverage(engine, internal_names: list, from_date: str, to_date: str) -> dict:
    """Which of the selected instruments already have 1m candles stored in
    [from_date, to_date]? Returns {internal_name: {"count", "first", "last"}}
    (instruments with no data are omitted). One range query that uses the
    UNIQUE(instrument_id, timeframe, candle_timestamp) index."""
    import datetime as _dt
    from sqlalchemy import bindparam
    if not internal_names:
        return {}
    start = _dt.datetime.strptime(str(from_date)[:10], "%Y-%m-%d")
    end = _dt.datetime.strptime(str(to_date)[:10], "%Y-%m-%d") + _dt.timedelta(days=1)
    query = text("""
        SELECT i.internal_name AS name, COUNT(*) AS n,
               MIN(c.candle_timestamp) AS first_ts, MAX(c.candle_timestamp) AS last_ts
        FROM candles c JOIN instruments i ON i.id = c.instrument_id
        WHERE c.timeframe = '1m' AND i.internal_name IN :names
          AND c.candle_timestamp >= :start AND c.candle_timestamp < :end
        GROUP BY i.id, i.internal_name
    """).bindparams(bindparam("names", expanding=True))
    with engine.connect() as conn:
        rows = conn.execute(query, {"names": list(internal_names), "start": start, "end": end}).fetchall()
    return {r.name: {"count": int(r.n), "first": r.first_ts, "last": r.last_ts} for r in rows}


def table_row_counts(engine) -> dict:
    counts = {}
    with engine.begin() as conn:
        for table in KNOWN_TABLES:
            result = conn.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
            counts[table] = result
    return counts


# ---------------------------------------------------------------- File browsing

@dataclass
class FileEntry:
    name: str
    path: str
    size_bytes: int
    modified: str


def list_directory(root: str) -> list:
    """Non-recursive listing of one directory -- dashboard drills down
    one level at a time rather than dumping a huge recursive tree."""
    path = Path(root)
    if not path.exists():
        return []
    entries = []
    for item in sorted(path.iterdir()):
        stat = item.stat()
        entries.append(FileEntry(
            name=item.name + ("/" if item.is_dir() else ""),
            path=str(item),
            size_bytes=stat.st_size if item.is_file() else 0,
            modified=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
        ))
    return entries


def preview_parquet(file_path: str, max_rows: int = 200) -> pd.DataFrame:
    df = pd.read_parquet(file_path)
    return df.head(max_rows)


def preview_csv(file_path: str, max_rows: int = 200) -> pd.DataFrame:
    return pd.read_csv(file_path, nrows=max_rows)


# ---------------------------------------------------------------- Background live control

@dataclass
class LiveRunState:
    running: bool = False
    started_at: Optional[str] = None
    error: Optional[str] = None
    thread: object = field(default=None, repr=False)
    controller: object = field(default=None, repr=False)


class LiveRunManager:
    """
    Runs LiveIngestionController.start() (blocking) on a background
    daemon thread so the Streamlit UI thread never freezes. Only one
    live session is supported at a time -- starting a second one while
    one is running is rejected, matching the "no uncontrolled loops"
    spirit of the rest of this engine's design.
    """

    def __init__(self):
        self._state = LiveRunState()
        self._lock = threading.Lock()

    @property
    def state(self) -> LiveRunState:
        return self._state

    def start(self, controller_factory):
        with self._lock:
            if self._state.running:
                raise RuntimeError("A live session is already running. Stop it before starting another.")

            controller = controller_factory()
            # Each run gets its OWN state object, and its thread only ever
            # touches that object. Otherwise a stopped session's thread
            # finishing late (during a Restart) would mark the NEW session
            # as not-running.
            new_state = LiveRunState(running=True, started_at=time.strftime("%Y-%m-%d %H:%M:%S"), controller=controller)

            def _run():
                try:
                    controller.start()  # blocking until stop() is called
                except Exception as exc:
                    new_state.error = str(exc)
                finally:
                    new_state.running = False

            thread = threading.Thread(target=_run, daemon=True)
            new_state.thread = thread
            self._state = new_state
            thread.start()

    def stop(self):
        with self._lock:
            if not self._state.running or self._state.controller is None:
                return
            self._state.controller.stop()
            self._state.running = False

    def status_dict(self) -> dict:
        controller = self._state.controller
        base = {
            "running": self._state.running,
            "started_at": self._state.started_at,
            "error": self._state.error,
            "reason": getattr(controller, "session_reason", None),
        }
        if controller is not None:
            base.update({
                "subscribed_instruments": controller.subscribed_instrument_count,
                "ticks_received": controller._received_count,
                "closed_1m_candles": controller._closed_1m_count,
                "closed_derived_candles": controller._closed_derived_count,
                "candle_delay": controller.delay_stats(),
            })
        return base


# Module-level singleton -- Streamlit re-executes the script on every
# interaction, so this must survive reruns. A plain module-level
# object (persisting for the life of the `streamlit run` process) is
# the simplest correct choice for "one live session for this app
# instance" (matches the single-user, personal-tool nature of this
# whole project).
live_run_manager = LiveRunManager()
