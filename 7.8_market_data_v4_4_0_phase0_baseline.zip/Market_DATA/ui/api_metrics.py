"""
ui/api_metrics.py
In-process call metrics for the MarketDataRepository read API, recorded
when methods are invoked through the API Monitor page. Process-wide (module
level), so counts survive Streamlit reruns and are shared by all browser
sessions of this dashboard process.

Honest scope: other modules (indicator engine, strategies...) that call the
repository from THEIR OWN processes are not instrumented, so their calls are
not counted here. Nothing in this file is estimated or fabricated.
"""

import threading
import datetime
from typing import Optional

_lock = threading.Lock()
_stats: dict = {}


def record_call(method: str, elapsed_ms: float, ok: bool, records: Optional[int]) -> None:
    with _lock:
        s = _stats.setdefault(method, {"count": 0, "errors": 0, "total_ms": 0.0, "last_request": None, "records": 0})
        s["count"] += 1
        s["total_ms"] += elapsed_ms
        s["last_request"] = datetime.datetime.now()
        if ok:
            s["records"] += records or 0
        else:
            s["errors"] += 1


def snapshot() -> dict:
    with _lock:
        return {k: dict(v) for k, v in _stats.items()}


def total_requests() -> int:
    with _lock:
        return sum(v["count"] for v in _stats.values())
