"""
ui/job_panel.py
Streamlit widgets for the background job runner and the gap-fill tools.
(All logic lives in ui/job_manager.py and controller/gapfill_controller.py.)
"""

import time

import pandas as pd
import streamlit as st

from ui.job_manager import job_manager, auto_gapfill, load_pref, submit_gapfill, ensure_auto_gapfill

_ICON = {"queued": "🕒", "running": "⏳", "done": "✅", "partial": "⚠️", "failed": "❌", "cancelled": "🚫"}


def _fmt_elapsed(s: float) -> str:
    s = int(s)
    return f"{s // 60}m {s % 60:02d}s" if s >= 60 else f"{s}s"


def render_jobs_panel(kinds=None, key: str = "jobs", limit: int = 10) -> None:
    """Live list of background jobs (auto-refreshes every 2 s while something is running)."""
    active_now = bool(job_manager.active())

    @st.fragment(run_every=2 if active_now else None)
    def _panel():
        jobs = job_manager.snapshot(kinds, limit)
        still_active = any(j["status"] in ("queued", "running") for j in jobs)
        if active_now and not still_active:
            st.rerun()          # a job just finished: redraw the whole page once, then stop polling
        if not jobs:
            st.info("No background jobs yet.")
            return
        for idx, j in enumerate(jobs):
            with st.container(border=True):
                tag = " · auto" if j["trigger"] == "auto" else ""
                st.markdown(f"{_ICON.get(j['status'], '')} **#{j['id']} {j['label']}** — {j['status']}{tag}")
                if j["status"] in ("queued", "running"):
                    frac = (j["done"] / j["total"]) if j["total"] else 0.0
                    detail = j["current"] or ("waiting in queue" if j["status"] == "queued" else "starting")
                    st.progress(min(frac, 1.0), text=f"{j['done']}/{j['total']} · {detail} · {_fmt_elapsed(j['elapsed_s'])}")
                    if st.button("Cancel job" if not j["cancel_requested"] else "Cancelling...",
                                 key=f"{key}_cancel_{j['id']}", disabled=j["cancel_requested"]):
                        job_manager.cancel(j["id"])
                        st.rerun(scope="fragment")
                else:
                    st.caption(f"took {_fmt_elapsed(j['elapsed_s'])}")
                if j["error"]:
                    st.error(j["error"])
                if j["results"]:
                    with st.expander(f"Results ({len(j['results'])})", expanded=(idx == 0 and j["status"] != "running")):
                        st.dataframe(pd.DataFrame(j["results"]), width="stretch", hide_index=True)

    _panel()


def render_gapfill_panel(ctx) -> None:
    """Manual gap scan + fill, and the auto gap-filler switch."""
    from controller.gapfill_controller import scan_mysql
    from model.storage.mysql import build_db_url, get_engine

    ensure_auto_gapfill(ctx)
    if not ctx.data_settings.storage.mysql_enabled:
        st.info("Gap-fill reads stored candles from MySQL, so MySQL storage must be enabled.")
        return
    e = ctx.env.db
    engine = get_engine(build_db_url(e.host, e.port, e.name, e.user, e.password))

    st.markdown("#### Auto gap-fill")
    st.caption("Every few minutes the app scans stored 1m data (live disconnects, restarts, missed days) and "
               "queues a background job that fetches ONLY the missing candles from FYERS, then rebuilds the "
               "higher timeframes for those dates. Nothing is interpolated or invented. It runs inside this "
               "server process and (re)starts when a page loads after a restart.")
    pref = load_pref()
    c1, c2, c3 = st.columns(3)
    interval = c1.number_input("Scan every (minutes)", 1, 120, int(pref.get("interval_min", 5)), key="gf_interval")
    lookback = c2.number_input("Look back (days)", 1, 30, int(pref.get("lookback_days", 3)), key="gf_lookback")
    if auto_gapfill.running:
        c3.success("Auto gap-fill: ON")
        if c3.button("Turn OFF", key="gf_off"):
            auto_gapfill.stop()
            st.rerun()
    else:
        c3.warning("Auto gap-fill: OFF")
        if c3.button("Turn ON", type="primary", key="gf_on"):
            auto_gapfill.start(ctx, interval, lookback)
            st.rerun()
    s = auto_gapfill.status()
    if s["running"]:
        st.caption(f"Last scan: {s['last_scan_at'] or 'starting...'} — {s['last_scan_summary'] or '...'}"
                   + (f" — last job #{s['last_job_id']}" if s["last_job_id"] else ""))
    if s["last_error"]:
        st.error(f"Auto scan error: {s['last_error']}")

    st.divider()
    st.markdown("#### Scan now")
    if st.button("Scan for gaps", key="gf_scan_btn"):
        with st.spinner("Scanning stored candles..."):
            targets, no_baseline = scan_mysql(engine, ctx.instruments.active_instruments(), int(lookback))
        st.session_state["gf_scan"] = (targets, no_baseline, time.strftime("%H:%M:%S"))

    scan = st.session_state.get("gf_scan")
    if scan:
        targets, no_baseline, at = scan
        st.caption(f"Scan at {at}")
        if not targets:
            st.success("No gaps found in the look-back window.")
        else:
            st.warning(f"{len(targets)} instrument(s) have gaps — about {sum(t.missing_minutes for t in targets)} missing minute(s).")
            st.dataframe(pd.DataFrame([{
                "Symbol": t.internal_name, "Reason": t.reason, "Missing min (est.)": t.missing_minutes,
                "Gaps": t.gap_count, "Fetch range": f"{t.from_date} .. {t.to_date}", "Last stored": t.last_stored,
            } for t in targets]), width="stretch", hide_index=True)
            if st.button(f"Fill {len(targets)} gap target(s) now (background)", type="primary", key="gf_fill_btn"):
                job = submit_gapfill(ctx, targets=targets)
                st.session_state.pop("gf_scan", None)
                st.success(f"Job #{job.id} started in the background -- you can leave this page.")
        if no_baseline:
            st.caption(f"{len(no_baseline)} instrument(s) have no stored 1m data at all (need an initial historical load, "
                       f"not a gap-fill): {', '.join(no_baseline[:10])}{' ...' if len(no_baseline) > 10 else ''}")
    st.caption("Holidays listed in config/holidays.yaml are skipped; an unlisted weekday holiday may appear as a gap and the fetch simply returns no data. "
               "Minutes with no trades may not exist at FYERS either -- the job result shows 'Still missing' after each fill.")

    st.divider()
    render_jobs_panel(["gapfill"], key="gf_jobs", limit=5)
