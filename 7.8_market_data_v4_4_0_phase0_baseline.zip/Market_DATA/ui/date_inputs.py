"""
ui/date_inputs.py
Calendar-based date/time pickers (replaces free-text 'YYYY-MM-DD' boxes).
Return plain ISO strings so every existing call site (which passes
strings into controllers/queries) keeps working unchanged.
"""

import datetime
import re
from typing import Optional

import streamlit as st
from model.config.market_calendar import today_ist

_MIN_DATE = datetime.date(2000, 1, 1)


def _slug_key(label: str) -> str:
    return "date_" + re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")


def date_field(container, label: str, default: Optional[str] = None, key: Optional[str] = None) -> str:
    """Calendar picker with a 'Today' shortcut button. default=None ->
    optional field (returns '' when nothing is picked, matching the old
    empty text box behaviour). default='YYYY-MM-DD' -> required field
    pre-filled with that date."""
    key = key or _slug_key(label)
    today_key = f"{key}__today_clicked"
    if st.session_state.pop(today_key, False):
        st.session_state[key] = today_ist()

    # Streamlit warns (and may error in future versions) if a widget is
    # given both a `value` default AND has its state pre-set via
    # st.session_state for the same key. So `value` is only passed on
    # the widget's very first render (key not seen before); every
    # later render (including right after the Today click above) omits
    # it and lets the existing session_state value drive the widget.
    first_render = key not in st.session_state
    d_col, b_col = container.columns([4, 1])
    widget_kwargs = dict(min_value=_MIN_DATE, max_value=today_ist(), key=key, format="YYYY-MM-DD")
    if first_render:
        if default is None:
            widget_kwargs["value"] = None
        else:
            widget_kwargs["value"] = today_ist() if default == "today" else datetime.date.fromisoformat(default)
    picked = d_col.date_input(label, **widget_kwargs)
    # A plain st.write("") spacer doesn't match the date_input's actual
    # label-row height, so the button sits visibly too high. This fixed
    # spacer height matches Streamlit's default widget label row.
    b_col.markdown('<div style="height: 1.8rem"></div>', unsafe_allow_html=True)
    if b_col.button("Today", key=f"{key}__today_btn", width='stretch'):
        st.session_state[today_key] = True
        st.rerun()
    return picked.isoformat() if picked else ""


def datetime_field(container, label: str, key: str) -> str:
    """Calendar + time picker -> 'YYYY-MM-DD HH:MM:SS'."""
    d_col, t_col = container.columns(2)
    d = d_col.date_input(f"{label} (date)", value=today_ist(), min_value=_MIN_DATE,
                         max_value=today_ist(), key=f"{key}_d", format="YYYY-MM-DD")
    t = t_col.time_input(f"{label} (time)", value=datetime.time(9, 15), key=f"{key}_t", step=60)
    return f"{d.isoformat()} {t.strftime('%H:%M:%S')}"
