"""
ui/admin_data_access.py
Full CRUD (Create/Read/Update/Delete) against every table in
database/schema.sql, for the admin dashboard.

Read/filter functions reuse ui/data_access.py (fetch_table,
fetch_candles_filtered) -- this module adds the write side (insert/
update/delete) that ui/data_access.py deliberately does NOT have,
since the normal dashboard is read + pipeline-trigger only, and admin
CRUD is a distinct, higher-risk capability kept in its own module.

Every write function returns the number of affected rows so the admin
UI can show an accurate "1 row updated" / "0 rows matched" message
instead of assuming success.
"""

import datetime
from typing import Optional

from sqlalchemy import text


# ---------------------------------------------------------------- instruments

def insert_instrument(engine, internal_name: str, fyers_symbol: str, exchange: str,
                       instrument_type: str, category: str, is_active: bool) -> int:
    with engine.begin() as conn:
        result = conn.execute(
            text("""
                INSERT INTO instruments (internal_name, fyers_symbol, exchange, instrument_type, category, is_active)
                VALUES (:internal_name, :fyers_symbol, :exchange, :instrument_type, :category, :is_active)
            """),
            {"internal_name": internal_name, "fyers_symbol": fyers_symbol, "exchange": exchange,
             "instrument_type": instrument_type, "category": category, "is_active": is_active},
        )
        return result.lastrowid


def update_instrument(engine, instrument_id: int, **fields) -> int:
    """fields: any of internal_name, fyers_symbol, exchange, instrument_type, category, is_active."""
    if not fields:
        return 0
    set_clause = ", ".join(f"{col} = :{col}" for col in fields)
    with engine.begin() as conn:
        result = conn.execute(
            text(f"UPDATE instruments SET {set_clause} WHERE id = :id"),
            {**fields, "id": instrument_id},
        )
        return result.rowcount


def delete_instrument(engine, instrument_id: int) -> int:
    """
    Deletes an instrument row. Will fail with a foreign-key error if
    candles still reference it (database/schema.sql's
    fk_candles_instrument) -- deliberately NOT cascaded, so an admin
    can't silently wipe out a symbol's entire candle history by
    deleting the instrument row. Delete the candles first if that's
    genuinely intended.
    """
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM instruments WHERE id = :id"), {"id": instrument_id})
        return result.rowcount


# ---------------------------------------------------------------- candles

def insert_candle(engine, instrument_id: int, timeframe: str, candle_timestamp: datetime.datetime,
                   open_: float, high: float, low: float, close: float, volume: int,
                   source: str, status: str) -> int:
    with engine.begin() as conn:
        result = conn.execute(
            text("""
                INSERT INTO candles (instrument_id, timeframe, candle_timestamp, open, high, low, close, volume, source, status)
                VALUES (:instrument_id, :timeframe, :ts, :open, :high, :low, :close, :volume, :source, :status)
            """),
            {"instrument_id": instrument_id, "timeframe": timeframe, "ts": candle_timestamp,
             "open": open_, "high": high, "low": low, "close": close, "volume": volume,
             "source": source, "status": status},
        )
        return result.lastrowid


def update_candle(engine, candle_id: int, **fields) -> int:
    """fields: any of open, high, low, close, volume, status. Manual
    OHLCV correction -- use sparingly and prefer re-running historical/
    aggregate over hand-editing where possible, since a manual edit
    here will NOT be reflected in Parquet unless you also re-run
    aggregate/export against the corrected MySQL row."""
    if not fields:
        return 0
    set_clause = ", ".join(f"{col} = :{col}" for col in fields)
    with engine.begin() as conn:
        result = conn.execute(
            text(f"UPDATE candles SET {set_clause} WHERE id = :id"),
            {**fields, "id": candle_id},
        )
        return result.rowcount


def delete_candle(engine, candle_id: int) -> int:
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM candles WHERE id = :id"), {"id": candle_id})
        return result.rowcount


def _candle_filter_sql(instrument_id: int, timeframe=None, from_date=None, to_date=None, status=None, source=None):
    """ONE shared WHERE builder for both the delete PREVIEW count and the
    actual DELETE, so what the admin confirms is exactly what gets deleted.
    instrument_id is mandatory: bulk delete can never target every
    instrument at once."""
    where = " WHERE instrument_id = :instrument_id"
    params = {"instrument_id": instrument_id}
    if timeframe:
        where += " AND timeframe = :timeframe"
        params["timeframe"] = timeframe
    if from_date:
        where += " AND DATE(candle_timestamp) >= :from_date"
        params["from_date"] = from_date
    if to_date:
        where += " AND DATE(candle_timestamp) <= :to_date"
        params["to_date"] = to_date
    if status:
        where += " AND status = :status"
        params["status"] = status
    if source:
        where += " AND source = :source"
        params["source"] = source
    return where, params


def count_candles_filtered(engine, instrument_id: int, timeframe: Optional[str] = None,
                           from_date: Optional[str] = None, to_date: Optional[str] = None,
                           status: Optional[str] = None, source: Optional[str] = None) -> int:
    """Exact number of rows delete_candles_filtered() would remove (read-only)."""
    where, params = _candle_filter_sql(instrument_id, timeframe, from_date, to_date, status, source)
    with engine.begin() as conn:
        return conn.execute(text("SELECT COUNT(*) FROM candles" + where), params).scalar()


def delete_candles_filtered(engine, instrument_id: int, timeframe: Optional[str] = None,
                             from_date: Optional[str] = None, to_date: Optional[str] = None,
                             status: Optional[str] = None, source: Optional[str] = None) -> int:
    """Bulk delete -- e.g. to force a clean re-aggregate for one
    instrument/timeframe/date-range. Requires instrument_id (not just
    a free-text WHERE) so an admin can't accidentally wipe every
    instrument's candles with one click."""
    where, params = _candle_filter_sql(instrument_id, timeframe, from_date, to_date, status, source)
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM candles" + where), params)
        return result.rowcount


# ---------------------------------------------------------------- checkpoints

def upsert_checkpoint(engine, fyers_symbol: str, timeframe: str, synced_through_date: str) -> None:
    with engine.begin() as conn:
        conn.execute(
            text("""
                INSERT INTO checkpoints (fyers_symbol, timeframe, synced_through_date)
                VALUES (:fs, :tf, :date)
                ON DUPLICATE KEY UPDATE synced_through_date = :date
            """),
            {"fs": fyers_symbol, "tf": timeframe, "date": synced_through_date},
        )


def delete_checkpoint(engine, checkpoint_id: int) -> int:
    """Deleting a checkpoint forces the next historical run for that
    symbol/timeframe to refetch from scratch instead of resuming --
    the intended way to force a clean resync from the admin UI."""
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM checkpoints WHERE id = :id"), {"id": checkpoint_id})
        return result.rowcount


# ---------------------------------------------------------------- ingestion_jobs

def insert_ingestion_job(engine, job_type: str, fyers_symbol: Optional[str], timeframe: Optional[str],
                          from_date: Optional[str], to_date: Optional[str], status: str,
                          raw_count: Optional[int] = None, valid_count: Optional[int] = None,
                          invalid_count: Optional[int] = None, error_message: Optional[str] = None) -> int:
    with engine.begin() as conn:
        result = conn.execute(
            text("""
                INSERT INTO ingestion_jobs
                    (job_type, fyers_symbol, timeframe, from_date, to_date, status,
                     raw_count, valid_count, invalid_count, error_message, finished_at)
                VALUES
                    (:job_type, :fyers_symbol, :timeframe, :from_date, :to_date, :status,
                     :raw_count, :valid_count, :invalid_count, :error_message, NOW())
            """),
            {"job_type": job_type, "fyers_symbol": fyers_symbol, "timeframe": timeframe,
             "from_date": from_date, "to_date": to_date, "status": status,
             "raw_count": raw_count, "valid_count": valid_count, "invalid_count": invalid_count,
             "error_message": error_message},
        )
        return result.lastrowid


def delete_ingestion_job(engine, job_id: int) -> int:
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM ingestion_jobs WHERE id = :id"), {"id": job_id})
        return result.rowcount


# ---------------------------------------------------------------- data cleanup (Section 27)
def _stale_open_filter_sql(older_than_date: str, instrument_id: Optional[int] = None, timeframe: Optional[str] = None):
    """Stale OPEN candles = ones that should have closed and been
    replaced by a CLOSED row already (e.g. left behind by a crashed
    live session -- see the Ctrl+C/shutdown fixes elsewhere in this
    project). instrument_id is optional here (unlike bulk delete):
    cleanup is a maintenance sweep, not a targeted deletion."""
    where = " WHERE status = 'OPEN' AND DATE(candle_timestamp) < :older_than_date"
    params = {"older_than_date": older_than_date}
    if instrument_id is not None:
        where += " AND instrument_id = :instrument_id"
        params["instrument_id"] = instrument_id
    if timeframe:
        where += " AND timeframe = :timeframe"
        params["timeframe"] = timeframe
    return where, params


def count_stale_open_candles(engine, older_than_date: str, instrument_id: Optional[int] = None, timeframe: Optional[str] = None) -> int:
    where, params = _stale_open_filter_sql(older_than_date, instrument_id, timeframe)
    with engine.begin() as conn:
        return conn.execute(text("SELECT COUNT(*) FROM candles" + where), params).scalar()


def delete_stale_open_candles(engine, older_than_date: str, instrument_id: Optional[int] = None, timeframe: Optional[str] = None) -> int:
    where, params = _stale_open_filter_sql(older_than_date, instrument_id, timeframe)
    with engine.begin() as conn:
        result = conn.execute(text("DELETE FROM candles" + where), params)
        return result.rowcount
