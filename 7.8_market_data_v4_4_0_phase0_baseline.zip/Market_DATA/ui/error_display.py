"""
ui/error_display.py
Shared error rendering (spec Section 33): clear message, which
operation/resource failed, backend detail only for admins, a Retry
button, and a link to the Logs page.

Applied to the highest-value operational flows (Historical Data,
Aggregation, Bulk Delete, Checkpoints, Live start/stop, Data Explorer
loads, API Monitor). Not every single small CRUD button in 1_Admin.py
uses this yet -- stated honestly rather than silently left inconsistent.
"""

from typing import Callable, Optional

import streamlit as st


def show_error(operation: str, resource: str, exc: Exception, role: str,
               retry: Optional[Callable] = None) -> None:
    st.error(f"**{operation} failed** (resource: `{resource}`)")
    if role == "admin":
        st.caption(f"Backend error: {type(exc).__name__}: {exc}")
    else:
        st.caption("Details are visible to admins. Check the Logs page, or ask an admin to check Admin: Audit Log.")
    if retry is not None and st.button("Retry", key=f"retry_{operation}_{resource}"):
        retry()
    st.caption("Full backend detail is in the **Logs** page (sidebar).")
