"""
ui/components.py
Shared, reusable Streamlit UI pieces used by BOTH ui/dashboard.py and
ui/pages/1_Admin.py -- kept in one place so stock/index selection
behaves identically everywhere.

IMPORTANT (why this looks the way it does):
    A widget that has a `key=` has its value owned by
    st.session_state[key] from that point on. Passing `default=`/`value=`
    to a KEYED widget only affects its very FIRST render -- on every
    later rerun (e.g. after a checkbox click), Streamlit uses whatever
    is already in session_state for that key and SILENTLY IGNORES
    `default=`. That was the exact bug: checking "Select all" changed
    a plain Python variable, but the already-rendered multiselect kept
    its old session_state value and never picked up the new default.

    The correct fix is an `on_change` callback on the checkbox that
    writes directly into st.session_state[<multiselect_key>] BEFORE the
    multiselect widget is instantiated on the rerun. This is the
    pattern Streamlit's own docs recommend for "select all" checkboxes.
"""

import streamlit as st


def _apply_select_all(multiselect_key: str, checkbox_key: str, options: list):
    """on_change callback: runs the instant the checkbox is toggled,
    before the script reruns and the multiselect widget renders."""
    if st.session_state.get(checkbox_key):
        st.session_state[multiselect_key] = list(options)
    else:
        st.session_state[multiselect_key] = []


def instrument_selector(instruments, key_prefix: str) -> list:
    """
    Renders separate Stocks and Indices multiselect dropdowns, each
    with a working "select all" checkbox, and returns the combined
    list of selected internal_name strings.

    key_prefix: must be unique per call site (e.g. "hist", "agg",
    "live", "admin_hist") since Streamlit widget keys must be unique
    across the whole app, including across pages in the same session.
    """
    all_stocks = [i.internal_name for i in instruments.all_stocks()]
    all_indices = [i.internal_name for i in instruments.all_indices()]

    stock_ms_key = f"{key_prefix}_stocks"
    stock_cb_key = f"{key_prefix}_all_stocks"
    index_ms_key = f"{key_prefix}_indices"
    index_cb_key = f"{key_prefix}_all_indices"

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Stocks**")
        st.checkbox(
            "Select all stocks", key=stock_cb_key,
            on_change=_apply_select_all, args=(stock_ms_key, stock_cb_key, all_stocks),
        )
        selected_stocks = st.multiselect("Choose stock(s)", all_stocks, key=stock_ms_key)

    with col2:
        st.markdown("**Indices**")
        st.checkbox(
            "Select all indices", key=index_cb_key,
            on_change=_apply_select_all, args=(index_ms_key, index_cb_key, all_indices),
        )
        selected_indices = st.multiselect("Choose index/indices", all_indices, key=index_ms_key)

    return selected_stocks + selected_indices
