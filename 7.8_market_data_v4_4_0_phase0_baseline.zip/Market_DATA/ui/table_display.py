"""
ui/table_display.py
Wrapped-text table display. Streamlit's grid (st.dataframe) truncates
long text by default; combining a wide TextColumn with a taller
row_height makes it wrap onto multiple lines instead of cutting off.
"""

from typing import Iterable

import streamlit as st


_WRAP_THRESHOLD_CHARS = 25  # only columns genuinely likely to overflow get wrapped + a taller row


def wrapped_dataframe(df, wrap_columns: Iterable[str], row_height: int = 70,
                      width: str = "stretch", height="auto", **kwargs):
    """Render df with LONG-text columns word-wrapped instead of
    truncated. wrap_columns is a list of CANDIDATES (e.g. "every text
    column", or a known long field like 'message') -- only the ones
    whose actual content is long enough to need it get the wide/tall
    treatment, so short columns like id/internal_name/exchange don't
    get stretched out for no reason (that's what made tables look
    sparse/oddly spaced before this fix)."""
    def _needs_wrap(col: str) -> bool:
        if col not in df.columns or df.empty:
            return False
        try:
            return df[col].astype(str).str.len().max() > _WRAP_THRESHOLD_CHARS
        except Exception:
            return False

    columns_to_wrap = [c for c in wrap_columns if _needs_wrap(c)]
    column_config = {col: st.column_config.TextColumn(width="large") for col in columns_to_wrap}
    effective_row_height = row_height if columns_to_wrap else None  # None = Streamlit's normal compact row height
    return st.dataframe(df, column_config=column_config, row_height=effective_row_height,
                        width=width, height=height, **kwargs)
