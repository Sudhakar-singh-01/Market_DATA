"""Lazy FNO dashboard sections. All database and operational logic is in service."""
import datetime as dt
import json

import pandas as pd
import streamlit as st

from ui.auth import current_role
from ui.ux_helpers import lazy_tabs
from ui.fno.service import FnoService
from model.fno.aggregation import MINUTES
from model.fno.models import IST

SECTIONS=["Overview","Option Chain","Futures","Options Contracts","Historical Fetch","Live Data",
          "Aggregation","Storage Manager","Checkpoints","Jobs and Logs","Data Quality","Settings"]


@st.cache_resource(show_spinner=False)
def get_service():
    return FnoService()


def show_rows(rows,total=None):
    if total is not None: st.caption(f"{total:,} matching rows · server-side pagination")
    if len(rows): st.dataframe(pd.DataFrame(rows),width="stretch",hide_index=True)
    else: st.info("No matching data yet.")


def table(service,label,key,filters=None):
    page=st.number_input("Page",min_value=1,value=1,step=1,key=key+"_page")-1
    rows,total=service.browse(label,page=page,size=50,filters=filters)
    show_rows(rows,total)
    if rows:
        st.download_button("Export this page as CSV",pd.DataFrame(rows).to_csv(index=False),
                           file_name="fno_"+key+".csv",mime="text/csv",key=key+"_csv")
    return rows


def dates(key):
    today=dt.datetime.now(IST).date()
    col=st.columns(2)
    a=col[0].date_input("From (IST)",today-dt.timedelta(days=7),key=key+"_from")
    b=col[1].date_input("To (IST)",today,key=key+"_to")
    return {"from":a.isoformat(),"to":b.isoformat()}


def underlyings(service,key):
    choices=list(service.settings.universe.underlyings)
    return st.multiselect("Underlyings",choices,default=choices,key=key+"_underlyings")


def admin_only():
    if current_role()!="admin":
        st.info("View access. An administrator can run jobs and manage FNO data.")
        return False
    return True


def submit(service,kind,params,label,key):
    if st.button(label,key=key,type="primary"):
        jid=service.submit(current_role(),kind,params)
        st.success(f"Job #{jid} queued. Follow progress in Jobs and Logs.")


def overview(service):
    data=service.overview()
    cols=st.columns(3)
    cols[0].metric("Contracts",sum(r["rows_count"] for r in data["contracts"]))
    cols[1].metric("Candle rows",sum(r["rows_count"] for r in data["candles"]))
    cols[2].metric("Active jobs",sum(r["rows_count"] for r in data["jobs"] if r["state"] in ("PENDING","RUNNING")))
    st.caption("FNO database and FNO Parquet only · timestamps use IST · paper-analysis data")
    for name in ("contracts","candles","jobs"):
        st.subheader(name.replace("_"," ").title())
        show_rows(data[name])
    if admin_only(): submit(service,"CONTRACT_SYNC",{},"Sync contract master","fno_sync")


def contracts(service,category):
    key="fno_"+category.lower()
    u=st.selectbox("Underlying",["All",*service.settings.universe.underlyings],key=key+"_u")
    status=st.selectbox("Status",["All","ACTIVE","EXPIRED"],key=key+"_status")
    filters={"category":category,"underlying":None if u=="All" else u,"status":None if status=="All" else status}
    symbol=st.text_input('Exact contract symbol',key=key+'_symbol')
    if symbol:filters['fyers_symbol']=symbol.strip()
    if st.checkbox('Filter expiry',key=key+'_expiry_filter'):filters['expiry']=st.date_input('Contract expiry',key=key+'_expiry')
    if category=='OPTIONS':
        side=st.selectbox('Option type',['All','CE','PE'],key=key+'_side')
        if side!='All':filters['option_type']=side
        strike=st.number_input('Strike (0 = all)',min_value=0.,value=0.,key=key+'_strike')
        if strike:filters['strike']=strike
    rows=table(service,"Contracts",key,filters)
    if rows:
        choices={r["id"]:r["fyers_symbol"] for r in rows}
        cid=st.selectbox("Inspect contract",list(choices),format_func=lambda x:choices[x],key=key+"_cid")
        tf=st.selectbox("Timeframe",["1m",*MINUTES],key=key+"_tf")
        scope=dates(key+'_c')
        table(service,"Candles",key+"_candles",{"contract_id":cid,"timeframe":tf,**scope})
        if st.button('Load contract coverage heatmap',key=key+'_heatmap'):
            coverage_heatmap(service,cid,scope,category)


def option_chain(service):
    u=st.selectbox("Underlying",list(service.settings.universe.underlyings),key="fno_chain_u")
    filters={"underlying":u,**dates("fno_chain")}
    if st.checkbox("Filter by expiry",key="fno_chain_expiry_filter"):
        filters["chain_expiry"]=st.date_input("Expiry",key="fno_chain_expiry")
    table(service,"Option chain","fno_chain_rows",filters)
    st.caption("IV is stored in percent. Each row includes captured_at and the selected expiry.")
    if admin_only():
        loop=st.checkbox("Repeat during market hours",key="fno_chain_loop")
        submit(service,"CHAIN_SNAPSHOT",{"underlyings":[u],"loop":loop},"Capture option chain","fno_chain_submit")


def historical(service):
    params={**dates("fno_hist"),"underlyings":underlyings(service,"fno_hist"),"use_parquet":True}
    params["expiries_ahead"]=st.number_input("Next expiries",1,12,service.settings.universe.expiries_ahead,key="fno_hist_exp")
    params["strike_window"]=service.settings.universe.strike_window
    st.caption("Run after 16:00 IST with live ingestion stopped. Preview uses one spot-quote request; harvest uses the persisted ATM selection.")
    if not admin_only():return
    key=json.dumps(params,sort_keys=True)
    if st.button("Estimate requests",key="fno_hist_preview"):
        with st.spinner("Calculating request plan…"):
            prepared,estimate,limiter=service.historical_preview(params)
        st.session_state["fno_hist_plan"]=(key,prepared,estimate,limiter)
    plan=st.session_state.get("fno_hist_plan")
    if plan and plan[0]==key:
        st.json({"request_estimate":plan[2],"shared_account_limiter":plan[3]})
        st.caption("Account quota is shared by processes using the same runtime directory. Account entitlement still needs a live probe.")
        submit(service,"HISTORICAL_HARVEST",plan[1],"Start historical fetch","fno_hist_submit")


def live(service):
    table(service,"Jobs","fno_live_jobs",{"job_type":"LIVE"})
    st.caption("Use one FNO socket. Stop any Cash-market live session before starting FNO live. Stop/cancel from Jobs and Logs.")
    if admin_only():
        us=underlyings(service,"fno_live")
        submit(service,"LIVE",{"underlyings":us},"Start FNO live","fno_live_submit")


def aggregation(service):
    st.caption("Canonical 1m → session-anchored 5m / 15m / 30m / 1h / 1d. Incomplete buckets are skipped; IV/Greeks stay NULL.")
    params={**dates("fno_agg"),"underlyings":underlyings(service,"fno_agg"),"use_parquet":True}
    params["timeframes"]=st.multiselect("Targets",list(MINUTES),default=list(MINUTES),key="fno_agg_targets")
    if admin_only():submit(service,"AGGREGATION",params,"Run aggregation","fno_agg_submit")
    table(service,"Aggregation jobs","fno_aggregation_jobs")


def destructive(service,action,key):
    if not admin_only():return
    cid=st.number_input("Contract ID",min_value=1,value=1,step=1,key=key+"_cid")
    tf=st.selectbox("Timeframe",["1m",*MINUTES],key=key+"_tf")
    jt=st.selectbox("Checkpoint type",["HISTORICAL","AGGREGATION"],key=key+"_jt") if action=="RESET_CHECKPOINTS" else "HISTORICAL"
    if st.button("Preview exact counts",key=key+"_preview"):
        st.session_state[key+"_plan"]=service.destructive_preview(action,cid,tf,jt)
    plan=st.session_state.get(key+"_plan")
    if not plan or (plan["contract_id"],plan["timeframe"],plan["job_type"])!=(cid,tf,jt):return
    st.json(plan)
    confirm=st.checkbox("I confirm this exact FNO selection",key=key+"_confirm")
    phrase=st.text_input("Type CONFIRM",key=key+"_phrase")
    if st.button("Apply confirmed action",key=key+"_apply",disabled=not(confirm and phrase=="CONFIRM")):
        n=service.destructive_execute(current_role(),plan,confirmed=True)
        st.success(f"Affected {n} rows. Audit entry recorded.")
        del st.session_state[key+"_plan"]


def storage(service):
    mode=st.selectbox("Storage view",["Manifest and files","MySQL candle delete","Retention cleanup"],key="fno_storage_mode")
    if mode=="Manifest and files":
        rows=table(service,"Storage manifest","fno_storage")
        paths=[r["relative_path"] for r in rows if r["status"]=="VERIFIED"]
        if paths:
            path=st.selectbox("Inspect VERIFIED file",paths,key="fno_file_path")
            page=st.number_input("File page",1,value=1,step=1,key="fno_file_page")-1
            df,n=service.preview_parquet(path,page)
            show_rows(df,n)
        if admin_only():
            params=dates("fno_reconcile")
            submit(service,"RECONCILE",params,"Run reconcile preview","fno_reconcile_submit")
    elif mode=="MySQL candle delete":
        st.info('For coordinated SQL/Parquet cleanup and progress invalidation, use Administration → Scoped Data Cleanup.')
        st.warning("Deletes the selected MySQL candles only. Parquet and checkpoints remain; reconcile repair can restore Parquet-only rows.")
        destructive(service,"DELETE_CANDLES","fno_delete")
    elif admin_only():
        st.caption("Retention removes old FNO candle and option-chain Parquet files. MySQL and checkpoints remain.")
        if st.button("Preview cleanup files",key="fno_cleanup_preview"):
            st.session_state["fno_cleanup_files"]=service.cleanup_preview()
        files=st.session_state.get("fno_cleanup_files")
        if files is not None:
            st.write(f"Exact file count: {len(files)}");st.json(files)
            yes=st.checkbox("Confirm deletion of these files",key="fno_cleanup_confirm")
            if st.button("Apply cleanup",disabled=not yes,key="fno_cleanup_apply"):
                result=service.cleanup_execute(current_role(),files,True)
                st.success(f"Deleted {len(result)} files.")
                del st.session_state["fno_cleanup_files"]


def checkpoints(service):
    table(service,"Checkpoints","fno_checkpoints")
    st.caption("Resetting progress never deletes candle data.")
    destructive(service,"RESET_CHECKPOINTS","fno_reset")


def jobs(service):
    @st.fragment(run_every=3)
    def panel():
        _jobs_panel(service)
    panel()


def _jobs_panel(service):
    st.caption("Jobs persist across restarts. Stale jobs become INTERRUPTED and can be resumed. Continuous live jobs report heartbeat instead of an invented percentage.")
    if st.button("Refresh jobs",key="fno_jobs_refresh"):pass
    state=st.selectbox("State",["All","PENDING","RUNNING","SUCCESS","PARTIAL","FAILED","INTERRUPTED","CANCELLED","NO_DATA"],key="fno_jobs_state")
    rows=table(service,"Jobs","fno_jobs",{"state":None if state=="All" else state})
    if rows:
        jid=st.selectbox("Job detail",[r["id"] for r in rows],key="fno_job_id")
        job=next(r for r in rows if r["id"]==jid)
        cols=st.columns(3)
        cols[0].metric("State",job["state"]);cols[1].metric("Stored rows",job["rows_stored"])
        cols[2].metric("Requests made",job["requests_made"])
        st.write("Heartbeat:",str(job["heartbeat_at"]))
        for field in ("params","result"):
            if job.get(field):st.json(json.loads(job[field]) if isinstance(job[field],str) else job[field])
        if job.get("error"):st.error(job["error"])
        if admin_only():
            if job["state"] in ("PENDING","RUNNING") and st.button("Stop / cancel job",key="fno_job_cancel"):
                st.info(str(service.job_action(current_role(),"cancel",jid)))
            if job["state"] in ("INTERRUPTED","PARTIAL","FAILED") and st.button("Resume job",key="fno_job_resume"):
                st.success(str(service.job_action(current_role(),"resume",jid)))
    if admin_only() and st.button("Run pending jobs",key="fno_jobs_run"):
        st.info(str(service.job_action(current_role(),"run",0)))
    st.subheader("FNO audit log")
    table(service,"Audit log","fno_audit")


def quality(service):
    st.caption("Read-only checks record findings. Missing options minutes are NOT_VERIFIED. Repairs are separate actions.")
    params={**dates("fno_verify"),"underlyings":underlyings(service,"fno_verify"),"use_parquet":True}
    if admin_only():submit(service,"VERIFY",params,"Run verification","fno_verify_submit")
    status=st.selectbox("Result status",["All","PASS","WARNING","FAIL","NOT_VERIFIED"],key="fno_dq_status")
    table(service,"Quality results","fno_dq",{"status":None if status=="All" else status})


def settings(service):
    st.json(service.safe_settings())
    from model.fno.capabilities import capabilities
    st.write('Installed SDK data capabilities',capabilities())
    st.caption('Documented provider support and installed SDK support are separate. Unavailable methods never fall back to guessed endpoints.')
    if current_role()=='admin' and st.button('Reload FYERS credentials',key='fno_reload_auth'):
        from model.config.env_loader import load_env_config
        load_env_config(reload=True)
        service.ctx.client=service.ctx.raw_client=service.ctx.creds=None
        st.success('Credentials reloaded. The next request performs authentication.')
    st.caption("Secrets are excluded. Edit config/fno_settings.yaml locally and restart the dashboard to reload it.")
    migration_ui(service)


def migration_ui(service):
    from model.fno.migrations import plan
    if not admin_only():return
    st.write("FNO migration preview",plan())
    yes=st.checkbox("Confirm applying these migrations to the FNO database",key="fno_migrate_confirm")
    if st.button("Apply FNO migrations",disabled=not yes,key="fno_migrate_apply"):
        service.migrate(current_role(),True)
        st.success("FNO migrations applied. Refresh the page.")


def render():
    st.title("FNO Market Data")
    section=lazy_tabs(SECTIONS,"fno_section")
    try:
        with st.spinner("Loading FNO…"):
            service=get_service()
            ready=service.schema_ready()
        if not ready:
            st.warning("FNO schema is missing or needs an update. Apply the listed FNO migrations.")
            migration_ui(service)
            return
        handlers={"Overview":overview,"Option Chain":option_chain,"Futures":lambda s:contracts(s,"FUTURES"),
            "Options Contracts":lambda s:contracts(s,"OPTIONS"),"Historical Fetch":historical,"Live Data":live,
            "Aggregation":aggregation,"Storage Manager":storage,"Checkpoints":checkpoints,
            "Jobs and Logs":jobs,"Data Quality":quality,"Settings":settings}
        handlers[section](service)
    except (ValueError,PermissionError) as exc:
        st.error(str(exc))
    except Exception as exc:
        st.error(f"FNO operation unavailable ({type(exc).__name__}). Check the FNO database, migrations and job logs.")


def coverage_heatmap(service,cid,scope,category):
    from model.config.market_calendar import calendar_verified,expected_starts
    a,b=dt.date.fromisoformat(scope['from']),dt.date.fromisoformat(scope['to'])
    if a>b or (b-a).days>365:raise ValueError('Heatmap supports at most 366 days')
    rows=service.repo.query("SELECT DATE(candle_timestamp) AS day,COUNT(DISTINCT candle_timestamp) AS observed FROM fno_candles WHERE contract_id=:c AND timeframe='1m' AND status='CLOSED' AND candle_timestamp>=:a AND candle_timestamp<:b GROUP BY DATE(candle_timestamp)",{'c':cid,'a':a,'b':b+dt.timedelta(days=1)})
    observed={r['day']:r['observed'] for r in rows};data=[]
    now=dt.datetime.now(IST)
    for offset in range((b-a).days+1):
        day=a+dt.timedelta(days=offset);known=calendar_verified(day,'FNO');n=observed.get(day,0)
        expected=len(expected_starts(day,'FNO',now=now)) if known else None
        data.append({'date':day,'observed':n,'expected_session_slots':expected,'status':'NOT VERIFIED' if not known or category=='OPTIONS' else 'OBSERVED' if n else 'NO DATA'})
    df=pd.DataFrame(data)
    import plotly.graph_objects as go
    st.plotly_chart(go.Figure(go.Heatmap(x=[str(x) for x in df.date],y=[str(cid)],z=[df.observed.tolist()],colorscale='Blues',colorbar={'title':'Observed 1m'})),width='stretch')
    st.dataframe(df,hide_index=True,width='stretch')
    st.caption('Observed volume of records, including zero-data dates. Quiet option minutes and unknown listing dates are not automatically missing candles.')
