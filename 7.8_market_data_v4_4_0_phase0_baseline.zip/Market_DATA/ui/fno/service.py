"""FNO UI application service: bounded reads, role checks and audited actions."""
import dataclasses
import datetime as dt
import json

from sqlalchemy import inspect, text

from controller.fno_cli import bootstrap
from model.fno import migrations
from model.fno.aggregation import MINUTES
from model.fno.models import IST
from model.fno.release3_repository import Release3Repository, date_range

TABLES={"Contracts":"fno_instruments","Candles":"fno_candles","Option chain":"fno_option_chain_snapshots",
    "Checkpoints":"fno_checkpoint_ranges","Jobs":"fno_ingestion_jobs","Aggregation jobs":"fno_aggregation_jobs",
    "Quality results":"fno_data_quality_results","Storage manifest":"fno_storage_manifest","Audit log":"fno_audit_log"}


def require_admin(role):
    if role!="admin": raise PermissionError("Administrator access required")


class FnoService:
    def __init__(self,ctx=None):
        self.ctx=ctx or bootstrap()
        self.repo=Release3Repository(self.ctx.engine)
        self.jobs=self.ctx.jobs
        self.settings=self.ctx.settings

    def schema_ready(self):
        found=set(inspect(self.ctx.engine).get_table_names())
        return set(TABLES.values())<=found

    def migrate(self,role,confirmed=False):
        require_admin(role)
        if not confirmed: raise ValueError("Confirm the FNO migration preview first")
        result=migrations.apply_all(self.ctx.engine)
        self.audit(role,"APPLY_MIGRATIONS",{"files":[x[0] for x in result]},len(result))
        return result

    def audit(self,role,action,params,count=None,conn=None):
        sql=text("INSERT INTO fno_audit_log (actor_role,action,target,parameters,records_affected,result) "
                 "VALUES (:r,:a,'FNO',:p,:n,'success')")
        p={"r":role,"a":action,"p":json.dumps(params,default=str),"n":count}
        if conn is not None: conn.execute(sql,p)
        else:
            with self.ctx.engine.begin() as c: c.execute(sql,p)

    def safe_settings(self):
        s=dataclasses.asdict(self.settings)
        s["database"]={"name":self.ctx.dbcfg.name,"host":self.ctx.dbcfg.host,"port":self.ctx.dbcfg.port}
        return json.loads(json.dumps(s,default=str))

    def overview(self):
        contracts=self.repo.query("SELECT category,status,COUNT(*) AS rows_count FROM fno_instruments GROUP BY category,status")
        candles=self.repo.query("SELECT timeframe,source,COUNT(*) AS rows_count,MIN(candle_timestamp) AS first_ts,"
            "MAX(candle_timestamp) AS last_ts FROM fno_candles GROUP BY timeframe,source")
        jobs=self.repo.query("SELECT state,COUNT(*) AS rows_count FROM fno_ingestion_jobs GROUP BY state")
        return {"contracts":contracts,"candles":candles,"jobs":jobs}

    def browse(self,label,page=0,size=50,filters=None):
        if label not in TABLES: raise ValueError("Unsupported FNO table")
        size=min(200,max(1,int(size))); page=max(0,int(page))
        table=TABLES[label]
        allowed={"Contracts":{"underlying","category","status","expiry","option_type","strike","fyers_symbol"},"Candles":{"contract_id","timeframe","source","status"},
            "Option chain":{"underlying","chain_expiry","side","contract_id"},"Checkpoints":{"contract_id","timeframe","job_type","status"},
            "Jobs":{"state","job_type"},"Quality results":{"status","check_name"},"Storage manifest":{"dataset","status","timeframe"},
            "Aggregation jobs":{"state","target_timeframe"},"Audit log":{"action"}}[label]
        where=[];p={"l":size,"o":page*size}
        for key,value in (filters or {}).items():
            if key in ("from","to"):
                ts="candle_timestamp" if label=="Candles" else "captured_at" if label=="Option chain" else None
                if ts:
                    where.append(ts+(">=:start" if key=="from" else "<:end"))
                    p["start" if key=="from" else "end"]=str(value) if key=="from" else dt.date.fromisoformat(str(value))+dt.timedelta(days=1)
                continue
            if key not in allowed: raise ValueError("Unsupported filter")
            if value is not None and value!="":
                where.append(f"{key}=:{key}");p[key]=value
        clause=" AND ".join(where) or "1=1"
        rows=self.repo.query(f"SELECT * FROM {table} WHERE {clause} ORDER BY id DESC LIMIT :l OFFSET :o",p)
        total=self.repo.query(f"SELECT COUNT(*) AS n FROM {table} WHERE {clause}",p)[0]["n"]
        return rows,int(total)

    def preview_parquet(self,rel,page=0,size=50):
        import pyarrow.parquet as pq
        m=self.repo.manifest_get(rel)
        if not m or m["status"]!="VERIFIED": raise ValueError("Only VERIFIED manifest files can be viewed")
        path=self.ctx.store.abs_path(rel)
        if self.ctx.store.sha256(path)!=m["checksum"]: raise ValueError("File checksum differs; run verification")
        size=min(200,max(1,int(size))); start=max(0,int(page))*size
        file=pq.ParquetFile(path)
        offset=0; frames=[]; remaining=size
        for batch in file.iter_batches(batch_size=1000):
            stop=offset+batch.num_rows
            if stop>start and remaining:
                part=batch.slice(max(0,start-offset),min(remaining,stop-max(start,offset)))
                frames.append(part.to_pandas());remaining-=part.num_rows
            offset=stop
            if not remaining:break
        import pandas as pd
        return pd.concat(frames,ignore_index=True) if frames else pd.DataFrame(),file.metadata.num_rows

    def submit(self,role,kind,params):
        require_admin(role)
        allowed={"AGGREGATION","VERIFY","HISTORICAL_HARVEST","CONTRACT_SYNC","LIVE","CHAIN_SNAPSHOT","RECONCILE","WORKFLOW"}
        if kind not in allowed: raise ValueError("Unsupported job type")
        if kind=="WORKFLOW":
            from controller.unified_workflow import validate_spec
            validate_spec(params,"FNO")
        if kind in ("AGGREGATION","VERIFY","HISTORICAL_HARVEST","RECONCILE"): date_range(params)
        if kind=="AGGREGATION" and (not params.get("timeframes") or set(params["timeframes"])-set(MINUTES)):
            raise ValueError("Select valid target timeframes")
        if "underlyings" in params:
            params={**params,"underlyings":sorted(set(params["underlyings"]))}
            if not params["underlyings"]:raise ValueError("Select at least one underlying")
        jid=self.jobs.submit(kind,params)
        self.audit(role,"SUBMIT_JOB",{"job_id":jid,"type":kind})
        from ui.fno.worker import start
        start(self.ctx)
        return jid

    def job_action(self,role,action,jid):
        require_admin(role)
        if action=="cancel":result=self.jobs.request_cancel(jid)
        elif action=="resume":result=self.jobs.resume(jid)
        elif action=="run":
            from ui.fno.worker import start
            start(self.ctx);result="Worker started"
        else:raise ValueError("Unsupported job action")
        self.audit(role,"JOB_"+action.upper(),{"job_id":jid,"result":result})
        if action=="resume":
            from ui.fno.worker import start
            start(self.ctx)
        return result

    def historical_preview(self,params):
        from controller.fno_cli import ensure_fyers,_harvest_ctx
        from controller.fno_historical import fetch_atm,make_plan_from_params
        date_range(params)
        ensure_fyers(self.ctx)
        params={**params,"atm":fetch_atm(self.ctx.client,self.settings,params["underlyings"])}
        plan=make_plan_from_params(_harvest_ctx(self.ctx),params)
        limits=self.settings.rate_limits
        return params,plan.estimate(limits.per_second,limits.per_day,limits.fno_reserve_fraction),self.ctx.limiter.stats()

    def destructive_preview(self,action,cid,tf,job_type="HISTORICAL"):
        if action not in ("DELETE_CANDLES","RESET_CHECKPOINTS"):raise ValueError("Unsupported action")
        if tf not in ("1m",*MINUTES) or int(cid)<=0:raise ValueError("Select an explicit contract and timeframe")
        table="fno_candles" if action=="DELETE_CANDLES" else "fno_checkpoint_ranges"
        where="contract_id=:cid AND timeframe=:tf"
        p={"cid":int(cid),"tf":tf,"job_type":job_type}
        if action=="RESET_CHECKPOINTS": where+=" AND job_type=:job_type"
        q=self.repo.query(f"SELECT COUNT(*) AS n,MAX(updated_at) AS last_write,MAX(id) AS last_id FROM {table} WHERE {where}",p)[0]
        return {"action":action,"contract_id":int(cid),"timeframe":tf,"job_type":job_type,
                "count":int(q["n"]),"last_write":str(q["last_write"]),"last_id":q["last_id"]}

    def destructive_execute(self,role,preview,confirmed=False):
        require_admin(role)
        if not confirmed:raise ValueError("Explicit confirmation is required")
        action,cid,tf,jt=(preview[k] for k in ("action","contract_id","timeframe","job_type"))
        # Protect audit + deletion in one transaction. Lock and fingerprint every selected row
        # so changing data forces a fresh review instead of deleting an unseen larger set.
        table="fno_candles" if action=="DELETE_CANDLES" else "fno_checkpoint_ranges"
        if action not in ("DELETE_CANDLES","RESET_CHECKPOINTS"):raise ValueError("Unsupported action")
        where="contract_id=:c AND timeframe=:tf"+(" AND job_type=:jt" if action=="RESET_CHECKPOINTS" else "")
        p={"c":cid,"tf":tf,"jt":jt}
        with self.ctx.engine.begin() as conn:
            rows=conn.execute(text(f"SELECT id,updated_at FROM {table} WHERE {where} FOR UPDATE"),p).all()
            stamp=str(max((r[1] for r in rows),default=None));last=max((r[0] for r in rows),default=None)
            if len(rows)!=preview["count"] or stamp!=preview["last_write"] or last!=preview["last_id"]:
                raise ValueError("Data changed since preview; preview again")
            n=conn.execute(text(f"DELETE FROM {table} WHERE {where}"),p).rowcount
            self.audit(role,action,preview,n,conn)
        return n

    def cleanup_preview(self):
        r=self.settings.retention
        return self.ctx.store.cleanup_old_files(r.candles_1m_days,chain_retain_days=r.option_chain_days)

    def cleanup_execute(self,role,preview,confirmed=False):
        require_admin(role)
        if not confirmed:raise ValueError("Explicit confirmation is required")
        if self.cleanup_preview()!=preview:raise ValueError("Cleanup files changed; preview again")
        self.audit(role,"CLEANUP_APPROVED",{"files":preview},len(preview))
        r=self.settings.retention
        result=self.ctx.store.cleanup_old_files(r.candles_1m_days,dry_run=False,confirm=True,chain_retain_days=r.option_chain_days)
        self.audit(role,"CLEANUP_COMPLETED",{"files":result},len(result))
        return result
