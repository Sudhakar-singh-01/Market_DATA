"""Process-local executor for persisted FNO jobs; DB claims prevent duplicates."""
import threading
from controller import worker_lifecycle as lifecycle
from controller.fno_jobs import FnoJobRunner
from controller.fno_cli import worker_handlers

_lock=threading.Lock()
_threads={}


def start(c):
    lifecycle.check()
    handlers=worker_handlers(c)
    # Continuous jobs must not block finite jobs or each other.
    groups={"live":{k:v for k,v in handlers.items() if k=="LIVE"},
            "chain":{k:v for k,v in handlers.items() if k=="CHAIN_SNAPSHOT"},
            "finite":{k:v for k,v in handlers.items() if k not in ("LIVE","CHAIN_SNAPSHOT")}}
    with _lock:
        for name,group in groups.items():
            key=(str(c.engine.url),name)
            if key in _threads and _threads[key].is_alive(): continue
            runner=FnoJobRunner(c.jobs,group,c.settings.jobs.heartbeat_seconds,c.settings.jobs.stale_after_seconds)
            def work(runner=runner):
                runner.recover()
                runner.run_until_empty()
            t=threading.Thread(target=work,name="fno-ui-"+name,daemon=True)
            lifecycle.register(runner.shutdown,t)
            _threads[key]=t; t.start()
