"""
ui/session_context.py
Best-effort per-browser-session identifiers for the audit log (spec
Section 29: "IP/session information where appropriate").

Honest limits, stated once here rather than repeated everywhere:
- st.context.ip_address reflects the direct TCP peer. Behind a reverse
  proxy (nginx, a cloud load balancer, Streamlit Community Cloud) that
  is the proxy's IP, not the end user's, unless the proxy is configured
  to forward the real client IP and Streamlit is set up to trust it.
  When running locally or on a plain single-machine deployment it's the
  actual client IP.
- session_id identifies a browser tab's Streamlit session, not a person
  -- this project still has one shared password per role, so it is
  correlation/traceability, not individual identity.
"""

import uuid
from typing import Optional

import streamlit as st

_SESSION_ID_KEY = "_session_context_id"


def get_session_id() -> str:
    if _SESSION_ID_KEY not in st.session_state:
        st.session_state[_SESSION_ID_KEY] = uuid.uuid4().hex[:16]
    return st.session_state[_SESSION_ID_KEY]


def get_client_ip() -> Optional[str]:
    try:
        return st.context.ip_address
    except Exception:
        return None
