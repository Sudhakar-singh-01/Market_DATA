"""
ui/pages/3_Data_Explorer.py
Database table inspection + browsing (spec Sections 10-11). Read-only:
no SQL console, every query here is parameterized and fixed-shape.
Available to both roles (spec: "Admin and authorized users").
"""

import sys
from pathlib import Path

import streamlit as st
from ui.date_inputs import date_field

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.data_access import fetch_table, fetch_candles_filtered, KNOWN_TABLES
from ui.table_inspector import table_schema, table_indexes, table_summary
from ui.audit_log import record_action
from ui.error_display import show_error
from ui.table_display import wrapped_dataframe

st.set_page_config(page_title="Data Explorer - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()

st.sidebar.markdown(f"**Logged in as:** {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Data Explorer")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled in config/data_settings.yaml -- table inspection requires MySQL.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)
table_name = st.selectbox("Table", KNOWN_TABLES)

st.subheader("Schema")
col1, col2 = st.columns(2)
with col1:
    st.caption("Columns")
    st.dataframe(table_schema(engine, table_name), width="stretch")
with col2:
    st.caption("Indexes")
    st.dataframe(table_indexes(engine, table_name), width="stretch")

st.subheader("Summary")
summary = table_summary(engine, table_name)
cols = st.columns(4)
cols[0].metric("Row count", f"{summary['row_count']:,}")
cols[1].metric("Approx. size (MB)", summary["approx_size_mb"])
cols[2].metric("Oldest record", str(summary["oldest_record"]))
cols[3].metric("Newest record", str(summary["newest_record"]))

st.divider()
st.subheader("Browse")

if table_name == "candles":
    all_symbols = [i.internal_name for i in instruments.all_instruments()]
    all_timeframes = ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes]
    c1, c2, c3, c4 = st.columns(4)
    symbol_filter = c1.selectbox("Symbol (optional)", ["(all)"] + all_symbols)
    timeframe_filter = c2.selectbox("Timeframe (optional)", ["(all)"] + all_timeframes)
    from_date = date_field(c3, "From date (optional)")
    to_date = date_field(c4, "To date (optional)")
    limit = st.number_input("Row limit", min_value=10, max_value=5000, value=500, step=50)

    if st.button("Load") or st.session_state.pop("explorer_retry", False):
        try:
            fyers_symbol = instruments.get(symbol_filter).fyers_symbol if symbol_filter != "(all)" else None
            timeframe = None if timeframe_filter == "(all)" else timeframe_filter
            st.session_state["explorer_df"] = fetch_candles_filtered(
                engine, fyers_symbol=fyers_symbol, timeframe=timeframe,
                from_date=from_date or None, to_date=to_date or None, limit=limit,
            )
        except Exception as exc:
            st.session_state["explorer_df"] = None
            show_error("Load candles", table_name, exc, current_role(),
                      retry=lambda: (st.session_state.update(explorer_retry=True), st.rerun()))
else:
    limit = st.number_input("Row limit", min_value=10, max_value=5000, value=200, step=10)
    if st.button("Load") or st.session_state.pop("explorer_retry", False):
        try:
            st.session_state["explorer_df"] = fetch_table(engine, table_name, limit=limit)
        except Exception as exc:
            st.session_state["explorer_df"] = None
            show_error("Load table", table_name, exc, current_role(),
                      retry=lambda: (st.session_state.update(explorer_retry=True), st.rerun()))

df = st.session_state.get("explorer_df")
if df is not None and not df.empty:
    search = st.text_input("Search (any column, case-insensitive)")
    display_df = df
    if search:
        mask = df.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False)).any(axis=1)
        display_df = df[mask]

    all_columns = list(display_df.columns)
    selected_columns = st.multiselect("Columns to show", all_columns, default=all_columns)
    if selected_columns:
        display_df = display_df[selected_columns]

    # Real pagination (not just a row-limit) -- Section 32 explicitly
    # requires this rather than loading everything into the browser.
    page_size = st.selectbox("Rows per page", [25, 50, 100, 250], index=1)
    total_pages = max(1, (len(display_df) - 1) // page_size + 1)
    page = st.number_input("Page", min_value=1, max_value=total_pages, value=1, step=1)
    start = (page - 1) * page_size
    page_df = display_df.iloc[start:start + page_size]

    st.caption(f"Showing rows {start + 1}-{min(start + page_size, len(display_df))} of {len(display_df)} "
               f"(page {page}/{total_pages}) -- click column headers in the table to sort.")
    text_cols = [c for c in page_df.columns if page_df[c].dtype == object]
    wrapped_dataframe(page_df, wrap_columns=text_cols)

    exp1, exp2 = st.columns(2)
    exp1.download_button("Export CSV (current filtered set, all pages)", display_df.to_csv(index=False), file_name=f"{table_name}_export.csv",
                          on_click=record_action, args=(engine, current_role(), "EXPORT"),
                          kwargs={"target": table_name, "parameters": {"format": "csv"}, "records_affected": len(display_df)})
    exp2.download_button("Export JSON (current filtered set, all pages)", display_df.to_json(orient="records", date_format="iso"), file_name=f"{table_name}_export.json",
                          on_click=record_action, args=(engine, current_role(), "EXPORT"),
                          kwargs={"target": table_name, "parameters": {"format": "json"}, "records_affected": len(display_df)})
elif df is not None:
    st.info("No rows matched.")
