"""
ui/pages/24_Admin_Bulk_Delete.py
Bulk delete workflow (spec Section 26) -- the highest-risk admin
operation in this spec. Follows the exact required flow: select
filters -> PREVIEW DELETE (backend counts exact affected rows) ->
confirmation screen -> explicit CONFIRM DELETE -> execute via the
EXISTING admin_data_access.delete_candles_filtered -> audit log ->
show result. Never a one-click delete.
"""

import sys
from pathlib import Path

import streamlit as st
from ui.date_inputs import date_field

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role, _configured_hash
from ui.password_hashing import verify_password
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.audit_log import record_action
import ui.admin_data_access as admin
from sqlalchemy import text

st.set_page_config(page_title="Admin: Bulk Delete - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()

st.sidebar.success(f"Admin: {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Bulk Delete")
st.warning('This legacy screen deletes MySQL rows only. For coordinated SQL/Parquet cleanup and progress invalidation, use Administration → Scoped Data Cleanup. Parquet-only rows left here can be restored by reconciliation.')
st.error("DESTRUCTIVE OPERATION. Deletions cannot be undone. Follow the preview -> confirm flow -- there is no one-click delete.")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)

st.subheader("Step 1: Select filters")
all_names = [i.internal_name for i in instruments.all_instruments()]
symbol_name = st.selectbox("Instrument (required -- bulk delete cannot target all instruments at once)", all_names)
instrument = instruments.get(symbol_name)
f1, f2, f3 = st.columns(3)
timeframe = f1.selectbox("Timeframe (optional)", ["(all)", "1m"] + [tf.name for tf in timeframe_settings.derived_timeframes])
status_sel = f2.selectbox("Status (optional)", ["(all)", "CLOSED", "OPEN"])
source_sel = f3.selectbox("Source (optional)", ["(all)", "FYERS_HISTORICAL", "FYERS_LIVE"])
col1, col2 = st.columns(2)
from_date = date_field(col1, "Date from (optional)")
to_date = date_field(col2, "Date to (optional)")

filters = {
    "instrument": instrument.internal_name, "fyers_symbol": instrument.fyers_symbol,
    "timeframe": None if timeframe == "(all)" else timeframe,
    "status": None if status_sel == "(all)" else status_sel,
    "source": None if source_sel == "(all)" else source_sel,
    "from_date": from_date or None, "to_date": to_date or None,
}

st.subheader("Step 2-3: Preview")
if st.button("PREVIEW DELETE"):
    with engine.begin() as conn:
        instrument_id = conn.execute(text("SELECT id FROM instruments WHERE fyers_symbol = :fs"),
                                      {"fs": instrument.fyers_symbol}).scalar()
    if instrument_id is None:
        st.session_state["bd_pending"] = None
        st.info("This instrument has no rows in MySQL yet -- nothing to delete.")
    else:
        # Same filter builder the DELETE will use -> preview == delete scope.
        affected = admin.count_candles_filtered(
            engine, instrument_id, filters["timeframe"], filters["from_date"], filters["to_date"],
            filters["status"], filters["source"])
        st.session_state["bd_pending"] = {**filters, "instrument_id": instrument_id, "affected": affected}

pending = st.session_state.get("bd_pending")
if pending and all(pending[k] == v for k, v in filters.items()):
    st.subheader("Step 4: Confirmation")
    with st.container(border=True):
        st.write("**Table:** candles")
        st.write(f"**Instrument:** {pending['instrument']} ({pending['fyers_symbol']})")
        st.write(f"**Timeframe:** {pending['timeframe'] or 'all'}   **Status:** {pending['status'] or 'all'}   "
                 f"**Source:** {pending['source'] or 'all'}")
        st.write(f"**Date range:** {pending['from_date'] or 'earliest'} to {pending['to_date'] or 'latest'}")
        st.metric("Records affected", f"{pending['affected']:,}")

    if pending["affected"] == 0:
        st.info("No records match these filters -- nothing to delete.")
    else:
        st.subheader("Step 5-6: Confirm (explicit confirmation + admin re-authentication)")
        typed = st.text_input("Type DELETE to enable the confirm button")
        admin_pw = st.text_input("Re-enter the ADMIN password", type="password")
        c1, c2 = st.columns(2)
        if c1.button("CANCEL"):
            st.session_state["bd_pending"] = None
            st.rerun()
        if c2.button("CONFIRM DELETE", type="primary", disabled=(typed != "DELETE" or not admin_pw)):
            audit_params = {k: pending[k] for k in ("timeframe", "status", "source", "from_date", "to_date")}
            target = f"candles:{pending['fyers_symbol']}"
            if not verify_password(admin_pw, _configured_hash("admin")):
                record_action(engine, current_role(), "BULK_DELETE", target=target, parameters=audit_params,
                              result="failed", error_message="admin re-authentication failed")
                st.error("Admin password incorrect -- nothing was deleted.")
            else:
                try:
                    affected = admin.delete_candles_filtered(
                        engine, pending["instrument_id"], pending["timeframe"], pending["from_date"],
                        pending["to_date"], pending["status"], pending["source"])
                    record_action(engine, current_role(), "BULK_DELETE", target=target, parameters=audit_params,
                                  records_affected=affected, result="success")
                    st.success(f"Deleted {affected:,} record(s). Recorded in the audit log.")
                except Exception as exc:
                    record_action(engine, current_role(), "BULK_DELETE", target=target, parameters=audit_params,
                                  result="failed", error_message=str(exc))
                    st.error(f"Delete failed: {exc}")
                finally:
                    st.session_state["bd_pending"] = None
