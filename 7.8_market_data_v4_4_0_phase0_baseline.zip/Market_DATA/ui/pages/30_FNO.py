"""Single FNO entry point; rendering and operations live in ui/fno/."""
import streamlit as st
from ui.auth import require_auth
from ui.fno.page import render

st.set_page_config(page_title="FNO Market Data",layout="wide")
if not require_auth("user"):
    st.stop()
render()
