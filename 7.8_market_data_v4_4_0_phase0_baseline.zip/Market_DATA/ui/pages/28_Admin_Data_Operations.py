"""
ui/pages/28_Admin_Data_Operations.py
Spec Section 27 "Other Admin Data Operations" -- the two that had no
dedicated flow yet: Bulk Validation and Data Cleanup. Every operation
shows scope, an estimate, requires confirmation, shows progress, and
shows result + errors.

Not duplicated here (already exist elsewhere, linked instead):
Bulk export -> Data Explorer's export buttons. Bulk aggregation ->
Aggregation page. Re-fetch data -> Historical Data page (same
underlying controller; re-running for an already-synced range re-fetches
it). Checkpoint reset -> Admin: Checkpoints. Storage verification ->
Operations Center.
"""

import sys
import datetime
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, build_1m_reader, get_mysql_engine_or_none
from ui.components import instrument_selector
from ui.ux_helpers import task_guard
from ui.date_inputs import date_field
from ui.audit_log import record_action
from ui.error_display import show_error
import ui.admin_data_access as admin
from model.processing.validator import validate_candles

st.set_page_config(page_title="Admin: Data Operations - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()

st.sidebar.success(f"Admin: {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Data Operations")
st.caption("Bulk export -> Data Explorer. Bulk aggregation -> Aggregation page. Re-fetch -> Historical Data page. "
           "Checkpoint reset -> Admin: Checkpoints. Storage verification -> Operations Center.")

tab_validate, tab_cleanup = st.tabs(["Bulk Validation", "Data Cleanup"])

# ------------------------------------------------------------------ Bulk Validation (read-only, non-destructive)
with tab_validate:
    st.subheader("Scope")
    v_symbols = instrument_selector(instruments, key_prefix="bv")
    v_timeframe = st.selectbox("Timeframe", ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes], key="bv_tf")
    c1, c2 = st.columns(2)
    v_from = date_field(c1, "From date", default=str(datetime.date.today() - datetime.timedelta(days=7)), key="bv_from")
    v_to = date_field(c2, "To date", default="today", key="bv_to")

    if st.button("ESTIMATE"):
        read_1m = build_1m_reader(env, data_settings) if v_timeframe == "1m" else None
        st.session_state["bv_scope"] = {"symbols": v_symbols, "timeframe": v_timeframe, "from": v_from, "to": v_to}
        if read_1m is None:
            st.session_state["bv_estimate"] = None
            st.error("Bulk validation currently reads via the 1m reader; storage isn't enabled or timeframe isn't supported here.")
        else:
            resolved = v_symbols if v_symbols not in (["all"], ["stocks"], ["indices"]) else [i.internal_name for i in instruments.active_instruments()]
            counts = {}
            for name in resolved:
                try:
                    instrument = instruments.get(name)
                    counts[name] = len(read_1m(instrument.fyers_symbol, v_from, v_to, instrument) or [])
                except KeyError:
                    continue
            st.session_state["bv_estimate"] = counts

    scope = st.session_state.get("bv_scope")
    estimate = st.session_state.get("bv_estimate")
    if scope and estimate is not None and scope == {"symbols": v_symbols, "timeframe": v_timeframe, "from": v_from, "to": v_to}:
        st.subheader("Confirmation")
        with st.container(border=True):
            st.write(f"**Instruments:** {len(estimate)}   **Timeframe:** {v_timeframe}   **Range:** {v_from} to {v_to}")
            st.metric("Estimated candles to validate", f"{sum(estimate.values()):,}")
        if sum(estimate.values()) == 0:
            st.info("Nothing to validate for this scope.")
        elif st.button("RUN VALIDATION", type="primary"):
            read_1m = build_1m_reader(env, data_settings)
            results_rows = []
            error_details = []
            names = list(estimate.keys())
            with task_guard("Bulk validation"):
                progress = st.progress(0.0, text="Starting...")
                for i, name in enumerate(names):
                    instrument = instruments.get(name)
                    progress.progress((i) / max(len(names), 1), text=f"Validating {name}...")
                    try:
                        candles = read_1m(instrument.fyers_symbol, v_from, v_to, instrument) or []
                        checked = validate_candles(candles, instruments=instruments)
                        invalid = [r for r in checked if r.status == "invalid"]
                        warnings = [r for r in checked if r.status == "warning"]
                        results_rows.append({"Instrument": name, "Checked": len(checked), "Valid": len(checked) - len(invalid) - len(warnings),
                                             "Invalid": len(invalid), "Warnings": len(warnings), "Error": None})
                        error_details.extend({"instrument": name, "errors": r.errors} for r in invalid)
                    except Exception as exc:
                        results_rows.append({"Instrument": name, "Checked": 0, "Valid": 0, "Invalid": 0, "Warnings": 0, "Error": str(exc)})
                progress.progress(1.0, text="Done")

            st.subheader("Result")
            st.dataframe(results_rows, width="stretch")
            if error_details:
                with st.expander(f"Invalid-candle details ({len(error_details)})"):
                    st.dataframe(error_details, width="stretch")

            engine = get_mysql_engine_or_none(env, data_settings)
            if engine is not None:
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=",".join(names),
                              parameters={"op": "bulk_validation", "timeframe": v_timeframe, "from": v_from, "to": v_to},
                              records_affected=sum(r["Checked"] for r in results_rows), result="success")

# ------------------------------------------------------------------ Data Cleanup (destructive)
with tab_cleanup:
    st.warning("Removes stale OPEN candles -- rows left behind by a crashed/interrupted live session that never "
               "closed (see the Ctrl+C/shutdown-race fixes elsewhere in this project for why these can happen). "
               "CLOSED candles are never touched by this operation.")
    if not data_settings.storage.mysql_enabled:
        st.info("MySQL storage is disabled.")
    else:
        engine = get_mysql_engine_or_none(env, data_settings)
        c1, c2, c3 = st.columns(3)
        all_names = [i.internal_name for i in instruments.all_instruments()]
        dc_symbol = c1.selectbox("Instrument (optional -- blank = all)", ["(all)"] + all_names, key="dc_symbol")
        dc_timeframe = c2.selectbox("Timeframe (optional -- blank = all)", ["(all)", "1m"] + [tf.name for tf in timeframe_settings.derived_timeframes], key="dc_tf")
        dc_days = c3.number_input("Older than (days)", min_value=0, value=1, step=1, key="dc_days")
        cutoff = str(datetime.date.today() - datetime.timedelta(days=int(dc_days)))
        st.caption(f"Will target OPEN candles with a timestamp before {cutoff}.")

        if st.button("ESTIMATE ", key="dc_estimate"):
            instrument_id = None
            if dc_symbol != "(all)":
                with engine.begin() as conn:
                    from sqlalchemy import text as _text
                    instrument_id = conn.execute(_text("SELECT id FROM instruments WHERE fyers_symbol = :fs"),
                                                 {"fs": instruments.get(dc_symbol).fyers_symbol}).scalar()
            timeframe = None if dc_timeframe == "(all)" else dc_timeframe
            count = admin.count_stale_open_candles(engine, cutoff, instrument_id, timeframe)
            st.session_state["dc_pending"] = {"symbol": dc_symbol, "timeframe": dc_timeframe, "days": int(dc_days),
                                              "instrument_id": instrument_id, "count": count, "cutoff": cutoff}

        pending = st.session_state.get("dc_pending")
        if pending and pending["symbol"] == dc_symbol and pending["timeframe"] == dc_timeframe and pending["days"] == int(dc_days):
            st.subheader("Confirmation")
            with st.container(border=True):
                st.write(f"**Instrument:** {pending['symbol']}   **Timeframe:** {pending['timeframe']}   **Cutoff:** before {pending['cutoff']}")
                st.metric("Stale OPEN records affected", f"{pending['count']:,}")
            if pending["count"] == 0:
                st.info("Nothing to clean up for this scope.")
            else:
                typed = st.text_input("Type CLEANUP to enable the confirm button", key="dc_typed")
                cc1, cc2 = st.columns(2)
                if cc1.button("CANCEL", key="dc_cancel"):
                    st.session_state["dc_pending"] = None
                    st.rerun()
                if cc2.button("CONFIRM CLEANUP", type="primary", disabled=(typed != "CLEANUP"), key="dc_confirm"):
                    try:
                        affected = admin.delete_stale_open_candles(engine, pending["cutoff"], pending["instrument_id"], pending["timeframe"] if pending["timeframe"] != "(all)" else None)
                        record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{pending['symbol']}",
                                      parameters={"op": "data_cleanup", "timeframe": pending["timeframe"], "older_than": pending["cutoff"]},
                                      records_affected=affected, result="success")
                        st.success(f"Removed {affected:,} stale OPEN record(s).")
                    except Exception as exc:
                        record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{pending['symbol']}",
                                      parameters={"op": "data_cleanup"}, result="failed", error_message=str(exc))
                        show_error("Data cleanup", pending["symbol"], exc, current_role())
                    finally:
                        st.session_state["dc_pending"] = None
