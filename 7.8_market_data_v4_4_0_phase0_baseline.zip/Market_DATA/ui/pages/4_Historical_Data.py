import streamlit as st
from ui.auth import require_auth
from ui.pipeline_page import render
st.set_page_config(page_title='Historical Smart Fetch',layout='wide')
if not require_auth("user"):st.stop()
render('SMART_FETCH')
with st.expander('Gap Fill (scan stored 1m candles for missing minutes and fill them)'):
    try:
        from ui.engine_bootstrap import load_config_or_stop
        from ui.job_manager import JobContext
        from ui.job_panel import render_gapfill_panel
        env,data_settings,timeframe_settings,instruments=load_config_or_stop()
        render_gapfill_panel(JobContext(env,data_settings,timeframe_settings,instruments))
    except Exception as exc:
        st.info(f'Gap fill NOT AVAILABLE ({type(exc).__name__}).')
