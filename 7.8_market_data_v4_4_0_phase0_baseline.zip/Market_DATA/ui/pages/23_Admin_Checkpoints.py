"""
ui/pages/23_Admin_Checkpoints.py
Checkpoint manager (spec Section 15/34). Reset requires an explicit
confirmation step and is audit-logged (Section 29). Uses the EXISTING
admin_data_access.delete_checkpoint -- no new delete logic here.
"resume" = re-running historical fetch from the day after the
checkpoint's synced_through_date, using the existing historical
controller (no separate resume implementation).
"""

import sys
import datetime
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, build_sink, build_checkpoint_store, get_mysql_engine_or_none
from ui.data_access import fetch_table
from ui.audit_log import record_action
from ui.error_display import show_error
from ui.ux_helpers import task_guard
import ui.admin_data_access as admin
from model.fyers.auth import get_authenticated_client, FyersAuthError
from controller.historical_controller import run_historical_ingestion
import pandas as pd


def pd_to_date(value):
    return pd.Timestamp(value).date()

st.set_page_config(page_title="Admin: Checkpoints - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()

st.sidebar.success(f"Admin: {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Checkpoints")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled -- checkpoints require MySQL.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)

if st.button("Refresh"):
    st.rerun()

df = fetch_table(engine, "checkpoints", limit=1000)
st.dataframe(df, width="stretch")

if df.empty:
    st.stop()

st.divider()
checkpoint_id = st.selectbox("Select a checkpoint", df["id"].tolist(),
                              format_func=lambda i: f"{df[df['id']==i].iloc[0]['fyers_symbol']} [{df[df['id']==i].iloc[0]['timeframe']}]")
row = df[df["id"] == checkpoint_id].iloc[0]
st.write(f"**Symbol:** {row['fyers_symbol']}  **Timeframe:** {row['timeframe']}  **Synced through:** {row['synced_through_date']}")

action_col1, action_col2 = st.columns(2)

with action_col1:
    st.subheader("Resume")
    st.caption(f"Re-runs historical fetch from {row['synced_through_date']} + 1 day to today for this symbol.")
    if st.button("RESUME") or st.session_state.pop("cp_resume_retry", False):
        with task_guard("Resume checkpoint"):
            try:
                instrument = next(i for i in instruments.all_instruments() if i.fyers_symbol == row["fyers_symbol"])
                from_date = str(pd_to_date(row["synced_through_date"]) + datetime.timedelta(days=1))
                to_date = str(datetime.date.today())
                client = get_authenticated_client(env.fyers)
                sink = build_sink(env, data_settings, instruments)
                checkpoint_store = build_checkpoint_store(env, data_settings)
                summary = run_historical_ingestion(
                    client=client, instruments=instruments, data_settings=data_settings,
                    from_date=from_date, to_date=to_date, symbol_filter=[instrument.internal_name],
                    sink=sink, checkpoint_store=checkpoint_store, timeframe_settings=timeframe_settings,
                )
                st.success(f"Resume complete: {summary.successful}/{summary.total} succeeded")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=row["fyers_symbol"],
                              parameters={"op": "resume_checkpoint", "from": from_date, "to": to_date}, result="success")
            except FyersAuthError as exc:
                show_error("Resume checkpoint", row["fyers_symbol"], exc, current_role(),
                          retry=lambda: (st.session_state.update(cp_resume_retry=True), st.rerun()))
            except Exception as exc:
                show_error("Resume checkpoint", row["fyers_symbol"], exc, current_role(),
                          retry=lambda: (st.session_state.update(cp_resume_retry=True), st.rerun()))

with action_col2:
    st.subheader("Reset checkpoint")
    st.warning("This deletes the checkpoint row, forcing the next historical run for this symbol/timeframe to refetch from scratch instead of resuming.")
    confirm_key = f"confirm_reset_{checkpoint_id}"
    if not st.session_state.get(confirm_key):
        if st.button("RESET CHECKPOINT", type="primary"):
            st.session_state[confirm_key] = True
            st.rerun()
    else:
        st.error(f"Confirm: delete checkpoint for **{row['fyers_symbol']} [{row['timeframe']}]** "
                 f"(currently synced through {row['synced_through_date']})?")
        c1, c2 = st.columns(2)
        if c1.button("CANCEL"):
            st.session_state[confirm_key] = False
            st.rerun()
        if c2.button("CONFIRM DELETE", type="primary"):
            affected = admin.delete_checkpoint(engine, checkpoint_id)
            record_action(engine, current_role(), "RESET_CHECKPOINT", target=f"{row['fyers_symbol']}:{row['timeframe']}",
                          parameters={"checkpoint_id": int(checkpoint_id)}, records_affected=affected, result="success")
            st.session_state[confirm_key] = False
            st.success(f"Checkpoint reset ({affected} row deleted).")
            st.rerun()
