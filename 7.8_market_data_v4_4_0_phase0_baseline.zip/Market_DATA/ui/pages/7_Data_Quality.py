"""Authenticated entry point; verification never repairs source data."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.auth import require_auth
st.set_page_config(page_title='Data Quality & Verification',layout='wide')
if not require_auth("user"):st.stop()
from ui.quality_page import render
render()
