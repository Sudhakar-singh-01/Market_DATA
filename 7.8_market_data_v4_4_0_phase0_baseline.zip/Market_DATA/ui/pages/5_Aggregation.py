import streamlit as st
from ui.auth import require_auth
from ui.pipeline_page import render
st.set_page_config(page_title='Aggregation',layout='wide')
if not require_auth("user"):st.stop()
render('AGGREGATION')
