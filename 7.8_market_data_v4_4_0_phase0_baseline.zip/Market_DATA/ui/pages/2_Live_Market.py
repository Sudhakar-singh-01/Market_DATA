"""
ui/pages/2_Live_Market.py
Live Market table (real per-tick LTP/OHLC/prev-close from the running
LiveIngestionController -- see controller/live_controller.py's
latest_ticks()) plus an instrument detail view with a candlestick
chart built from stored 1m/derived candles (spec Sections 8-9).

If no live session is running, the table is empty and says so --
never fabricates a price.
"""

import sys
import datetime
from pathlib import Path

import streamlit as st
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, load_config, build_1m_reader, get_mysql_engine_or_none
from ui.data_access import live_run_manager
from ui.audit_log import record_action
from ui.ux_helpers import cached_read_candles, render_delay_panel
from ui.error_display import show_error
from ui.instrument_editor import validate_new_instrument, append_instrument
from model.fyers.auth import get_authenticated_client, FyersAuthError
from model.fyers.quotes import get_quote
from model.fyers.symbol_master import search_symbols, download_symbol_master, cache_status

st.set_page_config(page_title="Live Market - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()

st.sidebar.markdown(f"**Logged in as:** {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Live Market")


# Keep the existing live controller and storage wiring; mutations require admin.
if current_role()=='admin':
    from ui.engine_bootstrap import build_sink
    from controller.live_controller import LiveIngestionController
    from model.fyers.auth import get_authenticated_client
    selected=st.multiselect('Live instruments',[i.internal_name for i in instruments.active_instruments()],key='cash_live_symbols')
    left,right=st.columns(2)
    if left.button('Start live feed',disabled=not selected or live_run_manager.state.running):
        def factory():
            client=get_authenticated_client(env.fyers)
            return LiveIngestionController(f'{env.fyers.client_id}:{env.fyers.access_token}',instruments,data_settings,
                symbol_filter=selected,sink=build_sink(env,data_settings,instruments),historical_client=client)
        try:live_run_manager.start(factory)
        except Exception as exc:st.error(f'Live start failed ({type(exc).__name__})')
    if right.button('Stop live feed',disabled=not live_run_manager.state.running):live_run_manager.stop()
    st.caption('One account socket owner across Cash/F&O processes. Stop the active feed before switching mode.')

@st.fragment(run_every=3)
def render_live_table():
    """Isolated auto-refresh: only this table re-executes every 3s (via
    Streamlit's fragment run_every), not the whole page -- so the
    Instrument Detail search/selection below doesn't get reset every
    few seconds. If no live session is running, this simply says so;
    it never blocks the rest of the page (see fix below)."""
    state = live_run_manager.state
    if not state.running or state.controller is None:
        st.info("No live session is running. An administrator can start one using the controls above -- "
                 "Instrument Detail below still works for stored historical data either way.")
        return

    controller = state.controller
    ticks = controller.latest_ticks()  # real Tick objects, or empty dict

    rows = []
    for instrument in instruments.all_instruments():
        tick = ticks.get(instrument.fyers_symbol)
        if tick is None:
            continue
        change = None
        change_pct = None
        if tick.prev_close_price:
            change = tick.ltp - tick.prev_close_price
            change_pct = (change / tick.prev_close_price) * 100 if tick.prev_close_price else None
        age_seconds = (datetime.datetime.now(tz=tick.timestamp.tzinfo) - tick.timestamp).total_seconds()
        rows.append({
            "Symbol": instrument.internal_name,
            "Exchange": instrument.exchange,
            "Type": instrument.instrument_type,
            "Category": instrument.category,
            "LTP": tick.ltp,
            "Open": tick.open_price,
            "High": tick.high_price,
            "Low": tick.low_price,
            "Prev Close": tick.prev_close_price,
            "Change": round(change, 2) if change is not None else None,
            "Change %": round(change_pct, 2) if change_pct is not None else None,
            "Last Tick": tick.timestamp.strftime("%H:%M:%S"),
            "Feed Status": "LIVE" if age_seconds < 15 else ("STALE" if age_seconds < 60 else "ERROR"),
        })

    df = pd.DataFrame(rows)

    col1, col2, col3, col4 = st.columns(4)
    search = col1.text_input("Search symbol", key="lm_table_search")
    category_filter = col2.selectbox("Category", ["(all)", "stock", "index"], key="lm_table_cat")
    exchange_filter = col3.selectbox("Exchange", ["(all)"] + sorted(df["Exchange"].unique().tolist()) if not df.empty else ["(all)"], key="lm_table_exch")
    status_filter = col4.selectbox("Feed status", ["(all)", "LIVE", "STALE", "ERROR"], key="lm_table_status")

    filtered = df.copy()
    if not filtered.empty:
        if search:
            filtered = filtered[filtered["Symbol"].str.contains(search, case=False)]
        if category_filter != "(all)":
            filtered = filtered[filtered["Category"] == category_filter]
        if exchange_filter != "(all)":
            filtered = filtered[filtered["Exchange"] == exchange_filter]
        if status_filter != "(all)":
            filtered = filtered[filtered["Feed Status"] == status_filter]

    st.caption(f"{len(filtered)} of {len(df)} subscribed instrument(s) shown. Auto-refreshes every 3 seconds.")
    st.dataframe(filtered, width="stretch")

    render_delay_panel(controller)


render_live_table()

st.divider()
st.subheader("Instrument detail")

mode = st.radio("Look up", ["Configured instruments", "Search NSE / BSE (any symbol)"], horizontal=True)

instrument = None
adhoc_quote = None

if mode == "Configured instruments":
    st.caption("Works for ANY configured instrument, live session running or not -- search below.")
    search_text = st.text_input("Search instrument (symbol or name)")
    all_names = [i.internal_name for i in instruments.all_instruments()]
    if search_text:
        all_names = [n for n in all_names if search_text.lower() in n.lower()
                    or search_text.lower() in instruments.get(n).fyers_symbol.lower()]
    if not all_names:
        st.info("No instrument matches your search.")
        st.stop()
    selected_name = st.selectbox("Instrument", all_names)
    instrument = instruments.get(selected_name)

else:
    st.caption("Looks up ANY NSE/BSE stock or index, whether or not it's in instruments/stocks.yaml or indices.yaml. "
              "Uses FYERS's public symbol list + a live quote call.")
    status = cache_status()
    refresh_cols = st.columns(3)
    for i, (ex, info) in enumerate(status.items()):
        label = f"{ex}: " + (f"refreshed {info['age_hours']}h ago" + (" (stale)" if info["stale"] else "") if info["cached"] else "not downloaded yet")
        refresh_cols[i].caption(label)
    if refresh_cols[2].button("Refresh NSE + BSE symbol lists"):
        with st.spinner("Downloading..."):
            nse_ok = download_symbol_master("NSE", force=True)
            bse_ok = download_symbol_master("BSE", force=True)
        if nse_ok and bse_ok:
            st.success("Symbol lists refreshed.")
        else:
            st.warning("One or both downloads failed -- see the Logs page for details. "
                      "You can still look up a symbol directly below.")
        st.rerun()

    ex_filter = st.selectbox("Exchange", ["Both", "NSE", "BSE"])
    query = st.text_input("Search by name or symbol (min 2 characters)")

    chosen_symbol = None
    if query and len(query.strip()) >= 2:
        exchanges_needed = ["NSE", "BSE"] if ex_filter == "Both" else [ex_filter]
        missing = [ex for ex in exchanges_needed if not status[ex]["cached"]]
        if missing:
            # First-time use: nothing has ever been downloaded for the
            # exchange(s) being searched. Rather than silently return no
            # matches and make the person go hunt for the Refresh button,
            # download it right now, inline.
            with st.spinner(f"First-time setup: downloading {' + '.join(missing)} symbol list..."):
                download_failed = [ex for ex in missing if not download_symbol_master(ex)]
            if download_failed:
                st.error(f"Could not download the symbol list for {', '.join(download_failed)} "
                        f"(no internet access to public.fyers.in, or FYERS changed the file format). "
                        f"Check the Logs page for the exact error. You can still type an exact FYERS symbol below.")
            else:
                st.rerun()

        matches = search_symbols(query, exchange=None if ex_filter == "Both" else ex_filter)
        if matches:
            pick = st.selectbox("Matches", matches, format_func=lambda m: f"{m['fyers_symbol']} -- {m['name']}")
            chosen_symbol = pick["fyers_symbol"]
        else:
            st.info(f"No symbol matched '{query}' in the downloaded NSE/BSE list. "
                    "Double-check spelling, try the other exchange, or type an exact FYERS symbol below.")

    st.caption("Or enter an exact FYERS symbol directly (e.g. `NSE:TCS-EQ`, `BSE:RELIANCE-A`, `NSE:NIFTY50-INDEX`):")
    manual_symbol = st.text_input("FYERS symbol", value=chosen_symbol or "")

    if manual_symbol.strip():
        try:
            client = get_authenticated_client(env.fyers)
            adhoc_quote = get_quote(client, manual_symbol.strip())
        except FyersAuthError as exc:
            st.error(f"Authentication error: {exc}")
        except Exception as exc:
            show_error("Fetch quote", manual_symbol, exc, current_role(), retry=lambda: st.rerun())

        if adhoc_quote and not adhoc_quote.ok:
            st.error(f"Could not fetch a quote for `{manual_symbol}`: {adhoc_quote.error}")
        elif adhoc_quote:
            st.markdown(f"#### {adhoc_quote.name or manual_symbol}")  # full name, never truncated (st.metric() would cut long names off)
            q_cols = st.columns(3)
            q_cols[0].metric("LTP", adhoc_quote.ltp if adhoc_quote.ltp is not None else "N/A")
            q_cols[1].metric("Change", f"{adhoc_quote.change:+.2f}" if adhoc_quote.change is not None else "N/A")
            q_cols[2].metric("Change %", f"{adhoc_quote.change_pct:+.2f}%" if adhoc_quote.change_pct is not None else "N/A")
            q_cols2 = st.columns(4)
            q_cols2[0].metric("Open", adhoc_quote.open if adhoc_quote.open is not None else "N/A")
            q_cols2[1].metric("High", adhoc_quote.high if adhoc_quote.high is not None else "N/A")
            q_cols2[2].metric("Low", adhoc_quote.low if adhoc_quote.low is not None else "N/A")
            q_cols2[3].metric("Volume", adhoc_quote.volume if adhoc_quote.volume is not None else "N/A")
            st.metric("Prev Close", adhoc_quote.prev_close if adhoc_quote.prev_close is not None else "N/A")

            already_configured = manual_symbol.strip() in {i.fyers_symbol for i in instruments.all_instruments()}
            if already_configured:
                st.info("This symbol is already in your configured instruments.")
            elif current_role() != "admin":
                st.caption("Ask an admin to add this symbol to instruments/stocks.yaml or indices.yaml if you want it tracked long-term.")
            else:
                with st.expander("Add to Instruments", expanded=False):
                    guessed_category = "index" if manual_symbol.strip().endswith("-INDEX") else "stock"
                    ac1, ac2 = st.columns(2)
                    new_category = ac1.selectbox("Category", ["stock", "index"],
                                                 index=0 if guessed_category == "stock" else 1, key="add_category")
                    new_internal_name = ac2.text_input("Internal name", value=(adhoc_quote.name or manual_symbol).split()[0].upper(),
                                                       key="add_internal_name")
                    ac3, ac4 = st.columns(2)
                    new_exchange = ac3.text_input("Exchange", value=manual_symbol.strip().split(":")[0], key="add_exchange")
                    new_type = ac4.text_input("Instrument type", value="INDEX" if new_category == "index" else "EQUITY", key="add_type")
                    new_active = st.checkbox("Active", value=True, key="add_active")

                    error = validate_new_instrument(instruments, new_internal_name, manual_symbol.strip())
                    if error:
                        st.warning(error)
                    if st.button("ADD TO INSTRUMENTS", type="primary", disabled=bool(error)):
                        try:
                            append_instrument(new_category, new_internal_name, manual_symbol.strip(),
                                             new_exchange, new_type, new_active)
                            engine = get_mysql_engine_or_none(env, data_settings)
                            if engine is not None:
                                record_action(engine, current_role(), "SYSTEM_OPERATION", target=manual_symbol.strip(),
                                              parameters={"op": "add_instrument", "category": new_category, "internal_name": new_internal_name},
                                              result="success")
                            load_config.clear()  # so the new instrument shows up without a restart
                            st.success(f"Added '{new_internal_name}' ({manual_symbol.strip()}) to {new_category}s. Reloading...")
                            st.rerun()
                        except Exception as exc:
                            show_error("Add instrument", manual_symbol, exc, current_role())
    st.stop()  # ad-hoc search mode doesn't have stored candles to chart below

# Fetched fresh on every page interaction (not auto-refreshed like the
# table above -- reselecting/reloading this section always shows the
# current live tick if one exists, regardless of whether it's the same
# instrument shown in the auto-refreshing table).
live_state = live_run_manager.state
ticks = live_state.controller.latest_ticks() if live_state.running and live_state.controller else {}
timeframe = st.selectbox("Timeframe", ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes])

id_cols = st.columns(5)
id_cols[0].metric("Symbol", instrument.internal_name)
id_cols[1].metric("FYERS Symbol", instrument.fyers_symbol)
id_cols[2].metric("Exchange", instrument.exchange)
id_cols[3].metric("Type", instrument.instrument_type)
id_cols[4].metric("Status", "ACTIVE" if instrument.active else "INACTIVE")

tick = ticks.get(instrument.fyers_symbol)
detail_cols = st.columns(4)
detail_cols[0].metric("LTP", tick.ltp if tick else "N/A")
detail_cols[1].metric("Open", tick.open_price if tick else "N/A")
detail_cols[2].metric("High", tick.high_price if tick else "N/A")
detail_cols[3].metric("Low", tick.low_price if tick else "N/A")

read_1m = build_1m_reader(env, data_settings)
if read_1m is None:
    st.warning("Neither MySQL nor Parquet storage is enabled -- cannot chart historical candles.")
else:
    lookback_days = st.slider("Lookback (days)", 1, 30, 5)
    to_date = datetime.date.today()
    from_date = to_date - datetime.timedelta(days=lookback_days)
    try:
        candles = cached_read_candles(read_1m, instrument.fyers_symbol, str(from_date), str(to_date), instrument,
                                      cache_key=f"{instrument.fyers_symbol}|{from_date}|{to_date}") if timeframe == "1m" else []
        if timeframe != "1m":
            st.info("Charting derived timeframes reads from MySQL directly below (aggregation reuses the existing engine -- not recomputed here).")
        chart_df = pd.DataFrame([{
            "timestamp": c.timestamp, "open": c.open, "high": c.high, "low": c.low, "close": c.close,
            "volume": c.volume, "source": c.source, "status": c.status,
        } for c in candles]) if candles else pd.DataFrame()

        if chart_df.empty:
            st.info("No stored candles for this instrument/date range yet.")
        else:
            try:
                import plotly.graph_objects as go
                fig = go.Figure(data=[go.Candlestick(
                    x=chart_df["timestamp"], open=chart_df["open"], high=chart_df["high"],
                    low=chart_df["low"], close=chart_df["close"],
                )])
                fig.update_layout(height=450, margin=dict(l=10, r=10, t=30, b=10))
                st.plotly_chart(fig, width='stretch')
            except ImportError:
                st.warning("plotly is not installed -- run `pip install plotly` for a candlestick chart. Showing a line chart instead.")
                st.line_chart(chart_df.set_index("timestamp")["close"])

            st.caption("Latest data information")
            latest = chart_df.iloc[-1]
            freshness_min = (datetime.datetime.now() - pd.Timestamp(latest["timestamp"]).to_pydatetime().replace(tzinfo=None)).total_seconds() / 60

            # st.metric() truncates long values with "..." and never
            # wraps -- that's what was cutting off the timestamp/source
            # text. st.write() shows the full text and wraps instead.
            info_cols = st.columns(4)
            with info_cols[0]:
                st.caption("Latest candle")
                st.write(pd.Timestamp(latest["timestamp"]).strftime("%Y-%m-%d"))
                st.write(pd.Timestamp(latest["timestamp"]).strftime("%H:%M:%S"))
            with info_cols[1]:
                st.caption("Source / Status")
                st.write(f"**{latest['source']}**")
                st.write(latest["status"])
            with info_cols[2]:
                st.caption("Data freshness")
                st.write(f"{freshness_min:.1f} min ago" if freshness_min < 1440 else f"{freshness_min / 1440:.1f} days ago")
            with info_cols[3]:
                st.caption("Volume")
                if instrument.category == "index":
                    st.write("N/A")
                    st.caption("(index -- no traded volume)")
                else:
                    st.write(f"{int(latest['volume']):,}")
    except Exception as exc:
        st.error(f"Could not load candles: {exc}")
