import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.auth import require_auth,current_role,_configured_hash
from ui.password_hashing import verify_password
from model.recovery_config import configured_verifier
from ui.recovery_page import render_page

st.set_page_config(page_title='Recovery Verification · TIOS',layout='wide')
if not require_auth("admin"):
    st.stop()

@st.cache_resource
def service():
    return configured_verifier()

try:
    render_page(service(),current_role(),lambda password:verify_password(password,_configured_hash('admin')))
except (ValueError,PermissionError) as exc:
    st.error(str(exc))
except Exception as exc:
    st.error(f'Recovery verification unavailable ({type(exc).__name__}). Check RECOVERY_DB settings. No import was performed.')
