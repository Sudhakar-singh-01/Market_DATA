"""Browse every table in the tool's configured databases, with bounded reads."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import pandas as pd
import streamlit as st
from ui.auth import require_auth
from model.database_catalog import configured_catalog
from model.read_contracts import ReadRequestError

st.set_page_config(page_title='Database Catalog · TIOS', layout='wide')
if not require_auth("admin"):
    st.stop()

st.title('Database Catalog')
st.caption('Cash and F&O remain separate. Existing Operations, Checkpoints and F&O pages handle guarded changes.')


@st.cache_resource
def get_catalog():
    return configured_catalog()


try:
    catalog = get_catalog()
    st.dataframe(catalog.databases(), hide_index=True, width='stretch')
    if not catalog.factories:
        st.info('Configure DB_NAME/DB_USER and FNO_DB_NAME/FNO_DB_USER first.')
        st.stop()
    segment = st.selectbox('Database segment', list(catalog.factories))
    names = catalog.table_names(segment)
    if not names:
        st.info('No tables found. Use the existing explicit migration workflow.')
        st.stop()
    table = st.selectbox('Table', names)
    schema = catalog.schema(segment, table)
    with st.expander('Columns, keys and indexes'):
        st.json(schema)
    filters = {}
    column = st.selectbox('Equality filter column', ['(none)']+[c['name'] for c in schema['columns']])
    if column != '(none)':
        filters[column] = st.text_input('Exact value')
    limit = st.selectbox('Rows per page', [50, 100, 200, 1000])
    offset = st.number_input('Row offset', min_value=0, max_value=100000, step=limit)
    if st.button('Count matching rows'):
        st.metric('Exact row count', catalog.count(segment, table, filters))
    page = catalog.rows(segment, table, limit=limit, offset=int(offset), filters=filters)
    frame = pd.DataFrame(page['data'])
    st.dataframe(frame, hide_index=True, width='stretch')
    st.caption(f"Returned {len(frame)} rows · Next offset: {page['meta']['next_offset']} · Counts are calculated on demand.")
    st.download_button('Export displayed page', frame.to_csv(index=False), f'{segment}_{table}_page.csv', 'text/csv')
except ReadRequestError as exc:
    st.error(str(exc))
except Exception as exc:
    st.error(f'Database catalog unavailable ({type(exc).__name__}). Check database configuration and connectivity.')
