import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.auth import require_auth,current_role,_configured_hash
from ui.password_hashing import verify_password
from model.database_catalog import configured_catalog
from model.cleanup_service import CleanupService
from ui.cleanup_page import render_page

st.set_page_config(page_title='Scoped Data Cleanup · TIOS',layout='wide')
if not require_auth("admin"):
    st.stop()

@st.cache_resource
def service():
    return CleanupService(configured_catalog())

try:
    render_page(service(),current_role(),lambda password:verify_password(password,_configured_hash('admin')))
except Exception as exc:
    st.error(f'Cleanup configuration unavailable ({type(exc).__name__}).')
