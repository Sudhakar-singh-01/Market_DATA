"""Admin entry point for unified workflow creation and monitoring."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.auth import require_auth,current_role
from ui.workflow_service import WorkflowDashboardService
from ui.workflow_page import render_page

st.set_page_config(page_title='Unified Workflow · TIOS',layout='wide')
if not require_auth("admin"):
    st.stop()

@st.cache_resource
def get_service():
    return WorkflowDashboardService()

render_page(get_service(),current_role())
