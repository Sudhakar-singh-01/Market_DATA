"""
ui/pages/27_Admin_Security.py
Security posture summary (spec Section 30). Shows real configured
values, not a marketing checklist -- and is honest about the auth
model's actual limits (documented in ui/auth.py's module docstring).
"""

import sys
import os
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role, _configured_hash

st.set_page_config(page_title="Admin: Security - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()

st.sidebar.success(f"Admin: {current_role()}")
if st.sidebar.button("Log out"):
    logout()
    st.rerun()

st.title("Admin: Security")

st.subheader("Current configuration")
cols = st.columns(2)
cols[0].metric("Password hashing", "PBKDF2-SHA256, 200k iterations")
cols[1].metric("Session timeout (min)", os.getenv("SESSION_TIMEOUT_MINUTES", "480"))
cols2 = st.columns(2)
cols2[0].metric("USER password configured", "YES" if _configured_hash("user") else "NO")
cols2[1].metric("ADMIN password configured", "YES" if _configured_hash("admin") else "NO")

st.subheader("Enforced rules")
st.markdown("""
- Passwords are never stored in plaintext (`config/.env` holds only PBKDF2 hashes).
- Backend-enforced role gates: every page under `ui/pages/2_*` through `9_*` calls
  `require_auth("user")`; every page under `ui/pages/2*_Admin_*` calls `require_auth("admin")`
  as the FIRST line of the page, before any data access -- this is not just a hidden sidebar link.
- Failed-login lockout: 5 wrong attempts locks that browser session out for 5 minutes.
- Bulk delete and checkpoint reset require an explicit typed/clicked confirmation step and are audit-logged.
- No FYERS credentials, `.env` contents, or tokens are ever rendered anywhere in the UI.
- No unrestricted SQL console exists (see Data Explorer / Admin: Database -- fixed-shape queries only).
- File Explorer is restricted to a directory whitelist with path-traversal rejection (see `ui/file_explorer.py`).
""")

st.subheader("Known limitations (stated honestly, not hidden)")
st.warning("""
- This is a **single shared password per role**, not per-individual accounts -- there is no user
  identity beyond "user" or "admin" in the audit log's `actor_role` column.
- Failed-login lockout state lives in Streamlit's `session_state`, so it resets per browser session --
  it is not a durable, cross-session rate limit against a determined attacker.
- No FastAPI/HTTP layer exists yet, so there are no API-level auth tokens to manage (see API Monitor page).
""")
