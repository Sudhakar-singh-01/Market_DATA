"""Master overview over existing tables/config; no duplicate masters."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import dataclasses
import datetime as dt
import pandas as pd
import streamlit as st
from sqlalchemy import inspect,text
from ui.auth import require_auth,current_role
from ui.ux_helpers import lazy_tabs
from model.config.market_calendar import calendar_metadata,get_holidays,today_ist
st.set_page_config(page_title='Master Tables',layout='wide')
if not require_auth("user"):st.stop()
st.title('Master Tables')
st.caption('Existing instrument identities and configuration sources · no inferred metadata')
section=lazy_tabs(['Cash instruments','F&O contracts','Timeframes & exchanges','Trading calendar'],'master_section')
try:
    if section=='Trading calendar':
        st.json(calendar_metadata());st.dataframe([{'date':d,'name':n} for d,n in get_holidays().items()])
        st.info('Unknown special-session times and unverified years stay NOT VERIFIED. Update the reviewed calendar explicitly.')
    elif section=='F&O contracts':
        from ui.fno.page import get_service,contracts
        service=get_service()
        category=st.selectbox('Category',['FUTURES','OPTIONS'])
        contracts(service,category)
        st.caption('Cash IDs and FNO contract IDs are independent. Underlying relationships use configured broker symbols.')
    else:
        from ui.quality_page import get_service
        service=get_service()
        if section=='Timeframes & exchanges':
            st.dataframe([dataclasses.asdict(t) for t in service.timeframes.derived_timeframes])
            st.dataframe(service.reader.query('SELECT exchange,instrument_type,COUNT(*) AS records FROM instruments GROUP BY exchange,instrument_type'))
            st.caption('Timeframes come from configuration; exchanges shown are distinct stored fields, not a new master table.')
        else:
            rows=service.reader.query('SELECT * FROM instruments ORDER BY id LIMIT 5001')
            if len(rows)>5000:st.warning('Showing first 5000 records. Refine through Data Explorer.');rows=rows[:5000]
            configured={i.fyers_symbol:i for i in service.instruments.all_instruments()}
            for r in rows:
                i=configured.get(r['fyers_symbol'])
                r['metadata_status']='UNCONFIGURED' if not i else 'MATCH' if all(str(r[k])==str(getattr(i,k)) for k in ('internal_name','exchange','instrument_type','category')) and bool(r['is_active'])==i.active else 'DRIFT'
            present={r['fyers_symbol'] for r in rows}
            missing=[dataclasses.asdict(i) for s,i in configured.items() if s not in present]
            count=service.reader.query('SELECT COUNT(*) AS n FROM instruments')[0]['n']
            st.metric('Instrument records',count);st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
            if missing:st.warning('Configured instruments missing from DB');st.dataframe(missing)
            if rows:st.download_button('Export displayed master rows',pd.DataFrame(rows).to_csv(index=False),'cash-master.csv')
            if current_role()=='admin':
                from model.master_management import sync_preview,apply_sync
                preview=sync_preview(service.engine,service.instruments)
                with st.expander('Review YAML → MySQL metadata sync'):st.json(preview)
                yes=st.checkbox('Confirm this reviewed metadata sync (no instrument deletion)')
                if st.button('Apply metadata sync',disabled=not yes):
                    st.success(str(apply_sync(service.engine,service.instruments,preview,current_role(),True)));st.rerun()
except (ValueError,PermissionError) as exc:st.error(str(exc))
except Exception as exc:st.error(f'Master data unavailable ({type(exc).__name__}). Counts and status are NOT AVAILABLE.')
