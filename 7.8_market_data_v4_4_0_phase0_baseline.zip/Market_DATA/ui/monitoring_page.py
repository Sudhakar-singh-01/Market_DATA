import datetime as dt
import json
import pandas as pd
import streamlit as st
from model.config.market_calendar import today_ist
from ui.date_inputs import date_field


def render_monitoring(service):
    st.subheader('Live Feed & Persistence')
    day=date_field(st,'Telemetry date',default='today',key='telemetry_date')
    rows=service.store.query('SELECT * FROM pipeline_events WHERE occurred_at>=:a AND occurred_at<:b ORDER BY id DESC LIMIT 5000',
        {'a':day,'b':dt.date.fromisoformat(day)+dt.timedelta(days=1)})
    st.caption('Cash pipeline telemetry. Tick reception does not prove SQL or Parquet persistence. No telemetry means NOT VERIFIED.')
    if not rows:st.info('No persisted telemetry for this date. Monitoring starts after metadata migration and ingestion restart.');return
    if len(rows)==5000:st.warning('Showing the latest 5000 events; statistics apply only to these displayed observations.')
    columns=st.columns(3)
    for col,kind in zip(columns,('TICK_RECEIVED','SQL_COMMIT','PARQUET_COMMIT')):
        selected=[r for r in rows if r['kind']==kind]
        col.metric(kind,str(selected[0]['occurred_at']) if selected else 'NOT VERIFIED')
    delays=[]
    for row in rows:
        d=row['details']
        if isinstance(d,str):d=json.loads(d)
        if 'delay_seconds' in d:delays.append({'at':row['occurred_at'],'sink':row['kind'],'delay_seconds':d['delay_seconds'],'symbol':row['symbol']})
    if delays:
        df=pd.DataFrame(delays)
        st.dataframe(df.groupby('sink').delay_seconds.agg(['count','mean','max',lambda s:s.quantile(.95)]).rename(columns={'<lambda_0>':'p95'}))
        st.line_chart(df.pivot_table(index='at',columns='sink',values='delay_seconds',aggfunc='max'))
    st.caption('Delay is measured from candle end to an acknowledged commit. Reception samples are throttled to one per symbol/30 seconds; they are not total tick counts. Disconnections have separate events.')
    frame=pd.DataFrame(rows);frame['details']=frame.details.map(lambda d:json.dumps(d,default=str))
    st.dataframe(frame,hide_index=True,width='stretch')
    st.download_button('Export telemetry CSV',frame.to_csv(index=False),'telemetry.csv')
