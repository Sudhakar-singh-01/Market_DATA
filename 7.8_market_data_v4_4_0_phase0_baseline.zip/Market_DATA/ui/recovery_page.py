"""Review recovery checks separately from live cutover or data-quality readiness."""
import json
import streamlit as st
from model.recovery_config import staged_recoveries
from model.schema_management import _digest


def render_page(service,role,authenticate):
    if role!='admin':
        st.error('Administrator access required')
        return
    st.title('Recovery Verification')
    st.caption('Checks a manually imported recovery database and its staged files. This screen never imports SQL, starts workers or replaces live storage.')
    target=service.recovery_engine.url
    st.write({'host':target.host,'port':target.port,'database':target.database})
    st.info('First stage a trusted backup in Backup & Recovery. Manually import its database.sql into a new empty tios_recovery_ database using an account restricted to that database. Keep the recovery copy idle. Setup: docs/RECOVERY_VERIFICATION.md.')
    stages=staged_recoveries(service.backup_service,role=role)
    if not stages:
        st.info('No staged recovery copies found. Open Backup & Recovery → Verify & stage recovery first.')
        return
    recovery_id=st.selectbox('Staged recovery',stages,key='recovery_stage')
    backup_id=recovery_id[:32]
    st.write({'backup_id':backup_id,'recovery_id':recovery_id})
    key=_digest({'target':str(target.render_as_string(hide_password=True)),'stage':recovery_id})[:16]
    expected='VERIFY '+target.database
    imported=st.checkbox('I imported this backup into this isolated recovery database and stopped its writers',key='recovery_imported_'+key)
    typed=st.text_input('Type '+expected,key='recovery_confirm_'+key)
    password=st.text_input('Admin password',type='password',key='recovery_password_'+key)
    if st.button('Verify recovery copy',key='recovery_verify',disabled=not (imported and typed==expected and password)):
        st.session_state.pop('recovery_report',None)
        if not authenticate(password):
            st.error('Admin password incorrect. Verification did not start.')
            return
        try:
            with st.spinner('Comparing full SQL data, foreign keys and staged file checksums...'):
                result=service.verify(backup_id,recovery_id,role=role,confirmation=typed)
            st.session_state['recovery_report']=(key,result)
        except Exception as exc:
            st.error(f'Verification unavailable ({type(exc).__name__}). Check local recovery configuration. No import was performed.')
    report=st.session_state.get('recovery_report')
    if report and report[0]==key:
        result=report[1]
        st.json(result)
        if result['status']=='VERIFIED':
            st.success('Reported SQL/file recovery checks passed. This does not authorize live cutover or certify market-data parity.')
        else:
            st.error('Recovery checks did not pass. Keep the original backup and live stores unchanged; inspect the reported failed check.')
        st.download_button('Download recovery report',json.dumps(result,indent=2,default=str),'recovery_report.json','application/json')
