"""
ui/password_hashing.py
PBKDF2-SHA256 password hashing, stdlib only -- deliberately has NO
Streamlit dependency so tools/hash_password.py can run without
installing the dashboard's full requirements first.
"""

import hashlib
import hmac
import os
from typing import Optional


def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    """Returns 'salt_hex$hash_hex'."""
    if salt is None:
        salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split("$", 1)
    except ValueError:
        return False  # malformed config value -- fail closed
    salt = bytes.fromhex(salt_hex)
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return hmac.compare_digest(candidate.hex(), digest_hex)
