"""Runnable consumer integration examples; no code executes on import."""
