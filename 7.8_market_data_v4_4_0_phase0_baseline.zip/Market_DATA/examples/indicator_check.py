"""Historical SMA calculation integration harness, not production event wiring."""
import argparse
import getpass
import json
from client import MarketDataClient
from client.consumer import load_verified_batch
from indicators.sma import Sma


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date', required=True)
    parser.add_argument('--segment', choices=['CASH','FNO'], default='CASH')
    parser.add_argument('--symbol', default='NSE:SBIN-EQ')
    parser.add_argument('--period', type=int, default=20)
    args = parser.parse_args()
    calculator = Sma(args.period)
    with MarketDataClient(username='admin',password=getpass.getpass('Tool admin password: '),
                          timeout=120,max_retries=0) as client:
        batch = load_verified_batch(client,args.segment,args.symbol,'1m',args.date,args.date,page_size=200)
    # The entire input must succeed before the first computation begins.
    outputs=[]
    for candle in batch.candles:
        output=calculator.update(candle.timestamp,candle.close)
        if output is not None: outputs.append(output)
    print(json.dumps(dict(status='SMA_REPLAY_COMPLETE' if outputs else 'WARMUP_ONLY',
        segment=batch.segment,symbol=batch.symbol,session=batch.session,indicator='SMA_CLOSE_V1',period=args.period,
        input_rows=len(batch.candles),warmup_rows=min(len(batch.candles),args.period-1),output_rows=len(outputs),
        first_output_candle=outputs[0].candle_timestamp.isoformat() if outputs else None,
        last_value=str(outputs[-1].value) if outputs else None,
        scope='Read-only historical calculation harness. Candle timestamps are starts; values available after close. No production event bus, strategy or trading run.')))


if __name__=='__main__': main()
