"""GET-only consumer adapter check; no indicator engine or storage changes."""
import argparse
import getpass
import json
from client import MarketDataClient
from client.consumer import load_verified_batch


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--segment', choices=['CASH','FNO'], default='CASH')
    p.add_argument('--symbol', default='NSE:SBIN-EQ')
    p.add_argument('--date', required=True)
    args = p.parse_args()
    with MarketDataClient(username='admin', password=getpass.getpass('Tool admin password: '),
                          timeout=120, max_retries=0) as client:
        batch = load_verified_batch(client,args.segment,args.symbol,'1m',args.date,args.date,page_size=200)
    print(json.dumps(dict(status='CONSUMER_BATCH_READY',segment=batch.segment,symbol=batch.symbol,
        rows=len(batch.candles),pages=batch.pages,session=batch.session,
        first=batch.candles[0].timestamp.isoformat(),last=batch.candles[-1].timestamp.isoformat(),
        numeric_type='Decimal',scope='Complete adapter input; live view, not atomic snapshot. No indicator engine run.')))


if __name__ == '__main__':
    main()
