"""Run from the repository root: python -m examples.read_verified_candles.

Requires a running local read API and MARKET_DATA_API_PASSWORD.
Change the symbol/dates to historical data you have already fetched and verified.
"""
from decimal import Decimal
from client import MarketDataClient


def main():
    count=0
    with MarketDataClient.from_env() as client:
        for page in client.iter_candle_pages('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16'):
            # Feed your indicator/backtest only after its own full-input policy succeeds.
            print('Quality:',page['quality'])
            for row in page['data']:
                close=Decimal(str(row['close']))
                count+=1
                if count==1: print('First candle:',row['candle_timestamp'],'close:',close)
    print('Completed rows:',count)


if __name__=='__main__': main()
