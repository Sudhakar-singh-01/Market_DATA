"""
view/console_view.py
Presentation-only output. No business logic, no data transformation --
just formats results that controllers already computed. Kept separate
so future output formats (JSON, a future GUI, etc.) don't require
touching controller logic.
"""

from controller.historical_controller import HistoricalBatchSummary


def print_startup_banner(active_stocks: int, active_indices: int, base_timeframe: str):
    print("=" * 60)
    print("FYERS Market Data Engine")
    print(f"Active stocks: {active_stocks}   Active indices: {active_indices}")
    print(f"Base timeframe: {base_timeframe}")
    print("=" * 60)


def print_historical_summary(summary: HistoricalBatchSummary):
    print()
    print(f"Historical ingestion: {summary.successful}/{summary.total} instrument(s) succeeded, "
          f"{summary.failed} failed")
    for r in summary.results:
        if r.status == "failed":
            print(f"  [FAILED]   {r.fyers_symbol}: {r.error}")
        else:
            derived_str = f" derived={r.derived_counts}" if getattr(r, "derived_counts", None) else ""
            print(f"  [{r.status.upper():8s}] {r.fyers_symbol}: raw={r.raw_count} valid={r.valid_count} "
                  f"invalid={r.invalid_count} warnings={r.warning_count}{derived_str}")


def print_timeframe_summary(summary):
    print()
    total = len(summary.results)
    successful = sum(1 for r in summary.results if r.status == "success")
    print(f"Timeframe aggregation: {successful}/{total} instrument-timeframe combination(s) succeeded")
    for r in summary.results:
        if r.status == "failed":
            print(f"  [FAILED]   {r.fyers_symbol} [{r.timeframe}]: {r.error}")
        else:
            print(f"  [{r.status.upper():8s}] {r.fyers_symbol} [{r.timeframe}]: "
                  f"source_1m={r.source_1m_count} derived={r.derived_count} valid={r.valid_count}")


def print_live_starting(instrument_count: int):
    print()
    print(f"Live ingestion starting for {instrument_count} instrument(s). Press Ctrl+C to stop.")


def print_live_status(controller):
    """controller: a LiveIngestionController. Presentation-only --
    reads the same counters view/api_view.get_live_connection_status()
    exposes, just formatted for the console instead of JSON."""
    print()
    print(f"Subscribed instruments : {controller.subscribed_instrument_count}")
    print(f"Ticks received          : {controller._received_count}")
    print(f"1m candles closed       : {controller._closed_1m_count}")
    print(f"Derived candles closed  : {controller._closed_derived_count}")
