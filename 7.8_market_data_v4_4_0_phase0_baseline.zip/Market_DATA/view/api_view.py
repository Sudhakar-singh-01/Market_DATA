"""
view/api_view.py
Clean, application-level service functions for future frontend
integration (spec Section 26). Deliberately NOT coupled to FYERS --
every function here takes already-constructed application objects
(InstrumentRegistry, a Reader for candle data) as parameters, never a
FYERS client. A future web framework (FastAPI/Flask/etc.) can wrap
these functions directly as endpoint handlers.
"""

import datetime
from dataclasses import dataclass
from typing import Callable, Optional

from model.config.instrument_loader import InstrumentRegistry


@dataclass
class InstrumentSummary:
    internal_name: str
    fyers_symbol: str
    exchange: str
    instrument_type: str
    category: str
    active: bool


@dataclass
class CandleView:
    fyers_symbol: str
    timeframe: str
    timestamp: str  # ISO 8601
    open: float
    high: float
    low: float
    close: float
    volume: int
    status: str


@dataclass
class HealthStatus:
    ok: bool
    checked_at: str
    details: dict


def list_instruments(instruments: InstrumentRegistry, active_only: bool = False) -> list:
    source = instruments.active_instruments() if active_only else instruments.all_instruments()
    return [
        InstrumentSummary(
            internal_name=i.internal_name, fyers_symbol=i.fyers_symbol, exchange=i.exchange,
            instrument_type=i.instrument_type, category=i.category, active=i.active,
        )
        for i in source
    ]


def get_historical_candles(
    read_candles_fn: Callable,
    fyers_symbol: str,
    timeframe: str,
    from_date: str,
    to_date: str,
) -> list:
    """
    read_candles_fn: e.g. ParquetCandleSink(...).read_candles or a
    MySQL-backed equivalent -- signature (fyers_symbol, timeframe,
    from_date, to_date) -> list[Candle]. This function does not care
    which storage backend it came from.
    """
    candles = read_candles_fn(fyers_symbol, timeframe, from_date, to_date)
    return [_to_candle_view(c) for c in candles]


def get_latest_candle(read_candles_fn: Callable, fyers_symbol: str, timeframe: str) -> Optional[CandleView]:
    today = datetime.date.today().isoformat()
    candles = read_candles_fn(fyers_symbol, timeframe, today, today)
    if not candles:
        return None
    latest = max(candles, key=lambda c: c.timestamp)
    return _to_candle_view(latest)


def get_ingestion_status(summary) -> dict:
    """Accepts a HistoricalBatchSummary (controller/historical_controller.py)
    or TimeframeBatchSummary (controller/timeframe_controller.py) and
    returns a plain-dict view suitable for JSON serialization."""
    return {
        "total": len(summary.results),
        "successful": sum(1 for r in summary.results if r.status == "success"),
        "failed": sum(1 for r in summary.results if r.status == "failed"),
        "results": [
            {"fyers_symbol": r.fyers_symbol, "status": r.status, "error": getattr(r, "error", None)}
            for r in summary.results
        ],
    }


def get_live_connection_status(controller) -> dict:
    """Accepts a LiveIngestionController (controller/live_controller.py)."""
    return {
        "subscribed_instruments": controller.subscribed_instrument_count,
        "ticks_received": controller._received_count,
        "closed_1m_candles": controller._closed_1m_count,
        "closed_derived_candles": controller._closed_derived_count,
    }


def health_check(instruments: InstrumentRegistry) -> HealthStatus:
    ok = bool(instruments.active_instruments())
    return HealthStatus(
        ok=ok,
        checked_at=datetime.datetime.now().isoformat(),
        details={
            "active_stocks": len(instruments.active_stocks()),
            "active_indices": len(instruments.active_indices()),
        },
    )


def _to_candle_view(candle) -> CandleView:
    return CandleView(
        fyers_symbol=candle.fyers_symbol, timeframe=candle.timeframe,
        timestamp=candle.timestamp.isoformat(),
        open=candle.open, high=candle.high, low=candle.low, close=candle.close,
        volume=candle.volume, status=candle.status,
    )
