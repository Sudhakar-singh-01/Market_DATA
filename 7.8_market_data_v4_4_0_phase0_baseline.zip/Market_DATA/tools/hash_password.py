"""
tools/hash_password.py
Generate a PBKDF2-SHA256 password hash for config/.env
(USER_PASSWORD_HASH / ADMIN_PASSWORD_HASH). Never store plaintext
passwords in config -- this is the only supported way to set them.

Usage:
    python tools/hash_password.py "your-password-here"
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ui.password_hashing import hash_password  # noqa: E402


def main():
    if len(sys.argv) != 2:
        print("Usage: python tools/hash_password.py \"your-password-here\"")
        sys.exit(1)
    password = sys.argv[1]
    print(hash_password(password))


if __name__ == "__main__":
    main()
