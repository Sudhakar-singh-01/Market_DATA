-- Run this ONCE against your market_data database (safe to re-run: IF NOT EXISTS).
-- Alternative to the 'Create audit_log table' button on the Admin: Audit Log page.
CREATE TABLE IF NOT EXISTS audit_log (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actor_role          VARCHAR(20)     NOT NULL,
    action              VARCHAR(40)     NOT NULL,
    target              VARCHAR(100)    NULL,
    parameters          TEXT            NULL,
    records_affected    INT UNSIGNED    NULL,
    result              VARCHAR(20)     NOT NULL,
    error_message       TEXT            NULL,
    ip_address          VARCHAR(45)     NULL,
    session_id          VARCHAR(32)     NULL,
    INDEX idx_occurred_at (occurred_at),
    INDEX idx_action (action)
) ENGINE=InnoDB;

-- If you created audit_log BEFORE this update, add the two new columns:
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS ip_address VARCHAR(45) NULL;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS session_id VARCHAR(32) NULL;
