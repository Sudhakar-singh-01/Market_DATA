-- FNO-only audit: never writes Subsystem A's audit table.
CREATE TABLE IF NOT EXISTS fno_audit_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actor_role VARCHAR(20) NOT NULL,
    action VARCHAR(40) NOT NULL,
    target VARCHAR(200) NULL,
    parameters JSON NULL,
    records_affected BIGINT UNSIGNED NULL,
    result VARCHAR(20) NOT NULL,
    INDEX idx_fno_audit_time (occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
