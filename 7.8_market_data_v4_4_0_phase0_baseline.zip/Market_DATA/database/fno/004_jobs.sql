-- database/fno/004_jobs.sql
-- Persisted jobs. State lives in the database (with a heartbeat), so a restart cannot lose it.

CREATE TABLE IF NOT EXISTS fno_ingestion_jobs (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_type         VARCHAR(40)     NOT NULL,                    -- HISTORICAL_HARVEST | CONTRACT_SYNC | CHAIN_SNAPSHOT | RECONCILE ...
    params           JSON            NOT NULL,
    dedupe_key       CHAR(64)        NOT NULL,                    -- sha256(job_type + canonical params)
    active_key       CHAR(64)        NULL,                        -- = dedupe_key while PENDING/RUNNING, else NULL
    state            VARCHAR(16)     NOT NULL DEFAULT 'PENDING',  -- PENDING|RUNNING|PARTIAL|SUCCESS|NO_DATA|FAILED|CANCELLED|INTERRUPTED
    created_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at       DATETIME        NULL,
    finished_at      DATETIME        NULL,
    heartbeat_at     DATETIME        NULL,                        -- refreshed while RUNNING; stale => INTERRUPTED on start-up
    cancel_requested TINYINT(1)      NOT NULL DEFAULT 0,          -- honoured after the current contract
    resumed_from     BIGINT UNSIGNED NULL,                        -- id of the INTERRUPTED job this one resumes
    requests_made    INT UNSIGNED    NOT NULL DEFAULT 0,          -- FYERS REST calls issued by this job (incl. retries)
    rows_raw         BIGINT UNSIGNED NOT NULL DEFAULT 0,          -- candle rows returned by FYERS, before validation
    rows_valid       BIGINT UNSIGNED NOT NULL DEFAULT 0,          -- rows that passed validation
    rows_invalid     BIGINT UNSIGNED NOT NULL DEFAULT 0,          -- rows rejected by validation (reported, never stored)
    rows_stored      BIGINT UNSIGNED NOT NULL DEFAULT 0,          -- rows newly inserted or filled in MySQL
    rows_duplicate   BIGINT UNSIGNED NOT NULL DEFAULT 0,          -- valid rows already stored with identical values
    no_data_count    INT UNSIGNED    NOT NULL DEFAULT 0,          -- requested ranges FYERS answered with no candles
    retry_count      INT UNSIGNED    NOT NULL DEFAULT 0,          -- retries after transient errors (429/network/timeout)
    error            TEXT            NULL,
    result           JSON            NULL,
    UNIQUE KEY uq_fno_job_active (active_key),                    -- DB-enforced duplicate prevention (NULLs may repeat)
    INDEX idx_fno_job_state (state, created_at),
    INDEX idx_fno_job_dedupe (dedupe_key),
    CONSTRAINT chk_fno_job_state CHECK (state IN
        ('PENDING','RUNNING','PARTIAL','SUCCESS','NO_DATA','FAILED','CANCELLED','INTERRUPTED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fno_aggregation_jobs (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_timeframe    VARCHAR(10)     NOT NULL,
    target_timeframe    VARCHAR(10)     NOT NULL,
    contract_selection  JSON            NOT NULL,
    source_from         DATE            NOT NULL,
    source_to           DATE            NOT NULL,
    output_from         DATE            NULL,
    output_to           DATE            NULL,
    input_rows          BIGINT UNSIGNED NOT NULL DEFAULT 0,
    output_rows         BIGINT UNSIGNED NOT NULL DEFAULT 0,
    skipped_intervals   BIGINT UNSIGNED NOT NULL DEFAULT 0,       -- buckets not built because source minutes were missing
    state               VARCHAR(16)     NOT NULL DEFAULT 'PENDING',
    verification_result JSON            NULL,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at          DATETIME        NULL,
    finished_at         DATETIME        NULL,
    heartbeat_at        DATETIME        NULL,
    error               TEXT            NULL,
    INDEX idx_fno_agg_state (state, created_at),
    CONSTRAINT chk_fno_agg_state CHECK (state IN
        ('PENDING','RUNNING','PARTIAL','SUCCESS','NO_DATA','FAILED','CANCELLED','INTERRUPTED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
