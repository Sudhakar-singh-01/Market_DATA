-- database/fno/006_fix_exchange_codes.sql
-- The first symbol-master parser stored the master's numeric exchange CODE ("10") instead of the exchange name.
-- Idempotent: affects only rows still holding the numeric code. NSE's FYERS code is 10 (symbols are all "NSE:...").
UPDATE fno_instruments SET exchange = 'NSE' WHERE exchange = '10';
