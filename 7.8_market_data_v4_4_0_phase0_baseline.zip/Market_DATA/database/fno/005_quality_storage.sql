-- database/fno/005_quality_storage.sql

CREATE TABLE IF NOT EXISTS fno_data_quality_results (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    check_name  VARCHAR(80)     NOT NULL,
    scope       VARCHAR(200)    NOT NULL,
    status      VARCHAR(16)     NOT NULL,                         -- PASS|WARNING|FAIL|NOT_VERIFIED|RUNNING
    details     JSON            NULL,
    run_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fno_dq_check (check_name, run_at),
    CONSTRAINT chk_fno_dq_status CHECK (status IN ('PASS','WARNING','FAIL','NOT_VERIFIED','RUNNING'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Parquet manifest. Readers use ONLY rows with status VERIFIED.
CREATE TABLE IF NOT EXISTS fno_storage_manifest (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    relative_path   VARCHAR(400)    NOT NULL,                     -- relative to the FNO Parquet root
    dataset         VARCHAR(30)     NOT NULL,                     -- candles | option_chain
    timeframe       VARCHAR(10)     NULL,
    partition_key   VARCHAR(200)    NOT NULL,                     -- e.g. underlying=NIFTY/expiry=2026-11-26/date=2026-10-19
    min_timestamp   DATETIME        NULL,
    max_timestamp   DATETIME        NULL,
    row_count       BIGINT UNSIGNED NOT NULL DEFAULT 0,
    schema_version  INT UNSIGNED    NOT NULL DEFAULT 1,
    checksum        CHAR(64)        NULL,                         -- sha256 of the final file
    status          VARCHAR(12)     NOT NULL,                     -- WRITING | VERIFIED | QUARANTINED
    job_id          BIGINT UNSIGNED NULL,
    note            VARCHAR(300)    NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_fno_manifest_path (relative_path),
    INDEX idx_fno_manifest_scope (dataset, timeframe, status),
    CONSTRAINT chk_fno_manifest_status CHECK (status IN ('WRITING','VERIFIED','QUARANTINED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
