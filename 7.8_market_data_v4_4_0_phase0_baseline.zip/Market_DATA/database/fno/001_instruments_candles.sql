-- database/fno/001_instruments_candles.sql
-- FNO contract master + candles. Idempotent. Applied ONLY by `main.py fno-migrate --apply`
-- (or the admin-confirmed dashboard button) against the FNO database -- never Subsystem A's.
-- Timestamps are Asia/Kolkata wall-clock, period start (same convention as Subsystem A).

CREATE TABLE IF NOT EXISTS fno_instruments (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fyers_symbol    VARCHAR(80)     NOT NULL,                    -- real FYERS symbol; never constructed
    fytoken         VARCHAR(40)     NULL,
    underlying      VARCHAR(40)     NOT NULL,                    -- from symbol-master field, not parsed from the name
    exchange        VARCHAR(10)     NOT NULL,
    category        VARCHAR(10)     NOT NULL,                    -- FUTURES | OPTIONS
    expiry          DATE            NOT NULL,
    strike          DECIMAL(14,4)   NULL,                        -- NULL for futures
    option_type     CHAR(2)         NULL,                        -- CE | PE, NULL for futures
    lot_size        INT UNSIGNED    NULL,
    tick_size       DECIMAL(10,4)   NULL,
    status          VARCHAR(10)     NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE | EXPIRED (rows are kept forever)
    first_seen_at   DATETIME        NOT NULL,
    last_seen_at    DATETIME        NOT NULL,
    source          VARCHAR(40)     NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_fno_fyers_symbol (fyers_symbol),
    INDEX idx_fno_inst_scope (underlying, category, expiry, status),
    INDEX idx_fno_inst_status_expiry (status, expiry),
    CONSTRAINT chk_fno_inst_category CHECK (category IN ('FUTURES','OPTIONS')),
    CONSTRAINT chk_fno_inst_status CHECK (status IN ('ACTIVE','EXPIRED')),
    CONSTRAINT chk_fno_inst_option CHECK (category = 'FUTURES' OR (strike IS NOT NULL AND option_type IN ('CE','PE')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fno_candles (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    contract_id      BIGINT UNSIGNED NOT NULL,
    timeframe        VARCHAR(10)     NOT NULL,                   -- 1m, 5m, 15m, 30m, 1h, 1d
    candle_timestamp DATETIME        NOT NULL,                   -- IST wall-clock, period start
    open             DECIMAL(18,4)   NOT NULL,
    high             DECIMAL(18,4)   NOT NULL,
    low              DECIMAL(18,4)   NOT NULL,
    close            DECIMAL(18,4)   NOT NULL,
    volume           BIGINT UNSIGNED NOT NULL DEFAULT 0,
    oi               BIGINT          NULL,                       -- NULL = unknown (never 0 for unknown)
    iv               DECIMAL(12,6)   NULL,
    delta            DECIMAL(14,8)   NULL,
    gamma            DECIMAL(14,8)   NULL,
    theta            DECIMAL(14,8)   NULL,
    vega             DECIMAL(14,8)   NULL,
    source           VARCHAR(24)     NOT NULL,                   -- FYERS_HISTORICAL | FYERS_LIVE | AGGREGATED
    status           VARCHAR(10)     NOT NULL DEFAULT 'CLOSED',  -- OPEN | CLOSED
    created_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fno_candles_contract FOREIGN KEY (contract_id) REFERENCES fno_instruments(id),
    UNIQUE KEY uq_fno_contract_tf_ts (contract_id, timeframe, candle_timestamp),
    INDEX idx_fno_candles_tf_ts (timeframe, candle_timestamp),
    CONSTRAINT chk_fno_candle_status CHECK (status IN ('OPEN','CLOSED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
