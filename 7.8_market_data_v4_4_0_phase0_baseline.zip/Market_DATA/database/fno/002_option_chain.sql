-- database/fno/002_option_chain.sql
-- One row per contract per snapshot. FYERS returns only the CURRENT chain and no capture
-- time, so captured_at is OUR clock (IST). A historical chain exists only for snapshots
-- this system captured itself.

CREATE TABLE IF NOT EXISTS fno_option_chain_snapshots (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    batch_id      VARCHAR(40)     NOT NULL,                      -- one id per snapshot call
    underlying    VARCHAR(40)     NOT NULL,
    captured_at   DATETIME        NOT NULL,                      -- our clock, IST
    chain_expiry  DATE            NOT NULL,
    contract_id   BIGINT UNSIGNED NOT NULL,
    strike        DECIMAL(14,4)   NOT NULL,
    side          CHAR(2)         NOT NULL,                      -- CE | PE
    ltp           DECIMAL(18,4)   NULL,
    bid           DECIMAL(18,4)   NULL,
    ask           DECIMAL(18,4)   NULL,
    volume        BIGINT          NULL,
    oi            BIGINT          NULL,
    oi_change     BIGINT          NULL,
    iv            DECIMAL(12,6)   NULL,
    delta         DECIMAL(14,8)   NULL,
    gamma         DECIMAL(14,8)   NULL,
    theta         DECIMAL(14,8)   NULL,
    vega          DECIMAL(14,8)   NULL,
    source        VARCHAR(24)     NOT NULL DEFAULT 'FYERS_OPTIONCHAIN',
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fno_chain_contract FOREIGN KEY (contract_id) REFERENCES fno_instruments(id),
    UNIQUE KEY uq_fno_chain_batch_contract (batch_id, contract_id),
    INDEX idx_fno_chain_underlying_ts (underlying, captured_at),
    INDEX idx_fno_chain_contract_ts (contract_id, captured_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
