-- database/fno/003_progress.sql
-- Range-based progress. A maximum timestamp alone never proves completeness.

CREATE TABLE IF NOT EXISTS fno_checkpoint_ranges (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    contract_id   BIGINT UNSIGNED NOT NULL,
    job_type      VARCHAR(30)     NOT NULL,                      -- HISTORICAL | AGGREGATION | ...
    timeframe     VARCHAR(10)     NOT NULL,
    range_from    DATE            NOT NULL,                      -- inclusive calendar day
    range_to      DATE            NOT NULL,                      -- inclusive calendar day
    status        VARCHAR(24)     NOT NULL,                      -- VERIFIED | NO_DATA | FAILED | EXPIRED_UNRECOVERABLE
    verified_at   DATETIME        NULL,
    retry_count   INT UNSIGNED    NOT NULL DEFAULT 0,
    last_error    VARCHAR(500)    NULL,
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fno_ckpt_contract FOREIGN KEY (contract_id) REFERENCES fno_instruments(id),
    INDEX idx_fno_ckpt_key (contract_id, job_type, timeframe, range_from),
    CONSTRAINT chk_fno_ckpt_order CHECK (range_from <= range_to),
    CONSTRAINT chk_fno_ckpt_status CHECK (status IN ('VERIFIED','NO_DATA','FAILED','EXPIRED_UNRECOVERABLE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per active contract; drives the harvest queue (soonest expiry first).
CREATE TABLE IF NOT EXISTS fno_harvest_state (
    contract_id          BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    expiry               DATE            NOT NULL,
    last_harvested_date  DATE            NULL,
    next_due             DATE            NULL,
    priority             INT             NOT NULL,                -- days to expiry when last planned (lower = sooner)
    status               VARCHAR(16)     NOT NULL DEFAULT 'PENDING', -- PENDING | UP_TO_DATE | FAILED | EXPIRED
    updated_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fno_harvest_contract FOREIGN KEY (contract_id) REFERENCES fno_instruments(id),
    INDEX idx_fno_harvest_queue (status, priority, expiry)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
