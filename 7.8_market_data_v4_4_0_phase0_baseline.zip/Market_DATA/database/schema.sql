-- ============================================================
-- database/schema.sql
-- FYERS Market Data Engine -- MySQL schema (Part 3)
-- Apply once manually (DBA/human step): the application never creates
-- or modifies schema itself (model/storage/mysql.py only reads/writes
-- rows against these tables).
-- ============================================================

CREATE DATABASE IF NOT EXISTS market_data
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE market_data;

-- ------------------------------------------------------------
-- instruments
-- Canonical reference record for every stock/index configured in
-- instruments/stocks.yaml / instruments/indices.yaml. Mirrors, but
-- does not replace, the YAML files -- YAML remains the source of
-- truth for WHICH instruments are configured; this table exists so
-- candles can reference a stable numeric instrument_id instead of
-- repeating the fyers_symbol string on every candle row.
-- ------------------------------------------------------------
CREATE TABLE instruments (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    internal_name       VARCHAR(50)     NOT NULL,
    fyers_symbol        VARCHAR(80)     NOT NULL,
    exchange            VARCHAR(20)     NOT NULL,
    instrument_type     VARCHAR(20)     NOT NULL,
    category            VARCHAR(10)     NOT NULL,   -- 'stock' | 'index'
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_internal_name (internal_name),
    UNIQUE KEY uq_fyers_symbol (fyers_symbol),
    INDEX idx_category_active (category, is_active)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- candles
-- Single table for ALL timeframes (1m, 5m, 15m, 30m, 1h, 1d), rather
-- than one table per timeframe. Rationale: identical schema across
-- timeframes, and most real queries filter by
-- (instrument_id, timeframe, candle_timestamp) regardless of which
-- timeframe -- a single well-indexed table avoids six near-identical
-- tables and six near-identical repository code paths. If a single
-- table's row count becomes a genuine performance problem at your
-- data volume, MySQL native partitioning BY LIST (timeframe) can be
-- added later without changing the logical schema.
--
-- status ('OPEN'|'CLOSED') persists whether a candle was still forming
-- when written (spec Section 13) -- primarily relevant for the live
-- path's most-recent candle; historical candles are always CLOSED.
-- ------------------------------------------------------------
CREATE TABLE candles (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    instrument_id       BIGINT UNSIGNED NOT NULL,
    timeframe           VARCHAR(10)     NOT NULL,   -- '1m','5m','15m','30m','1h','1d'
    candle_timestamp    DATETIME        NOT NULL,   -- Asia/Kolkata wall-clock, period start
    open                DECIMAL(14,4)   NOT NULL,
    high                DECIMAL(14,4)   NOT NULL,
    low                 DECIMAL(14,4)   NOT NULL,
    close               DECIMAL(14,4)   NOT NULL,
    volume              BIGINT UNSIGNED NOT NULL DEFAULT 0,
    source              VARCHAR(20)     NOT NULL,   -- 'FYERS_HISTORICAL' | 'FYERS_LIVE'
    status              VARCHAR(10)     NOT NULL DEFAULT 'CLOSED',  -- 'OPEN' | 'CLOSED'
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_candles_instrument FOREIGN KEY (instrument_id) REFERENCES instruments(id),

    -- CANDLE IDENTITY (spec Section 5): instrument + timeframe +
    -- timestamp, enforced at the database level, not just application-
    -- side. INSERT IGNORE relies on this constraint (model/storage/mysql.py).
    UNIQUE KEY uq_instrument_tf_ts (instrument_id, timeframe, candle_timestamp),

    -- Query pattern coverage (spec Section 6):
    --   instrument + timeframe + timestamp -> covered by the UNIQUE KEY above
    --   instrument + timestamp (any timeframe)              -> idx_instrument_ts
    --   timeframe + timestamp (any instrument)               -> idx_tf_ts
    INDEX idx_instrument_ts (instrument_id, candle_timestamp),
    INDEX idx_tf_ts (timeframe, candle_timestamp)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- checkpoints
-- Resume/backfill support (spec Section 6, Part 2's CheckpointStore
-- interface). One row per (fyers_symbol, timeframe) tracking the last
-- date confirmed durably persisted.
-- ------------------------------------------------------------
CREATE TABLE checkpoints (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fyers_symbol        VARCHAR(80)     NOT NULL,
    timeframe           VARCHAR(10)     NOT NULL,
    synced_through_date DATE            NOT NULL,
    updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_symbol_timeframe (fyers_symbol, timeframe)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- ingestion_jobs
-- Lightweight job/run history (spec Section 28: "avoid creating
-- unnecessary tables" -- this is deliberately ONE simple table, not a
-- full job-scheduling system). One row per historical_controller /
-- timeframe_controller run, recording what was requested and the
-- resulting counts.
-- ------------------------------------------------------------
CREATE TABLE ingestion_jobs (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_type            VARCHAR(20)     NOT NULL,   -- 'historical' | 'timeframe' | 'live_session'
    fyers_symbol        VARCHAR(80)     NULL,       -- NULL for a whole-batch summary row
    timeframe           VARCHAR(10)     NULL,
    from_date           DATE            NULL,
    to_date             DATE            NULL,
    status              VARCHAR(20)     NOT NULL,   -- 'success' | 'failed' | 'no_data' | 'partial'
    raw_count           INT UNSIGNED    NULL,
    valid_count         INT UNSIGNED    NULL,
    invalid_count       INT UNSIGNED    NULL,
    error_message       TEXT            NULL,
    started_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at         DATETIME        NULL,

    INDEX idx_job_type_started (job_type, started_at),
    INDEX idx_symbol_started (fyers_symbol, started_at)
) ENGINE=InnoDB;

-- Deliberately NOT created: a per-candle validation-error log table.
-- Per-candle validation errors are already logged with full context
-- (model/processing/validator.py callers log warnings) and are high-
-- volume, low-long-term-value data -- persisting every individual
-- validation warning in MySQL was judged not justified (spec Section
-- 28: "avoid creating unnecessary tables"). ingestion_jobs.invalid_count
-- gives the aggregate signal; full detail lives in the log files.

-- ------------------------------------------------------------
-- audit_log
-- Append-only record of admin/destructive actions (dashboard Section
-- 29 requirement: LOGIN/LOGOUT/BULK_DELETE/RESET_CHECKPOINT/etc.).
-- Application code only INSERTs and SELECTs here -- never UPDATE/DELETE.
-- Never stores passwords, tokens, or API secrets (enforced by callers
-- in ui/audit_log.py, not by this schema).
-- ------------------------------------------------------------
CREATE TABLE audit_log (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actor_role          VARCHAR(20)     NOT NULL,   -- 'user' | 'admin'
    action              VARCHAR(40)     NOT NULL,   -- 'LOGIN' | 'BULK_DELETE' | 'RESET_CHECKPOINT' | ...
    target              VARCHAR(100)    NULL,       -- e.g. table name, symbol, checkpoint id
    parameters          TEXT            NULL,       -- JSON-encoded scope/filters (no secrets)
    records_affected    INT UNSIGNED    NULL,
    result              VARCHAR(20)     NOT NULL,   -- 'success' | 'failed' | 'cancelled'
    error_message       TEXT            NULL,
    ip_address          VARCHAR(45)     NULL,       -- best-effort; proxy IP if behind one (see ui/session_context.py)
    session_id          VARCHAR(32)     NULL,       -- browser-session correlation, not an individual identity

    INDEX idx_occurred_at (occurred_at),
    INDEX idx_action (action)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- error_logs
-- WARNING/ERROR/CRITICAL log records, mirrored from the file logger so
-- they can be queried/filtered without opening the log file. INFO/DEBUG
-- stay file-only (mirroring every tick-level INFO line would add a DB
-- write per log call, which is unacceptable on the live-ticks hot path).
-- Append-only: application code only INSERTs and SELECTs here.
-- ------------------------------------------------------------
CREATE TABLE error_logs (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at  DATETIME(3)     NOT NULL,
    level        VARCHAR(10)     NOT NULL,   -- WARNING | ERROR | CRITICAL
    module       VARCHAR(200)    NOT NULL,
    message      TEXT            NOT NULL,

    INDEX idx_occurred_at (occurred_at),
    INDEX idx_level (level)
) ENGINE=InnoDB;
