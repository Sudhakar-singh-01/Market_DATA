-- Run this ONCE against your market_data database (safe to re-run: IF NOT EXISTS).
-- Alternative to the "Create error_logs table now" button on the Logs page.
CREATE TABLE IF NOT EXISTS error_logs (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    occurred_at  DATETIME(3)     NOT NULL,
    level        VARCHAR(10)     NOT NULL,
    module       VARCHAR(200)    NOT NULL,
    message      TEXT            NOT NULL,
    INDEX idx_occurred_at (occurred_at),
    INDEX idx_level (level)
) ENGINE=InnoDB;
