"""Read-only backend checks. Never submits jobs, repairs storage or calls providers."""
import argparse
import json
from pathlib import Path, PureWindowsPath


def storage_report(catalog, *, offline=False, page_size=500):
    from model.storage_scope import validate_storage_roots
    layout = validate_storage_roots(catalog.roots)
    report = {'layout': layout, 'directories': {}, 'manifest': {
        'status': 'SKIPPED_OFFLINE' if offline else 'PENDING',
        'complete': False, 'parity_verified': False}}
    for segment, item in layout.items():
        root = Path(item['root'])
        names = ('raw', 'processed') if segment == 'CASH' else ('candles', 'option_chain')
        report['directories'][segment] = {'root_exists': root.is_dir(),
                                         **{name: (root / name).is_dir() for name in names}}
    if offline:
        report['status'] = 'CONFIGURATION_ONLY'
        return report, 0
    if 'FNO' not in layout:
        raise ValueError('FNO storage root unavailable')
    from sqlalchemy import select
    table = catalog.table('FNO', 'fno_storage_manifest')
    root = Path(layout['FNO']['root'])
    checked = missing = invalid = 0
    samples, invalid_samples = [], []
    last = None
    # Keyset pages cover the entire manifest without loading candle contents.
    with catalog.engine('FNO').connect() as conn:
        while True:
            query = select(table.c.relative_path).order_by(table.c.relative_path).limit(page_size)
            if last is not None:
                query = query.where(table.c.relative_path > last)
            rows = list(conn.execute(query).scalars())
            if not rows:
                break
            for rel in rows:
                checked += 1
                path = Path(str(rel))
                unsafe = (not isinstance(rel, str) or not rel or path.is_absolute()
                          or bool(PureWindowsPath(str(rel)).drive) or '\\' in str(rel)
                          or '..' in path.parts or path.as_posix() != str(rel))
                candidate = root / path
                if not unsafe:
                    unsafe = any(p.is_symlink() or getattr(p, 'is_junction', lambda: False)()
                                 for p in (candidate, *candidate.parents) if p != root.parent)
                    unsafe = unsafe or not candidate.resolve().is_relative_to(root)
                if unsafe:
                    invalid += 1
                    if len(invalid_samples) < 10:
                        invalid_samples.append('Unsafe manifest path (value withheld)')
                elif not candidate.is_file():
                    missing += 1
                    if len(samples) < 10:
                        samples.append(rel)
            last = rows[-1]
    report['manifest'] = {'status': 'FINDINGS' if missing or invalid else 'PASS',
        'complete': True, 'checked_count': checked, 'missing_count': missing,
        'invalid_path_count': invalid, 'missing_samples': samples,
        'invalid_samples': invalid_samples, 'parity_verified': False,
        'scope': 'Manifest path safety and file existence only; no checksum, rows or SQL/Parquet parity verification. Concurrent writes may change results.'}
    report['missing_roots'] = [segment for segment, dirs in report['directories'].items() if not dirs['root_exists']]
    report['status'] = 'FINDINGS' if missing or invalid or report['missing_roots'] else 'PASS'
    return report, 2 if report['status'] == 'FINDINGS' else 0


# Keep diagnostic values narrow: arbitrary persisted errors and provider strings
# are deliberately excluded even for authenticated administrators.
_NUMERIC_FIELDS = set("done total rows_checked PASS WARNING FAIL NOT_VERIFIED rows invalid duplicates expected observed missing sql_only parquet_only value_mismatches stored sql_rows parquet_rows stored_rows expected_rows raw_count valid_count invalid_count database_present yaml_matches_database calendar_verified claimed exists".split())
_CONTAINER_FIELDS = {'checks', 'parquet_integrity'}


def diagnostic_values(value):
    if isinstance(value, str):
        if len(value) > 1024 * 1024:
            return {'details_omitted': True}
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            return {}
    if not isinstance(value, dict):
        return {}
    out = {k: v for k, v in value.items()
           if k in _NUMERIC_FIELDS and isinstance(v, (int, float, bool))}
    for key in _CONTAINER_FIELDS:
        if isinstance(value.get(key), dict):
            out[key] = diagnostic_values(value[key])
    # These fixed application messages explain common NOT_VERIFIED outcomes.
    reasons = {'Parquet comparison disabled', 'partition row bound exceeded',
               'Invalid base candles',
               'Stored candles alone do not prove tick reception or successful live persistence; inspect telemetry'}
    if value.get('reason') in reasons:
        out['reason'] = value['reason']
    elif value.get('reason') or value.get('error'):
        out['error_detail_withheld'] = True
    return out


def job_report(catalog, segment, job_id):
    from sqlalchemy import select, func
    from model.market_read_service import MarketReadService
    report = MarketReadService(catalog).get_job_status(segment, job_id)
    jobs = catalog.table(segment, 'ingestion_jobs' if segment == 'CASH' else 'fno_ingestion_jobs')
    with catalog.engine(segment).connect() as conn:
        if 'result' in jobs.c:
            result = conn.execute(select(jobs.c.result).where(jobs.c.id == job_id)).scalar_one()
            report['diagnostic_result'] = diagnostic_values(result)
        if segment == 'CASH':
            if 'data_quality_results' not in catalog.table_names(segment):
                report['findings'] = {'complete': False, 'status': 'TABLE_UNAVAILABLE'}
                return report
            table = catalog.table(segment, 'data_quality_results')
            predicate = table.c.job_id == job_id
            count = conn.execute(select(func.count()).select_from(table).where(predicate)).scalar_one()
            # Show failures/warnings before PASS entries, while retaining stable id order.
            query = select(table).where(predicate).order_by((table.c.status == 'PASS'), table.c.id).limit(100)
            rows = []
            for row in conn.execute(query).mappings():
                rows.append({'id': row['id'], 'check_name': str(row['check_name'])[:80],
                             'scope': str(row['scope'])[:240], 'status': str(row['status'])[:16],
                             'details': diagnostic_values(row['details'])})
            report['findings'] = {'total_count': count, 'returned_count': len(rows),
                                  'truncated': count > len(rows), 'complete': count <= len(rows),
                                  'data': rows, 'detail_scope': 'Allowlisted counts, booleans and fixed reasons; raw errors and arbitrary text omitted.'}
    return report


def parser():
    from model.timeframes import TIMEFRAMES
    result = argparse.ArgumentParser(description=__doc__)
    sub = result.add_subparsers(dest='command', required=True)
    storage = sub.add_parser('storage', help='Inspect configured roots and FNO manifest file existence')
    storage.add_argument('--offline', action='store_true', help='Skip authentication and database checks; configuration only')
    preview = sub.add_parser('fetch-preview', help='Preview CASH fetch without submission or provider requests')
    preview.add_argument('--segment', choices=['CASH'], required=True)
    preview.add_argument('--from', dest='date_from', required=True)
    preview.add_argument('--to', dest='date_to', required=True)
    preview.add_argument('--symbols', nargs='+', required=True)
    job = sub.add_parser('job', help='Read persisted job status')
    job.add_argument('--segment', choices=['CASH', 'FNO'], required=True)
    job.add_argument('--id', type=int, required=True)
    inv = sub.add_parser('inventory', help='Bounded historical SQL/Parquet counts and timestamp keys; no provider or writes')
    inv.add_argument('--segment', choices=['CASH', 'FNO'], required=True)
    inv.add_argument('--from', dest='date_from', required=True)
    inv.add_argument('--to', dest='date_to', required=True)
    inv.add_argument('--symbols', nargs='+')
    inv.add_argument('--contract-ids', type=int, nargs='+')
    inv.add_argument('--underlyings', nargs='+')
    inv.add_argument('--timeframes', nargs='+', choices=TIMEFRAMES)
    inv.add_argument('--output', type=Path, help='New .json report; never overwrites an existing file')
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        from model.read_contracts import ReadRequestError
        if args.command == 'inventory' and args.output:
            if args.output.suffix.lower() != '.json' or args.output.exists():
                raise ReadRequestError('Choose a new .json output file')
        if not (args.command == 'storage' and args.offline):
            from controller.workflow_cli import authenticate_admin
            authenticate_admin()
        if args.command == 'storage':
            from model.database_catalog import configured_catalog
            report, code = storage_report(configured_catalog(), offline=args.offline)
        elif args.command == 'fetch-preview':
            from controller.market_data_service import MarketDataService
            report = MarketDataService().preview_fetch(args.segment, {
                'from': args.date_from, 'to': args.date_to,
                'symbols': [s for arg in args.symbols for s in arg.split(',') if s]}, role='admin')
            code = 2 if report.get('plan', {}).get('blocked') else 0
        elif args.command == 'inventory':
            from model.database_catalog import configured_catalog
            from model.data_inventory import inventory_report
            from model.timeframes import TIMEFRAMES
            report = inventory_report(configured_catalog(), args.segment, args.date_from, args.date_to,
                symbols=args.symbols, contract_ids=args.contract_ids, underlyings=args.underlyings,
                timeframes=args.timeframes or TIMEFRAMES)
            code = 0 if report['status'] == 'SCOPED_INVENTORY_PASS' else 2
            if args.output:
                # Exclusive create: the operator's earlier report remains intact.
                with args.output.open('x', encoding='utf-8') as stream:
                    json.dump(report, stream, indent=2, default=str)
                report = {k: report[k] for k in ('status','complete','segment','from','to','summary','values_verified')}
                report['report'] = str(args.output.absolute())
        else:
            from model.database_catalog import configured_catalog
            report = job_report(configured_catalog(), args.segment, args.id)
            code = 0
        print(json.dumps(report, default=str))
        return code
    except Exception as exc:
        from model.pipeline_errors import FetchPreflightError
        from model.read_contracts import ReadRequestError
        if args.command == 'inventory' and isinstance(exc, ReadRequestError):
            print(json.dumps({'status': 'INVALID_SCOPE', 'complete': False, 'message': str(exc)}))
            return 2
        if isinstance(exc, FetchPreflightError):
            print(json.dumps({'status': 'BLOCKED', 'blocked': exc.blocked}, default=str))
            return 2
        print(json.dumps({'status': 'UNAVAILABLE', 'complete': False,
            'error': type(exc).__name__,
            'message': 'Check admin authentication, storage roots and selected database configuration/access. No changes were made; no successful database check is claimed.'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
