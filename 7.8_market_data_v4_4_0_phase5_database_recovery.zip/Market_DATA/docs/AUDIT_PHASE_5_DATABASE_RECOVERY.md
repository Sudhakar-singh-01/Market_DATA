# Audit Phase 5 — database maintenance and recovery verification

Phase 5 hardens the existing backup/recovery boundary. It does not add automatic
live restore, change migration SQL or reset either configured database.

`tios-backup-v1` manifests are parsed with duplicate-key rejection and strict
types for database identity, table counts, member byte counts, SHA-256 values,
creation time and restore status. Recovery staging refuses a symlinked destination
root and verifies the extracted inventory and hashes from disk before reporting
`STAGED_ONLY`. A failed check removes the incomplete new staging folder.

Existing migration safeguards remain unchanged: preview-bound allowlisted SQL,
database identity checks, advisory locking, verified-backup acknowledgment and a
flushed statement journal. MySQL DDL is still not claimed to be transactional.
Existing recovery verification still requires a manually imported, separate
`tios_recovery_*` database and performs exact schema and typed row-multiset checks.

## Optional Windows checks

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_backup_service.py tests\test_schema_management.py tests\test_schema_compatibility.py tests\test_recovery_verification.py tests\test_schema_dashboard.py tests\test_cleanup_service.py
```

Expected: no failures. The opt-in MySQL recovery drill must use disposable test
databases and a test account allowed to create and drop only its temporary recovery
database. Never point `FNO_TEST_DB_*` variables at production.
