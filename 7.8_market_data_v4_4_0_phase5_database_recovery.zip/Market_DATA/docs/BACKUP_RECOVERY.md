# Step 3: SQL + Parquet backup and recovery staging

Open Admin → Backup & Recovery. This feature exports one configured segment at a
time: Cash and FNO remain separate. It does not fetch data or consume FYERS quota.

## Create a backup

1. Stop historical/live ingestion, jobs, aggregation, schema changes, and every
   other process writing SQL or the configured Parquet root. Leave writers stopped
   until the backup finishes. The acknowledgment does not stop workers for you.
2. Select CASH or FNO and preview. Review the database, tables, data root and file
   size estimate. SQL export size is additional and is not estimated.
3. Confirm writers are stopped and create the backup. This synchronous operation
   may take time; keep the app/session running and allow enough free disk space.
4. Retain the returned archive path and SHA-256 separately. Completed archives
   appear as backups/<id>.zip. Interrupted operations never publish a completed ZIP;
   after a process crash, review/remove only abandoned hidden work/partial files.

Each archive contains:

- database.sql: schema and all rows from all visible base tables in that database,
  including jobs, checkpoints, audit/quality metadata and user-added tables.
- parquet/: every regular file under that segment's configured data root, including
  manifests/sidecars. If Parquet is disabled for Cash, the backup is SQL-only.
- manifest.json: segment, database, row counts, member sizes and SHA-256 hashes.

SQL uses a repeatable-read, read-only consistent snapshot. Only InnoDB base tables
are supported; views, triggers, routines, events and non-InnoDB tables cause the
preview to refuse the operation. Use a database account permitted to see the
complete schema/metadata; the tool cannot discover objects hidden from its account.
It does not back up MySQL users, grants, server settings, .env or application config
outside the data root. Preserve those separately using your existing procedures.

MySQL TIMESTAMP values are exported/imported in UTC; DATETIME wall-clock values
(including IST candle timestamps) remain unchanged. Decimal precision, NULL,
binary values, Unicode, quotes and microseconds are preserved. Generated columns
are recreated by schema DDL and omitted from INSERTs. All existing schema DDL is
exported from MySQL; inspect any unusual database-specific tablespace/foreign-schema
references before a recovery import.

Parquet metadata and schema are checked before/after copying; file hashes are
verified before publication. These checks do not prove market-data quality or
SQL/Parquet parity, and cannot make independently active stores atomic. Keep all
writers stopped. The shared advisory lock coordinates with the new Schema Manager
and other BackupService instances only, not external programs or ingestion jobs.

## Verify and stage recovery

1. Select a completed backup and click Verify backup. All member hashes are checked.
2. Re-enter the admin password and type STAGE <backup-id>.
3. The tool verifies a private copy and extracts into a new recovery/<id>_<suffix>
   directory. It never overwrites the live data directory or executes dump SQL.

Extraction rejects traversal, symlinks, duplicate/case-colliding filenames and
Windows reserved/invalid names. Limits: 100,000 archive members, 32 MiB manifest,
1 TiB total expanded size; available extraction space is checked. Restore staging
requires space for the compressed copy plus expanded contents. Checksums detect
corruption; they do not authenticate an archive altered by someone with disk access.
Use only locally created, trusted backups and protect archives like the source data.

Manifest verification also rejects duplicate JSON keys, invalid database/table
inventory types, negative counts/sizes, malformed hashes and timestamps. After
extraction, staging rechecks the complete file inventory and every member checksum
from disk before returning `STAGED_ONLY`. A symlinked recovery root is rejected.

## Recovery drill (manual, separate empty database)

The UI reports CHECKSUM_VERIFIED and STAGED_ONLY, never RESTORE_TESTED. To establish
that a backup is recoverable on your Windows/MySQL setup:

1. Create a separate empty recovery database with compatible MySQL version,
   character set and permissions. Do not select the live Cash/FNO database.
2. In a fresh MySQL client session connected to the recovery database, use
   `SOURCE F:/path/to/recovery/database.sql;` (replace with the actual staged path).
   SQL intentionally contains no CREATE DATABASE, USE or DROP statements. If an
   import fails partway, use a new empty recovery database for the next attempt.
3. Compare exact row counts with manifest.json, validate constraints and sampled
   typed values, and run existing SQL/Parquet verification against recovery copies.
   Re-enabling FOREIGN_KEY_CHECKS does not retroactively validate imported rows.
4. Preserve live storage until the drill succeeds. Plan live cutover separately,
   with ingestion stopped and SQL plus Parquet/checkpoints treated as one recovery
   scope. Automatic live replacement and automatic rollback are not in this step.

Do not use the Schema Manager's “verified database backup” acknowledgment merely
because checksums pass; complete a recovery drill first.

Step 9 adds **Administration → Recovery Verification** and
`python -m controller.recovery_cli` to automate schema, complete row-multiset,
foreign-key and staged-file checks after that manual isolated import. See
[RECOVERY_VERIFICATION.md](RECOVERY_VERIFICATION.md). It never imports dump SQL or
performs live cutover; market-data parity/application recovery remain separate checks.

## Validation

Unit tests exercise real ZIP creation, streamed verification, fresh-folder staging,
source preservation, stale/corrupt archives, unsafe Windows paths, permissions,
writer changes, malformed manifest metadata, post-extraction corruption and failure
cleanup. SQL scalar encoding is tested without MySQL.
An optional disposable-MySQL test covers dump generation and scalar round trips.
A full real-MySQL recovery drill remains a deployment prerequisite; skipped tests
are not reported as successful database restores.

Restored job/checkpoint rows are historical state. Review pending/running jobs before
starting any workers against a recovery or replacement database; do not let restored
jobs automatically resume while validating the recovered data.
