# Audit Phase 4 — calendar/session correctness and 3m integration

Phase 4 adds `3m` as a locally derived timeframe for Cash and F&O. The canonical
provider timeframe remains `1m`.

Cash buckets start at each configured session interval's open. A regular
375-minute Cash session produces 125 complete `3m` bars. Split sessions restart
the bucket clock after every break, so a bucket never crosses a closed interval.
Missing or invalid source minutes leave the affected derived bucket absent.

The public read contract, SDK, strict read probe, workflow UI, F&O CLI and F&O
aggregation now accept `3m`. A full 385-minute F&O session produces 129 bars;
the last session-clipped bucket contains the final minute. Recovery/rebuild and
cleanup scopes include the new derived partition without changing their existing
cross-store recovery rules.

## Optional Windows verification

Run from the extracted project root after activating the existing environment:

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_aggregation_reporting.py tests\test_cash_calendar_update.py tests\test_market_data_client.py tests\test_consumer_adapter.py tests\test_unified_workflow.py tests\test_cleanup_service.py tests\test_cash_recovery.py
.venv\Scripts\python.exe -m pytest -q tests\fno\test_fno_release3.py
```

The first command should pass the deterministic Cash, contract, workflow and
recovery checks. The F&O integration module runs when its disposable test database
environment is configured; otherwise its database fixtures may skip. Do not point
test variables at production databases.

No production database, broker request, data reset or destructive migration is
required by this phase. Existing stored data is not automatically rebuilt; select
an explicit scope when `3m` history is needed.
