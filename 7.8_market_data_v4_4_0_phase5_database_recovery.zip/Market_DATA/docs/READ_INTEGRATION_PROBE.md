# One-command read integration probe

The probe calls only the already-running local GET API. It requires no broker login and does not directly connect to SQL, modify data, fetch provider history, or rerun recovery. It writes a unique JSON report to TIOS_HOME/recovery/read_checks. This cumulative build adds a client-side probe; the previously tested regular-session API process can remain running.

From the new extracted project folder in CMD:

```bat
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.read_probe_cli --date 2026-10-23 --cash-symbol "NSE:SBIN-EQ" --fno-symbol "NSE:BANKNIFTY26NOVFUT" --underlying NIFTY
```

Enter the tool admin password once. No password is placed in the command, logged, or saved in the report. Default API origin is http://127.0.0.1:8000; use --port if necessary. If no API is running, start `python -m api --port 8000` in another CMD with TIOS_HOME set. API dependencies are in requirements-api.txt.

## Checks

1. Cash verified regular 1m, 3m, 5m, 15m, 30m, 1h, 1d reads, limited to the selected day/symbol. For SBIN October 23, the expected counts under the verified 375-minute session are 375, 125, 75, 25, 13, 7, 1. The server validates recomputation; the probe does not merely compare expected counts.
2. Cash pagination: raw regular SQL pages of 200 rows are compared by ordered timestamp/timeframe/OHLCV/source/status against the fresh verified 1m baseline. Full-scope exclusion counts must agree. A normal full session requires two pages. Pagination does not repeatedly trigger expensive full-store verification. A concurrent write may cause an explicit finding; this is not an atomic snapshot.
3. FNO raw 1m sample and verified 1m contract-day. The supplied BANKNIFTY futures contract previously had 385 rows for this day; current verification determines whether it is still complete. Sparse options produce a finding, not a false complete label.
4. NIFTY stored option-chain sample (up to two records), with underlying and batch identity checks. This confirms the endpoint/sample only, not full option-chain integrity or historical options availability.

There are 10 check results and ordinarily 11 GET requests. No automatic retries are used. Each request has a 120-second HTTP timeout; this is not a hard total task deadline. Per-check wall time includes transport, authentication, server, SQL and Parquet work, and cannot identify a bottleneck by itself. Authentication failure stops immediately; individual data/endpoint findings are recorded while independent checks continue. Missing data is a finding, not a request to fetch or overwrite it.

Every check prints its result and seconds promptly. Final status is SCOPED_READ_CHECK_PASS only when all selected checks pass; otherwise FINDINGS. STOPPED denotes a top-level failure. Reports have no passwords, tokens, SQL URLs or raw error details. Share the final output and the JSON report. Do not automatically rerun repair or delete data based on a finding.

The optional --fno-symbol and --underlying flags control these extra endpoint checks; omitting them narrows the scope and does not certify untested endpoints. The date and Cash symbol must be explicit.

## Validation

69 read API/SDK/integration tests passed locally with actual SQLite and Parquet, including the new batch success path over all Cash derived timeframes, FNO coverage and option-chain samples, no SQL mutation statements during the probe, missing-data reporting, and immediate authentication stop. Windows/MySQL timings and results require the owner's run. The previous core build's full suite was 830 passed / 194 skipped; it was not rerun for this additive diagnostic-only build.
