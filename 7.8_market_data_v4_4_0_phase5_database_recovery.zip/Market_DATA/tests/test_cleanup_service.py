"""Real SQLite transactions and Parquet bytes; no production credentials or deletes."""
import datetime as dt
import json
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest
from sqlalchemy import create_engine, text

from model.cleanup_service import CleanupService
from model.backup_service import sha256_file


@pytest.fixture(params=['CASH','FNO'])
def setup(tmp_path, request):
    segment = request.param
    engine = create_engine('sqlite:///'+str(tmp_path/'test.db'))
    root = tmp_path/'data'; root.mkdir()
    prefix = '' if segment == 'CASH' else 'fno_'
    ident = 'instrument_id' if segment == 'CASH' else 'contract_id'
    with engine.begin() as c:
        c.execute(text(f'CREATE TABLE {prefix}instruments (id INTEGER PRIMARY KEY, fyers_symbol TEXT, underlying TEXT, expiry DATE)'))
        c.execute(text(f'CREATE TABLE {prefix}candles (id INTEGER PRIMARY KEY, {ident} INTEGER, timeframe TEXT, candle_timestamp DATETIME, close NUMERIC)'))
        for i,symbol in [(1,'NSE:ONE'),(2,'NSE:TWO')]:
            c.execute(text(f'INSERT INTO {prefix}instruments VALUES (:i,:s,"NIFTY","2020-01-30")'),dict(i=i,s=symbol))
        if segment == 'CASH':
            c.execute(text('CREATE TABLE checkpoints (id INTEGER PRIMARY KEY, fyers_symbol TEXT, timeframe TEXT, synced_through_date DATE)'))
            c.execute(text('INSERT INTO checkpoints VALUES (1,"NSE:ONE","1m","2020-01-20"),(2,"NSE:TWO","1m","2020-01-20")'))
            c.execute(text('CREATE TABLE ingestion_jobs (id INTEGER PRIMARY KEY, status TEXT, state TEXT, active_key TEXT)'))
        else:
            c.execute(text('CREATE TABLE fno_checkpoint_ranges (id INTEGER PRIMARY KEY, contract_id INTEGER, timeframe TEXT, range_from DATE, range_to DATE)'))
            c.execute(text('INSERT INTO fno_checkpoint_ranges VALUES (1,1,"1m","2020-01-01","2020-01-20"),(2,2,"1m","2020-01-01","2020-01-20")'))
            c.execute(text('CREATE TABLE fno_harvest_state (contract_id INTEGER PRIMARY KEY, last_harvested_date DATE)'))
            c.execute(text('INSERT INTO fno_harvest_state VALUES (1,"2020-01-20"),(2,"2020-01-20")'))
            c.execute(text('CREATE TABLE fno_storage_manifest (id INTEGER PRIMARY KEY, relative_path TEXT, dataset TEXT, timeframe TEXT, checksum TEXT, row_count INTEGER, status TEXT, min_timestamp DATETIME, max_timestamp DATETIME, note TEXT)'))
            for table in ['fno_ingestion_jobs','fno_aggregation_jobs']:
                c.execute(text(f'CREATE TABLE {table} (id INTEGER PRIMARY KEY, state TEXT, active_key TEXT)'))
        for i,cid,tf,day in [(1,1,'1m','2020-01-10'),(2,2,'1m','2020-01-10'),(3,1,'5m','2020-01-10'),(4,1,'1m','2020-01-11')]:
            c.execute(text(f'INSERT INTO {prefix}candles VALUES (:i,:cid,:tf,:ts,100)'),dict(i=i,cid=cid,tf=tf,ts=day+' 09:15:00'))
    paths = []
    for tf in ['1m','5m']:
        if segment == 'CASH':
            path = root/('raw/1m' if tf == '1m' else 'processed/'+tf)/'NSE_ONE'/'2020-01-10.parquet'
            frame = pd.DataFrame({'fyers_symbol':['NSE:ONE'],'timeframe':[tf],'candle_timestamp':pd.to_datetime(['2020-01-10 09:15:00']).tz_localize('Asia/Kolkata'),'close':[100.]})
        else:
            path = root/'candles'/tf/'underlying=NIFTY'/'expiry=2020-01-30'/'date=2020-01-10.parquet'
            frame = pd.DataFrame({'contract_id':[1,2],'timeframe':[tf,tf],'candle_timestamp':pd.to_datetime(['2020-01-10 09:15:00']*2),'close':[100.,200.]})
        path.parent.mkdir(parents=True,exist_ok=True); frame.to_parquet(path,index=False); paths.append(path)
        if segment == 'FNO':
            with engine.begin() as c:
                c.execute(text('INSERT INTO fno_storage_manifest (relative_path,dataset,timeframe,checksum,row_count,status) VALUES (:p,"candles",:tf,:h,2,"VERIFIED")'),dict(p=path.relative_to(root).as_posix(),tf=tf,h=sha256_file(path)))
    catalog = SimpleNamespace(roots={segment:root},engine=lambda s:engine)
    service = CleanupService(catalog,tmp_path/'operations')
    service.guard = SimpleNamespace(_engine=lambda s:engine,_database_lock=lambda e:nullcontext())
    # SQLite has no MySQL advisory locks; production guard remains MySQL-only.
    if segment == 'FNO':
        request.getfixturevalue('monkeypatch').setattr(service,'_partition_locks',lambda *args:nullcontext())
    return service,segment,engine,paths


def preview(setup,tf='1m'):
    service,segment,_,_ = setup
    return service.preview(segment,'NSE:ONE','2020-01-10','2020-01-10',tf,role='admin')


def apply(setup,plan=None):
    service,_,_,_ = setup
    plan = plan or preview(setup)
    return service.apply(plan,role='admin',confirmation='CLEANUP '+plan['database'],writers_stopped=True,backup_acknowledged=True)


def test_cleanup_preserves_peer_rows_and_derived_invalidates_checkpoints(setup):
    service,segment,engine,paths = setup
    plan = preview(setup)
    assert plan['timeframes'] == ['1m','3m','5m','15m','30m','1h','1d']
    assert plan['row_counts']['candles' if segment == 'CASH' else 'fno_candles'] == 2
    originals = {p:p.read_bytes() for p in paths}
    result = apply(setup,plan)
    assert result['status'] == 'SUCCESS', result
    prefix = '' if segment == 'CASH' else 'fno_'
    with engine.connect() as c:
        assert c.execute(text(f'SELECT id FROM {prefix}candles ORDER BY id')).scalars().all() == [2,4]
        checkpoint = 'checkpoints' if segment == 'CASH' else 'fno_checkpoint_ranges'
        assert c.execute(text('SELECT id FROM '+checkpoint)).scalars().all() == [2]
        if segment == 'FNO':
            assert c.execute(text('SELECT contract_id FROM fno_harvest_state')).scalars().all() == [2]
            for p in paths:
                assert pd.read_parquet(p).contract_id.tolist() == [2]
                manifest = c.execute(text('SELECT checksum,row_count FROM fno_storage_manifest WHERE relative_path=:p'),dict(p=p.relative_to(service.catalog.roots[segment]).as_posix())).one()
                assert manifest == (sha256_file(p),1)
        else:
            assert all(not p.exists() for p in paths)
    journal = Path(result['journal'])
    assert not (journal.parent/'RECOVERY_NEEDED').exists()
    assert {p.read_bytes() for p in journal.parent.glob('*.original.parquet')} == set(originals.values())
    assert json.loads(journal.read_text().splitlines()[-1])['event'] == 'COMPLETED'


def test_derived_only_leaves_base(setup):
    result = apply(setup,preview(setup,'5m'))
    assert result['status'] == 'SUCCESS'
    assert setup[3][0].exists()
    assert preview(setup)['row_counts']['candles' if setup[1]=='CASH' else 'fno_candles'] == 1


@pytest.mark.parametrize('kind',['sql_content','file_content','checkpoint','tamper'])
def test_stale_or_tampered_plan_blocks_before_mutation(setup,kind):
    service,segment,engine,paths = setup
    plan = preview(setup)
    if kind == 'tamper':
        plan['row_counts'] = {}
    elif kind == 'file_content':
        frame = pd.read_parquet(paths[0]); frame['close'] = 999.; frame.to_parquet(paths[0],index=False)
    else:
        with engine.begin() as c:
            if kind == 'sql_content':
                c.execute(text('UPDATE '+('candles' if segment=='CASH' else 'fno_candles')+' SET close=999 WHERE id=1'))
            else:
                c.execute(text('DELETE FROM '+('checkpoints' if segment=='CASH' else 'fno_checkpoint_ranges')+' WHERE id=1'))
    with pytest.raises(ValueError):
        apply(setup,plan)
    assert paths[0].exists()


def test_roles_confirmations_and_acknowledgments(setup):
    service,segment,_,_ = setup
    with pytest.raises(PermissionError):
        service.preview(segment,'NSE:ONE','2020-01-10','2020-01-10',role='viewer')
    plan = preview(setup)
    with pytest.raises(PermissionError):
        service.apply(plan,role='viewer',confirmation='x')
    with pytest.raises(ValueError):
        service.apply(plan,role='admin',confirmation='CLEANUP '+plan['database'])
    with pytest.raises(ValueError):
        service.apply(plan,role='admin',confirmation='x',writers_stopped=True,backup_acknowledged=True)


@pytest.mark.parametrize('state',['RUNNING','PENDING','CANCEL_REQUESTED'])
def test_active_jobs_fail_closed(setup,state):
    service,segment,engine,_ = setup
    with engine.begin() as c:
        table = 'ingestion_jobs' if segment == 'CASH' else 'fno_ingestion_jobs'
        c.execute(text('INSERT INTO '+table+' (id,state) VALUES (1,:s)'),dict(s=state))
    with pytest.raises(ValueError,match='Active jobs'):
        preview(setup)


def test_bounds_and_injection_rejected(setup):
    service,segment,_,_ = setup
    for symbol,a,b,tf in [('NSE:ONE','2020-01-01','2020-02-01','1m'),('NSE:ONE','2020-01-10','2020-01-10','../../x'),('../x','2020-01-10','2020-01-10','1m'),('NSE:ONE','2099-01-10','2099-01-10','1m')]:
        with pytest.raises(ValueError):
            service.preview(segment,symbol,a,b,tf,role='admin')


def test_symlink_mixed_partition_and_unknown_layout_rejected(setup):
    service,segment,_,paths = setup
    link = service.catalog.roots[segment]/'unsafe'
    link.symlink_to(paths[0])
    with pytest.raises(ValueError,match='Symlink'): preview(setup)
    link.unlink()
    unknown = paths[0].parent/'pending.tmp'; unknown.write_bytes(b'unknown')
    with pytest.raises(ValueError,match='Unknown partition'): preview(setup)
    unknown.unlink()
    frame = pd.read_parquet(paths[0]); frame.loc[0,'timeframe'] = '1h'; frame.to_parquet(paths[0],index=False)
    with pytest.raises(ValueError,match='Mixed date/timeframe'): preview(setup)


def test_failure_keeps_originals_journal_and_blocks_retry(setup,monkeypatch):
    service,segment,engine,paths = setup
    # Fail after the first file mutation: SQL rolls back, file state may be partial.
    if segment == 'FNO':
        original = service._publish_file
        def fail(source,destination):
            original(source,destination)
            raise RuntimeError('injected publication failure')
        monkeypatch.setattr(service,'_publish_file',fail)
    else:
        original = service._sync_dir
        def fail(path):
            if path == paths[0].parent:
                raise RuntimeError('injected unlink failure')
            original(path)
        monkeypatch.setattr(service,'_sync_dir',fail)
    result = apply(setup)
    assert result['status'] == 'RECOVERY_NEEDED'
    operation = Path(result['journal']).parent
    assert (operation/'RECOVERY_NEEDED').exists()
    assert len(list(operation.glob('*.original.parquet'))) == 2
    with engine.connect() as c:
        assert c.execute(text('SELECT COUNT(*) FROM '+('candles' if segment=='CASH' else 'fno_candles'))).scalar() == 4
    with pytest.raises(ValueError,match='Unresolved cleanup'):
        apply(setup, {'segment':segment,'database':engine.url.database})


def test_production_guard_rejects_sqlite(setup):
    service,segment,_,_ = setup
    from model.schema_management import SchemaManager
    service.guard = SchemaManager(service.catalog)
    with pytest.raises(ValueError,match='MySQL'):
        preview(setup)


def test_fno_manifest_and_peer_contract_validation(setup):
    service,segment,engine,paths = setup
    if segment != 'FNO':
        pytest.skip('Shared manifests are FNO only')
    with engine.begin() as c:
        c.execute(text('UPDATE fno_instruments SET underlying="OTHER" WHERE id=2'))
    with pytest.raises(ValueError,match='Mixed or unknown'):
        preview(setup)
    with engine.begin() as c:
        c.execute(text('UPDATE fno_instruments SET underlying="NIFTY" WHERE id=2'))
        c.execute(text('UPDATE fno_storage_manifest SET status="WRITING"'))
    with pytest.raises(ValueError,match='manifest'):
        preview(setup)


def test_sql_commit_failure_retains_recovery_journal(setup,monkeypatch):
    service,segment,engine,paths = setup
    from sqlalchemy import event
    plan = preview(setup)
    def fail(conn):
        raise RuntimeError('injected commit failure with secret sql params')
    event.listen(engine,'commit',fail)
    try:
        result = apply(setup,plan)
    finally:
        event.remove(engine,'commit',fail)
    assert result['status'] == 'RECOVERY_NEEDED'
    assert result['error_type'] == 'RuntimeError'
    assert 'secret sql' not in json.dumps(result)
    assert 'secret sql' not in Path(result['journal']).read_text()
    assert (Path(result['journal']).parent/'RECOVERY_NEEDED').exists()


def test_scope_byte_bound_prevents_parquet_read(setup,monkeypatch):
    import model.cleanup_service as module
    monkeypatch.setattr(module,'MAX_FILE_BYTES',1)
    def unexpected(*args,**kwargs):
        raise AssertionError('Data must not be loaded before metadata bounds')
    monkeypatch.setattr(module.pd,'read_parquet',unexpected)
    with pytest.raises(ValueError,match='excessive partition'):
        preview(setup)


def test_root_overlap_fails_closed(setup,tmp_path):
    service,segment,_,_ = setup
    other = 'FNO' if segment == 'CASH' else 'CASH'
    service.catalog.roots[other] = service.catalog.roots[segment]/'raw' # Cash namespace; reverse containment is also unsafe
    with pytest.raises(ValueError,match='overlap'):
        preview(setup)


@pytest.mark.parametrize('corruption',['float_id','aware_timestamp','empty','missing_manifest'])
def test_invalid_fno_partition_fails_closed(setup,corruption):
    service,segment,engine,paths = setup
    if segment != 'FNO':
        pytest.skip('FNO convention')
    frame = pd.read_parquet(paths[0])
    if corruption == 'float_id':
        frame['contract_id'] = [1.1,2.]
    elif corruption == 'aware_timestamp':
        frame['candle_timestamp'] = frame.candle_timestamp.dt.tz_localize('Asia/Kolkata')
    elif corruption == 'empty':
        frame = frame.iloc[:0]
    else:
        with engine.begin() as c:
            c.execute(text('DELETE FROM fno_storage_manifest'))
    if corruption != 'missing_manifest':
        frame.to_parquet(paths[0],index=False)
    with pytest.raises(ValueError):
        preview(setup)


class AdvisoryEngine:
    """Strict single-session fake: catches accidental pool-per-partition use."""
    def __init__(self, fail_at=None, release_fails=False):
        self.url = SimpleNamespace(database='guarded_fno')
        self.connections = 0
        self.acquired = []
        self.released = []
        self.fail_at = fail_at
        self.release_fails = release_fails
        self.invalidated = False
        self.closed = False

    def connect(self):
        self.connections += 1
        assert self.connections == 1, 'All partition locks must share one session'
        return self

    def __enter__(self):
        return self

    def __exit__(self,*args):
        self.closed = True

    def execute(self, statement, params):
        if str(statement).startswith('SELECT GET_LOCK'):
            assert str(statement) == 'SELECT GET_LOCK(:key, 0)'
            if self.fail_at == len(self.acquired):
                return SimpleNamespace(scalar=lambda:0)
            self.acquired.append(params['key'])
        else:
            self.released.append(params['key'])
            if self.release_fails:
                raise RuntimeError('disconnect during release')
        return SimpleNamespace(scalar=lambda:1)

    def invalidate(self):
        self.invalidated = True


def test_many_fno_partitions_use_one_connection_and_writer_namespace(tmp_path):
    import hashlib
    service = CleanupService(SimpleNamespace(),tmp_path/'journal')
    engine = AdvisoryEngine()
    files = [{'relative_path':f'candles/1m/date={i:03}.parquet'} for i in reversed(range(186))]
    with service._partition_locks(engine,tmp_path,'FNO',files):
        assert len(engine.acquired) == 186
        expected = ['fno:'+hashlib.sha256(('guarded_fno:'+f['relative_path']).encode()).hexdigest()[:55]
                    for f in sorted(files,key=lambda f:f['relative_path'])]
        assert engine.acquired == expected
        assert not engine.released
    assert engine.connections == 1
    assert engine.released == list(reversed(engine.acquired))
    assert engine.closed and not engine.invalidated


def test_fno_lock_failure_releases_previously_acquired_locks(tmp_path):
    service = CleanupService(SimpleNamespace(),tmp_path/'journal')
    engine = AdvisoryEngine(fail_at=3)
    files = [{'relative_path':f'candles/1m/date={i}.parquet'} for i in range(10)]
    with pytest.raises(RuntimeError,match='Another FNO'):
        with service._partition_locks(engine,tmp_path,'FNO',files):
            pytest.fail('Contended lock must prevent entry')
    assert len(engine.acquired) == 3
    assert engine.released == list(reversed(engine.acquired))
    assert engine.connections == 1 and engine.closed


def test_fno_release_failure_invalidates_session_and_preserves_body_exception(tmp_path):
    service = CleanupService(SimpleNamespace(),tmp_path/'journal')
    engine = AdvisoryEngine(release_fails=True)
    files = [{'relative_path':'candles/1m/day.parquet'}]
    with pytest.raises(ValueError,match='body failure'):
        with service._partition_locks(engine,tmp_path,'FNO',files):
            raise ValueError('body failure')
    assert engine.invalidated and engine.closed
    assert engine.released == engine.acquired


def test_journal_must_be_outside_peer_root(setup,tmp_path):
    service,segment,_,_ = setup
    peer = tmp_path/'peer'; peer.mkdir()
    service.catalog.roots['FNO' if segment == 'CASH' else 'CASH'] = peer
    service.journal_root = peer/'cleanup_journals'
    with pytest.raises(ValueError,match='outside all configured'):
        preview(setup)


def test_nested_segment_cleanup_preserves_other_tree(setup):
    service,segment,engine,paths=setup
    if segment=='CASH':
        peer=service.catalog.roots['CASH']/'fno'
        peer.mkdir()
        service.catalog.roots['FNO']=peer
    else:
        # Existing FNO fixture becomes a nested tree under a Cash root.
        cash=service.catalog.roots['FNO'].parent
        service.catalog.roots['CASH']=cash
        # Journals must stay outside the enclosing Cash root.
        service.journal_root=cash.parent/(cash.name+'-journal')
        peer=cash/'raw'
        peer.mkdir()
    marker=peer/'other-segment.parquet';marker.write_bytes(b'preserve-peer')
    plan=preview(setup)
    result=apply(setup,plan)
    assert result['status']=='SUCCESS',result
    assert marker.read_bytes()==b'preserve-peer'
