"""Offline recovery fixtures: imported rows are separate from immutable backups."""
import contextlib
import decimal
import hashlib
import json
import zipfile
from pathlib import Path
from types import SimpleNamespace
import pytest
from sqlalchemy import create_engine
from model.backup_service import BackupService, sql_literal
from model.recovery_verification import RecoveryVerifier, _row


class OfflineVerifier(RecoveryVerifier):
    def _ddl(self, conn, table):
        return conn.exec_driver_sql('SELECT sql FROM sqlite_master WHERE type=? AND name=?',('table',table)).scalar()

    def _identity(self, manifest, confirmation):
        if confirmation!='VERIFY tios_recovery_test': raise ValueError('CONFIRMATION')
        return 'tios_recovery_test'

    @contextlib.contextmanager
    def _snapshot(self, name):
        with self.engine.connect() as conn: yield conn


@pytest.fixture
def recovery(tmp_path):
    live=tmp_path/'live'; live.mkdir()
    service=BackupService(SimpleNamespace(roots={'CASH':live}),tmp_path/'backups',tmp_path/'stages')
    service.backup_root.mkdir()
    engine=create_engine('sqlite:///'+str(tmp_path/'import.db'))
    with engine.begin() as conn:
        conn.exec_driver_sql('CREATE TABLE sample (id INTEGER, label TEXT, payload BLOB)')
        conn.exec_driver_sql('INSERT INTO sample VALUES (?,?,?)',(1,'日本語',b'\x00\xff'))
    values=(1,'日本語',b'\x00\xff')
    dump='-- TIOS recovery dump. Import into an EMPTY, separate recovery database.\nCREATE TABLE sample (id INTEGER, label TEXT, payload BLOB);\nINSERT INTO sample (id,label,payload) VALUES ('+','.join(map(sql_literal,values))+');\nSET FOREIGN_KEY_CHECKS=1;\n'
    def stage(dump_text=dump, tables=None):
        ident='a'*32
        payloads={'database.sql':dump_text.encode(),'parquet/a.parquet':b'parquet'}
        manifest={'format':'tios-backup-v1','created_at':'2026-10-30T00:00:00+00:00',
                  'segment':'CASH','database':'cash','tables':tables or {'sample':1},'restore_tested':False,
                  'members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in payloads.items()}}
        with zipfile.ZipFile(service.backup_root/(ident+'.zip'),'w') as archive:
            for n,v in payloads.items(): archive.writestr(n,v)
            archive.writestr('manifest.json',json.dumps(manifest))
        verified=service.verify(ident,role='admin')
        folder=Path(service.stage_recovery(verified,role='admin',confirmation='STAGE '+ident)['path'])
        return ident,folder
    return service,engine,stage,dump


def verify(recovery, mutate=None, dump=None, cls=OfflineVerifier, **kw):
    service,engine,stage,source=recovery
    ident,folder=stage(source if dump is None else dump)
    if mutate: mutate(folder,engine)
    verifier=cls(service,engine,['cash'])
    return verifier.verify(ident,folder.name,role=kw.get('role','admin'),confirmation=kw.get('confirmation','VERIFY tios_recovery_test'))


def test_exhaustive_verification_and_report(recovery):
    result=verify(recovery)
    assert result['status']=='VERIFIED'
    assert result['scope']=='SQL_AND_FILES_VERIFIED'
    assert result['restore_tested'] is False
    assert result['market_parity']=='NOT_TESTED'
    assert json.loads(Path(result['report_path']).read_text())==result
    assert 'NOT_TESTED' in result['schema_coverage']


@pytest.mark.parametrize('kind',['changed','extra','symlink'])
def test_stage_tampering(recovery,kind):
    def change(folder,engine):
        if kind=='changed': (folder/'database.sql').write_text('bad')
        elif kind=='extra': (folder/'extra').write_text('x')
        else: (folder/'extra').symlink_to(folder/'database.sql')
    assert verify(recovery,change)['status']=='FAILED'


@pytest.mark.parametrize('statement',["UPDATE sample SET label='wrong'",'DELETE FROM sample','INSERT INTO sample SELECT * FROM sample','CREATE TABLE extra (id INT)'])
def test_wrong_import(recovery,statement):
    def change(folder,engine):
        with engine.begin() as conn: conn.exec_driver_sql(statement)
    assert verify(recovery,change)['status']=='FAILED'


def test_unknown_dump_never_executed(recovery):
    result=verify(recovery,dump=recovery[3]+'DROP TABLE sample;\n')
    assert result['errors']==['DUMP_GRAMMAR']
    with recovery[1].connect() as conn: assert conn.exec_driver_sql('SELECT COUNT(*) FROM sample').scalar()==1


def test_role_and_confirmation(recovery):
    with pytest.raises(PermissionError): verify(recovery,role='viewer')
    assert verify(recovery,confirmation='yes')['errors']==['CONFIRMATION']
    assert verify(recovery,cls=RecoveryVerifier)['errors']==['TARGET_IDENTITY']


def test_literals_are_typed_and_exact():
    values=[None,decimal.Decimal('1.2300'),'é,☃',b'\x00\xff',-12]
    row=','.join(sql_literal(v) for v in values)
    assert json.loads(_row(row))==[sql_literal(v) for v in values]
    with pytest.raises(ValueError): _row('NOW()')


def test_orphan_detection(recovery):
    service,engine,stage,dump=recovery
    with engine.begin() as conn:
        conn.exec_driver_sql('DROP TABLE sample')
        conn.exec_driver_sql('CREATE TABLE parent (id INT PRIMARY KEY)')
        conn.exec_driver_sql('CREATE TABLE sample (id INTEGER, label TEXT, payload BLOB, FOREIGN KEY(id) REFERENCES parent(id))')
        conn.exec_driver_sql('INSERT INTO sample VALUES (?,?,?)',(1,'日本語',b'\x00\xff'))
    # Build source with an empty parent so exact row checks pass before orphan check.
    original=stage
    def both(source):
        source=source.replace('CREATE TABLE sample','CREATE TABLE parent (id INT PRIMARY KEY);\nCREATE TABLE sample')
        source=source.replace('payload BLOB);','payload BLOB, FOREIGN KEY(id) REFERENCES parent(id));')
        return original(source,{'parent':0,'sample':1})
    assert verify((service,engine,both,dump))['errors']==['FOREIGN_KEY_ORPHAN']


@pytest.mark.parametrize('name,live,source',[
    ('cash',[], 'cash'),('tios_recovery_test',['TIOS_RECOVERY_TEST'],'cash'),
    ('tios_recovery_test',[],'TIOS_RECOVERY_TEST'),('tios_recovery_',[],'cash'),
    ('tios_recovery_test;DROP',[],'cash')])
def test_mysql_identity_rejects_live_and_source(recovery,name,live,source):
    engine=SimpleNamespace(dialect=SimpleNamespace(name='mysql'),url=SimpleNamespace(database=name))
    verifier=RecoveryVerifier(recovery[0],engine,live)
    with pytest.raises(ValueError,match='TARGET_IDENTITY'):
        verifier._identity({'database':source},'VERIFY '+name)


def test_role_checked_before_any_backup_calls(recovery,monkeypatch):
    service,engine,_,_=recovery
    monkeypatch.setattr(service,'verify',lambda *a,**k:pytest.fail('role bypass'))
    with pytest.raises(PermissionError):
        OfflineVerifier(service,engine,[]).verify('x','x',role='viewer',confirmation='x')


def test_dump_line_limit(recovery,monkeypatch):
    monkeypatch.setattr('model.recovery_verification.MAX_LINE_BYTES',100)
    result=verify(recovery,dump=recovery[3]+'X'*101+'\n')
    assert result['errors']==['DUMP_LINE_LIMIT']


@pytest.mark.parametrize('counts',[{'sample':True},{'sample':-1},{'sample':'1'}])
def test_invalid_manifest_counts(recovery,counts):
    service,engine,stage,dump=recovery
    with pytest.raises(ValueError,match='table inventory'):
        stage(dump,counts)


def test_changed_stage_during_verification(recovery):
    class Changing(OfflineVerifier):
        def _compare(self,*args):
            super()._compare(*args)
            next(self.backups.recovery_root.glob('*/database.sql')).write_text('changed')
    assert verify(recovery,cls=Changing)['errors']==['STAGE_CHECKSUM']


def test_symlink_stage_ancestor(recovery,tmp_path):
    service,engine,stage,dump=recovery
    ident,folder=stage()
    alias=tmp_path/'alias'; alias.symlink_to(tmp_path,target_is_directory=True)
    service.recovery_root=alias/'stages'
    result=OfflineVerifier(service,engine,[],tmp_path/'reports').verify(ident,folder.name,role='admin',confirmation='VERIFY tios_recovery_test')
    assert result['status']=='FAILED'


def test_report_symlink_ancestor(recovery,tmp_path):
    service,engine,stage,dump=recovery
    ident,folder=stage()
    alias=tmp_path/'alias'; alias.symlink_to(tmp_path,target_is_directory=True)
    with pytest.raises(ValueError,match='PATH_SYMLINK'):
        OfflineVerifier(service,engine,[],alias/'reports').verify(ident,folder.name,role='admin',confirmation='VERIFY tios_recovery_test')
    assert not (tmp_path/'reports').exists()


def test_row_order_ignored_and_duplicates_counted(recovery):
    service,engine,stage,dump=recovery
    row=dump.splitlines()[2]
    second=row.replace('VALUES (1,','VALUES (2,')
    dump=dump.replace(row,row+'\n'+second+'\n'+row)
    with engine.begin() as conn:
        conn.exec_driver_sql('DELETE FROM sample')
        for ident in (2,1,1): conn.exec_driver_sql('INSERT INTO sample VALUES (?,?,?)',(ident,'日本語',b'\x00\xff'))
    def triple(source): return stage(source,{'sample':3})
    assert verify((service,engine,triple,dump))['status']=='VERIFIED'
    with engine.begin() as conn:
        conn.exec_driver_sql('DELETE FROM sample WHERE id=2')
        conn.exec_driver_sql('INSERT INTO sample VALUES (?,?,?)',(1,'日本語',b'\x00\xff'))
    assert verify((service,engine,triple,dump))['errors']==['ROW_CONTENT']


def test_wrong_actual_database_restores_session(recovery):
    calls=[]
    class Connection:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def execution_options(self,**kw): return self
        def exec_driver_sql(self,sql,args=None):
            calls.append((sql,args))
            return SimpleNamespace(scalar=lambda:'SYSTEM' if '@@' in sql else 'cash')
        def commit(self): calls.append(('commit',None))
        def rollback(self): calls.append(('rollback',None))
    engine=SimpleNamespace(connect=lambda:Connection())
    verifier=RecoveryVerifier(recovery[0],engine,[])
    with pytest.raises(ValueError,match='TARGET_IDENTITY'):
        with verifier._snapshot('tios_recovery_test'): pytest.fail('wrong target yielded')
    assert ('rollback',None) in calls
    assert ('SET SESSION time_zone = %s',('SYSTEM',)) in calls


def test_schema_changes_fail_even_empty_table(recovery):
    service,engine,stage,dump=recovery
    with engine.begin() as conn:
        conn.exec_driver_sql('DELETE FROM sample')
        conn.exec_driver_sql('ALTER TABLE sample ADD COLUMN extra INT')
    source=dump.replace(dump.splitlines()[2]+'\n','')
    def empty(value): return stage(value,{'sample':0})
    assert verify((service,engine,empty,source))['errors']==['SCHEMA_DDL_MISMATCH']


@pytest.mark.parametrize('second,expected',[(None,'VERIFIED'),('日本語','FAILED')])
def test_composite_foreign_key_null_semantics(recovery,second,expected):
    service,engine,stage,dump=recovery
    parent='CREATE TABLE parent (id INT, label TEXT, PRIMARY KEY(id,label))'
    child='CREATE TABLE sample (id INTEGER, label TEXT, payload BLOB, FOREIGN KEY(id,label) REFERENCES parent(id,label))'
    with engine.begin() as conn:
        conn.exec_driver_sql('DROP TABLE sample')
        conn.exec_driver_sql(parent); conn.exec_driver_sql(child)
        conn.exec_driver_sql('INSERT INTO sample VALUES (?,?,?)',(1,second,b'\x00\xff'))
    source=parent+';\n'+child+';\nINSERT INTO sample (id,label,payload) VALUES ('+','.join(sql_literal(v) for v in (1,second,b'\x00\xff'))+');\n'
    def both(value): return stage(value,{'parent':0,'sample':1})
    result=verify((service,engine,both,source))
    assert result['status']==expected
    if expected=='FAILED': assert result['errors']==['FOREIGN_KEY_ORPHAN']


def test_external_foreign_key_rejected(recovery,monkeypatch):
    from model import recovery_verification as module
    original=module.inspect
    class Inspector:
        def __init__(self,conn): self.inner=original(conn)
        def __getattr__(self,key): return getattr(self.inner,key)
        def get_foreign_keys(self,table):
            return [{'referred_schema':'cash','referred_table':'sample','constrained_columns':['id'],'referred_columns':['id']}]
    monkeypatch.setattr(module,'inspect',Inspector)
    assert verify(recovery)['errors']==['EXTERNAL_FOREIGN_KEY']


def test_report_sanitizes_driver_errors(recovery):
    class Broken(OfflineVerifier):
        def _compare(self,*args): raise RuntimeError('mysql://secret:password@host SQL VALUES sensitive')
    result=verify(recovery,cls=Broken)
    assert result['errors']==['VERIFICATION_ERROR']
    evidence=Path(result['report_path']).read_text()
    assert 'password' not in evidence and 'sensitive' not in evidence


def test_report_write_failure_removes_partial(recovery,monkeypatch):
    service,engine,stage,dump=recovery
    ident,folder=stage()
    def fail(fd): raise OSError('disk error')
    monkeypatch.setattr('model.recovery_verification.os.fsync',fail)
    verifier=OfflineVerifier(service,engine,[])
    with pytest.raises(OSError): verifier.verify(ident,folder.name,role='admin',confirmation='VERIFY tios_recovery_test')
    assert list(verifier.report_root.iterdir())==[]


def test_valid_mysql_identity_without_connecting(recovery):
    engine=SimpleNamespace(dialect=SimpleNamespace(name='mysql'),url=SimpleNamespace(database='tios_recovery_ok'))
    verifier=RecoveryVerifier(recovery[0],engine,['cash','fno'])
    assert verifier._identity({'database':'cash'},'VERIFY tios_recovery_ok')=='tios_recovery_ok'


def test_report_saved_when_platform_has_no_fchmod(recovery,monkeypatch):
    monkeypatch.delattr('model.recovery_verification.os.fchmod')
    assert verify(recovery)['status']=='VERIFIED'


def test_schema_memory_bound(recovery,monkeypatch):
    monkeypatch.setattr('model.recovery_verification.MAX_SCHEMA_BYTES',10)
    assert verify(recovery)['errors']==['DUMP_SCHEMA_LIMIT']
