"""Persisted, resumable FNO aggregation; source is always canonical 1m."""
import datetime as dt

from controller.fno_jobs import JobOutcome
from model.fno.aggregation import MINUTES, aggregate_day, session_bounds
from model.fno.models import IST
from model.fno.release3_repository import Release3Repository, date_range

JOB_TYPE = "AGGREGATION"


def run_aggregation(handle, repo, store, settings, now=None):
    repo = Release3Repository(repo.engine)
    a,b = date_range(handle.params)
    targets = list(dict.fromkeys(handle.params.get("timeframes", list(MINUTES))))
    if not targets or any(tf not in MINUTES for tf in targets):
        raise ValueError("Choose targets from 3m, 5m, 15m, 30m, 1h, 1d")
    now = now or dt.datetime.now(IST)
    totals = {"targets": {}, "contracts": 0}
    state = "NO_DATA"
    for tf in targets:
        stats = {"input_rows":0,"output_rows":0,"skipped_buckets":0,"invalid_rows":0,"days":0,
                 "missing_buckets":0,"incomplete_buckets":0,"forming_buckets":0}
        totals["targets"][tf] = stats
        record = repo.start_aggregation(handle.id, tf, handle.params)
        try:
            for contract in repo.iter_contracts(handle.params.get("underlyings"),handle.params.get("contract_ids"),data_range=(a,b)):
                if tf == targets[0]:
                    totals["contracts"] += 1
                day = a
                while day <= b:
                    stop = handle.stop_outcome(totals)
                    if stop:
                        repo.aggregation_progress(record, stats, stop.state, stop.error)
                        return stop
                    rel = (store.relative_candle_path(tf,contract.underlying,contract.expiry,day) if store else
                           f"{tf}/{contract.underlying}/{contract.expiry}/{day}")
                    with repo.partition_lock(rel):
                        rows = repo.fetch_candles(contract.contract_id,"1m",day,day)
                        old = repo.fetch_candles(contract.contract_id,tf,day,day)
                        if rows or old:
                            result = aggregate_day(rows,day,tf,settings.session,now)
                            repo.invalidate_aggregation_day(contract.contract_id,tf,day)
                            repo.replace_derived_day(contract.contract_id,tf,day,result.candles)
                            back = repo.fetch_candles(contract.contract_id,tf,day,day)
                            if back != result.candles:
                                raise RuntimeError("Derived MySQL read-back differs from source aggregation")
                            if store is not None:
                                all_rows = repo.partition_candles(contract.underlying,contract.expiry,tf,day)
                                store.replace_derived_partition(rel,all_rows,handle.id)
                            # Checkpoints record completed full days only. Every requested day is
                            # re-evaluated on resume, so corrected 1m inputs cannot leave stale bars.
                            full_day = now >= session_bounds(day,settings.session)[1] + dt.timedelta(
                                minutes=settings.history.session_close_buffer_minutes)
                            if result.candles and not result.skipped and not result.invalid_rows and full_day:
                                repo.add_checkpoint_range(contract.contract_id,JOB_TYPE,tf,day,day,"VERIFIED")
                            stats["days"] += 1
                            stats["input_rows"] += len(rows)
                            stats["output_rows"] += len(back)
                            stats["skipped_buckets"] += result.skipped
                            for k in ("invalid_rows","missing_buckets","incomplete_buckets","forming_buckets"):
                                stats[k] += getattr(result,k)
                            if back:
                                stats["output_from"] = min(stats.get("output_from",day),day)
                                stats["output_to"] = max(stats.get("output_to",day),day)
                            handle.add(rows_raw=len(rows),rows_valid=len(rows)-result.invalid_rows,
                                       rows_invalid=result.invalid_rows,rows_stored=len(back))
                    repo.aggregation_progress(record,stats)
                    handle.heartbeat()
                    day += dt.timedelta(days=1)
            tf_state = ("PARTIAL" if stats["skipped_buckets"] or stats["invalid_rows"] else
                        "SUCCESS" if stats["output_rows"] else "NO_DATA")
            repo.aggregation_progress(record,stats,tf_state)
            if tf_state == "PARTIAL" or state == "PARTIAL":
                state = "PARTIAL"
            elif tf_state == "SUCCESS":
                state = "SUCCESS"
        except Exception as exc:
            repo.aggregation_progress(record,stats,"FAILED",f"{type(exc).__name__}: {exc}")
            raise
    return JobOutcome(state, totals)
