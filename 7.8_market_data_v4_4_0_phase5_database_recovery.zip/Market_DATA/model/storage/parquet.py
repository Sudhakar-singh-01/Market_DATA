"""
model/storage/parquet.py
Partitioned Parquet storage for analytical use (backtesting, Pandas/
NumPy analysis) -- spec Section 7.

Partition layout:
    data/raw/1m/<fyers_symbol>/<YYYY-MM-DD>.parquet
    data/processed/<timeframe>/<fyers_symbol>/<YYYY-MM-DD>.parquet

Partitioning by instrument + timeframe + date (one file per instrument
per calendar day) means:
  - A live update for "today" only ever reads/rewrites ONE small file
    (spec Section 7: "do not load an unnecessarily huge dataset into
    memory just to append a small live update").
  - Historical backtesting over a date range can filter to exactly the
    files it needs without scanning unrelated instruments/timeframes.

Append-safe / duplicate-aware (spec Section 7): write_batch() always
reads the existing partition file (if present), concatenates, drops
duplicate (candle_timestamp) rows keeping the newest, sorts, and
rewrites the single small file -- never blindly appends rows that
could duplicate an existing timestamp.
"""

import logging
from pathlib import Path

import pandas as pd
import pyarrow.pandas_compat  # noqa: F401 -- see comment below

from model.processing.models import Candle, IST

# pandas' DataFrame.to_parquet() lazily imports pyarrow.pandas_compat on
# its FIRST call, which in turn imports concurrent.futures.thread; that
# module registers an atexit hook via threading._register_atexit(). If
# that first call happens on a background thread (e.g. a live WebSocket
# tick callback) after the interpreter has started finalizing, the
# registration raises "RuntimeError: can't register atexit after
# shutdown". Importing it here, at module load time on the main thread
# (well before any background thread exists), forces that one-time
# import to happen safely up front instead.

log = logging.getLogger("market_data.storage.parquet")

_COLUMNS = [
    "internal_name", "fyers_symbol", "instrument_type", "exchange",
    "candle_timestamp", "timeframe", "open", "high", "low", "close",
    "volume", "source", "status",
]


def _base_dir(timeframe: str, data_root: str = "data") -> Path:
    return Path(data_root) / ("raw/1m" if timeframe == "1m" else f"processed/{timeframe}")


def _partition_path(candle: Candle, data_root: str = "data") -> Path:
    date_str = candle.timestamp.astimezone(IST).date().isoformat()
    safe_symbol = candle.fyers_symbol.replace(":", "_")
    return _base_dir(candle.timeframe, data_root) / safe_symbol / f"{date_str}.parquet"


def _candle_to_row(candle: Candle) -> dict:
    return {
        "internal_name": candle.internal_name,
        "fyers_symbol": candle.fyers_symbol,
        "instrument_type": candle.instrument_type,
        "exchange": candle.exchange,
        "candle_timestamp": candle.timestamp.astimezone(IST),
        "timeframe": candle.timeframe,
        "open": candle.open, "high": candle.high, "low": candle.low, "close": candle.close,
        "volume": candle.volume,
        "source": candle.source,
        "status": candle.status,
    }


def _row_to_candle(row) -> Candle:
    ts = row["candle_timestamp"]
    if ts.tzinfo is None:
        ts = ts.tz_localize(IST)
    return Candle(
        internal_name=row["internal_name"], fyers_symbol=row["fyers_symbol"],
        instrument_type=row["instrument_type"], exchange=row["exchange"],
        timestamp=ts.to_pydatetime(), timeframe=row["timeframe"],
        open=float(row["open"]), high=float(row["high"]), low=float(row["low"]), close=float(row["close"]),
        volume=int(row["volume"]), source=row["source"], status=row["status"],
    )


class ParquetCandleSink:
    """Implements controller.sinks.CandleSink against partitioned
    Parquet files."""

    def __init__(self, data_root=None):
        from model.storage_scope import cash_data_root
        self._data_root = str(cash_data_root()) if data_root is None else data_root
        self.last_write_state = {"status": "NOT_STARTED", "completed_partitions": [],
                                 "failed_partition": None, "pending_partitions": [], "rows": 0}

    def write_one(self, candle: Candle) -> None:
        self.write_batch([candle])

    def write_batch(self, candles: list) -> None:
        if not candles:
            self.last_write_state = {"status": "COMPLETE", "completed_partitions": [],
                                     "failed_partition": None, "pending_partitions": [], "rows": 0}
            return

        # Group by destination partition file so each file is touched
        # exactly once even if this batch spans multiple days/instruments.
        by_path: dict = {}
        for c in candles:
            path = _partition_path(c, self._data_root)
            by_path.setdefault(path, []).append(c)

        total_written = 0
        paths = list(by_path)
        completed = []
        self.last_write_state = {"status": "IN_PROGRESS", "completed_partitions": [],
                                 "failed_partition": None, "pending_partitions": [str(p) for p in paths],
                                 "rows": len(candles)}
        for index, path in enumerate(paths):
            try:
                total_written += self._write_partition(path, by_path[path])
            except Exception:
                self.last_write_state = {
                    "status": "PARTIAL" if completed else "FAILED",
                    "completed_partitions": list(completed), "failed_partition": str(path),
                    "pending_partitions": [str(p) for p in paths[index + 1:]], "rows": len(candles),
                    "failed_partition_may_have_changed": True,
                    "next_action": "Verify affected Parquet partitions against canonical SQL before retrying.",
                }
                raise
            completed.append(str(path))
            self.last_write_state["completed_partitions"] = list(completed)
            self.last_write_state["pending_partitions"] = [str(p) for p in paths[index + 1:]]

        from model.monitoring import commit_events
        commit_events("PARQUET_COMMIT",candles)
        self.last_write_state = {"status": "COMPLETE", "completed_partitions": list(completed),
                                 "failed_partition": None, "pending_partitions": [], "rows": len(candles)}
        log.info(f"ParquetCandleSink: wrote {total_written} row(s) across {len(by_path)} partition file(s)")

    def _write_partition(self, path: Path, candles: list) -> int:
        import os
        import tempfile
        from model.storage.locking import file_lock
        path.parent.mkdir(parents=True, exist_ok=True)
        with file_lock(str(path)+".lock"):
            existing=[]
            if path.exists():
                import pyarrow.parquet as pq
                if pq.ParquetFile(path).metadata.num_rows>20000:raise ValueError('Partition exceeds safe write bound')
                existing=pd.read_parquet(path).to_dict('records')
            rows={r['candle_timestamp']:r for r in existing}
            if len(rows)!=len(existing):raise ValueError('Stored duplicates require explicit review; no automatic deletion')
            for c in candles:
                new = _candle_to_row(c)
                old = rows.get(new["candle_timestamp"])
                replace = old is None or old["status"] == "OPEN" or (old["source"] == "FYERS_LIVE"
                    and new["source"] == "FYERS_HISTORICAL" and new["status"] == "CLOSED")
                if replace:
                    rows[new["candle_timestamp"]] = new
                elif (any(round(float(old[k]),4) != round(float(new[k]),4) for k in ("open","high","low","close"))
                      or int(old["volume"])!=int(new["volume"]) or old["source"]!=new["source"] or old["status"]!=new["status"]):
                    raise ValueError("Stored CLOSED Parquet values conflict; verification required (no automatic repair)")
            combined = pd.DataFrame(list(rows.values()),columns=_COLUMNS).sort_values("candle_timestamp").reset_index(drop=True)
            fd,tmp = tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=path.parent)
            os.close(fd)
            try:
                combined.to_parquet(tmp,index=False)
                if pd.read_parquet(tmp).to_dict('records') != combined.to_dict('records'):
                    raise ValueError("Parquet readback differs")
                os.replace(tmp,path)
            finally:
                if os.path.exists(tmp):os.unlink(tmp)
        return len(candles)

    def read_candles(self, fyers_symbol: str, timeframe: str, from_date: str, to_date: str) -> list:
        """Reads candles for one instrument/timeframe/date-range,
        filtering to only the partition files that fall in range
        (spec Section 7: 'read', 'filtering')."""
        safe_symbol = fyers_symbol.replace(":", "_")
        instrument_dir = _base_dir(timeframe, self._data_root) / safe_symbol
        if not instrument_dir.exists():
            return []

        dfs = []
        for file in sorted(instrument_dir.glob("*.parquet")):
            date_str = file.stem
            if from_date <= date_str <= to_date:
                dfs.append(pd.read_parquet(file))

        if not dfs:
            return []

        combined = pd.concat(dfs, ignore_index=True).sort_values("candle_timestamp")
        return [_row_to_candle(row) for _, row in combined.iterrows()]

    def cleanup_old_partitions(self, timeframe: str, retain_days: int, dry_run: bool = False) -> list:
        """
        Deletes partition files (one per instrument per calendar day)
        older than `retain_days` from today, for the given timeframe.
        Returns the list of file paths that were (or would be, if
        dry_run=True) deleted.

        Retention is intentionally per-timeframe: 1m data is by far
        the bulkiest and least useful indefinitely (call this with
        timeframe="1m" and a short retain_days), while derived
        timeframes (3m/5m/15m/30m/1h/1d) are much smaller and typically
        worth keeping far longer or indefinitely -- call this
        separately per timeframe with different retain_days, or not
        at all for timeframes you want to keep forever.

        This function only ever DELETES whole daily partition files
        that are entirely past the retention window -- it never
        rewrites a file to strip out old rows from it, and it never
        touches a file within the retention window.
        """
        import datetime

        base_dir = _base_dir(timeframe, self._data_root)
        if not base_dir.exists():
            return []

        cutoff_date = (datetime.date.today() - datetime.timedelta(days=retain_days)).isoformat()
        deleted = []

        for instrument_dir in base_dir.iterdir():
            if not instrument_dir.is_dir():
                continue
            for file in instrument_dir.glob("*.parquet"):
                date_str = file.stem
                if date_str < cutoff_date:
                    deleted.append(str(file))
                    if not dry_run:
                        file.unlink()

        if deleted:
            log.info(f"cleanup_old_partitions({timeframe}, retain_days={retain_days}, dry_run={dry_run}): "
                      f"{'would delete' if dry_run else 'deleted'} {len(deleted)} file(s)")
        return deleted
