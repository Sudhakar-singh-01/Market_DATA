"""
model/storage/mysql.py
MySQL persistence for canonical Candle data. Implements the CandleSink
and CheckpointStore interfaces defined in Part 2
(controller/sinks.py, model/fyers/historical.py) -- this is the "Part 3
implementation" those interfaces were designed for.

Does NOT create/modify schema (schema lives in database/schema.sql,
applied once by a human/DBA, not by application code).

Duplicate prevention (spec Section 5-6): relies on the database's own
UNIQUE KEY on (instrument_id, timeframe, candle_timestamp) via
INSERT IGNORE, exactly as Part 2's historical pipeline already did --
never relies on application-side-only duplicate checking.

Bulk insert (spec Section 6): write_batch() executes all rows in ONE
transaction. Rows are executed individually within that transaction
(not a single multi-value INSERT) so rowcount can be checked per row
for accurate inserted/duplicate accounting -- Part 2's requirement for
accurate counts takes priority over maximum raw insert throughput.
"""

import logging
from typing import Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from model.processing.models import Candle, IST
from model.config.instrument_loader import Instrument

log = logging.getLogger("market_data.storage.mysql")


_ENGINE_CACHE: dict = {}


def get_engine(db_url: str) -> Engine:
    """Cached per URL: reuse one connection pool instead of building a new engine per call."""
    engine = _ENGINE_CACHE.get(db_url)
    if engine is None:
        # pool_pre_ping: recover from stale/dropped connections; pool_recycle: avoid MySQL wait_timeout drops
        engine = create_engine(db_url, pool_pre_ping=True, pool_recycle=1800, connect_args={"connect_timeout": 5})
        _ENGINE_CACHE[db_url] = engine
    return engine


def build_db_url(host: str, port: int, name: str, user: str, password: str) -> str:
    host = "127.0.0.1" if str(host).strip().lower() == "localhost" else host  # "localhost" can add seconds per new connection on Windows (IPv6 fallback)
    from sqlalchemy.engine import URL
    return URL.create("mysql+pymysql", username=user, password=password, host=host, port=port, database=name).render_as_string(hide_password=False)


# ---------------------------------------------------------------- Instrument metadata

def get_or_create_instrument(engine: Engine, instrument: Instrument) -> int:
    with engine.begin() as conn:
        row = conn.execute(
            text("SELECT id FROM instruments WHERE fyers_symbol = :fs"),
            {"fs": instrument.fyers_symbol},
        ).fetchone()
        if row:
            return row[0]

        result = conn.execute(
            text("""
                INSERT INTO instruments (internal_name, fyers_symbol, exchange, instrument_type, category, is_active)
                VALUES (:internal_name, :fyers_symbol, :exchange, :instrument_type, :category, :is_active)
            """),
            {
                "internal_name": instrument.internal_name,
                "fyers_symbol": instrument.fyers_symbol,
                "exchange": instrument.exchange,
                "instrument_type": instrument.instrument_type,
                "category": instrument.category,
                "is_active": instrument.active,
            },
        )
        return result.lastrowid


def sync_all_instruments(engine: Engine, instruments) -> dict:
    """
    Proactively upserts EVERY instrument from instruments/stocks.yaml +
    indices.yaml into MySQL's instruments table, regardless of whether
    any candle has ever been fetched for it.

    Without this, a symbol only appears in the instruments table (and
    therefore in the admin dashboard's Instruments tab, or any SQL
    query against it) the first time a candle happens to be written
    for it via get_or_create_instrument() -- so adding a new symbol to
    the YAML doesn't show up anywhere in MySQL until you've actually
    run historical/live for it at least once. This function closes
    that gap: run it any time after editing stocks.yaml/indices.yaml
    to make YAML and MySQL agree immediately.

    Also updates is_active/exchange/instrument_type for instruments
    that already exist, so toggling `active: false` in YAML and
    re-running this reflects in MySQL too (get_or_create_instrument
    alone never updates an existing row).
    """
    created = 0
    updated = 0

    with engine.begin() as conn:
        for instrument in instruments.all_instruments():
            row = conn.execute(
                text("SELECT id, exchange, instrument_type, category, is_active FROM instruments WHERE fyers_symbol = :fs"),
                {"fs": instrument.fyers_symbol},
            ).fetchone()

            if row is None:
                conn.execute(
                    text("""
                        INSERT INTO instruments (internal_name, fyers_symbol, exchange, instrument_type, category, is_active)
                        VALUES (:internal_name, :fyers_symbol, :exchange, :instrument_type, :category, :is_active)
                    """),
                    {
                        "internal_name": instrument.internal_name, "fyers_symbol": instrument.fyers_symbol,
                        "exchange": instrument.exchange, "instrument_type": instrument.instrument_type,
                        "category": instrument.category, "is_active": instrument.active,
                    },
                )
                created += 1
            else:
                changed = (
                    row[1] != instrument.exchange or row[2] != instrument.instrument_type
                    or row[3] != instrument.category or bool(row[4]) != instrument.active
                )
                if changed:
                    conn.execute(
                        text("""
                            UPDATE instruments
                            SET exchange = :exchange, instrument_type = :instrument_type,
                                category = :category, is_active = :is_active
                            WHERE id = :id
                        """),
                        {
                            "exchange": instrument.exchange, "instrument_type": instrument.instrument_type,
                            "category": instrument.category, "is_active": instrument.active, "id": row[0],
                        },
                    )
                    updated += 1

    log.info(f"sync_all_instruments: created={created} updated={updated} unchanged={len(instruments.all_instruments()) - created - updated}")
    return {"created": created, "updated": updated, "total": len(instruments.all_instruments())}


# ---------------------------------------------------------------- Candle storage (CandleSink)

class MySQLCandleSink:
    """Implements controller.sinks.CandleSink against MySQL."""

    def __init__(self, engine: Engine, instrument_registry):
        self._engine = engine
        self._instruments = instrument_registry
        self._instrument_id_cache: dict = {}
        from model.monitoring import configure
        try:configure(engine)
        except Exception:pass

    def _instrument_id(self, fyers_symbol: str) -> int:
        if fyers_symbol not in self._instrument_id_cache:
            instrument = next(
                (i for i in self._instruments.all_instruments() if i.fyers_symbol == fyers_symbol), None
            )
            if instrument is None:
                raise ValueError(f"No configured instrument found for fyers_symbol '{fyers_symbol}'")
            self._instrument_id_cache[fyers_symbol] = get_or_create_instrument(self._engine, instrument)
        return self._instrument_id_cache[fyers_symbol]

    def write_one(self, candle: Candle) -> None:
        self.write_batch([candle])

    def write_batch(self, candles: list) -> list:
        self.last_conflicts = self.last_stored = self.last_duplicates = 0
        if not candles:
            return []

        rows = []
        for c in candles:
            rows.append({
                "instrument_id": self._instrument_id(c.fyers_symbol),
                "timeframe": c.timeframe,
                "candle_timestamp": c.timestamp,
                "open": c.open, "high": c.high, "low": c.low, "close": c.close,
                "volume": c.volume,
                "source": c.source,
                "status": c.status,
            })

        from dataclasses import replace
        accepted = []
        self.last_conflicts = 0
        self.last_stored = 0
        self.last_duplicates = 0
        with self._engine.begin() as conn:
            for c,row in zip(candles,rows):
                before = conn.execute(text("SELECT open,high,low,close,volume,source,status FROM candles WHERE instrument_id=:instrument_id AND timeframe=:timeframe AND candle_timestamp=:candle_timestamp FOR UPDATE"),row).mappings().first()
                # Canonical historical CLOSED rows are immutable; historical data
                # may supersede provisional LIVE, and OPEN may become CLOSED.
                guard = "(status='OPEN' OR (source='FYERS_LIVE' AND VALUES(source)='FYERS_HISTORICAL' AND VALUES(status)='CLOSED'))"
                fields = ("open","high","low","close","volume","source","status")
                updates = ",".join(f"{k}=IF({guard},VALUES({k}),{k})" for k in fields)
                conn.execute(text("INSERT INTO candles (instrument_id,timeframe,candle_timestamp,open,high,low,close,volume,source,status) "
                    "VALUES (:instrument_id,:timeframe,:candle_timestamp,:open,:high,:low,:close,:volume,:source,:status) "
                    "ON DUPLICATE KEY UPDATE "+updates),row)
                old = conn.execute(text("SELECT open,high,low,close,volume,source,status FROM candles WHERE "
                    "instrument_id=:instrument_id AND timeframe=:timeframe AND candle_timestamp=:candle_timestamp"),row).mappings().one()
                same = all(round(float(old[k]),4)==round(float(row[k]),4) for k in ("open","high","low","close")) and int(old["volume"])==int(row["volume"])
                changed = before is None or dict(before)!=dict(old)
                self.last_stored += changed
                self.last_duplicates += not changed and same
                self.last_conflicts += not same
                accepted.append(replace(c,open=float(old["open"]),high=float(old["high"]),low=float(old["low"]),
                    close=float(old["close"]),volume=int(old["volume"]),source=old["source"],status=old["status"]))
        from model.monitoring import commit_events
        commit_events("SQL_COMMIT",accepted)
        return accepted


# ---------------------------------------------------------------- Checkpoint storage

class MySQLCheckpointStore:
    """Implements model.fyers.historical.CheckpointStore against MySQL."""

    def __init__(self, engine: Engine):
        self._engine = engine

    def get_last_synced_date(self, fyers_symbol: str, timeframe: str) -> Optional[str]:
        with self._engine.begin() as conn:
            row = conn.execute(
                text("""
                    SELECT synced_through_date FROM checkpoints
                    WHERE fyers_symbol = :fs AND timeframe = :tf
                """),
                {"fs": fyers_symbol, "tf": timeframe},
            ).fetchone()
        return row[0].isoformat() if row and row[0] else None

    def save_checkpoint(self, fyers_symbol: str, timeframe: str, synced_through_date: str) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                text("""
                    INSERT INTO checkpoints (fyers_symbol, timeframe, synced_through_date)
                    VALUES (:fs, :tf, :date)
                    ON DUPLICATE KEY UPDATE synced_through_date = GREATEST(synced_through_date, :date)
                """),
                {"fs": fyers_symbol, "tf": timeframe, "date": synced_through_date},
            )


# ---------------------------------------------------------------- Job history (ingestion_jobs)

class MySQLJobRecorder:
    """
    Implements controller.sinks.JobRecorder against MySQL's
    ingestion_jobs table. This table existed in database/schema.sql
    from Part 3 but nothing wrote to it -- historical_controller.py
    and timeframe_controller.py now call this after every instrument
    (and once per whole batch) so job history is queryable in MySQL,
    not just visible in log files.
    """

    def __init__(self, engine: Engine):
        self._engine = engine

    def record(
        self, job_type: str, fyers_symbol: Optional[str], timeframe: Optional[str],
        from_date: Optional[str], to_date: Optional[str], status: str,
        raw_count: Optional[int] = None, valid_count: Optional[int] = None,
        invalid_count: Optional[int] = None, error_message: Optional[str] = None,
    ) -> int:
        with self._engine.begin() as conn:
            result = conn.execute(
                text("""
                    INSERT INTO ingestion_jobs
                        (job_type, fyers_symbol, timeframe, from_date, to_date, status,
                         raw_count, valid_count, invalid_count, error_message, finished_at)
                    VALUES
                        (:job_type, :fyers_symbol, :timeframe, :from_date, :to_date, :status,
                         :raw_count, :valid_count, :invalid_count, :error_message, NOW())
                """),
                {"job_type": job_type, "fyers_symbol": fyers_symbol, "timeframe": timeframe,
                 "from_date": from_date, "to_date": to_date, "status": status,
                 "raw_count": raw_count, "valid_count": valid_count, "invalid_count": invalid_count,
                 "error_message": error_message},
            )
            return result.lastrowid


# ---------------------------------------------------------------- Reads (for timeframe_controller / api_view)

def read_candles(engine: Engine, fyers_symbol: str, timeframe: str, from_date: str, to_date: str, instrument: Instrument) -> list:
    """
    Reads stored candles for one instrument/timeframe/date-range,
    reconstructed as canonical Candle objects. Works for 1m OR any
    derived timeframe (3m/5m/15m/30m/1h/1d) -- the `candles` table holds
    all timeframes together (database/schema.sql), so this is a single
    general-purpose read function, not one-per-timeframe.
    """
    with engine.begin() as conn:
        rows = conn.execute(
            text("""
                SELECT c.candle_timestamp, c.open, c.high, c.low, c.close, c.volume, c.source, c.status
                FROM candles c
                JOIN instruments i ON i.id = c.instrument_id
                WHERE i.fyers_symbol = :fs AND c.timeframe = :timeframe
                  AND DATE(c.candle_timestamp) BETWEEN :from_date AND :to_date
                ORDER BY c.candle_timestamp ASC
            """),
            {"fs": fyers_symbol, "timeframe": timeframe, "from_date": from_date, "to_date": to_date},
        ).fetchall()

    return [
        Candle(
            internal_name=instrument.internal_name,
            fyers_symbol=instrument.fyers_symbol,
            instrument_type=instrument.instrument_type,
            exchange=instrument.exchange,
            # MySQL's DATETIME column has no timezone concept -- reading
            # it back gives a NAIVE datetime with the same wall-clock
            # value we wrote (IST). Re-attach the IST tzinfo here so
            # this round-trips correctly.
            timestamp=row[0].replace(tzinfo=IST), timeframe=timeframe,
            open=float(row[1]), high=float(row[2]), low=float(row[3]), close=float(row[4]),
            volume=int(row[5]), source=row[6], status=row[7],
        )
        for row in rows
    ]


def read_1m_candles(engine: Engine, fyers_symbol: str, from_date: str, to_date: str, instrument: Instrument) -> list:
    """Backward-compatible 1m-only wrapper around read_candles() --
    kept because existing callers (controller/timeframe_controller.py's
    reader signature) already use this name/signature."""
    return read_candles(engine, fyers_symbol, "1m", from_date, to_date, instrument)
