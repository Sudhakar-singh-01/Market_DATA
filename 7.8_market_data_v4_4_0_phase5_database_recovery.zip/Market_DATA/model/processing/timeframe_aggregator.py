"""Shared OHLCV combiner and Cash session-anchored aggregation.

Closed output requires every unique, valid, CLOSED source minute in the
session-clipped bucket. Incomplete inputs are visible as missing derived bars.
"""

import datetime
import logging
from dataclasses import dataclass, field
from typing import Optional

from model.processing.models import Candle

log = logging.getLogger("market_data.processing.timeframe_aggregator")

# Fixed-duration timeframes, in seconds. "1d" is handled separately
# (calendar-date based, not a fixed duration) -- see _bucket_start().
_TIMEFRAME_SECONDS = {
    "3m": 180,
    "5m": 300,
    "15m": 900,
    "30m": 1800,
    "1h": 3600,
}

SUPPORTED_TIMEFRAMES = list(_TIMEFRAME_SECONDS.keys()) + ["1d"]


def _bucket_start(ts: datetime.datetime, timeframe: str) -> datetime.datetime:
    from model.config.market_calendar import session_windows, IST
    if timeframe not in SUPPORTED_TIMEFRAMES:
        raise ValueError(f"Unsupported derived timeframe: {timeframe}")
    ts = ts.replace(tzinfo=IST) if ts.tzinfo is None else ts.astimezone(IST)
    windows = session_windows(ts.date())
    window = next((w for w in windows if w[0] <= ts < w[1]), None)
    if window is None:
        raise ValueError("Timestamp is outside the configured cash session")
    if timeframe == "1d":
        return windows[0][0]
    start = window[0]
    minutes = _TIMEFRAME_SECONDS[timeframe] // 60
    return start + datetime.timedelta(minutes=int((ts-start).total_seconds()//60)//minutes*minutes)


def bucket_minutes(start, timeframe):
    """Expected minute starts and final close; daily spans intervals but never their breaks."""
    from model.config.market_calendar import session_windows, expected_starts
    windows = session_windows(start.date())
    if timeframe == "1d" and windows and start == windows[0][0]:
        return set(expected_starts(start.date())), windows[-1][1]
    window = next((w for w in windows if w[0] <= start < w[1]), None)
    if window is None or timeframe not in _TIMEFRAME_SECONDS:
        return set(), start
    end = min(window[1], start + datetime.timedelta(seconds=_TIMEFRAME_SECONDS[timeframe]))
    return {start+datetime.timedelta(minutes=i) for i in range(int((end-start).total_seconds()//60))}, end


def _complete(rows, start, timeframe, now=None):
    from model.config.market_calendar import IST
    import math
    expected, end = bucket_minutes(start, timeframe)
    if not expected:
        return False
    now = now or datetime.datetime.now(IST)
    stamps = [c.timestamp for c in rows]
    valid = all(c.timeframe == "1m" and c.status == "CLOSED" and c.volume >= 0
        and all(math.isfinite(float(v)) and v > 0 for v in (c.open,c.high,c.low,c.close))
        and c.low <= min(c.open,c.close) <= max(c.open,c.close) <= c.high for c in rows)
    return valid and end <= now and len(stamps) == len(expected) and set(stamps) == expected


def _combine(candles: list, bucket_start: datetime.datetime, timeframe: str, status: str) -> Candle:
    """
    Combines a non-empty, chronologically-ordered list of 1m Candles
    (all belonging to the same instrument) into one higher-timeframe
    Candle, per spec Section 11:
        open   = first candle's open
        high   = max of highs
        low    = min of lows
        close  = last candle's close
        volume = sum of volumes
    """
    first, last = candles[0], candles[-1]
    return Candle(
        internal_name=first.internal_name,
        fyers_symbol=first.fyers_symbol,
        instrument_type=first.instrument_type,
        exchange=first.exchange,
        timestamp=bucket_start,
        timeframe=timeframe,
        open=first.open,
        high=max(c.high for c in candles),
        low=min(c.low for c in candles),
        close=last.close,
        volume=sum(c.volume for c in candles),
        source=first.source,
        status=status,
    )


def aggregate_1m_to_timeframe(one_minute_candles: list, timeframe: str) -> list:
    """Only complete CLOSED session buckets; missing minutes are never invented."""
    if timeframe not in SUPPORTED_TIMEFRAMES:
        raise ValueError(f"Unsupported timeframe: {timeframe}")
    buckets = {}
    for c in sorted(one_minute_candles, key=lambda x:x.timestamp):
        try:
            start = _bucket_start(c.timestamp, timeframe)
        except ValueError:
            continue
        buckets.setdefault((c.fyers_symbol,start), []).append(c)
    return [_combine(rows,start,timeframe,"CLOSED") for (symbol,start),rows in buckets.items()
            if _complete(rows,start,timeframe)]


@dataclass
class _BucketState:
    bucket_start: datetime.datetime
    candles: list = field(default_factory=list)


class LiveTimeframeAggregator:
    """
    Live INCREMENTAL aggregation across MULTIPLE instruments and
    MULTIPLE timeframes simultaneously, each isolated independently
    (spec Section 16-17: "one 1m candle may contribute to 3m/5m/15m/30m/
    1h/1d state" and "one instrument must never affect another").

    Usage: call on_1m_candle() once per CLOSED, validated 1m Candle as
    it arrives from the live pipeline. Returns the list of any derived
    candles that just CLOSED as a result (usually 0, sometimes several
    at once if e.g. a 1h and a 1d boundary close simultaneously).
    """

    def __init__(self, timeframes: Optional[list] = None):
        self._timeframes = timeframes or list(_TIMEFRAME_SECONDS.keys()) + ["1d"]
        for tf in self._timeframes:
            if tf not in SUPPORTED_TIMEFRAMES:
                raise ValueError(f"Unsupported derived timeframe: {tf}")
        # keyed by (fyers_symbol, timeframe)
        self._state: dict = {}

    def on_1m_candle(self, one_minute_candle: Candle) -> list:
        if one_minute_candle.timeframe != "1m":
            raise ValueError(
                f"LiveTimeframeAggregator.on_1m_candle() received a non-1m candle: "
                f"timeframe='{one_minute_candle.timeframe}'"
            )

        closed = []
        for tf in self._timeframes:
            result = self._feed_one_timeframe(one_minute_candle, tf)
            if result is not None:
                closed.append(result)
        return closed

    def _feed_one_timeframe(self, candle: Candle, timeframe: str) -> Optional[Candle]:
        key = (candle.fyers_symbol, timeframe)
        try:
            bucket_start = _bucket_start(candle.timestamp, timeframe)
        except ValueError:
            return None
        state = self._state.get(key)

        if state is not None and bucket_start < state.bucket_start:
            log.warning(
                f"Dropping out-of-order 1m candle for {candle.fyers_symbol} [{timeframe}]: "
                f"bucket {bucket_start} is before current bucket {state.bucket_start}"
            )
            return None

        closed_candle = None
        if state is None or bucket_start > state.bucket_start:
            if state is not None and _complete(state.candles, state.bucket_start, timeframe):
                closed_candle = _combine(state.candles, state.bucket_start, timeframe, status="CLOSED")
                log.info(f"Derived candle closed: {candle.fyers_symbol} [{timeframe}] {state.bucket_start}")
            state = _BucketState(bucket_start=bucket_start, candles=[candle])
        else:
            state.candles.append(candle)

        self._state[key] = state
        return closed_candle

    def current_open_candle(self, fyers_symbol: str, timeframe: str) -> Optional[Candle]:
        """Read-only view of the still-forming (OPEN) higher-timeframe
        candle, without closing it -- lets a caller inspect in-progress
        state (spec Section 13: distinguish OPEN vs CLOSED)."""
        state = self._state.get((fyers_symbol, timeframe))
        if state is None or not state.candles:
            return None
        return _combine(state.candles, state.bucket_start, timeframe, status="OPEN")

    def flush(self, fyers_symbol: str, timeframe: str) -> Optional[Candle]:
        """Force-closes the in-progress bucket (e.g. at shutdown/market
        close) even though no next-bucket candle arrived to trigger the
        normal rollover."""
        key = (fyers_symbol, timeframe)
        state = self._state.pop(key, None)
        if state is None or not state.candles:
            return None
        return (_combine(state.candles, state.bucket_start, timeframe, status="CLOSED")
                if _complete(state.candles, state.bucket_start, timeframe) else None)

    def flush_all(self) -> list:
        keys = list(self._state.keys())
        results = []
        for fyers_symbol, timeframe in keys:
            candle = self.flush(fyers_symbol, timeframe)
            if candle is not None:
                results.append(candle)
        return results
