"""
model/processing/candle_builder.py
Aggregates a stream of Ticks into 1-minute OHLCV buckets, per symbol.
Part 2 scope: 1-minute ONLY (spec Section 16 -- "must not generate
3m/5m/15m/etc").

Strictly separated from model/fyers/websocket.py (spec Section 15):
this module knows nothing about sockets, subscriptions, or reconnects
-- it only consumes Tick objects and emits candle buckets.

VOLUME SEMANTICS (spec Section 18 -- must be explicit, not assumed):
    FYERS's live SymbolUpdate 'vol_traded_today' field (see
    model/processing/normalizer.py's Tick.volume_traded_today) is
    widely documented by third parties as a CUMULATIVE running total
    for the trading day, not a per-tick incremental value. This could
    NOT be independently re-confirmed against a live FYERS response at
    implementation time -- flagged per spec Section 28.

    Given that assumption, a 1-minute candle's volume is computed as:
        (cumulative volume at minute close) - (cumulative volume at minute open)
    which is what _finalize() below does. If a tick arrives with no
    volume_traded_today at all (None), the running total simply isn't
    advanced for that tick -- volume is never fabricated or estimated.

    If this cumulative-volume assumption turns out to be wrong once
    verified against real messages, only this module's volume
    calculation needs to change -- the rest of the pipeline is
    unaffected.

OUT-OF-ORDER / LATE TICKS (spec Section 17):
    If a tick's minute bucket is EARLIER than the symbol's current
    in-progress bucket, it is a late/out-of-order tick relative to an
    already-advancing candle. It is logged and DROPPED -- a CLOSED (or
    already-rolled-past) candle is never reopened or silently mutated.
    If a tick's minute bucket is LATER, that's the normal case that
    triggers a rollover (see on_tick()).
"""

import datetime
import logging
from dataclasses import dataclass

from model.processing.models import Tick

log = logging.getLogger("market_data.processing.candle_builder")


def _period_start(ts: datetime.datetime) -> datetime.datetime:
    return ts.replace(second=0, microsecond=0)


@dataclass
class CandleBucket:
    """Raw, instrument-metadata-free OHLCV accumulator for one symbol's
    current or just-completed minute. Enriched into a full canonical
    Candle by normalizer.normalize_live_candle() -- this class
    deliberately does NOT know about internal_name/exchange/etc."""
    fyers_symbol: str
    period_start: datetime.datetime  # tz-aware, Asia/Kolkata
    open: float
    high: float
    low: float
    close: float
    volume_start: int
    volume_last: int

    @property
    def volume(self) -> int:
        return max(0, self.volume_last - self.volume_start)


class CandleBuilder1m:
    """One instance handles 1-minute bars across MANY symbols
    independently (spec Section 16: "Handle symbol-specific state
    independently")."""

    def __init__(self, on_candle_closed=None):
        self._on_candle_closed = on_candle_closed
        self._in_progress: dict = {}

    def on_tick(self, tick: Tick):
        """
        Feeds one tick. Returns the just-CLOSED bucket if this tick
        rolled the symbol's bucket over into a new minute, else None
        (still accumulating into the current/OPEN bucket).
        """
        period_start = _period_start(tick.timestamp)
        current = self._in_progress.get(tick.fyers_symbol)

        if current is not None and period_start < current.period_start:
            log.warning(
                f"Dropping out-of-order/late tick for {tick.fyers_symbol}: "
                f"tick period {period_start} is before current bucket {current.period_start}"
            )
            return None

        closed = None
        if current is None or period_start > current.period_start:
            if current is not None:
                closed = current
                self._emit_closed(closed)
            current = CandleBucket(
                fyers_symbol=tick.fyers_symbol,
                period_start=period_start,
                open=tick.ltp,
                high=tick.ltp,
                low=tick.ltp,
                close=tick.ltp,
                volume_start=tick.volume_traded_today or 0,
                volume_last=tick.volume_traded_today or 0,
            )
        else:
            current.high = max(current.high, tick.ltp)
            current.low = min(current.low, tick.ltp)
            current.close = tick.ltp
            if tick.volume_traded_today is not None:
                current.volume_last = tick.volume_traded_today

        self._in_progress[tick.fyers_symbol] = current
        return closed

    def current_bucket(self, fyers_symbol: str):
        """Read-only access to the still-forming (OPEN) bucket for a
        symbol, without finalizing it -- lets a caller inspect an
        in-progress candle if needed (spec Section 17: downstream
        systems should be able to distinguish OPEN vs CLOSED)."""
        return self._in_progress.get(fyers_symbol)

    def flush(self, fyers_symbol: str):
        """Force-closes the in-progress bucket for a symbol (e.g. at
        market close or shutdown) even though no next-minute tick
        arrived to trigger the normal rollover (spec Section 17:
        session end handling)."""
        current = self._in_progress.pop(fyers_symbol, None)
        if current is None:
            return None
        self._emit_closed(current)
        return current

    def flush_all(self) -> list:
        symbols = list(self._in_progress.keys())
        return [b for b in (self.flush(s) for s in symbols) if b is not None]

    def _emit_closed(self, bucket: CandleBucket):
        log.info(f"1m candle closed: {bucket.fyers_symbol} {bucket.period_start} vol={bucket.volume}")
        if self._on_candle_closed:
            self._on_candle_closed(bucket)
