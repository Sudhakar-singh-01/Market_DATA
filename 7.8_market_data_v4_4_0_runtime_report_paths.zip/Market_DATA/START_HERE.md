# Current update: backend logic and CLI verification

Latest package: `7.8_market_data_v4_4_0_runtime_report_paths.zip`.
Read **docs/REPORT_PATH_HOTFIX.md**. Item2–3 relative reports/plans now follow
TIOS_HOME across code upgrades; absolute paths still work. Place/select the two
old value reports once; no automatic migration/overwrite. Missing paths are shown.

Latest package: `7.8_market_data_v4_4_0_data23_recheck.zip`.
Read **docs/DATA23_COMPLETION.md** for a bounded provider recheck of the six
remaining empty scopes, using the earlier FNO value JSON reports. It does not
import data or claim all items2–3 passed. Next step/UI held; source access pending.

Latest package: `7.8_market_data_v4_4_0_data_offline_fno_verify.zip`.
Read **docs/DATA_OFFLINE_FNO_VERIFY.md** for bounded historical F&O value/coverage
and optional-field availability checks. No live market/API server/token needed.
Items 2–3 source/unit and full alignment gates remain pending; UI remains paused.

Latest package: `7.8_market_data_v4_4_0_data_phase3_underlying.zip`.
Read **docs/DATA_PHASE3_UNDERLYING.md** for reviewed NIFTY/BANKNIFTY underlying-index
collection and read-only verification. Existing runtime profile stays in place.

Latest package: `7.8_market_data_v4_4_0_data_phase2_session_units.zip`.
Read **docs/DATA_PHASE2_SESSION_UNITS.md**. Existing runtime configuration remains
valid; this adds read-only session/unit reports and numeric parser regressions.
AUDIT_FINDINGS is expected while primary timing/unit evidence is unconfirmed.

Latest full package: `7.8_market_data_v4_4_0_data_phase1_inventory.zip`.
Read **docs/DATA_PHASE1_INVENTORY.md** for the new read-only inventory command,
bounded scope, status meanings and Windows examples. This adds data-plan item 1;
later data items have not been started.

Latest package: `7.8_market_data_v4_4_0_windows_jobs_hotfix.zip`.
Read **docs/WINDOWS_JOBS_HOTFIX.md**. User Windows evidence now confirms Storage
and Operations pass; the remaining Jobs test environment issue is corrected here.

Latest package: `7.8_market_data_v4_4_0_recovery_windows_reset.zip`.
Read **docs/RECOVERY_WINDOWS_RESET.md** for CASH long-path changes, visible test
failures, unresolved Jobs status and the authorized Windows reset sequence.

Latest follow-up: **docs/WINDOWS_SCHEMA_CLI_HOTFIX.md** documents the schema
comparison/date-message fixes and pending Windows failures. Use the full package
`7.8_market_data_v4_4_0_schema_cli_hotfix.zip`.

UI development is paused. Start with **docs/BACKEND_LOGIC_REPORT.md** and
**docs/BACKEND_CLI_RUNBOOK.md** for the current backend package. In Windows CMD,
from the project directory with dependencies installed, run
`tools\market_logic_check.cmd` for isolated code checks. Production data verification
is separate. No reset or migration is required just to run these checks. The
historical setup/migration examples below are not an instruction to apply DDL
automatically when upgrading an existing installation.

# New UI entry point

Latest UI replacement instructions: **docs/UI_REBUILD.md**.
All old-to-new features: **docs/UI_FEATURE_MAP.md**.
Use a fresh extracted code folder with the existing TIOS_HOME; do not initialize
or reset runtime state. The new top-right task center shows multiple tasks.
Historical release instructions below are references; the new workspace routing
supersedes their old sidebar names.

# TIOS Market Data — Release 4

Existing Python/Streamlit project ka extension. Cash aur F&O ke existing databases/storage retained hain. Is release mein Data Quality & Verification, Master Tables, Historical Smart Fetch, durable Cash jobs aur monitoring add hue hain. Koi real-money order execution add nahi hua.

## Windows par update

1. Dashboard, live feed aur workers stop karein. Existing project/config/data ka backup rakhein. ZIP ko **alag folder** mein extract karein. Apna `config/.env`, instrument YAML customizations aur existing `data/` preserve/copy karein. ZIP ke naye `config/fno_settings.yaml` aur `config/holidays.yaml` ko review karke apni settings merge karein; purani API limits blindly copy na karein.
2. Project root (jahan `main.py` hai) mein apna existing Python environment activate karein. Missing dependencies ke liye:

   ```bat
   python -m pip install -r requirements.txt
   ```

   Existing FYERS SDK 3.1.10 par regular history/live supported hain. Expired-history discovery/data methods is SDK mein absent hain; app `NOT AVAILABLE` dikhata hai. SDK upgrade is release mein automatically nahi kiya gaya. `docs/RELEASE4_API_SPEC.md` padhein.
3. Apne real DB host/port/user/password retain karein. `DB_NAME=market_data` aur `FNO_DB_NAME=fno_market_data` alag rakhein. **Existing databases/schema recreate ya drop na karein.**
4. Metadata changes preview karein, phir apply karein:

   ```bat
   python main.py quality-migrate
   python main.py quality-migrate --apply
   python main.py fno-migrate
   python main.py fno-migrate --apply
   ```

   Cash migration existing `ingestion_jobs` extend karti hai aur `data_quality_results`, `pipeline_events` banati hai. Candles/checkpoints rewrite nahi hote. FNO migrations idempotent hain; pehle se applied hon toh repeat DDL nahi hoti. MySQL DDL atomic rollback nahi deta: migration interrupted ho toh preview/reapply pending steps karein.
5. Dashboard:

   ```bat
   python -m streamlit run ui/dashboard.py --server.address 127.0.0.1
   ```

   `http://localhost:8501` kholein. Existing user/admin password hashes reuse hote hain. Sidebar: Dashboard, Market Data, F&O, Master Tables; administration sirf admin ke liye.

## Pehla verification run

Apne instrument aur available dates use karein. Udaharan:

```bat
python main.py verify --symbols SBIN --from 2026-10-19 --to 2026-10-23 --run
python main.py pipeline-jobs
python main.py quality-export --job 1 --output exports/verification-1.json
```

Export mein `--job` ko actual verification ID se replace karein. Verification **read-only source inspection** hai. `PARTIAL` ya `NOT_VERIFIED` par report padhein; automatic delete, overwrite, reset ya re-fetch nahi hota.

## Smart Fetch aur aggregation

```bat
python main.py smart-fetch --symbols SBIN --from 2026-10-19 --to 2026-10-23 --preview
python main.py smart-fetch --symbols SBIN --from 2026-10-19 --to 2026-10-23 --run
python main.py pipeline-aggregate --symbols SBIN --from 2026-10-19 --to 2026-10-23 --timeframes 3m 5m 15m 30m 1h 1d --run
```

Covered minutes ke liye zero broker requests. SQL/Parquet mismatch, invalid data, unverified calendar ya unsupported lookback par fetch block hota hai. Sirf complete source buckets aggregate hote hain. Existing conflicting CLOSED bars ke liye explicit review chahiye; automatic repair nahi hai.

## Headless aur token recovery

```bat
python main.py pipeline-worker
python main.py pipeline-worker --schedule-eod --symbols SBIN HDFCBANK
python main.py pipeline-jobs --cancel 12
python main.py pipeline-jobs --resume 12 --run
```

`--schedule-eod` optional hai; latest completed verified session ko durable job banata hai (restart par same scope duplicate nahi). Existing `python main.py schedule` live open/close automation retain karta hai aur EOD durable queue use karta hai. Run only one scheduler. Cash aur F&O ke live modes ek account socket lock share karte hain; active mode stop karke switch karein. Simultaneous Cash+F&O multiplexing is release mein nahi hai.

Token expire ho toh job `INTERRUPTED`/`PARTIAL`/`FAILED` with authentication reason dikhayega. Existing manual FYERS login flow se token update karein. Dashboard mein **Reload credentials from .env** / F&O Settings mein **Reload FYERS credentials**, phir job explicitly resume karein. Automatic OAuth refresh assume nahi kiya gaya.

## Alerts aur monitoring

Market Data → Data Quality & Verification → Live Feed & Persistence mein actual Cash tick-reception samples, SQL commit aur Parquet commit timestamps/delays milenge. Migration ke baad ingestion restart karein. Purane data se telemetry fabricate nahi hoti.

Alerts default mein send nahi hote. `python main.py alerts-dispatch` pending preview hai. Telegram configure karne ke baad operator `--send` use kar sakta hai; details runbook mein hain. Testing mein koi real alert send nahi hua.

## Read before freeze

Provider-free backend validation ek isolated temporary profile mein run karne ke
liye Windows CMD se:

```bat
tools\phase9_windows_e2e.cmd
```

Yeh command production MySQL/FYERS acceptance replace nahi karta. Exact scope,
expected counts aur limitations `docs/AUDIT_PHASE_9_WINDOWS_E2E.md` mein hain.

- `docs/RELEASE4_IMPLEMENTATION.md`: requirement matrix, file mapping, verification rules, permissions, limitations.
- `docs/RELEASE4_RUNBOOK.md`: operations, recovery, bounded processing and acceptance checklist.
- `docs/RELEASE4_API_SPEC.md`: official FYERS/NSE sources and installed SDK capabilities.
- `docs/RELEASE4_TEST_REPORT.md`: actual test result and untested environments.
- `docs/AUDIT_PHASE_9_WINDOWS_E2E.md`: isolated one-command Windows backend validation.

Windows/MySQL 8.0 acceptance, real FYERS account entitlement, actual Enter-key browser interaction, and full strategy/analysis-engine integration remain explicit acceptance items. No production account/database was used during this build.

## Workflow UI update

Admin login ke baad Administration → Unified Workflow pehla entry hai. Missing
target/date-range hints, job-state guidance aur uncertain submission recovery
message updated hain. Scoped Windows checks: `docs/AUDIT_PHASE_10_UI.md`.
