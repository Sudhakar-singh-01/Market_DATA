"""Existing Streamlit entry point with grouped TIOS navigation."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import streamlit as st
from ui.auth import require_auth,current_role,logout
st.set_page_config(page_title='TIOS · Market Data',layout='wide')
if not require_auth("user"):st.stop()
st.sidebar.title('TIOS')
st.sidebar.caption('Market Data & F&O')
st.sidebar.write('Role:',current_role())
if st.sidebar.button('Log out',key='shell_logout'):logout();st.rerun()
nav={
 'Dashboard':[st.Page('home.py',title='Overview',default=True)],
 'Market Data':[
   st.Page('pages/2_Live_Market.py',title='Live Market'),
   st.Page('pages/3_Data_Explorer.py',title='Data Explorer'),
   st.Page('pages/4_Historical_Data.py',title='Historical Smart Fetch'),
   st.Page('pages/5_Aggregation.py',title='Aggregation'),
   st.Page('pages/7_Data_Quality.py',title='Data Quality & Verification'),
   st.Page('pages/11_Coverage_Heatmap.py',title='Coverage Heatmap'),
   st.Page('pages/6_Data_Flow.py',title='Data Flow'),
   st.Page('pages/8_Storage.py',title='Storage'),
   st.Page('pages/9_Logs.py',title='Logs'),
   st.Page('pages/10_API_Monitor.py',title='API Monitor')],
 'F&O':[st.Page('pages/30_FNO.py',title='F&O Management')],
 'Master Tables':[st.Page('pages/12_Master_Tables.py',title='Master Tables')],
}
if current_role()=='admin':
 nav['Administration']=[st.Page('pages/'+name,title=title) for name,title in [
 ('32_Admin_Unified_Workflow.py','Unified Workflow'),
 ('1_Admin.py','Configuration'),('20_Admin_Database.py','Database'),('21_Admin_Files.py','Files'),
 ('29_Admin_Database_Catalog.py','All Databases & Tables'),
 ('30_Admin_Schema_Manager.py','Schema Manager'),
 ('31_Admin_Backup_Recovery.py','Backup & Recovery'),
 ('33_Admin_Scoped_Cleanup.py','Scoped Data Cleanup'),
 ('34_Admin_Recovery_Drill.py','Recovery Verification'),
 ('22_Admin_Jobs.py','Jobs'),('23_Admin_Checkpoints.py','Checkpoints'),('24_Admin_Bulk_Delete.py','Bulk Delete'),
 ('25_Admin_Operations_Center.py','Operations'),('26_Admin_Audit_Log.py','Audit Log'),
 ('27_Admin_Security.py','Security'),('28_Admin_Data_Operations.py','Data Operations')]]
st.navigation(nav).run()
