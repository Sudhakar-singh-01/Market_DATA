"""User-reported preview/job fragment collision; isolated widget regression."""
from types import SimpleNamespace
from streamlit.testing.v1 import AppTest


def test_preview_and_persisted_jobs_have_distinct_download_widgets(monkeypatch):
    import ui.pipeline_page as page
    job={'id':1,'job_type':'SMART_FETCH','state':'RUNNING','started_at':None,'heartbeat_at':None,
         'rows_stored':10,'error':None,'result':{},'params':{}}
    service=SimpleNamespace(
        instruments=SimpleNamespace(all_instruments=lambda:[SimpleNamespace(internal_name='SBIN')]),
        engine=object(),store=SimpleNamespace(list=lambda **kwargs:[job]),
        smart_preview=lambda params:{'blocked':[],'items':[{'symbol':'SBIN'}],
                                     'requests_estimate':1,'complete_symbol_days':0})
    monkeypatch.setattr(page,'get_service',lambda:service)
    monkeypatch.setattr(page,'ready',lambda engine:True)
    monkeypatch.setattr(page,'current_role',lambda:'user')
    app=AppTest.from_string('from ui.pipeline_page import render\nrender("SMART_FETCH")').run()
    app.multiselect(key='SMART_FETCH_symbols').set_value(['SBIN']).run()
    next(b for b in app.button if b.label=='Preview missing ranges').click().run()
    assert not app.exception
    buttons=app.get('download_button')
    assert len(buttons)==2
    assert len({b.proto.id for b in buttons})==2
    app.run()
    assert not app.exception
