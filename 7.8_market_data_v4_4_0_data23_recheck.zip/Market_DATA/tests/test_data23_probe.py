import copy
import datetime as dt
import json
from types import SimpleNamespace as NS

import pytest
from sqlalchemy import event, text

from controller import data23_probe as probe, data23_probe_cli as cli
from model.fno.config import load_fno_settings
from test_read_api import env, seed, DAY


def report():
    return {'segment': 'FNO', 'from': str(DAY), 'to': str(DAY), 'checks': [
        {'contract_id': 1, 'symbol': 'NSE:TEST-OPT', 'date': str(DAY), 'timeframe': '1m',
         'status': 'NOT_VERIFIED', 'reason': 'NO_CANDLES_OBSERVED'}]}


def invoke(env, response, **kwargs):
    calls = []
    def history(data):
        calls.append(data)
        if isinstance(response, BaseException): raise response
        return response
    r = probe.probe_empty(env[0], load_fno_settings(), [report()], lambda: NS(history=history), **kwargs)
    return r, calls


def test_only_reported_empty_scopes_no_mutations_or_raw_provider_echo(env):
    queries = []
    event.listen(env[1]['FNO'], 'before_cursor_execute', lambda c, cu, s, p, ctx, m: queries.append(s))
    r, calls = invoke(env, {'s': 'ok', 'candles': [], 'message': 'access_token=SECRET'})
    assert r['checks'][0]['status'] == 'PROVIDER_NO_DATA_ON_RECHECK'
    assert r['summary']['history_call_attempts'] == len(calls) == 1
    assert calls[0]['symbol'] == 'NSE:TEST-OPT'
    assert calls[0]['range_from'] == calls[0]['range_to'] == str(DAY)
    assert not r['sql_modified'] and not r['market_data_modified'] and not r['unit_scale_verified']
    assert 'SECRET' not in json.dumps(r)
    assert not any(q.lstrip().upper().startswith(('INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP')) for q in queries)


def test_existing_data_skips_provider_without_claiming_values_verified(env):
    seed(env, 'FNO', n=1)
    r = probe.probe_empty(env[0], load_fno_settings(), [report()], lambda: pytest.fail('No refetch'))
    assert r['checks'][0]['status'] == 'STORED_ROWS_NOW_PRESENT_REVERIFY_VALUES'
    assert r['summary']['history_call_attempts'] == 0


def test_reused_master_id_and_today_block_before_provider(env):
    r = report(); r['checks'][0]['symbol'] = 'NSE:OTHER'
    with pytest.raises(ValueError):
        probe.probe_empty(env[0], load_fno_settings(), [r], lambda: pytest.fail('No request'))
    today = str(env[0].clock().date()); r = report()
    r['from'] = r['to'] = r['checks'][0]['date'] = today
    with pytest.raises(ValueError):
        probe.probe_empty(env[0], load_fno_settings(), [r], lambda: pytest.fail('No request'))


@pytest.mark.parametrize('kind', ['auth', 'rate', 'network', 'interrupt'])
def test_failed_or_interrupted_request_stops_remaining_scopes_and_preserves_result(env, kind):
    with env[1]['FNO'].begin() as c:
        c.execute(text("INSERT INTO fno_instruments (id,fyers_symbol,underlying,category,expiry) VALUES (2,'NSE:SECOND','NIFTY','OPTIONS','2026-10-27')"))
    r = report(); r['checks'].append(dict(r['checks'][0], contract_id=2, symbol='NSE:SECOND'))
    calls = []
    def history(data):
        calls.append(data)
        if kind == 'network': raise OSError('SECRET')
        if kind == 'interrupt': raise KeyboardInterrupt()
        return {'s': 'error', 'code': 401 if kind == 'auth' else 429, 'message': 'SECRET'}
    result = probe.probe_empty(env[0], load_fno_settings(), [r], lambda: NS(history=history))
    assert result['status'] == 'PARTIAL' and len(calls) == 1
    assert result['checks'][1]['status'] == 'NOT_ATTEMPTED'
    assert 'SECRET' not in json.dumps(result)


def test_expired_contract_requires_separate_endpoint_review_not_permanent_no_data(env):
    with env[1]['FNO'].begin() as c: c.execute(text("UPDATE fno_instruments SET expiry='2026-10-20'"))
    r = probe.probe_empty(env[0], load_fno_settings(), [report()], lambda: pytest.fail('No expired fallback'))
    assert r['checks'][0]['status'] == 'EXPIRED_API_REVIEW_REQUIRED'
    assert r['summary']['history_call_attempts'] == 0


def test_newly_available_rows_are_not_stored_and_wrong_date_rows_not_usable(env):
    epoch = int(dt.datetime.combine(DAY, dt.time(9, 15)).replace(tzinfo=env[0].clock().tzinfo).timestamp())
    r, _ = invoke(env, {'s': 'ok', 'candles': [[epoch, 100, 101, 99, 100, 65, 0]]})
    c = r['checks'][0]
    assert c['status'] == 'DATA_NOW_AVAILABLE_REVIEW_REQUIRED' and c['valid_rows_in_date'] == c['oi_present_rows'] == 1
    assert env[0].catalog.count('FNO', 'fno_candles') == 0
    r, _ = invoke(env, {'s': 'ok', 'candles': [[epoch + 86400, 100, 101, 99, 100, 65, 0]]})
    assert r['checks'][0]['status'] == 'PROVIDER_ROWS_NOT_USABLE'
    assert r['checks'][0]['wrong_date_rows'] == 1


def test_bounds_conflicting_identity_and_nonempty_checks_ignored(env):
    r = report(); r['checks'] = [dict(r['checks'][0], contract_id=i) for i in range(1, 12)]
    with pytest.raises(ValueError): probe.reviewed_empty_scopes([r])
    a = report(); b = copy.deepcopy(a); b['checks'][0]['symbol'] = 'NSE:OTHER'
    with pytest.raises(ValueError): probe.reviewed_empty_scopes([a, b])
    a['checks'][0]['reason'] = 'SQL_PARQUET_VALUE_MISMATCH'
    assert probe.reviewed_empty_scopes([a]) == []
    result, calls = invoke(env, {'s': 'ok', 'candles': [[]] * 2001})
    assert len(calls) == 1 and result['checks'][0]['status'] == 'RESPONSE_BOUND_EXCEEDED'


def test_cli_auth_and_no_overwrite_before_provider(env, monkeypatch, tmp_path, capsys):
    p = tmp_path / 'prior.json'; p.write_text(json.dumps(report()))
    output = tmp_path / 'probe.json'
    args = ['--reports', str(p), '--output', str(output)]
    def denied(): raise PermissionError('SECRET')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', denied)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: pytest.fail('Auth first'))
    assert cli.main(args) == 1 and not output.exists()
    assert 'SECRET' not in capsys.readouterr().out
    output.write_text('preserve')
    assert cli.main(args) == 2 and output.read_text() == 'preserve'


def test_cli_input_hash_and_findings_are_saved_without_automatic_pass(env, monkeypatch, tmp_path, capsys):
    import hashlib
    seed(env, 'FNO', n=1)  # Existing data -> no provider, while still producing evidence.
    p = tmp_path / 'prior.json'; p.write_text(json.dumps(report()))
    output = tmp_path / 'probe.json'
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: env[0].catalog)
    monkeypatch.setattr('model.fyers.auth.get_authenticated_client', lambda *a: pytest.fail('No broker needed'))
    assert cli.main(['--reports', str(p), '--output', str(output)]) == 2
    r = json.loads(output.read_text())
    assert r['input_report_sha256'] == [hashlib.sha256(p.read_bytes()).hexdigest()]
    assert not json.loads(capsys.readouterr().out)['items_2_3_fully_verified']


def test_cli_provider_factory_uses_shared_low_priority_limiter(env, monkeypatch, tmp_path):
    with env[1]['FNO'].begin() as c: c.execute(text("UPDATE fno_instruments SET expiry='2099-12-27'"))
    p = tmp_path / 'prior.json'; p.write_text(json.dumps(report()))
    output = tmp_path / 'probe.json'; acquired = []; calls = []
    def history(data): calls.append(data); return {'s': 'ok', 'candles': []}
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: env[0].catalog)
    monkeypatch.setattr('model.config.env_loader.load_env_config', lambda: NS(fyers=object()))
    monkeypatch.setattr('model.fyers.auth.get_authenticated_client', lambda creds: NS(history=history))
    monkeypatch.setattr('model.fyers.rate_limiter.get_shared_limiter', lambda: NS(acquire=acquired.append))
    assert cli.main(['--reports', str(p), '--output', str(output)]) == 2
    from model.fyers.rate_limiter import LOW
    assert acquired == [LOW] and len(calls) == 1
    assert json.loads(output.read_text())['checks'][0]['status'] == 'PROVIDER_NO_DATA_ON_RECHECK'
