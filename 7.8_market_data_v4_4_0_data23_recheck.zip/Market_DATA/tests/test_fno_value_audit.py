import datetime as dt
import json

import pandas as pd
import pytest
from sqlalchemy import event, text

from controller import diagnostics_cli
from model.fno import value_audit as audit
from test_read_api import env, seed, fno_parquet, DAY


def run(env, **kwargs):
    return audit.audit_values(env[0], str(DAY), str(DAY), contract_ids=[1], **kwargs)


def test_sparse_values_verified_without_complete_option_coverage_and_no_writes(env):
    path = fno_parquet(env, seed(env, 'FNO', n=3))
    before = path.read_bytes()
    queries = []
    event.listen(env[1]['FNO'], 'before_cursor_execute', lambda c, cu, s, p, ctx, m: queries.append(s))
    r = run(env)
    assert r['status'] == 'FNO_VALUES_CHECK_PASS' and r['values_verified']
    assert not r['complete_minute_coverage'] and not r['unit_scale_verified'] and not r['live_verified']
    assert r['checks'][0]['status'] == 'VERIFIED_SPARSE'
    assert r['checks'][0]['optional_fields']['oi'] == {'present': 0, 'null': 3}
    assert r['summary']['shared_files_read'] == 1 and r['summary']['parquet_rows_scanned'] == 3
    assert path.read_bytes() == before
    assert not any(q.lstrip().upper().startswith(('INSERT', 'UPDATE', 'DELETE', 'ALTER', 'CREATE', 'DROP')) for q in queries)


def test_full_session_futures_coverage_and_zero_oi_is_present(env):
    rows = seed(env, 'FNO', n=385)
    with env[1]['FNO'].begin() as c:
        c.execute(text("UPDATE fno_instruments SET category='FUTURES'"))
        c.execute(text('UPDATE fno_candles SET oi=0'))
    fno_parquet(env, [dict(r, oi=0) for r in rows])
    r = run(env)
    assert r['values_verified'] and r['complete_minute_coverage']
    assert r['checks'][0]['optional_fields']['oi'] == {'present': 385, 'null': 0}


@pytest.mark.parametrize('fault', ['mismatch', 'checksum', 'empty', 'future_sparse', 'optional_invalid'])
def test_bad_data_never_certified(env, fault):
    rows = seed(env, 'FNO', n=3)
    path = fno_parquet(env, rows)
    if fault == 'mismatch':
        with env[1]['FNO'].begin() as c: c.execute(text('UPDATE fno_candles SET close=100 WHERE id=1'))
    elif fault == 'checksum':
        frame = pd.read_parquet(path); frame.loc[0, 'close'] = 100; frame.to_parquet(path, index=False)
    elif fault == 'empty':
        with env[1]['FNO'].begin() as c: c.execute(text('DELETE FROM fno_candles'))
        path.unlink()
        with env[1]['FNO'].begin() as c: c.execute(text('DELETE FROM fno_storage_manifest'))
    elif fault == 'future_sparse':
        with env[1]['FNO'].begin() as c: c.execute(text("UPDATE fno_instruments SET category='FUTURES'"))
    else:
        with env[1]['FNO'].begin() as c: c.execute(text('UPDATE fno_candles SET oi=-1 WHERE id=1'))
        fno_parquet(env, [dict(r, oi=-1) for r in rows])
    r = run(env)
    assert not r['values_verified'] and r['status'] == 'FINDINGS'
    assert r['checks'][0]['status'] == 'NOT_VERIFIED'


def test_shared_partition_loaded_once_for_two_contracts(env, monkeypatch):
    rows = seed(env, 'FNO', n=3)
    with env[1]['FNO'].begin() as c:
        c.execute(text("INSERT INTO fno_instruments (id,fyers_symbol,underlying,category,expiry) VALUES (2,'NSE:SECOND','NIFTY','OPTIONS','2026-10-27')"))
        for r in rows:
            c.execute(env[2]['FNO']['fno_candles'].insert(), dict(r, contract_id=2))
    fno_parquet(env, rows + [dict(r, contract_id=2) for r in rows])
    import pyarrow.parquet as pq
    original = pq.ParquetFile; calls = []
    def counted(*args, **kwargs):
        calls.append(1); return original(*args, **kwargs)
    monkeypatch.setattr(pq, 'ParquetFile', counted)
    r = audit.audit_values(env[0], str(DAY), str(DAY), contract_ids=[1, 2])
    assert r['values_verified'] and r['summary']['verified_rows'] == 6
    assert len(calls) == r['summary']['shared_files_read'] == 1


def test_underlying_selector_includes_no_data_claims_but_not_entire_master(env):
    fno_parquet(env, seed(env, 'FNO', n=3))
    with env[1]['FNO'].begin() as c:
        c.execute(text('CREATE TABLE fno_checkpoint_ranges (contract_id INTEGER, range_from DATE, range_to DATE)'))
        for identity in (2, 3):
            c.execute(text("INSERT INTO fno_instruments (id,fyers_symbol,underlying,category,expiry) VALUES (:i,:s,'NIFTY','OPTIONS','2026-10-27')"), {'i': identity, 's': f'NSE:TEST{identity}'})
        c.execute(text("INSERT INTO fno_checkpoint_ranges VALUES (2,'2026-10-16','2026-10-16')"))
    r = audit.audit_values(env[0], str(DAY), str(DAY), underlyings=['NIFTY'])
    assert [c['contract_id'] for c in r['checks']] == [1, 2]
    assert not r['values_verified'] and r['summary']['statuses']['NOT_VERIFIED'] == 1


def test_bounds_and_empty_target_scope_do_not_pass(env, monkeypatch):
    fno_parquet(env, seed(env, 'FNO', n=3))
    monkeypatch.setattr(audit, 'MAX_FILE_ROWS', 2)
    r = run(env)
    assert r['status'] == 'PARTIAL' and r['checks'][0]['reason'] == 'READ_BOUND_EXCEEDED'
    monkeypatch.setattr(audit, 'MAX_CHECKS', 0)
    with pytest.raises(ValueError): run(env)
    with pytest.raises(ValueError): audit.audit_values(env[0], str(env[0].clock().date()), str(env[0].clock().date()), contract_ids=[1])


@pytest.mark.parametrize('change', ['calendar', 'file', 'manifest'])
def test_end_of_audit_change_invalidates_prior_success(env, monkeypatch, change):
    path = fno_parquet(env, seed(env, 'FNO', n=3))
    original = audit.verified_day
    def changed(*args, **kwargs):
        result = original(*args, **kwargs)
        if change == 'calendar': monkeypatch.setattr(audit, 'calendar_metadata', lambda: {'new': True})
        elif change == 'file': path.touch()
        else:
            with env[1]['FNO'].begin() as c: c.execute(text("UPDATE fno_storage_manifest SET status='WRITING'"))
        return result
    monkeypatch.setattr(audit, 'verified_day', changed)
    r = run(env)
    assert not r['values_verified'] and r['status'] == 'PARTIAL'
    assert r['summary']['verified_rows'] == 0


def test_cli_admin_auth_exclusive_report_and_no_provider(env, monkeypatch, tmp_path, capsys):
    fno_parquet(env, seed(env, 'FNO', n=3))
    def denied(): raise PermissionError('denied')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', denied)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: pytest.fail('Auth first'))
    output = tmp_path / 'values.json'
    args = ['fno-values', '--from', str(DAY), '--to', str(DAY), '--contract-ids', '1', '--output', str(output)]
    assert diagnostics_cli.main(args) == 1 and not output.exists()
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: env[0].catalog)
    monkeypatch.setattr('model.fyers.auth.get_authenticated_client', lambda *a, **k: pytest.fail('No provider'))
    assert diagnostics_cli.main(args) == 0
    before = output.read_bytes()
    assert json.loads(before)['complete_minute_coverage'] is False
    assert diagnostics_cli.main(args) == 2 and output.read_bytes() == before


def test_derived_values_reuse_base_partition_and_reject_mutated_aggregation(env):
    from model.fno.aggregation import aggregate_day
    from model.fno.read_verification import _candles
    from model.fno.parquet_store import FnoParquetStore, candles_to_frame
    rows = seed(env, 'FNO', n=385)
    fno_parquet(env, rows)
    bars = aggregate_day(_candles(rows), DAY, '5m', now=env[0].clock()).candles
    frame = candles_to_frame(bars)
    store = FnoParquetStore(env[0].catalog.roots['FNO'], None)
    rel = store.relative_candle_path('5m', 'NIFTY', dt.date(2026, 10, 27), DAY)
    path = store.abs_path(rel); path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(path, index=False)
    with env[1]['FNO'].begin() as c:
        c.execute(env[2]['FNO']['fno_candles'].insert(), frame.to_dict('records'))
        c.execute(env[2]['FNO']['fno_storage_manifest'].insert(), {'relative_path': rel, 'status': 'VERIFIED',
            'checksum': store.sha256(path), 'row_count': len(frame)})
    r = run(env, timeframes=['1m', '5m'])
    assert r['values_verified'] and r['summary']['shared_files_read'] == 2
    assert r['summary']['parquet_rows_scanned'] == 385 + 77
    with env[1]['FNO'].begin() as c: c.execute(text("UPDATE fno_candles SET volume=999 WHERE timeframe='5m'"))
    frame['volume'] = 999; frame.to_parquet(path, index=False)
    with env[1]['FNO'].begin() as c:
        c.execute(text('UPDATE fno_storage_manifest SET checksum=:h WHERE relative_path=:p'), {'h': store.sha256(path), 'p': rel})
    r = run(env, timeframes=['1m', '5m'])
    assert not r['values_verified'] and r['checks'][1]['reason'] == 'AGGREGATION_MISMATCH'


def test_sql_budget_and_empty_underlying_scope_cannot_pass(env, monkeypatch):
    fno_parquet(env, seed(env, 'FNO', n=3))
    monkeypatch.setattr(audit, 'MAX_TOTAL_ROWS', 2)
    r = run(env)
    assert r['status'] == 'PARTIAL' and r['summary']['sql_rows_read'] == 3
    assert r['summary']['shared_files_read'] == 0
    with env[1]['FNO'].begin() as c:
        c.execute(text('CREATE TABLE fno_checkpoint_ranges (contract_id INTEGER, range_from DATE, range_to DATE)'))
    r = audit.audit_values(env[0], str(DAY), str(DAY), underlyings=['BANKNIFTY'])
    assert not r['values_verified'] and r['issues'] == ['NO_TARGETS_IN_SCOPE']


def test_corrupt_shared_file_checksum_is_not_rehashed_for_each_contract(env, monkeypatch):
    from model.fno.parquet_store import FnoParquetStore
    path = fno_parquet(env, seed(env, 'FNO', n=3))
    with env[1]['FNO'].begin() as c:
        c.execute(text("INSERT INTO fno_instruments (id,fyers_symbol,underlying,category,expiry) VALUES (2,'NSE:SECOND','NIFTY','OPTIONS','2026-10-27')"))
    frame = pd.read_parquet(path); frame.loc[0, 'volume'] = 999; frame.to_parquet(path, index=False)
    original = FnoParquetStore.sha256; calls = []
    def counted(p): calls.append(1); return original(p)
    monkeypatch.setattr(FnoParquetStore, 'sha256', staticmethod(counted))
    r = audit.audit_values(env[0], str(DAY), str(DAY), contract_ids=[1, 2])
    assert not r['values_verified'] and len(calls) == 1
    assert all(c['reason'] == 'PARQUET_CHECKSUM_OR_ROW_COUNT_MISMATCH' for c in r['checks'])
