from pathlib import Path
from types import SimpleNamespace

from tools import phase9_validation as validation


def test_manifest_is_unique_present_and_provider_free():
    validation.validate_manifest()
    paths=[path for group in validation.TEST_GROUPS.values() for path in group]
    assert len(paths)==len(set(paths))
    assert all((validation.ROOT/path).is_file() for path in paths)
    assert not any("mysql" in path.lower() for path in paths)


def test_runner_uses_current_python_stops_on_failure_and_sanitizes_summary(monkeypatch):
    for key in ("FNO_TEST_DB_PASSWORD", "CASH_DATA_ROOT", "TIOS_RUNTIME_DIR"):
        monkeypatch.setenv(key,"operator-value")
    calls=[]
    def runner(command,cwd,env):
        calls.append((command,Path(cwd),env))
        return SimpleNamespace(returncode=0 if len(calls)==1 else 7)
    result=validation.run(("core","operations","api"),runner=runner)
    assert result["status"]=="FAILED"
    assert [item["group"] for item in result["groups"]]==["core","operations"]
    assert calls[0][0][:4]==[validation.sys.executable,"-m","pytest","-q"]
    assert all("tools.phase9_pytest_guard" in command for command,_,_ in calls)
    assert all(not any(key in env for key in ("FNO_TEST_DB_PASSWORD", "CASH_DATA_ROOT", "TIOS_RUNTIME_DIR")) for _,_,env in calls)
    assert all(cwd==validation.ROOT for _,cwd,_ in calls)
    assert all(env.get("TIOS_HOME") and "DB_PASSWORD" not in env and "FYERS_ACCESS_TOKEN" not in env
               for _,_,env in calls)
    assert "environment" not in result and "command" not in result


def test_isolated_profile_contains_no_operator_credentials(tmp_path):
    home=validation.isolated_environment(tmp_path)
    env=(home/"config/.env").read_text(encoding="utf-8")
    assert "PASSWORD" not in env and "TOKEN" not in env
    assert (home/"data/cash").is_dir() and (home/"data/fno").is_dir()
    assert str(home).replace("\\","/") in (home/"config/fno_settings.yaml").read_text(encoding="utf-8")



def test_guard_blocks_database_fixture_before_setup():
    import pytest
    from tools.phase9_pytest_guard import pytest_runtest_setup
    with pytest.raises(pytest.skip.Exception):
        pytest_runtest_setup(SimpleNamespace(fixturenames=["tmp_path", "fno_engine"]))
    pytest_runtest_setup(SimpleNamespace(fixturenames=["tmp_path", "env"]))
