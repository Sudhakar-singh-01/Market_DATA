"""Regressions for the user's October 26 Windows output and logs."""
import datetime as dt
from types import SimpleNamespace
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from model.pipeline_errors import FetchPreflightError

service=None
started=[]


class FakeFetch:
    def __init__(self):
        self.blocked=[]; self.calls=[]; self.change=False
    def smart_preview(self,params):
        return {'blocked':self.blocked,'items':[{'symbol':'SBIN','missing':10}],
                'requests_estimate':1,'complete_symbol_days':0}
    def submit(self,*args):
        self.calls.append(args)
        if self.change:raise FetchPreflightError({'blocked':[{'symbol':'SBIN','date':'2026-10-19','reason':'Storage conflict'}]})
        return 13


@pytest.fixture
def app():
    global service,started
    service=FakeFetch();started=[]
    source="from test_reported_dashboard_failures import service,started\nfrom ui.fetch_review import render_gap_fetch\nrender_gap_fetch({'symbols':['SBIN'],'from':'2026-10-19','to':'2026-10-19'},'admin',lambda:service,lambda s:started.append(s))"
    return AppTest.from_string(source).run()


def test_blocked_coverage_preview_explains_without_submit_or_traceback(app):
    service.blocked=[{'symbol':'SBIN','date':'2026-10-19','reason':'Storage conflict'}]
    app.button(key='cov_fill_all').click().run()
    assert not app.exception and app.error and app.dataframe
    assert service.calls==[] and started==[]
    assert not any(b.key=='cov_fetch_submit' for b in app.button)


def test_coverage_requires_preview_then_explicit_submission(app):
    app.button(key='cov_fill_all').click().run()
    assert service.calls==[]
    app.button(key='cov_fetch_submit').click().run()
    assert not app.exception and len(service.calls)==1 and started==[service]


def test_stale_preflight_is_handled_and_review_consumed(app):
    app.button(key='cov_fill_all').click().run()
    service.change=True
    app.button(key='cov_fetch_submit').click().run()
    assert not app.exception and app.error and started==[]
    assert 'cov_fetch_preview' not in app.session_state


def test_actual_coverage_page_reproduced_blocked_click(monkeypatch):
    import streamlit as st
    import ui.auth,ui.engine_bootstrap,ui.components,ui.quality_page
    import controller.coverage_controller as coverage
    import controller.gapfill_controller as gaps
    from model.config.instrument_loader import load_instrument_registry
    registry=load_instrument_registry()
    fake=FakeFetch();fake.blocked=[{'symbol':'SBIN','date':'2026-10-19','reason':'Calendar not verified'}]
    monkeypatch.setattr(ui.auth,'require_auth',lambda _:True)
    monkeypatch.setattr(ui.auth,'current_role',lambda:'admin')
    env=SimpleNamespace(db=SimpleNamespace(host='local',port=3306,name='test'))
    monkeypatch.setattr(ui.engine_bootstrap,'load_config_or_stop',lambda:(env,SimpleNamespace(storage=SimpleNamespace(mysql_enabled=True)),None,registry))
    monkeypatch.setattr(ui.engine_bootstrap,'get_mysql_engine_or_none',lambda *a:object())
    monkeypatch.setattr(ui.components,'instrument_selector',lambda *a,**k:['SBIN'])
    monkeypatch.setattr(coverage,'load_daily_counts',lambda *a:{})
    monkeypatch.setattr(coverage,'load_day_minutes',lambda *a:set())
    monkeypatch.setattr(gaps,'now_ist_naive',lambda:dt.datetime(2026,10,26,12))
    monkeypatch.setattr(ui.quality_page,'get_service',lambda:fake)
    st.cache_data.clear()
    at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'ui/views/coverage_cash.py')).run()
    at.button(key='cov_fill_all').click().run()
    assert not at.exception and at.error and fake.calls==[]
    st.cache_data.clear()


def test_backend_preflight_keeps_findings_and_never_queues():
    from controller.pipeline_service import PipelineService
    service=PipelineService.__new__(PipelineService)
    service.validate=lambda p:None
    service.settings=SimpleNamespace(storage=SimpleNamespace(parquet_enabled=True))
    service.store=SimpleNamespace(submit=lambda *a:pytest.fail('Blocked fetch must never queue'))
    service.smart_preview=lambda p:{'blocked':[{'symbol':'SBIN','date':'2026-10-19','reason':'Storage conflict'}]}
    with pytest.raises(FetchPreflightError) as caught:
        service.submit('admin','SMART_FETCH',{'symbols':['SBIN']})
    assert caught.value.blocked[0]['symbol']=='SBIN'


def test_background_audit_does_not_read_streamlit_context(monkeypatch):
    from ui.audit_log import record_action
    import ui.session_context as context
    from sqlalchemy import create_engine
    def forbidden():pytest.fail('Background thread must use captured context only')
    monkeypatch.setattr(context,'get_client_ip',forbidden)
    monkeypatch.setattr(context,'get_session_id',forbidden)
    record_action(create_engine('sqlite://'),'admin','LOGIN',ip_address=None,session_id=None,resolve_session=False)


@pytest.mark.parametrize('child_status,job_status',[('no_complete_buckets','PARTIAL'),('partial','PARTIAL'),('no_source_data','NO_DATA'),('success','SUCCESS')])
def test_cash_aggregation_job_propagates_true_outcome(monkeypatch,child_status,job_status):
    from controller.pipeline_service import PipelineService
    import controller.timeframe_controller as tf
    import model.storage.mysql as mysql
    monkeypatch.setattr(mysql,'MySQLCandleSink',lambda *a:SimpleNamespace())
    monkeypatch.setattr(mysql,'MySQLJobRecorder',lambda *a:SimpleNamespace())
    monkeypatch.setattr(tf,'generate_timeframe_for_instrument',lambda *a,**k:SimpleNamespace(status=child_status,error=None,reason='test reason',missing_1m_count=135))
    s=PipelineService.__new__(PipelineService)
    s.settings=SimpleNamespace(storage=SimpleNamespace(parquet_enabled=False))
    s.instruments=SimpleNamespace(get=lambda _:object());s.engine=object()
    s.store=SimpleNamespace(progress=lambda *a:None)
    h=SimpleNamespace(params={'symbols':['SBIN'],'timeframes':['1d'],'from':'2026-10-19','to':'2026-10-19'},id=1,stop_outcome=lambda _:None)
    result=s.aggregate(h)
    assert result.state==job_status
    assert result.result['results'][0]['missing_1m_count']==135


def test_cash_worker_logs_cash_not_fno(caplog):
    from controller.fno_jobs import FnoJobRunner,JobOutcome
    import logging
    store=SimpleNamespace(cancel_requested=lambda jid:False,claim_next=lambda kinds:{'id':281,'job_type':'AGGREGATION','params':{}},finish=lambda *a:None)
    runner=FnoJobRunner(store,{'AGGREGATION':lambda h:JobOutcome('PARTIAL')},segment='CASH')
    with caplog.at_level(logging.INFO):runner.run_one()
    assert 'CASH job 281 (AGGREGATION) finished: PARTIAL' in caplog.text
    assert 'FNO job 281' not in caplog.text
