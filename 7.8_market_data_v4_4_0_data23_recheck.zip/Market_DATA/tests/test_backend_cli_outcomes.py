"""CLI failures and one-job commands must remain visible to shell automation."""
import argparse
from types import SimpleNamespace as NS

import pytest

import main as entry
from controller import fno_cli, pipeline_cli
from controller.historical_controller import HistoricalBatchSummary, InstrumentIngestionResult
from controller.timeframe_controller import TimeframeBatchSummary, TimeframeGenerationResult


@pytest.mark.parametrize('status,expected', [('success', 0), ('failed', 1), ('no_data', 2)])
def test_historical_command_returns_data_outcome(monkeypatch, status, expected):
    result = InstrumentIngestionResult('NSE:SBIN-EQ', status)
    summary = HistoricalBatchSummary([result])
    monkeypatch.setattr(entry, 'run_historical_ingestion', lambda **kw: summary)
    for name in ('build_sink', 'build_checkpoint_store', 'build_job_recorder'):
        monkeypatch.setattr(entry, name, lambda *a: None)
    args = NS(from_date='2026-10-19', to_date='2026-10-19', symbols=['SBIN'])
    settings = NS(historical_enabled=True)
    assert entry.run_historical_mode(args, NS(), NS(), settings, NS(), NS(), NS()) == expected


@pytest.mark.parametrize('status,expected', [('success', 0), ('partial', 2), ('pending', 2),
                                           ('no_source_data', 2), ('failed', 1)])
def test_aggregate_command_returns_data_outcome(monkeypatch, status, expected):
    summary = TimeframeBatchSummary([TimeframeGenerationResult('NSE:SBIN-EQ', '3m', status)])
    monkeypatch.setattr(entry, 'run_timeframe_generation', lambda **kw: summary)
    for name in ('build_sink', 'build_1m_reader', 'build_job_recorder'):
        monkeypatch.setattr(entry, name, lambda *a: None)
    args = NS(from_date='2026-10-19', to_date='2026-10-19', symbols=['SBIN'], timeframes=['3m'])
    assert entry.run_aggregate_mode(args, NS(), NS(), NS(), NS(), NS()) == expected


def test_empty_or_invalid_batch_does_not_exit_success(monkeypatch):
    assert entry.batch_exit_code(NS(results=[])) == 2
    assert entry.batch_exit_code(NS(results=[NS(status='success', invalid_count=1)])) == 2
    assert entry.batch_exit_code(NS(results=[NS(status='partial'), NS(status='failed')])) == 1


def test_main_preserves_mode_exit_code(monkeypatch):
    monkeypatch.setattr(entry, 'parse_args', lambda: NS(mode='aggregate'))
    monkeypatch.setattr(entry, 'load_and_validate', lambda: (NS(), NS(), NS(), NS(base_timeframe='1m'),
                                                          NS(active_stocks=lambda: [], active_indices=lambda: [])))
    monkeypatch.setattr(entry, 'run_aggregate_mode', lambda *a: 2)
    assert entry.main() == 2


def test_cash_run_executes_only_new_submission(monkeypatch):
    jobs = {11: {'id': 11, 'state': 'PENDING'}, 12: {'id': 12, 'state': 'PENDING'}}
    class Runner:
        def run_until_empty(self):
            pytest.fail('Submission command must not drain unrelated queued jobs')
        def run_one(self, *, job_id):
            assert job_id == 12
            jobs[job_id]['state'] = 'SUCCESS'
            return job_id
    service = NS(engine=object(), submit=lambda *a: 12, runner=Runner,
                 store=NS(get=lambda jid: jobs[jid]))
    monkeypatch.setattr('controller.pipeline_service.PipelineService', lambda: service)
    monkeypatch.setattr('model.quality_store.ready', lambda engine: True)
    args = NS(mode='verify', start='2026-10-19', end='2026-10-19', symbols=['SBIN'], run=True)
    assert pipeline_cli.run(args) == 0
    assert jobs[11]['state'] == 'PENDING'


@pytest.mark.parametrize('state', ['PENDING', 'RUNNING'])
def test_cash_submission_held_by_other_worker_is_incomplete(monkeypatch, state):
    service = NS(engine=object(), submit=lambda *a: 12,
                 runner=lambda: NS(run_one=lambda **kw: None),
                 store=NS(get=lambda jid: {'id': jid, 'state': state}))
    monkeypatch.setattr('controller.pipeline_service.PipelineService', lambda: service)
    monkeypatch.setattr('model.quality_store.ready', lambda engine: True)
    args = NS(mode='verify', start='2026-10-19', end='2026-10-19', symbols=['SBIN'], run=True)
    assert pipeline_cli.run(args) == 2


def _job(jid, state):
    return dict(id=jid, state=state, requests_made=0, rows_raw=0, rows_valid=0, rows_invalid=0,
                rows_stored=0, rows_duplicate=0, no_data_count=0, retry_count=0, error=None, result={})


@pytest.mark.parametrize('claimed,state,expected', [(True, 'SUCCESS', 0), (True, 'PARTIAL', 2),
    (True, 'FAILED', 1), (False, 'PENDING', 2), (False, 'RUNNING', 2)])
def test_fno_run_executes_only_selected_job(monkeypatch, claimed, state, expected):
    jobs = {11: _job(11, 'PENDING'), 12: _job(12, 'PENDING')}
    class Runner:
        def __init__(self, *a): pass
        def recover(self): pytest.fail('Scoped submission must not recover unrelated jobs')
        def run_until_empty(self): pytest.fail('Scoped submission must not drain queue')
        def run_one(self, *, job_id):
            assert job_id == 12
            jobs[job_id]['state'] = state
            return job_id if claimed else None
    c = NS(jobs=NS(get=lambda jid: jobs.get(jid)), settings=NS(jobs=NS(heartbeat_seconds=10, stale_after_seconds=90)),
           client=None)
    monkeypatch.setattr(fno_cli, 'FnoJobRunner', Runner)
    monkeypatch.setattr(fno_cli, 'local_handlers', lambda c: {})
    assert fno_cli._run_jobs(c, job_id=12) == expected
    assert jobs[11]['state'] == 'PENDING'


def test_fno_local_command_passes_its_job_id(monkeypatch):
    c = NS(jobs=NS(submit=lambda *a: 12))
    monkeypatch.setattr(fno_cli, 'bootstrap', lambda: c)
    seen = []
    monkeypatch.setattr(fno_cli, '_run_jobs', lambda ctx, **kw: seen.append(kw) or 0)
    args = NS(mode='fno-verify', from_date='2026-10-19', to_date='2026-10-19', no_parquet=False,
              underlyings=['NIFTY'], contract_ids=None, submit_only=False)
    assert fno_cli.cmd_local_job(args) == 0
    assert seen == [{'job_id': 12}]
