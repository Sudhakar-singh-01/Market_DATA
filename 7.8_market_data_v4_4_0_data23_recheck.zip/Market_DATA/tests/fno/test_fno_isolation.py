"""
Isolation rules (spec section 4). Every rule has an automated test.
Static scans cover model/fno, controller/fno_*.py and ui/fno; DB tests prove
Subsystem A's tables and Parquet tree are untouched by FNO operations.
"""
import ast
import re
from pathlib import Path

import pytest

from tests_support import a_fingerprint, tree_fingerprint

PROJECT = Path(__file__).resolve().parents[2]


def fno_python_files():
    files = list((PROJECT / "model" / "fno").rglob("*.py"))
    files += list((PROJECT / "controller").glob("fno_*.py"))
    files += list((PROJECT / "ui" / "fno").rglob("*.py")) if (PROJECT / "ui" / "fno").exists() else []
    pages = PROJECT / "ui" / "views" / "fno_management.py"
    if pages.exists():
        files.append(pages)
    return files


def test_fno_python_files_were_found():
    assert len(fno_python_files()) >= 8


def test_no_fno_module_uses_subsystem_a_parquet_sink():
    """No FNO module imports or constructs ParquetCandleSink (whose default root is A's 'data')."""
    offenders = []
    for f in fno_python_files():
        tree = ast.parse(f.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == "model.storage.parquet":
                offenders.append(f"{f.name}: imports model.storage.parquet")
            if isinstance(node, ast.Name) and node.id == "ParquetCandleSink":
                offenders.append(f"{f.name}: references ParquetCandleSink")
    assert not offenders, offenders


def test_fno_modules_do_not_import_subsystem_a_storage_or_engine():
    banned = ("model.storage.mysql", "model.storage.parquet", "model.storage.csv", "ui.engine_bootstrap",
              "controller.sinks", "ui.admin_data_access", "ui.data_access")
    offenders = []
    for f in fno_python_files():
        tree = ast.parse(f.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            mod = node.module if isinstance(node, ast.ImportFrom) else None
            names = [a.name for a in node.names] if isinstance(node, ast.Import) else []
            for m in ([mod] if mod else []) + names:
                if m and any(m == b or m.startswith(b + ".") for b in banned):
                    offenders.append(f"{f.name}: {m}")
    assert not offenders, offenders


def test_fno_code_never_hardcodes_subsystem_a_data_paths():
    for f in fno_python_files():
        text = f.read_text(encoding="utf-8")
        for bad in ('"data/raw', "'data/raw", '"data/processed', "'data/processed", 'data_root="data"'):
            # config.py legitimately NAMES the A dirs in order to forbid them
            if f.name == "config.py":
                continue
            assert bad not in text, f"{f.name} references {bad}"


A_TABLES = ["instruments", "candles", "checkpoints", "ingestion_jobs", "audit_log", "error_logs"]


def test_fno_sql_never_references_subsystem_a_tables_unqualified():
    pat = re.compile(r"\b(?:FROM|JOIN|INTO|UPDATE|TABLE|REFERENCES|DELETE\s+FROM|TRUNCATE)\s+`?(" + "|".join(A_TABLES) + r")`?\b", re.I)
    sql_files = list((PROJECT / "database" / "fno").glob("*.sql")) + fno_python_files()
    for f in sql_files:
        text = re.sub(r"--[^\n]*", "", f.read_text(encoding="utf-8"))
        assert not pat.search(text), f"{f.name} references a Subsystem A table"


def test_every_table_created_by_fno_sql_is_prefixed():
    for f in (PROJECT / "database" / "fno").glob("*.sql"):
        for name in re.findall(r"CREATE TABLE IF NOT EXISTS\s+(\w+)", f.read_text()):
            assert name.startswith("fno_"), (f.name, name)


def test_one_process_wide_limiter_is_the_only_fno_rate_gate():
    """FNO code takes slots only via RateLimitedClient / the shared limiter module, never its own sleeps for pacing."""
    for f in fno_python_files():
        text = f.read_text(encoding="utf-8")
        assert "MIN_REQUEST_INTERVAL_SECONDS" not in text


# ------------------------------------------------ operations leave A untouched
def test_fno_operations_leave_subsystem_a_database_untouched(a_engine, clean_fno):
    from model.fno.repository import FnoRepository
    before = a_fingerprint(a_engine)
    repo = FnoRepository(clean_fno)
    from tests_support import sample_contract
    cid = repo.upsert_contract(sample_contract())
    repo.add_checkpoint_range(cid, "HISTORICAL", "1m", __import__("datetime").date(2026, 10, 1),
                              __import__("datetime").date(2026, 10, 5), "VERIFIED")
    repo.reset_checkpoints(contract_ids=[cid], job_type="HISTORICAL", timeframe="1m")
    assert a_fingerprint(a_engine) == before


def test_fno_cleanup_cannot_touch_subsystem_a_parquet(tmp_path):
    from model.fno.parquet_store import FnoParquetStore
    from model.exceptions import ConfigurationError
    a_raw = tmp_path / "data" / "raw" / "1m" / "NSE_SBIN-EQ"; a_raw.mkdir(parents=True)
    (a_raw / "2026-10-16.parquet").write_bytes(b"A-data")
    a_proc = tmp_path / "data" / "processed" / "5m"; a_proc.mkdir(parents=True)
    (a_proc / "x.parquet").write_bytes(b"A-processed")
    before = tree_fingerprint(tmp_path / "data")
    fno_root = tmp_path / "data" / "fno"
    store = FnoParquetStore(fno_root, manifest=None)
    store.cleanup_old_files(retain_days=0, dry_run=False, confirm=True)
    for evil in (tmp_path / "data" / "raw", a_raw / "2026-10-16.parquet", tmp_path / "data"):
        with pytest.raises(ConfigurationError):
            store._guard(evil)
    assert tree_fingerprint(tmp_path / "data") == before


def test_parquet_store_requires_an_explicit_root():
    from model.fno.parquet_store import FnoParquetStore
    with pytest.raises(TypeError):
        FnoParquetStore()          # no default root, by design
    with pytest.raises(Exception):
        FnoParquetStore(None, manifest=None)
