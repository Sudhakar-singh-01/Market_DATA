import dataclasses
import datetime as dt
import hashlib
import json
import threading
from types import SimpleNamespace
import pytest
from sqlalchemy import text
from model.config.market_calendar import IST,expected_starts
from model.config.instrument_loader import Instrument,InstrumentRegistry
from model.config.data_settings import load_data_settings
from model.config.timeframe_settings import load_timeframe_settings
from model.processing.models import Candle
from model.storage.mysql import MySQLCandleSink
from model.storage.parquet import ParquetCandleSink
from controller.sinks import CompositeCandleSink
from controller.pipeline_service import PipelineService
from model.quality_store import migrate,migration_plan

DAY=dt.date(2026,10,19)
@pytest.fixture
def cash(a_engine,tmp_path):
    assert a_engine.url.database=='market_data_test'
    migrate(a_engine,True)
    inst=Instrument('R4TEST','NSE:R4TEST-EQ','NSE','EQ',True,'stock')
    registry=InstrumentRegistry([inst]);settings=load_data_settings()
    env=SimpleNamespace(db=SimpleNamespace(host='127.0.0.1',port=3306,name='market_data_test',user='fnotest',password='fnotest'),fyers=SimpleNamespace(access_token='fake',client_id='fake'))
    s=PipelineService(env,settings,load_timeframe_settings(),registry,a_engine,tmp_path/'data')
    mysql=MySQLCandleSink(a_engine,registry);pq=ParquetCandleSink(str(tmp_path/'data'));sink=CompositeCandleSink([mysql,pq])
    rows=[Candle(inst.internal_name,inst.fyers_symbol,'EQ','NSE',t,'1m',100,102,99,101,10,'FYERS_HISTORICAL') for t in expected_starts(DAY)]
    s.params={'from':str(DAY),'to':str(DAY),'symbols':['R4TEST'],'use_parquet':True}
    s.sink=sink;s.sql_sink=mysql;s.pq_sink=pq;s.rows=rows
    yield s
    from model.monitoring import flush
    flush()
    with a_engine.begin() as c:
        c.execute(text("DELETE FROM candles WHERE instrument_id IN (SELECT id FROM instruments WHERE internal_name='R4TEST')"))
        c.execute(text("DELETE FROM instruments WHERE internal_name='R4TEST'"))
        c.execute(text("DELETE FROM checkpoints WHERE fyers_symbol='NSE:R4TEST-EQ'"))
        c.execute(text("DELETE FROM data_quality_results"));c.execute(text("DELETE FROM pipeline_events"))
        c.execute(text("DELETE FROM ingestion_jobs WHERE params IS NOT NULL"))


def test_migration_idempotent_and_explicit(cash):
    with pytest.raises(ValueError):migrate(cash.engine)
    assert not migration_plan(cash.engine) and migrate(cash.engine,True)==0


def test_sql_canonical_rows_reach_parquet_and_conflicts_stay_reported(cash):
    cash.sink.write_batch(cash.rows[:1])
    cash.sink.write_batch([dataclasses.replace(cash.rows[0],high=150)])
    assert cash.sink.last_conflicts==1 and cash.sink.last_stored==0
    sql=cash.reader.sql_day(cash.reader.instrument('NSE:R4TEST-EQ')['id'],'1m',DAY)
    pq,_=cash.reader.parquet_day('NSE:R4TEST-EQ','1m',DAY)
    assert float(sql[0]['high'])==pq[0]['high']==102


def test_historical_supersedes_live_in_both_stores(cash):
    cash.sink.write_batch([dataclasses.replace(cash.rows[0],source='FYERS_LIVE',high=105)])
    cash.sink.write_batch(cash.rows[:1])
    assert cash.sink.last_stored==1 and cash.sink.last_conflicts==0
    pq,_=cash.reader.parquet_day('NSE:R4TEST-EQ','1m',DAY)
    assert pq[0]['source']=='FYERS_HISTORICAL' and pq[0]['high']==102


def test_complete_smart_fetch_has_zero_provider_requests(cash,monkeypatch):
    cash.sink.write_batch(cash.rows)
    import model.fyers.auth as auth
    monkeypatch.setattr(auth,'get_authenticated_client',lambda _:pytest.fail('Covered range must not authenticate/call FYERS'))
    jid=cash.submit('admin','SMART_FETCH',cash.params);cash.runner().run_one()
    j=cash.store.get(jid)
    assert j['state']=='SUCCESS' and j['requests_made']==0


def test_smart_preview_finds_internal_hole_and_blocks_storage_conflict(cash):
    cash.sink.write_batch(cash.rows[:4]+cash.rows[5:])
    p=cash.smart_preview(cash.params)
    assert len(p['items'])==1 and p['items'][0]['missing']==1
    assert p['items'][0]['from'].endswith('09:19:00+05:30')
    with cash.engine.begin() as c:c.execute(text("UPDATE candles SET high=103 WHERE instrument_id IN (SELECT id FROM instruments WHERE internal_name='R4TEST') LIMIT 1"))
    assert cash.smart_preview(cash.params)['blocked']
    with pytest.raises(ValueError):cash.submit('admin','SMART_FETCH',cash.params)


def test_verifier_detects_missing_derived_and_is_read_only(cash):
    cash.sink.write_batch(cash.rows)
    def fingerprint():
        data=cash.reader.query('SELECT * FROM candles ORDER BY id')
        files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in cash.reader.root.rglob('*.parquet')}
        return json.dumps(data,default=str,sort_keys=True),files
    before=fingerprint();jid=cash.submit('admin','VERIFY',cash.params);cash.runner().run_one()
    j=cash.store.get(jid);findings=cash.store.findings(jid)
    assert j['state']=='PARTIAL' and j['result']['checks']['FAIL']>=5
    assert any(r['check_name']=='aggregation' and r['status']=='FAIL' for r in findings)
    assert fingerprint()==before


def test_false_checkpoint_empty_day_detected(cash):
    with cash.engine.begin() as c:c.execute(text("INSERT INTO checkpoints (fyers_symbol,timeframe,synced_through_date) VALUES ('NSE:R4TEST-EQ','1m',:d)"),{'d':DAY})
    jid=cash.submit('admin','VERIFY',cash.params);cash.runner().run_one()
    rows=cash.store.findings(jid,'checkpoints')
    assert rows[0]['status']=='FAIL' and rows[0]['details']['missing']==375


def test_permissions_dedup_cancel_and_interruption(cash):
    from model.fno.errors import DuplicateJobError
    with pytest.raises(PermissionError):cash.submit('user','VERIFY',cash.params)
    jid=cash.submit('admin','VERIFY',cash.params)
    with pytest.raises(DuplicateJobError):cash.submit('admin','VERIFY',cash.params)
    with pytest.raises(PermissionError):cash.action('user','cancel',jid)
    cash.action('admin','cancel',jid);assert cash.store.get(jid)['state']=='CANCELLED'
    jid=cash.submit('admin','VERIFY',cash.params);cash.store.claim_next()
    with cash.engine.begin() as c:c.execute(text('UPDATE ingestion_jobs SET heartbeat_at=:n WHERE id=:i'),{'i':jid,'n':dt.datetime(2000,1,1)})
    assert cash.runner().recover()==[jid]
    new=cash.action('admin','resume',jid);assert cash.store.get(new)['resumed_from']==jid


def test_report_export_streams_all_findings(cash,tmp_path):
    from controller.pipeline_cli import export_report
    jid=cash.submit('admin','VERIFY',cash.params);cash.runner().run_one()
    path=export_report(cash.store,jid,tmp_path/'report.json')
    report=json.loads(open(path).read())
    assert report['job']['result']['rule_version'] and len(report['findings'])>15


def test_metadata_preview_rejects_stale_and_does_not_trust_changes(cash):
    from model.master_management import sync_preview,apply_sync
    preview=sync_preview(cash.engine,cash.instruments)
    preview['changes']=[{'after':{'fyers_symbol':'EVIL'}}];preview['count']=900
    result=apply_sync(cash.engine,cash.instruments,preview,'admin',True)
    assert result['updated']==1 and cash.reader.instrument('NSE:R4TEST-EQ')
    with pytest.raises(ValueError):apply_sync(cash.engine,cash.instruments,preview,'admin',True)
    with pytest.raises(PermissionError):apply_sync(cash.engine,cash.instruments,preview,'user',True)


def test_end_of_day_queuing_is_restart_idempotent(cash):
    from controller.pipeline_cli import schedule_eod
    now=dt.datetime(2026,10,19,19,tzinfo=IST)
    first=schedule_eod(cash,now)
    cash.store.finish(first,'SUCCESS',result={})
    assert schedule_eod(cash,now)==first


def test_alert_preview_retry_dedup_and_delivery_no_network(cash):
    from model.monitoring import configure,emit,flush,dispatch_alerts
    configure(cash.engine);emit('TEST_FAILURE',{},severity='ERROR');emit('TEST_FAILURE',{},severity='ERROR');assert flush()
    assert dispatch_alerts(cash.engine)['pending']==1
    def broken(_):raise OSError('offline')
    assert dispatch_alerts(cash.engine,True,broken)['retry_pending']==1
    sent=[];assert dispatch_alerts(cash.engine,True,sent.append)['delivered']==1
    assert len(sent)==1 and dispatch_alerts(cash.engine)['pending']==0


@pytest.mark.parametrize('section',['Verification Overview','Historical Coverage','Data Integrity','MySQL vs Parquet','Checkpoint Health','Ingestion Job Diagnostics','Aggregation Verification','Live Feed & Persistence','Verification History'])
def test_nine_quality_views_render_with_real_database(cash,monkeypatch,section):
    import sys
    from pathlib import Path
    sys.path.insert(0,str(Path(__file__).parents[1]))
    from test_dashboard_layer import _authed_apptest
    import ui.quality_page as page
    monkeypatch.setattr(page,'get_service',lambda:cash)
    jid=cash.submit('admin','VERIFY',cash.params);cash.runner().run_one()
    at=_authed_apptest('ui/views/quality_cash.py','user',monkeypatch)
    at=next(r for r in at.radio if r.key=='quality_section').set_value(section).run()
    assert not at.exception and not at.error
    assert not any(b.label in ('Run checks','Resume verification','Apply verification migration') for b in at.button)


def test_master_table_read_access_and_grouped_dashboard(cash,monkeypatch):
    import sys
    from pathlib import Path
    sys.path.insert(0,str(Path(__file__).parents[1]))
    from test_dashboard_layer import _authed_apptest
    import ui.quality_page as page
    monkeypatch.setattr(page,'get_service',lambda:cash)
    at=_authed_apptest('ui/views/master_tables.py','user',monkeypatch)
    assert not at.exception and not at.error
    assert not any(b.label=='Apply metadata sync' for b in at.button)
    at=_authed_apptest('ui/dashboard.py','user',monkeypatch)
    assert not at.exception
    assert any(t.value=='Overview' for t in at.title)


def test_verified_analysis_reads_recheck_sources_and_bound_partitions(cash):
    from model.repository import MarketDataRepository
    from model.verified_reads import QualityNotVerifiedError
    cash.sink.write_batch(cash.rows)
    repo=MarketDataRepository(cash.env,cash.settings,cash.instruments)
    repo._mysql_engine=cash.engine;repo._parquet_sink=cash.pq_sink
    days=list(repo.iter_verified_days('R4TEST','1m',str(DAY),str(DAY)))
    assert len(days)==1 and len(days[0][1])==375
    with cash.engine.begin() as c:c.execute(text("DELETE FROM candles WHERE instrument_id IN (SELECT id FROM instruments WHERE internal_name='R4TEST') LIMIT 1"))
    with pytest.raises(QualityNotVerifiedError):list(repo.iter_verified_days('R4TEST','1m',str(DAY),str(DAY)))


def test_smart_fetch_exact_missing_range_then_idempotent(cash,monkeypatch):
    import model.fyers.auth as auth
    cash.sink.write_batch(cash.rows[:4]+cash.rows[5:]);calls=[]
    class Client:
        def history(self,data):
            calls.append(data);r=cash.rows[4]
            return {'s':'ok','candles':[[int(r.timestamp.timestamp()),100,102,99,101,10]]}
    monkeypatch.setattr(auth,'get_authenticated_client',lambda _:Client())
    monkeypatch.setattr('model.fyers.rate_limiter.acquire_shared',lambda:0)
    jid=cash.submit('admin','SMART_FETCH',cash.params);cash.runner().run_one()
    job=cash.store.get(jid)
    assert job['state']=='SUCCESS' and job['rows_stored']==1 and job['requests_made']==1
    assert calls[0]['range_from']==calls[0]['range_to']==str(int(cash.rows[4].timestamp.timestamp()))
    assert not cash.smart_preview(cash.params)['items']


def test_smart_fetch_expired_token_interrupts_without_retry(cash,monkeypatch):
    import model.fyers.auth as auth
    calls=[]
    class Client:
        def history(self,data):calls.append(data);return {'s':'error','code':-16,'message':'Token expired'}
    monkeypatch.setattr(auth,'get_authenticated_client',lambda _:Client())
    monkeypatch.setattr('model.fyers.rate_limiter.acquire_shared',lambda:0)
    jid=cash.submit('admin','SMART_FETCH',cash.params);cash.runner().run_one()
    job=cash.store.get(jid)
    assert job['state']=='INTERRUPTED' and job['requests_made']==1 and len(calls)==1


def test_parquet_identity_corruption_fails_verification(cash):
    import pandas as pd
    cash.sink.write_batch(cash.rows[:1]);p=cash.reader.path('NSE:R4TEST-EQ','1m',DAY)
    frame=pd.read_parquet(p);frame['fyers_symbol']='NSE:WRONG-EQ';frame.to_parquet(p,index=False)
    jid=cash.submit('admin','VERIFY',cash.params);cash.runner().run_one()
    rows=cash.store.findings(jid,'storage')
    assert any(r['status']=='FAIL' and 'identity' in r['details'].get('reason','') for r in rows)


def test_headless_partial_verification_has_nonzero_exit_status(cash,monkeypatch):
    from controller.pipeline_cli import run
    monkeypatch.setattr('controller.pipeline_service.PipelineService',lambda:cash)
    result=run(SimpleNamespace(mode='verify',start=str(DAY),end=str(DAY),symbols=['R4TEST'],run=True))
    assert result==2


def test_smart_preview_rejects_duplicate_parquet_without_repair(cash):
    import pandas as pd
    cash.sink.write_batch(cash.rows)
    path=cash.reader.path('NSE:R4TEST-EQ','1m',DAY);frame=pd.read_parquet(path)
    pd.concat([frame,frame.iloc[:1]]).to_parquet(path,index=False)
    before=path.read_bytes()
    assert cash.smart_preview(cash.params)['blocked']
    assert path.read_bytes()==before


def test_oversized_partition_is_not_certified_and_reader_stays_bounded(cash,monkeypatch):
    import pyarrow.parquet as pq
    cash.sink.write_batch(cash.rows[:1])
    class Oversized:
        metadata=SimpleNamespace(num_rows=20001)
        def iter_batches(self,**kwargs):pytest.fail('Oversized partitions must not be materialized')
    monkeypatch.setattr(pq,'ParquetFile',lambda _:Oversized())
    with pytest.raises(RuntimeError,match='bounded'):cash.reader.parquet_day('NSE:R4TEST-EQ','1m',DAY)
