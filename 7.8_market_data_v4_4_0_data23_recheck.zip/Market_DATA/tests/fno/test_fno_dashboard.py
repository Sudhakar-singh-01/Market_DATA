import dataclasses
import datetime as dt
import json
from types import SimpleNamespace

import pandas as pd
import pytest
from sqlalchemy import text

from model.fno.config import load_fno_settings
from model.fno.job_store import FnoJobStore
from model.fno.parquet_store import FnoParquetStore
from model.fno.release3_repository import Release3Repository
from ui.fno.service import FnoService
from test_dashboard_layer import _authed_apptest
from tests_support import make_candle,sample_contract


class FakeService:
    def __init__(self):
        self.settings=load_fno_settings()
        self.calls=[]
        self.ready=True
    def schema_ready(self):return self.ready
    def overview(self):return {"contracts":[],"candles":[],"jobs":[]}
    def browse(self,*args,**kw):return [],0
    def safe_settings(self):return {"database":{"name":"fno_market_data"},"parquet_root":"data/fno"}
    def migrate(self,*args):self.calls.append(("migrate",args))
    def submit(self,*args):self.calls.append(("submit",args));return 7
    def historical_preview(self,p):return ({**p,"atm":{"NIFTY":25000}},{"requests":3},{"used_today":1})
    def destructive_preview(self,action,cid,tf,jt):
        return {"action":action,"contract_id":cid,"timeframe":tf,"job_type":jt,"count":12,"last_write":"now","last_id":12}
    def destructive_execute(self,*args,**kw):self.calls.append(("delete",args));return 12
    def cleanup_preview(self):return ["option_chain/underlying=NIFTY/date=2025-01-01.parquet"]
    def cleanup_execute(self,*args):self.calls.append(("cleanup",args));return args[1]


@pytest.fixture()
def ui(monkeypatch):
    import ui.fno.page as page
    service=FakeService()
    monkeypatch.setattr(page,"get_service",lambda:service)
    def app(role="admin"):
        return _authed_apptest("ui/views/fno_management.py",role,monkeypatch)
    return service,app


def choose(at,section):
    return next(r for r in at.radio if r.key=="fno_section").set_value(section).run()


def button(at,key):return next(b for b in at.button if b.key==key)


@pytest.mark.parametrize("role",["admin","user"])
def test_all_twelve_sections_render_with_empty_data_and_permissions(ui,role):
    from ui.fno.page import SECTIONS
    service,app=ui
    at=app(role)
    assert not at.exception
    assert next(r for r in at.radio if r.key=="fno_section").options==SECTIONS
    for section in SECTIONS:
        at=choose(at,section)
        assert not at.exception and not at.error,(section,[e.value for e in at.exception],[e.value for e in at.error])
        if role=="user":
            assert not any(b.key in {"fno_sync","fno_live_submit","fno_agg_submit","fno_verify_submit",
                "fno_hist_preview","fno_migrate_apply","fno_reset_apply"} for b in at.button)
    assert service.calls==[]


def test_lazy_selection_does_not_query_other_sections(ui):
    service,app=ui
    def boom():raise AssertionError("Overview should not render")
    at=choose(app(),"Settings")
    service.overview=boom
    at=at.run()
    assert not at.exception and not at.error


def test_reset_requires_preview_checkbox_and_phrase(ui):
    service,app=ui
    at=choose(app(),"Checkpoints")
    assert not any(b.key=="fno_reset_apply" for b in at.button)
    at=button(at,"fno_reset_preview").click().run()
    assert button(at,"fno_reset_apply").disabled
    at=next(c for c in at.checkbox if c.key=="fno_reset_confirm").check().run()
    assert button(at,"fno_reset_apply").disabled
    at=next(t for t in at.text_input if t.key=="fno_reset_phrase").set_value("CONFIRM").run()
    assert not button(at,"fno_reset_apply").disabled
    at=button(at,"fno_reset_apply").click().run()
    assert not at.exception and len(service.calls)==1 and service.calls[0][0]=="delete"


def test_changing_selection_requires_new_preview(ui):
    service,app=ui
    at=choose(app(),"Checkpoints")
    at=button(at,"fno_reset_preview").click().run()
    at=next(n for n in at.number_input if n.key=="fno_reset_cid").set_value(2).run()
    assert not any(b.key=="fno_reset_apply" for b in at.button) and not service.calls


def test_migrations_require_confirmation_and_historical_requires_estimate(ui):
    service,app=ui
    service.ready=False
    at=app()
    assert button(at,"fno_migrate_apply").disabled
    at=next(c for c in at.checkbox if c.key=="fno_migrate_confirm").check().run()
    at=button(at,"fno_migrate_apply").click().run()
    assert service.calls[0][0]=="migrate"
    service.ready=True
    at=choose(at,"Historical Fetch")
    assert not any(b.key=="fno_hist_submit" for b in at.button)
    at=button(at,"fno_hist_preview").click().run()
    assert not at.exception and button(at,"fno_hist_submit")
    at=button(at,"fno_hist_submit").click().run()
    assert service.calls[-1][1][1]=="HISTORICAL_HARVEST"


def test_db_error_is_visible_without_credentials(ui,monkeypatch):
    import ui.fno.page as page
    def fail():raise RuntimeError("secret-password-do-not-render")
    monkeypatch.setattr(page,"get_service",fail)
    at=ui[1]()
    assert not at.exception and len(at.error)==1
    assert "secret-password" not in at.error[0].value


@pytest.fixture()
def service(clean_fno,fno_cfg,tmp_path):
    settings=dataclasses.replace(load_fno_settings(),parquet_root=tmp_path/"fno")
    repo=Release3Repository(clean_fno)
    c=SimpleNamespace(engine=clean_fno,repo=repo,jobs=FnoJobStore(clean_fno),settings=settings,dbcfg=fno_cfg,
        store=FnoParquetStore(settings.parquet_root,repo))
    return FnoService(c)


def test_service_enforces_role_confirmation_stale_preview_and_atomic_audit(service):
    cid=service.repo.upsert_contract(sample_contract())
    service.repo.upsert_candles([make_candle(cid)])
    preview=service.destructive_preview("DELETE_CANDLES",cid,"1m")
    assert preview["count"]==1
    with pytest.raises(PermissionError):service.destructive_execute("user",preview,True)
    with pytest.raises(ValueError):service.destructive_execute("admin",preview)
    service.repo.upsert_candles([make_candle(cid,1)])
    with pytest.raises(ValueError,match="changed"):service.destructive_execute("admin",preview,True)
    preview=service.destructive_preview("DELETE_CANDLES",cid,"1m")
    assert service.destructive_execute("admin",preview,True)==2
    logs=service.repo.query("SELECT action,records_affected FROM fno_audit_log")
    assert logs==[{"action":"DELETE_CANDLES","records_affected":2}]


def test_user_cannot_submit_cancel_migrate_or_cleanup(service):
    for fn in (lambda:service.submit("user","LIVE",{}),lambda:service.job_action("user","run",0),
               lambda:service.migrate("user",True),lambda:service.cleanup_execute("user",[],True)):
        with pytest.raises(PermissionError):fn()


def test_server_side_filters_pagination_and_settings_redaction(service):
    for n in range(5):service.repo.upsert_contract(sample_contract(symbol=f"NSE:TEST{n}CE"))
    rows,total=service.browse("Contracts",page=1,size=2,filters={"category":"OPTIONS"})
    assert total==5 and len(rows)==2
    other,_=service.browse("Contracts",page=0,size=2)
    assert {r["id"] for r in rows}.isdisjoint(r["id"] for r in other)
    with pytest.raises(ValueError):service.browse("Contracts",filters={"bad SQL":"x"})
    text=json.dumps(service.safe_settings())
    assert "password" not in text.lower() and "access_token" not in text.lower()
