"""Provider-free ingestion boundaries: wrong scopes must not become verified data."""
import datetime as dt
from dataclasses import replace
from types import SimpleNamespace as NS

import pytest

from controller import fno_historical as history
from controller.fno_live import FnoLiveIngestor
from model.fno.config import load_fno_settings
from model.fno.history_client import ERROR, NO_DATA, OK, FetchResult, classify_response
from model.fno.models import IST, WriteResult
from model.fno.normalizer import normalize_expired_rows
from tests_support import make_candle, sample_contract

DAY = dt.date(2026, 10, 19)
SETTINGS = load_fno_settings()
COLUMNS = ['timestamp', 'open', 'high', 'low', 'close', 'volume']


def raw(day=DAY, minute=15):
    return [int(dt.datetime.combine(day, dt.time(9, minute), tzinfo=IST).timestamp()), 100, 101, 99, 100, 10]


def contract():
    return replace(sample_contract('NSE:NIFTY26OCTFUT', category='FUTURES', expiry=dt.date(2026, 10, 27)), contract_id=1)


class Repo:
    def __init__(self):
        self.rows = []
        self.checkpoints = []

    def upsert_candles(self, rows):
        self.rows.extend(rows)
        return WriteResult(inserted=len(rows))

    def verify_candles_present(self, rows):
        return True

    def accepted_candles(self, rows):
        return list(rows)

    def add_checkpoint_range(self, *args, **kwargs):
        self.checkpoints.append(args[5])

    def missing_ranges(self, *args):
        return [] if self.checkpoints[-1:] == ['VERIFIED'] else [(DAY, DAY)]

    def upsert_harvest_state(self, *args, **kwargs):
        pass


class Handle:
    id = 1
    params = {'from': DAY.isoformat(), 'to': DAY.isoformat()}

    def stop_outcome(self):
        return None

    def add(self, **kwargs):
        pass

    def heartbeat(self):
        pass


@pytest.mark.parametrize('candles', [None, {}, '', 'bad', False, 0, {'row': raw()}])
def test_malformed_success_payload_is_error_not_terminal_no_data(candles):
    assert classify_response({'s': 'ok', 'candles': candles}, SETTINGS.history)[0] == ERROR


def test_missing_candle_list_is_not_evidence_of_no_data():
    assert classify_response({'s': 'ok'}, SETTINGS.history)[0] == ERROR
    assert classify_response({'s': 'ok', 'candles': []}, SETTINGS.history)[0] == NO_DATA
    assert classify_response({'s': 'no_data'}, SETTINGS.history)[0] == NO_DATA


@pytest.mark.parametrize('row', [None, 1, 'abcdef', {'timestamp': 1}])
def test_expired_malformed_row_is_reported_without_aborting_other_rows(row):
    result = normalize_expired_rows([row, raw()], COLUMNS, 1)
    assert len(result.valid) == 1
    assert len(result.invalid) == 1 and result.invalid[0].reason == 'malformed_row'


@pytest.mark.parametrize('columns', [True, 42, COLUMNS + [[]], COLUMNS + ['iv', 'implied_volatility']])
def test_expired_unverified_column_schema_is_rejected_without_crashing(columns):
    result = normalize_expired_rows([raw()], columns, 1)
    assert not result.valid
    assert result.invalid[0].reason == 'unverified_expired_schema'


def test_harvest_rejects_provider_rows_outside_requested_dates(monkeypatch):
    repo = Repo()
    rows = [raw(), raw(day=DAY + dt.timedelta(days=1))]
    ctx = history.HarvestContext(repo, NS(fetch=lambda *a: FetchResult(OK, rows)), None, SETTINGS,
                                clock=lambda: dt.datetime(2026, 10, 20, 17, tzinfo=IST))
    item = history.PlanItem(contract(), DAY, DAY, 8)
    monkeypatch.setattr(history, 'make_plan_from_params', lambda *a: history.HarvestPlan([item], 1, effective_to=DAY))
    result = history.run_harvest(Handle(), ctx)
    assert result.state == 'PARTIAL'
    assert [row.timestamp.date() for row in repo.rows] == [DAY]
    assert repo.checkpoints == ['FAILED']
    assert result.result['invalid_reasons'] == {'outside_requested_range': 1}


@pytest.mark.parametrize('accepted', [[], [make_candle(2)]])
def test_harvest_canonical_readback_must_have_exact_requested_keys(accepted):
    repo = Repo()
    repo.accepted_candles = lambda rows: accepted
    writes = []
    ctx = NS(repo=repo, store=NS(write_candles=lambda *a, **k: writes.append(a)))
    item = history.PlanItem(contract(), DAY, DAY, 8)
    with pytest.raises(RuntimeError, match='canonical read-back'):
        history.persist_chunk(ctx, item, [make_candle(1)], 1)
    assert not writes


def test_harvest_partial_storage_exception_retains_completed_sql():
    repo = Repo()
    def fail(*a, **k):raise OSError('file locked')
    ctx = NS(repo=repo, store=NS(write_candles=fail))
    item = history.PlanItem(contract(), DAY, DAY, 8)
    with pytest.raises(OSError) as exc:
        history.persist_chunk(ctx, item, [make_candle(1)], 1)
    state = exc.value.recovery_state
    assert state['sql_write_completed'] and state['parquet_write_started']
    assert state['sql_rows_changed'] == 1 and not state['parquet_write_completed']
    assert state['atomic'] is False and len(repo.rows) == 1


def ingestor(response, *, store=None, now=None):
    repo = Repo()
    return FnoLiveIngestor(repo, store, SETTINGS, [contract()], fetcher=NS(fetch=lambda *a: response),
                           clock=lambda: now or dt.datetime(2026, 10, 19, 9, 17, 30, tzinfo=IST)), repo


@pytest.mark.parametrize('status', ['ERROR', 'INVALID_SYMBOL'])
def test_backfill_reports_provider_failures(status):
    live, repo = ingestor(FetchResult(status, []))
    result = live.backfill(DAY)
    assert result['failed'] == 1 and not repo.rows


def test_backfill_never_stores_other_dates_or_forming_minutes():
    live, repo = ingestor(FetchResult(OK, [raw(), raw(minute=17), raw(minute=18), raw(day=DAY - dt.timedelta(days=1))]))
    result = live.backfill(DAY)
    assert [row.timestamp for row in repo.rows] == [dt.datetime(2026, 10, 19, 9, 15, tzinfo=IST)]
    assert result['candles'] == 1 and result['invalid_rows'] == 1 and result['failed'] == 1


def test_backfill_partial_storage_reports_completed_mysql_and_pending_parquet():
    def fail(*args, **kwargs):
        raise OSError('disk full')
    live, repo = ingestor(FetchResult(OK, [raw()]), store=NS(write_candles=fail))
    result = live.backfill(DAY)
    assert len(repo.rows) == 1 and result['failed'] == 1 and result['candles'] == 0
    assert result['storage_failures'] == [{'contract_id': 1, 'mysql_write_completed': True,
                                          'parquet_write_completed': False, 'error_type': 'OSError'}]


def test_missing_volume_does_not_establish_fno_cumulative_baseline():
    live, repo = ingestor(FetchResult(OK, []))
    for minute, volume in [(15, None), (16, 5000), (17, 5010), (18, 5020)]:
        message = {'symbol': contract().fyers_symbol, 'ltp': 100, 'exch_feed_time': raw(minute=minute)[0]}
        if volume is not None:
            message['vol_traded_today'] = volume
        live.on_message(message)
    assert [c.volume for c in live._buffer] == [0, 0, 10]
