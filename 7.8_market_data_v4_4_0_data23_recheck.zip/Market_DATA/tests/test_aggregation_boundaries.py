"""Regression coverage for bounded aggregation and exchange session evidence."""
import datetime as dt
from contextlib import nullcontext
from dataclasses import replace
from decimal import Decimal
from types import SimpleNamespace

import pytest
import yaml

from controller.timeframe_controller import generate_timeframe_for_instrument
from model.config import market_calendar as calendar
from model.config.instrument_loader import Instrument, InstrumentRegistry
from model.fno.aggregation import aggregate_day
from model.fno.config import DEFAULT_SESSION
from model.fno.models import FnoCandle
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe

DAY = dt.date(2026, 10, 19)
NOW = dt.datetime(2026, 10, 22, 17, tzinfo=calendar.IST)
INSTRUMENT = Instrument('TEST', 'NSE:TEST-EQ', 'NSE', 'EQ', True, 'stock')


def cash_rows(day=DAY, count=5):
    start = dt.datetime.combine(day, dt.time(9, 15), calendar.IST)
    return [Candle('TEST', 'NSE:TEST-EQ', 'EQ', 'NSE', start+dt.timedelta(minutes=i),
                   '1m', 100, 102, 99, 101, 10, 'FYERS_HISTORICAL') for i in range(count)]


def fno_rows(day=DAY, count=385):
    return [FnoCandle(1, '1m', row.timestamp, *(Decimal(str(p)) for p in
                     (row.open, row.high, row.low, row.close)), row.volume)
            for row in cash_rows(day, count)]


def test_cash_generation_never_writes_outside_requested_symbol_or_dates():
    rows = cash_rows() + cash_rows(dt.date(2026, 10, 21))
    rows += [replace(c, fyers_symbol='NSE:OTHER-EQ', internal_name='OTHER') for c in cash_rows()]
    written = []
    result = generate_timeframe_for_instrument(INSTRUMENT, '5m', str(DAY), str(DAY),
        lambda *args: rows, InstrumentRegistry([INSTRUMENT]),
        SimpleNamespace(validation_enabled=False), SimpleNamespace(write_batch=written.extend))
    assert result.status == 'partial' and result.rejected_source_count == 10
    assert len(written) == 1
    assert {(c.fyers_symbol, c.timestamp.date()) for c in written} == {(INSTRUMENT.fyers_symbol, DAY)}


@pytest.mark.parametrize('volume', [float('inf'), float('nan'), 1.5, True])
def test_cash_invalid_volume_cannot_form_a_closed_derived_bar(volume):
    rows = cash_rows()
    rows[0] = replace(rows[0], volume=volume)
    assert aggregate_1m_to_timeframe(rows, '5m') == []


@pytest.mark.parametrize('volume', [float('inf'), float('nan'), 1.5, True])
def test_fno_invalid_volume_cannot_form_a_closed_derived_bar(volume):
    rows = fno_rows(count=5)
    rows[0] = replace(rows[0], volume=volume)
    result = aggregate_day(rows, DAY, '5m', now=NOW)
    assert not result.candles and result.invalid_rows == 1


@pytest.fixture
def split_calendar(tmp_path):
    path = tmp_path/'calendar.yaml'
    path.write_text(yaml.safe_dump({'verified_years': {'CASH': [2026], 'FNO': [2026]},
        'holidays': ['2026-10-20'], 'special_sessions': {str(DAY): {
            'segments': ['FNO'], 'verified': True, 'intervals': [
                {'open': '09:15', 'close': '09:20'}, {'open': '11:30', 'close': '11:35'}]}}}), encoding='utf-8')
    calendar.reload_holidays(path)
    yield
    calendar.reload_holidays()


@pytest.mark.parametrize('timeframe, count', [('3m', 4), ('5m', 2), ('1d', 1)])
def test_fno_split_session_aggregates_only_real_minutes(split_calendar, timeframe, count):
    rows = fno_rows(count=5)
    rows += [replace(c, timestamp=c.timestamp+dt.timedelta(hours=2, minutes=15)) for c in rows]
    result = aggregate_day(rows, DAY, timeframe, now=NOW)
    assert len(result.candles) == count and result.skipped == 0
    assert sum(c.volume for c in result.candles) == 100
    assert result.candles[0].timestamp == rows[0].timestamp


def test_fno_session_break_rows_are_rejected(split_calendar):
    rows = fno_rows(count=6)
    result = aggregate_day(rows, DAY, '5m', now=NOW)
    assert result.invalid_rows == 1 and len(result.candles) == 1


def test_fno_ingestion_uses_same_split_session_as_aggregation(split_calendar):
    from model.fno.normalizer import normalize_history_rows
    rows = fno_rows(count=6)
    raw = [[c.timestamp.timestamp(), c.open, c.high, c.low, c.close, c.volume] for c in rows]
    result = normalize_history_rows(raw, 1)
    assert len(result.valid) == 5
    assert [r.reason for r in result.invalid] == ['outside_session']


def test_fno_holiday_does_not_generate_derived_rows(split_calendar):
    result = aggregate_day(fno_rows(dt.date(2026, 10, 20)), dt.date(2026, 10, 20), '5m', now=NOW)
    assert not result.candles and result.invalid_rows == 385


def test_fno_coverage_does_not_count_break_minutes(split_calendar):
    from controller.fno_verify import coverage
    rows = fno_rows(count=5)
    rows += [replace(c, timestamp=c.timestamp+dt.timedelta(hours=2, minutes=15)) for c in rows]
    status, report = coverage(rows, DAY, 'FUTURES', DEFAULT_SESSION, NOW)
    assert status == 'PASS'
    assert report['session_minutes_elapsed'] == 10 and report['missing_minutes'] == 0
    assert report['largest_silent_stretch_minutes'] == 0


class AggregationRepo:
    def __init__(self):
        self.engine = None
        self.derived = {}
        self.checkpoints = []
        self.writes = []
    def iter_contracts(self, *args, **kwargs):
        return iter([SimpleNamespace(contract_id=1, underlying='NIFTY', expiry=dt.date(2026, 11, 26))])
    def start_aggregation(self, *args): return 1
    def partition_lock(self, *args): return nullcontext()
    def fetch_candles(self, cid, tf, a, b):
        return fno_rows(a) if tf == '1m' and a == DAY else self.derived.get((tf, a), [])
    def invalidate_aggregation_day(self, *args): self.writes.append(('invalidate', args))
    def replace_derived_day(self, cid, tf, day, rows):
        self.writes.append(('replace', day)); self.derived[tf, day] = rows
    def add_checkpoint_range(self, *args): self.checkpoints.append(args)
    def aggregation_progress(self, *args): pass


def test_fno_complete_day_followed_by_empty_trading_day_is_not_success(monkeypatch):
    import controller.fno_aggregate as controller
    repo = AggregationRepo()
    monkeypatch.setattr(controller, 'Release3Repository', lambda _: repo)
    handle = SimpleNamespace(id=1, params={'from': str(DAY), 'to': '2026-10-21',
        'contract_ids': [1], 'timeframes': ['5m']},
        stop_outcome=lambda *args: None, add=lambda **kwargs: None, heartbeat=lambda: None)
    settings = SimpleNamespace(session=DEFAULT_SESSION, history=SimpleNamespace(session_close_buffer_minutes=2))
    result = controller.run_aggregation(handle, repo, None, settings, now=NOW)
    assert result.state == 'PARTIAL'
    stats = result.result['targets']['5m']
    assert stats['missing_buckets'] == 77 and stats['output_rows'] == 77
    assert stats['days'] == 2  # Holiday has no expected buckets.


def test_fno_aggregation_records_sql_completed_before_parquet_failure(monkeypatch):
    import copy
    import controller.fno_aggregate as controller
    repo = AggregationRepo()
    repo.partition_candles = lambda underlying, expiry, tf, day: repo.derived[(tf,day)]
    monkeypatch.setattr(controller, 'Release3Repository', lambda _: repo)
    evidence = []
    handle = SimpleNamespace(id=1, params={'from': str(DAY), 'to': str(DAY), 'contract_ids': [1], 'timeframes': ['5m']},
        stop_outcome=lambda *args: None, add=lambda **kwargs: None, heartbeat=lambda: None,
        progress=lambda result: evidence.append(copy.deepcopy(result)))
    settings = SimpleNamespace(session=DEFAULT_SESSION, history=SimpleNamespace(session_close_buffer_minutes=2))
    def fail(*args):raise OSError('partition locked')
    store = SimpleNamespace(relative_candle_path=lambda *args: 'test.parquet', replace_derived_partition=fail)
    with pytest.raises(OSError, match='locked'):
        controller.run_aggregation(handle, repo, store, settings, now=NOW)
    state = evidence[-1]['current_write']
    assert state['sql_write_completed'] and not state['parquet_write_completed'] and state['parquet_required']
    assert not state['atomic'] and len(repo.derived[('5m',DAY)]) == 77

