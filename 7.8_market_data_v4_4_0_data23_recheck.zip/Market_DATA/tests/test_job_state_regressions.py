"""Provider-free job ownership/race checks against disposable SQLite stores."""
import datetime as dt
import json
import threading

import pytest
from sqlalchemy import create_engine, event, text

from controller.fno_jobs import FnoJobRunner, JobHandle, JobOutcome
from model.fno.job_store import COUNTERS, FnoJobStore
from model.quality_store import QualityStore


@pytest.fixture(params=['CASH', 'FNO'])
def queue(request, tmp_path, monkeypatch):
    engine = create_engine('sqlite:///' + str(tmp_path / 'jobs.db'))
    table = 'ingestion_jobs' if request.param == 'CASH' else 'fno_ingestion_jobs'
    counters = ','.join(name + ' INTEGER NOT NULL DEFAULT 0' for name in COUNTERS)
    with engine.begin() as conn:
        conn.execute(text(f'''CREATE TABLE {table} (
            id INTEGER PRIMARY KEY, job_type TEXT, status TEXT, state TEXT,
            params TEXT, result TEXT, error TEXT, dedupe_key TEXT, active_key TEXT UNIQUE,
            resumed_from INTEGER, cancel_requested INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP, started_at DATETIME,
            heartbeat_at DATETIME, finished_at DATETIME, {counters})'''))
        conn.execute(text('''CREATE TABLE audit_log (actor_role TEXT, action TEXT, target TEXT,
            parameters TEXT, records_affected INTEGER, result TEXT)'''))
        conn.execute(text('''CREATE TABLE fno_aggregation_jobs (
            state TEXT, heartbeat_at DATETIME, finished_at DATETIME, error TEXT,
            contract_selection TEXT)'''))
    if request.param == 'FNO':
        monkeypatch.setattr('model.fno.job_store.is_fno_engine', lambda selected: selected is engine)
        with engine.connect() as conn:
            conn.connection.driver_connection.create_function('JSON_UNQUOTE', 1, lambda value: value)
        store = FnoJobStore(engine)
    else:
        store = QualityStore(engine)
    yield store, engine, table
    engine.dispose()


def submit(store, value=1):
    return store.submit('VERIFY', {'value': value})


def test_selected_job_claim_leaves_unrelated_job_pending(queue):
    store, _, _ = queue
    first, selected = submit(store), submit(store, 2)
    runner = FnoJobRunner(store, {'VERIFY': lambda handle: JobOutcome('SUCCESS', {'id': handle.id})})
    assert runner.run_one(job_id=selected) == selected
    assert store.get(first)['state'] == 'PENDING'
    assert store.get(selected)['state'] == 'SUCCESS'
    assert runner.run_one(job_id=selected) is None
    assert store.get(first)['state'] == 'PENDING'


def test_claim_filter_is_applied_before_queue_limit(queue):
    store, engine, table = queue
    with engine.begin() as conn:
        for value in range(105):
            conn.execute(text(f"INSERT INTO {table} (job_type,state,params) VALUES ('UNKNOWN','PENDING','{{}}')"))
    selected = submit(store)
    assert store.claim_next(['VERIFY'])['id'] == selected


def test_late_worker_cannot_overwrite_terminal_state_or_result(queue):
    store, _, _ = queue
    jid = submit(store)
    store.claim_next()
    evidence = {'stored': 12, 'recovery_needed': True}
    store.finish(jid, 'INTERRUPTED', result=evidence)
    store.progress(jid, {'stored': 13})
    store.add_counters(jid, rows_stored=13)
    store.finish(jid, 'SUCCESS', result={'stored': 14})
    row = store.get(jid)
    assert row['state'] == 'INTERRUPTED'
    assert row['result'] == evidence
    assert row['rows_stored'] == 0


@pytest.mark.parametrize('rival_action', ['heartbeat', 'finish'])
def test_recovery_rechecks_stale_predicate_before_transition(queue, rival_action):
    store, engine, table = queue
    jid = submit(store)
    store.claim_next()
    with engine.begin() as conn:
        conn.execute(text(f"UPDATE {table} SET heartbeat_at='2000-01-01' WHERE id=:id"), {'id': jid})
    intercepted = []
    def race(conn, cursor, statement, parameters, context, many):
        if intercepted or not statement.lstrip().upper().startswith('UPDATE') or "state='INTERRUPTED'" not in statement:
            return
        intercepted.append(True)
        if rival_action == 'heartbeat':
            conn.exec_driver_sql(f"UPDATE {table} SET heartbeat_at='2099-01-01' WHERE id={jid}")
        else:
            conn.exec_driver_sql(f"UPDATE {table} SET state='SUCCESS', result='{{\"done\":12}}' WHERE id={jid}")
    event.listen(engine, 'before_cursor_execute', race)
    try:
        assert store.recover_interrupted(90) == []
    finally:
        event.remove(engine, 'before_cursor_execute', race)
    assert intercepted
    assert store.get(jid)['state'] == ('RUNNING' if rival_action == 'heartbeat' else 'SUCCESS')


def test_recovery_preserves_progress_and_blocks_old_handle(queue):
    store, engine, table = queue
    jid = submit(store)
    job = store.claim_next()
    store.progress(jid, {'completed': ['SQL'], 'pending': ['PARQUET']})
    with engine.begin() as conn:
        conn.execute(text(f"UPDATE {table} SET heartbeat_at='2000-01-01' WHERE id=:id"), {'id': jid})
    assert store.recover_interrupted(90) == [jid]
    assert store.get(jid)['result']['completed'] == ['SQL']
    assert JobHandle(store, job, threading.Event()).stop_outcome().state == 'INTERRUPTED'


def test_handler_interruption_retains_durable_progress(queue):
    from controller.worker_lifecycle import WorkerInterrupted
    store, _, _ = queue
    jid = submit(store)
    def handler(handle):
        handle.progress({'completed': ['SQL'], 'pending': ['PARQUET']})
        raise WorkerInterrupted('Stopped before Parquet')
    FnoJobRunner(store, {'VERIFY': handler}).run_one()
    row = store.get(jid)
    assert row['state'] == 'INTERRUPTED'
    assert row['result'] == {'completed': ['SQL'], 'pending': ['PARQUET']}
