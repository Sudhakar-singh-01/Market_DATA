import copy
import datetime as dt
import json
import pandas as pd
import pytest
from sqlalchemy import create_engine,text
from model.config.market_calendar import IST
from model.storage_inventory import fingerprint
from model.cash_recovery import RecoveryStore,make_plan,apply_plan

NOW=dt.datetime(2026,10,27,tzinfo=IST)
REL='raw/1m/NSE_SBIN-EQ/2025-01-02.parquet'


@pytest.fixture
def setup(tmp_path,monkeypatch):
    import model.cash_inventory_preview as q
    monkeypatch.setattr(q,'calendar_verified',lambda d:False)
    engine=create_engine('sqlite:///'+str(tmp_path/'test.db'))
    with engine.begin() as c:
        c.execute(text('CREATE TABLE instruments (id INTEGER PRIMARY KEY,fyers_symbol TEXT,internal_name TEXT,exchange TEXT,instrument_type TEXT)'))
        c.execute(text("INSERT INTO instruments VALUES(1,'NSE:SBIN-EQ','SBIN','NSE','EQUITY')"))
        c.execute(text('CREATE TABLE candles (id INTEGER PRIMARY KEY,instrument_id INTEGER NOT NULL,timeframe TEXT NOT NULL,candle_timestamp DATETIME NOT NULL,open REAL,high REAL,low REAL,close REAL,volume INTEGER,source TEXT,status TEXT,UNIQUE(instrument_id,timeframe,candle_timestamp))'))
    store=RecoveryStore(engine);root=tmp_path/'cash';root.mkdir();ops=tmp_path/'operations'
    rows=[dict(fyers_symbol='NSE:SBIN-EQ',internal_name='SBIN',exchange='NSE',instrument_type='EQUITY',
        candle_timestamp=dt.datetime(2025,1,2,9,15+i,tzinfo=IST),timeframe='1m',open=100.,high=102.,low=99.,close=101.,volume=10,source='FYERS',status='CLOSED') for i in range(2)]
    source=tmp_path/'old'/REL;source.parent.mkdir(parents=True);pd.DataFrame(rows).to_parquet(source,index=False)
    sha,size=fingerprint(source)
    report={'format_version':1,'complete':True,'partitions':[{'relative_path':REL,'variants':[{'path':str(source),'sha256':sha}]}]}
    yield store,root,ops,report,rows,source
    engine.dispose()


def test_insert_restore_preserve_source_and_idempotent_resume(setup):
    store,root,ops,report,rows,source=setup
    before=source.read_bytes();plan=make_plan(report,root,store,now=NOW)
    assert plan['summary']['sql_insert_rows']==2
    assert not ops.exists() and not list(root.iterdir())
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='COMPLETE' and r['inserted_rows']==2 and r['restored_files']==1
    assert (root/REL).read_bytes()==before==source.read_bytes()
    backups=list(ops.rglob('before.json'));assert len(backups)==1
    assert json.loads(backups[0].read_text())['sql_rows']==[]
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['applied_statuses']=={'ALREADY_CONSISTENT':1} and r['inserted_rows']==0


def test_existing_sql_never_updates(setup):
    store,root,ops,report,rows,source=setup
    with store.engine.begin() as c:store.insert_missing(c,1,rows[:1])
    with store.engine.connect() as c:before=dict(c.execute(text('SELECT * FROM candles')).mappings().one())
    plan=make_plan(report,root,store,now=NOW)
    assert plan['summary']['sql_insert_rows']==1
    apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    with store.engine.connect() as c:after=dict(c.execute(text('SELECT * FROM candles WHERE id=:i'),{'i':before['id']}).mappings().one())
    assert before==after


def test_conflicting_sql_unresolved_no_write(setup):
    store,root,ops,report,rows,source=setup
    bad=copy.deepcopy(rows);bad[0]['close']=100
    with store.engine.begin() as c:store.insert_missing(c,1,bad)
    plan=make_plan(report,root,store,now=NOW)
    assert plan['summary']['statuses']=={'UNRESOLVED':1}
    assert not ops.exists()


def test_variant_conflict_not_chosen_by_file_size(setup):
    store,root,ops,report,rows,source=setup
    bad=copy.deepcopy(rows);bad[0]['close']=100
    other=source.parent/'other.parquet';pd.DataFrame(bad).to_parquet(other,index=False)
    report['partitions'][0]['variants'].append({'path':str(other),'sha256':fingerprint(other)[0]})
    plan=make_plan(report,root,store,now=NOW)
    assert plan['entries'][0]['reason']=='usable_variants_conflict_or_need_union'


def test_invalid_variant_preserved_but_good_candidate_used(setup):
    store,root,ops,report,rows,source=setup
    bad=copy.deepcopy(rows);bad[0]['high']=50
    other=source.parent/'bad.parquet';pd.DataFrame(bad).to_parquet(other,index=False)
    report['partitions'][0]['variants'].append({'path':str(other),'sha256':fingerprint(other)[0]})
    plan=make_plan(report,root,store,now=NOW)
    assert plan['entries'][0]['status']=='READY'
    assert other.exists()


def test_destination_conflict_blocks_only_partition(setup):
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW)
    target=root/REL;target.parent.mkdir(parents=True);target.write_bytes(b'preserve')
    result=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert result['status']=='PARTIAL' and target.read_bytes()==b'preserve'
    assert store.rows(1,dt.date(2025,1,2))==[]


def test_insert_failure_rolls_back_and_does_not_publish(setup,monkeypatch):
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW);original=store.insert_missing
    def fail(conn,iid,data):original(conn,iid,data);raise RuntimeError('transaction failed')
    monkeypatch.setattr(store,'insert_missing',fail)
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='PARTIAL' and not (root/REL).exists()
    assert store.rows(1,dt.date(2025,1,2))==[]


def test_failure_after_commit_can_resume(setup,monkeypatch):
    import model.cash_recovery as m
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW);real=m.os.link
    def fail(src,dst):
        if dst.name=='2025-01-02.parquet':raise OSError('publish failure')
        return real(src,dst)
    monkeypatch.setattr(m.os,'link',fail)
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='PARTIAL' and r['inserted_rows']==2
    assert len(store.rows(1,dt.date(2025,1,2)))==2 and not (root/REL).exists()
    monkeypatch.setattr(m.os,'link',real)
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='COMPLETE' and r['inserted_rows']==0 and r['restored_files']==1


def test_schema_without_unique_constraint_rejected(setup):
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW)
    with store.engine.begin() as c:
        c.execute(text('ALTER TABLE candles RENAME TO old_candles'))
        c.execute(text('CREATE TABLE candles AS SELECT * FROM old_candles'))
    with pytest.raises(ValueError):apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert not ops.exists()


def test_ack_and_path_guards(setup):
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW)
    with pytest.raises(ValueError):apply_plan(plan,root,store,ops,now=NOW)
    plan['entries'][0]['item']['relative_path']='../escape'
    with pytest.raises(ValueError):apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)


def test_one_failed_partition_does_not_block_another(setup):
    store,root,ops,report,rows,source=setup
    rows2=copy.deepcopy(rows)
    for r in rows2:r['candle_timestamp']+=dt.timedelta(days=1)
    rel2=REL.replace('2025-01-02','2025-01-03')
    source2=source.parent/'2025-01-03.parquet';pd.DataFrame(rows2).to_parquet(source2,index=False)
    report['partitions'].append({'relative_path':rel2,'variants':[{'path':str(source2),'sha256':fingerprint(source2)[0]}]})
    plan=make_plan(report,root,store,now=NOW)
    source.write_bytes(b'stale after plan')
    result=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert result['status']=='PARTIAL'
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1,'VERIFIED':1}
    assert (root/rel2).exists() and not (root/REL).exists()


def test_backup_failure_prevents_sql_inserts(setup,monkeypatch):
    import model.cash_recovery as m
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW)
    def fail(*args,**kwargs):raise OSError('disk full')
    monkeypatch.setattr(m,'write_json_new',fail)
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='PARTIAL'
    assert store.rows(1,dt.date(2025,1,2))==[] and not (root/REL).exists()


def test_publication_race_preserves_other_writer_file(setup,monkeypatch):
    import model.cash_recovery as m
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW);original=m.os.link
    def race(src,dst):
        if dst.name=='2025-01-02.parquet':dst.write_bytes(b'concurrent writer')
        return original(src,dst)
    monkeypatch.setattr(m.os,'link',race)
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='PARTIAL' and (root/REL).read_bytes()==b'concurrent writer'
    assert r['outcomes'][0]['sql_may_have_committed']


def test_partial_coverage_warning_retained(setup,monkeypatch):
    import model.cash_inventory_preview as q
    store,root,ops,report,rows,source=setup
    monkeypatch.setattr(q,'calendar_verified',lambda d:True)
    monkeypatch.setattr(q,'expected_starts',lambda d:[r['candle_timestamp'] for r in rows]+[rows[-1]['candle_timestamp']+dt.timedelta(minutes=1)])
    plan=make_plan(report,root,store,now=NOW)
    assert plan['entries'][0]['status']=='READY'
    assert 'incomplete_minute_coverage' in plan['entries'][0]['item']['warnings']


def test_deleted_sql_after_plan_is_not_silently_reimported(setup):
    store,root,ops,report,rows,source=setup
    with store.engine.begin() as c:store.insert_missing(c,1,rows[:1])
    plan=make_plan(report,root,store,now=NOW)
    assert plan['summary']['sql_insert_rows']==1
    with store.engine.begin() as c:c.execute(text('DELETE FROM candles'))
    r=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert r['status']=='PARTIAL' and r['inserted_rows']==0
    assert r['outcomes'][0]['reason']=='SQL_missing_scope_changed_replan'


def conflicting_source(setup):
    store,root,ops,report,rows,source=setup
    bad=copy.deepcopy(rows);bad[0]['close']=100
    other=source.parent/'conflict.parquet';pd.DataFrame(bad).to_parquet(other,index=False)
    report['partitions'][0]['variants'].append({'path':str(other),'sha256':fingerprint(other)[0]})
    return other


def test_explicit_sql_exact_conflict_restore_preserves_every_source(setup):
    store,root,ops,report,rows,source=setup
    other=conflicting_source(setup);before=other.read_bytes()
    with store.engine.begin() as c:store.insert_missing(c,1,rows)
    assert make_plan(report,root,store,now=NOW)['entries'][0]['status']=='UNRESOLVED'
    plan=make_plan(report,root,store,now=NOW,prefer_sql_exact=True)
    assert plan['summary']['sql_exact_selections']==1
    assert plan['summary']['sql_insert_rows']==0
    assert plan['entries'][0]['item']['sql_exact_required']
    result=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert result['restored_files']==1 and result['inserted_rows']==0
    assert other.read_bytes()==before and (root/REL).read_bytes()==source.read_bytes()


@pytest.mark.parametrize('sql_kind',['empty','subset','conflicting'])
def test_sql_exact_option_never_selects_without_full_match(setup,sql_kind):
    store,root,ops,report,rows,source=setup;conflicting_source(setup)
    data=[] if sql_kind=='empty' else copy.deepcopy(rows[:1] if sql_kind=='subset' else rows)
    if sql_kind=='conflicting':data[0]['close']=99.5
    with store.engine.begin() as c:store.insert_missing(c,1,data)
    plan=make_plan(report,root,store,now=NOW,prefer_sql_exact=True)
    assert plan['entries'][0]['status']=='UNRESOLVED'
    assert not (root/REL).exists()


@pytest.mark.parametrize('change',['delete','value'])
def test_sql_exact_change_after_plan_blocks_publication(setup,change):
    store,root,ops,report,rows,source=setup;conflicting_source(setup)
    with store.engine.begin() as c:store.insert_missing(c,1,rows)
    plan=make_plan(report,root,store,now=NOW,prefer_sql_exact=True)
    with store.engine.begin() as c:
        c.execute(text('DELETE FROM candles WHERE id=1' if change=='delete' else 'UPDATE candles SET close=100 WHERE id=1'))
    result=apply_plan(plan,root,store,ops,writers_stopped=True,now=NOW)
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1}
    assert result['inserted_rows']==0 and not (root/REL).exists()


def test_cli_missing_input_reports_path_before_auth(tmp_path,capsys):
    from controller.cash_recovery_cli import main
    missing=tmp_path/'missing.json'
    with pytest.raises(SystemExit) as exc:
        main(['plan','--preview',str(missing),'--output',str(tmp_path/'out.json')])
    assert exc.value.code==2
    assert str(missing) in capsys.readouterr().err


def test_cli_missing_output_directory_reports_before_auth(tmp_path,capsys):
    from controller.cash_recovery_cli import main
    source=tmp_path/'input.json';source.write_text('{}')
    with pytest.raises(SystemExit) as exc:
        main(['plan','--preview',str(source),'--output',str(tmp_path/'absent'/'out.json')])
    assert exc.value.code==2
    assert 'Output directory not found' in capsys.readouterr().err


def test_one_run_plans_applies_and_records_then_rechecks(setup):
    from model.cash_recovery_run import run_recovery
    store,root,ops,report,rows,source=setup
    result=run_recovery(report,root,store,ops,writers_stopped=True,now=NOW)
    assert result['inserted_rows']==2 and result['restored_files']==1
    from pathlib import Path
    plan=json.loads(Path(result['plan']).read_text())
    assert Path(result['report']).is_file()
    again=run_recovery(report,root,store,ops,writers_stopped=True,scope_plan=plan,now=NOW)
    assert again['plan_summary']['statuses']=={'ALREADY_CONSISTENT':1}
    assert again['inserted_rows']==again['restored_files']==0


def test_one_run_preserves_unresolved_and_reports_no_ready(setup):
    from model.cash_recovery_run import run_recovery
    store,root,ops,report,rows,source=setup;conflicting_source(setup)
    result=run_recovery(report,root,store,ops,writers_stopped=True,now=NOW)
    assert result['status']=='PARTIAL' and result['unresolved_plan_entries']==1
    assert not (root/REL).exists()


def test_one_run_scope_skips_consistent_without_certifying_it(setup,monkeypatch):
    from model.cash_recovery_run import run_recovery
    store,root,ops,report,rows,source=setup
    plan=make_plan(report,root,store,now=NOW)
    plan['entries'][0]['status']='ALREADY_CONSISTENT'
    monkeypatch.setattr(store,'metadata',lambda *a:pytest.fail('Skipped partition was accessed'))
    result=run_recovery(report,root,store,ops,writers_stopped=True,scope_plan=plan,now=NOW)
    assert result['previously_consistent_not_rechecked']==1
    assert result['plan_summary']['partitions']==0


def test_one_run_requires_stopped_writers(setup):
    from model.cash_recovery_run import run_recovery
    store,root,ops,report,rows,source=setup
    with pytest.raises(ValueError,match='writers_stopped'):
        run_recovery(report,root,store,ops,now=NOW)
    assert not ops.exists()


def test_field_audit_separates_metadata_market_keys_and_duplicates(setup):
    from model.cash_conflict_audit import field_comparison
    rows=setup[4];other=copy.deepcopy(rows);other[0]['source']='FYERS_LIVE'
    assert field_comparison(rows,other)['category']=='METADATA_ONLY'
    other[1]['close']=100
    c=field_comparison(rows,other)
    assert c['market_value_rows']==1 and c['metadata_only_rows']==1
    assert c['field_counts']=={'source':1,'close':1}
    assert field_comparison(rows,rows[:1])['sql_only']==1
    with pytest.raises(ValueError,match='duplicate_timestamp'):
        field_comparison(rows,rows+rows[:1])


def test_audit_reads_invalid_quality_sources_without_mutation(setup):
    from model.cash_conflict_audit import audit_conflicts
    store,root,ops,preview,rows,source=setup
    with store.engine.begin() as c:store.insert_missing(c,1,rows)
    altered=copy.deepcopy(rows);altered[0]['high']=50
    pd.DataFrame(altered).to_parquet(source,index=False)
    preview['partitions'][0]['variants'][0]['sha256']=fingerprint(source)[0]
    scope=make_plan(preview,root,store,now=NOW);before=source.read_bytes()
    result=audit_conflicts(preview,scope,root,store,now=NOW)
    assert result['complete'] and result['data_modified'] is False, result
    v=result['entries'][0]['variants'][0]
    assert v['quality']['issues'] and v['comparison']['field_counts']=={'high':1}
    assert source.read_bytes()==before and not list(root.iterdir()) and not ops.exists()
    assert len(store.rows(1,dt.date(2025,1,2)))==2


def test_audit_missing_source_reports_partial_not_success(setup):
    from model.cash_conflict_audit import audit_conflicts
    store,root,ops,preview,rows,source=setup
    scope=make_plan(preview,root,store,now=NOW);scope['entries'][0]['status']='UNRESOLVED'
    source.unlink()
    report=audit_conflicts(preview,scope,root,store,now=NOW)
    assert not report['complete']
    assert report['entries'][0]['variants'][0]['status']=='ERROR'


def test_field_audit_counts_beyond_sample_cap(setup):
    from model.cash_conflict_audit import field_comparison
    rows=setup[4];other=copy.deepcopy(rows)
    for row in other:row['close']=100
    result=field_comparison(rows,other,sample_limit=1)
    assert result['field_counts']['close']==2 and len(result['samples'])==1


def resolution_audit(setup,exact=True):
    source=setup[5]
    return {'operation':'READ_ONLY_CASH_FIELD_AUDIT','complete':True,'entries':[{'relative_path':REL,
        'variants':[{'source':str(source),'sha256':fingerprint(source)[0],
        'comparison':{'category':'EXACT' if exact else 'MARKET_VALUE_DIFFERENCES'}}]}]}


def test_resolution_preserves_exact_session_data_without_market_writes(setup):
    from model.cash_resolution import resolve_candidates
    store,root,ops,preview,rows,source=setup
    with store.engine.begin() as c:store.insert_missing(c,1,rows)
    before=source.read_bytes()
    result=resolve_candidates(resolution_audit(setup),root,store,ops,
        lambda *a:pytest.fail('Exact match must not fetch'),now=NOW)
    assert result['summary']=={'SESSION_PRESERVED_REVIEW':1}
    assert source.read_bytes()==before and not list(root.iterdir())
    assert len(store.rows(1,dt.date(2025,1,2)))==2


def test_resolution_no_data_does_not_write_parquet(setup):
    from model.cash_resolution import resolve_candidates
    store,root,ops,preview,rows,source=setup
    result=resolve_candidates(resolution_audit(setup,False),root,store,ops,lambda *a:[],now=NOW)
    assert result['summary']=={'PROVIDER_NO_DATA':1}
    assert not list(ops.rglob('*.parquet')) and not list(root.iterdir())


def test_resolution_provider_candidate_only_in_workspace(setup):
    from model.cash_resolution import resolve_candidates
    store,root,ops,preview,rows,source=setup
    provider=[dict(r,source='FYERS_HISTORICAL') for r in rows]
    result=resolve_candidates(resolution_audit(setup,False),root,store,ops,lambda *a:provider,now=NOW)
    assert result['summary']=={'PROVIDER_CANDIDATE_STAGED':1}
    assert store.rows(1,dt.date(2025,1,2))==[] and not list(root.iterdir())
    assert len(list(ops.rglob('provider_candidate.parquet')))==1


def test_resolution_bad_ohlc_not_excused_by_session_policy(setup):
    from model.cash_resolution import classify_session
    rows=copy.deepcopy(setup[4]);rows[0]['high']=1
    with pytest.raises(ValueError,match='non_session_quality'):
        classify_session(rows,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW)


def test_session_classification_counts_all_off_session_rows(setup,monkeypatch):
    from model.cash_resolution import classify_session
    import model.cash_inventory_preview as preview
    monkeypatch.setattr(preview,'calendar_verified',lambda day:True)
    rows=copy.deepcopy(setup[4])
    rows[0]['candle_timestamp']=dt.datetime(2025,1,2,8,0,tzinfo=IST)
    result=classify_session(rows,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW)
    assert result['outside_session_rows']==1 and result['regular_rows']==1
    assert result['canonical_certified'] is False


def repair_fixture(setup,target_exists=False):
    from model.cash_repair import plan_repair
    store,root,ops,preview,rows,source=setup
    prior=copy.deepcopy(rows[:1]);prior[0]['close']=100
    extra=dict(rows[1],candle_timestamp=dt.datetime(2025,1,2,9,17,tzinfo=IST));prior.append(extra)
    with store.engine.begin() as c:store.insert_missing(c,1,prior)
    if target_exists:
        target=root/REL;target.parent.mkdir(parents=True);pd.DataFrame(prior).to_parquet(target,index=False)
    provider=[dict(r,source='FYERS_HISTORICAL') for r in rows]
    pd.DataFrame(provider).to_parquet(source,index=False);sha,size=fingerprint(source)
    report={'status':'REVIEW_READY','outcomes':[{'relative_path':REL,'status':'PROVIDER_CANDIDATE_STAGED',
        'candidate':str(source),'sha256':sha,'bytes':size}]}
    plan=plan_repair(report,root,store,now=NOW)
    # Exercise the exact disk round trip used on Windows.
    return json.loads(json.dumps(plan,default=str)),prior


@pytest.mark.parametrize('target_exists',[False,True])
def test_provider_repair_preserves_extras_ids_and_resumes(setup,target_exists):
    from model.cash_repair import apply_repair
    store,root,ops,preview,rows,source=setup;plan,prior=repair_fixture(setup,target_exists)
    assert plan['summary']['inserted']==1 and plan['summary']['updated']==1
    before_source=source.read_bytes()
    result=apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'VERIFIED':1}
    sql=store.rows(1,dt.date(2025,1,2));assert len(sql)==3
    assert next(r for r in sql if r['id']==1)['close']==101
    assert next(r for r in sql if r['id']==2)['source']=='FYERS'
    assert len(pd.read_parquet(root/REL))==3 and source.read_bytes()==before_source
    if target_exists:assert len(list(ops.rglob('target_before.parquet')))==1
    again=apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert again['applied_statuses']=={'ALREADY_APPLIED':1}


def test_provider_repair_rejects_changed_sql(setup):
    from model.cash_repair import apply_repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    with store.engine.begin() as c:c.execute(text('UPDATE candles SET volume=999 WHERE id=1'))
    result=apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1} and not (root/REL).exists()


def test_provider_repair_sql_commit_publish_failure_can_resume(setup,monkeypatch):
    import model.cash_repair as repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    original=repair.os.link
    monkeypatch.setattr(repair.os,'link',lambda *a:(_ for _ in ()).throw(OSError('publish failed')))
    result=repair.apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['outcomes'][0]['sql_may_have_committed'] and len(store.rows(1,dt.date(2025,1,2)))==3
    monkeypatch.setattr(repair.os,'link',original)
    result=repair.apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'VERIFIED':1} and len(store.rows(1,dt.date(2025,1,2)))==3


def test_provider_repair_failed_insert_rolls_back_updates(setup,monkeypatch):
    from model.cash_repair import apply_repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    monkeypatch.setattr(store,'insert_missing',lambda *a:(_ for _ in ()).throw(RuntimeError('failed')))
    result=apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1}
    sql=store.rows(1,dt.date(2025,1,2));assert len(sql)==2 and sql[0]['close']==100
    assert not (root/REL).exists()


def test_provider_repair_requires_explicit_policy(setup):
    from model.cash_repair import apply_repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    with pytest.raises(ValueError,match='accept_provider'):
        apply_repair(plan,root,store,ops,writers_stopped=True,now=NOW)


def test_provider_repair_preserves_changed_target(setup):
    from model.cash_repair import apply_repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup,True)
    altered=copy.deepcopy(rows);altered[0]['volume']=999
    pd.DataFrame(altered).to_parquet(root/REL,index=False);before=(root/REL).read_bytes()
    result=apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1}
    assert (root/REL).read_bytes()==before and store.rows(1,dt.date(2025,1,2))[0]['close']==100


def test_provider_repair_backup_failure_prevents_writes(setup,monkeypatch):
    import model.cash_repair as repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    original=repair.write_json_new
    def fail(path,payload):
        if path.name=='sql_before.json':raise OSError('backup unavailable')
        return original(path,payload)
    monkeypatch.setattr(repair,'write_json_new',fail)
    result=repair.apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    assert result['applied_statuses']=={'REVIEW_REQUIRED':1}
    assert not (root/REL).exists() and store.rows(1,dt.date(2025,1,2))[0]['close']==100


def test_parquet_stage_fsync_uses_writable_exclusive_handle(setup,monkeypatch,tmp_path):
    import builtins
    import model.cash_repair as repair
    modes={};synced=[];original=repair.os.fsync
    def tracked_open(path,mode,*args,**kwargs):
        stream=builtins.open(path,mode,*args,**kwargs);modes[stream.fileno()]=mode;return stream
    def windows_like_sync(fd):
        assert modes[fd]=='xb','Windows staging fsync must use writable exclusive handle'
        synced.append(fd);return original(fd)
    monkeypatch.setattr(repair,'open',tracked_open,raising=False)
    monkeypatch.setattr(repair.os,'fsync',windows_like_sync)
    path=tmp_path/'candidate.tmp';repair.write_parquet_new(path,setup[4])
    assert synced and len(pd.read_parquet(path))==2
    before=path.read_bytes()
    with pytest.raises(FileExistsError):repair.write_parquet_new(path,setup[4])
    assert path.read_bytes()==before


def test_repair_staging_oserror_has_actionable_details_and_no_sql_write(setup,monkeypatch):
    import model.cash_repair as repair
    store,root,ops,preview,rows,source=setup;plan,_=repair_fixture(setup)
    def fail(*args):
        exc=OSError(13,'Permission denied','staging.tmp');exc.winerror=5;raise exc
    monkeypatch.setattr(repair,'write_parquet_new',fail)
    result=repair.apply_repair(plan,root,store,ops,writers_stopped=True,accept_provider=True,now=NOW)
    outcome=result['outcomes'][0]
    assert outcome['stage']=='stage_parquet' and outcome['os_error']['winerror']==5
    assert outcome['sql_may_have_committed'] is False
    assert store.rows(1,dt.date(2025,1,2))[0]['close']==100
    assert not (root/REL).exists()


def session_restore_fixture(setup,monkeypatch):
    import model.cash_inventory_preview as q
    monkeypatch.setattr(q,'calendar_verified',lambda d:True)
    store,root,ops,preview,rows,source=setup
    data=copy.deepcopy(rows);data[0]['candle_timestamp']=dt.datetime(2025,1,2,8,0,tzinfo=IST)
    pd.DataFrame(data).to_parquet(source,index=False)
    with store.engine.begin() as c:store.insert_missing(c,1,data)
    return {'status':'REVIEW_READY','outcomes':[{'relative_path':REL,'status':'SESSION_PRESERVED_REVIEW','candidate':str(source)}]}


def test_session_restore_retains_offsession_without_certification(setup,monkeypatch):
    from model.cash_session_restore import restore_sessions
    from model.cash_inventory_preview import check_rows
    store,root,ops,preview,rows,source=setup;r=session_restore_fixture(setup,monkeypatch)
    before=store.rows(1,dt.date(2025,1,2))
    out=restore_sessions(r,root,store,ops,writers_stopped=True,now=NOW)
    assert out['restored_files']==1 and out['inserted_rows']==0 and out['canonical_certified'] is False
    assert store.rows(1,dt.date(2025,1,2))==before
    loaded=pd.read_parquet(root/REL).to_dict('records')
    assert check_rows(loaded,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW)['issues']==['integrity_findings']
    out=restore_sessions(r,root,store,ops,writers_stopped=True,now=NOW)
    assert out['restored_files']==0 and out['plan_statuses']=={'ALREADY_CONSISTENT':1}


def test_session_restore_blocks_source_sql_difference(setup,monkeypatch):
    from model.cash_session_restore import restore_sessions
    store,root,ops,preview,rows,source=setup;r=session_restore_fixture(setup,monkeypatch)
    with store.engine.begin() as c:c.execute(text('DELETE FROM candles WHERE id=1'))
    out=restore_sessions(r,root,store,ops,writers_stopped=True,now=NOW)
    assert out['plan_statuses']=={'UNRESOLVED':1} and not (root/REL).exists()


def test_session_restore_rejects_bad_price_even_sql_exact(setup,monkeypatch):
    from model.cash_session_restore import restore_sessions
    store,root,ops,preview,rows,source=setup;r=session_restore_fixture(setup,monkeypatch)
    data=pd.read_parquet(source);data.loc[0,'high']=1;data.to_parquet(source,index=False)
    with store.engine.begin() as c:c.execute(text('UPDATE candles SET high=1 WHERE id=1'))
    out=restore_sessions(r,root,store,ops,writers_stopped=True,now=NOW)
    assert out['plan_statuses']=={'UNRESOLVED':1} and not (root/REL).exists()


def gap_fixture(setup, monkeypatch):
    import model.cash_inventory_preview as q
    monkeypatch.setattr(q, 'calendar_verified', lambda d: True)
    store, root, ops, preview, rows, source = setup
    extra = dict(rows[0], candle_timestamp=dt.datetime(2025, 1, 2, 15, 59, tzinfo=IST))
    with store.engine.begin() as c: store.insert_missing(c, 1, [extra])
    (root/REL).parent.mkdir(parents=True)
    pd.DataFrame([extra]).to_parquet(root/REL, index=False)
    report = {'status': 'COMPLETE', 'canonical_certified': False,
              'outcomes': [{'relative_path': REL, 'status': 'VERIFIED'}],
              'session_entries': [{'relative_path': REL, 'session_classification': {
                  'regular_rows': 0, 'quality': {'coverage': {'expected': 375, 'missing': 375}}}}]}
    provider = [dict(rows[0], source='FYERS_HISTORICAL', candle_timestamp=
                    dt.datetime(2025, 1, 2, 9, 15, tzinfo=IST)+dt.timedelta(minutes=i)) for i in range(375)]
    return report, provider, extra


def test_gap_stage_apply_preserves_extra_and_is_resumable(setup, monkeypatch):
    from model.cash_gap_recovery import stage_gaps
    from model.cash_repair import apply_repair
    store, root, ops, _, _, _ = setup
    report, provider, extra = gap_fixture(setup, monkeypatch)
    before = (root/REL).read_bytes()
    result = stage_gaps(report, root, store, ops, lambda m, d: provider, now=NOW)
    assert result['summary'] == {'statuses': {'READY': 1}, 'inserted': 375, 'updated': 0, 'preserved_sql_only': 1}
    assert (root/REL).read_bytes() == before and len(store.rows(1, dt.date(2025, 1, 2))) == 1
    plan = json.loads(open(result['plan']).read())
    out = apply_repair(plan, root, store, ops/'apply', writers_stopped=True, accept_provider=True, now=NOW)
    assert out['applied_statuses'] == {'VERIFIED': 1}
    actual = pd.read_parquet(root/REL)
    assert len(actual) == 376 and actual.iloc[-1]['source'] == extra['source']
    out = apply_repair(plan, root, store, ops/'apply', writers_stopped=True, accept_provider=True, now=NOW)
    assert out['applied_statuses'] == {'ALREADY_APPLIED': 1}


@pytest.mark.parametrize('kind', ['empty', 'partial', 'duplicate', 'bad_price'])
def test_gap_rejects_invalid_provider_without_market_writes(setup, monkeypatch, kind):
    from model.cash_gap_recovery import stage_gaps
    store, root, ops, _, _, _ = setup
    report, provider, extra = gap_fixture(setup, monkeypatch)
    if kind == 'empty': provider = []
    elif kind == 'partial': provider = provider[:-1]
    elif kind == 'duplicate': provider[-1] = provider[0]
    else: provider[0]['high'] = 1
    before = (root/REL).read_bytes()
    result = stage_gaps(report, root, store, ops, lambda m, d: provider, now=NOW)
    assert result['candidate_summary'] == {'REVIEW_REQUIRED': 1}
    assert result['summary']['statuses'] == {'DEFERRED': 1}
    assert (root/REL).read_bytes() == before and len(store.rows(1, dt.date(2025, 1, 2))) == 1
    assert not list(ops.rglob('candidate-*.parquet'))


def test_gap_skips_full_sessions_and_calendar_review(setup, monkeypatch):
    from model.cash_gap_recovery import stage_gaps
    store, root, ops, _, _, _ = setup
    report, provider, extra = gap_fixture(setup, monkeypatch)
    entry = report['session_entries'][0]
    entry['session_classification']['regular_rows'] = 375
    def no_fetch(*args): raise AssertionError('must not fetch')
    assert stage_gaps(report, root, store, ops, no_fetch, now=NOW)['selected_partitions'] == 0
    entry['session_classification']['regular_rows'] = 0
    entry['session_classification']['quality']['coverage']['expected'] = 0
    assert stage_gaps(report, root, store, ops, no_fetch, now=NOW)['selected_partitions'] == 0


def rebuild_fixture(setup, monkeypatch):
    import model.cash_rebuild as rebuild
    monkeypatch.setattr(rebuild, 'calendar_verified', lambda d: True)
    report, provider, extra = gap_fixture(setup, monkeypatch)
    store, root, ops, _, _, _ = setup
    with store.engine.begin() as c: store.insert_missing(c, 1, provider)
    pd.DataFrame(provider+[extra]).to_parquet(root/REL, index=False)
    return report, provider, extra


def test_derived_preview_session_filter_and_no_market_writes(setup, monkeypatch):
    from model.cash_rebuild import plan_rebuild
    store, root, ops, _, _, _ = setup
    report, provider, extra = rebuild_fixture(setup, monkeypatch)
    before = (root/REL).read_bytes()
    result = plan_rebuild([report, report], root, store, ops, now=NOW)
    plan = json.loads(open(result['plan']).read())
    assert result['summary']['source_partitions'] == 1
    assert result['summary']['statuses'] == {'NEEDS_REBUILD': 6}
    assert {e['timeframe']: e['expected_rows'] for e in plan['entries']} == {'3m':125,'5m':75,'15m':25,'30m':13,'1h':7,'1d':1}
    assert plan['sources'][0]['preserved_outside_rows'] == 1
    daily = next(e for e in plan['entries'] if e['timeframe']=='1d')['expected'][0]
    assert daily['volume'] == 3750 and daily['candle_timestamp'].endswith('09:15:00+05:30')
    assert (root/REL).read_bytes() == before and not (root/'processed').exists()
    with store.engine.connect() as c: assert c.execute(text('SELECT COUNT(*) FROM candles')).scalar() == 376


def test_derived_preview_rejects_raw_mismatch(setup, monkeypatch):
    from model.cash_rebuild import plan_rebuild
    store, root, ops, _, _, _ = setup
    report, provider, extra = rebuild_fixture(setup, monkeypatch)
    with store.engine.begin() as c: c.execute(text('UPDATE candles SET volume=999 WHERE id=1'))
    result = plan_rebuild([report], root, store, ops, now=NOW)
    assert result['summary']['source_review_reasons'] == {'raw_SQL_Parquet_mismatch':1}
    assert result['summary']['derived_partitions'] == 0


def test_derived_preview_rejects_incomplete_session(setup, monkeypatch):
    from model.cash_rebuild import plan_rebuild
    store, root, ops, _, _, _ = setup
    report, provider, extra = gap_fixture(setup, monkeypatch)
    import model.cash_rebuild as rebuild
    monkeypatch.setattr(rebuild,'calendar_verified',lambda d:True)
    with store.engine.begin() as c: store.insert_missing(c,1,provider[:-1])
    pd.DataFrame(provider[:-1]+[extra]).to_parquet(root/REL,index=False)
    result=plan_rebuild([report],root,store,ops,now=NOW)
    assert result['summary']['source_statuses']=={'REVIEW_REQUIRED':1}
    assert result['summary']['derived_partitions']==0


def test_derived_preview_reports_existing_conflict_without_overwrite(setup,monkeypatch):
    from model.cash_rebuild import plan_rebuild
    store, root, ops, _, _, _=setup
    report,provider,extra=rebuild_fixture(setup,monkeypatch)
    target=root/REL.replace('raw/1m','processed/5m');target.parent.mkdir(parents=True)
    pd.DataFrame([dict(provider[0],timeframe='5m',volume=999)]).to_parquet(target,index=False)
    before=target.read_bytes()
    result=plan_rebuild([report],root,store,ops,now=NOW)
    plan=json.loads(open(result['plan']).read());e=next(e for e in plan['entries'] if e['timeframe']=='5m')
    assert e['parquet_changes']=={'missing':74,'extra':0,'changed':1}
    assert target.read_bytes()==before


def test_derived_preview_calendar_review_no_candidates(setup,monkeypatch):
    import model.cash_rebuild as rebuild
    store,root,ops,_,_,_=setup
    report,_,_=rebuild_fixture(setup,monkeypatch)
    monkeypatch.setattr(rebuild,'session_window',lambda d:None)
    result=rebuild.plan_rebuild([report],root,store,ops,now=NOW)
    assert result['summary']['source_review_reasons']=={'calendar_review_required':1}
    assert not list(ops.rglob('candidate-*.parquet'))


def derived_apply_fixture(setup,monkeypatch):
    import model.cash_rebuild_apply as apply
    monkeypatch.setattr(apply, "calendar_verified", lambda d: True)
    from model.cash_rebuild import plan_rebuild
    store,root,ops,_,_,_=setup
    report,provider,extra=rebuild_fixture(setup,monkeypatch)
    old=[dict(provider[0],timeframe='5m',volume=999),
         dict(provider[0],timeframe='5m',candle_timestamp=dt.datetime(2025,1,2,9,0,tzinfo=IST))]
    with store.engine.begin() as c:
        for r in old:
            values={k:r[k] for k in ('open','high','low','close','volume','source','status')}
            values['ts']=r['candle_timestamp'].replace(tzinfo=None)
            c.execute(text("INSERT INTO candles (instrument_id,timeframe,candle_timestamp,open,high,low,close,volume,source,status) VALUES (1,'5m',:ts,:open,:high,:low,:close,:volume,:source,:status)"),values)
    target=root/REL.replace('raw/1m','processed/5m');target.parent.mkdir(parents=True)
    pd.DataFrame(old).to_parquet(target,index=False)
    result=plan_rebuild([report],root,store,ops/'preview',now=NOW)
    plan=json.loads(open(result['plan']).read())
    return plan,target


def test_derived_apply_archives_replaces_and_resume_no_changes(setup,monkeypatch):
    from model.cash_rebuild_apply import apply_rebuild
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    raw=(root/REL).read_bytes();old=target.read_bytes();before=derived_sql(store,1,dt.date(2025,1,2),'5m')
    out=apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['status']=='SCOPED_DERIVED_REBUILD_VERIFIED' and out['applied_statuses']=={'VERIFIED':6}
    assert out['totals']=={'inserted':245,'updated':1,'archived_removed':1}
    assert (root/REL).read_bytes()==raw
    rows=derived_sql(store,1,dt.date(2025,1,2),'5m')
    assert len(rows)==75 and rows[0]['id']==next(r['id'] for r in before if str(r['candle_timestamp']).startswith('2025-01-02 09:15'))
    backups=list((ops/'apply').rglob('target_before.parquet'));assert len(backups)==1 and backups[0].read_bytes()==old
    archive=json.loads(backups[0].with_name('sql_before.json').read_text())
    assert len(archive['rows'])==2 and {r['id'] for r in archive['rows']}=={r['id'] for r in before}
    again=apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert again['applied_statuses']=={'ALREADY_APPLIED':6} and again['totals']=={'inserted':0,'updated':0,'archived_removed':0}


@pytest.mark.parametrize('kind',['raw','derived_sql','derived_file','candidate','expected'])
def test_derived_apply_blocks_changes_since_preview(setup,monkeypatch,kind):
    from model.cash_rebuild_apply import apply_rebuild
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='5m']
    if kind=='raw':
        with store.engine.begin() as c:c.execute(text("UPDATE candles SET volume=999 WHERE timeframe='1m' AND id=1"))
    elif kind=='derived_sql':
        with store.engine.begin() as c:c.execute(text("UPDATE candles SET volume=888 WHERE timeframe='5m'"))
    elif kind=='derived_file':
        df=pd.read_parquet(target);df.loc[0,'volume']=888;df.to_parquet(target,index=False)
    elif kind=='candidate':
        path=plan['entries'][0]['candidate'];df=pd.read_parquet(path);df.loc[0,'volume']=888;df.to_parquet(path,index=False)
    else:plan['entries'][0]['expected'][0]['volume']=888
    sql_before=derived_sql(store,1,dt.date(2025,1,2),'5m');pq_before=target.read_bytes()
    out=apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['applied_statuses']=={'REVIEW_REQUIRED':1}
    assert derived_sql(store,1,dt.date(2025,1,2),'5m')==sql_before and target.read_bytes()==pq_before


def test_derived_apply_backup_failure_prevents_writes(setup,monkeypatch):
    import model.cash_rebuild_apply as a
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='5m']
    before=derived_sql(store,1,dt.date(2025,1,2),'5m');data=target.read_bytes()
    def fail(*args):raise OSError('backup disk unavailable')
    monkeypatch.setattr(a,'backup_partition',fail)
    out=a.apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['outcomes'][0]['stage']=='backup'
    assert derived_sql(store,1,dt.date(2025,1,2),'5m')==before and target.read_bytes()==data


def test_derived_apply_resume_after_commit_publish_failure(setup,monkeypatch):
    import model.cash_rebuild_apply as a
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='5m']
    data=target.read_bytes();replace=a.os.replace
    def fail(*args):raise OSError('publish temporarily unavailable')
    monkeypatch.setattr(a.os,'replace',fail)
    out=a.apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['outcomes'][0]['sql_may_have_committed'] is True
    assert len(derived_sql(store,1,dt.date(2025,1,2),'5m'))==75 and target.read_bytes()==data
    monkeypatch.setattr(a.os,'replace',replace)
    out=a.apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['applied_statuses']=={'VERIFIED':1} and out['totals']=={'inserted':0,'updated':0,'archived_removed':0}
    assert len(pd.read_parquet(target))==75


def test_derived_apply_flags_and_path_scope(setup,monkeypatch):
    from model.cash_rebuild_apply import apply_rebuild
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    with pytest.raises(ValueError,match='accept_derived'):
        apply_rebuild(plan,root,store,ops/'apply',now=NOW)
    plan['entries'][0]['relative_path']=REL
    with pytest.raises(ValueError,match='invalid_or_duplicate_target'):
        apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)


def test_derived_apply_transaction_failure_rolls_back(setup,monkeypatch):
    import model.cash_rebuild_apply as a
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='5m']
    before=derived_sql(store,1,dt.date(2025,1,2),'5m');data=target.read_bytes();original=a.change_sql
    def fail(*args):
        original(*args)
        raise ValueError('injected_failure_after_SQL_mutations')
    monkeypatch.setattr(a,'change_sql',fail)
    out=a.apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['outcomes'][0]['stage']=='sql_transaction' and out['outcomes'][0]['sql_may_have_committed'] is False
    assert derived_sql(store,1,dt.date(2025,1,2),'5m')==before and target.read_bytes()==data


def test_derived_apply_hardlink_failure_precedes_commit(setup,monkeypatch):
    import model.cash_rebuild_apply as a
    from model.cash_rebuild import derived_sql
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='15m']
    def fail(*args):raise OSError('hardlink unavailable')
    monkeypatch.setattr(a.os,'link',fail)
    out=a.apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['outcomes'][0]['stage']=='stage_parquet' and out['outcomes'][0]['sql_may_have_committed'] is False
    assert derived_sql(store,1,dt.date(2025,1,2),'15m')==[]


def test_derived_apply_keeps_other_dates_timeframes_instruments(setup,monkeypatch):
    from model.cash_rebuild_apply import apply_rebuild
    store,root,ops,_,_,_=setup
    plan,target=derived_apply_fixture(setup,monkeypatch)
    plan['entries']=[e for e in plan['entries'] if e['timeframe']=='5m']
    with store.engine.begin() as c:
        for iid,tf,ts in [(2,'5m','2025-01-02 09:00:00'),(1,'5m','2025-01-03 09:00:00'),(1,'15m','2025-01-02 09:00:00')]:
            c.execute(text('INSERT INTO candles(instrument_id,timeframe,candle_timestamp,open,high,low,close,volume,source,status) VALUES(:i,:tf,:ts,100,102,99,101,10,\'FYERS\',\'CLOSED\')'),{'i':iid,'tf':tf,'ts':ts})
        before=[dict(r) for r in c.execute(text("SELECT * FROM candles WHERE NOT(instrument_id=1 AND timeframe='5m' AND candle_timestamp>='2025-01-02' AND candle_timestamp<'2025-01-03') ORDER BY id")).mappings()]
    out=apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['applied_statuses']=={'VERIFIED':1}
    with store.engine.connect() as c:
        after=[dict(r) for r in c.execute(text("SELECT * FROM candles WHERE NOT(instrument_id=1 AND timeframe='5m' AND candle_timestamp>='2025-01-02' AND candle_timestamp<'2025-01-03') ORDER BY id")).mappings()]
    assert before==after


def final_check_fixture(setup,monkeypatch):
    from model.cash_rebuild_apply import apply_rebuild
    store,root,ops,preview,_,_=setup
    plan,_=derived_apply_fixture(setup,monkeypatch)
    out=apply_rebuild(plan,root,store,ops/'apply',writers_stopped=True,accept_replacement=True,now=NOW)
    assert out['applied_statuses']=={'VERIFIED':6}
    return preview,plan


def test_final_check_parity_separate_from_session_quality_no_market_writes(setup,monkeypatch):
    from model.cash_final_check import final_check
    store,root,ops,_,_,_=setup
    preview,plan=final_check_fixture(setup,monkeypatch)
    before={str(p):p.read_bytes() for p in root.rglob('*.parquet')}
    with store.engine.connect() as c:sql_before=[dict(r) for r in c.execute(text('SELECT * FROM candles ORDER BY id')).mappings()]
    result=final_check(preview,[plan,plan],root,store,ops/'final',now=NOW)
    assert result['status']=='SCOPED_STORAGE_PASS'
    assert result['summary']['raw_partitions']==1 and result['summary']['derived_partitions']==6
    assert result['summary']['derived_rows']==246 and result['summary']['raw_quality_review_partitions']==1
    assert result['canonical_quality_certified'] is False and result['market_data_modified'] is False
    assert before=={str(p):p.read_bytes() for p in root.rglob('*.parquet')}
    with store.engine.connect() as c:assert sql_before==[dict(r) for r in c.execute(text('SELECT * FROM candles ORDER BY id')).mappings()]
    assert not list((ops/'final').rglob('*.parquet'))


def test_final_check_detects_raw_mismatch(setup,monkeypatch):
    from model.cash_final_check import final_check
    store,root,ops,_,_,_=setup
    preview,plan=final_check_fixture(setup,monkeypatch)
    with store.engine.begin() as c:c.execute(text("UPDATE candles SET volume=99 WHERE timeframe='1m' AND id=1"))
    result=final_check(preview,[plan],root,store,ops/'final',now=NOW)
    assert result['status']=='FINDINGS' and result['raw_results'][0]['reason']=='raw_SQL_Parquet_mismatch'
    assert result['summary']['derived_statuses']=={'FINDINGS':6}


def test_final_check_detects_derived_change(setup,monkeypatch):
    from model.cash_final_check import final_check
    store,root,ops,_,_,_=setup
    preview,plan=final_check_fixture(setup,monkeypatch)
    with store.engine.begin() as c:c.execute(text("UPDATE candles SET volume=99 WHERE timeframe='1d'"))
    result=final_check(preview,[plan],root,store,ops/'final',now=NOW)
    assert result['status']=='FINDINGS' and result['summary']['derived_statuses']=={'VERIFIED':5,'FINDINGS':1}


def test_offsession_preservation_does_not_hide_bad_ohlc(setup,monkeypatch):
    from model.cash_inventory_preview import check_rows
    store,root,ops,_,rows,_=setup
    bad=copy.deepcopy(rows);bad[0]['candle_timestamp']=dt.datetime(2025,1,2,8,0,tzinfo=IST);bad[0]['high']=1
    q=check_rows(bad,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW,allow_outside_session=True)
    assert 'integrity_findings' in q['issues']
    good=copy.deepcopy(rows);good[0]['candle_timestamp']=dt.datetime(2025,1,2,8,0,tzinfo=IST)
    monkeypatch.setattr('model.cash_inventory_preview.calendar_verified',lambda d:True)
    assert 'integrity_findings' in check_rows(good,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW)['issues']
    assert not check_rows(good,'NSE:SBIN-EQ',dt.date(2025,1,2),NOW,allow_outside_session=True)['issues']


def coverage_fixture(setup,monkeypatch):
    report,provider,extra=gap_fixture(setup,monkeypatch)
    store,root,ops,_,_,_=setup
    partial=[dict(r,source='FYERS_LIVE') for r in provider[:29]]
    partial[0]['close']=100
    with store.engine.begin() as c:
        c.execute(text('DELETE FROM candles'))
        store.insert_missing(c,1,partial)
    pd.DataFrame(partial).to_parquet(root/REL,index=False)
    check={'status':'SCOPED_STORAGE_PASS','complete':True,'raw_results':[{
        'relative_path':REL,'status':'PARITY_VERIFIED','calendar_verified':True,
        'quality_issues':[],'quality_review_reasons':['incomplete_minute_coverage'],'rows':29}]}
    return check,provider


def test_coverage_gap_fills_and_corrects_matching_keys_with_backup(setup,monkeypatch):
    from model.cash_gap_recovery import stage_gaps
    from model.cash_repair import apply_repair
    store,root,ops,_,_,_=setup;check,provider=coverage_fixture(setup,monkeypatch)
    before=(root/REL).read_bytes()
    out=stage_gaps(check,root,store,ops/'stage',lambda m,d:provider,now=NOW,from_check=True,day_filter=dt.date(2025,1,2))
    assert out['summary']=={'statuses':{'READY':1},'inserted':346,'updated':29,'preserved_sql_only':0}
    assert (root/REL).read_bytes()==before
    plan=json.loads(open(out['plan']).read())
    done=apply_repair(plan,root,store,ops/'apply',writers_stopped=True,accept_provider=True,now=NOW)
    assert done['applied_statuses']=={'VERIFIED':1} and len(pd.read_parquet(root/REL))==375
    assert next((ops/'apply').rglob('target_before.parquet')).read_bytes()==before


@pytest.mark.parametrize('kind',['empty','partial','duplicate','bad_price'])
def test_coverage_rejects_bad_provider_without_writes(setup,monkeypatch,kind):
    from model.cash_gap_recovery import stage_gaps
    store,root,ops,_,_,_=setup;check,provider=coverage_fixture(setup,monkeypatch)
    if kind=='empty':provider=[]
    elif kind=='partial':provider=provider[:-1]
    elif kind=='duplicate':provider[-1]=provider[0]
    else:provider[0]['high']=1
    before=(root/REL).read_bytes()
    out=stage_gaps(check,root,store,ops,lambda m,d:provider,now=NOW,from_check=True,day_filter=dt.date(2025,1,2))
    assert out['candidate_summary']=={'REVIEW_REQUIRED':1} and (root/REL).read_bytes()==before
    assert len(store.rows(1,dt.date(2025,1,2)))==29


def test_coverage_scope_requires_date_and_excludes_calendar_review(setup,monkeypatch):
    from model.cash_gap_recovery import stage_gaps
    store,root,ops,_,_,_=setup;check,provider=coverage_fixture(setup,monkeypatch)
    def no_fetch(*args):raise AssertionError('must not fetch')
    with pytest.raises(ValueError,match='explicit_coverage_date'):
        stage_gaps(check,root,store,ops,no_fetch,now=NOW,from_check=True)
    out=stage_gaps(check,root,store,ops,no_fetch,now=NOW,from_check=True,day_filter=dt.date(2025,1,3))
    assert out['selected_partitions']==0
    check['raw_results'][0]['calendar_verified']=False
    check['raw_results'][0]['quality_review_reasons'].append('calendar_not_verified')
    out=stage_gaps(check,root,store,ops,no_fetch,now=NOW,from_check=True,day_filter=dt.date(2025,1,2))
    assert out['selected_partitions']==0


def test_coverage_cli_repairs_then_rebuilds_only_selected_scope(setup,monkeypatch,capsys):
    from controller.cash_gap_cli import main
    import model.cash_rebuild as rebuild
    import model.cash_rebuild_apply as apply
    store,root,ops,_,_,_=setup;check,provider=coverage_fixture(setup,monkeypatch)
    monkeypatch.setattr(rebuild,'calendar_verified',lambda d:True)
    monkeypatch.setattr(apply,'calendar_verified',lambda d:True)
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('controller.cash_resolution_cli.historical_fetcher',lambda:lambda m,d:provider)
    class Catalog:
        roots={'CASH':root}
        _engines={}
        def engine(self,segment):return store.engine
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:Catalog())
    monkeypatch.setattr('model.config.runtime_paths.state_path',lambda key:ops/key)
    path=root.parent/'check.json';path.write_text(json.dumps(check))
    assert main(['--check-report',str(path),'--date','2025-01-02','--apply','--writers-stopped',
                 '--accept-provider','--rebuild','--accept-derived-replacement'])==0
    output=capsys.readouterr().out
    assert 'BASE_REPAIR_VERIFIED' in output and 'SCOPED_DERIVED_REBUILD_VERIFIED' in output
    assert len(list((root/'processed').rglob('*.parquet')))==6
    assert len(pd.read_parquet(root/REL))==375


def test_windows_extended_recovery_path_spelling_preserves_identity():
    from model.storage.windows_paths import extended_windows_path
    original = 'C:\\Users\\test\\' + 'a' * 120 + '\\' + 'b' * 64 + '\\attempt-' + 'c' * 32 + '\\target_before.parquet'
    assert len(original) > 260
    actual = extended_windows_path(original)
    assert actual == '\\\\?\\' + original
    assert extended_windows_path(actual) == actual
    assert extended_windows_path('\\\\server\\share\\recovery\\events.jsonl') == '\\\\?\\UNC\\server\\share\\recovery\\events.jsonl'
    with pytest.raises(ValueError): extended_windows_path('relative\\backup.json')
    with pytest.raises(ValueError): extended_windows_path('C:backup.json')


def test_coverage_cli_reports_failure_stage_and_os_error(setup,monkeypatch,capsys):
    from controller.cash_gap_cli import main
    store,root,ops,_,_,_=setup;check,provider=coverage_fixture(setup,monkeypatch)
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('controller.cash_resolution_cli.historical_fetcher',lambda:lambda m,d:provider)
    class Catalog:
        roots={'CASH':root}
        _engines={}
        def engine(self,segment):return store.engine
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:Catalog())
    monkeypatch.setattr('model.config.runtime_paths.state_path',lambda key:ops/key)
    def locked(*args):raise PermissionError(13,'Simulated sharing violation','target_before.parquet')
    monkeypatch.setattr('model.cash_repair.write_parquet_new',locked)
    path=root.parent/'check.json';path.write_text(json.dumps(check))
    assert main(['--check-report',str(path),'--date','2025-01-02','--apply','--writers-stopped','--accept-provider'])==2
    output=capsys.readouterr().out
    report=json.loads(output.splitlines()[-1])
    failure=report['failures'][0]
    assert failure['stage']=='stage_parquet' and failure['sql_may_have_committed'] is False
    assert failure['os_error']['errno']==13
    assert len(store.rows(1,dt.date(2025,1,2)))==29
