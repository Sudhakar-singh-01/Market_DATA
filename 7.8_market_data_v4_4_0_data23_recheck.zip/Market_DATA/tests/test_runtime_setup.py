from pathlib import Path
import pytest
import yaml

from controller import runtime_cli


@pytest.fixture
def sources(tmp_path):
    project = tmp_path / 'project'
    (project / 'config').mkdir(parents=True)
    (project / 'instruments').mkdir()
    for name in ('data_settings.yaml', 'timeframe_settings.yaml', 'holidays.yaml'):
        (project / 'config' / name).write_text('existing: value\n')
    (project / 'config/fno_settings.yaml').write_text('parquet:\n  root: old\nuniverse:\n  keep: true\n')
    (project / 'config/.env').write_text('PASSWORD=mock-secret\nCASH_DATA_ROOT=old\n')
    for name in ('stocks.yaml', 'indices.yaml'):
        (project / 'instruments' / name).write_text('[]\n')
    (project / 'runtime').mkdir()
    (project / 'runtime/quota.json').write_text('{"used":3}')
    cash = tmp_path / 'cash'
    fno = cash / 'fno'
    fno.mkdir(parents=True)
    (cash / 'candle.bin').write_bytes(b'cash')
    (fno / 'candle.bin').write_bytes(b'fno')
    return project, cash, fno, tmp_path / 'profile'


def run(sources, **kwargs):
    project, cash, fno, home = sources
    return runtime_cli.initialize_profile(home, cash, fno, project_root=project,
                                          authenticate=lambda: None, **kwargs)


def snapshot(root):
    return {p.relative_to(root): p.read_bytes() for p in root.rglob('*') if p.is_file()}


def test_preview_no_mutation(sources):
    before = snapshot(sources[0].parent)
    assert run(sources)['status'] == 'PREVIEW_ONLY'
    assert snapshot(sources[0].parent) == before
    assert not sources[-1].exists()


def test_copy_preserves_credentials_state_sources_and_excludes_nested_peer(sources):
    project, cash, fno, home = sources
    before = snapshot(project.parent)
    result = run(sources, apply=True, writers_stopped=True)
    assert result['checksums_verified'] == result['files']
    assert (home / 'data/cash/candle.bin').read_bytes() == b'cash'
    assert not (home / 'data/cash/fno').exists()
    assert (home / 'data/fno/candle.bin').read_bytes() == b'fno'
    assert (home / 'runtime/quota.json').read_bytes() == b'{"used":3}'
    env = (home / 'config/.env').read_text()
    assert 'PASSWORD=mock-secret' in env
    assert (home / 'data/cash').as_posix() in env
    settings = yaml.safe_load((home / 'config/fno_settings.yaml').read_text())
    assert settings['universe']['keep'] is True
    assert settings['parquet']['root'] == (home / 'data/fno').as_posix()
    after = snapshot(project.parent)
    assert {p: after[p] for p in before} == before


def test_existing_target_rejected(sources):
    sources[-1].mkdir()
    with pytest.raises(ValueError, match='already exists'):
        run(sources, apply=True, writers_stopped=True)


def test_apply_requires_stopped_writers(sources):
    with pytest.raises(ValueError, match='writers-stopped'):
        run(sources, apply=True)
    assert not sources[-1].exists()


def test_failed_copy_cleans_only_own_staging(sources, monkeypatch):
    before = snapshot(sources[0].parent)
    def fail(*args):
        raise OSError('mock copy failure')
    monkeypatch.setattr(runtime_cli.shutil, 'copy2', fail)
    with pytest.raises(OSError):
        run(sources, apply=True, writers_stopped=True)
    assert snapshot(sources[0].parent) == before
    assert not list(sources[-1].parent.glob('.profile*'))


def test_source_change_detected(sources, monkeypatch):
    original = runtime_cli.shutil.copy2
    def changing(source, destination):
        original(source, destination)
        if source.name == 'candle.bin':
            source.write_bytes(b'changed')
    monkeypatch.setattr(runtime_cli.shutil, 'copy2', changing)
    with pytest.raises(RuntimeError, match='Source changed'):
        run(sources, apply=True, writers_stopped=True)
    assert not sources[-1].exists()
    assert not list(sources[-1].parent.glob('.profile*'))


def test_missing_source_fails(sources):
    sources[2].rename(sources[2].with_name('moved'))
    with pytest.raises(ValueError, match='existing data'):
        run(sources)


def test_symlinks_rejected(sources, make_symlink):
    make_symlink(sources[1] / 'linked', sources[2], target_is_directory=True)
    with pytest.raises(ValueError, match='Symlinks'):
        run(sources)
