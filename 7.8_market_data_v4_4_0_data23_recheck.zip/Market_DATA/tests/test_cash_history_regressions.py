"""CASH history and repair boundaries, without a broker or database connection."""
import datetime as dt
from types import SimpleNamespace as NS
from unittest.mock import Mock

import pytest

from controller import gapfill_controller as gaps
from controller import historical_controller as history
from controller.sinks import CompositeCandleSink, CrossStoreWriteError
from model.config import market_calendar as calendar
from model.config.data_settings import RetrySettings
from model.config.instrument_loader import Instrument, InstrumentRegistry
from model.exceptions import HistoricalProviderError
from model.fyers import historical
from model.processing.gap_detector import find_gaps_1m

INSTRUMENT = Instrument('TEST', 'NSE:TEST-EQ', 'NSE', 'EQ', True, 'stock')
REGISTRY = InstrumentRegistry([INSTRUMENT])
DAY = dt.date(2026, 10, 19)
RETRY = RetrySettings(0, 0, 1)


@pytest.mark.parametrize('index', range(6))
def test_historical_boolean_fields_are_rejected(index):
    from model.processing.normalizer import normalize_historical_candle, NormalizationError
    row = raw(at()); row[index] = True
    with pytest.raises(NormalizationError):
        normalize_historical_candle(row, INSTRUMENT)


def at(day=DAY, hour=9, minute=15, second=0):
    return dt.datetime.combine(day, dt.time(hour, minute, second), calendar.IST)


def raw(ts):
    return [int(ts.timestamp()), 100, 102, 99, 101, 10]


@pytest.fixture
def split_calendar(tmp_path):
    path = tmp_path / 'holidays.yaml'
    path.write_text('''verified_years: {CASH: [2026]}
holidays: []
special_sessions:
  "2026-10-18": {verified: true, open: "18:00", close: "19:00"}
  "2026-10-19":
    verified: true
    intervals:
      - {open: "09:15", close: "10:00"}
      - {open: "11:30", close: "12:30"}
''', encoding='utf-8')
    calendar.reload_holidays(path)
    yield
    calendar.reload_holidays()


@pytest.mark.parametrize('response', [{'s': 'ok'}, {'s': 'ok', 'candles': None},
                                      {'s': 'ok', 'candles': {'rows': []}},
                                      {'s': 'ok', 'candles': 'not candles'}])
def test_ok_without_list_is_provider_error_not_no_data(response):
    client = Mock()
    client.history.return_value = response
    with pytest.raises(HistoricalProviderError, match='Malformed historical candles payload'):
        historical.fetch_historical_1m(client, INSTRUMENT.fyers_symbol, str(DAY), str(DAY), RETRY)
    assert client.history.call_count == 1


@pytest.mark.parametrize('days', [0, -1, True, 1.5])
def test_invalid_chunk_size_fails_before_an_unbounded_loop(days):
    with pytest.raises(ValueError, match='positive integer'):
        historical.chunk_date_range(str(DAY), str(DAY), days)


def run_history(monkeypatch, rows, sink=None, timeframes=None, derived_sink=None):
    monkeypatch.setattr(history, 'fetch_historical_1m', lambda *args, **kwargs: rows)
    writes = []
    sink = sink or NS(write_batch=lambda values: writes.extend(values), last_conflicts=0)
    result = history.process_instrument(object(), INSTRUMENT, str(DAY), str(DAY),
        NS(retry=RETRY, validation_enabled=True), REGISTRY, sink,
        NS(save_checkpoint=lambda *args: None), timeframe_settings=timeframes, derived_sink=derived_sink)
    return result, writes


def test_history_rejects_out_of_request_and_unaligned_rows(monkeypatch):
    rows = [raw(at()), raw(at(DAY - dt.timedelta(days=1))), raw(at(second=5))]
    result, written = run_history(monkeypatch, rows)
    assert result.status == 'partial'
    assert result.raw_count == 3 and result.valid_count == 1 and result.invalid_count == 2
    assert len(written) == 1 and written[0].timestamp == at()


def test_history_does_not_freeze_current_forming_minute_as_closed(monkeypatch):
    now = at(hour=10, minute=0, second=30)
    class Frozen(dt.datetime):
        @classmethod
        def now(cls, tz=None):
            return now if tz else now.replace(tzinfo=None)
    monkeypatch.setattr(dt, 'datetime', Frozen)
    result, written = run_history(monkeypatch, [raw(at(hour=9, minute=59)), raw(at(hour=10))])
    assert result.invalid_count == 1
    assert len(written) == 1 and written[0].timestamp.minute == 59


def test_derived_conflict_makes_full_history_partial(monkeypatch):
    rows = [raw(ts) for ts in calendar.expected_starts(DAY)]
    derived = NS(write_batch=lambda candles: None, last_conflicts=1)
    result, written = run_history(monkeypatch, rows, timeframes=NS(derived_timeframes=[NS(name='5m')]),
                                 derived_sink=derived)
    assert len(written) == 375
    assert result.status == 'partial' and result.derived_counts == {'5m': 75}


def test_derived_failure_keeps_completed_raw_write_and_counts(monkeypatch):
    class Sink:
        last_stored = 0
        last_conflicts = 0
        def write_batch(self, values):
            if values[0].timeframe != '1m':
                self.last_stored = 0
                raise OSError('derived partition unavailable')
            self.last_stored = len(values)
    result, _ = run_history(monkeypatch, [raw(ts) for ts in calendar.expected_starts(DAY)], sink=Sink(),
                            timeframes=NS(derived_timeframes=[NS(name='5m')]))
    assert result.status == 'failed'
    assert result.raw_count == result.valid_count == result.stored_count == 375


def test_provider_failure_does_not_report_previous_instrument_writes(monkeypatch):
    def fail(*args, **kwargs):
        raise TimeoutError('provider timeout')
    monkeypatch.setattr(history, 'fetch_historical_1m', fail)
    sink = NS(last_stored=375, write_batch=Mock())
    result = history.process_instrument(object(), INSTRUMENT, str(DAY), str(DAY),
        NS(retry=RETRY, validation_enabled=True), REGISTRY, sink, NS(save_checkpoint=Mock()))
    assert result.status == 'failed' and result.stored_count == result.raw_count == 0
    sink.write_batch.assert_not_called()


def test_gap_tail_uses_evening_and_split_session_closes(split_calendar):
    assert gaps.expected_last_candle(dt.datetime(2026, 10, 18, 20)) == dt.datetime(2026, 10, 18, 18, 59)
    assert gaps.expected_last_candle(dt.datetime(2026, 10, 19, 8)) == dt.datetime(2026, 10, 18, 18, 59)
    assert gaps.expected_last_candle(dt.datetime(2026, 10, 19, 11)) == dt.datetime(2026, 10, 19, 9, 59)
    assert gaps.expected_last_candle(dt.datetime(2026, 10, 19, 14)) == dt.datetime(2026, 10, 19, 12, 29)
    assert gaps._missing_in_range(dt.datetime(2026, 10, 18, 18, 30), dt.datetime(2026, 10, 18, 18, 59)) == 29


def test_gap_counts_only_missing_exchange_minutes_across_break(split_calendar):
    rows = [NS(timestamp=at(hour=9, minute=58)), NS(timestamp=at(hour=11, minute=31))]
    found = find_gaps_1m(rows)
    assert len(found) == 1 and found[0].missing_minutes == 2


def test_stale_tail_counts_and_requests_use_the_same_bound(monkeypatch):
    calls = []
    monkeypatch.setattr(gaps, '_missing_in_range', lambda start, end: calls.append((start, end)) or 10)
    now = dt.datetime(2026, 10, 19, 17)
    targets, _ = gaps.plan_fills([gaps.SymbolData('TEST', INSTRUMENT.fyers_symbol,
                                                 dt.datetime(2010, 1, 1, 15, 29), [])], now=now)
    assert len(calls) == 1
    assert calls[0][0].date() >= now.date() - dt.timedelta(days=gaps.MAX_TAIL_DAYS + 1)
    assert targets[0].missing_minutes == 10
