import copy
import datetime as dt
import json
from types import SimpleNamespace as NS

import pandas as pd
import pytest
from sqlalchemy import text,event

from controller import underlying_service as svc
from controller import underlying_cli as cli
from controller.unified_workflow import fingerprint
from model.config.instrument_loader import Instrument,InstrumentRegistry
from model.config.market_calendar import IST
from model.fno.config import DEFAULT_SESSION
from test_read_api import env,seed,DAY


def registry():
    return InstrumentRegistry([
        Instrument('NIFTY50','NSE:NIFTY50-INDEX','NSE','INDEX',True,'index'),
        Instrument('NIFTYBANK','NSE:NIFTYBANK-INDEX','NSE','INDEX',True,'index'),
        Instrument('SBIN','NSE:SBIN-EQ','NSE','EQUITY',True,'stock')])


def settings():
    return NS(session=DEFAULT_SESSION,universe=NS(underlyings=('NIFTY','BANKNIFTY','FINNIFTY'),spot_symbols={
        'NIFTY':'NSE:NIFTY50-INDEX','BANKNIFTY':'NSE:NIFTYBANK-INDEX','FINNIFTY':'NSE:FINNIFTY-INDEX'}))


def workflow(names=('NIFTY50',)):
    targets=[{'internal_name':n,'symbol':registry().get(n).fyers_symbol} for n in names]
    params={'from':str(DAY),'to':str(DAY),'symbols':list(names),'timeframes':[],'use_parquet':True,
        'workflow':{'version':1,'segment':'CASH','targets':targets,'timeframes':['1m'],'from':str(DAY),'to':str(DAY)}}
    p={'segment':'CASH','params':params,'fetch_plan':{'requests_estimate':1},'stages':['FETCH','VERIFY','READY']}
    p['token']=fingerprint(p);return p


def facade(state='SUCCESS'):
    calls=[]
    class Runner:
        def run_one(self,*,job_id):calls.append(('run',job_id))
        def run_until_empty(self):pytest.fail('Must not drain unrelated queue')
    def submit(role,kind,params):
        calls.append(('submit',role,kind,copy.deepcopy(params)));return 19
    backend=NS(instruments=registry(),submit=submit,runner=Runner,
        store=NS(get=lambda jid:{'state':state,'result':{'version':1,'stage':'READY','ready':True}}))
    def preview(segment,params,**kwargs):
        calls.append(('preview',segment,params,kwargs))
        return workflow(tuple(params['symbols']))
    return NS(_service=lambda seg:backend,preview_workflow=preview),calls


def test_explicit_mapping_only_active_indices_no_guessed_symbols():
    resolved=svc.resolve_underlyings(['banknifty','NIFTY','NIFTY'],registry(),settings())
    assert [r['internal_name'] for r in resolved]==['NIFTYBANK','NIFTY50']
    with pytest.raises(ValueError):svc.resolve_underlyings(['FINNIFTY'],registry(),settings())
    cfg=settings();cfg.universe.spot_symbols['NIFTY']='NSE:SBIN-EQ'
    with pytest.raises(ValueError):svc.resolve_underlyings(['NIFTY'],registry(),cfg)
    import dataclasses
    reg=InstrumentRegistry([dataclasses.replace(i,active=False) if i.internal_name=='NIFTY50' else i
                            for i in registry().all_instruments()])
    with pytest.raises(ValueError):svc.resolve_underlyings(['NIFTY'],reg,settings())


def test_preview_is_existing_cash_workflow_without_submission():
    service,calls=facade()
    plan=svc.preview_underlyings(service,settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert plan['mappings'][0]['symbol']=='NSE:NIFTY50-INDEX'
    assert [c[0] for c in calls]==['preview']


@pytest.mark.parametrize('state,code,ready',[('SUCCESS',0,True),('FAILED',1,False),('PARTIAL',2,False),('RUNNING',2,False),('NO_DATA',2,False)])
def test_run_only_claims_new_job_and_never_exposes_stale_readiness(state,code,ready):
    service,calls=facade(state)
    plan=svc.preview_underlyings(service,settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    result,actual=svc.run_underlyings(service,settings(),plan)
    assert actual==code and result['regular_index_data_ready']==ready
    assert ('run',19) in calls
    assert [c for c in calls if c[0]=='submit'][0][1:3]==('admin','WORKFLOW')


def test_changed_plan_mapping_calendar_and_foreign_targets_block_before_submit(monkeypatch):
    service,calls=facade();cfg=settings()
    plan=svc.preview_underlyings(service,cfg,['NIFTY'],str(DAY),str(DAY),['1m'])
    altered=copy.deepcopy(plan);altered['mappings'][0]['symbol']='NSE:OTHER'
    with pytest.raises(ValueError):svc.run_underlyings(service,cfg,altered)
    cfg.universe.spot_symbols['NIFTY']='NSE:NIFTYBANK-INDEX'
    with pytest.raises(ValueError):svc.run_underlyings(service,cfg,plan)
    cfg=settings();monkeypatch.setattr(svc,'calendar_metadata',lambda:{'different':True})
    with pytest.raises(ValueError):svc.run_underlyings(service,cfg,plan)
    assert not any(c[0]=='submit' for c in calls)


def seed_index(env):
    rows=seed(env,n=375)
    with env[1]['CASH'].begin() as c:
        c.execute(text("UPDATE instruments SET fyers_symbol='NSE:NIFTY50-INDEX',internal_name='NIFTY50',instrument_type='INDEX',category='index' WHERE id=1"))
    from controller.verification_controller import CashReader
    path=CashReader(env[1]['CASH'],env[0].catalog.roots['CASH']).path('NSE:NIFTY50-INDEX','1m',DAY)
    path.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame([{**r,'fyers_symbol':'NSE:NIFTY50-INDEX'} for r in rows]).to_parquet(path,index=False)
    return path


def test_real_strict_index_read_and_385_vs_375_alignment_no_forward_fill(env):
    path=seed_index(env);seed(env,segment='FNO',n=385)
    before=path.read_bytes();queries=[]
    for e in env[1].values():event.listen(e,'before_cursor_execute',lambda c,cu,s,p,ctx,m:queries.append(s))
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert report['regular_index_data_ready'] and report['summary']['verified_rows']==375
    assert not report['fno_timestamp_alignment_ready']
    align=report['alignment'][0]
    assert align['fno_observed_slots']==385
    assert align['without_verified_index']==align['outside_configured_cash_session']==10
    assert not align['fno_values_verified']
    assert path.read_bytes()==before
    assert not any(q.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','ALTER','DROP')) for q in queries)


def test_missing_base_blocks_derived_and_later_mutation_invalidates_readiness(env):
    path=seed_index(env)
    with env[1]['CASH'].begin() as c:c.execute(text('UPDATE candles SET close=100 WHERE id=1'))
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m','5m'])
    assert not report['regular_index_data_ready']
    assert [x['status'] for x in report['checks']]==['NOT_VERIFIED','NOT_CHECKED_BASE_UNVERIFIED']


def test_wrong_master_metadata_cannot_be_index_ready(env):
    seed_index(env)
    with env[1]['CASH'].begin() as c:c.execute(text("UPDATE instruments SET category='stock'"))
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert report['checks'][0]['status']=='INDEX_METADATA_MISMATCH'


def test_cli_authentication_and_explicit_confirmation_precede_services(monkeypatch,tmp_path,capsys):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:pytest.fail('Confirmation missing'))
    with pytest.raises(SystemExit):cli.main(['run','--plan',str(tmp_path/'p.json')])
    def denied():raise PermissionError('denied')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',denied)
    monkeypatch.setattr('model.fno.config.load_fno_settings',lambda:pytest.fail('Must authenticate first'))
    assert cli.main(['check','--underlyings','NIFTY','--from',str(DAY),'--to',str(DAY),'--output',str(tmp_path/'r.json')])==1
    assert not (tmp_path/'r.json').exists()


def test_cli_preview_preserves_existing_report_without_network(monkeypatch,tmp_path):
    service,calls=facade()
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('model.fno.config.load_fno_settings',settings)
    monkeypatch.setattr('controller.market_data_service.MarketDataService',lambda:service)
    path=tmp_path/'plan.json'
    args=['preview','--underlyings','NIFTY','--from',str(DAY),'--to',str(DAY),'--timeframes','1m','--output',str(path)]
    assert cli.main(args)==0
    before=path.read_bytes();assert cli.main(args)==2 and path.read_bytes()==before
    assert json.loads(before)['format']=='tios-underlying-v1'


def test_rehashed_stock_target_cannot_escape_index_scope():
    service,calls=facade()
    plan=svc.preview_underlyings(service,settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    plan['workflow']=workflow(('SBIN',))
    plan.pop('token');plan['token']=fingerprint(plan)
    with pytest.raises(ValueError):svc.run_underlyings(service,settings(),plan)
    assert not any(c[0]=='submit' for c in calls)


def test_calendar_change_invalidates_readiness_and_alignment(env,monkeypatch):
    seed_index(env);seed(env,segment='FNO',n=375)
    calls=[];original=svc.calendar_metadata
    def changing():
        calls.append(1);return {**original(),'revision':len(calls)}
    monkeypatch.setattr(svc,'calendar_metadata',changing)
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert not report['regular_index_data_ready'] and not report['fno_timestamp_alignment_ready']
    assert report['summary']['verified_rows']==0


def test_full_timestamp_overlap_is_scoped_ready_but_not_fno_value_certificate(env):
    seed_index(env);seed(env,segment='FNO',n=375)
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert report['status']=='UNDERLYING_SCOPED_READY' and report['fno_timestamp_alignment_ready']
    assert report['alignment'][0]['fno_values_verified'] is False


def test_index_zero_volume_remains_valid_without_fabricated_turnover(env):
    path=seed_index(env)
    with env[1]['CASH'].begin() as c:c.execute(text('UPDATE candles SET volume=0'))
    frame=pd.read_parquet(path);frame['volume']=0;frame.to_parquet(path,index=False)
    report=svc.check_underlyings(env[0],registry(),settings(),['NIFTY'],str(DAY),str(DAY),['1m'])
    assert report['regular_index_data_ready'] and report['summary']['verified_rows']==375
    assert not report['fno_timestamp_alignment_ready']  # No FNO observations seeded.


def test_preview_scope_bound_precedes_workflow_preview():
    service,calls=facade();names=[f'N{i}' for i in range(5)]
    cfg=NS(universe=NS(underlyings=names,spot_symbols={n:'NSE:NIFTY50-INDEX' for n in names}))
    with pytest.raises(ValueError):svc.preview_underlyings(service,cfg,names,'2026-10-01','2026-10-31')
    assert calls==[]
