from pathlib import Path
import pytest


def test_symlink_privilege_denial_skips_only_windows_fixture(make_symlink, monkeypatch, tmp_path):
    def denied(*args, **kwargs):
        exc = OSError('Privilege not held')
        exc.winerror = 1314
        raise exc
    monkeypatch.setattr(Path, 'symlink_to', denied)
    monkeypatch.setattr('sys.platform', 'win32')
    with pytest.raises(pytest.skip.Exception, match='Windows symlink privilege'):
        make_symlink(tmp_path/'alias', tmp_path/'target')


def test_unexpected_symlink_errors_still_fail(make_symlink, monkeypatch, tmp_path):
    def denied(*args, **kwargs):
        raise OSError('Unexpected fixture error')
    monkeypatch.setattr(Path, 'symlink_to', denied)
    with pytest.raises(OSError, match='Unexpected fixture error'):
        make_symlink(tmp_path/'alias', tmp_path/'target')
