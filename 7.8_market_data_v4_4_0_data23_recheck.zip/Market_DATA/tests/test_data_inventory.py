import datetime as dt
import json

import pandas as pd
import pytest
from sqlalchemy import Column, Date, DateTime, Integer, MetaData, String, Table, create_engine, event

from controller import diagnostics_cli
from model import data_inventory as inv
from model.database_catalog import DatabaseCatalog
from model.config.market_calendar import IST

DAY = dt.date(2026, 11, 5)
NOW = dt.datetime(2026, 11, 6, 12, tzinfo=IST)


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    engine = create_engine('sqlite://')
    meta = MetaData()
    masters, candles = {}, {}
    for segment, prefix in [('CASH', ''), ('FNO', 'fno_')]:
        fields = [Column('id', Integer, primary_key=True), Column('fyers_symbol', String),
                  Column('internal_name', String)]
        if segment == 'FNO':
            fields += [Column('underlying', String), Column('expiry', Date), Column('category', String)]
        masters[segment] = Table(prefix+'instruments', meta, *fields)
        candles[segment] = Table(prefix+'candles', meta, Column('id', Integer, primary_key=True),
            Column('instrument_id' if segment == 'CASH' else 'contract_id', Integer),
            Column('timeframe', String), Column('candle_timestamp', DateTime), Column('status', String))
    ck = Table('fno_checkpoint_ranges', meta, Column('id', Integer, primary_key=True),
               Column('contract_id', Integer), Column('timeframe', String), Column('range_from', Date),
               Column('range_to', Date), Column('status', String), Column('job_type', String))
    manifest = Table('fno_storage_manifest', meta, Column('relative_path', String, primary_key=True), Column('status', String))
    meta.create_all(engine)
    roots = {s: tmp_path/s.lower() for s in masters}
    for root in roots.values(): root.mkdir()
    cat = DatabaseCatalog({s: lambda: engine for s in masters}, roots)
    monkeypatch.setattr(inv, 'calendar_verified', lambda *a: True)
    with engine.begin() as c:
        c.execute(masters['CASH'].insert(), [{'id': 1, 'internal_name': 'SBIN', 'fyers_symbol': 'NSE:SBIN-EQ'}])
        c.execute(masters['FNO'].insert(), [dict(id=i, internal_name='', fyers_symbol=f'NSE:OPT{i}',
            underlying='NIFTY', expiry=dt.date(2026,11,9), category='OPTIONS') for i in range(1,5)])

    def seed(segment='CASH', ids=(1,), count=375, timeframe='1m'):
        stamps = [dt.datetime(2026,11,5,9,15)+dt.timedelta(minutes=i) for i in range(count)]
        records=[]
        for i in ids:
            with engine.begin() as c:
                c.execute(candles[segment].insert(), [{'instrument_id' if segment=='CASH' else 'contract_id':i,
                     'candle_timestamp':ts, 'timeframe':timeframe, 'status':'CLOSED'} for ts in stamps])
            records += [{'fyers_symbol':'NSE:SBIN-EQ'}|({'contract_id':i} if segment=='FNO' else {})|
                        {'timeframe':timeframe,'candle_timestamp':ts,'status':'CLOSED'} for ts in stamps]
        rel = ('raw/1m/NSE_SBIN-EQ/2026-11-05.parquet' if segment=='CASH' else
               f'candles/{timeframe}/underlying=NIFTY/expiry=2026-11-09/date=2026-11-05.parquet')
        path=roots[segment]/rel;path.parent.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(records).to_parquet(path,index=False)
        if segment=='FNO':
            with engine.begin() as c: c.execute(manifest.insert(), {'relative_path':rel,'status':'VERIFIED'})
        return path

    yield cat, engine, masters, candles, ck, manifest, seed
    engine.dispose()


def run(cat, segment='CASH', **kwargs):
    return inv.inventory_report(cat,segment,DAY,DAY,timeframes=['1m'],now=NOW,**kwargs)


def test_cash_scoped_counts_keys_and_no_writes(fixture):
    cat, engine, _, _, _, _, seed=fixture
    path=seed(); before=path.read_bytes(); statements=[]
    event.listen(engine,'before_cursor_execute',lambda c,cur,s,p,ctx,m: statements.append(s))
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='SCOPED_INVENTORY_PASS' and report['complete']
    row=report['partitions'][0]
    assert row['sql']['rows']==row['parquet']['rows']==375
    assert row['keys_match'] and not report['values_verified']
    assert row['coverage']['sql']['unobserved_slots']==0
    assert report['targets'][0]['base_days_observed']==['2026-11-05']
    assert not any(s.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','DROP','ALTER')) for s in statements)
    assert path.read_bytes()==before


def test_empty_registered_symbol_reports_unfetched_day_not_holiday(fixture):
    report=run(fixture[0],symbols=['NSE:SBIN-EQ'])
    assert report['status']=='FINDINGS' and report['complete']
    row=report['partitions'][0]
    assert row['coverage']['expected_slots']==375
    assert 'NO_CANDLES_OBSERVED' in row['issues']
    assert report['targets'][0]['base_days_without_candles']==['2026-11-05']


def test_shared_fno_file_read_once_and_no_data_contract_included(fixture,monkeypatch):
    cat,engine,_,_,ck,_,seed=fixture
    seed('FNO',ids=(1,2),count=385)
    with engine.begin() as c:
        c.execute(ck.insert(),{'contract_id':3,'timeframe':'1m','range_from':DAY,'range_to':DAY,
                              'status':'NO_DATA','job_type':'HISTORICAL'})
    import pyarrow.parquet as pq
    original=pq.ParquetFile;calls=[]
    def opened(stream):calls.append(stream);return original(stream)
    monkeypatch.setattr(pq,'ParquetFile',opened)
    report=run(cat,'FNO',underlyings=['NIFTY'])
    assert [t['id'] for t in report['targets']]==[1,2,3]  # No entire-master scan.
    assert len(calls)==1 and calls[0].closed
    assert report['summary']['parquet_rows_read']==770
    assert report['partitions'][2]['checkpoint_statuses']==['NO_DATA']
    assert report['partitions'][2]['parquet']['rows']==0
    assert 'NO_CANDLES_OBSERVED' in report['partitions'][2]['issues']
    assert report['partitions'][0]['keys_match']


def test_key_mismatch_and_open_rows_are_findings(fixture):
    cat,_,_,_,_,_,seed=fixture
    path=seed(count=2);frame=pd.read_parquet(path);frame.loc[0,'status']='OPEN';frame.to_parquet(path,index=False)
    report=run(cat,symbols=['SBIN'])
    row=report['partitions'][0]
    assert 'SQL_PARQUET_KEY_MISMATCH' in row['issues']
    assert 'PARQUET_DUPLICATE_OR_OPEN_ROWS' in row['issues']
    assert not report['values_verified']


def test_unknown_calendar_and_oversized_file_cannot_pass(fixture,monkeypatch):
    cat,*_,seed=fixture
    seed();monkeypatch.setattr(inv,'MAX_FILE_ROWS',1)
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='PARTIAL' and not report['complete']
    assert 'PARQUET_ROW_BOUND_EXCEEDED' in report['partitions'][0]['issues']
    monkeypatch.setattr(inv,'MAX_FILE_ROWS',200000)
    monkeypatch.setattr(inv,'calendar_verified',lambda *a:False)
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='FINDINGS'
    assert 'CALENDAR_UNVERIFIED' in report['partitions'][0]['issues']


def test_corrupt_shared_file_remains_unavailable_for_every_contract(fixture):
    cat,*_,seed=fixture
    path=seed('FNO',ids=(1,2));path.write_bytes(b'corrupt')
    report=run(cat,'FNO',contract_ids=[1,2])
    assert report['status']=='PARTIAL' and not report['complete']
    assert 'INSPECTION_UNAVAILABLE' in report['partitions'][0]['issues']
    assert 'PARQUET_READ_ERROR' in report['partitions'][1]['issues']


def test_changed_file_never_reports_matching_keys(fixture,monkeypatch):
    cat,*_,seed=fixture
    seed();original=inv._version;calls=[]
    def version(path):
        calls.append(path);v=original(path)
        return (*v[:-1],v[-1]+len(calls))
    monkeypatch.setattr(inv,'_version',version)
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='PARTIAL'
    assert 'PARQUET_CHANGED_DURING_READ' in report['partitions'][0]['issues']
    assert 'keys_match' not in report['partitions'][0]


@pytest.mark.parametrize('kwargs',[{'symbols':['UNKNOWN']},{'symbols':['SBIN'],'contract_ids':[1]}])
def test_unknown_or_mixed_selection_is_rejected(fixture,kwargs):
    with pytest.raises(ValueError): run(fixture[0],**kwargs)


def test_current_day_large_range_and_scope_bounds(fixture,monkeypatch):
    cat=fixture[0]
    with pytest.raises(ValueError): inv.inventory_report(cat,'CASH',DAY,NOW.date(),symbols=['SBIN'],now=NOW)
    with pytest.raises(ValueError): inv.inventory_report(cat,'CASH','2026-01-01',DAY,symbols=['SBIN'],now=NOW)
    monkeypatch.setattr(inv,'MAX_PARTITIONS',1)
    with pytest.raises(ValueError): inv.inventory_report(cat,'CASH',DAY,DAY,symbols=['SBIN'],timeframes=['1m','5m'],now=NOW)


def test_linked_partition_refused(fixture,tmp_path):
    cat,*_,seed=fixture
    path=seed();outside=tmp_path/'outside.parquet';outside.write_bytes(path.read_bytes());path.unlink()
    try:path.symlink_to(outside)
    except OSError as e:
        if getattr(e,'winerror',None)==1314:pytest.skip('Real symlink fixture requires Windows privilege')
        raise
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='PARTIAL'
    assert report['partitions'][0]['error_type']=='ValueError'


def test_cli_admin_first_and_output_is_exclusive(fixture,tmp_path,monkeypatch,capsys):
    cat,*_,seed=fixture;seed()
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:cat)
    path=tmp_path/'report.json'
    args=['inventory','--segment','CASH','--symbols','SBIN','--from',str(DAY),'--to',str(DAY),'--timeframes','1m','--output',str(path)]
    assert diagnostics_cli.main(args)==0
    before=path.read_bytes();report=json.loads(before)
    assert report['status']=='SCOPED_INVENTORY_PASS' and not report['values_verified']
    assert diagnostics_cli.main(args)==2 and path.read_bytes()==before
    def denied():raise PermissionError('denied')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',denied)
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:pytest.fail('Must authenticate before catalog access'))
    assert diagnostics_cli.main(args[:-2])==1


def test_sql_failure_is_partial_and_error_is_sanitized(fixture,monkeypatch):
    cat,engine,*_=fixture
    def fail(conn,cursor,statement,params,context,many):
        if 'FROM candles' in statement:raise RuntimeError('mysql://user:secret@host')
    event.listen(engine,'before_cursor_execute',fail)
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='PARTIAL' and not report['complete']
    assert 'secret' not in json.dumps(report)


@pytest.mark.parametrize('segment,expected_total', [('CASH',621),('FNO',638)])
def test_all_timeframes_include_session_clipped_final_buckets(fixture,segment,expected_total):
    cat,engine,_,candles,_,manifest,seed=fixture
    seed(segment,count=375 if segment=='CASH' else 385)
    from model.fno.config import DEFAULT_SESSION
    for tf in inv.TIMEFRAMES[1:]:
        starts=sorted(inv._expected(segment,DAY,tf,DEFAULT_SESSION))
        data=[{'timeframe':tf,'candle_timestamp':ts.replace(tzinfo=None),'status':'CLOSED'} for ts in starts]
        with engine.begin() as c:
            c.execute(candles[segment].insert(),[dict(row,**{'instrument_id' if segment=='CASH' else 'contract_id':1}) for row in data])
        rel=(f'processed/{tf}/NSE_SBIN-EQ/2026-11-05.parquet' if segment=='CASH' else
             f'candles/{tf}/underlying=NIFTY/expiry=2026-11-09/date=2026-11-05.parquet')
        path=cat.roots[segment]/rel;path.parent.mkdir(parents=True,exist_ok=True)
        pd.DataFrame([dict(row,**({'fyers_symbol':'NSE:SBIN-EQ'} if segment=='CASH' else {'contract_id':1})) for row in data]).to_parquet(path,index=False)
        if segment=='FNO':
            with engine.begin() as c:c.execute(manifest.insert(),{'relative_path':rel,'status':'VERIFIED'})
    report=inv.inventory_report(cat,segment,DAY,DAY,now=NOW,
                               **({'symbols':['SBIN']} if segment=='CASH' else {'contract_ids':[1]}))
    assert report['status']=='SCOPED_INVENTORY_PASS'
    assert report['summary']['sql_rows_read']==expected_total
    assert len(report['partitions'])==7


def test_sql_row_bound_and_no_target_scope_never_pass(fixture,monkeypatch):
    cat,*_,seed=fixture;seed()
    monkeypatch.setattr(inv,'MAX_SQL_ROWS',2)
    report=run(cat,symbols=['SBIN'])
    assert report['status']=='PARTIAL'
    assert 'SQL_PARTITION_ROW_BOUND_EXCEEDED' in report['partitions'][0]['issues']
    report=run(cat,'FNO',underlyings=['UNKNOWN'])
    assert report['status']=='FINDINGS' and report['targets']==[]
    assert report['summary']['issues']['NO_TARGETS_IN_SCOPE']==1


def test_target_cap_rejects_broad_scope_before_reading_partitions(fixture,monkeypatch):
    cat,*_,seed=fixture;seed('FNO',ids=(1,2))
    monkeypatch.setattr(inv,'MAX_TARGETS',1)
    with pytest.raises(ValueError):run(cat,'FNO',underlyings=['NIFTY'])
