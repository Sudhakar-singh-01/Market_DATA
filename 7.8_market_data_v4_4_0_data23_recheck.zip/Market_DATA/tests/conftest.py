import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


import pytest
@pytest.fixture(autouse=True)
def isolated_runtime_budget(tmp_path,monkeypatch):
    """Tests cannot spend/reset the installation's persisted account allowance."""
    from model.fyers.rate_limiter import configure_shared_limiter
    # A developer's permanent Windows profile must not replace repository
    # fixtures (calendar/config) during tests. Individual profile tests set
    # TIOS_HOME explicitly after this isolation step.
    monkeypatch.delenv('TIOS_HOME', raising=False)
    monkeypatch.setenv('TIOS_RUNTIME_DIR',str(tmp_path/'runtime'))
    configure_shared_limiter(None)
    yield
    configure_shared_limiter(None)


@pytest.fixture
def make_symlink():
    """Skip only real-link fixtures when Windows denies symlink creation."""
    def create(alias, target, **kwargs):
        try:
            alias.symlink_to(target, **kwargs)
        except OSError as exc:
            if sys.platform == 'win32' and getattr(exc, 'winerror', None) == 1314:
                pytest.skip('Real symlink fixture requires Windows symlink privilege')
            raise
    return create
