"""Provider-free live price/volume and reconnect regression checks."""
import datetime as dt
from types import SimpleNamespace as NS

import pytest

from controller import live_controller as live
from model.config.instrument_loader import Instrument, InstrumentRegistry
from model.processing.candle_builder import CandleBuilder1m
from model.processing.models import IST, Tick
from model.processing.normalizer import normalize_live_tick

DAY = dt.date(2026, 10, 19)
SYMBOL = 'NSE:TEST-EQ'


def timestamp(minute, second=0, day=DAY):
    return dt.datetime.combine(day, dt.time(9, minute, second), tzinfo=IST)


def tick(minute, volume, price=100, second=0):
    return Tick(SYMBOL, timestamp(minute, second), price, volume)


@pytest.mark.parametrize('volume', ['100', '9007199254740993'])
def test_numeric_string_tick_volume_is_an_exact_integer(volume):
    result = normalize_live_tick({'symbol': SYMBOL, 'ltp': '100',
                                 'exch_feed_time': timestamp(15).timestamp(),
                                 'vol_traded_today': volume})
    assert result.volume_traded_today == int(volume)
    assert type(result.volume_traded_today) is int


@pytest.mark.parametrize('field', ['ltp', 'exch_feed_time', 'vol_traded_today'])
def test_boolean_tick_numbers_are_rejected(field):
    message = {'symbol': SYMBOL, 'ltp': 100, 'exch_feed_time': timestamp(15).timestamp(),
               'vol_traded_today': 10}
    message[field] = True
    assert normalize_live_tick(message) is None


def test_missing_first_volume_never_becomes_the_whole_day_volume():
    builder = CandleBuilder1m()
    builder.on_tick(tick(15, None))
    builder.on_tick(tick(15, 5_000_000, second=10))
    builder.on_tick(tick(15, 5_000_040, second=20))
    closed = builder.on_tick(tick(16, 5_000_050))
    assert closed.volume == 40
    assert closed.volume_start == 5_000_000


def test_stale_tick_inside_the_current_minute_does_not_regress_close_or_volume():
    builder = CandleBuilder1m()
    builder.on_tick(tick(15, 100, price=100, second=10))
    builder.on_tick(tick(15, 120, price=110, second=40))
    builder.on_tick(tick(15, 110, price=105, second=20))
    closed = builder.on_tick(tick(16, 130))
    assert closed.close == 110
    assert closed.volume == 20


@pytest.fixture
def controller(monkeypatch):
    monkeypatch.setattr(live, 'FyersWebSocketClient', lambda **kw: NS(stop=lambda: None))
    instrument = Instrument('TEST', SYMBOL, 'NSE', 'EQ', True, 'stock')
    stored = []
    result = live.LiveIngestionController('fake', InstrumentRegistry([instrument]),
        NS(validation_enabled=False, retry=None, reconnect=None),
        sink=NS(write_one=stored.append, write_batch=lambda rows: stored.extend(rows)),
        clock=lambda: timestamp(20, 30))
    result._timeframe_aggregator = NS(on_1m_candle=lambda row: [], flush_all=lambda: [])
    return result, stored


def test_cash_contiguous_minutes_include_the_first_ticks_volume_delta(controller):
    result, stored = controller
    for minute, volume, sec in [(15,100,1), (15,120,50), (16,130,1), (16,140,50), (17,150,1)]:
        result._candle_builder.on_tick(tick(minute, volume, second=sec))
    assert [row.volume for row in stored] == [20, 20]


def test_cash_gap_does_not_assign_all_missed_volume_to_one_candle(controller):
    result, stored = controller
    for minute, volume, sec in [(15,100,1), (15,120,50), (19,8000,1), (19,8010,50), (20,8020,1)]:
        result._candle_builder.on_tick(tick(minute, volume, second=sec))
    assert [row.volume for row in stored] == [20, 10]


def test_live_aggregation_uses_the_sql_accepted_authoritative_row(controller):
    from dataclasses import replace
    result, _ = controller
    fed = []
    result._sink = NS(write_one=lambda c: [replace(c, source='FYERS_HISTORICAL', volume=99)])
    result._timeframe_aggregator = NS(on_1m_candle=lambda row: fed.append(row) or [])
    result._candle_builder.on_tick(tick(15, 100))
    result._candle_builder.on_tick(tick(16, 120))
    assert fed[0].volume == 99 and fed[0].source == 'FYERS_HISTORICAL'


def test_cash_reconnect_clears_volume_baseline_even_without_history(controller):
    result, stored = controller
    for minute, volume, sec in [(15,100,1), (15,120,50), (16,130,1)]:
        result._candle_builder.on_tick(tick(minute, volume, second=sec))
    result._handle_reconnect()
    result._candle_builder.on_tick(tick(16, 8000, second=50))
    result._candle_builder.on_tick(tick(17, 8020, second=1))
    assert stored[-1].volume == 0  # no estimate over the disconnected interval
