"""Real Parquet handles close before returning or raising from verification."""
import datetime as dt
from pathlib import Path
from types import SimpleNamespace as NS

import pandas as pd
import pytest

from controller.verification_controller import CashReader


@pytest.mark.parametrize('invalid', [False, True])
def test_cash_verification_closes_owned_file_even_on_bad_identity(tmp_path, monkeypatch, invalid):
    reader = CashReader(None, tmp_path)
    day = dt.date(2026, 10, 19)
    path = reader.path('NSE:TEST-EQ', '1m', day)
    path.parent.mkdir(parents=True)
    pd.DataFrame([{'fyers_symbol': 'WRONG' if invalid else 'NSE:TEST-EQ', 'timeframe': '1m'}]).to_parquet(path)
    opened = []
    real = Path.open
    def tracking(self, mode='r', *args, **kwargs):
        stream = real(self, mode, *args, **kwargs)
        if self == path and mode == 'rb':opened.append(stream)
        return stream
    monkeypatch.setattr(Path, 'open', tracking)
    if invalid:
        with pytest.raises(ValueError, match='identity'):
            reader.parquet_day('NSE:TEST-EQ', '1m', day)
    else:
        assert len(reader.parquet_day('NSE:TEST-EQ', '1m', day)[0]) == 1
    assert opened and all(s.closed for s in opened)


def test_fno_verification_closes_file_after_manifest_mismatch(tmp_path, monkeypatch):
    from sqlalchemy import Table, MetaData, Column, String
    from model.fno.read_verification import _parquet
    from model.read_contracts import DataNotVerifiedError
    day = dt.date(2026, 10, 19)
    path = tmp_path / 'candles/1m/underlying=NIFTY/expiry=2026-11-26/date=2026-10-19.parquet'
    path.parent.mkdir(parents=True)
    pd.DataFrame([{'contract_id': 1}]).to_parquet(path)
    table = Table('fno_storage_manifest', MetaData(), Column('relative_path', String))
    service = NS(catalog=NS(roots={'FNO': tmp_path}, table=lambda *args: table),
                 _read=lambda *args: [{'status': 'VERIFIED', 'row_count': 2, 'checksum': 'stale'}])
    opened = []
    real = Path.open
    def tracking(self, mode='r', *args, **kwargs):
        stream = real(self, mode, *args, **kwargs)
        if self == path and mode == 'rb':opened.append(stream)
        return stream
    monkeypatch.setattr(Path, 'open', tracking)
    with pytest.raises(DataNotVerifiedError, match='row count'):
        _parquet(service, {'id': 1, 'expiry': dt.date(2026, 11, 26), 'underlying': 'NIFTY'}, '1m', day)
    assert opened and all(s.closed for s in opened)
