import copy
import time
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from ui.feature_map import WORKSPACES,FEATURES,features

DATA={'tasks':[{'key':'cash:1','id':1,'segment':'CASH','kind':'SMART_FETCH','state':'RUNNING','source':'Persisted queue'},
               {'key':'fno:1','id':1,'segment':'FNO','kind':'VERIFY','state':'RUNNING','source':'Persisted queue'},
               {'key':'ui:1','segment':'UI','kind':'Backup','state':'RUNNING','source':'UI operation'}],
      'sources':[],'checked_at':'2026-11-05T12:00:00+05:30'}


def test_new_shell_shows_every_task_and_no_old_navigation(monkeypatch):
    import ui.task_panel as panel
    monkeypatch.setattr(panel,'snapshot',lambda:copy.deepcopy(DATA))
    from test_dashboard_layer import _authed_apptest
    app=_authed_apptest('ui/dashboard.py','user',monkeypatch)
    assert not app.exception
    assert any(t.value=='Overview' for t in app.title)
    html=' '.join(m.value for m in app.markdown)
    assert html.count('class="task-card"')==3
    assert 'SMART_FETCH' in html and 'VERIFY' in html and 'Backup' in html
    assert not (Path(__file__).resolve().parents[1]/'ui/pages').exists()


@pytest.mark.parametrize('workspace',[w for w in WORKSPACES if w not in ('Overview','Data Explorer')])
def test_workspace_uses_mapped_tool_without_starting_other_features(monkeypatch,workspace):
    import ui.workspaces as w
    monkeypatch.setattr('ui.auth.require_auth',lambda role:True)
    calls=[]
    def open_view(view):
        calls.append(view)
        import streamlit as st
        st.write('Selected '+view)
    monkeypatch.setattr(w,'_open_view',open_view)
    monkeypatch.setattr(w,'_fno',lambda section:calls.append('fno:'+section))
    app=AppTest.from_string('from ui.workspaces import render\nrender('+repr(workspace)+',"admin")').run()
    assert not app.exception
    assert len(calls)==1
    assert calls[0]==features(workspace,'admin')[0].view


def test_normal_user_never_has_admin_tools():
    for workspace in WORKSPACES:
        assert all(f.role=='user' for f in features(workspace,'user'))
    assert len([f for f in FEATURES if f.role=='admin'])>=10


def test_reader_load_is_explicit_and_scope_change_invalidates_results(monkeypatch):
    import ui.workspaces
    monkeypatch.setattr('ui.auth.require_auth',lambda role:True)
    calls=[]
    class Reads:
        def __init__(self,catalog):pass
        def get_candles(self,*args,**kwargs):
            calls.append((args,kwargs))
            return {'data':[{'candle_timestamp':'2026-11-04T09:15:00+05:30'}],
                    'meta':{'next_cursor':'next' if len(calls)==1 else None,'returned':1},
                    'quality':{'status':'VERIFIED'}}
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:object())
    monkeypatch.setattr('model.market_read_service.MarketReadService',Reads)
    app=AppTest.from_string('from ui.workspaces import render\nrender("Data Explorer","user")').run()
    assert not app.exception and calls==[]
    app.text_input(key='reader_symbol').set_value('NSE:SBIN-EQ').run()
    assert calls==[]
    app.button(key='reader_load').click().run()
    assert not app.exception and len(calls)==1
    app.button(key='reader_next').click().run()
    assert not app.exception and calls[-1][1]['cursor']=='next'
    app.selectbox(key='reader_tf').set_value('3m').run()
    assert not app.exception and app.button(key='reader_next').disabled
    assert len(calls)==2
