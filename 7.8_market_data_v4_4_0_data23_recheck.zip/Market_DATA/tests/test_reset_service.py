"""Reset orchestration only against disposable SQLite/files and service doubles."""
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
import json
import copy
import pytest
from sqlalchemy import create_engine,text,inspect
from model.backup_service import BackupService
from model.reset_service import ResetService,SEGMENTS
from model.schema_management import _digest


@pytest.fixture
def setup(tmp_path):
    engines={s:create_engine('sqlite://') for s in SEGMENTS}
    roots={s:tmp_path/s.lower() for s in SEGMENTS}
    for s in SEGMENTS:
        roots[s].mkdir();(roots[s]/'one.parquet').write_bytes(b'old '+s.encode())
        (roots[s]/'keep.lock').write_bytes(b'0')
        with engines[s].begin() as c:
            c.execute(text('CREATE TABLE sample (id INTEGER PRIMARY KEY, value TEXT)'))
            c.execute(text("INSERT INTO sample VALUES (1,'existing data')"))
    catalog=SimpleNamespace(roots=roots,engine=lambda s:engines[s])
    guard=SimpleNamespace(_engine=lambda s:engines[s],_database_lock=lambda e:nullcontext())
    class Backups(BackupService):
        def __init__(self):
            super().__init__(catalog,tmp_path/'backups',tmp_path/'recovery')
            self.guard=guard;self.calls=[];self.fail=None
        def preview(self,s,*,role):
            root,files=self._files(s)
            return {'segment':s,'database':s.lower()+'_test','host':'localhost','port':3306,
                    'tables':sorted(inspect(engines[s]).get_table_names()),'parquet_root':str(root),
                    'file_hash':_digest(files)}
        def create(self,plan,**kwargs):
            s=plan['segment'];self.calls.append(s)
            if s==self.fail:raise RuntimeError('private database details')
            return {'status':'CHECKSUM_VERIFIED','backup_id':s,'restore_tested':False}
    backups=Backups()
    class LocalReset(ResetService):
        fail_drop=None
        drops=[]
        def _check_external_references(self,segment):pass
        def _drop_tables(self,s,tables,record):
            assert backups.calls==list(SEGMENTS)
            self.drops.append(s)
            if s==self.fail_drop:raise RuntimeError('DDL failed')
            with engines[s].begin() as c:
                for t in tables:c.execute(text('DROP TABLE '+t));record('TABLE_DROPPED',segment=s,table=t)
        def _recreate(self,s,definitions,record):
            with engines[s].begin() as c:c.execute(text('CREATE TABLE sample (id INTEGER PRIMARY KEY,value TEXT)'))
            record('EMPTY_SCHEMA_CREATED',segment=s)
    service=LocalReset(catalog,backups,tmp_path/'reset_journals')
    service.drops=[]
    return service,engines,roots,backups


def test_preview_does_not_modify_tables_or_files(setup):
    service,engines,roots,backups=setup
    plan=service.preview(role='admin')
    assert plan['format']=='tios-reset-v1' and len(plan['targets'])==2
    assert plan['confirmation']=='RESET cash_test + fno_test'
    assert not service.journal_root.exists() and not backups.calls
    for s in SEGMENTS:
        assert (roots[s]/'one.parquet').read_bytes()==b'old '+s.encode()
        with engines[s].connect() as c:assert c.execute(text('SELECT COUNT(*) FROM sample')).scalar()==1


@pytest.mark.parametrize('change',[{'writers_stopped':False},{'accept_data_loss':False},{'confirmation':'RESET wrong'}])
def test_apply_rejects_missing_exact_acknowledgments_before_backup(setup,change):
    service,_,_,backups=setup;plan=service.preview(role='admin')
    args={'role':'admin','confirmation':plan['confirmation'],'writers_stopped':True,'accept_data_loss':True,**change}
    with pytest.raises(ValueError):service.apply(plan,**args)
    assert not backups.calls and not service.journal_root.exists()


def apply(service,plan):
    return service.apply(plan,role='admin',confirmation=plan['confirmation'],writers_stopped=True,accept_data_loss=True)


def test_modified_plan_is_rejected(setup):
    service,_,_,backups=setup;plan=service.preview(role='admin')
    plan['targets'][0]['backup_plan']['tables']=['another_table']
    with pytest.raises(ValueError,match='scope or code changed'):apply(service,plan)
    assert not backups.calls


def test_both_backups_required_before_any_reset(setup):
    service,engines,roots,backups=setup;plan=service.preview(role='admin');backups.fail='FNO'
    result=apply(service,plan)
    assert result['status']=='RECOVERY_NEEDED' and service.drops==[]
    assert 'private' not in json.dumps(result)
    for s in SEGMENTS:
        assert (roots[s]/'one.parquet').exists()
        with engines[s].connect() as c:assert c.execute(text('SELECT COUNT(*) FROM sample')).scalar()==1
    with pytest.raises(ValueError,match='Previous reset'):apply(service,plan)


def test_reset_archives_files_and_recreates_empty_tables(setup):
    service,engines,roots,_=setup;result=apply(service,service.preview(role='admin'))
    assert result['status']=='EMPTY_SCHEMA_READY'
    operation=Path(result['journal']).parent
    assert not (operation/'RECOVERY_NEEDED').exists()
    for s in SEGMENTS:
        assert not (roots[s]/'one.parquet').exists()
        assert (operation/'parquet'/s/'one.parquet').read_bytes()==b'old '+s.encode()
        assert (roots[s]/'keep.lock').exists()
        with engines[s].connect() as c:assert c.execute(text('SELECT COUNT(*) FROM sample')).scalar()==0
    assert len(result['backups'])==2 and result['restore_tested'] is False


def test_partial_failure_retains_exact_events_backups_and_blocks_retry(setup):
    service,engines,roots,_=setup;plan=service.preview(role='admin');service.fail_drop='FNO'
    result=apply(service,plan)
    assert result['status']=='RECOVERY_NEEDED'
    assert result['completed']==['CASH:FILES_ARCHIVED','FNO:FILES_ARCHIVED','CASH:TABLES_DROPPED','CASH:EMPTY_SCHEMA_CREATED']
    events=[json.loads(line) for line in Path(result['journal']).read_text().splitlines()]
    assert events[-1]['event']=='RECOVERY_NEEDED'
    assert Path(result['journal']).with_name('RECOVERY_NEEDED').exists()
    with engines['FNO'].connect() as c:assert c.execute(text('SELECT COUNT(*) FROM sample')).scalar()==1


def test_admin_gate_and_journal_root_cannot_overlap_data(setup):
    service,_,roots,_=setup
    with pytest.raises(PermissionError):service.preview(role='user')
    service.journal_root=roots['CASH']/'reset'
    with pytest.raises(ValueError,match='outside both'):service.preview(role='admin')


def test_drop_journals_each_statement_and_restores_fk_session_on_failure(setup):
    service,_,_,_=setup
    calls=[];events=[]
    class Connection:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def exec_driver_sql(self,sql):
            calls.append(sql)
            if sql=='SELECT @@SESSION.FOREIGN_KEY_CHECKS':return SimpleNamespace(scalar=lambda:1)
            if sql=='DROP TABLE `second`':raise RuntimeError('DDL failure')
        def commit(self):calls.append('COMMIT')
    engine=SimpleNamespace(connect=lambda:Connection(),dialect=SimpleNamespace(
        identifier_preparer=SimpleNamespace(quote=lambda name:'`'+name+'`')))
    service.guard=SimpleNamespace(_engine=lambda s:engine)
    with pytest.raises(RuntimeError):
        ResetService._drop_tables(service,'CASH',['first','second'],lambda e,**d:events.append((e,d)))
    assert calls[-2:]==['SET SESSION FOREIGN_KEY_CHECKS=1','COMMIT']
    assert [e for e,d in events]==['DROP_INTENT','TABLE_DROPPED','DROP_INTENT']


def test_source_drift_after_backup_stops_before_moves_and_drops(setup,monkeypatch):
    service,_,roots,backups=setup
    plan=service.preview(role='admin');create=backups.create
    def changing(bp,**kwargs):
        result=create(bp,**kwargs)
        if bp['segment']=='FNO':(roots['FNO']/'one.parquet').write_bytes(b'changed content')
        return result
    monkeypatch.setattr(backups,'create',changing)
    result=apply(service,plan)
    assert result['status']=='RECOVERY_NEEDED' and service.drops==[]
    assert (roots['CASH']/'one.parquet').exists() and (roots['FNO']/'one.parquet').exists()


def test_cli_apply_without_maintenance_flag_never_authenticates(monkeypatch,tmp_path,capsys):
    from controller import reset_cli,workflow_cli
    calls=[]
    monkeypatch.setattr(workflow_cli,'authenticate_admin',lambda:calls.append('auth'))
    assert reset_cli.main(['apply','--plan',str(tmp_path/'not_loaded.json')])==1
    assert calls==[] and '--writers-stopped is required' in capsys.readouterr().out


def test_cli_denied_authentication_never_builds_catalog(monkeypatch,tmp_path):
    from controller import reset_cli,workflow_cli
    from model import database_catalog
    def denied():raise PermissionError('private authentication detail')
    def forbidden():raise AssertionError('Catalog must not load before auth')
    monkeypatch.setattr(workflow_cli,'authenticate_admin',denied)
    monkeypatch.setattr(database_catalog,'configured_catalog',forbidden)
    output=tmp_path/'preview.json'
    assert reset_cli.main(['preview','--output',str(output)])==1
    assert not output.exists()


def test_locked_fno_file_stops_before_any_sql_drop(setup,monkeypatch):
    import os
    service,engines,roots,_=setup
    plan=service.preview(role='admin');replace=os.replace
    def locked(source,destination):
        if Path(source)==roots['FNO']/'one.parquet':raise PermissionError('File is in use')
        return replace(source,destination)
    monkeypatch.setattr('model.reset_service.os.replace',locked)
    result=apply(service,plan)
    assert result['status']=='RECOVERY_NEEDED' and service.drops==[]
    assert result['completed']==['CASH:FILES_ARCHIVED']
    for s in SEGMENTS:
        with engines[s].connect() as c:assert c.execute(text('SELECT COUNT(*) FROM sample')).scalar()==1
    assert (roots['FNO']/'one.parquet').exists()


def test_cross_database_references_block_before_backup_or_reset(setup,monkeypatch):
    service,_,_,backups=setup
    def external(segment):raise ValueError('Cross-database foreign keys require DBA review')
    monkeypatch.setattr(service,'_check_external_references',external)
    with pytest.raises(ValueError,match='Cross-database'):service.preview(role='admin')
    assert not backups.calls and not service.journal_root.exists()
