"""UI regression tests for persisted jobs rather than the retired in-memory tabs."""
import sys
import types
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).parent))
from test_dashboard_layer import _authed_apptest


def fake_pipeline(monkeypatch):
    import ui.pipeline_page as page
    from model.config.instrument_loader import load_instrument_registry
    from model.config.timeframe_settings import load_timeframe_settings
    job={'id':7,'job_type':'SMART_FETCH','state':'RUNNING','started_at':'2026-10-19','heartbeat_at':'2026-10-19',
         'rows_stored':50,'error':None,'params':{},'result':{'done':1,'total':4,'current':'SBIN'}}
    service=SimpleNamespace(instruments=load_instrument_registry(),timeframes=load_timeframe_settings(),engine=object(),
        store=SimpleNamespace(list=lambda **_: [job]))
    monkeypatch.setattr(page,'get_service',lambda:service);monkeypatch.setattr(page,'ready',lambda _:True)
    return service


def test_historical_page_sections_render(monkeypatch):
    fake_pipeline(monkeypatch)
    at=_authed_apptest('ui/views/historical_cash.py','admin',monkeypatch)
    assert not at.exception
    assert at.title[0].value=='Historical Smart Fetch'
    assert any(b.label=='Preview missing ranges' for b in at.button)


def test_aggregation_page_renders(monkeypatch):
    fake_pipeline(monkeypatch)
    at=_authed_apptest('ui/views/aggregation_cash.py','admin',monkeypatch)
    assert not at.exception and at.title[0].value=='Aggregation'
    assert any(x.label=='Target timeframes' for x in at.multiselect)


def test_admin_page_renders(monkeypatch):
    at=_authed_apptest('ui/views/configuration.py','admin',monkeypatch)
    assert not at.exception


def test_background_jobs_panel_shows_a_running_job(monkeypatch):
    fake_pipeline(monkeypatch)
    at=_authed_apptest('ui/views/historical_cash.py','admin',monkeypatch)
    assert not at.exception
    assert len(at.get('progress'))==1
    assert any(b.label=='Cancel job' for b in at.button)
    at=_authed_apptest('ui/views/historical_cash.py','user',monkeypatch)
    assert not any(b.label in ('Cancel job','Start job') for b in at.button)


def _fake_config(monkeypatch, mysql_enabled=False):
    """Real settings/instrument files, fake env (no .env / DB / FYERS needed)."""
    import ui.engine_bootstrap as eb
    from model.config.data_settings import load_data_settings
    from model.config.timeframe_settings import load_timeframe_settings
    from model.config.instrument_loader import load_instrument_registry
    ds = load_data_settings()
    import dataclasses
    ds = dataclasses.replace(ds, storage=dataclasses.replace(ds.storage, mysql_enabled=mysql_enabled))  # settings are frozen
    env = types.SimpleNamespace(db=types.SimpleNamespace(host="127.0.0.1", port=3306, name="x", user="u", password="p"), fyers=None)
    cfg = (env, ds, load_timeframe_settings(), load_instrument_registry())
    monkeypatch.setattr(eb, "load_config", lambda: cfg)
    return cfg


