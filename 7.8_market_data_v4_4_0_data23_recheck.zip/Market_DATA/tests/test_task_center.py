import datetime as dt
from types import SimpleNamespace
from pathlib import Path
import pytest
from sqlalchemy import create_engine,MetaData,Table,Column,Integer,String,DateTime,Boolean
from model.database_catalog import DatabaseCatalog
from ui.task_center import activity,local_tasks,snapshot,database_tasks
from ui.task_panel import panel_html
from ui.feature_map import FEATURES,WORKSPACES,FNO_SECTIONS


def test_all_views_have_exact_feature_mapping_and_roles():
    actual={p.stem for p in (Path(__file__).resolve().parents[1]/'ui/views').glob('*.py')}
    assert {f.view for f in FEATURES}==actual
    assert len(FEATURES)==len(actual)
    assert set(f.role for f in FEATURES)=={'user','admin'}
    from ui.fno.page import SECTIONS
    assert set(s for sections in FNO_SECTIONS.values() for s in sections)==set(SECTIONS)
    assert len(WORKSPACES)==9
    assert {f.workspace for f in FEATURES}<=set(WORKSPACES)


def test_multiple_local_tasks_and_failure_cleanup():
    with activity('Backup','CASH'):
        with pytest.raises(RuntimeError):
            with activity('Verification','FNO'):
                assert {r['kind'] for r in local_tasks()}=={'Backup','Verification'}
                raise RuntimeError('private details')
        assert [r['kind'] for r in local_tasks()]==['Backup']
    assert local_tasks()==[]


def catalog_fixture():
    engines={}
    for segment in ('CASH','FNO'):
        engine=create_engine('sqlite://');engines[segment]=engine
        md=MetaData()
        t=Table('ingestion_jobs' if segment=='CASH' else 'fno_ingestion_jobs',md,
          Column('id',Integer,primary_key=True),Column('job_type',String),Column('state',String),
          Column('params',String),Column('error',String),Column('rows_stored',Integer))
        md.create_all(engine)
        with engine.begin() as c:
            c.execute(t.insert(),[{'id':i,'job_type':'WORKFLOW','state':'RUNNING' if i%2 else 'PENDING',
                                 'params':'private-token','error':'private-password','rows_stored':i} for i in range(1,452)])
            c.execute(t.insert(),{'id':999,'job_type':'VERIFY','state':'SUCCESS'})
    return DatabaseCatalog({s:lambda e=e:e for s,e in engines.items()})


def test_all_persisted_and_local_jobs_visible_without_secret_fields():
    cat=catalog_fixture()
    legacy=SimpleNamespace(active=lambda:[{'id':1,'kind':'gapfill','status':'running','done':2,'total':8}])
    live=SimpleNamespace(state=SimpleNamespace(running=True,started_at='now'))
    with activity('Backup','CASH'):
        data=snapshot(cat,legacy,live,SimpleNamespace(running=True))
    assert len(data['tasks'])==906  # 902 queue rows + local backup, gapfill, live, scheduler
    assert len({r['key'] for r in data['tasks']})==906
    assert len([r for r in data['tasks'] if r.get('id')==1])==3
    assert all(r['status']=='AVAILABLE' for r in data['sources'])
    html=panel_html(data)
    assert html.count('class="task-card"')==906
    assert 'private-token' not in html and 'private-password' not in html


def test_source_failure_does_not_become_zero_tasks_and_html_is_escaped():
    class Unavailable:
        def table(self,*args):raise RuntimeError('private-db-password')
    with activity('<script>alert(1)</script>'):
        data=snapshot(Unavailable(),SimpleNamespace(active=lambda:[]),
                      SimpleNamespace(state=SimpleNamespace(running=False)),SimpleNamespace(running=False))
    html=panel_html(data)
    assert 'UNAVAILABLE' in str(data['sources'])
    assert 'Task list may be incomplete' in html
    assert '<script>' not in html and '&lt;script&gt;' in html
    assert 'private-db-password' not in html
