"""Real Streamlit rerun/widget tests with an isolated service double."""
import copy
import datetime as dt
import pytest
from streamlit.testing.v1 import AppTest
from controller.unified_workflow import fingerprint


class FakeService:
    def __init__(self):self.calls=[];self.jobs={};self.fail_preview=False;self.fail_submit=False;self.fail_after_create=False
    def options(self,segment,*,role):
        self.calls.append(('options',segment))
        return {'symbols':['SBIN','HDFCBANK'],'underlyings':['NIFTY'],'expiries_ahead':1,
                'strike_window':1,'include_futures':True,'include_options':False}
    def preview(self,segment,params,tfs,*,role):
        self.calls.append(('preview',segment,copy.deepcopy(params)))
        if self.fail_preview:raise ValueError('Resolve preview findings')
        target={'internal_name':'SBIN','symbol':'NSE:SBIN-EQ'} if segment=='CASH' else {'contract_id':7,'symbol':'NSE:TEST-OPT'}
        p={**params,'workflow':{'targets':[target],'timeframes':tfs,'from':params['from'],'to':params['to']}}
        plan={'segment':segment,'params':p,'fetch_plan':{'requests':1},'stages':['FETCH','VERIFY','READY']}
        plan['token']=fingerprint(plan);return plan
    def submit(self,plan,*,role):
        self.calls.append(('submit',plan['segment']))
        if self.fail_submit:raise RuntimeError('private provider secret')
        self.jobs[42]={'id':42,'job_type':'WORKFLOW','state':'PENDING'}
        if self.fail_after_create:raise RuntimeError('private database response lost')
        return {'segment':plan['segment'],'job_id':42}
    def list_jobs(self,segment,**kwargs):
        self.calls.append(('list',segment));return {'data':[{'id':k,'state':v['state']} for k,v in self.jobs.items()],'has_more':False}
    def get_job(self,segment,jid,**kwargs):
        self.calls.append(('get',segment,jid))
        if jid not in self.jobs:raise ValueError('Workflow job not found')
        return copy.deepcopy(self.jobs[jid])
    def action(self,segment,action,jid,*,role):
        self.calls.append(('action',action,jid))
        new=None
        if action=='resume':new=43;self.jobs[new]={'id':new,'job_type':'WORKFLOW','state':'PENDING'}
        if action=='cancel':self.jobs[jid]['state']='CANCELLED'
        return {'segment':segment,'new_job_id':new}


ui_service=None


@pytest.fixture
def app():
    global ui_service
    ui_service=FakeService()
    source="from test_workflow_dashboard import ui_service\nfrom ui.workflow_page import render_page\nrender_page(ui_service,'admin')"
    return AppTest.from_string(source,default_timeout=15).run()


def preview(app):
    app.multiselect(key='wf_symbols').set_value(['SBIN']).run()
    app.button(key='wf_preview').click().run()
    assert not app.exception


def test_readonly_render_and_preview_confirmation_then_monitor(app):
    assert not app.exception and not any(c[0]=='submit' for c in ui_service.calls)
    preview(app)
    assert app.button(key='wf_submit').disabled
    confirm=next(c for c in app.checkbox if c.key.startswith('wf_confirm_'))
    confirm.check().run()
    app.button(key='wf_submit').click().run()
    assert not app.exception
    assert app.radio(key='wf_mode').value=='Monitor jobs'
    assert app.number_input(key='wf_job_CASH').value==42
    assert len([c for c in ui_service.calls if c[0]=='submit'])==1
    app.button(key='wf_refresh').click().run()
    assert not any(c[0]=='action' for c in ui_service.calls)
    assert len([c for c in ui_service.calls if c[0]=='submit'])==1


def test_changed_scope_invalidates_old_preview(app):
    preview(app)
    app.multiselect(key='wf_symbols').set_value(['HDFCBANK']).run()
    assert not any(b.key=='wf_submit' for b in app.button)
    assert not any(c[0]=='submit' for c in ui_service.calls)


def test_submit_failure_consumes_review_without_exposing_secret(app):
    preview(app);ui_service.fail_submit=True
    next(c for c in app.checkbox if c.key.startswith('wf_confirm_')).check().run()
    app.button(key='wf_submit').click().run()
    assert not app.exception and 'private' not in str([e.value for e in app.error])
    assert any('check the persisted queue before submitting again' in e.value for e in app.error)
    app.run()
    assert not any(b.key=='wf_submit' for b in app.button)


def test_failed_preview_does_not_retain_previous_plan(app):
    preview(app);ui_service.fail_preview=True
    app.button(key='wf_preview').click().run()
    app.run()
    assert not any(b.key=='wf_submit' for b in app.button)


def test_resume_focuses_new_job_after_full_rerun(app):
    ui_service.jobs[42]={'id':42,'job_type':'WORKFLOW','state':'PARTIAL','workflow':{'stage':'BLOCKED','ready':False}}
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert app.button(key='wf_action_apply_CASH_42').disabled
    app.checkbox(key='wf_action_confirm_CASH_42_PARTIAL_resume').check().run()
    app.button(key='wf_action_apply_CASH_42').click().run()
    assert not app.exception
    assert app.number_input(key='wf_job_CASH').value==43
    assert ('action','resume',42) in ui_service.calls


def test_ready_timestamp_and_terminal_no_retry_controls(app):
    ui_service.jobs[42]={'id':42,'job_type':'WORKFLOW','state':'SUCCESS','workflow':{
        'stage':'READY','ready':True,'verified_at':'2026-10-25T15:00:00+05:30','completed_checks':1,'total_checks':1,'verified_rows':375}}
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert any('2026-10-25T15:00' in s.value for s in app.success)
    assert not any(b.key and b.key.startswith('wf_action_apply') for b in app.button)


def test_fno_preview_controls_and_scope(app):
    app.selectbox(key='wf_segment').set_value('FNO').run()
    app.multiselect(key='wf_underlyings').set_value(['NIFTY']).run()
    app.button(key='wf_preview').click().run()
    assert not app.exception
    call=next(c for c in ui_service.calls if c[0]=='preview')
    assert call[1]=='FNO' and call[2]['include_futures'] is True and call[2]['include_options'] is False


def test_user_role_cannot_load_service_or_actions():
    global ui_service
    ui_service=FakeService()
    app=AppTest.from_string("from test_workflow_dashboard import ui_service\nfrom ui.workflow_page import render_page\nrender_page(ui_service,'user')").run()
    assert not app.exception and ui_service.calls==[]


def test_preview_explains_missing_selection_and_invalid_dates(app):
    assert app.button(key='wf_preview').disabled
    assert any('Select at least one Cash instrument' in item.value for item in app.info)
    app.multiselect(key='wf_symbols').set_value(['SBIN']).run()
    end=app.date_input(key='wf_to').value
    app.date_input(key='wf_from').set_value(end-dt.timedelta(days=31)).run()
    assert app.button(key='wf_preview').disabled
    assert any('at most 31 days' in item.value for item in app.warning)
    app.date_input(key='wf_from').set_value(end-dt.timedelta(days=30)).run()
    assert not app.button(key='wf_preview').disabled
    app.date_input(key='wf_to').set_value(end-dt.timedelta(days=31)).run()
    assert app.button(key='wf_preview').disabled
    assert any('on or before' in item.value for item in app.warning)
    assert not any(c[0]=='preview' for c in ui_service.calls)


def test_fno_requires_contract_type_and_explains_disabled_preview(app):
    app.selectbox(key='wf_segment').set_value('FNO').run()
    app.multiselect(key='wf_underlyings').set_value(['NIFTY']).run()
    app.checkbox(key='wf_futures').uncheck().run()
    assert app.button(key='wf_preview').disabled
    assert any('include futures or options' in item.value for item in app.info)
    assert not any(c[0]=='preview' for c in ui_service.calls)


@pytest.mark.parametrize('state,kind,message',[
    ('PENDING','info','Queued.'),
    ('RUNNING','info','In progress.'),
    ('PARTIAL','warning','Workflow incomplete.'),
    ('FAILED','error','Workflow failed.'),
    ('INTERRUPTED','error','Workflow interrupted.'),
    ('NO_DATA','info','No usable verified rows'),
    ('CANCELLED','info','Completed work may remain stored'),
    ('SUCCESS','warning','Not ready for complete verified consumption'),
])
def test_monitor_explains_state_without_automatic_actions(app,state,kind,message):
    ui_service.jobs[42]={'id':42,'job_type':'WORKFLOW','state':state,'workflow':{'ready':False}}
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert any(message in item.value for item in app.get(kind))
    assert not any(c[0] in ('submit','action') for c in ui_service.calls)


def test_running_job_cannot_display_ready_success(app):
    ui_service.jobs[42]={'id':42,'job_type':'WORKFLOW','state':'RUNNING','workflow':{'ready':True}}
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert not any('READY at' in item.value for item in app.success)
    assert any('persisted job state is SUCCESS' in item.value for item in app.warning)


@pytest.mark.parametrize('reason,message',[
    ('DATA_NOT_VERIFIED','Stored data did not satisfy strict verification'),
    ('VERIFICATION_UNAVAILABLE','Check database and Parquet availability'),
])
def test_blocked_readiness_has_actionable_guidance(app,reason,message):
    ui_service.jobs[42]={'id':42,'job_type':'WORKFLOW','state':'PARTIAL',
                         'workflow':{'ready':False,'reason':reason}}
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert any(message in item.value for item in app.warning)
    assert not any(c[0] in ('submit','action') for c in ui_service.calls)


def test_uncertain_submission_can_be_found_without_repeating_dispatch(app):
    preview(app); ui_service.fail_after_create=True
    next(c for c in app.checkbox if c.key.startswith('wf_confirm_')).check().run()
    app.button(key='wf_submit').click().run()
    assert not app.exception
    assert 42 in ui_service.jobs
    assert any('Submission could not be confirmed' in e.value for e in app.error)
    assert not any(b.key=='wf_submit' for b in app.button)
    app.radio(key='wf_mode').set_value('Monitor jobs').run()
    assert not app.exception
    assert app.number_input(key='wf_job_CASH').value==42
    assert len([c for c in ui_service.calls if c[0]=='submit'])==1
    assert not any(c[0]=='action' for c in ui_service.calls)
