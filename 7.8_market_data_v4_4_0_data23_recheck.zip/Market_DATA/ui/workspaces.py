"""New workspace composition; guarded domain tools retain their public services."""
from pathlib import Path
import runpy
import streamlit as st
from ui.feature_map import features, FNO_SECTIONS
from ui.task_panel import tracked_spinner

VIEWS=Path(__file__).resolve().parent/'views'


def _open_view(view):
    from ui.feature_map import FEATURES
    if view not in {f.view for f in FEATURES}:raise ValueError('Unknown UI tool')
    runpy.run_path(str(VIEWS/(view+'.py')),run_name='__main__')


def _fno(section):
    from ui.fno import page as f
    with tracked_spinner('Loading FNO '+section):service=f.get_service()
    if not service.schema_ready():
        st.warning('FNO schema unavailable. Review migrations before applying changes.')
        f.migration_ui(service);return
    handlers={'Overview':f.overview,'Historical Fetch':f.historical,'Aggregation':f.aggregation,
              'Live Data':f.live,'Option Chain':f.option_chain,'Futures':lambda s:f.contracts(s,'FUTURES'),
              'Options Contracts':lambda s:f.contracts(s,'OPTIONS'),'Data Quality':f.quality,
              'Jobs and Logs':f.jobs,'Checkpoints':f.checkpoints,'Storage Manager':f.storage,'Settings':f.settings}
    handlers[section](service)


def overview():
    st.markdown('### Your market data workspace')
    st.write('Select a workspace in the sidebar. CASH and FNO retain separate databases, storage and quality rules.')
    cols=st.columns(3)
    for col,title,body in zip(cols,('Collect','Inspect','Maintain'),(
        'Historical Data → preview targets and requests before a reviewed run. Live Market → explicit start and stop.',
        'Data Explorer → stored candles and verified reads. Coverage & Quality → scoped findings and parity.',
        'Jobs → explicit progress and resume. Storage & Recovery → reviewed backup, schema and cleanup operations.')):
        with col:
            with st.container(border=True):st.subheader(title);st.write(body)
    st.info('The task center stays at the top right across workspaces. Every observed active job is listed; scroll for additional tasks.')
    st.caption('A READY job is historical evidence. Use verified reads to recheck current SQL/Parquet data.')


def candle_reader(role):
    import datetime as dt
    import json
    from model.config.market_calendar import IST
    from model.read_contracts import TIMEFRAMES
    from model.database_catalog import configured_catalog
    from model.market_read_service import MarketReadService
    st.subheader('Stored candle reader')
    c=st.columns(3)
    segment=c[0].selectbox('Segment',['CASH','FNO'],key='reader_segment')
    symbol=c[1].text_input('Exact FYERS symbol',key='reader_symbol')
    timeframe=c[2].selectbox('Timeframe',TIMEFRAMES,key='reader_tf')
    yesterday=dt.datetime.now(IST).date()-dt.timedelta(days=1)
    c=st.columns(2)
    start=c[0].date_input('From (IST)',yesterday,key='reader_from')
    end=c[1].date_input('To (IST)',yesterday,key='reader_to')
    quality=st.radio('Quality',['verified','raw'],horizontal=True,key='reader_quality')
    session=st.selectbox('Session',['all','regular'] if segment=='CASH' else ['all'],key='reader_session_'+segment)
    st.caption('One bounded page per explicit request. Verified ranges are limited to 31 days; raw results do not certify quality.')
    scope=[segment,symbol,timeframe,str(start),str(end),quality,session]
    saved=st.session_state.get('reader_page')
    if saved and saved['scope']!=scope:st.session_state.pop('reader_page',None);saved=None
    c=st.columns(2)
    first=c[0].button('Load first page',disabled=not symbol.strip(),key='reader_load')
    more=c[1].button('Load next page',disabled=not(saved and saved['page']['meta']['next_cursor']),key='reader_next')
    if first or more:
        cursor=saved['page']['meta']['next_cursor'] if more else None
        st.session_state.pop('reader_page',None)
        with tracked_spinner('Reading '+segment+' stored candles'):
            page=MarketReadService(configured_catalog()).get_candles(segment,symbol.strip(),timeframe,start,end,
                quality=quality,session=session,cursor=cursor,limit=200)
        saved={'scope':scope,'page':page};st.session_state['reader_page']=saved
        st.rerun()
    if saved:
        page=saved['page'];st.write('Quality:',page['quality']);st.dataframe(page['data'],hide_index=True,width='stretch')
        st.download_button('Export displayed page JSON',json.dumps(page,default=str,indent=2),'candle_page.json','application/json')
        st.caption(str(page['meta']['returned'])+' rows on this page. Pagination is a live view, not a snapshot.')


def render(workspace,role):
    # Gate before loading any view, configuration, or service.
    from ui.auth import require_auth
    if not require_auth('user'):st.stop()
    st.title(workspace)
    st.caption('TIOS / MARKET DATA  ·  CASH + FNO  ·  IST')
    if workspace=='Overview':
        overview()
        if st.checkbox('Load system health and Cash summary',key='overview_cash'):
            _open_view('overview_health')
        if st.checkbox('Load FNO summary',key='overview_fno'):
            try:_fno('Overview')
            except Exception as exc:st.warning('FNO summary unavailable ('+type(exc).__name__+').')
        return
    entries=features(workspace,role)
    choices={f.title:('view',f) for f in entries}
    if workspace=='Data Explorer':choices={'Verified / raw candle reader':('reader',None),**choices}
    for section in FNO_SECTIONS.get(workspace,()):choices['FNO · '+section]=('fno',section)
    if not choices:st.info('No tools are available for this role.');return
    selected=st.selectbox('Tool',list(choices),key='workspace_tool_'+workspace)
    kind,value=choices[selected]
    try:
        if kind=='reader':candle_reader(role)
        elif kind=='fno':_fno(value)
        else:
            if value.role=='admin' and role!='admin':st.error('Administrator access required');return
            selection=(workspace,selected)
            if value.view=='workflow' and st.session_state.get('_workspace_selection')!=selection:
                st.session_state['wf_mode']='Monitor jobs' if workspace=='Jobs' else 'New workflow'
            st.session_state['_workspace_selection']=selection
            _open_view(value.view)
    except Exception as exc:
        st.error('Tool unavailable ('+type(exc).__name__+'). Check configuration and persisted status before retrying.')


def page(workspace,role):
    def open_workspace():render(workspace,role)
    open_workspace.__name__='workspace_'+workspace.lower().replace(' ','_').replace('&','and')
    return open_workspace
