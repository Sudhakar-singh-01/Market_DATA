"""Authoritative UI routing inventory; imports no database/provider services."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Feature:
    title: str
    workspace: str
    view: str
    role: str = 'user'

FEATURES = (
    Feature("System health, Cash counts and verification evidence","Overview","overview_health"),
    Feature('Cash live feed','Live Market','live_market'),
    Feature('SQL tables and candle export','Data Explorer','database_explorer'),
    Feature('Cash Smart Fetch and gap fill','Historical Data','historical_cash'),
    Feature('Cash aggregation','Historical Data','aggregation_cash'),
    Feature('Pipeline diagram','Settings & Diagnostics','data_flow'),
    Feature('Cash verification and telemetry','Coverage & Quality','quality_cash'),
    Feature('Storage files and retention','Storage & Recovery','storage_browser'),
    Feature('Application logs','Settings & Diagnostics','logs'),
    Feature('Python API inspector','Settings & Diagnostics','api_monitor'),
    Feature('Cash coverage and gap preview','Coverage & Quality','coverage_cash'),
    Feature('Instruments, timeframes and calendar','Instruments','master_tables'),
    Feature('Configuration and advanced CRUD','Settings & Diagnostics','configuration','admin'),
    Feature('Database administration','Storage & Recovery','database_admin','admin'),
    Feature('Approved file browser','Storage & Recovery','files_admin','admin'),
    Feature('Cash ingestion jobs','Jobs','jobs_cash','admin'),
    Feature('Cash checkpoints','Jobs','checkpoints_cash','admin'),
    Feature('Bulk deletion','Storage & Recovery','bulk_delete','admin'),
    Feature('Operations controls','Jobs','operations','admin'),
    Feature('Audit history','Settings & Diagnostics','audit_log','admin'),
    Feature('Security information','Settings & Diagnostics','security','admin'),
    Feature('Validation and cleanup tools','Storage & Recovery','data_operations','admin'),
    Feature('All databases and tables','Storage & Recovery','database_catalog','admin'),
    Feature('Schema preview and migrations','Storage & Recovery','schema_manager','admin'),
    Feature('FNO overview, contracts, chain, history, live, aggregation, storage, checkpoints, jobs, quality and settings','Data Explorer','fno_management'),
    Feature('Backup, checksum and recovery staging','Storage & Recovery','backup_recovery','admin'),
    Feature('Reviewed unified workflow','Historical Data','workflow','admin'),
    Feature('Scoped cleanup and recovery journal','Storage & Recovery','scoped_cleanup','admin'),
    Feature('Isolated recovery verification','Storage & Recovery','recovery_verification','admin'),
)
WORKSPACES = ('Overview','Historical Data','Live Market','Data Explorer',
              'Coverage & Quality','Jobs','Instruments','Storage & Recovery','Settings & Diagnostics')
# FNO subsections route to their existing guarded rendering functions.
FNO_SECTIONS = {
 'Overview': ('Overview',), 'Historical Data': ('Historical Fetch','Aggregation'),
 'Live Market': ('Live Data','Option Chain'), 'Data Explorer': ('Futures','Options Contracts','Option Chain'),
 'Coverage & Quality': ('Data Quality',), 'Jobs': ('Jobs and Logs','Checkpoints'),
 'Instruments': ('Futures','Options Contracts'), 'Storage & Recovery': ('Storage Manager',),
 'Settings & Diagnostics': ('Settings',),
}

def features(workspace,role):
    result=[f for f in FEATURES if f.workspace==workspace and (f.role=='user' or role=='admin')]
    if workspace=='Historical Data':result.sort(key=lambda f:f.view!='workflow')
    if workspace=='Jobs' and role=='admin':
        from dataclasses import replace
        workflow=next(f for f in FEATURES if f.view=='workflow')
        result.insert(0,replace(workflow,title='Unified workflow monitoring',workspace='Jobs'))
    return result
