"""
ui/views/files_admin.py
Admin-only, read-only project File Explorer (spec Section 12/34).
Restricted to approved directories via ui/file_explorer.py -- no
arbitrary OS filesystem access, no execution.
"""

import sys
import datetime
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.file_explorer import list_allowed_roots, list_dir, read_text_preview

st.set_page_config(page_title="Admin: Files - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()


st.title("Admin: File Explorer")
st.caption("Read-only. Restricted to approved project directories -- no arbitrary filesystem access, no execution.")

root = st.selectbox("Directory", list_allowed_roots())
subpath = st.text_input("Subpath (optional, e.g. 'processing/validator.py' or a subfolder)", value="")
relative_path = f"{root}/{subpath}".rstrip("/") if subpath else root

entries = list_dir(relative_path)
if entries is None:
    st.error("Path not found or not allowed.")
else:
    st.dataframe([{
        "name": e["name"], "type": e["type"],
        "size_bytes": e["size_bytes"],
        "modified": datetime.datetime.fromtimestamp(e["modified"]).strftime("%Y-%m-%d %H:%M:%S"),
        "path": e["path"],
    } for e in entries], width="stretch")

    file_entries = [e for e in entries if e["type"] != "folder"]
    if file_entries:
        selected = st.selectbox("Preview a file", [e["path"] for e in file_entries])
        content = read_text_preview(selected)
        if content is None:
            st.info("This file type isn't previewable as text (binary, or not a recognized text extension).")
        else:
            st.code(content, language=Path(selected).suffix.lstrip(".") or "text")
