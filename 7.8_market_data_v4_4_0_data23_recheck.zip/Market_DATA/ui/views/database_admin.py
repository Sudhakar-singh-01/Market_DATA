"""
ui/views/database_admin.py
Admin-nav entry for database inspection (spec Section 34 lists
"Database" under ADMIN nav). The full browse/search/filter/export
experience already lives in the Data Explorer page (available to both
roles per spec Section 11) -- this page is deliberately NOT a
duplicate implementation, just an admin-focused quick summary plus a
pointer to Data Explorer for full browsing.
"""

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.data_access import KNOWN_TABLES
from ui.table_inspector import table_summary

st.set_page_config(page_title="Admin: Database - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Database")
st.caption("For full browse/search/filter/sort/export, use the Data Explorer page (same underlying data).")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)
for table in KNOWN_TABLES:
    summary = table_summary(engine, table)
    with st.container(border=True):
        st.subheader(table)
        cols = st.columns(4)
        cols[0].metric("Rows", f"{summary['row_count']:,}")
        cols[1].metric("Approx. size (MB)", summary["approx_size_mb"])
        cols[2].metric("Oldest", str(summary["oldest_record"]))
        cols[3].metric("Newest", str(summary["newest_record"]))
