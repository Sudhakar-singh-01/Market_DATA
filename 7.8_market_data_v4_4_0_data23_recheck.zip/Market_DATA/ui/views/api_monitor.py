"""
ui/views/api_monitor.py
API Monitor + Request/Response Inspector (spec Sections 17-18) for this
project's REAL read API: model/repository.py -> MarketDataRepository.

Methods are discovered by introspection (public get_*/list_*/has_* only --
read-only by construction), so newly added getters appear automatically and
no endpoint names are invented. These are in-process Python calls, not HTTP,
so "Headers"/HTTP status are shown as N/A, with OK/ERROR as the status.
"""

import dataclasses
import datetime
import inspect
import json
import sys
import time
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_repository
from ui.date_inputs import date_field
from ui import api_metrics
from model.repository import MarketDataRepository

st.set_page_config(page_title="API Monitor - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()
repo = get_repository()

_CATEGORY = {"list_instruments": "Instruments", "get_candles": "Candles", "get_candles_df": "Candles",
             "get_candles_multi": "Candles", "get_latest_candle": "Latest Data", "has_storage_backend": "Health"}
_MAX_ROWS_SHOWN = 500


def discover_methods() -> dict:
    found = {}
    for name, fn in inspect.getmembers(MarketDataRepository, inspect.isfunction):
        if name.startswith(("get_", "list_", "has_")):  # read-only methods only
            found[name] = fn
    return found


def signature_rows(fn) -> list:
    rows = []
    for pname, p in inspect.signature(fn).parameters.items():
        if pname == "self":
            continue
        rows.append({
            "name": pname,
            "type": getattr(p.annotation, "__name__", str(p.annotation)) if p.annotation is not inspect._empty else "-",
            "required": p.default is inspect._empty,
            "default": "-" if p.default is inspect._empty else repr(p.default),
        })
    return rows


def to_jsonable(obj):
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {k: to_jsonable(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, pd.DataFrame):
        return to_jsonable(obj.reset_index().to_dict("records"))
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, (datetime.datetime, datetime.date, pd.Timestamp)):
        return obj.isoformat()
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    return str(obj)


def count_records(result) -> int:
    if result is None:
        return 0
    if isinstance(result, (list, tuple, pd.DataFrame)):
        return len(result)
    if isinstance(result, dict):
        return sum(len(v) if isinstance(v, (list, tuple)) else 1 for v in result.values())
    return 1


def default_kwargs_for(fn, instruments, timeframe_settings) -> dict:
    """Sensible default arguments so every discovered method can be
    called with one click for a quick 'what does this return' preview
    -- without the person manually filling in the Inspector tab for
    each method one at a time."""
    names = [i.internal_name for i in instruments.all_instruments()]
    first_name = names[0] if names else None
    week_ago = str(datetime.date.today() - datetime.timedelta(days=7))
    today = str(datetime.date.today())
    kwargs = {}
    for p in signature_rows(fn):
        n = p["name"]
        if n == "internal_name":
            kwargs[n] = first_name
        elif n == "internal_names":
            kwargs[n] = names[:2]
        elif n == "timeframe":
            kwargs[n] = "1m"
        elif n == "from_date":
            kwargs[n] = week_ago
        elif n == "to_date":
            kwargs[n] = today
        elif n == "active_only":
            kwargs[n] = False
        elif not p["required"]:
            continue  # leave optional params at their own default
        else:
            kwargs[n] = None
    return kwargs


def as_table(payload):
    if isinstance(payload, list) and payload and isinstance(payload[0], dict):
        return pd.DataFrame(payload)
    if isinstance(payload, dict) and payload and all(isinstance(v, list) for v in payload.values()):
        frames = [pd.DataFrame(v).assign(instrument=k) for k, v in payload.items() if v]
        return pd.concat(frames, ignore_index=True) if frames else None
    if isinstance(payload, dict):
        return pd.DataFrame([payload])
    return None


methods = discover_methods()
backend_ok = repo.has_storage_backend()
stats = api_metrics.snapshot()

st.title("API Monitor")
st.caption("Your project's read API: `MarketDataRepository` in model/repository.py -- the one interface other "
           "modules use to read market data. Read-only methods (get_*/list_*/has_*) are discovered automatically.")

tab_endpoints, tab_inspector = st.tabs(["Endpoints", "Request / Response Inspector"])

with tab_endpoints:
    rows = []
    for name, fn in methods.items():
        s = stats.get(name)
        doc = (inspect.getdoc(fn) or "").strip().split("\n\n")[0].replace("\n", " ")
        sig = ", ".join(f"{r['name']}: {r['type']}" + ("" if r["required"] else f" = {r['default']}") for r in signature_rows(fn))
        rows.append({
            "Category": _CATEGORY.get(name, "Other"),
            "Method": "GET",
            "Endpoint": f"MarketDataRepository.{name}",
            "Parameters": sig or "-",
            "Status": "AVAILABLE" if backend_ok or name in ("list_instruments", "has_storage_backend") else "NO STORAGE BACKEND",
            "Requests": s["count"] if s else 0,
            "Errors": s["errors"] if s else 0,
            "Avg response (ms)": round(s["total_ms"] / s["count"], 1) if s and s["count"] else None,
            "Records returned": s["records"] if s else 0,
            "Last request": s["last_request"].strftime("%Y-%m-%d %H:%M:%S") if s and s["last_request"] else "-",
            "Description": doc,
        })
    df = pd.DataFrame(rows).sort_values(["Category", "Endpoint"])
    st.dataframe(df, width="stretch", hide_index=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Endpoints discovered", len(methods))
    c2.metric("Requests via this page (since app start)", api_metrics.total_requests())
    c3.metric("Storage backend", "MySQL" if data_settings.storage.mysql_enabled else ("Parquet" if data_settings.storage.parquet_enabled else "NONE"))
    st.info("Request/error/latency counters cover calls made through this page (including Preview all, below) "
            "in this dashboard process. Other modules call the repository from their own processes, and "
            "consumer identity is not tracked, so per-consumer traffic is NOT AVAILABLE -- these are "
            "endpoint-level numbers only.")

    st.divider()
    st.subheader("Preview all -- what each method actually returns")
    st.caption("Calls every discovered method once with sensible defaults (first configured instrument, last 7 days) "
              "so you can see every method's real input/output shape at a glance, instead of checking one at a "
              "time in the Inspector tab below.")
    if st.button("Preview all methods now"):
        for name in sorted(methods):
            fn = methods[name]
            kwargs = default_kwargs_for(fn, instruments, timeframe_settings)
            start = time.perf_counter()
            try:
                result = getattr(repo, name)(**kwargs)
                elapsed_ms = (time.perf_counter() - start) * 1000
                n_records = count_records(result)
                api_metrics.record_call(name, elapsed_ms, True, n_records)
                payload = to_jsonable(result)
                with st.expander(f"✅ {name}({', '.join(f'{k}={v!r}' for k, v in kwargs.items())}) -- {n_records} record(s), {elapsed_ms:.1f} ms"):
                    sample = payload[:5] if isinstance(payload, list) else payload
                    if isinstance(payload, list) and len(payload) > 5:
                        st.caption(f"Showing 5 of {len(payload)} records.")
                    st.code(json.dumps(sample, indent=2, default=str), language="json")
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - start) * 1000
                api_metrics.record_call(name, elapsed_ms, False, None)
                with st.expander(f"❌ {name}(...) -- failed"):
                    st.error(f"{type(exc).__name__}: {exc}")

with tab_inspector:
    chosen = st.selectbox("Endpoint", list(methods.keys()),
                          format_func=lambda n: f"GET  MarketDataRepository.{n}   [{_CATEGORY.get(n, 'Other')}]")
    fn = methods[chosen]
    with st.expander("Method documentation", expanded=False):
        st.code(f"{chosen}{inspect.signature(fn)}", language="python")
        st.text(inspect.getdoc(fn) or "(no docstring)")
    st.dataframe(pd.DataFrame(signature_rows(fn)), width="stretch", hide_index=True)

    names = [i.internal_name for i in instruments.all_instruments()]
    timeframes = ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes]
    week_ago = str(datetime.date.today() - datetime.timedelta(days=7))
    kwargs = {}
    for p in signature_rows(fn):
        n = p["name"]
        if n == "internal_name":
            kwargs[n] = st.selectbox("internal_name", names, key=f"api_{chosen}_{n}")
        elif n == "internal_names":
            kwargs[n] = st.multiselect("internal_names", names, default=names[:2], key=f"api_{chosen}_{n}")
        elif n == "timeframe":
            kwargs[n] = st.selectbox("timeframe", timeframes, key=f"api_{chosen}_{n}")
        elif n == "from_date":
            kwargs[n] = date_field(st, "from_date", default=week_ago, key=f"api_{chosen}_{n}")
        elif n == "to_date":
            kwargs[n] = date_field(st, "to_date", default="today", key=f"api_{chosen}_{n}")
        elif n == "active_only":
            kwargs[n] = st.checkbox("active_only", value=True, key=f"api_{chosen}_{n}")
        else:
            kwargs[n] = st.text_input(n, key=f"api_{chosen}_{n}")

    if st.button("Send request", type="primary"):
        requested_at = datetime.datetime.now()
        start = time.perf_counter()
        ok, error, result = True, None, None
        try:
            result = getattr(repo, chosen)(**kwargs)
        except Exception as exc:  # shown to the user; never a raw stack trace
            ok, error = False, f"{type(exc).__name__}: {exc}"
        elapsed_ms = (time.perf_counter() - start) * 1000
        n_records = count_records(result) if ok else None
        api_metrics.record_call(chosen, elapsed_ms, ok, n_records)
        st.session_state["api_last"] = {
            "endpoint": chosen, "params": kwargs, "at": requested_at, "ms": elapsed_ms, "ok": ok, "error": error,
            "records": n_records, "payload": to_jsonable(result) if ok else None,
        }

    last = st.session_state.get("api_last")
    if last:
        st.divider()
        req_col, resp_col = st.columns(2)
        with req_col:
            st.subheader("REQUEST")
            st.write("**Method:** GET (read-only, in-process call)")
            st.write(f"**Endpoint:** `MarketDataRepository.{last['endpoint']}`")
            st.write(f"**Timestamp:** {last['at'].strftime('%Y-%m-%d %H:%M:%S')}")
            st.write("**Headers:** N/A (not an HTTP call)")
            st.json(last["params"])
        with resp_col:
            st.subheader("RESPONSE")
            m1, m2, m3 = st.columns(3)
            m1.metric("Status", "OK" if last["ok"] else "ERROR")
            m2.metric("Response time", f"{last['ms']:.1f} ms")
            m3.metric("Records", last["records"] if last["ok"] else "-")
            if not last["ok"]:
                st.error(last["error"])

        if last["ok"]:
            payload = last["payload"]
            json_tab, table_tab = st.tabs(["JSON view", "Table view"])
            with json_tab:
                shown = payload[:200] if isinstance(payload, list) else payload
                if isinstance(payload, list) and len(payload) > 200:
                    st.caption(f"Showing first 200 of {len(payload)} records.")
                st.code(json.dumps(shown, indent=2, default=str), language="json")
            with table_tab:
                table = as_table(payload)
                if table is None:
                    st.info("This response is a single value, not tabular.")
                else:
                    if len(table) > _MAX_ROWS_SHOWN:
                        st.caption(f"Showing first {_MAX_ROWS_SHOWN} of {len(table)} rows.")
                    st.dataframe(table.head(_MAX_ROWS_SHOWN), width="stretch")
