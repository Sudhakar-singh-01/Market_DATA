"""Explicit repository-owned schema setup with stale-preview protection."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.task_panel import tracked_spinner
from ui.auth import require_auth, current_role, _configured_hash
from ui.password_hashing import verify_password
from model.database_catalog import configured_catalog
from model.schema_management import SchemaManager

st.set_page_config(page_title='Schema Manager · TIOS',layout='wide')
if not require_auth("admin"):
    st.stop()
st.title('Database Schema Manager')
st.caption('Uses the configured existing Cash/FNO databases. Review and apply repository-owned schema definitions explicitly.')
st.warning('Stop ingestion and other schema writers first. MySQL DDL commits implicitly; take and verify a database backup before applying. A journal is not a data backup.')

@st.cache_resource
def manager():
    return SchemaManager(configured_catalog())

try:
    service = manager()
    segments = list(service.catalog.factories)
    if not segments:
        st.info('Configure and create the Cash/FNO databases first.'); st.stop()
    segment = st.selectbox('Segment',segments)
    if st.button('Check schema compatibility (read only)'):
        with tracked_spinner('Checking schema compatibility'):
            st.session_state['schema_compatibility'] = (segment, service.compatibility(segment,role=current_role()))
    checked = st.session_state.get('schema_compatibility')
    if checked and checked[0] == segment:
        report = checked[1]
        st.subheader('Schema compatibility: '+report['status'])
        st.caption('Point-in-time metadata check. A compatible schema does not certify market-data quality or a tested recovery backup.')
        st.json(report)
        st.download_button('Download compatibility report',__import__('json').dumps(report,indent=2),
                           'schema_compatibility.json','application/json')
    operations = ['missing_tables'] + (['cash_pipeline'] if segment == 'CASH' else [])
    operation = st.selectbox('Operation',operations)
    st.caption('missing_tables creates absent owned tables only; existing tables remain unchanged. cash_pipeline adds existing job/report metadata columns and indexes.')
    if st.button('Preview schema changes'):
        with tracked_spinner('Previewing schema changes'):
            st.session_state['schema_plan'] = service.preview(segment,operation,role=current_role())
    plan = st.session_state.get('schema_plan')
    if plan and (plan['segment'],plan['operation']) == (segment,operation):
        st.write({'database':plan['database'],'missing_tables':plan['missing_tables'],'statement_count':len(plan['statements'])})
        st.write('Compatibility: '+plan['compatibility']['status'])
        if plan['blockers']:
            st.error('Apply blocked: incompatible existing schema or duplicate active job keys require review.')
            st.json(plan['blockers'])
        with st.expander('Compatibility details and check limitations'):
            st.json(plan['compatibility'])
        st.code(';\n\n'.join(plan['statements']) or '-- No changes required',language='sql')
        st.download_button('Download schema plan',__import__('json').dumps(plan,indent=2), 'schema_plan.json','application/json')
        if plan['statements'] and plan['can_apply']:
            scope = plan['token'][:16]
            backed_up = st.checkbox('I have verified a database backup and stopped ingestion/schema writers',key='schema_backup_'+scope)
            confirmation = st.text_input('Type APPLY '+plan['database'],key='schema_confirm_'+scope)
            password = st.text_input('Admin password',type='password',key='schema_password_'+scope)
            if st.button('Apply reviewed plan',disabled=not (backed_up and password and confirmation == 'APPLY '+plan['database'])):
                if not verify_password(password,_configured_hash('admin')):
                    st.error('Admin password incorrect. No changes applied.')
                else:
                    try:
                        with tracked_spinner('Applying reviewed schema changes'):
                            result = service.apply(plan,role=current_role(),confirmation=confirmation,backup_acknowledged=backed_up)
                        st.json(result)
                    finally:
                        st.session_state.pop('schema_plan',None)
except (ValueError,PermissionError) as exc:
    st.error(str(exc))
except Exception as exc:
    st.error(f'Schema operation unavailable ({type(exc).__name__}). Inspect local configuration and the operation journal before retrying.')
