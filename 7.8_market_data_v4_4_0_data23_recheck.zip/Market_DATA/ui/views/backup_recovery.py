"""Admin backup and recovery staging; never overwrites a live database."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import streamlit as st
from ui.task_panel import tracked_spinner
from ui.auth import require_auth,current_role,_configured_hash
from ui.password_hashing import verify_password
from model.database_catalog import configured_catalog
from model.backup_service import BackupService

st.set_page_config(page_title='Backup & Recovery · TIOS',layout='wide')
if not require_auth("admin"):
    st.stop()
st.title('Backup & Recovery')
st.caption('Back up SQL schema/data and the configured Parquet root. Recovery staging extracts to a fresh folder; it does not import SQL or overwrite live storage.')
st.info('After a trusted manual import into an isolated recovery database, open Administration → Recovery Verification for SQL and staged-file checks.')

@st.cache_resource
def backup_service():
    return BackupService(configured_catalog())

try:
    service=backup_service()
    create_tab,recovery_tab=st.tabs(['Create backup','Verify & stage recovery'])
    with create_tab:
        segments=list(service.catalog.factories)
        if segments:
            segment=st.selectbox('Segment',segments)
            if st.button('Preview backup'):
                st.session_state['backup_plan']=service.preview(segment,role=current_role())
            plan=st.session_state.get('backup_plan')
            if plan and plan['segment']==segment:
                st.json(plan)
                st.warning('Stop historical/live ingestion, background jobs and other SQL/Parquet/schema writers before continuing. SQL snapshots alone cannot synchronize both stores.')
                stopped=st.checkbox('All writers are stopped and sufficient backup disk space is available')
                if st.button('Create backup',disabled=not stopped):
                    try:
                        with tracked_spinner('Exporting and verifying backup; keep this session open...'):
                            result=service.create(plan,role=current_role(),writers_stopped=stopped)
                        st.json(result)
                        st.success('Checksum-verified backup created. A recovery import test is still required.')
                    finally:
                        st.session_state.pop('backup_plan',None)
        else:
            st.info('Configure the Cash/FNO database connections first.')
    with recovery_tab:
        backups=service.list_backups(role=current_role())
        if backups:
            st.dataframe(backups,hide_index=True,width='stretch')
            ident=st.selectbox('Backup', [b['backup_id'] for b in backups])
            if st.button('Verify backup'):
                with tracked_spinner('Verifying every archive member...'):
                    st.session_state['verified_backup']=service.verify(ident,role=current_role())
            verified=st.session_state.get('verified_backup')
            if verified and verified['backup_id']==ident:
                st.json(verified)
                typed=st.text_input('Type STAGE '+ident)
                password=st.text_input('Admin password',type='password')
                if st.button('Stage recovery in new folder',disabled=not (typed=='STAGE '+ident and password)):
                    if not verify_password(password,_configured_hash('admin')):
                        st.error('Incorrect admin password.')
                    else:
                        with tracked_spinner('Rechecking and extracting recovery copy...'):
                            st.json(service.stage_recovery(verified,role=current_role(),confirmation=typed))
        else:
            st.info('No completed backups found.')
except (ValueError,PermissionError) as exc:
    st.error(str(exc))
except Exception as exc:
    st.error(f'Backup/recovery failed ({type(exc).__name__}). No live restore was performed. Check database connectivity, source files and available disk space.')
