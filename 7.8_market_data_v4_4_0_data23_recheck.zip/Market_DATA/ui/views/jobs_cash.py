"""
ui/views/jobs_cash.py
Ingestion Jobs page (spec Section 16/34, admin nav). Uses the real
ingestion_jobs table/model -- no invented status values.
"""

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.data_access import fetch_table
from ui.table_display import wrapped_dataframe

st.set_page_config(page_title="Admin: Jobs - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Ingestion Jobs")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)
df = fetch_table(engine, "ingestion_jobs", limit=1000)

col1, col2, col3 = st.columns(3)
job_type = col1.selectbox("Job type", ["(all)"] + (sorted(df["job_type"].unique().tolist()) if not df.empty else []))
status = col2.selectbox("Status", ["(all)"] + (sorted(df["status"].unique().tolist()) if not df.empty else []))
symbol = col3.text_input("Symbol contains")

filtered = df
if not df.empty:
    if job_type != "(all)":
        filtered = filtered[filtered["job_type"] == job_type]
    if status != "(all)":
        filtered = filtered[filtered["status"] == status]
    if symbol:
        filtered = filtered[filtered["fyers_symbol"].fillna("").str.contains(symbol, case=False)]

st.caption(f"{len(filtered)} job(s)")
wrapped_dataframe(filtered, wrap_columns=["error_message"])

if not filtered.empty:
    job_id = st.selectbox("View job detail", filtered["id"].tolist())
    job = filtered[filtered["id"] == job_id].iloc[0]
    with st.container(border=True):
        st.subheader(f"Job #{job_id}")
        cols = st.columns(4)
        cols[0].metric("Type", job["job_type"])
        cols[1].metric("Status", job["status"])
        cols[2].metric("Started", str(job["started_at"]))
        duration = None
        if job["finished_at"] and job["started_at"]:
            duration = (job["finished_at"] - job["started_at"]).total_seconds()
        cols[3].metric("Duration (s)", duration if duration is not None else "Running / not finished")
        st.write(f"**Symbol:** {job['fyers_symbol']}  **Timeframe:** {job['timeframe']}  "
                 f"**Range:** {job['from_date']} to {job['to_date']}")
        st.write(f"**Records** -- raw: {job['raw_count']}, valid: {job['valid_count']}, invalid: {job['invalid_count']}")
        if job["error_message"]:
            st.error(job["error_message"])
