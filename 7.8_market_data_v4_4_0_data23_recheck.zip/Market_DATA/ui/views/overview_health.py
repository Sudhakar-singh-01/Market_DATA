"""Overview drawn only from configured sources; failures never become zeros."""
import streamlit as st
from ui.task_panel import tracked_spinner
from ui.auth import require_auth
if not require_auth("user"):st.stop()
from sqlalchemy import text
from ui.quality_page import get_service
from model.quality_store import ready
st.title('TIOS · Market Data')
st.caption('Market coverage, storage and pipeline health · all timestamps in IST')
def system_status():
    """Health badges (from the previous dashboard): cheap local checks run on load; the FYERS API call only on request."""
    from ui.engine_bootstrap import load_config
    from ui.data_access import live_run_manager
    from ui.ux_helpers import cached_health
    st.subheader('System status')
    try:
        env,data_settings,_tf,_instruments=load_config()
        report=cached_health(env,data_settings)
        by_name={c.name:c for c in report.checks}
    except Exception as exc:
        st.info(f'System checks NOT AVAILABLE ({type(exc).__name__}).');return
    cols=st.columns(5)
    def badge(col,label,ok,detail=''):
        col.metric(label,'NOT CHECKED' if ok is None else 'OK' if ok else 'FAIL',help=detail or None)
    checked=st.session_state.get('fyers_health_result')
    badge(cols[0],'FYERS API',checked.ok if checked else None,checked.detail if checked else "Press 'Check FYERS API' (makes one real request)")
    if cols[0].button('Check FYERS API',key='home_check_fyers'):
        from controller.health_controller import check_fyers
        with tracked_spinner('Checking FYERS API'):
            st.session_state['fyers_health_result']=check_fyers(env)
        st.rerun()
    live=live_run_manager.state
    badge(cols[1],'Live engine',live.running,'Live ingestion running' if live.running else 'Not running (see Live Market)')
    for col,key,label in ((cols[2],'MySQL','MySQL'),(cols[3],'Parquet storage','Parquet'),(cols[4],'Disk space','Disk space')):
        if key in by_name:badge(col,label,by_name[key].ok,by_name[key].detail)


try:
    system_status()
    st.divider()
except Exception:
    pass
try:
    with tracked_spinner('Loading current status…'):
        s=get_service()
        counts=s.store.query('SELECT (SELECT COUNT(*) FROM instruments) AS instruments,(SELECT COUNT(*) FROM candles) AS candles') [0]
        latest=s.store.query("SELECT id,state,result,finished_at FROM ingestion_jobs WHERE job_type='VERIFY' AND state IN ('SUCCESS','PARTIAL') ORDER BY id DESC LIMIT 1") if ready(s.engine) else []
    cols=st.columns(4)
    cols[0].metric('Cash instruments',counts['instruments']);cols[1].metric('Stored candles',counts['candles'])
    cols[2].metric('Latest verification',latest[0]['state'] if latest else 'NOT VERIFIED')
    cols[3].metric('Live persistence','NOT VERIFIED')
    a,b=st.columns([2,1])
    with a:
        st.subheader('Recent ingestion')
        rows=s.store.query('SELECT id,job_type,status,started_at,finished_at FROM ingestion_jobs ORDER BY id DESC LIMIT 20')
        if rows:st.dataframe(rows,hide_index=True,width='stretch')
        else:st.info('No ingestion jobs recorded.')
    with b:
        st.subheader('Verification evidence')
        if latest:
            st.write('Run',latest[0]['id']);st.write('As of',str(latest[0]['finished_at']))
            st.json(latest[0]['result'].get('checks',{}))
        else:st.info('Run scoped checks from Market Data → Data Quality & Verification.')
    st.caption('F&O has its existing contract database. Open F&O for its independent counts and results.')
except Exception as exc:
    st.warning(f'Source status NOT AVAILABLE ({type(exc).__name__}). Configure the existing database connection to load this dashboard.')
    st.button('Retry status')
