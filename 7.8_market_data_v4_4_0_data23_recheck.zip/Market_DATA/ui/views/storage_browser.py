"""
ui/views/storage_browser.py
Storage monitoring (spec Section 21): MySQL + Parquet, using the
actual repository/storage implementation and actual configured paths
-- nothing hardcoded.
"""

import sys
from pathlib import Path

import streamlit as st
from sqlalchemy import text

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.data_access import table_row_counts
from ui.ux_helpers import cached_db_size_and_latest_write, cached_row_counts
from model.storage.mysql import build_db_url
from controller.health_controller import check_mysql, check_parquet_writable

st.set_page_config(page_title="Storage - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Storage")

st.subheader("MySQL")
if not data_settings.storage.mysql_enabled:
    st.info("Disabled in config/data_settings.yaml.")
else:
    check = check_mysql(env, data_settings)
    engine = get_mysql_engine_or_none(env, data_settings)
    cols = st.columns(4)
    cols[0].metric("Database", env.db.name)
    cols[1].metric("Connection", "CONNECTED" if check.ok else "ERROR", help=check.detail)
    size_mb, latest_write = cached_db_size_and_latest_write(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
    cols[2].metric("Database size (MB)", size_mb if size_mb is not None else "NOT AVAILABLE")
    cols[3].metric("Latest write", str(latest_write) if latest_write else "NOT AVAILABLE")

    st.caption("Tables")
    st.json(cached_row_counts(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)))

st.divider()
st.subheader("Parquet")
if not data_settings.storage.parquet_enabled:
    st.info("Disabled in config/data_settings.yaml.")
else:
    check = check_parquet_writable(data_settings)
    from model.storage_scope import cash_data_root
    root = cash_data_root()
    file_count = 0
    total_bytes = 0
    latest_mtime = None
    latest_partition = None
    if root.exists():
        for path in root.rglob("*.parquet"):
            file_count += 1
            stat = path.stat()
            total_bytes += stat.st_size
            if latest_mtime is None or stat.st_mtime > latest_mtime:
                latest_mtime = stat.st_mtime
                latest_partition = str(path.relative_to(root))

    cols = st.columns(4)
    cols[0].metric("Status", "WRITABLE" if check.ok else "ERROR", help=check.detail)
    cols[1].metric("File count", file_count)
    cols[2].metric("Total size (MB)", round(total_bytes / (1024 * 1024), 2))
    if latest_mtime:
        import datetime
        cols[3].metric("Latest write", datetime.datetime.fromtimestamp(latest_mtime).strftime("%Y-%m-%d %H:%M:%S"))
    else:
        cols[3].metric("Latest write", "NOT AVAILABLE")
    st.caption(f"Latest partition/file: {latest_partition or 'NOT AVAILABLE'}")
