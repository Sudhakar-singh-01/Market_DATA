"""
ui/views/audit_log.py
Read-only audit log viewer (spec Section 29). Admin-only. Never
displays passwords/tokens/secrets -- callers of record_action() are
responsible for keeping those out in the first place.
"""

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.audit_log import fetch_audit_log, audit_table_exists, ensure_audit_table
from ui.table_display import wrapped_dataframe

st.set_page_config(page_title="Admin: Audit Log - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Audit Log")

if not data_settings.storage.mysql_enabled:
    st.info("MySQL storage is disabled -- audit log requires MySQL and the audit_log table "
            "(see database/schema.sql -- apply it manually if you haven't yet).")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)

if not audit_table_exists(engine):
    st.warning("The `audit_log` table doesn't exist in your database yet, so nothing has been recorded so far.")
    st.caption("One click below creates it (CREATE TABLE IF NOT EXISTS -- safe to repeat). "
               "Or run database/add_audit_log.sql yourself in MySQL.")
    if st.button("Create audit_log table now", type="primary"):
        try:
            ensure_audit_table(engine)
            st.success("audit_log table created. Actions from now on are recorded.")
            st.rerun()
        except Exception as exc:
            st.error(f"Could not create the table (does your MySQL user have CREATE privilege?): {exc}")
    st.stop()

try:
    action_filter = st.selectbox("Action", ["(all)", "LOGIN", "LOGOUT", "BULK_DELETE", "RESET_CHECKPOINT",
                                             "START_HISTORICAL_FETCH", "START_AGGREGATION", "EXPORT", "SYSTEM_OPERATION"])
    limit = st.slider("Rows", 50, 5000, 500, step=50)
    df = fetch_audit_log(engine, limit=limit, action_filter=action_filter)
    st.caption(f"{len(df)} entr(y/ies) shown, newest first.")
    wrapped_dataframe(df, wrap_columns=["parameters", "error_message", "target"])
except Exception as exc:
    st.error(f"Could not read audit_log: {exc}\n\nIf this is a 'table doesn't exist' error, apply the "
             f"audit_log CREATE TABLE statement appended to database/schema.sql.")
