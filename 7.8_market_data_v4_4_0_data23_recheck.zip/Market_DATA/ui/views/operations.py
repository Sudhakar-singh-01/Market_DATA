"""
ui/views/operations.py
Consolidated admin operations (spec Section 28). Every action here
calls an EXISTING backend operation -- nothing simulated. This page is
a shortcut/dashboard over Live/Historical/Aggregation/Checkpoints/
Storage, not a new implementation of any of them.
"""

import sys
from pathlib import Path

import streamlit as st
from ui.task_panel import tracked_spinner

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, build_sink, get_mysql_engine_or_none
from ui.data_access import live_run_manager
from ui.components import instrument_selector
from ui.audit_log import record_action
from model.fyers.auth import get_authenticated_client, FyersAuthError
from controller.live_controller import LiveIngestionController
from controller.health_controller import check_mysql, check_parquet_writable

st.set_page_config(page_title="Admin: Operations Center - Market Data Engine", layout="wide")

if not require_auth("admin"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Admin: Operations Center")

st.subheader("Live Feed")
state = live_run_manager.state
c1, c2, c3 = st.columns(3)
c1.metric("Status", "RUNNING" if state.running else "STOPPED")
op_symbols = instrument_selector(instruments, key_prefix="opscenter_live")


def _start_live(symbols, op_name):
    try:
        client = get_authenticated_client(env.fyers)
        access_token_ws = f"{env.fyers.client_id}:{env.fyers.access_token}"
        sink = build_sink(env, data_settings, instruments)

        def factory():
            return LiveIngestionController(
                access_token_ws=access_token_ws, instruments=instruments, data_settings=data_settings,
                symbol_filter=symbols, sink=sink, historical_client=client,
            )

        live_run_manager.start(factory)
        engine = get_mysql_engine_or_none(env, data_settings)
        if engine is not None:
            record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed",
                          parameters={"op": op_name, "symbols": symbols}, result="success")
        st.success("Live ingestion starting in background.")
    except FyersAuthError as exc:
        st.error(f"Authentication error: {exc}")
    except Exception as exc:
        st.error(f"Could not start live ingestion: {exc}")


def _stop_live(op_name):
    live_run_manager.stop()
    engine = get_mysql_engine_or_none(env, data_settings)
    if engine is not None:
        record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed", parameters={"op": op_name}, result="success")


c1, c2, c3, c4 = st.columns(4)
c1.metric("Status", "RUNNING" if state.running else "STOPPED")
if c2.button("Start", disabled=state.running):
    if not op_symbols:
        st.warning("Select at least one stock or index above.")
    else:
        _start_live(op_symbols, "start")
if c3.button("Stop", disabled=not state.running):
    _stop_live("stop")
    st.rerun()
if c4.button("Restart", disabled=not state.running):
    if not op_symbols:
        st.warning("Select the instruments to run after restart, above.")
    else:
        with tracked_spinner("Stopping current session..."):
            old_thread = state.thread
            _stop_live("restart_stop")
            if old_thread is not None:
                old_thread.join(timeout=15)
        _start_live(op_symbols, "restart_start")
st.caption("Restart = Stop, wait for the old session to finish, then Start with the instruments selected above.")

st.divider()
st.subheader("Database / Storage")
c1, c2 = st.columns(2)
if c1.button("Refresh / Health check DB"):
    check = check_mysql(env, data_settings)
    st.success(check.detail) if check.ok else st.error(check.detail)
if c2.button("Verify Parquet storage"):
    check = check_parquet_writable(data_settings)
    st.success(check.detail) if check.ok else st.error(check.detail)

st.divider()
st.subheader("Historical Fetch / Aggregation / Checkpoints")
st.caption("These run through their dedicated pages (same backend controllers, full forms and confirmations) -- "
           "one form each, so they can't drift out of sync.")
st.markdown(
    "- **Historical Data** (sidebar) -- create a historical fetch job\n"
    "- **Aggregation** (sidebar) -- create an aggregation job\n"
    "- **Admin: Checkpoints** (sidebar) -- sync / reset\n"
    "- **Admin: Bulk Delete** (sidebar) -- preview -> confirm delete\n"
    "- **Admin: Data Operations** (sidebar) -- bulk validation / data cleanup"
)

st.divider()
st.subheader("API")
st.info("The local GET API is started separately with python -m api. This page does not restart that process. The in-process MarketDataRepository remains available; API Monitor tests its methods.")
