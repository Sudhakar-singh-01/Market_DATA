"""
ui/views/coverage_cash.py
Coverage heatmap: symbols x trading days, coloured by the % of the expected
375 one-minute candles (09:15-15:29) that are actually stored. Drill into any
symbol/day to see the exact missing minutes and fill them in the background.
All numbers come from stored data -- nothing is estimated except "expected",
which is the fixed NSE session (no holiday calendar; see the note on the page).
"""

import datetime
import sys
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.components import instrument_selector
from ui.job_manager import JobContext, submit_gapfill
from ui.job_panel import render_jobs_panel
from controller.coverage_controller import (
    load_daily_counts, load_day_minutes, build_matrix, summarize, worst_symbols, weekdays_between,
    missing_for_day, compress_ranges, build_fill_targets, expected_minutes,
)
from controller.gapfill_controller import FillTarget, now_ist_naive

st.set_page_config(page_title="Coverage Heatmap - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Coverage Heatmap")
st.caption("Each cell = stored 1m candles / expected 375 (09:15-15:29) for that symbol and day. "
           "Green = complete, red = missing minutes. Hover a cell for the numbers, or drill down below for the exact minutes.")

if not data_settings.storage.mysql_enabled:
    st.info("The coverage heatmap reads stored candles from MySQL, so MySQL storage must be enabled.")
    st.stop()

engine = get_mysql_engine_or_none(env, data_settings)

# ------------------------------------------------------------------ controls
c1, c2 = st.columns([3, 2])
with c1:
    names = instrument_selector(instruments, key_prefix="cov")
with c2:
    lookback = st.number_input("Look back (calendar days)", min_value=3, max_value=180, value=30, key="cov_days")
    holiday_mode = False
    st.caption("Empty trading days remain visible. Only the configured calendar identifies holidays.")

if not names:
    st.info("Select at least one stock or index above (or tick 'Select all').")
    st.stop()


@st.cache_data(ttl=60, show_spinner="Reading coverage from MySQL...")
def _counts(_engine, key: str, names_key: tuple, from_iso: str, to_iso: str, _insts):
    return load_daily_counts(_engine, _insts, datetime.date.fromisoformat(from_iso), datetime.date.fromisoformat(to_iso))


now = now_ist_naive()
to_day = now.date()
from_day = to_day - datetime.timedelta(days=int(lookback) - 1)
selected = [instruments.get(n) for n in names]
try:
    counts = _counts(engine, f"{env.db.host}:{env.db.port}/{env.db.name}", tuple(sorted(names)),
                     from_day.isoformat(), to_day.isoformat(), selected)
except Exception as exc:
    st.error(f"Could not read coverage from MySQL: {exc}")
    st.stop()

matrix = build_matrix(counts, names, weekdays_between(from_day, to_day), now, treat_empty_days_as_holiday=holiday_mode)
days = sorted({d for row in matrix.values() for d in row})
if not days:
    st.info("No trading days with expected candles in this range yet.")
    st.stop()

summary = summarize(matrix)
m = st.columns(4)
m[0].metric("Overall coverage", f"{summary['completeness_pct']:.2f}%" if summary["completeness_pct"] is not None else "n/a")
m[1].metric("Missing minutes", f"{summary['missing']:,}")
m[2].metric("Symbol-days with gaps", f"{summary['symbol_days_with_gaps']:,} / {summary['symbol_days']:,}")
m[3].metric("Probable holidays greyed", summary["holiday_days"])

# ------------------------------------------------------------------ heatmap
rows = list(matrix.keys())
z, hover = [], []
for name in rows:
    zr, hr = [], []
    for d in days:
        c = matrix[name][d]
        zr.append(c.pct)
        if c.holiday:
            hr.append(f"{name}<br>{d:%a %Y-%m-%d}<br>no data for ANY selected symbol (probable holiday / not fetched)")
        else:
            hr.append(f"{name}<br>{d:%a %Y-%m-%d}<br>{c.stored}/{c.expected} candles ({c.pct:.1f}%)<br>missing {c.missing} min")
    z.append(zr)
    hover.append(hr)

fig = go.Figure(go.Heatmap(
    z=z, x=[d.isoformat() for d in days], y=rows, text=hover, hoverinfo="text",
    zmin=0, zmax=100, xgap=2, ygap=2,
    colorscale=[[0, "#d73027"], [0.5, "#fdae61"], [0.9, "#a6d96a"], [1, "#1a9850"]],
    colorbar=dict(title="% stored"),
))
fig.update_layout(
    height=max(320, 24 * len(rows) + 140), margin=dict(l=10, r=10, t=10, b=10),
    xaxis=dict(type="category", tickangle=-45), yaxis=dict(autorange="reversed"),
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
)
st.plotly_chart(fig, width="stretch")

worst = worst_symbols(matrix)
if worst:
    st.markdown("#### Symbols with the most missing minutes")
    st.dataframe(pd.DataFrame(worst), width="stretch", hide_index=True)
    fills = build_fill_targets(matrix, {n: instruments.get(n).fyers_symbol for n in rows})
    from ui.quality_page import get_service
    from controller.pipeline_service import start_worker
    from ui.fetch_review import render_gap_fetch
    render_gap_fetch({'symbols':names,'from':str(from_day),'to':str(to_day)},current_role(),get_service,start_worker)
else:
    st.success("No missing minutes in the selected range.")

# ------------------------------------------------------------------ drill-down
st.divider()
st.markdown("#### Drill down: exact missing minutes")
dc1, dc2 = st.columns(2)
default_symbol = worst[0]["Symbol"] if worst else rows[0]
symbol = dc1.selectbox("Symbol", rows, index=rows.index(default_symbol), key="cov_symbol")
sym_days = sorted(matrix[symbol].keys(), reverse=True)
gap_days = [d for d in sym_days if matrix[symbol][d].missing > 0]
ordered_days = gap_days + [d for d in sym_days if d not in gap_days]
day = dc2.selectbox("Day (days with gaps first)", ordered_days, key="cov_day",
                    format_func=lambda d: f"{d:%a %Y-%m-%d}" + (f"  -  {matrix[symbol][d].missing} missing" if matrix[symbol][d].missing else ""))

cell = matrix[symbol][day]
if cell.holiday:
    st.info("No selected symbol has data on this day (probable holiday or never fetched).")
else:
    present = load_day_minutes(engine, instruments.get(symbol).fyers_symbol, day)
    missing = missing_for_day(day, present, now)
    expected_set = set(expected_minutes(day, now))
    st.caption(f"{symbol} on {day:%a %Y-%m-%d}: {cell.stored}/{cell.expected} candles stored, {len(missing)} minute(s) missing.")

    gz = [[(None if datetime.datetime.combine(day, datetime.time(h, mi)) not in expected_set
            else (1 if datetime.datetime.combine(day, datetime.time(h, mi)) in present else 0))
           for mi in range(60)] for h in range(9, 16)]
    gt = [[f"{h:02d}:{mi:02d} " + ("stored" if gz[h - 9][mi] == 1 else "MISSING") if gz[h - 9][mi] is not None else ""
           for mi in range(60)] for h in range(9, 16)]
    gfig = go.Figure(go.Heatmap(z=gz, x=list(range(60)), y=[f"{h:02d}:xx" for h in range(9, 16)], text=gt, hoverinfo="text",
                                zmin=0, zmax=1, xgap=2, ygap=2, showscale=False,
                                colorscale=[[0, "#d73027"], [1, "#1a9850"]]))
    gfig.update_layout(height=260, margin=dict(l=10, r=10, t=10, b=10), yaxis=dict(autorange="reversed"),
                       xaxis=dict(title="minute of the hour", dtick=5), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    st.plotly_chart(gfig, width="stretch")

    if missing:
        st.dataframe(pd.DataFrame([{"From": a.strftime("%H:%M"), "To": b.strftime("%H:%M"), "Minutes": n}
                                   for a, b, n in compress_ranges(missing)]), width="stretch", hide_index=True)
        st.caption('Use Historical Smart Fetch to preview and submit this symbol/date safely.')
