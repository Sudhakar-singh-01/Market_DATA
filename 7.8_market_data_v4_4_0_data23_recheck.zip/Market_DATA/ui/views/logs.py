"""
ui/views/logs.py
Log viewer (spec Section 23) reading the project's EXISTING rotating
log file (model/logging_setup.py) -- no separate logging system.
Parses the standard format: "TIMESTAMP | LEVEL | module | message".
"""

import re
import sys
from pathlib import Path

import streamlit as st
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop, get_mysql_engine_or_none
from ui.logging_bootstrap import resolve_log_path
from ui.table_display import wrapped_dataframe
from ui.error_display import show_error
from sqlalchemy import inspect as sa_inspect, text, bindparam

st.set_page_config(page_title="Logs - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Logs")

_LINE_RE = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \| (?P<level>\w+)\s*\| (?P<module>\S+) \| (?P<message>.*)$")


def _load_log_lines(log_path: Path, max_lines: int) -> list:
    if not log_path.exists():
        return []
    with open(log_path, "r", errors="replace") as f:
        lines = f.readlines()
    return lines[-max_lines:]


_SYMBOL_RE = re.compile(r"\b[A-Z0-9&_]+:[A-Z0-9&_.]+-(?:EQ|INDEX)\b")
_JOB_RE = re.compile(r"\bjob[ _#=:]*(?:id)?[ _#=:]*(\d+)", re.IGNORECASE)


def _parse(lines: list) -> pd.DataFrame:
    rows = []
    current = None
    for line in lines:
        match = _LINE_RE.match(line)
        if match:
            if current:
                rows.append(current)
            current = match.groupdict()
        elif current is not None:
            current["message"] += "\n" + line.rstrip("\n")  # traceback continuation
    if current:
        rows.append(current)
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["ts"] = pd.to_datetime(df["ts"], format="%Y-%m-%d %H:%M:%S,%f", errors="coerce")
    # Symbol / Job ID are not separate fields in the logger's format -- they are
    # extracted from the message text when present (never guessed).
    df["symbol"] = df["message"].str.extract(f"({_SYMBOL_RE.pattern})", expand=False).fillna("-")
    df["job_id"] = df["message"].str.extract(_JOB_RE.pattern, flags=re.IGNORECASE, expand=False).fillna("-")
    return df[["ts", "level", "module", "symbol", "job_id", "message"]]


tab_file, tab_db = st.tabs(["File Log (everything)", "Database -- WARNING and above"])

with tab_file:
    max_lines = st.slider("Lines to load (most recent)", 100, 20000, 2000, step=100)
    log_path = resolve_log_path(data_settings)
    lines = _load_log_lines(log_path, max_lines)

    if not lines:
        st.info(f"No log file yet at {log_path}. It is created as soon as the dashboard (or live/historical run) logs its first line -- start a run and refresh this page.")
    else:
        df = _parse(lines)
        if df.empty:
            st.info("Log file exists but has no lines in the expected format yet.")
        else:
            r1, r2, r3 = st.columns(3)
            levels = r1.multiselect("Level", ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], default=["INFO", "WARNING", "ERROR", "CRITICAL"])
            modules = r2.multiselect("Module", sorted(df["module"].unique().tolist()))
            search = r3.text_input("Search message")

            r4, r5, r6, r7 = st.columns(4)
            min_d, max_d = df["ts"].min().date(), df["ts"].max().date()
            date_from = r4.date_input("From date", value=min_d, min_value=min_d, max_value=max_d)
            date_to = r5.date_input("To date", value=max_d, min_value=min_d, max_value=max_d)
            symbols = sorted(s for s in df["symbol"].unique() if s != "-")
            symbol_sel = r6.selectbox("Symbol", ["(all)"] + symbols)
            job_sel = r7.text_input("Job ID")

            filtered = df[(df["ts"].dt.date >= date_from) & (df["ts"].dt.date <= date_to)]
            if levels:
                filtered = filtered[filtered["level"].isin(levels)]
            if modules:
                filtered = filtered[filtered["module"].isin(modules)]
            if search:
                filtered = filtered[filtered["message"].str.contains(search, case=False, na=False)]
            if symbol_sel != "(all)":
                filtered = filtered[filtered["symbol"] == symbol_sel]
            if job_sel:
                filtered = filtered[filtered["job_id"] == job_sel.strip()]

            st.caption(f"{len(filtered)} of {len(df)} parsed line(s) shown. Symbol/Job ID are read from the message text when a line contains one "
                       f"(the app's log lines currently mention symbols but rarely job IDs -- '-' means none was logged).")
            wrapped_dataframe(filtered.sort_values("ts", ascending=False), wrap_columns=["message"], height=600)

with tab_db:
    st.caption("WARNING/ERROR/CRITICAL records are mirrored here as they happen (INFO/DEBUG stay file-only -- "
               "see File Log tab -- to avoid a DB write per tick-level log line).")
    if not data_settings.storage.mysql_enabled:
        st.info("MySQL storage is disabled -- DB-backed logs require MySQL.")
    else:
        try:
            engine = get_mysql_engine_or_none(env, data_settings)
            table_exists = sa_inspect(engine).has_table("error_logs")
        except Exception as exc:
            engine = None
            table_exists = None
            show_error("Connect to MySQL", "error_logs", exc, current_role(), retry=lambda: st.rerun())

        if table_exists is False:
            st.warning("The `error_logs` table doesn't exist yet, so nothing has been mirrored so far.")
            st.caption("Or run database/add_error_logs.sql yourself in MySQL.")
            if st.button("Create error_logs table now", type="primary"):
                try:
                    with engine.begin() as conn:
                        conn.execute(text("""
                            CREATE TABLE IF NOT EXISTS error_logs (
                                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                occurred_at DATETIME(3) NOT NULL, level VARCHAR(10) NOT NULL,
                                module VARCHAR(200) NOT NULL, message TEXT NOT NULL,
                                INDEX idx_occurred_at (occurred_at), INDEX idx_level (level)
                            ) ENGINE=InnoDB
                        """))
                    st.success("error_logs table created. New WARNING+ log lines will be mirrored from now on.")
                    st.rerun()
                except Exception as exc:
                    show_error("Create error_logs table", "error_logs", exc, current_role(), retry=lambda: st.rerun())
        elif table_exists:
            r1, r2, r3 = st.columns(3)
            db_levels = r1.multiselect("Level", ["WARNING", "ERROR", "CRITICAL"], default=["WARNING", "ERROR", "CRITICAL"], key="db_levels")
            db_module = r2.text_input("Module contains", key="db_module")
            db_search = r3.text_input("Search message", key="db_search")
            db_limit = st.slider("Rows", 50, 5000, 500, step=50, key="db_limit")

            query = "SELECT * FROM error_logs WHERE level IN :levels"
            params = {"levels": db_levels or ["WARNING", "ERROR", "CRITICAL"]}
            if db_module:
                query += " AND module LIKE :module"
                params["module"] = f"%{db_module}%"
            if db_search:
                query += " AND message LIKE :search"
                params["search"] = f"%{db_search}%"
            query += " ORDER BY occurred_at DESC LIMIT :limit"
            params["limit"] = db_limit
            stmt = text(query).bindparams(bindparam("levels", expanding=True))

            try:
                with engine.begin() as conn:
                    db_df = pd.read_sql(stmt, conn, params=params)
                st.caption(f"{len(db_df)} row(s) shown, newest first.")
                wrapped_dataframe(db_df, wrap_columns=["message"], height=600)
            except Exception as exc:
                show_error("Load error_logs", "error_logs", exc, current_role(), retry=lambda: st.rerun())
