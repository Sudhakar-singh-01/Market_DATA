"""
ui/views/data_flow.py
Visualizes the ACTUAL repository pipeline (spec Section 19), with live
status per stage where real status exists. The API stage is the project's real read API (model/repository.py).
"""

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ui.auth import require_auth, logout, current_role
from ui.engine_bootstrap import load_config_or_stop
from ui.data_access import live_run_manager
from controller.health_controller import check_mysql, check_parquet_writable

st.set_page_config(page_title="Data Flow - Market Data Engine", layout="wide")

if not require_auth("user"):
    st.stop()


env, data_settings, timeframe_settings, instruments = load_config_or_stop()

st.title("Data Flow")

live_state = live_run_manager.state
mysql_check = check_mysql(env, data_settings)
parquet_check = check_parquet_writable(data_settings)

stages = [
    ("FYERS", "External data provider", "N/A (external)"),
    ("FYERS Client", "model/fyers/auth.py, model/fyers/historical.py, model/fyers/websocket.py",
     "CONNECTED" if live_state.running else "IDLE"),
    ("Fetch / WebSocket", "controller/live_controller.py + controller/historical_controller.py",
     "RUNNING" if live_state.running else "IDLE"),
    ("Validation", "model/processing/validator.py", "ACTIVE" if data_settings.validation_enabled else "DISABLED"),
    ("Normalization", "model/processing/normalizer.py", "ACTIVE"),
    ("1-Minute Canonical Data", "model/processing/candle_builder.py", "ACTIVE" if live_state.running else "IDLE"),
    ("MySQL", "model/storage/mysql.py", "CONNECTED" if mysql_check.ok else "ERROR"),
    ("Parquet", "model/storage/parquet.py", "CONNECTED" if parquet_check.ok else "ERROR"),
    ("Aggregation", "model/processing/timeframe_aggregator.py", "ACTIVE" if live_state.running else "IDLE (run manually from Aggregation page)"),
    ("Market Data Repository (read API)", "model/repository.py -> get_candles / get_latest_candle / list_instruments ... (see API Monitor)",
     "AVAILABLE" if (data_settings.storage.mysql_enabled or data_settings.storage.parquet_enabled) else "NO STORAGE BACKEND"),
    ("API Consumers", "other modules calling MarketDataRepository (in their own processes)", "NOT TRACKED (callers are not instrumented)"),
]

for name, detail, status in stages:
    cols = st.columns([2, 5, 2])
    cols[0].markdown(f"**{name}**")
    cols[1].caption(detail)
    color = {"CONNECTED": "green", "RUNNING": "green", "ACTIVE": "green", "AVAILABLE": "green",
             "IDLE": "orange", "DISABLED": "orange",
             "ERROR": "red", "NOT IMPLEMENTED": "gray"}.get(status.split(" ")[0], "gray")
    cols[2].markdown(f":{color}[{status}]")
    st.markdown("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↓")

if live_state.running and live_state.controller:
    st.divider()
    st.subheader("Live metrics")
    m = st.columns(3)
    m[0].metric("Ticks received", live_state.controller._received_count)
    m[1].metric("1m candles closed", live_state.controller._closed_1m_count)
    m[2].metric("Derived candles closed", live_state.controller._closed_derived_count)
