"""
ui/views/configuration.py
Admin dashboard: full CRUD (Create/Read/Update/Delete) on every table
in database/schema.sql, plus its own copy of the pipeline-runner
section (historical/aggregate) using the same shared stock/index
selector as the normal dashboard (ui/components.py).

Rendered as a guarded advanced tool within Settings & Diagnostics.

CRUD writes go through ui/admin_data_access.py -- this file is
presentation/wiring only, same separation as the rest of the project.
"""

import sys
from pathlib import Path

import streamlit as st
from ui.date_inputs import date_field, datetime_field
from sqlalchemy import text

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from model.config.env_loader import load_env_config
from model.config.data_settings import load_data_settings
from model.config.timeframe_settings import load_timeframe_settings
from model.config.instrument_loader import load_instrument_registry
from model.fyers.auth import get_authenticated_client, FyersAuthError
from model.exceptions import ConfigurationError
from model.storage.mysql import build_db_url, MySQLCandleSink, MySQLCheckpointStore, get_engine as get_mysql_storage_engine, read_1m_candles
from model.storage.parquet import ParquetCandleSink
from model.storage.csv import export_candles_to_csv, deterministic_export_filename, default_export_path
from controller.historical_controller import run_historical_ingestion
from controller.timeframe_controller import run_timeframe_generation
from controller.live_controller import LiveIngestionController
from controller.sinks import CompositeCandleSink, NoOpCandleSink

from ui.data_access import (
    get_mysql_engine, fetch_table, fetch_candles_filtered,
    list_directory, preview_parquet, preview_csv, live_run_manager,
)
from ui.components import instrument_selector
from ui.ux_helpers import task_guard
from ui.job_manager import JobContext, submit_historical, submit_aggregation
from ui.job_panel import render_jobs_panel
from ui.auth import require_admin_auth, logout, current_role
from ui.audit_log import record_action
from ui.logging_bootstrap import ensure_logging
import pandas as pd
import ui.admin_data_access as admin

st.set_page_config(page_title="Admin - Market Data Engine", layout="wide")

# ------------------------------------------------------------------ Password gate (must be first)

if not require_admin_auth():
    st.stop()



@st.cache_resource
def load_config():
    env = load_env_config()
    data_settings = load_data_settings()
    timeframe_settings = load_timeframe_settings()
    instruments = load_instrument_registry()
    ensure_logging(data_settings, env)
    return env, data_settings, timeframe_settings, instruments


def build_sink(env, data_settings, instruments):
    sinks = []
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        sinks.append(MySQLCandleSink(engine, instruments))
    if data_settings.storage.parquet_enabled:
        sinks.append(ParquetCandleSink())
    if not sinks:
        return NoOpCandleSink()
    return sinks[0] if len(sinks) == 1 else CompositeCandleSink(sinks)


def build_checkpoint_store(env, data_settings):
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        return MySQLCheckpointStore(engine)
    return None


def build_1m_reader(env, data_settings):
    if data_settings.storage.mysql_enabled:
        engine = get_mysql_storage_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        return lambda fyers_symbol, from_date, to_date, instrument: read_1m_candles(engine, fyers_symbol, from_date, to_date, instrument)
    if data_settings.storage.parquet_enabled:
        parquet = ParquetCandleSink()
        return lambda fyers_symbol, from_date, to_date, instrument: parquet.read_candles(fyers_symbol, "1m", from_date, to_date)
    return None


try:
    env, data_settings, timeframe_settings, instruments = load_config()
except ConfigurationError as exc:
    st.error(f"Configuration error: {exc}")
    st.stop()

if not data_settings.storage.mysql_enabled:
    st.error("Admin CRUD requires MySQL storage to be enabled (config/data_settings.yaml storage.mysql.enabled: true).")
    st.stop()

engine = get_mysql_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))


def _safe_fetch_table(engine, table_name, limit):
    """
    Wraps fetch_table() so a MySQL connection failure shows a friendly
    st.error() and an empty table instead of crashing the whole page
    with an unhandled traceback. Every top-level (not inside a button
    handler) table load in this admin page goes through this, since
    those run unconditionally on every page load/rerun -- a DB outage
    should degrade gracefully here, the same way button-triggered
    actions elsewhere in this file already do via their own try/except.
    """
    try:
        return fetch_table(engine, table_name, limit=limit)
    except Exception as exc:
        st.error(f"Could not load '{table_name}' from MySQL: {exc}")
        return pd.DataFrame()

st.title("Admin Dashboard")
st.caption("Full CRUD access to every table. Use carefully -- changes here go straight to the database, with no undo.")

# ------------------------------------------------------------------ Admin Overview (spec Section 25)

with st.expander("Admin Overview -- system health, running/failed jobs, recent errors, recent admin actions", expanded=True):
    from controller.health_controller import run_health_check

    health = run_health_check(env, data_settings, check_fyers_api=False)
    health_by_name = {c.name: c for c in health.checks}
    live_state = live_run_manager.state

    hcols = st.columns(4)
    hcols[0].metric("Live/WebSocket", "RUNNING" if live_state.running else "STOPPED")
    if "MySQL" in health_by_name:
        hcols[1].metric("MySQL", "OK" if health_by_name["MySQL"].ok else "FAIL")
    if "Parquet storage" in health_by_name:
        hcols[2].metric("Parquet", "OK" if health_by_name["Parquet storage"].ok else "FAIL")
    hcols[3].metric("Repository API", "AVAILABLE" if (data_settings.storage.mysql_enabled or data_settings.storage.parquet_enabled) else "NO BACKEND")

    running_jobs = failed_jobs = None
    try:
        with engine.begin() as conn:
            running_jobs = conn.execute(text("SELECT COUNT(*) FROM ingestion_jobs WHERE finished_at IS NULL")).scalar()
            failed_jobs = conn.execute(text("SELECT COUNT(*) FROM ingestion_jobs WHERE status = 'failed'")).scalar()
    except Exception:
        pass
    jcols = st.columns(2)
    jcols[0].metric("Running jobs", running_jobs if running_jobs is not None else "NOT AVAILABLE")
    jcols[1].metric("Failed jobs", failed_jobs if failed_jobs is not None else "NOT AVAILABLE")

    st.caption("Recent errors (failed ingestion_jobs)")
    try:
        recent_errors = pd.read_sql(
            text("SELECT started_at, job_type, fyers_symbol, error_message FROM ingestion_jobs "
                 "WHERE status = 'failed' ORDER BY started_at DESC LIMIT 5"),
            engine.connect(),
        )
        st.dataframe(recent_errors, width="stretch") if not recent_errors.empty else st.caption("None.")
    except Exception as exc:
        st.caption(f"NOT AVAILABLE ({exc})")

    st.caption("Recent admin actions (audit log)")
    try:
        from ui.audit_log import fetch_audit_log
        st.dataframe(fetch_audit_log(engine, limit=5), width="stretch")
    except Exception as exc:
        st.caption(f"NOT AVAILABLE -- apply the audit_log table from database/schema.sql ({exc})")

st.divider()

tab_instruments, tab_candles, tab_checkpoints, tab_jobs, tab_files, tab_run = st.tabs(
    ["Instruments", "Candles", "Checkpoints", "Ingestion Jobs", "Files & Exports", "Run Pipeline"]
)

# ------------------------------------------------------------------ Instruments CRUD

with tab_instruments:
    st.subheader("Existing instruments")
    df = _safe_fetch_table(engine, "instruments", 500)
    st.dataframe(df)

    st.subheader("Add instrument")
    col1, col2, col3 = st.columns(3)
    new_internal_name = col1.text_input("internal_name", key="ins_new_name")
    new_fyers_symbol = col2.text_input("fyers_symbol (e.g. NSE:TCS-EQ)", key="ins_new_symbol")
    new_exchange = col3.text_input("exchange", value="NSE", key="ins_new_exchange")
    col4, col5, col6 = st.columns(3)
    new_type = col4.selectbox("instrument_type", ["EQUITY", "INDEX"], key="ins_new_type")
    new_category = col5.selectbox("category", ["stock", "index"], key="ins_new_category")
    new_active = col6.checkbox("active", value=True, key="ins_new_active")

    if st.button("Create instrument"):
        try:
            new_id = admin.insert_instrument(engine, new_internal_name, new_fyers_symbol, new_exchange, new_type, new_category, new_active)
            st.success(f"Created instrument id={new_id}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"instruments:{new_id}",
                          parameters={"op": "insert_instrument", "fyers_symbol": new_fyers_symbol}, result="success")
        except Exception as exc:
            st.error(f"Create failed: {exc}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target="instruments",
                          parameters={"op": "insert_instrument"}, result="failed", error_message=str(exc))

    st.divider()
    st.subheader("Update / Delete instrument")
    if df.empty:
        st.info("No instruments yet.")
    else:
        target_id = st.selectbox("Select instrument id", df["id"].tolist(), key="ins_target_id")
        row = df[df["id"] == target_id].iloc[0]

        col1, col2, col3 = st.columns(3)
        upd_active = col1.checkbox("active", value=bool(row["is_active"]), key="ins_upd_active")
        upd_exchange = col2.text_input("exchange", value=row["exchange"], key="ins_upd_exchange")
        upd_type = col3.text_input("instrument_type", value=row["instrument_type"], key="ins_upd_type")

        col_a, col_b = st.columns(2)
        if col_a.button("Update instrument"):
            try:
                count = admin.update_instrument(engine, int(target_id), is_active=upd_active, exchange=upd_exchange, instrument_type=upd_type)
                st.success(f"Updated {count} row(s)")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"instruments:{target_id}",
                              parameters={"op": "update_instrument", "is_active": upd_active, "exchange": upd_exchange, "instrument_type": upd_type},
                              records_affected=count, result="success")
            except Exception as exc:
                st.error(f"Update failed: {exc}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"instruments:{target_id}",
                              parameters={"op": "update_instrument"}, result="failed", error_message=str(exc))

        if col_b.button("Delete instrument", type="primary"):
            try:
                count = admin.delete_instrument(engine, int(target_id))
                st.success(f"Deleted {count} row(s)")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"instruments:{target_id}",
                              parameters={"op": "delete_instrument"}, records_affected=count, result="success")
            except Exception as exc:
                st.error(f"Delete failed (likely still has candles referencing it): {exc}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"instruments:{target_id}",
                              parameters={"op": "delete_instrument"}, result="failed", error_message=str(exc))

# ------------------------------------------------------------------ Candles CRUD

with tab_candles:
    st.subheader("Filter candles")
    all_symbols = [i.internal_name for i in instruments.all_instruments()]
    all_timeframes = ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes]

    col1, col2, col3, col4 = st.columns(4)
    f_symbol = col1.selectbox("Symbol", ["(all)"] + all_symbols, key="cand_symbol")
    f_timeframe = col2.selectbox("Timeframe", ["(all)"] + all_timeframes, key="cand_tf")
    f_from = date_field(col3, "From date (optional)", key="cand_from")
    f_to = date_field(col4, "To date (optional)", key="cand_to")

    if st.button("Search candles"):
        fyers_symbol = None if f_symbol == "(all)" else instruments.get(f_symbol).fyers_symbol
        timeframe = None if f_timeframe == "(all)" else f_timeframe
        st.session_state["_candles_df"] = fetch_candles_filtered(
            engine, fyers_symbol=fyers_symbol, timeframe=timeframe, from_date=f_from or None, to_date=f_to or None,
        )

    candles_df = st.session_state.get("_candles_df")
    if candles_df is not None:
        st.dataframe(candles_df)

    st.divider()
    st.subheader("Manually add a candle")
    st.caption("For correction/backfill purposes -- prefer re-running historical/aggregate where possible.")
    col1, col2, col3 = st.columns(3)
    ac_symbol = col1.selectbox("Instrument", all_symbols, key="ac_symbol")
    ac_timeframe = col2.selectbox("Timeframe", all_timeframes, key="ac_tf")
    ac_ts = datetime_field(col3, "Timestamp", key="ac_ts")
    col4, col5, col6, col7, col8 = st.columns(5)
    ac_open = col4.number_input("open", value=0.0, key="ac_open")
    ac_high = col5.number_input("high", value=0.0, key="ac_high")
    ac_low = col6.number_input("low", value=0.0, key="ac_low")
    ac_close = col7.number_input("close", value=0.0, key="ac_close")
    ac_volume = col8.number_input("volume", value=0, step=1, key="ac_volume")

    if st.button("Create candle"):
        try:
            import datetime
            instrument_row = fetch_table(engine, "instruments", limit=1000)
            match = instrument_row[instrument_row["internal_name"] == ac_symbol]
            if match.empty:
                st.error("Instrument not found in MySQL yet -- run historical at least once first, or create it in the Instruments tab.")
            else:
                instrument_id = int(match.iloc[0]["id"])
                ts = datetime.datetime.strptime(ac_ts, "%Y-%m-%d %H:%M:%S")
                new_id = admin.insert_candle(
                    engine, instrument_id, ac_timeframe, ts, ac_open, ac_high, ac_low, ac_close, int(ac_volume),
                    source="FYERS_HISTORICAL", status="CLOSED",
                )
                st.success(f"Created candle id={new_id}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{new_id}",
                              parameters={"op": "insert_candle", "symbol": ac_symbol, "timeframe": ac_timeframe, "timestamp": ac_ts},
                              result="success")
        except Exception as exc:
            st.error(f"Create failed: {exc}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target="candles",
                          parameters={"op": "insert_candle", "symbol": ac_symbol}, result="failed", error_message=str(exc))

    st.divider()
    st.subheader("Update / Delete a specific candle")
    del_id = st.number_input("Candle id", min_value=0, step=1, key="cand_del_id")
    col1, col2, col3 = st.columns(3)
    upd_status = col1.selectbox("New status", ["CLOSED", "OPEN"], key="cand_upd_status")
    col_a, col_b = st.columns(2)
    if col_a.button("Update status"):
        try:
            count = admin.update_candle(engine, int(del_id), status=upd_status)
            st.success(f"Updated {count} row(s)")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{del_id}",
                          parameters={"op": "update_candle", "status": upd_status}, records_affected=count, result="success")
        except Exception as exc:
            st.error(f"Update failed: {exc}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{del_id}",
                          parameters={"op": "update_candle"}, result="failed", error_message=str(exc))
    if col_b.button("Delete candle", type="primary"):
        try:
            count = admin.delete_candle(engine, int(del_id))
            st.success(f"Deleted {count} row(s)")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{del_id}",
                          parameters={"op": "delete_candle"}, records_affected=count, result="success")
        except Exception as exc:
            st.error(f"Delete failed: {exc}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"candles:{del_id}",
                          parameters={"op": "delete_candle"}, result="failed", error_message=str(exc))

    st.divider()
    st.subheader("Bulk delete (force re-aggregate)")
    st.info("Moved to **Admin: Bulk Delete** (sidebar) -- that page has the required "
            "preview -> confirm workflow (spec Section 26: no one-click destructive delete). "
            "This tab intentionally no longer offers a bulk delete shortcut here.")

# ------------------------------------------------------------------ Checkpoints CRUD

with tab_checkpoints:
    st.subheader("Existing checkpoints")
    cp_df = _safe_fetch_table(engine, "checkpoints", 500)
    st.dataframe(cp_df)

    st.subheader("Create / Update checkpoint")
    col1, col2, col3 = st.columns(3)
    cp_symbol = col1.text_input("fyers_symbol (e.g. NSE:SBIN-EQ)", key="cp_symbol")
    cp_timeframe = col2.text_input("timeframe", value="1m", key="cp_tf")
    cp_date = date_field(col3, "synced_through_date", default="today", key="cp_date")
    if st.button("Save checkpoint"):
        try:
            admin.upsert_checkpoint(engine, cp_symbol, cp_timeframe, cp_date)
            st.success("Checkpoint saved.")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"checkpoints:{cp_symbol}:{cp_timeframe}",
                          parameters={"op": "upsert_checkpoint", "synced_through_date": cp_date}, result="success")
        except Exception as exc:
            st.error(f"Save failed: {exc}")
            record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"checkpoints:{cp_symbol}:{cp_timeframe}",
                          parameters={"op": "upsert_checkpoint"}, result="failed", error_message=str(exc))

    st.divider()
    st.subheader("Delete checkpoint (forces full resync on next historical run)")
    if cp_df.empty:
        st.info("No checkpoints yet.")
    else:
        cp_del_id = st.selectbox("Select checkpoint id", cp_df["id"].tolist(), key="cp_del_id")
        if st.button("Delete checkpoint", type="primary"):
            try:
                count = admin.delete_checkpoint(engine, int(cp_del_id))
                st.success(f"Deleted {count} row(s)")
                record_action(engine, current_role(), "RESET_CHECKPOINT", target=f"checkpoints:{cp_del_id}",
                              parameters={"op": "delete_checkpoint"}, records_affected=count, result="success")
            except Exception as exc:
                st.error(f"Delete failed: {exc}")
                record_action(engine, current_role(), "RESET_CHECKPOINT", target=f"checkpoints:{cp_del_id}",
                              parameters={"op": "delete_checkpoint"}, result="failed", error_message=str(exc))

# ------------------------------------------------------------------ Ingestion jobs CRUD

with tab_jobs:
    st.subheader("Job history")
    jobs_df = _safe_fetch_table(engine, "ingestion_jobs", 500)
    st.dataframe(jobs_df)

    st.subheader("Delete a job record")
    if jobs_df.empty:
        st.info("No job records yet.")
    else:
        job_del_id = st.selectbox("Select job id", jobs_df["id"].tolist(), key="job_del_id")
        if st.button("Delete job record", type="primary"):
            try:
                count = admin.delete_ingestion_job(engine, int(job_del_id))
                st.success(f"Deleted {count} row(s)")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"ingestion_jobs:{job_del_id}",
                              parameters={"op": "delete_ingestion_job"}, records_affected=count, result="success")
            except Exception as exc:
                st.error(f"Delete failed: {exc}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target=f"ingestion_jobs:{job_del_id}",
                              parameters={"op": "delete_ingestion_job"}, result="failed", error_message=str(exc))

# ------------------------------------------------------------------ Run pipeline (same capability as the normal dashboard)

with tab_files:
    st.subheader("Browse a folder")
    folder_choice = st.selectbox(
        "Folder",
        ["data/raw/1m", "data/processed/3m", "data/processed/5m", "data/processed/15m", "data/processed/30m",
         "data/processed/1h", "data/processed/1d", "exports", "logs"],
        key="admin_files_folder",
    )
    subfolder = st.text_input("Subfolder (optional, e.g. an instrument name)", value="", key="admin_files_subfolder")
    full_path = f"{folder_choice}/{subfolder}" if subfolder else folder_choice

    entries = list_directory(full_path)
    if not entries:
        st.info(f"'{full_path}' does not exist yet or is empty. It will be created automatically the first time data is written there.")
    else:
        st.table([{"name": e.name, "size_bytes": e.size_bytes, "modified": e.modified} for e in entries])

        file_names = [e.name for e in entries if not e.name.endswith("/")]
        if file_names:
            selected_file = st.selectbox("Preview a file", file_names, key="admin_files_preview_select")
            preview_path = f"{full_path}/{selected_file}"
            try:
                if selected_file.endswith(".parquet"):
                    st.dataframe(preview_parquet(preview_path))
                elif selected_file.endswith(".csv"):
                    st.dataframe(preview_csv(preview_path))
                else:
                    st.text(Path(preview_path).read_text(errors="replace")[:5000])
            except Exception as exc:
                st.error(f"Could not preview file: {exc}")


with tab_run:
    st.subheader("Historical ingestion")
    col1, col2 = st.columns(2)
    h_from = date_field(col1, "From", default="2024-01-01", key="admin_hist_from")
    h_to = date_field(col2, "To", default="2024-01-31", key="admin_hist_to")
    h_symbols = instrument_selector(instruments, key_prefix="admin_hist")

    if st.button("Run historical", key="admin_run_hist"):
        if not h_symbols:
            st.warning("Select at least one stock or index above.")
        else:
            _job = submit_historical(JobContext(env, data_settings, timeframe_settings, instruments), h_symbols, h_from, h_to)
            record_action(engine, current_role(), "START_HISTORICAL_FETCH", target=",".join(h_symbols),
                          parameters={"from": h_from, "to": h_to, "job_id": _job.id}, result="submitted")
            st.success(f"Job #{_job.id} started in the background. You can switch pages or close this tab -- it keeps running.")

    st.divider()
    st.subheader("Timeframe aggregation")
    col1, col2 = st.columns(2)
    a_from = date_field(col1, "From", default="2024-01-01", key="admin_agg_from")
    a_to = date_field(col2, "To", default="2024-01-31", key="admin_agg_to")
    a_symbols = instrument_selector(instruments, key_prefix="admin_agg")
    a_timeframes = st.multiselect("Timeframes (empty = all)", [tf.name for tf in timeframe_settings.derived_timeframes], key="admin_agg_tf")

    if st.button("Run aggregate", key="admin_run_agg"):
        if not a_symbols:
            st.warning("Select at least one stock or index above.")
        else:
            _job = submit_aggregation(JobContext(env, data_settings, timeframe_settings, instruments), a_symbols, a_from, a_to, a_timeframes or None)
            record_action(engine, current_role(), "START_AGGREGATION", target=",".join(a_symbols),
                          parameters={"from": a_from, "to": a_to, "timeframes": a_timeframes, "job_id": _job.id}, result="submitted")
            st.success(f"Job #{_job.id} started in the background. You can switch pages or close this tab -- it keeps running.")

    render_jobs_panel(["historical", "aggregation"], key="admin_jobs", limit=5)

    st.divider()
    st.subheader("Export to CSV")
    all_symbols = [i.internal_name for i in instruments.all_instruments()]
    all_timeframes = ["1m"] + [tf.name for tf in timeframe_settings.derived_timeframes]
    col1, col2, col3, col4 = st.columns(4)
    e_symbol = col1.selectbox("Symbol", all_symbols, key="admin_exp_symbol")
    e_timeframe = col2.selectbox("Timeframe", all_timeframes, key="admin_exp_tf")
    e_from = date_field(col3, "From", default="2024-01-01", key="admin_exp_from")
    e_to = date_field(col4, "To", default="2024-01-31", key="admin_exp_to")

    if st.button("Run export", key="admin_run_export"):
        try:
            if not data_settings.storage.parquet_enabled:
                st.error("Export requires Parquet storage to be enabled.")
            else:
                instrument = instruments.get(e_symbol)
                parquet = ParquetCandleSink()
                candles = parquet.read_candles(instrument.fyers_symbol, e_timeframe, e_from, e_to)
                if not candles:
                    st.warning("No stored candles found for that selection.")
                else:
                    filename = deterministic_export_filename(instrument.fyers_symbol, e_timeframe, e_from, e_to)
                    output_path = default_export_path(data_settings.storage.csv_output_dir, filename)
                    path = export_candles_to_csv(candles, output_path)
                    st.success(f"Exported {len(candles)} candle(s) to {path}")
                    record_action(engine, current_role(), "EXPORT", target=f"candles:{e_symbol}:{e_timeframe}",
                                  parameters={"from": e_from, "to": e_to, "format": "csv"},
                                  records_affected=len(candles), result="success")
                    with open(path, "rb") as f:
                        st.download_button("Download CSV", f, file_name=Path(path).name, key="admin_download_csv")
        except Exception as exc:
            st.error(f"Export failed: {exc}")
            record_action(engine, current_role(), "EXPORT", target=f"candles:{e_symbol}:{e_timeframe}",
                          parameters={"from": e_from, "to": e_to, "format": "csv"}, result="failed", error_message=str(exc))

    st.divider()
    st.subheader("Live ingestion control")
    l_symbols = instrument_selector(instruments, key_prefix="admin_live")

    col1, col2 = st.columns(2)
    if col1.button("Start live", key="admin_start_live", disabled=live_run_manager.state.running):
        if not l_symbols:
            st.warning("Select at least one stock or index above.")
        else:
            try:
                client = get_authenticated_client(env.fyers)
                access_token_ws = f"{env.fyers.client_id}:{env.fyers.access_token}"
                sink = build_sink(env, data_settings, instruments)

                def factory():
                    return LiveIngestionController(
                        access_token_ws=access_token_ws, instruments=instruments, data_settings=data_settings,
                        symbol_filter=l_symbols, sink=sink, historical_client=client,
                    )

                live_run_manager.start(factory)
                st.success("Live ingestion starting in background.")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed",
                              parameters={"op": "start", "symbols": l_symbols}, result="success")
            except FyersAuthError as exc:
                st.error(f"Authentication error: {exc}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed",
                              parameters={"op": "start"}, result="failed", error_message=str(exc))
            except Exception as exc:
                st.error(f"Could not start live ingestion: {exc}")
                record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed",
                              parameters={"op": "start"}, result="failed", error_message=str(exc))

    if col2.button("Stop live", key="admin_stop_live", disabled=not live_run_manager.state.running):
        live_run_manager.stop()
        st.info("Stop requested.")
        record_action(engine, current_role(), "SYSTEM_OPERATION", target="live_feed", parameters={"op": "stop"}, result="success")

    st.divider()
    st.caption("Live status (shared across Normal and Admin dashboards -- only one live session runs at a time):")
    st.json(live_run_manager.status_dict())
