"""Unified workflow UI; orchestration and permissions stay in the service."""
import datetime as dt
import json
import streamlit as st
from ui.task_panel import tracked_spinner
from controller.unified_workflow import fingerprint
from model.config.market_calendar import IST
from ui.workflow_service import STATES


def _error(exc):
    if isinstance(exc,(ValueError,PermissionError)):
        st.error(str(exc))
    else:
        st.error(f'Workflow operation unavailable ({type(exc).__name__}). Check configuration and persisted job status before retrying.')


def render_page(service,role):
    if role!='admin':
        st.error('Administrator access required');return
    st.title('Unified Market Data Workflow')
    st.caption('Fetch → Clean / Validate / Store → optional Aggregation → Verify → Ready')
    st.info('READY is historical verification evidence. Other modules should still request quality=verified when reading data.')
    if st.session_state.pop('wf_go_monitor',False):
        st.session_state['wf_mode']='Monitor jobs'
        st.session_state['wf_monitor_segment']=st.session_state['wf_last_job']['segment']
        st.session_state['wf_job_'+st.session_state['wf_last_job']['segment']]=st.session_state['wf_last_job']['job_id']
    if focus:=st.session_state.pop('wf_focus',None):
        st.session_state['wf_job_'+focus['segment']]=focus['job_id']
    mode=st.radio('Workspace',['New workflow','Monitor jobs'],horizontal=True,key='wf_mode')
    if message:=st.session_state.pop('wf_notice',None):st.success(message)
    if message:=st.session_state.pop('wf_submit_error',None):st.error(message)
    try:
        if mode=='New workflow':_new(service,role)
        else:_monitor(service,role)
    except Exception as exc:_error(exc)


def _new(service,role):
    segment=st.selectbox('Segment',['CASH','FNO'],key='wf_segment')
    options=service.options(segment,role=role)
    yesterday=dt.datetime.now(IST).date()-dt.timedelta(days=1)
    cols=st.columns(2)
    start=cols[0].date_input('From (IST)',value=yesterday-dt.timedelta(days=6),max_value=yesterday,key='wf_from')
    end=cols[1].date_input('To (IST)',value=yesterday,max_value=yesterday,key='wf_to')
    params={'from':str(start),'to':str(end)}
    if segment=='CASH':
        params['symbols']=st.multiselect('Cash instruments',options['symbols'],key='wf_symbols')
        selected=bool(params['symbols'])
    else:
        params['underlyings']=st.multiselect('FNO underlyings',options['underlyings'],key='wf_underlyings')
        params['expiries_ahead']=st.number_input('Nearest expiries',1,12,min(12,max(1,options['expiries_ahead'])),key='wf_expiries')
        params['strike_window']=st.number_input('Strikes on each side of ATM',0,50,min(50,max(0,options['strike_window'])),key='wf_strikes')
        params['include_futures']=st.checkbox('Include futures',value=options['include_futures'],key='wf_futures')
        params['include_options']=st.checkbox('Include options',value=options['include_options'],key='wf_options')
        selected=bool(params['underlyings']) and (params['include_futures'] or params['include_options'])
        st.caption('FNO preview may request a spot quote. It freezes selected active contracts; sparse option coverage can block READY.')
    derived=st.multiselect('Derived timeframes (optional)',['3m','5m','15m','30m','1h','1d'],key='wf_timeframes')
    tfs=['1m',*derived]
    st.caption('Canonical 1m is always included. Maximum 31 days, 200 targets and 5000 target-days; both stores required.')
    key=fingerprint([segment,params,tfs])
    review=st.session_state.get('wf_review')
    if review and review['input_key']!=key:
        st.session_state.pop('wf_review',None);review=None
        st.info('Selection changed. Create a fresh preview before submission.')
    valid=selected and start<=end and (end-start).days<31
    if not selected:
        st.info('Select at least one Cash instrument.' if segment=='CASH' else
                'Select at least one FNO underlying and include futures or options.')
    if start>end:
        st.warning('From date must be on or before To date.')
    elif (end-start).days>=31:
        st.warning('Choose a date range of at most 31 days, including both dates.')
    if st.button('Preview workflow',disabled=not valid,key='wf_preview'):
        st.session_state.pop('wf_review',None)
        with tracked_spinner('Preparing frozen workflow scope…'):
            plan=service.preview(segment,params,tfs,role=role)
        review={'input_key':key,'plan':plan};st.session_state['wf_review']=review
    if not review:return
    plan=review['plan'];scope=plan['params']['workflow']
    st.subheader('Review before submission')
    cols=st.columns(3)
    cols[0].metric('Targets',len(scope['targets']))
    cols[1].metric('Timeframes',len(scope['timeframes']))
    cols[2].metric('Date range',f"{scope['from']} → {scope['to']}")
    st.dataframe(scope['targets'],hide_index=True,width='stretch')
    st.write('Stages:', ' → '.join(plan['stages']))
    with st.expander('Fetch estimate and reviewed parameters'):
        st.json({'fetch_plan':plan['fetch_plan'],'params':plan['params']})
    st.download_button('Download reviewed plan',json.dumps(plan,indent=2,default=str),'workflow_preview.json','application/json',key='wf_plan_download')
    confirmed=st.checkbox('I reviewed the targets, date range and expected provider requests',key='wf_confirm_'+plan['token'][:12])
    if st.button('Submit workflow',type='primary',disabled=not confirmed,key='wf_submit'):
        # Consume before dispatch: uncertain submissions require checking jobs, not blind replay.
        st.session_state.pop('wf_review',None)
        try:
            result=service.submit(plan,role=role)
        except Exception:
            st.session_state['wf_submit_error']=('Submission could not be confirmed. Open Monitor jobs for '+segment+
                     ' and check the persisted queue before submitting again.')
            st.rerun()
        st.session_state['wf_last_job']=result
        verb='already active' if result.get('existing') else 'submitted'
        st.session_state['wf_notice']=f"Workflow #{result['job_id']} {verb} in {result['segment']}."
        st.session_state['wf_go_monitor']=True
        st.rerun()


def _monitor(service,role):
    segment=st.selectbox('Monitor segment',['CASH','FNO'],key='wf_monitor_segment')
    state=st.selectbox('State',['All',*STATES],key='wf_state')
    page=st.number_input('Job list page',min_value=1,max_value=4001,value=1,step=1,key='wf_list_page')
    auto=st.checkbox('Refresh status every 5 seconds',value=False,key='wf_auto')
    st.caption('Refresh reads job status only. It does not fetch data or start/resume workers.')

    @st.fragment(run_every=5 if auto else None)
    def status_panel():
        try:
            if st.button('Refresh now',key='wf_refresh'):pass
            listing=service.list_jobs(segment,role=role,state=None if state=='All' else state,offset=(int(page)-1)*25)
            rows=listing['data']
            if rows:st.dataframe(rows,hide_index=True,width='stretch')
            else:st.info('No workflow jobs on this page.')
            if listing['has_more']:st.caption('More jobs are available on the next page.')
            latest=st.session_state.get('wf_last_job',{})
            default=latest.get('job_id',1) if latest.get('segment')==segment else (rows[0]['id'] if rows else 1)
            jid=int(st.number_input('Inspect workflow job ID',min_value=1,value=int(default),step=1,key='wf_job_'+segment))
            if not rows and not (latest.get('segment')==segment) and not st.checkbox('Look up an older job ID',key='wf_lookup_'+segment):return
            row=service.get_job(segment,jid,role=role)
            st.subheader(f'Workflow #{jid} · {segment}')
            if row.get('reviewed_scope'):
                with st.expander('Frozen targets and date scope'):
                    st.json(row['reviewed_scope'])
            summary=row.get('workflow') or {}
            cols=st.columns(3)
            cols[0].metric('Job state',row['state'])
            cols[1].metric('Current stage',summary.get('stage','Waiting / unavailable'))
            cols[2].metric('Verified rows',summary.get('verified_rows',0))
            _readiness(row['state'],summary)
            st.caption('Verified at: '+str(summary.get('verified_at') or 'Not yet verified'))
            total=summary.get('total_checks',0);done=summary.get('completed_checks',0)
            if total:st.progress(min(1.,max(0.,done/total)),text=f'Verification checks: {done} / {total}')
            else:st.caption('Fetch/aggregation progress uses counters; a reliable overall percentage is not available yet.')
            if summary.get('stages'):st.dataframe(summary['stages'],hide_index=True,width='stretch')
            counters={k:row[k] for k in ('requests_made','rows_raw','rows_valid','rows_invalid','rows_stored','heartbeat_at','cancel_requested') if k in row}
            if counters:st.json(counters)
            if summary.get('reason'):
                reasons={'DATA_NOT_VERIFIED':'Stored data did not satisfy strict verification. Review Data Quality & Verification for the selected scope.',
                         'VERIFICATION_UNAVAILABLE':'Verification could not complete. Check database and Parquet availability before retrying.'}
                st.warning(reasons.get(summary['reason'],'Readiness is blocked. Review persisted job status.'))
            st.code(f'GET /api/v1/jobs/{jid}?segment={segment}',language='text')
            _actions(service,role,segment,jid,row['state'])
        except Exception as exc:_error(exc)
    status_panel()


def _readiness(state,summary):
    """Present persisted evidence without treating queued work as a failure."""
    if state=='SUCCESS' and summary.get('ready') is True:
        st.success('READY at '+str(summary.get('verified_at') or 'unknown time'))
    elif state=='PENDING':
        st.info('Queued. Refresh status to follow this job. Start/recover the queue worker only if needed; it can process other queued jobs.')
    elif state=='RUNNING':
        st.info('In progress. Readiness is available after verification completes. Refreshing this page does not restart the job.')
        if summary.get('ready') is True:
            st.warning('Readiness is not confirmed until the persisted job state is SUCCESS.')
    elif state in ('FAILED','INTERRUPTED'):
        st.error('Workflow '+state.lower()+'. Review the recorded stage and counters before explicitly resuming as a new job.')
    elif state=='PARTIAL':
        st.warning('Workflow incomplete. Review verification findings and stored data before explicitly resuming; complete coverage is not established.')
    elif state=='NO_DATA':
        st.info('No usable verified rows were produced. Review the selected dates and targets before creating a new workflow.')
    elif state=='CANCELLED':
        st.info('Cancelled. Completed work may remain stored. Review the recorded stages before creating a new workflow.')
    else:
        st.warning('Not ready for complete verified consumption.')


def _actions(service,role,segment,jid,state):
    if state in ('CANCELLED','SUCCESS','NO_DATA'):
        st.caption('This job is terminal. Use a fresh reviewed workflow for another run.');return
    options=['cancel','run'] if state in ('PENDING','RUNNING') else ['resume'] if state in ('FAILED','PARTIAL','INTERRUPTED') else []
    if not options:return
    labels={'cancel':'Request cancellation','resume':'Resume as a new job','run':'Start/recover queue worker'}
    action=st.selectbox('Job action',options,format_func=labels.get,key=f'wf_action_{segment}_{jid}_{state}')
    if action=='run':st.warning('This starts the existing queue worker for the selected database, including other queued jobs; stale jobs may be marked interrupted.')
    if action=='resume':st.caption('Resume creates a new job with the same frozen scope. Existing stages recheck stored data.')
    confirmed=st.checkbox('Confirm '+labels[action].lower(),key=f'wf_action_confirm_{segment}_{jid}_{state}_{action}')
    if st.button('Apply job action',disabled=not confirmed,key=f'wf_action_apply_{segment}_{jid}'):
        result=service.action(segment,action,jid,role=role)
        if result.get('new_job_id'):
            st.session_state['wf_last_job']={'segment':segment,'job_id':result['new_job_id']}
            st.session_state['wf_focus']={'segment':segment,'job_id':result['new_job_id']}
        st.session_state['wf_notice']='Action requested. Refreshing persisted status.'
        st.rerun()
