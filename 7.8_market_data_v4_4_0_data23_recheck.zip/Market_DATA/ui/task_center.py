"""Read-only task federation. No worker/provider/service bootstrapping."""
import datetime as dt
import threading
import uuid
from contextlib import contextmanager
from sqlalchemy import select
from model.config.market_calendar import IST

_lock=threading.RLock()
_local={}

@contextmanager
def activity(label,segment='UI'):
    ident=uuid.uuid4().hex
    with _lock:_local[ident]={'key':'ui:'+ident,'segment':segment,'kind':label,'state':'RUNNING','source':'UI operation'}
    try:yield
    finally:
        with _lock:_local.pop(ident,None)


def local_tasks():
    with _lock:return [dict(row) for row in _local.values()]


def database_tasks(catalog,segment):
    """All active queue rows, keyset-paged; never select params/errors/results."""
    table=catalog.table(segment,'ingestion_jobs' if segment=='CASH' else 'fno_ingestion_jobs')
    names=[k for k in ('id','job_type','state','heartbeat_at','started_at','cancel_requested',
                       'requests_made','rows_stored') if k in table.c]
    if not {'id','state'}<=set(names):raise ValueError('Job schema unavailable')
    tasks=[];position=0
    with catalog.engine(segment).connect() as conn:
        while True:
            query=select(*(table.c[k] for k in names)).where(table.c.id>position,
                table.c.state.in_(('PENDING','RUNNING'))).order_by(table.c.id).limit(200)
            rows=[dict(r) for r in conn.execute(query).mappings()]
            for r in rows:
                tasks.append({'key':segment+':sql:'+str(r['id']), 'id':r['id'],'segment':segment,
                    'kind':r.get('job_type') or 'Job','state':r['state'],'source':'Persisted queue',
                    **{k:r[k] for k in ('heartbeat_at','started_at','cancel_requested','requests_made','rows_stored') if k in r}})
            if len(rows)<200:break
            position=rows[-1]['id']
    return tasks


def snapshot(catalog=None,legacy=None,live=None,auto=None):
    tasks=local_tasks();sources=[]
    if catalog is None:
        try:
            from model.database_catalog import configured_catalog
            catalog=configured_catalog()
        except Exception:
            sources.append({'source':'CASH/FNO queues','status':'UNAVAILABLE'})
    if catalog is not None:
        for segment in ('CASH','FNO'):
            try:
                tasks.extend(database_tasks(catalog,segment))
                sources.append({'source':segment+' queue','status':'AVAILABLE'})
            except Exception:
                sources.append({'source':segment+' queue','status':'UNAVAILABLE'})
    try:
        if legacy is None:
            from ui.job_manager import job_manager
            legacy=job_manager
        for r in legacy.active():
            tasks.append({'key':'legacy:'+str(r['id']),'segment':'CASH','id':r['id'],
                'kind':r['kind'],'state':r['status'].upper(),'source':'Local background worker',
                'done':r.get('done',0),'total':r.get('total',0),'cancel_requested':r.get('cancel_requested',False)})
        sources.append({'source':'Local jobs','status':'AVAILABLE'})
    except Exception:sources.append({'source':'Local jobs','status':'UNAVAILABLE'})
    try:
        if live is None:
            from ui.data_access import live_run_manager
            live=live_run_manager
        state=live.state
        if state.running:
            tasks.append({'key':'cash:live','segment':'CASH','kind':'Live feed','state':'RUNNING',
                          'source':'Local live engine','started_at':state.started_at})
        if auto is None:
            from ui.job_manager import auto_gapfill
            auto=auto_gapfill
        if auto.running:tasks.append({'key':'cash:auto','segment':'CASH','kind':'Automatic gap scanning',
                                     'state':'RUNNING','source':'Local scheduler'})
        sources.append({'source':'Live/scheduler','status':'AVAILABLE'})
    except Exception:sources.append({'source':'Live/scheduler','status':'UNAVAILABLE'})
    return {'tasks':tasks,'sources':sources,'checked_at':dt.datetime.now(IST).isoformat()}
