"""TIOS workspace entry point. Domain tools and task monitoring share one shell."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import streamlit as st
from ui.auth import require_auth,current_role,logout
from ui.feature_map import WORKSPACES
from ui.shell import render_header
from ui.workspaces import page

st.set_page_config(page_title='TIOS · Market Data',layout='wide')
if not require_auth("user"):st.stop()
role=current_role()
render_header(role)
if st.sidebar.button('Log out',key='shell_logout'):logout();st.rerun()
nav=[st.Page(page(name,role),title=name,url_path=name.lower().replace(' & ','-').replace(' ','-'),default=i==0)
     for i,name in enumerate(WORKSPACES)]
st.navigation({'Workspace':nav}).run()
