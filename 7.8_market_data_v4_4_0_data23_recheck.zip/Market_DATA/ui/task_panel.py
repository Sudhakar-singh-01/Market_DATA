"""Escaped, persistent top-right task list; every observed active task is shown."""
import html
from contextlib import contextmanager
import streamlit as st
from ui.task_center import activity, snapshot


def panel_html(data):
    esc=lambda v:html.escape(str(v),quote=True)
    cards=[]
    for row in data['tasks']:
        details=[row['source']]
        if row.get('id') is not None:details.append('#'+str(row['id']))
        if row.get('total'):details.append(str(row.get('done',0))+' / '+str(row['total']))
        for key in ('rows_stored','requests_made'):
            if key in row:details.append(key.replace('_',' ')+': '+str(row[key]))
        if row.get('heartbeat_at'):details.append('Heartbeat: '+str(row['heartbeat_at']))
        if row.get('cancel_requested'):details.append('Cancellation requested')
        cards.append('<article class="task-card"><b>'+esc(row['segment'])+' · '+esc(row['kind'])+
                     '</b><span>'+esc(row['state'])+'</span><small>'+esc(' · '.join(details) or row['source'])+'</small></article>')
    missing=[r['source'] for r in data['sources'] if r['status']!='AVAILABLE']
    text=''.join(cards) or '<p>No active tasks observed.</p>'
    if missing:text+='<p class="task-warning">Unavailable: '+esc(', '.join(missing))+'. Task list may be incomplete.</p>'
    return '<aside class="task-center" aria-label="In-progress tasks"><h3>In progress · '+str(len(cards))+'</h3><div class="task-list">'+text+'</div><small>Inspect and manage tasks in Jobs. Updated '+esc(data['checked_at'])+' · live view</small></aside>'


def draw(data=None):
    if not st.session_state.get('new_ui_shell'):return
    holder=st.session_state.get('_task_panel_holder')
    if holder is not None:holder.markdown(panel_html(snapshot() if data is None else data),unsafe_allow_html=True)


def render():
    st.session_state['_task_panel_holder']=st.empty()
    @st.fragment(run_every=5)
    def poll():draw()
    poll()


@contextmanager
def tracked_spinner(label,**kwargs):
    try:
        with activity(str(label)):
            draw()
            with st.spinner(label,**kwargs):yield
    finally:
        draw()
