"""Nine lazy, read-only verification views over persisted source evidence."""
import datetime as dt
import json
import pandas as pd
import streamlit as st
from ui.task_panel import tracked_spinner
from ui.auth import current_role
from ui.date_inputs import date_field
from ui.ux_helpers import lazy_tabs
from controller.pipeline_service import PipelineService,start_worker
from model.quality_store import ready,migration_plan,migrate

PAGES={'Verification Overview':None,'Historical Coverage':'coverage','Data Integrity':'integrity',
       'MySQL vs Parquet':'storage','Checkpoint Health':'checkpoints','Ingestion Job Diagnostics':'jobs',
       'Aggregation Verification':'aggregation','Live Feed & Persistence':'live','Verification History':None}


@st.cache_resource(show_spinner=False)
def get_service():
    from ui.engine_bootstrap import load_config
    env,settings,timeframes,instruments=load_config()
    if not settings.storage.mysql_enabled:raise ValueError('Verification history requires MySQL enabled')
    return PipelineService(env,settings,timeframes,instruments)


def records(rows, *, key='quality_records'):
    if not rows:st.info('No matching findings for this selection. This does not imply a passed verification.');return
    frame=pd.DataFrame(rows)
    if 'details' in frame:frame['details']=frame['details'].map(lambda x:json.dumps(x,default=str))
    st.dataframe(frame,hide_index=True,width='stretch')
    st.download_button('Export displayed rows (CSV)',frame.to_csv(index=False),file_name='verification-page.csv',mime='text/csv',key=key+'_download')


def render():
    from model.config.market_calendar import today_ist
    st.title('Data Quality & Verification')
    st.caption('Read-only source checks · reports and jobs persist · timestamps in IST')
    page=lazy_tabs(list(PAGES),'quality_section')
    c=st.columns(2)
    start=date_field(c[0],'From date',default=str(today_ist()-dt.timedelta(days=7)),key='quality_from')
    end=date_field(c[1],'To date',default='today',key='quality_to')
    try:
        with tracked_spinner('Loading verification service…'):service=get_service()
        names=st.multiselect('Instruments',[i.internal_name for i in service.instruments.all_instruments()],key='quality_symbols')
        if not ready(service.engine):
            st.warning('Verification metadata migration is required. Existing market data is unchanged.')
            if current_role()=='admin':
                with st.expander('Migration preview'):st.code('\n\n'.join(migration_plan(service.engine)),language='sql')
                yes=st.checkbox('Confirm creating/extending Cash job and report metadata')
                if st.button('Apply verification migration',disabled=not yes):migrate(service.engine,True);st.rerun()
            return
        if current_role()=='admin':
            if st.button('Run checks',type='primary'):
                jid=service.submit(current_role(),'VERIFY',{'from':start,'to':end,'symbols':names})
                start_worker(service);st.success(f'Verification job #{jid} queued. Source records will not be repaired.')
        else:st.caption('View access. An administrator can start verification jobs.')
        if page=='Live Feed & Persistence':
            from ui.monitoring_page import render_monitoring
            render_monitoring(service);return
        jobs=[r for r in service.store.list(limit=100) if r['job_type']=='VERIFY']
        if not jobs:
            st.info('No verification runs yet. Quality status: NOT VERIFIED.');return
        jid=st.selectbox('Verification run',[r['id'] for r in jobs],format_func=lambda i:f"#{i} · "+next(r['state'] for r in jobs if r['id']==i))
        job=next(r for r in jobs if r['id']==jid)
        result=job.get('result') or {}
        cols=st.columns(4)
        for col,key in zip(cols,('PASS','WARNING','FAIL','NOT_VERIFIED')):col.metric(key,result.get('checks',{}).get(key,'NOT AVAILABLE'))
        st.caption(f"Job {job['state']} · Started {job['started_at']} · Heartbeat {job.get('heartbeat_at')} · As of {result.get('as_of','NOT AVAILABLE')}")
        if result.get('total'):
            st.progress(min(1.,result.get('done',0)/result['total']),text=f"{result.get('done',0)}/{result['total']} symbol-days · {result.get('current','')}")
        if job.get('error'):st.error(job['error'])
        st.button('Refresh progress',key='quality_refresh')
        if current_role()=='admin':
            if job['state'] in ('PENDING','RUNNING') and st.button('Cancel verification'):
                st.info(service.action(current_role(),'cancel',jid))
            if job['state'] in ('PARTIAL','FAILED','INTERRUPTED') and st.button('Resume verification'):
                new=service.action(current_role(),'resume',jid);start_worker(service);st.success(f'Queued #{new}')
        if page=='Live Feed & Persistence':
            from ui.monitoring_page import render_monitoring
            render_monitoring(service);return
        if page=='Verification Overview':
            st.write('Requested scope',job['params'])
            st.caption('Completed is a job state. PASS applies only to the stated check, scope and as-of time.')
        if page=='Verification History':
            records([{k:r.get(k) for k in ('id','state','started_at','finished_at','resumed_from','error')} for r in jobs],key='quality_history')
            if st.button('Prepare complete run report'):
                rows=[];after=0
                while len(rows)<=100000:
                    batch=service.store.findings(jid,after=after,limit=2000)
                    if not batch:break
                    rows.extend(batch);after=batch[-1]['id']
                if len(rows)>100000:st.warning('Use quality-export CLI for this report; browser export limit is 100,000 findings.')
                else:st.download_button('Download complete report (JSON)',json.dumps({'job':job,'findings':rows},default=str,indent=2),file_name=f'verification-{jid}.json',mime='application/json')
            return
        status=st.selectbox('Finding status',['All','FAIL','WARNING','NOT_VERIFIED','PASS'])
        after=st.number_input('After finding ID',0,value=0,step=200)
        rows=service.store.findings(jid,PAGES[page],None if status=='All' else status,int(after),200)
        records(rows,key='quality_findings')
        if page=='Historical Coverage' and rows:
            chart=[]
            for r in rows:
                d=r['details'] or {};chart.append({'scope':r['scope'],'observed':d.get('observed',0),'missing':d.get('missing',0)})
            st.bar_chart(pd.DataFrame(chart).set_index('scope'))
    except (ValueError,PermissionError) as exc:st.error(str(exc))
    except Exception as exc:
        st.error(f'Verification service unavailable ({type(exc).__name__}). Check database connectivity and configuration; no success assumed.')
        st.button('Retry loading verification',key='quality_retry')
