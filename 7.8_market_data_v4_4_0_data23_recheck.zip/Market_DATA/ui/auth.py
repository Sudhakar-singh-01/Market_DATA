"""
ui/auth.py
Role-based dashboard access control (USER / ADMIN).

Passwords are configured in config/.env as PBKDF2-SHA256 hashes --
never plaintext, never logged. Generate a hash with:

    python tools/hash_password.py "your-password-here"

then put the printed value in config/.env as USER_PASSWORD_HASH /
ADMIN_PASSWORD_HASH.

This enforces:
    - two roles, USER and ADMIN (ADMIN also satisfies a USER check --
      it's a strict superset)
    - session expiration (SESSION_TIMEOUT_MINUTES, default 480 = 8h)
    - failed-login lockout (5 wrong attempts -> 5 minute lockout)

Still a single-user-per-role, local-tool auth model (one shared
password per role, no individual accounts, no backend token exchange)
-- appropriate for a personal local tool, not meant to withstand a
determined attacker with access to config/.env or this machine.
Session state (including lockouts) lives in Streamlit's session_state,
so it resets per browser session, not globally across all users of a
shared deployment; treat this as a soft, casual-access barrier.
"""

import os
import time
from typing import Optional

import streamlit as st
from dotenv import load_dotenv

from ui.password_hashing import verify_password


_ROLE_KEY = "auth_role"
_LOGIN_TIME_KEY = "auth_login_time"
_FAILED_ATTEMPTS_KEY = "auth_failed_attempts"
_LOCKOUT_UNTIL_KEY = "auth_lockout_until"

_ROLE_RANK = {"user": 1, "admin": 2}  # admin satisfies a "user" requirement

_MAX_FAILED_ATTEMPTS = 5
_LOCKOUT_SECONDS = 5 * 60


def _load_env() -> None:
    # Idempotent -- safe even if env_loader already loaded config/.env.
    from model.config.runtime_paths import env_path
    load_dotenv(dotenv_path=env_path())


def _session_timeout_seconds() -> int:
    _load_env()
    try:
        return int(os.getenv("SESSION_TIMEOUT_MINUTES", "480")) * 60
    except ValueError:
        return 480 * 60


def _configured_hash(role: str) -> str:
    _load_env()
    env_var = "ADMIN_PASSWORD_HASH" if role == "admin" else "USER_PASSWORD_HASH"
    return os.getenv(env_var, "")


def current_role() -> Optional[str]:
    """Returns the authenticated role for this session ('user'/'admin'),
    or None if not logged in or the session has expired."""
    role = st.session_state.get(_ROLE_KEY)
    if not role:
        return None
    login_time = st.session_state.get(_LOGIN_TIME_KEY, 0)
    if time.time() - login_time > _session_timeout_seconds():
        st.session_state[_ROLE_KEY] = None
        return None
    return role


def _is_locked_out() -> Optional[float]:
    """Returns seconds remaining if locked out, else None."""
    until = st.session_state.get(_LOCKOUT_UNTIL_KEY, 0)
    remaining = until - time.time()
    return remaining if remaining > 0 else None


def _register_failed_attempt():
    attempts = st.session_state.get(_FAILED_ATTEMPTS_KEY, 0) + 1
    st.session_state[_FAILED_ATTEMPTS_KEY] = attempts
    if attempts >= _MAX_FAILED_ATTEMPTS:
        st.session_state[_LOCKOUT_UNTIL_KEY] = time.time() + _LOCKOUT_SECONDS
        st.session_state[_FAILED_ATTEMPTS_KEY] = 0


def _clear_failed_attempts():
    st.session_state[_FAILED_ATTEMPTS_KEY] = 0
    st.session_state[_LOCKOUT_UNTIL_KEY] = 0


def require_auth(min_role: str = "user") -> bool:
    """
    Renders a login form if the session doesn't already satisfy
    min_role ('user' or 'admin'). Returns True if the caller should
    proceed, False if the caller should render nothing further (the
    caller is expected to `st.stop()` when this returns False).
    """
    from ui.ux_helpers import apply_global_ui
    apply_global_ui()  # wrap st.metric text instead of truncating it (all pages)

    role = current_role()
    if role and _ROLE_RANK.get(role, 0) >= _ROLE_RANK.get(min_role, 1):
        return True

    user_hash = _configured_hash("user")
    admin_hash = _configured_hash("admin")
    if not user_hash and not admin_hash:
        st.error(
            "No passwords configured. Set USER_PASSWORD_HASH and/or "
            "ADMIN_PASSWORD_HASH in config/.env -- generate a hash with "
            "`python tools/hash_password.py \"your-password\"` (see config/.env.example)."
        )
        return False

    lockout_remaining = _is_locked_out()
    st.title("Market Data Dashboard -- Login")
    if lockout_remaining:
        st.error(f"Too many failed attempts. Try again in {int(lockout_remaining) + 1}s.")
        return False

    # st.form() is what makes Enter submit the password -- a bare
    # text_input + st.button requires clicking the button; wrapping
    # them in a form makes Streamlit submit on Enter (standard behavior
    # for a form with exactly one text input).
    with st.form("login_form", clear_on_submit=False, enter_to_submit=True):
        entered = st.text_input("Password", type="password", key="login_password_input")
        submitted = st.form_submit_button("Log in")

    if submitted:
        if admin_hash and verify_password(entered, admin_hash):
            st.session_state[_ROLE_KEY] = "admin"
            st.session_state[_LOGIN_TIME_KEY] = time.time()
            _clear_failed_attempts()
            _try_audit_log("admin", "LOGIN", result="success")
            st.rerun()
        elif user_hash and verify_password(entered, user_hash):
            st.session_state[_ROLE_KEY] = "user"
            st.session_state[_LOGIN_TIME_KEY] = time.time()
            _clear_failed_attempts()
            _try_audit_log("user", "LOGIN", result="success")
            st.rerun()
        else:
            _register_failed_attempt()
            _try_audit_log("unknown", "LOGIN", result="failed")
            st.error("Incorrect password.")

    return False


def _try_audit_log(role: str, action: str, result: str):
    """Fire-and-forget: the DB write runs on a daemon thread so login /
    logout never wait for MySQL."""
    import threading
    try:
        from ui.session_context import get_client_ip, get_session_id
        ip, sid = get_client_ip(), get_session_id()  # must be read on the script thread
    except Exception:
        ip = sid = None
    threading.Thread(target=_audit_log_blocking, args=(role, action, result, ip, sid), daemon=True).start()


def _audit_log_blocking(role: str, action: str, result: str, ip=None, sid=None):
    # Auth code intentionally does NOT import ui.data_access at module
    # level (would create a Streamlit/DB dependency just to log in) --
    # imported lazily here, and any failure (e.g. MySQL disabled) is
    # swallowed since login must work even if MySQL is down.
    try:
        from model.config.env_loader import load_env_config
        from model.config.data_settings import load_data_settings
        from model.storage.mysql import build_db_url, get_engine
        from ui.audit_log import record_action
        env = load_env_config()
        data_settings = load_data_settings()
        if not data_settings.storage.mysql_enabled:
            return
        engine = get_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))
        record_action(engine, role, action, result=result, ip_address=ip, session_id=sid, resolve_session=False)
    except Exception:
        pass


def logout():
    role = current_role() or "unknown"
    _try_audit_log(role, "LOGOUT", result="success")
    st.session_state[_ROLE_KEY] = None


# ---------------------------------------------------------------- Backward-compat shim
# ui/views/configuration.py previously imported require_admin_auth directly.
# Kept as a thin wrapper so existing pages don't need touching beyond
# swapping the import if they want role-aware behavior later.
def require_admin_auth() -> bool:
    return require_auth("admin")
