"""Bounded, read-only diagnosis. Only job state and findings are persisted.

No cleanup, refetch, checkpoint reset, quarantine or candle rewrite occurs here.
Rows are inspected one contract/day at a time and manifest entries in pages.
"""
import datetime as dt
import re

import pandas as pd

from controller.fno_jobs import JobOutcome
from model.fno.aggregation import aggregate_day, buckets, invalid_candle, session_bounds, session_minutes, MINUTES
from model.fno.comparison import frames_equal
from model.fno.models import IST
from model.fno.parquet_store import candles_to_frame, COLUMNS, KEY, CHAIN_COLUMNS, CHAIN_KEY
from model.fno.release3_repository import Release3Repository, date_range, day_bounds

JOB_TYPE = "VERIFY"


def coverage(rows, day, category, session, now):
    minutes = [t for t in session_minutes(day, session) if t+dt.timedelta(minutes=1) <= now]
    allowed = set(minutes)
    expected = len(minutes)
    stamps = sorted({c.timestamp for c in rows if c.status=='CLOSED' and c.timestamp in allowed and not invalid_candle(c)})
    present = set(stamps)
    gaps, run = [], 0
    for minute in minutes:
        if minute in present:
            gaps.append(run); run = 0
        else:
            run += 1
    gaps.append(run)
    status = "NOT_VERIFIED" if category=="OPTIONS" else ("WARNING" if len(stamps)<expected else "PASS")
    return status, {"observed_minutes":len(stamps),"session_minutes_elapsed":expected,
        "first":str(stamps[0]) if stamps else None,"last":str(stamps[-1]) if stamps else None,
        "largest_silent_stretch_minutes":max(gaps,default=0),
        "missing_minutes":max(0,expected-len(stamps)),
        "interpretation":"Option silence is not proof of missing data" if category=="OPTIONS" else "Observed trading day"}


def run_verification(handle, repo, store, settings, now=None):
    repo = Release3Repository(repo.engine)
    a,b = date_range(handle.params)
    now = now or dt.datetime.now(IST)
    counts = {"PASS":0,"FAIL":0,"WARNING":0,"NOT_VERIFIED":0}
    summary = {"checks":counts,"contracts":0,"candle_rows":0,"manifest_files":0,"samples":[],
               "contract_scope":"Explicit IDs, or every contract for selected underlyings, including contracts without candles"}
    def finding(name,scope,status,details):
        counts[status] += 1
        details = {"job_id":handle.id, **details}
        repo.save_quality_result(name,scope,status,details)
        if status != "PASS" and len(summary["samples"])<30:
            summary["samples"].append({**details,"check":name,"scope":scope,"status":status})

    for con in repo.iter_contracts(handle.params.get("underlyings"),handle.params.get("contract_ids"),data_range=None,include_claims=True):
        stop = handle.stop_outcome(summary)
        if stop: return stop
        summary["contracts"] += 1
        scope = str(con.contract_id)
        valid_meta = (con.exchange==con.fyers_symbol.split(":")[0] and con.lot_size is not None and con.lot_size>0
            and con.tick_size is not None and con.tick_size>0
            and ((con.category=="OPTIONS" and con.option_type in ("CE","PE") and con.strike is not None and con.strike>0)
                 or (con.category=="FUTURES" and con.strike is None and con.option_type is None)))
        finding("contract_metadata",scope,"PASS" if valid_meta else "FAIL",{"symbol":con.fyers_symbol})
        day = a
        while day<=b:
            stop = handle.stop_outcome(summary)
            if stop: return stop
            scope = f"{con.contract_id}/{day}"
            base = repo.fetch_candles(con.contract_id,"1m",day,day)
            lo,hi = session_bounds(day,settings.session)
            from model.config.market_calendar import calendar_verified, is_trading_day
            if day > con.expiry:
                if base:
                    finding("after_expiry",scope,"FAIL",{"rows":len(base)})
                day += dt.timedelta(days=1)
                continue
            if not calendar_verified(day,"FNO"):
                finding("calendar_evidence",scope,"NOT_VERIFIED",{"reason":"FNO calendar/session evidence not verified for this date"})
            if not base and is_trading_day(day, 'FNO'):
                finding("minute_coverage",scope,"NOT_VERIFIED" if con.category=="OPTIONS" or not calendar_verified(day,"FNO") else "WARNING",
                    {"observed_minutes":0,"reason":"No candles for selected contract/day; listing date and trade activity may be unknown"})
            if base:
                status,detail = coverage(base,day,con.category,settings.session,now)
                finding("minute_coverage",scope,status,detail)
                optional = ("oi","iv","delta","gamma","theta","vega")
                finding("optional_null_rates",scope,"PASS",{"rows":len(base),
                    "null_count":{k:sum(getattr(c,k) is None for c in base) for k in optional},
                    "null_percent":{k:round(100*sum(getattr(c,k) is None for c in base)/len(base),4) for k in optional}})
                if day==now.date() and lo<=now<hi and con.category=="FUTURES":
                    last = max(c.timestamp for c in base)
                    age = (now-last-dt.timedelta(minutes=1)).total_seconds()
                    finding("live_freshness",scope,"WARNING" if age>settings.live.stale_after_seconds else "PASS",
                            {"age_seconds_after_candle_end":age,"threshold_seconds":settings.live.stale_after_seconds})
            for tf in ("1m",*MINUTES):
                rows = base if tf=="1m" else repo.fetch_candles(con.contract_id,tf,day,day)
                if not rows:
                    if tf!="1m" and base:
                        expected = aggregate_day(base,day,tf,settings.session,now).candles
                        if expected:
                            finding("aggregation_matches_source",scope+"/"+tf,"FAIL",{"stored_rows":0,"expected_rows":len(expected)})
                    continue
                summary["candle_rows"] += len(rows)
                handle.add(rows_raw=len(rows),rows_valid=len(rows))
                bad = sum(invalid_candle(c) for c in rows)
                allowed = set(session_minutes(day,settings.session)) if tf=="1m" else {s for s,e in buckets(day,tf,settings.session)}
                outside = sum(not lo<=c.timestamp<hi or bool(c.timestamp.second or c.timestamp.microsecond)
                              or (allowed is not None and c.timestamp not in allowed) for c in rows)
                duplicates = len(rows)-len({c.timestamp for c in rows})
                finding("candle_integrity",scope+"/"+tf,"FAIL" if bad or outside or duplicates or day>con.expiry else "PASS",
                        {"rows":len(rows),"invalid_ohlcv":bad,"outside_session_or_bucket":outside,
                         "duplicates":duplicates,"after_expiry":day>con.expiry})
                if tf!="1m":
                    expected = aggregate_day(base,day,tf,settings.session,now).candles
                    equal = frames_equal(candles_to_frame(rows),candles_to_frame(expected))
                    finding("aggregation_matches_source",scope+"/"+tf,"PASS" if equal else "FAIL",
                            {"stored_rows":len(rows),"expected_rows":len(expected)})
                if store is not None:
                    rel = store.relative_candle_path(tf,con.underlying,con.expiry,day)
                    try:
                        frame = store.read_partition(rel,contract_id=con.contract_id)
                        subset = frame[frame.contract_id==con.contract_id] if frame is not None else None
                        equal = frames_equal(candles_to_frame(rows),subset)
                        finding("mysql_parquet_values",scope+"/"+tf,"PASS" if equal else "FAIL",{"path":rel,"mysql_rows":len(rows)})
                    except Exception as exc:
                        finding("mysql_parquet_values",scope+"/"+tf,"FAIL",{"path":rel,"error":type(exc).__name__})
            day += dt.timedelta(days=1)
            handle.heartbeat()
        # Verify every intersecting claim using bounded COUNT queries. A whole
        # empty VERIFIED range is provably wrong; holiday gaps alone are not.
        claims = repo.query("SELECT job_type,timeframe,range_from,range_to FROM fno_checkpoint_ranges WHERE contract_id=:c "
            "AND status='VERIFIED' AND range_from<=:b AND range_to>=:a",{"c":con.contract_id,"a":a,"b":b})
        for ck in claims:
            ca,cb = max(a,ck["range_from"]),min(b,ck["range_to"])
            start,end = day_bounds(ca)[0],day_bounds(cb)[1]-dt.timedelta(microseconds=1)
            n = repo.count_candles(con.contract_id,ck["timeframe"],start,end)
            missing=0;verified_calendar=True;current=ca
            while current<=cb:
                verified_calendar &= calendar_verified(current,'FNO')
                if is_trading_day(current, 'FNO'):
                    lo,hi=session_bounds(current,settings.session)
                    expected=(set(session_minutes(current,settings.session))
                              if ck['timeframe']=='1m' else {s for s,e in buckets(current,ck['timeframe'],settings.session)})
                    rows=repo.fetch_candles(con.contract_id,ck['timeframe'],current,current)
                    present={c.timestamp for c in rows if c.status=='CLOSED' and not invalid_candle(c)}
                    missing+=len(expected-present)
                current+=dt.timedelta(days=1)
                handle.heartbeat()
            status='FAIL' if not n else 'NOT_VERIFIED' if not verified_calendar or (missing and con.category=='OPTIONS') else 'WARNING' if missing else 'PASS'
            finding("checkpoint_data_present",f"{con.contract_id}/{ck['job_type']}/{ck['timeframe']}/{ca}..{cb}",
                    status,{"rows_in_requested_intersection":n,'missing_expected_slots':missing,'calendar_verified':verified_calendar})

    if store is None:
        finding("parquet_verification","requested scope","NOT_VERIFIED",{"reason":"Parquet comparison explicitly disabled"})
    else:
        # The manifest scan below checks Parquet -> MySQL values. Also detect
        # chain batches present only in MySQL (including entirely missing files).
        day=a
        while day<=b:
            start,end=day_bounds(day)
            chain_days=repo.query("SELECT underlying,COUNT(*) AS n FROM fno_option_chain_snapshots "
                "WHERE captured_at>=:a AND captured_at<:b GROUP BY underlying",{"a":start,"b":end})
            for group in chain_days:
                und=group["underlying"]
                if handle.params.get("underlyings") and und not in handle.params["underlyings"]:continue
                rel=f"option_chain/underlying={und}/date={day}.parquet"
                m=repo.manifest_get(rel)
                same=bool(m and m["status"]=="VERIFIED" and m["row_count"]==group["n"] and store.abs_path(rel).is_file())
                finding("chain_mysql_parquet_counts",rel,"PASS" if same else "FAIL",
                        {"mysql_rows":group["n"],"manifest_rows":m["row_count"] if m else None})
            day+=dt.timedelta(days=1)
            handle.heartbeat()
            stop=handle.stop_outcome(summary)
            if stop:return stop
        offset = 0
        while True:
            page = repo.manifest_list(limit=200,offset=offset)
            if not page: break
            offset += len(page)
            for m in page:
                stop = handle.stop_outcome(summary)
                if stop: return stop
                rel = m["relative_path"]
                match = re.search(r"date=(\d{4}-\d{2}-\d{2})\.parquet$",rel)
                if not match or not a<=dt.date.fromisoformat(match[1])<=b: continue
                if handle.params.get("underlyings") and not any(f"underlying={u}/" in rel for u in handle.params["underlyings"]): continue
                summary["manifest_files"] += 1
                try:
                    path = store.abs_path(rel)
                    if m["status"]!="VERIFIED" or not path.is_file():
                        finding("manifest_file",rel,"FAIL",{"manifest_status":m["status"],"exists":path.is_file()})
                        continue
                    # Bound in-memory reads to one row-group batch, even for a day's chain snapshots.
                    import pyarrow.parquet as pq
                    with path.open("rb") as stream:
                        file = pq.ParquetFile(stream)
                        columns,keys,tscol = ((COLUMNS,KEY,"candle_timestamp") if m["dataset"]=="candles"
                                             else (CHAIN_COLUMNS,CHAIN_KEY,"captured_at"))
                        correct = (file.schema_arrow.names==columns and file.metadata.num_rows==m["row_count"]
                                   and store.sha256(path)==m["checksum"])
                        from model.quality import parquet_has_duplicate_keys
                        correct = correct and not parquet_has_duplicate_keys(path, keys)
                        low=high=None
                        for batch in file.iter_batches(batch_size=2000):
                            frame=batch.to_pandas()
                            low = min(low,frame[tscol].min()) if low is not None else frame[tscol].min()
                            high = max(high,frame[tscol].max()) if high is not None else frame[tscol].max()
                            if m["dataset"]=="candles":
                                for (cid,tf),group in frame.groupby(["contract_id","timeframe"]):
                                    # Check extra Parquet rows too; checking only MySQL's rows misses these.
                                    day=dt.date.fromisoformat(match[1])
                                    db= candles_to_frame(repo.fetch_candles(int(cid),tf,day,day))
                                    subset=db[db.candle_timestamp.isin(group.candle_timestamp)]
                                    if not frames_equal(subset,group): correct=False
                            else:
                                for batch_id,group in frame.groupby("batch_id"):
                                    db=pd.DataFrame(repo.query("SELECT "+",".join(CHAIN_COLUMNS)+
                                        " FROM fno_option_chain_snapshots WHERE batch_id=:b",{"b":batch_id}),columns=CHAIN_COLUMNS)
                                    db=db[db.contract_id.isin(group.contract_id)]
                                    if not frames_equal(db,group,CHAIN_COLUMNS,CHAIN_KEY): correct=False
                            handle.heartbeat()
                        correct = correct and low==m["min_timestamp"] and high==m["max_timestamp"]
                        finding("manifest_file",rel,"PASS" if correct else "FAIL",{"manifest_status":m["status"],"rows":file.metadata.num_rows})
                except Exception as exc:
                    finding("manifest_file",rel,"FAIL",{"error":type(exc).__name__})
        import itertools
        chain_files=(p.relative_to(store.root).as_posix() for p in (store.root/'option_chain').rglob('date=*.parquet'))
        for index,rel in enumerate(itertools.chain((p.relative_to(store.root).as_posix() for p in (store.root/'candles').rglob('date=*.parquet')),chain_files)):
            if index%200==0:
                stop=handle.stop_outcome(summary)
                if stop:return stop
                handle.heartbeat()
            if handle.params.get("underlyings") and not any(f"underlying={u}/" in rel for u in handle.params["underlyings"]): continue
            match = re.search(r"date=(\d{4}-\d{2}-\d{2})\.parquet$",rel)
            if match and a<=dt.date.fromisoformat(match[1])<=b and not repo.manifest_get(rel):
                finding("unregistered_file",rel,"FAIL",{"reason":"Parquet file has no manifest entry"})
        for rel in store.stale_temp_files():
            finding("interrupted_temp_write",rel,"WARNING",{"remediation":"Inspect with reconcile; verify does not remove files"})
    return JobOutcome("PARTIAL" if counts["FAIL"] or counts["WARNING"] or counts["NOT_VERIFIED"] else
                      "SUCCESS" if summary["candle_rows"] else "NO_DATA",summary)
