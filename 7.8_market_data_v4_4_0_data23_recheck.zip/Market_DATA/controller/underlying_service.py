"""Underlying-index scope binding over existing CASH workflows and strict reads."""
import copy
import datetime as dt

from sqlalchemy import select

from controller.unified_workflow import fingerprint, validate_spec, public_result
from model.config.market_calendar import IST, calendar_metadata, session_windows
from model.quality import stamp
from model.read_contracts import ReadRequestError, date_scope
from model.timeframes import TIMEFRAMES


def resolve_underlyings(underlyings, registry, settings):
    names=sorted({str(n).upper() for n in underlyings})
    if not 1<=len(names)<=20:
        raise ReadRequestError('Select 1 to 20 explicit underlyings')
    configured=set(settings.universe.underlyings)
    mappings=[]
    for name in names:
        symbol=settings.universe.spot_symbols.get(name)
        if name not in configured or not symbol:
            raise ReadRequestError('Underlying has no configured spot mapping')
        matches=[i for i in registry.active_indices() if i.fyers_symbol==symbol]
        if len(matches)!=1:
            raise ReadRequestError('Spot symbol must match exactly one active CASH index; review indices configuration')
        inst=matches[0]
        if inst.exchange!='NSE' or inst.instrument_type.upper()!='INDEX':
            raise ReadRequestError('Underlying requires an NSE INDEX instrument')
        mappings.append({'underlying':name,'internal_name':inst.internal_name,'symbol':symbol})
    return mappings


def preview_underlyings(service, settings, underlyings, start, end, timeframes=TIMEFRAMES):
    backend=service._service('CASH')
    mappings=resolve_underlyings(underlyings,backend.instruments,settings)
    a,b=date_scope(start,end,max_days=31)
    if len(mappings)*((b-a).days+1)*len(set(timeframes)|{'1m'})>1000:
        raise ReadRequestError('Narrow scope to at most 1000 index/day/timeframe checks')
    workflow=service.preview_workflow('CASH',{'from':start,'to':end,
        'symbols':sorted({m['internal_name'] for m in mappings})},role='admin',timeframes=list(timeframes))
    plan={'format':'tios-underlying-v1','mappings':mappings,'workflow':workflow,
          'calendar_token':fingerprint(calendar_metadata()),
          'effect':'Only selected CASH index workflow: missing 1m fetch, selected aggregation, strict historical checks. No FNO candle writes, live capture, reset or repair.'}
    plan['token']=fingerprint(plan)
    return plan


def run_underlyings(service, settings, plan, progress=None):
    reviewed=copy.deepcopy(plan)
    token=reviewed.pop('token',None)
    if reviewed.get('format')!='tios-underlying-v1' or token!=fingerprint(reviewed):
        raise ReadRequestError('Underlying plan changed; preview again')
    if reviewed.get('calendar_token')!=fingerprint(calendar_metadata()):
        raise ReadRequestError('Calendar changed; preview again')
    backend=service._service('CASH')
    mappings=resolve_underlyings([m['underlying'] for m in reviewed['mappings']],backend.instruments,settings)
    if mappings!=reviewed['mappings']:
        raise ReadRequestError('Underlying/index mapping changed; preview again')
    workflow=copy.deepcopy(reviewed['workflow'])
    inner=workflow.pop('token',None)
    if inner!=fingerprint(workflow) or workflow.get('segment')!='CASH':
        raise ReadRequestError('Workflow plan changed; preview again')
    params=workflow['params'];spec=validate_spec(params,'CASH')
    a,b=date_scope(spec['from'],spec['to'],max_days=31)
    if len(mappings)*((b-a).days+1)*len(spec['timeframes'])>1000:
        raise ReadRequestError('Underlying plan exceeds the bounded check scope')
    targets=sorted({(m['internal_name'],m['symbol']) for m in mappings})
    if sorted((t['internal_name'],t['symbol']) for t in spec['targets'])!=targets:
        raise ReadRequestError('Workflow targets differ from underlying indexes')
    # Reuse existing submission/preflight and durable handler, but do NOT start a
    # queue-draining background worker or recover unrelated jobs.
    jid=backend.submit('admin','WORKFLOW',params)
    if progress:progress(jid)
    backend.runner().run_one(job_id=jid)
    job=backend.store.get(jid)
    if job is None:
        return {'status':'JOB_UNAVAILABLE','job_id':jid,'regular_index_data_ready':False},1
    result=public_result(job.get('result'))
    ready=job['state']=='SUCCESS' and bool(result and result.get('ready'))
    if result:result['ready']=ready
    report={'status':'UNDERLYING_WORKFLOW_READY' if ready else job['state'],
            'job_id':jid,'regular_index_data_ready':ready,'mappings':mappings,'workflow':result,
            'fno_alignment_checked':False,
            'scope':'Selected historical CASH indexes only; FNO timestamp alignment, live freshness and unit evidence are separate.'}
    return report,0 if ready else 1 if job['state']=='FAILED' else 2


def _alignment(catalog, mapping, day, verified_base):
    """Read FNO SQL timestamp observations only; never invent/carry forward prices."""
    master=catalog.table('FNO','fno_instruments')
    candles=catalog.table('FNO','fno_candles')
    lo=dt.datetime.combine(day,dt.time())
    query=select(candles.c.candle_timestamp).select_from(candles.join(master,candles.c.contract_id==master.c.id)).where(
        master.c.underlying==mapping['underlying'],candles.c.timeframe=='1m',candles.c.status=='CLOSED',
        candles.c.candle_timestamp>=lo,candles.c.candle_timestamp<lo+dt.timedelta(days=1)).distinct().limit(20001)
    with catalog.engine('FNO').connect() as conn:times=list(conn.execute(query).scalars())
    if len(times)>20000:raise ReadRequestError('FNO timestamp scope exceeds bound')
    times={stamp(ts) for ts in times};missing=sorted(times-verified_base)
    windows=session_windows(day,'CASH')
    outside={ts for ts in times if not any(op<=ts<cl for op,cl in windows)}
    return {'status':'NO_FNO_OBSERVATIONS' if not times else 'UNPAIRED_TIMESTAMPS' if missing else 'OBSERVED_TIMESTAMPS_COVERED',
        'fno_observed_slots':len(times),'without_verified_index':len(missing),
        'outside_configured_cash_session':len(outside),'unpaired_samples':[ts.isoformat() for ts in missing[:12]],
        'samples_truncated':len(missing)>12,'fno_values_verified':False,
        'meaning':'Union of selected-underlying FNO SQL timestamps; not all-contract completeness or synchronized quote proof. No forward fill.'}


def check_underlyings(reads, registry, settings, underlyings, start, end, timeframes=TIMEFRAMES, now=None):
    a,b=date_scope(start,end,max_days=31)
    now=now or dt.datetime.now(IST)
    if now.tzinfo is None or b>=now.astimezone(IST).date():
        raise ReadRequestError('Select completed historical dates')
    tfs=list(dict.fromkeys(['1m',*timeframes]))
    if any(tf not in TIMEFRAMES for tf in tfs):raise ReadRequestError('Unsupported timeframe')
    mappings=resolve_underlyings(underlyings,registry,settings)
    if len(mappings)*((b-a).days+1)*len(tfs)>1000:raise ReadRequestError('Narrow scope to at most 1000 index/day/timeframe checks')
    catalog=reads.catalog
    from model.market_read_service import MarketReadService
    # Use the existing strict SQL/Parquet reader; no verification-job writer.
    if not isinstance(reads,MarketReadService):
        raise TypeError('A MarketReadService instance is required')
    before=fingerprint(calendar_metadata());checks=[];alignments=[];unavailable=False
    for mapping in mappings:
        table=catalog.table('CASH','instruments')
        with catalog.engine('CASH').connect() as conn:
            rows=list(conn.execute(select(table).where(table.c.fyers_symbol==mapping['symbol']).limit(2)).mappings())
        meta_ok=(len(rows)==1 and rows[0]['category']=='index' and rows[0]['is_active'] in (True,1)
                 and rows[0]['internal_name']==mapping['internal_name']
                 and str(rows[0]['instrument_type']).upper()=='INDEX' and rows[0]['exchange']=='NSE')
        for offset in range((b-a).days+1):
            day=a+dt.timedelta(days=offset);base=set();base_ok=False
            for tf in tfs:
                item={'underlying':mapping['underlying'],'symbol':mapping['symbol'],'date':str(day),'timeframe':tf}
                checks.append(item)
                if not meta_ok:
                    item['status']='INDEX_METADATA_MISMATCH';continue
                if tf!='1m' and not base_ok:
                    item['status']='NOT_CHECKED_BASE_UNVERIFIED';continue
                try:
                    page=reads.get_candles('CASH',mapping['symbol'],tf,str(day),str(day),quality='verified',
                                          closed_only=True,session='regular',limit=1000)
                    if page['meta'].get('next_cursor') is not None or page['quality'].get('coverage') not in ('COMPLETE','NO_SESSION') or page['quality'].get('status')!='VERIFIED':
                        raise ReadRequestError('Incomplete strict index evidence')
                    item.update(status='VERIFIED',rows=len(page['data']),coverage=page['quality']['coverage'])
                    if tf=='1m':
                        base={stamp(r['candle_timestamp']) for r in page['data']};base_ok=True
                except Exception as exc:
                    item.update(status='NOT_VERIFIED',error_type=type(exc).__name__)
            try:
                alignment=_alignment(catalog,mapping,day,base)
            except Exception as exc:
                alignment={'status':'ALIGNMENT_UNAVAILABLE','error_type':type(exc).__name__}
                unavailable=True
            alignments.append({'underlying':mapping['underlying'],'date':str(day),**alignment})
    if fingerprint(calendar_metadata())!=before:
        unavailable=True
        for item in checks:item['status']='CALENDAR_CHANGED_DURING_CHECK'
    ready=bool(checks) and all(c['status']=='VERIFIED' for c in checks) and sum(c.get('rows',0) for c in checks)>0
    aligned=not unavailable and bool(alignments) and all(x['status']=='OBSERVED_TIMESTAMPS_COVERED' for x in alignments)
    return {'status':('UNDERLYING_SCOPED_READY' if aligned else 'REGULAR_INDEX_READY_ALIGNMENT_PENDING') if ready else 'UNDERLYING_FINDINGS',
        'regular_index_data_ready':ready,'alignment_inspection_complete':not unavailable,
        'fno_timestamp_alignment_ready':aligned,
        'from':str(a),'to':str(b),'mappings':mappings,'checks':checks,'alignment':alignments,
        'summary':{'checks':len(checks),'verified':sum(c['status']=='VERIFIED' for c in checks),
                   'verified_rows':sum(c.get('rows',0) for c in checks if c['status']=='VERIFIED')},
        'sql_modified':False,'market_data_modified':False,
        'scope':'Point-in-time regular-session historical index values only. Alignment is separate SQL timestamp evidence; no FNO value, live freshness, exchange-source or unit-scale certificate.'}
