"""Bounded read-only broker recheck of empty scopes in prior FNO value reports."""
import argparse
import hashlib
import json
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reports', nargs='+', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        from model.read_contracts import ReadRequestError
        if args.output.suffix.lower() != '.json' or args.output.exists():
            raise ReadRequestError('Choose a new .json report')
        if not 1 <= len(args.reports) <= 4:
            raise ReadRequestError('Select one to four value reports')
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        reports = []; hashes = []
        for path in args.reports:
            if path.stat().st_size > 1024 * 1024:
                raise ReadRequestError('Each value report must be at most 1 MiB')
            raw = path.read_bytes()
            if len(raw) > 1024 * 1024:
                raise ReadRequestError('Value report grew beyond 1 MiB')
            reports.append(json.loads(raw.decode('utf-8-sig')))
            hashes.append(hashlib.sha256(raw).hexdigest())
        from model.database_catalog import configured_catalog
        from model.market_read_service import MarketReadService
        from model.fno.config import load_fno_settings
        from controller.data23_probe import probe_empty
        def client():
            from model.config.env_loader import load_env_config
            from model.fyers.auth import get_authenticated_client
            from model.fyers.rate_limiter import RateLimitedClient, get_shared_limiter, LOW
            raw = get_authenticated_client(load_env_config().fyers)
            return RateLimitedClient(raw, get_shared_limiter(), LOW)
        result = probe_empty(MarketReadService(configured_catalog()), load_fno_settings(), reports, client,
                             progress=lambda r: print(json.dumps(r), flush=True))
        result['input_report_sha256'] = hashes
        with args.output.open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2, default=str)
        print(json.dumps({'status': result['status'], 'summary': result['summary'],
                          'report': str(args.output.absolute()), 'items_2_3_fully_verified': False}))
        return 2  # New observations never resolve all source/unit/coverage gates.
    except Exception as exc:
        from model.read_contracts import ReadRequestError
        result = {'status': 'INVALID_SCOPE' if isinstance(exc, ReadRequestError) else 'STOPPED',
                  'error_type': type(exc).__name__, 'message': str(exc) if isinstance(exc, ReadRequestError)
                  else 'Check administrator authentication, reviewed reports, current master and broker access. No data repair was performed.'}
        print(json.dumps(result)); return 2 if isinstance(exc, ReadRequestError) else 1
    except KeyboardInterrupt:
        print(json.dumps({'status': 'INTERRUPTED', 'message': 'No automatic data storage or repair was requested.'}))
        return 130


if __name__ == '__main__':
    raise SystemExit(main())
