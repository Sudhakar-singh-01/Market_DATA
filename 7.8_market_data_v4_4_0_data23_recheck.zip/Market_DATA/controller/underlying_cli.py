"""Reviewed underlying-index collection and read-only readiness checks."""
import argparse
import json
from pathlib import Path

from model.timeframes import TIMEFRAMES


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    for name in ('preview','check'):
        q=sub.add_parser(name)
        q.add_argument('--underlyings',nargs='+',required=True)
        q.add_argument('--from',dest='start',required=True)
        q.add_argument('--to',dest='end',required=True)
        q.add_argument('--timeframes',nargs='+',choices=TIMEFRAMES,default=list(TIMEFRAMES))
        q.add_argument('--output',type=Path,required=True,help='New .json plan/report')
    run=sub.add_parser('run')
    run.add_argument('--plan',type=Path,required=True)
    run.add_argument('--confirm',action='store_true')
    args=p.parse_args(argv)
    if args.command=='run' and not args.confirm:p.error('--confirm is required to execute the reviewed fetch workflow')
    try:
        if args.command!='run' and (args.output.suffix.lower()!='.json' or args.output.exists()):
            from model.read_contracts import ReadRequestError
            raise ReadRequestError('Choose a new .json output file')
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.fno.config import load_fno_settings
        settings=load_fno_settings()
        from controller.underlying_service import preview_underlyings,run_underlyings,check_underlyings
        if args.command=='check':
            from model.config.instrument_loader import load_instrument_registry
            from model.database_catalog import configured_catalog
            from model.market_read_service import MarketReadService
            report=check_underlyings(MarketReadService(configured_catalog()),load_instrument_registry(),settings,
                                    args.underlyings,args.start,args.end,args.timeframes)
            code=0 if report['regular_index_data_ready'] and report['fno_timestamp_alignment_ready'] else 2
        else:
            from controller.market_data_service import MarketDataService
            service=MarketDataService()
            if args.command=='preview':
                report=preview_underlyings(service,settings,args.underlyings,args.start,args.end,args.timeframes)
                code=0
            else:
                report,code=run_underlyings(service,settings,json.loads(args.plan.read_text(encoding='utf-8-sig')),
                    progress=lambda jid:print(json.dumps({'status':'SUBMITTED','job_id':jid,'segment':'CASH'}),flush=True))
        if args.command!='run':
            with args.output.open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2,default=str)
            if args.command=='preview':
                report={'status':'PREVIEW_ONLY','mappings':report['mappings'],
                        'fetch_plan':report['workflow']['fetch_plan'],'stages':report['workflow']['stages']}
            else:
                report={k:report[k] for k in ('status','regular_index_data_ready','alignment_inspection_complete',
                                             'fno_timestamp_alignment_ready','summary')}
            report['report']=str(args.output.absolute())
        print(json.dumps(report,default=str));return code
    except KeyboardInterrupt:
        print(json.dumps({'status':'INTERRUPTED','message':'Inspect the printed submitted job ID; prior writes may be complete.'}));return 130
    except Exception as exc:
        from model.pipeline_errors import FetchPreflightError
        from model.read_contracts import ReadRequestError
        if isinstance(exc,ReadRequestError):
            print(json.dumps({'status':'INVALID_SCOPE','message':str(exc)}));return 2
        if isinstance(exc,FetchPreflightError):
            print(json.dumps({'status':'BLOCKED','blocked':exc.blocked},default=str));return 2
        print(json.dumps({'status':'STOPPED','error_type':type(exc).__name__,
            'message':'Check admin/configuration, exact active index mappings, fresh plan and closed date scope. If submitted, inspect that job; no automatic rollback is claimed.'}));return 1


if __name__=='__main__':raise SystemExit(main())
