"""Headless entry points over the same Cash service and durable job store."""
import datetime as dt
import json
import sys
from pathlib import Path
from model.config.market_calendar import IST,today_ist,session_window,calendar_verified

MODES={'quality-migrate','verify','smart-fetch','pipeline-aggregate','pipeline-jobs','quality-export','pipeline-worker','alerts-dispatch'}

def add_parsers(sub):
    p=sub.add_parser('quality-migrate',help='Preview explicit Cash metadata migration')
    p.add_argument('--apply',action='store_true')
    for name in ('verify','smart-fetch','pipeline-aggregate'):
        p=sub.add_parser(name)
        p.add_argument('--from',dest='start',required=True);p.add_argument('--to',dest='end',required=True)
        p.add_argument('--symbols',nargs='+',required=True);p.add_argument('--run',action='store_true')
        if name=='smart-fetch':p.add_argument('--preview',action='store_true')
        if name=='pipeline-aggregate':p.add_argument('--timeframes',nargs='+')
    p=sub.add_parser('pipeline-jobs')
    p.add_argument('--cancel',type=int);p.add_argument('--resume',type=int);p.add_argument('--run',action='store_true')
    p=sub.add_parser('pipeline-worker',help='Persistent worker; explicit EOD scheduling opt-in')
    p.add_argument('--once',action='store_true');p.add_argument('--schedule-eod',action='store_true');p.add_argument('--symbols',nargs='+')
    p=sub.add_parser('quality-export')
    p.add_argument('--job',type=int,required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('alerts-dispatch');p.add_argument('--send',action='store_true')


def schedule_eod(service,now=None):
    """One durable EOD request per selected date/symbol scope, including restart catch-up.
    A failed/partial run is visible and requires explicit resume, never a silent retry loop.
    """
    from model.fno.job_store import dedupe_key
    now=now or dt.datetime.now(IST)
    day=now.date()
    for _ in range(8):
        window=session_window(day)
        if window and window[1]+dt.timedelta(minutes=2)<=now and calendar_verified(day):break
        day-=dt.timedelta(days=1)
    else:return None
    symbols=getattr(service,'scheduled_symbols',None) or [i.internal_name for i in service.instruments.active_stocks()+service.instruments.active_indices()]
    params={'from':str(day),'to':str(day),'symbols':sorted(set(symbols)),'use_parquet':service.settings.storage.parquet_enabled}
    key=dedupe_key('SCHEDULE_EOD',params)
    existing=service.store.query('SELECT id FROM ingestion_jobs WHERE dedupe_key=:k LIMIT 1',{'k':key})
    if existing:return existing[0]['id']
    return service.submit('admin','SCHEDULE_EOD',params)


def export_report(store,jid,output):
    import os,tempfile
    job=store.get(jid)
    if not job or job['job_type']!='VERIFY':raise ValueError('Select an existing verification run')
    dest=Path(output);dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=dest.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write('{"job":'+json.dumps(job,default=str)+',"findings":[')
            after=0;first=True
            while True:
                rows=store.findings(jid,after=after,limit=2000)
                if not rows:break
                for row in rows:
                    if not first:f.write(',')
                    json.dump(row,f,default=str);first=False
                after=rows[-1]['id']
            f.write(']}')
        os.replace(tmp,dest)
    finally:
        Path(tmp).unlink(missing_ok=True)
    return str(dest)


def run(args):
    from controller.pipeline_service import PipelineService
    from model.quality_store import ready,migration_plan,migrate
    service=PipelineService()
    exit_code=0
    def code(state):return 0 if state == "SUCCESS" else 1 if state == "FAILED" else 2
    if args.mode=='quality-migrate':
        print(json.dumps({'statements':migration_plan(service.engine)},indent=2))
        if args.apply:print('Applied metadata statements:',migrate(service.engine,True))
        return 0
    if not ready(service.engine):raise ValueError('Run quality-migrate, review, then quality-migrate --apply')
    if args.mode in ('verify','smart-fetch','pipeline-aggregate'):
        kind={'verify':'VERIFY','smart-fetch':'SMART_FETCH','pipeline-aggregate':'AGGREGATION'}[args.mode]
        p={'from':args.start,'to':args.end,'symbols':args.symbols}
        if getattr(args,'timeframes',None):p['timeframes']=args.timeframes
        if getattr(args,'preview',False):print(json.dumps(service.smart_preview(p),indent=2));return 0
        jid=service.submit('admin',kind,p);print('Queued',jid)
        if args.run:
            service.runner().run_one(job_id=jid);job=service.store.get(jid)
            print(json.dumps(job,default=str,indent=2));exit_code=code(job['state'])
    elif args.mode=='pipeline-jobs':
        if args.cancel:service.action('admin','cancel',args.cancel)
        if args.resume:print('Resumed as',service.action('admin','resume',args.resume))
        if args.run:
            service.runner().recover();ids=service.runner().run_until_empty()
            exit_code=max((code(service.store.get(i)['state']) for i in ids),default=0)
        print(json.dumps(service.store.list(),default=str,indent=2))
    elif args.mode=='quality-export':print(export_report(service.store,args.job,args.output))
    elif args.mode=='alerts-dispatch':
        from model.monitoring import dispatch_alerts
        print(json.dumps(dispatch_alerts(service.engine,send=args.send),default=str))
    else:
        import threading,signal
        stop=threading.Event()
        for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stop.set())
        runner=service.runner();runner.shutdown=stop
        service.scheduled_symbols=args.symbols
        while not stop.is_set():
            runner.recover()
            if args.schedule_eod:schedule_eod(service)
            ids=runner.run_until_empty()
            exit_code=max(exit_code,max((code(service.store.get(i)["state"]) for i in ids),default=0))
            if args.once:break
            stop.wait(5)
    return exit_code
