"""Default read-only reset preview; apply is separately authenticated/confirmed."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    preview=sub.add_parser('preview');preview.add_argument('--output',type=Path,required=True)
    apply=sub.add_parser('apply');apply.add_argument('--plan',type=Path,required=True)
    apply.add_argument('--writers-stopped',action='store_true')
    args=parser.parse_args(argv)
    try:
        if args.command=='preview' and args.output.exists():raise ValueError('Choose a new plan filename; existing plans are not overwritten')
        if args.command=='apply' and not args.writers_stopped:raise ValueError('--writers-stopped is required')
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.database_catalog import configured_catalog
        from model.reset_service import ResetService
        service=ResetService(configured_catalog())
        if args.command=='preview':
            plan=service.preview(role='admin')
            with args.output.open('x',encoding='utf-8') as out:json.dump(plan,out,indent=2,default=str)
            print(json.dumps({'status':'PREVIEW_ONLY','plan':str(args.output),'targets':[
                {'segment':t['backup_plan']['segment'],'database':t['backup_plan']['database'],
                 'tables':t['backup_plan']['tables'],'parquet_root':t['backup_plan']['parquet_root'],
                 'parquet_files_to_archive':len(t['archive_files'])} for t in plan['targets']],
                 'confirmation':plan['confirmation']}))
            return 0
        plan=json.loads(args.plan.read_text(encoding='utf-8-sig'))
        print(plan['effect']);print('All CASH/FNO readers, dashboards, live feeds, workers and external writers must be stopped.')
        print('Fresh backups will be checksum-verified; restoration has NOT been tested automatically.')
        if input('Type ACCEPT SQL DATA LOSS to continue: ')!='ACCEPT SQL DATA LOSS':
            raise ValueError('SQL data-loss acknowledgment not provided')
        confirmation=input('Type exactly '+plan['confirmation']+': ')
        result=service.apply(plan,role='admin',confirmation=confirmation,writers_stopped=True,accept_data_loss=True)
        print(json.dumps(result,indent=2,default=str))
        return 0 if result['status']=='EMPTY_SCHEMA_READY' else 2
    except (KeyboardInterrupt,EOFError):
        print('Stopped. If apply had started, inspect reset journal and keep writers stopped.');return 130
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error_type':type(exc).__name__,
            'message':str(exc) if isinstance(exc,ValueError) else 'Check administrator authentication, configuration and reset journals.'}))
        return 1


if __name__=='__main__':raise SystemExit(main())
