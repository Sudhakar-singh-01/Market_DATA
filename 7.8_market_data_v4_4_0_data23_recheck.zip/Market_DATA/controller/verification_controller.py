"""Read-only Cash pipeline diagnosis. Writes only job/findings metadata.

A partition is one symbol/day/timeframe. No repair API is imported here.
"""
import datetime as dt
import hashlib
from pathlib import Path
import pandas as pd
from sqlalchemy import text
from model.config.market_calendar import IST, expected_starts, calendar_verified, calendar_metadata
from model.quality import compare_rows, integrity, stamp, MAX_PARTITION_ROWS, RULE_VERSION
from controller.fno_jobs import JobOutcome
from model.processing.models import Candle
from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe, SUPPORTED_TIMEFRAMES


class CashReader:
    def __init__(self,engine,root=None):
        from model.storage_scope import cash_data_root
        self.engine,self.root=engine,cash_data_root() if root is None else Path(root)
    def query(self,sql,p=None):
        with self.engine.connect() as c:return [dict(r) for r in c.execute(text(sql),p or {}).mappings()]
    def instrument(self,symbol):
        rows=self.query('SELECT * FROM instruments WHERE fyers_symbol=:s',{'s':symbol})
        return rows[0] if rows else None
    def sql_day(self,iid,tf,day):
        if iid is None:return []
        return self.query('SELECT * FROM candles WHERE instrument_id=:i AND timeframe=:tf AND candle_timestamp>=:a '
            'AND candle_timestamp<:b ORDER BY candle_timestamp,id LIMIT :limit',
            {'i':iid,'tf':tf,'a':day,'b':day+dt.timedelta(days=1),'limit':MAX_PARTITION_ROWS+1})
    def path(self,symbol,tf,day):
        if any(x in symbol for x in ('/','\\','..')):raise ValueError('Unsafe symbol')
        return self.root/('raw' if tf=='1m' else 'processed')/tf/symbol.replace(':','_')/(day.isoformat()+'.parquet')
    def parquet_day(self,symbol,tf,day):
        import pyarrow.parquet as pq
        path=self.path(symbol,tf,day)
        if not path.exists():return [],None
        before=path.stat()
        with path.open("rb") as stream:
            file=pq.ParquetFile(stream)
            if file.metadata.num_rows>MAX_PARTITION_ROWS:raise RuntimeError('Partition exceeds bounded row limit; split/review scope before certification')
            records=[]
            for batch in file.iter_batches(batch_size=2000):records.extend(batch.to_pandas().to_dict('records'))
        for record in records:
            if record.get('fyers_symbol')!=symbol or record.get('timeframe')!=tf:
                raise ValueError('Parquet identity disagrees with requested symbol/timeframe')
        after=path.stat()
        if (before.st_mtime_ns,before.st_size)!=(after.st_mtime_ns,after.st_size):raise RuntimeError('Partition changed during verification; retry after writer finishes')
        return records,{'bytes':after.st_size,'modified_ns':after.st_mtime_ns}


def row_candles(rows,inst):
    return [Candle(inst.internal_name,inst.fyers_symbol,inst.instrument_type,inst.exchange,stamp(r['candle_timestamp']),
        '1m',float(r['open']),float(r['high']),float(r['low']),float(r['close']),int(r['volume']),r['source'],r['status']) for r in rows]


def candle_rows(candles):
    return [dict(candle_timestamp=c.timestamp,open=c.open,high=c.high,low=c.low,close=c.close,volume=c.volume,
        source=c.source,status=c.status) for c in candles]


def run_verification(handle,reader,instruments,store,now=None):
    now=now or dt.datetime.now(IST)
    p=handle.params
    a,b=dt.date.fromisoformat(p['from']),dt.date.fromisoformat(p['to'])
    if a>b or (b-a).days>3660:raise ValueError('Choose an ordered range of at most 3661 days')
    from controller.historical_controller import select_instruments
    selected=select_instruments(instruments,p.get('symbols'))
    if not selected:raise ValueError('Select at least one configured instrument')
    out={'rule_version':RULE_VERSION,'calendar_version':calendar_metadata().get('version','UNVERIFIED'),
         'as_of':now.isoformat(),'done':0,'total':len(selected)*((b-a).days+1),'current':'',
         'checks':{'PASS':0,'WARNING':0,'FAIL':0,'NOT_VERIFIED':0},'rows_checked':0}
    def finding(name,scope,status,details):
        out['checks'][status]+=1
        store.finding(handle.id,name,scope,status,details)
    for inst in selected:
        meta=reader.instrument(inst.fyers_symbol)
        iid=meta['id'] if meta else None
        agree=bool(meta and all(str(meta[k])==str(getattr(inst,k)) for k in ('internal_name','exchange','instrument_type','category')) and bool(meta['is_active'])==inst.active)
        finding('metadata',inst.internal_name,'PASS' if agree else 'FAIL',{'database_present':bool(meta),'yaml_matches_database':agree})
        day=a
        while day<=b:
            stopped=handle.stop_outcome(out)
            if stopped:return stopped
            scope=f'{inst.internal_name}/{day}';out['current']=scope
            base=[];base_ok=False
            for tf in ('1m',*SUPPORTED_TIMEFRAMES):
                sql=reader.sql_day(iid,tf,day)
                if len(sql)>MAX_PARTITION_ROWS:
                    finding('integrity',scope+'/'+tf,'NOT_VERIFIED',{'reason':'partition row bound exceeded'});continue
                check=integrity(sql,tf,day,now)
                out['rows_checked']+=len(sql)
                handle.add(rows_raw=len(sql),rows_invalid=check['invalid'])
                finding('integrity',scope+'/'+tf,'FAIL' if check['invalid'] or check['duplicates'] else 'PASS' if sql else 'NOT_VERIFIED',check)
                if tf=='1m':
                    base=sql;base_ok=not(check['invalid'] or check['duplicates'])
                    expected=set(expected_starts(day,now=now,lag_seconds=60))
                    present={stamp(r['candle_timestamp']) for r in sql if r.get('status')=='CLOSED'}
                    missing=sorted(expected-present)
                    known=calendar_verified(day)
                    finding('coverage',scope,'NOT_VERIFIED' if not known else 'WARNING' if missing else 'PASS',
                        {'expected':len(expected),'observed':len(expected&present),'missing':len(missing),'missing_samples':list(map(str,missing[:30])),
                         'calendar_verified':known,'interpretation':'Observed candles; silence may be legitimate for illiquid instruments'})
                    ck=reader.query("SELECT synced_through_date FROM checkpoints WHERE fyers_symbol=:s AND timeframe='1m'",{'s':inst.fyers_symbol})
                    claimed=bool(ck and ck[0]['synced_through_date']>=day)
                    finding('checkpoints',scope,'FAIL' if claimed and missing and known else 'NOT_VERIFIED' if not known or not claimed else 'PASS',
                        {'claimed':claimed,'missing':len(missing),'meaning':'Max date is a progress hint, not independent proof of completeness'})
                else:
                    try:
                        expected_rows=candle_rows(aggregate_1m_to_timeframe(row_candles(base,inst),tf)) if base_ok else []
                        comparison=compare_rows(sql,expected_rows)
                        bad=any(comparison[k] for k in ('sql_only','parquet_only','value_mismatches'))
                        finding('aggregation',scope+'/'+tf,'NOT_VERIFIED' if not base_ok or not calendar_verified(day) else 'FAIL' if bad else 'PASS' if expected_rows or sql else 'NOT_VERIFIED',
                            {**comparison,'stored':len(sql),'expected':len(expected_rows),'reason':None if base_ok else 'Invalid base candles'})
                    except Exception as exc:finding('aggregation',scope+'/'+tf,'NOT_VERIFIED',{'reason':type(exc).__name__})
                if p.get('use_parquet',True):
                    try:
                        pq,version=reader.parquet_day(inst.fyers_symbol,tf,day)
                        if day==now.date():
                            cutoff=now-dt.timedelta(minutes=2)
                            sql=[r for r in sql if stamp(r['candle_timestamp'])<cutoff and r['status']=='CLOSED']
                            pq=[r for r in pq if stamp(r['candle_timestamp'])<cutoff and r.get('status')=='CLOSED']
                        detail=compare_rows(sql,pq)
                        detail.update(file_version=version,sql_rows=len(sql),parquet_rows=len(pq))
                        pq_check=integrity(pq,tf,day,now)
                        detail['parquet_integrity']=pq_check
                        bad=any(detail[k] for k in ('sql_only','parquet_only','value_mismatches')) or pq_check['invalid'] or pq_check['duplicates']
                        # Today's mutable partitions cannot receive a durable PASS certificate.
                        status='NOT_VERIFIED' if day>=now.date() else 'FAIL' if bad else 'PASS' if sql or pq else 'NOT_VERIFIED'
                        finding('storage',scope+'/'+tf,status,detail)
                    except Exception as exc:
                        finding('storage',scope+'/'+tf,'NOT_VERIFIED' if isinstance(exc,RuntimeError) else 'FAIL',{'error':type(exc).__name__,'reason':str(exc)[:200]})
                else:finding('storage',scope+'/'+tf,'NOT_VERIFIED',{'reason':'Parquet comparison disabled'})
            out['done']+=1;store.progress(handle.id,out);day+=dt.timedelta(days=1)
        diagnostics=reader.query('SELECT id,status,raw_count,valid_count,invalid_count,error_message,started_at,finished_at FROM ingestion_jobs '
            'WHERE fyers_symbol=:s AND started_at>=:a AND started_at<:b ORDER BY id DESC LIMIT 200',
            {'s':inst.fyers_symbol,'a':a,'b':b+dt.timedelta(days=1)})
        finding('jobs',inst.internal_name,'WARNING' if any(r['status'] in ('failed','partial') for r in diagnostics) else 'PASS' if diagnostics else 'NOT_VERIFIED',
            {'rows':len(diagnostics),'sample':diagnostics[:20],'bounded_to_latest':200})
        finding('live',inst.internal_name,'NOT_VERIFIED',{'reason':'Stored candles alone do not prove tick reception or successful live persistence; inspect telemetry'})
    out['current']='Completed'
    return JobOutcome('PARTIAL' if any(out['checks'][k] for k in ('FAIL','WARNING','NOT_VERIFIED')) else 'SUCCESS',out)
