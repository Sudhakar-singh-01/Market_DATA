"""Headless schema checks, backup operations and scoped cleanup previews."""
import argparse
import json
from pathlib import Path


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    schema = sub.add_parser('schema', help='Read schema compatibility and missing-table DDL; never applies DDL')
    schema.add_argument('--segment', choices=['CASH', 'FNO'], required=True)
    sub.add_parser('backups', help='List existing backup archives')
    preview = sub.add_parser('backup-preview', help='Inspect one database/root and save a fresh review plan')
    preview.add_argument('--segment', choices=['CASH', 'FNO'], required=True)
    preview.add_argument('--output', type=Path, required=True)
    create = sub.add_parser('backup-create', help='Create the reviewed SQL + Parquet archive after stopping writers')
    create.add_argument('--plan', type=Path, required=True)
    create.add_argument('--writers-stopped', action='store_true')
    verify = sub.add_parser('backup-verify', help='Verify archive checksums; does not certify restoration')
    verify.add_argument('--id', required=True)
    cleanup = sub.add_parser('cleanup-preview', help='Inspect a scoped cleanup; never deletes')
    cleanup.add_argument('--segment', choices=['CASH', 'FNO'], required=True)
    cleanup.add_argument('--symbol', required=True, help='Exact FYERS symbol')
    cleanup.add_argument('--from', dest='start', required=True)
    cleanup.add_argument('--to', dest='end', required=True)
    cleanup.add_argument('--timeframe', default='1m')
    return p


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    if args.command == 'backup-create' and not args.writers_stopped:
        p.error('Stop writers first, then pass --writers-stopped')
    try:
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        from model.read_contracts import date_scope
        if args.command == 'cleanup-preview':
            # Validate before catalog access, retaining a useful public error.
            date_scope(args.start, args.end, max_days=31)
        from model.database_catalog import configured_catalog
        catalog = configured_catalog()
        code = 0
        if args.command == 'schema':
            from model.schema_management import SchemaManager
            service = SchemaManager(catalog)
            plan = service.preview(args.segment, role='admin')
            compatibility = plan['compatibility']
            report = {'status': 'PREVIEW_ONLY', 'missing_tables': plan, 'compatibility': compatibility,
                      'database_modified': False}
            code = 0 if compatibility.get('compatible') else 2
        elif args.command == 'cleanup-preview':
            from model.cleanup_service import CleanupService
            report = CleanupService(catalog).preview(args.segment, args.symbol, args.start, args.end,
                                                     args.timeframe, role='admin')
        else:
            from model.backup_service import BackupService
            service = BackupService(catalog)
            if args.command == 'backups':
                report = {'backups': service.list_backups(role='admin')}
            elif args.command == 'backup-preview':
                report = service.preview(args.segment, role='admin')
                with args.output.open('x', encoding='utf-8') as stream:
                    json.dump(report, stream, indent=2, default=str)
                report = {'status': 'PREVIEW_ONLY', 'plan': str(args.output), 'segment': args.segment}
            elif args.command == 'backup-create':
                plan = json.loads(args.plan.read_text(encoding='utf-8-sig'))
                report = service.create(plan, role='admin', writers_stopped=True)
            else:
                report = service.verify(args.id, role='admin')
        print(json.dumps(report, default=str, indent=2))
        return code
    except KeyboardInterrupt:
        print(json.dumps({'status': 'INTERRUPTED', 'message': 'Inspect any backup candidate before retrying.'}))
        return 130
    except Exception as exc:
        from model.read_contracts import ReadRequestError
        print(json.dumps({'status': 'FAILED', 'error_type': type(exc).__name__,
                          'message': str(exc) if isinstance(exc, ReadRequestError) else
                          'Check authentication, configuration, fresh plan and file access; no reset or migration was requested.'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
