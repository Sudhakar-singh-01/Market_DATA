"""Recheck only empty historical scopes from existing value reports; never store candles."""
import datetime as dt
from collections import Counter

from sqlalchemy import select

from controller.unified_workflow import fingerprint
from model.config.market_calendar import IST, calendar_metadata, live_session_status
from model.data_inventory import _targets
from model.fno.history_client import FnoHistoryFetcher, classify_response, OK, NO_DATA, AUTH, RATE_LIMIT
from model.fno.normalizer import normalize_history_rows
from model.market_read_service import MarketReadService
from model.read_contracts import ReadRequestError, date_scope

MAX_SCOPES = 10
MAX_RESPONSE_ROWS = 2000


def reviewed_empty_scopes(reports):
    scopes = {}
    if not 1 <= len(reports) <= 4:
        raise ReadRequestError('Select one to four existing FNO value reports')
    for report in reports:
        if report.get('segment') != 'FNO' or not isinstance(report.get('checks'), list) or len(report['checks']) > 500:
            raise ReadRequestError('Select bounded FNO value reports')
        a, b = date_scope(report.get('from'), report.get('to'), max_days=31)
        for item in report['checks']:
            if item.get('status') != 'NOT_VERIFIED' or item.get('reason') != 'NO_CANDLES_OBSERVED':
                continue
            identity = item.get('contract_id')
            day, _ = date_scope(item.get('date'), item.get('date'), max_days=1)
            if (type(identity) is not int or identity <= 0 or not a <= day <= b
                    or item.get('timeframe') != '1m' or not isinstance(item.get('symbol'), str)):
                raise ReadRequestError('Invalid empty scope in supplied report')
            key = (identity, day)
            value = {'contract_id': identity, 'symbol': item['symbol'], 'date': str(day)}
            if key in scopes and scopes[key] != value:
                raise ReadRequestError('Reports disagree on contract identity')
            scopes[key] = value
    if len(scopes) > MAX_SCOPES:
        raise ReadRequestError('Select at most ten empty contract/day scopes')
    return list(scopes.values())


def probe_empty(reads, settings, reports, make_client, progress=None):
    if not isinstance(reads, MarketReadService):
        raise TypeError('MarketReadService required')
    scopes = reviewed_empty_scopes(reports)
    now = reads.clock()
    if now.tzinfo is None:
        raise ReadRequestError('Timezone-aware clock required')
    now = now.astimezone(IST)
    # Bind every reviewed ID/symbol before any provider request. A reset/master
    # rebuild cannot silently redirect old report IDs to other contracts.
    targets = {}
    if scopes:
        days = [dt.date.fromisoformat(s['date']) for s in scopes]
        if max(days) >= now.date():
            raise ReadRequestError('Only completed historical dates can be rechecked')
        targets = {t['id']: t for t in _targets(reads.catalog, 'FNO', min(days), max(days),
                                               None, [s['contract_id'] for s in scopes], None)}
        for scope in scopes:
            target = targets[scope['contract_id']]
            if (target['fyers_symbol'] != scope['symbol'] or target['category'] not in ('OPTIONS', 'FUTURES')
                    or dt.date.fromisoformat(scope['date']) > target['expiry']):
                raise ReadRequestError('Stored contract identity differs from supplied report; create a fresh value report')
    checks = []
    requests = 0
    client = None
    stopped = False
    table = reads.catalog.table('FNO', 'fno_candles') if scopes else None
    for scope in scopes:
        item = dict(scope, status='NOT_ATTEMPTED')
        checks.append(item)
        if stopped:
            continue
        day = dt.date.fromisoformat(scope['date'])
        lo = dt.datetime.combine(day, dt.time())
        try:
            present = reads._read('FNO', select(table.c.id).where(
                table.c.contract_id == scope['contract_id'], table.c.timeframe == '1m',
                table.c.candle_timestamp >= lo, table.c.candle_timestamp < lo + dt.timedelta(days=1)).limit(1))
            if present:
                item['status'] = 'STORED_ROWS_NOW_PRESENT_REVERIFY_VALUES'
                continue
            if targets[scope['contract_id']]['expiry'] < now.date():
                item['status'] = 'EXPIRED_API_REVIEW_REQUIRED'
                continue
            if client is None:
                client = make_client()
            if progress:
                progress(dict(scope, status='REQUESTING_HISTORY'))
            requests += 1
            payload = FnoHistoryFetcher(client, settings.history).payload(scope['symbol'], day, day)
            response = client.history(data=payload)  # exactly one call; no retry loop
            kind, _, _ = classify_response(response, settings.history)
            if kind == AUTH:
                item['status'] = 'PROVIDER_AUTH_REQUIRED'; stopped = True
            elif kind == RATE_LIMIT:
                item['status'] = 'PROVIDER_RATE_LIMITED'; stopped = True
            elif kind == NO_DATA:
                item['status'] = 'PROVIDER_NO_DATA_ON_RECHECK'
            elif kind != OK:
                item['status'] = 'PROVIDER_RESPONSE_NOT_VERIFIED'
            else:
                rows = response['candles']
                if len(rows) > MAX_RESPONSE_ROWS:
                    item['status'] = 'RESPONSE_BOUND_EXCEEDED'
                    continue
                normalized = normalize_history_rows(rows, scope['contract_id'], oi_enabled=settings.history.oi_flag,
                                                     session=settings.session)
                matching = [c for c in normalized.valid if c.timestamp.date() == day]
                wrong_date = len(normalized.valid) - len(matching)
                item.update(status='DATA_NOW_AVAILABLE_REVIEW_REQUIRED' if matching else 'PROVIDER_ROWS_NOT_USABLE',
                            raw_rows=len(rows), valid_rows_in_date=len(matching), wrong_date_rows=wrong_date,
                            rejected_reasons=dict(Counter(r.reason for r in normalized.invalid)),
                            response_duplicates=normalized.response_duplicates,
                            oi_present_rows=sum(c.oi is not None for c in matching))
        except KeyboardInterrupt:
            item['status'] = 'INTERRUPTED_RESPONSE_UNCONFIRMED'; stopped = True
        except Exception:
            item['status'] = 'REQUEST_OR_SOURCE_UNAVAILABLE'; stopped = True
    return {'status': ('RECHECK_OBSERVATIONS' if scopes else 'NO_EMPTY_SCOPES') if not stopped else 'PARTIAL',
            'observed_at': now.isoformat(), 'checks': checks,
            'summary': {'selected_empty_scopes': len(scopes), 'history_call_attempts': requests,
                        'statuses': dict(Counter(c['status'] for c in checks))},
            'configured_session_context': {'calendar_snapshot_sha256': fingerprint(calendar_metadata()),
                'current_status': {s: live_session_status(now, s, session=settings.session if s == 'FNO' else None)
                                   for s in ('CASH', 'FNO')},
                'independently_confirmed': False},
            'external_evidence_verified': False, 'unit_scale_verified': False, 'live_verified': False,
            'sql_modified': False, 'market_data_modified': False, 'automatic_import_or_repair': False,
            'limits': {'max_scopes': MAX_SCOPES, 'max_response_rows_per_scope': MAX_RESPONSE_ROWS,
                       'max_attempts_per_scope': 1},
            'scope': 'One fresh provider history response per still-empty unexpired reviewed scope. Repeated NO_DATA does not prove zero trades or explain provider absence. Returned rows are not stored or independently verified; explicit recovery is required if data becomes available. This cannot confirm units, exchange hours, live reception or index alignment.'}
