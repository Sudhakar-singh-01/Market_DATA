"""
controller/live_controller.py
Orchestrates live ingestion (spec Section 20). Wires:
    model.fyers.websocket (transport)
    -> model.processing.normalizer.normalize_live_tick (raw -> Tick)
    -> model.processing.candle_builder.CandleBuilder1m (Tick -> closed bucket)
    -> model.processing.normalizer.normalize_live_candle (bucket -> Candle)
    -> model.processing.validator.validate_candle
    -> CandleSink (controller/sinks.py)

Does NOT implement storage code (spec Section 20).
"""

import logging
import signal
import sys
import threading
import datetime
import collections

from model.processing.models import IST
from model.config.instrument_loader import InstrumentRegistry
from model.config.data_settings import DataSettings
from model.fyers.websocket import FyersWebSocketClient
from model.fyers.historical import fetch_historical_1m
from model.processing.normalizer import normalize_live_tick, normalize_live_candle, normalize_historical_candle, NormalizationError
from model.processing.candle_builder import CandleBuilder1m
from model.processing.timeframe_aggregator import LiveTimeframeAggregator
from model.processing.validator import validate_candle, validate_candles
from controller.sinks import CandleSink, NoOpCandleSink

log = logging.getLogger("market_data.controller.live")


class LiveIngestionController:
    def __init__(
        self,
        access_token_ws: str,
        instruments: InstrumentRegistry,
        data_settings: DataSettings,
        symbol_filter=None,
        sink: CandleSink = None,
        derived_timeframes=None,
        historical_client=None,
        clock=None,
    ):
        """
        historical_client: an authenticated FYERS REST client (as
        returned by model.fyers.auth.get_authenticated_client), used
        ONLY for gap-backfill after a WebSocket reconnect (spec Section
        22). Optional -- if not supplied, gap-backfill is skipped and
        only logged as a warning; the live pipeline still works, it
        just won't retroactively fill a reconnect gap.
        """
        self._clock = clock or (lambda: datetime.datetime.now(IST))
        self._stop_event = threading.Event()
        self._stop_lock = threading.Lock()
        self.session_reason = None
        self._instruments = instruments
        self._data_settings = data_settings
        self._sink = sink or NoOpCandleSink()
        self._historical_client = historical_client
        self._last_closed_1m_ts: dict = {}  # fyers_symbol -> datetime, for gap-backfill
        self._last_volume: dict = {}  # symbol -> (closed minute, cumulative volume)

        selected = self._select_instruments(symbol_filter)
        if not selected:
            raise ValueError("No matching active instruments to subscribe to for live ingestion.")
        self._instruments_by_symbol = {i.fyers_symbol: i for i in selected}
        fyers_symbols = list(self._instruments_by_symbol.keys())

        log.info(f"Live ingestion: {len(fyers_symbols)} instrument(s) selected for subscription")

        self._candle_builder = CandleBuilder1m(on_candle_closed=self._handle_closed_1m_bucket)
        # Live incremental higher-timeframe aggregation (spec Section
        # 15-17). Uses the SAME aggregate math as the historical batch
        # path (model/processing/timeframe_aggregator.py) so live and
        # historical derived candles can never diverge (spec Section 29).
        self._timeframe_aggregator = LiveTimeframeAggregator(timeframes=derived_timeframes)
        self._ws_client = FyersWebSocketClient(
            access_token=access_token_ws,
            symbols=fyers_symbols,
            on_tick=self._handle_raw_message,
            reconnect_settings=data_settings.reconnect,
            on_reconnect=self._handle_reconnect,
        )
        self._received_count = 0
        self._closed_1m_count = 0
        self._closed_derived_count = 0
        self._last_tick_by_symbol: dict = {}  # fyers_symbol -> Tick, for Live Market UI (real data, not fabricated)
        self._tick_lock = threading.Lock()
        # Per-candle delay log (newest last). delay = time we received/closed the
        # candle MINUS the candle's end time (candle_timestamp + 1 minute).
        self._delay_log = collections.deque(maxlen=1000)

    def latest_ticks(self) -> dict:
        """Snapshot of the most recent Tick per subscribed symbol. Used
        by the dashboard's Live Market page for LTP/OHLC/change --
        sourced directly from real FYERS ticks, not derived/guessed."""
        with self._tick_lock:
            return dict(self._last_tick_by_symbol)

    def delay_records(self) -> list:
        """Snapshot of recent per-candle delay records (newest last)."""
        return list(self._delay_log)

    def delay_stats(self) -> dict:
        recs = self.delay_records()
        if not recs:
            return {"count": 0}
        d = [r["delay_s"] for r in recs]
        return {"count": len(d), "last_s": d[-1], "avg_s": sum(d) / len(d), "max_s": max(d), "min_s": min(d)}

    @property
    def subscribed_instrument_count(self) -> int:
        return len(self._instruments_by_symbol)

    def _select_instruments(self, symbol_filter) -> list:
        if not symbol_filter or symbol_filter == ["all"]:
            return self._instruments.active_instruments()
        if symbol_filter == ["stocks"]:
            return self._instruments.active_stocks()
        if symbol_filter == ["indices"]:
            return self._instruments.active_indices()
        selected = []
        for name in symbol_filter:
            try:
                instrument = self._instruments.get(name)
            except KeyError:
                log.warning(f"Requested instrument '{name}' not found in registry, skipping")
                continue
            if instrument.active:
                selected.append(instrument)
        return selected

    def _handle_raw_message(self, raw_message: dict):
        if self._stop_event.is_set():
            return
        tick = normalize_live_tick(raw_message)
        if tick is None:
            return

        if tick.fyers_symbol not in self._instruments_by_symbol:
            return
        from model.monitoring import emit
        emit("TICK_RECEIVED",{"exchange_timestamp":tick.timestamp.isoformat()},tick.fyers_symbol,throttle_seconds=30)
        self._received_count += 1
        if self._received_count % 500 == 0:
            # Deliberately NOT logging every tick (spec Section 24:
            # "Do not log every tick by default").
            log.info(f"Live ticks received so far: {self._received_count}")

        with self._tick_lock:
            self._last_tick_by_symbol[tick.fyers_symbol] = tick

        self._candle_builder.on_tick(tick)

    def _handle_closed_1m_bucket(self, bucket):
        """
        Called when candle_builder closes a 1m bucket. Workflow (spec
        Section 19): normalize -> validate -> STORE 1m -> feed into
        timeframe aggregator -> validate any newly-closed derived
        candles -> store them. 1m storage happens BEFORE aggregation
        so the aggregator's job is fully decoupled from storage
        latency/failures -- a slow/failing 1m store still lets
        aggregation proceed with the in-memory candle.
        """
        received_at = datetime.datetime.now(tz=IST)  # moment this closed candle reached us
        instrument = self._instruments_by_symbol.get(bucket.fyers_symbol)
        if instrument is None:
            log.warning(f"Closed 1m candle for unrecognized symbol '{bucket.fyers_symbol}', dropping")
            return

        candle_1m = normalize_live_candle(bucket, instrument, status="CLOSED")
        previous = self._last_volume.get(bucket.fyers_symbol)
        if (previous is not None and bucket.volume_last is not None
                and bucket.period_start == previous[0] + datetime.timedelta(minutes=1)
                and bucket.period_start.date() == previous[0].date()
                and bucket.volume_start is not None and bucket.volume_start >= previous[1]
                and bucket.volume_last >= bucket.volume_start):
            candle_1m.volume = bucket.volume_last - previous[1]
        if bucket.volume_last is not None:
            self._last_volume[bucket.fyers_symbol] = (bucket.period_start, bucket.volume_last)
        else:
            self._last_volume.pop(bucket.fyers_symbol, None)

        if self._data_settings.validation_enabled:
            result = validate_candle(candle_1m, instruments=self._instruments)
            if result.status == "invalid":
                log.warning(f"{candle_1m.fyers_symbol}: invalid live 1m candle at {candle_1m.timestamp}: {result.errors}")
                return
            if result.status == "warning":
                log.info(f"{candle_1m.fyers_symbol}: live 1m candle warning at {candle_1m.timestamp}: {result.warnings}")

        self._closed_1m_count += 1
        accepted = self._sink.write_one(candle_1m)
        if isinstance(accepted, list):
            if len(accepted) != 1 or (accepted[0].fyers_symbol, accepted[0].timestamp, accepted[0].timeframe) != (candle_1m.fyers_symbol, candle_1m.timestamp, '1m'):
                raise RuntimeError('Live canonical read-back changed candle identity')
            candle_1m = accepted[0]
        stored_at = datetime.datetime.now(tz=IST)
        self._last_closed_1m_ts[candle_1m.fyers_symbol] = candle_1m.timestamp
        try:
            candle_end = candle_1m.timestamp + datetime.timedelta(minutes=1)
            self._delay_log.append({
                "symbol": instrument.internal_name,
                "candle_start": candle_1m.timestamp,
                "candle_end": candle_end,
                "received_at": received_at,
                "stored_at": stored_at,
                "delay_s": (received_at - candle_end).total_seconds(),
                "store_delay_s": (stored_at - candle_end).total_seconds(),
            })
        except Exception:
            pass  # delay tracking must never break ingestion

        # Feed into higher-timeframe aggregation (spec Section 15-16).
        # Do not wait for a historical reload -- this uses only the
        # just-closed 1m candle plus whatever in-memory state the
        # aggregator already has for this symbol.
        for derived_candle in self._timeframe_aggregator.on_1m_candle(candle_1m):
            self._handle_closed_derived_candle(derived_candle)

    def _handle_closed_derived_candle(self, candle):
        if self._data_settings.validation_enabled:
            result = validate_candle(candle, instruments=self._instruments)
            if result.status == "invalid":
                log.warning(f"{candle.fyers_symbol} [{candle.timeframe}]: invalid derived candle at {candle.timestamp}: {result.errors}")
                return
            if result.status == "warning":
                log.info(f"{candle.fyers_symbol} [{candle.timeframe}]: derived candle warning at {candle.timestamp}: {result.warnings}")

        self._closed_derived_count += 1
        log.info(f"Derived candle stored: {candle.fyers_symbol} [{candle.timeframe}] {candle.timestamp}")
        self._sink.write_one(candle)

    def _handle_reconnect(self):
        """
        Gap-recovery (spec Section 22): a WebSocket reconnect alone does
        NOT guarantee no 1m candles were missed while disconnected --
        this backfills that gap from the FYERS Historical API before
        resuming live processing normally (the caller doesn't need to
        do anything else; ticks keep flowing into _handle_raw_message
        as usual once this returns).

        Uses TODAY's date only (Asia/Kolkata) as the backfill window,
        since the last-known 1m timestamp per symbol is only tracked
        for the current session -- a reconnect after a multi-day outage
        is out of scope for this automatic backfill and would need a
        manual `historical` run instead.
        """
        self._last_volume.clear()
        self._candle_builder.reset_volume_baselines()
        if self._historical_client is None:
            log.warning(
                "WebSocket reconnected but no historical_client was configured for gap-backfill -- "
                "any 1m candles missed during the disconnect will NOT be automatically recovered. "
                "See LiveIngestionController's historical_client parameter."
            )
            return

        reconnect_at = self._clock().astimezone(IST)
        reconnect_minute = reconnect_at.replace(second=0, microsecond=0)
        today = reconnect_at.date().isoformat()
        for fyers_symbol, instrument in self._instruments_by_symbol.items():
            last_ts = self._last_closed_1m_ts.get(fyers_symbol)
            if last_ts is None:
                continue  # no 1m candle closed yet this session -- nothing to backfill from

            gap_start = (last_ts + datetime.timedelta(minutes=1)).date().isoformat()
            log.info(f"{fyers_symbol}: reconnect gap-backfill, range {gap_start}..{today}")
            try:
                raw_rows = fetch_historical_1m(
                    self._historical_client, fyers_symbol, gap_start, today,
                    retry_settings=self._data_settings.retry,
                )
            except Exception as exc:
                log.error(f"{fyers_symbol}: reconnect gap-backfill failed: {exc}")
                continue

            candles = []
            for row in raw_rows:
                try:
                    candle = normalize_historical_candle(row, instrument, timeframe="1m")
                    # Only completed minutes strictly inside the disconnect gap.
                    # The reconnect minute may already be forming from live ticks;
                    # treating a provider row for it as CLOSED would race/overwrite
                    # the active builder on historical/live overlap.
                    if (last_ts < candle.timestamp < reconnect_minute
                            and candle.timestamp.date().isoformat() == today
                            and not candle.timestamp.second and not candle.timestamp.microsecond):
                        candles.append(candle)
                except NormalizationError as exc:
                    log.warning(f"{fyers_symbol}: skipping gap-backfill row that failed normalization: {exc}")

            if not candles:
                continue

            if self._data_settings.validation_enabled:
                results = validate_candles(candles, instruments=self._instruments)
                valid_candles = [r.candle for r in results if r.status in ("valid", "warning")]
            else:
                valid_candles = candles

            accepted = self._sink.write_batch(valid_candles)
            if accepted is not None:
                valid_candles = accepted
            for candle in sorted(valid_candles, key=lambda c: c.timestamp):
                for derived_candle in self._timeframe_aggregator.on_1m_candle(candle):
                    self._handle_closed_derived_candle(derived_candle)
                self._last_closed_1m_ts[fyers_symbol] = candle.timestamp
            bucket = self._candle_builder.current_bucket(fyers_symbol)
            if bucket is not None and any(c.timestamp == bucket.period_start for c in valid_candles):
                self._candle_builder.discard(fyers_symbol)

            log.info(f"{fyers_symbol}: reconnect gap-backfill stored {len(valid_candles)} 1m candle(s)")

    def start(self):
        log.info("Live ingestion starting")
        shutdown_requested = {"flag": False}

        def _do_shutdown(reason):
            if shutdown_requested["flag"]:
                log.warning(f"Second shutdown request ({reason}) -- forcing immediate exit")
                import os
                os._exit(1)
            shutdown_requested["flag"] = True
            log.info(f"Shutdown requested ({reason}) -- stopping "
                     f"(Ctrl+C again, or type stop/q again, to force-quit)")
            self.stop()

        def _signal_handler(signum, frame):
            _do_shutdown(f"signal {signum}")

        # signal.signal() only works when called from the interpreter's
        # main thread. When this controller is driven from a background
        # thread (e.g. the Streamlit dashboard's LiveRunManager runs
        # start() on a daemon thread so the UI doesn't freeze), calling
        # it would raise ValueError and abort live ingestion immediately
        # -- which would look exactly like "live data isn't coming in".
        # In that case the caller (e.g. the dashboard's Stop button)
        # is expected to call .stop() directly instead of relying on
        # OS signals, so we just skip signal/stdin wiring entirely.
        is_main_thread = threading.current_thread() is threading.main_thread()
        if is_main_thread:
            signal.signal(signal.SIGINT, _signal_handler)
            signal.signal(signal.SIGTERM, _signal_handler)

            def _stdin_listener():
                # Fallback shutdown path for environments where Ctrl+C/
                # SIGINT isn't reliably delivered to this process (some
                # IDE run panels, redirected/piped consoles, certain
                # Windows terminal setups). Type 'stop' or 'q' + Enter
                # at any time to shut down gracefully without depending
                # on OS signal delivery.
                try:
                    for line in sys.stdin:
                        if line.strip().lower() in ("stop", "quit", "exit", "q"):
                            _do_shutdown("stdin command")
                            break
                except Exception:
                    pass  # stdin may be unavailable (e.g. run as a service) -- ignore

            threading.Thread(target=_stdin_listener, daemon=True).start()
            print("Live ingestion running. Press Ctrl+C, or type 'stop' and Enter, to shut down.")
        else:
            log.info("Running on a background thread (e.g. dashboard-managed) -- "
                     "skipping OS signal/stdin shutdown wiring; call .stop() directly to stop.")

        try:
            self._ws_client.connect_and_run()  # idle connections are allowed off-market
        finally:
            self.stop()
        return {"open": False, "reason": self.session_reason}

    def stop(self):
        with self._stop_lock:
            if self._stop_event.is_set():
                return
            self._stop_event.set()
            self._ws_client.stop()
            now = self._clock()
            # Only real, completed buckets become CLOSED. A partial minute is
            # preserved as OPEN and is never fed into derived aggregation.
            for symbol, instrument in self._instruments_by_symbol.items():
                bucket = self._candle_builder.current_bucket(symbol)
                if bucket is None:
                    continue
                if now >= bucket.period_start + datetime.timedelta(minutes=1):
                    self._candle_builder.flush(symbol)
                else:
                    self._sink.write_one(normalize_live_candle(bucket, instrument, status="OPEN"))
            for candle in self._timeframe_aggregator.flush_all():
                self._handle_closed_derived_candle(candle)
