"""
controller/fno_historical.py
FNO history = HARVEST of ACTIVE contracts (capture-forward). Expired contracts are never
fetched; any still-missing range of an expired contract is recorded EXPIRED_UNRECOVERABLE.

Pipeline per request:  plan -> rate-limited fetch -> normalise -> validate -> MySQL upsert
-> MySQL read-back -> Parquet write (+ validation, manifest VERIFIED) -> checkpoint.
A response alone NEVER advances a checkpoint; a range becomes VERIFIED only after every
enabled store has verified its write. Order: MySQL first, then Parquet, then checkpoint.
"""
from model.fno.capabilities import UnsupportedCapabilityError
import datetime
import logging
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from controller.fno_jobs import JobHandle, JobOutcome
from controller import worker_lifecycle as lifecycle
from model.fno import ranges as rng
from model.fno.config import FnoSettings
from model.fno.errors import TokenExpiredError
from model.fno.history_client import (FnoHistoryFetcher, TransientFetchError, OK, NO_DATA, INVALID_SYMBOL, ERROR)
from model.fno.models import (IST, CATEGORY_FUTURES, CATEGORY_OPTIONS, STATUS_ACTIVE, STATUS_EXPIRED,
                              R_VERIFIED, R_NO_DATA, R_FAILED, R_EXPIRED, WriteResult)
from model.fno.normalizer import normalize_history_rows, Rejected
from model.fyers.rate_limiter import DailyQuotaExhausted

log = logging.getLogger("market_data.fno.historical")
JOB_TYPE = "HISTORICAL_HARVEST"
CKPT_JOB = "HISTORICAL"
TF = "1m"


class AtmUnavailable(Exception):
    pass


@dataclass
class PlanItem:
    contract: object
    range_from: datetime.date
    range_to: datetime.date
    days_to_expiry: int


@dataclass
class HarvestPlan:
    items: list = field(default_factory=list)
    contracts_selected: int = 0
    unrecoverable: list = field(default_factory=list)       # (contract, from, to) of EXPIRED contracts
    effective_to: Optional[datetime.date] = None

    @property
    def estimated_requests(self) -> int:
        return len(self.items)

    def estimate(self, per_second: float, per_day: int, reserve: float) -> dict:
        eff_rate = max(0.1, per_second * (1 - reserve))
        return {"requests": self.estimated_requests, "contracts": self.contracts_selected,
                "min_seconds": round(self.estimated_requests / eff_rate, 1),
                "share_of_daily_budget_pct": round(100.0 * self.estimated_requests / max(1, per_day * (1 - reserve)), 2),
                "expired_unrecoverable_ranges": len(self.unrecoverable)}


def last_complete_day(now: datetime.datetime, buffer_minutes: int, close: datetime.time = datetime.time(15, 40)) -> datetime.date:
    """Today's data is only complete after close + buffer; before that, the last complete day is yesterday."""
    now = now.astimezone(IST) if now.tzinfo else now
    close_dt = datetime.datetime.combine(now.date(), close) + datetime.timedelta(minutes=buffer_minutes)
    return now.date() if now.replace(tzinfo=None) >= close_dt else now.date() - datetime.timedelta(days=1)


def select_contracts(contracts: list, underlyings, expiries_ahead: int, strike_window: int, include_futures: bool,
                     include_options: bool, today: datetime.date, atm: dict) -> list:
    """Universe selection: nearest N expiries per underlying and category; options limited to
    ATM +/- strike_window strikes. Only ACTIVE, not-yet-expired contracts are ever selected."""
    chosen = []
    for und in (u.upper() for u in underlyings):
        mine = [c for c in contracts if c.underlying == und and c.status == STATUS_ACTIVE and c.expiry >= today]
        if include_futures:
            fut = [c for c in mine if c.category == CATEGORY_FUTURES]
            exps = sorted({c.expiry for c in fut})[:expiries_ahead]
            chosen += [c for c in fut if c.expiry in exps]
        if include_options:
            opt = [c for c in mine if c.category == CATEGORY_OPTIONS]
            if not opt:
                continue
            spot = atm.get(und)
            if spot is None:
                raise AtmUnavailable(f"No ATM/spot reference for {und}: pass --atm {und}=<price> or enable its spot symbol.")
            for exp in sorted({c.expiry for c in opt})[:expiries_ahead]:
                strikes = sorted({c.strike for c in opt if c.expiry == exp})
                center = min(range(len(strikes)), key=lambda i: abs(strikes[i] - Decimal(str(spot))))
                keep = set(strikes[max(0, center - strike_window): center + strike_window + 1])
                chosen += [c for c in opt if c.expiry == exp and c.strike in keep]
    return chosen


def build_plan(repo, contracts: list, from_date: datetime.date, to_date: datetime.date, today: datetime.date,
               now: datetime.datetime, settings: FnoSettings, all_universe_contracts: Optional[list] = None) -> HarvestPlan:
    h = settings.history
    complete_to = min(to_date, last_complete_day(now, h.session_close_buffer_minutes, settings.session.close))
    plan = HarvestPlan(effective_to=complete_to, contracts_selected=len(contracts))
    for c in contracts:
        if c.expiry < today or c.status == STATUS_EXPIRED:
            continue                                            # never fetch expired contracts
        end = min(complete_to, c.expiry)
        if from_date > end:
            continue
        for a, b in repo.missing_ranges(c.contract_id, CKPT_JOB, TF, from_date, end):
            for ca, cb in rng.chunk_range(a, b, h.max_days_per_request):
                plan.items.append(PlanItem(c, ca, cb, (c.expiry - today).days))
    # Expired contracts we were tracking (real stored symbols only). If expired_history is enabled and the
    # contract is young enough we ATTEMPT the fetch and let FYERS decide; otherwise whatever is missing is
    # recorded as EXPIRED_UNRECOVERABLE without a request. Ranges already marked EXPIRED_UNRECOVERABLE are
    # terminal and are never planned again.
    tracked = repo.harvest_tracked_ids()
    for c in (all_universe_contracts or []):
        if c.contract_id not in tracked or not (c.status == STATUS_EXPIRED or c.expiry < today):
            continue
        end = min(to_date, c.expiry)
        if from_date > end:
            continue
        existing = repo.get_checkpoint_ranges(c.contract_id, CKPT_JOB, TF)
        missing = rng.missing_days(from_date, end, existing, done_statuses={"VERIFIED","NO_DATA"})
        age = (today - c.expiry).days
        attempt = settings.expired_history_enabled
        for a, b in missing:
            if attempt:
                for ca, cb in rng.chunk_range(a, b, h.max_days_per_request):
                    plan.items.append(PlanItem(c, ca, cb, -age))        # negative days-to-expiry: most urgent first
            else:
                plan.unrecoverable.append((c, a, b))
    plan.items.sort(key=lambda i: (i.days_to_expiry, i.contract.fyers_symbol, i.range_from))
    return plan


@dataclass
class HarvestContext:
    repo: object
    fetcher: FnoHistoryFetcher
    store: Optional[object]            # FnoParquetStore or None when Parquet is disabled
    settings: FnoSettings
    clock: callable = lambda: datetime.datetime.now(tz=IST)


def params_to_selection(params: dict, settings: FnoSettings) -> dict:
    u = settings.universe
    return {
        "underlyings": params.get("underlyings") or list(u.underlyings),
        "expiries_ahead": int(params.get("expiries_ahead", u.expiries_ahead)),
        "strike_window": int(params.get("strike_window", u.strike_window)),
        "include_futures": bool(params.get("include_futures", u.include_futures)),
        "include_options": bool(params.get("include_options", u.include_options)),
    }


def make_plan_from_params(ctx: HarvestContext, params: dict) -> HarvestPlan:
    now = ctx.clock(); today = now.date()
    sel = params_to_selection(params, ctx.settings)
    from_d = datetime.date.fromisoformat(params["from"]); to_d = datetime.date.fromisoformat(params["to"])
    universe = ctx.repo.get_contracts(status=None)
    universe = [c for c in universe if c.underlying in {x.upper() for x in sel["underlyings"]}]
    chosen = select_contracts(universe, today=today, atm=params.get("atm") or {}, **sel)
    return build_plan(ctx.repo, chosen, from_d, to_d, today, now, ctx.settings, all_universe_contracts=universe)


def persist_chunk(ctx: HarvestContext, item: PlanItem, candles: list, job_id: int) -> WriteResult:
    """MySQL first (+ read-back), then Parquet (+ its own validation). Raises on any failure."""
    state = {"atomic": False, "sql_write_started": False, "sql_write_completed": False,
             "sql_rows_changed": 0, "parquet_required": ctx.store is not None,
             "parquet_write_started": False, "parquet_write_completed": False,
             "contract_id": item.contract.contract_id,
             "from": str(item.range_from), "to": str(item.range_to)}
    try:
        lifecycle.check()
        state["sql_write_started"] = True
        result = ctx.repo.upsert_candles(candles)
        state["sql_write_completed"] = True
        state["sql_rows_changed"] = getattr(result, "stored", 0)
        if not ctx.repo.verify_candles_present(candles):
            raise RuntimeError("MySQL read-back verification failed")
        if ctx.store is not None:
            lifecycle.check()
            meta = {item.contract.contract_id: (item.contract.underlying, item.contract.expiry)}
            # Mirror the accepted MySQL values, not rejected conflicting API rows.
            accepted = ctx.repo.accepted_candles(candles)
            expected_keys = {(c.contract_id, c.timeframe, c.naive_ist()) for c in candles}
            accepted_keys = {(c.contract_id, c.timeframe, c.naive_ist()) for c in accepted}
            if accepted_keys != expected_keys or len(accepted) != len(expected_keys):
                raise RuntimeError("MySQL canonical read-back was incomplete or changed scope")
            state["parquet_write_started"] = True
            pq = ctx.store.write_candles(accepted, meta, job_id=job_id)
            state["parquet_write_completed"] = True
            result.parquet_quarantined = len(getattr(pq, "quarantined_existing", None) or [])
        return result
    except Exception as exc:
        state['error_type'] = type(exc).__name__
        state['next_action'] = 'Run scoped SQL/Parquet verification before explicit resume; a failed write may have partially completed.'
        exc.recovery_state = state
        raise



def run_harvest(handle: JobHandle, ctx: HarvestContext) -> JobOutcome:
    params = handle.params
    plan = make_plan_from_params(ctx, params)
    c = {"items": len(plan.items), "verified": 0, "stored_unverified": 0, "no_data": 0, "failed": 0, "conflicts": 0,
         "unrecoverable_marked": 0, "expired_requests": 0, "live_superseded": 0, "live_superseded_changed": 0, "live_diff_fields": {},
         "response_duplicates": 0, "parquet_quarantined": 0, "invalid_symbol": 0, "invalid_reasons": {}, "storage_failures": []}
    failures, aborted = [], None
    # 1) expired contracts: record what can never be fetched (not an error, not retried)
    for contract, a, b in plan.unrecoverable:
        failures.append(f"{contract.fyers_symbol}: expired retrieval disabled; capability/entitlement review required")
        c["failed"] += 1
    # 2) harvest active contracts, soonest expiry first
    last_ok: dict = {}
    seen_contracts: dict = {}
    for item in plan.items:
        stop = handle.stop_outcome()
        if stop:
            aborted = stop; break
        con = item.contract
        c["expired_requests"] += item.days_to_expiry < 0
        seen_contracts[con.contract_id] = con
        try:
            if item.days_to_expiry<0:
                if not hasattr(ctx.fetcher,'fetch_expired'):raise UnsupportedCapabilityError('Expired history adapter unavailable')
                res=ctx.fetcher.fetch_expired(con,item.range_from,item.range_to)
            else:res = ctx.fetcher.fetch(con.fyers_symbol, item.range_from, item.range_to)
        except UnsupportedCapabilityError as exc:
            aborted=JobOutcome("PARTIAL",{},str(exc));break
        except TokenExpiredError as exc:
            aborted = JobOutcome("FAILED", {}, str(exc)); break                      # fail clearly, no retry loop
        except DailyQuotaExhausted as exc:
            aborted = JobOutcome("PARTIAL", {}, str(exc)); break
        except TransientFetchError as exc:
            c["failed"] += 1; failures.append(str(exc))
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_FAILED, error=str(exc))
            handle.add(retry_count=ctx.settings.history.max_retries, requests_made=ctx.settings.history.max_retries + 1)
            continue
        # The provider contract has completed.  Finish validation, both durable
        # stores and the checkpoint for this chunk before honoring a graceful
        # stop.  JobHandle's contract is "stop after the current contract";
        # abandoning the fetched response here repeated provider work on resume.
        handle.add(requests_made=res.requests, retry_count=res.retries)
        if res.status == NO_DATA:
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_NO_DATA)
            c["no_data"] += 1; handle.add(no_data_count=1); continue
        if res.status == INVALID_SYMBOL and item.days_to_expiry < 0:
            # expired contract that FYERS no longer serves: terminal, recorded once, not a failure, never retried
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_FAILED,
                                          error=f"Expired symbol rejected (code {res.code}); check expired-contract discovery and entitlement")
            c["failed"] += 1
            failures.append('Expired symbol rejected; remains reviewable/retryable')
            continue
        if res.status in (INVALID_SYMBOL, ERROR):
            c["failed"] += 1; c["invalid_symbol"] += res.status == INVALID_SYMBOL
            msg = f"{con.fyers_symbol}: {res.status} (code {res.code}) {res.message}"
            if res.status == INVALID_SYMBOL:
                msg += " -- ACTIVE contract rejected as invalid; not retried in this run"
            failures.append(msg)
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_FAILED, error=msg)
            continue
        if item.days_to_expiry<0:
            from model.fno.normalizer import normalize_expired_rows
            norm=normalize_expired_rows(res.rows,getattr(res,'columns',None),con.contract_id,ctx.settings.session)
        else:
            norm = normalize_history_rows(res.rows, con.contract_id, TF, oi_enabled=ctx.settings.history.oi_flag,
                                          session=ctx.settings.session)
        # A provider can return structurally valid candles outside its requested
        # range. Do not persist them or certify this request using their presence.
        in_scope = []
        for candle in norm.valid:
            if item.range_from <= candle.timestamp.astimezone(IST).date() <= item.range_to:
                in_scope.append(candle)
            else:
                norm.invalid.append(Rejected(candle, "outside_requested_range"))
        norm.valid = in_scope
        c["response_duplicates"] += norm.response_duplicates
        for rej in norm.invalid:
            c["invalid_reasons"][rej.reason] = c["invalid_reasons"].get(rej.reason, 0) + 1
        handle.add(rows_raw=norm.raw_count, rows_valid=len(norm.valid), rows_invalid=len(norm.invalid))
        if not norm.valid:
            c["failed"] += 1
            msg = f"{con.fyers_symbol}: all {norm.raw_count} rows rejected by validation"
            failures.append(msg)
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_FAILED, error=msg)
            continue
        try:
            w = persist_chunk(ctx, item, norm.valid, handle.id)
        except lifecycle.WorkerInterrupted as exc:
            if getattr(exc, "recovery_state", None):c["storage_failures"].append(exc.recovery_state)
            aborted = JobOutcome("INTERRUPTED", {}, "Storage interrupted; range remains retryable")
            break
        except Exception as exc:                                                    # partial storage failure
            if getattr(exc, "recovery_state", None):c["storage_failures"].append(exc.recovery_state)
            c["failed"] += 1
            msg = f"{con.fyers_symbol} {item.range_from}..{item.range_to}: storage failed ({type(exc).__name__}: {exc})"
            failures.append(msg); log.error(msg)
            ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_FAILED, error=msg)
            continue
        handle.add(rows_stored=w.stored, rows_duplicate=w.duplicate)
        c["conflicts"] += w.conflicts
        c["live_superseded"] += w.superseded_live; c["live_superseded_changed"] += w.superseded_changed
        c["parquet_quarantined"] += w.parquet_quarantined
        for k, v in w.superseded_fields.items():
            c["live_diff_fields"][k] = c["live_diff_fields"].get(k, 0) + v
        if w.conflicts or norm.invalid:
            c["failed"] += 1
            c["stored_unverified"] += len(norm.valid)
            msg = f"{con.fyers_symbol}: {w.conflicts} CLOSED conflicts and {len(norm.invalid)} invalid rows; range not verified"
            failures.append(msg)
            ctx.repo.add_checkpoint_range(con.contract_id,CKPT_JOB,TF,item.range_from,item.range_to,R_FAILED,error=msg)
            continue
        ctx.repo.add_checkpoint_range(con.contract_id, CKPT_JOB, TF, item.range_from, item.range_to, R_VERIFIED)   # LAST
        c["verified"] += 1
        last_ok[con.contract_id] = max(item.range_to, last_ok.get(con.contract_id, item.range_to))
        handle.heartbeat()
        stop = handle.stop_outcome()
        if stop:
            aborted = stop; break
    # 3) harvest_state bookkeeping
    today = ctx.clock().date()
    for cid, con in seen_contracts.items():
        remaining = ctx.repo.missing_ranges(cid, CKPT_JOB, TF, datetime.date.fromisoformat(params["from"]),
                                            min(plan.effective_to, con.expiry)) if plan.effective_to >= datetime.date.fromisoformat(params["from"]) else []
        ctx.repo.upsert_harvest_state(cid, con.expiry, (con.expiry - today).days, "UP_TO_DATE" if not remaining else "FAILED",
                                      last_harvested_date=last_ok.get(cid), next_due=today + datetime.timedelta(days=1))
    result = {**c, "failures": failures[:25], "failure_count": len(failures),
              "effective_to": str(plan.effective_to), "estimate": plan.estimate(
                  ctx.settings.rate_limits.per_second, ctx.settings.rate_limits.per_day, ctx.settings.rate_limits.fno_reserve_fraction)}
    if aborted:
        aborted.result = {**result, **aborted.result}
        if aborted.state == "FAILED" and c["verified"] + c["no_data"] > 0:
            aborted.state = "PARTIAL"
        return aborted
    if not plan.items and not plan.unrecoverable:
        return JobOutcome("SUCCESS", {**result, "note": "nothing to fetch: everything requested is already checkpointed"})
    if c["failed"] == 0:
        return JobOutcome("NO_DATA" if c["verified"] == 0 and c["no_data"] > 0 else "SUCCESS", result)
    if c["verified"] + c["no_data"] + c["stored_unverified"] > 0:
        return JobOutcome("PARTIAL", result, f"{c['failed']} request(s) failed; first: {failures[0]}")
    return JobOutcome("FAILED", result, f"all {c['failed']} request(s) failed; first: {failures[0]}")


def fetch_atm(client, settings: FnoSettings, underlyings) -> dict:
    """ATM reference = spot/index last price, ONE quotes call for all configured spot symbols.
    Underlyings whose price could not be read are simply absent (the planner then refuses options for them)."""
    sym_by_und = {u: settings.universe.spot_symbols[u] for u in (x.upper() for x in underlyings)
                  if u in settings.universe.spot_symbols}
    if not sym_by_und:
        return {}
    resp = client.quotes(data={"symbols": ",".join(sym_by_und.values())})
    out = {}
    try:
        by_sym = {d.get("n"): d for d in resp.get("d", [])}
        for u, sym in sym_by_und.items():
            d = by_sym.get(sym)
            lp = None if d is None else (d.get("v") or d).get("lp")
            if lp is not None:
                out[u] = float(lp)
    except (AttributeError, TypeError, ValueError):
        return {}
    return out
