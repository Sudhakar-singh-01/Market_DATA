@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Project .venv missing. Install the documented project dependencies first.
  exit /b 1
)
".venv\Scripts\python.exe" -m tools.market_logic_check %*
exit /b %errorlevel%
