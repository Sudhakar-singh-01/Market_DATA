"""Loaded only by the isolated Phase 9 runner; never contacts a MySQL server."""
import pytest


def pytest_runtest_setup(item):
    if {'fno_engine', 'a_engine', 'clean_fno'} & set(item.fixturenames):
        pytest.skip('Phase 9 provider-free validation excludes MySQL-backed fixtures')
