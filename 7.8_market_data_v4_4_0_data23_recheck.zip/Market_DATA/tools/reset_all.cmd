@echo off
setlocal
cd /d "%~dp0\.."
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Project .venv was not found. 1>&2
  exit /b 2
)
REM This launcher only PREVIEWS. It does not reset SQL or move/delete files.
".venv\Scripts\python.exe" -m controller.reset_cli preview --output reset_preview.json
exit /b %ERRORLEVEL%
