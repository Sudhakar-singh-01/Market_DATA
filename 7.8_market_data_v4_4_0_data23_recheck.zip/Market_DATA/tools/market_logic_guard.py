"""Safety boundary used only by the backend acceptance runner."""
import sys
import socket
from tools.phase9_pytest_guard import pytest_runtest_setup  # noqa: F401

_PAIR_CODES = {fn.__code__ for name in ('socketpair', '_fallback_socketpair')
               if (fn := getattr(socket, name, None)) is not None and hasattr(fn, '__code__')}


def block_network(event, args):
    if event in {'socket.connect', 'socket.getaddrinfo', 'socket.gethostbyname'}:
        if event == 'socket.connect':
            frame = sys._getframe(1)
            # Windows implements socketpair using a freshly bound loopback port.
            # Allow only this stdlib-created pair for asyncio wakeups, never a
            # general loopback exemption that could reach the user's MySQL.
            local = frame.f_locals
            if (frame.f_code in _PAIR_CODES and local.get('addr') in ('127.0.0.1', '::1')
                    and args[0] is local.get('csock')
                    and args[1] == (local.get('addr'), local.get('port'))):
                return
        raise RuntimeError('Backend acceptance forbids real network connections; use a test double')


def pytest_configure(config):
    # Irreversible for this disposable pytest process, even if a test restores
    # monkeypatches. SQLite files and in-process FastAPI TestClient remain usable.
    sys.addaudithook(block_network)
