"""Extended Win32 spelling for already validated internal recovery I/O paths."""
import ntpath
import os
from pathlib import Path


def extended_windows_path(value):
    value = os.fspath(value)
    if value.startswith('\\\\?\\'):
        return value
    drive, _ = ntpath.splitdrive(value)
    if not drive or not ntpath.isabs(value) or value.startswith('\\\\.\\'):
        raise ValueError('An absolute drive or UNC path is required')
    value = ntpath.normpath(value)
    return ('\\\\?\\UNC\\' + value[2:]) if value.startswith('\\\\') else ('\\\\?\\' + value)


def recovery_io_path(path):
    """Call after link/root checks; retain full operation hashes and filenames."""
    path = Path(path).absolute()
    return Path(extended_windows_path(path)) if os.name == 'nt' else path
