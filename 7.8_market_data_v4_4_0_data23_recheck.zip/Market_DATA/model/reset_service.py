"""Explicit whole-store reset. Never called by normal startup or GET/UI refresh.

MySQL DDL and file moves are not atomic. Fresh verified backups and an fsynced
operation journal precede every destructive step; failures require manual review.
"""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import uuid

from sqlalchemy import text, inspect
from model.backup_service import BackupService
from model.cash_restore import guard
from model.config.runtime_paths import state_path
from model.quality_store import migration_plan
from model.schema_management import owned_definitions, _digest
from model.storage.locking import file_lock

SEGMENTS=('CASH','FNO')


class ResetService:
    def __init__(self,catalog,backups=None,journal_root=None):
        self.catalog=catalog
        self.backups=backups or BackupService(catalog)
        self.guard=self.backups.guard
        self.journal_root=guard(journal_root or state_path('recovery/reset_operations'))

    @staticmethod
    def _admin(role):
        if role!='admin':raise PermissionError('Administrator access required')

    def _paths(self):
        guard(self.journal_root)
        scopes={}
        for segment in SEGMENTS:
            root,files=self.backups._files(segment)
            if root is None:raise ValueError('Both configured Parquet roots are required')
            root=guard(root).resolve()
            if (root/'main.py').exists() or (root/'.git').exists() or (root/'config/.env').exists():
                raise ValueError('Parquet root looks like a code/configuration root; review configuration')
            if self.journal_root==root or root in self.journal_root.parents or self.journal_root in root.parents:
                raise ValueError('Reset journal must be outside both Parquet roots')
            selected=sorted(n for n in files if n.endswith('.parquet') or '.parquet.tmp-' in Path(n).name)
            scopes[segment]=(root,selected)
        return scopes

    def _check_external_references(self,segment):
        engine=self.guard._engine(segment)
        with engine.connect() as conn:
            found=conn.execute(text(
                'SELECT 1 FROM information_schema.KEY_COLUMN_USAGE '
                'WHERE REFERENCED_TABLE_SCHEMA=:db AND TABLE_SCHEMA<>:db LIMIT 1'),
                {'db':engine.url.database}).first()
        if found:
            raise ValueError('Cross-database foreign keys require DBA review before reset')

    def preview(self,*,role):
        self._admin(role)
        scopes=self._paths()
        targets=[]
        for segment in SEGMENTS:
            self._check_external_references(segment)
            plan=self.backups.preview(segment,role=role)
            if str(plan['database']).lower() in ('mysql','sys','information_schema','performance_schema'):
                raise ValueError('System database reset is forbidden')
            if not plan['database']:raise ValueError('Exact database name is required')
            targets.append({'backup_plan':plan,'archive_files':scopes[segment][1],
                            'recreate_definitions':owned_definitions(segment)})
        a,b=(t['backup_plan'] for t in targets)
        if (a['host'],a['port'],a['database'])==(b['host'],b['port'],b['database']):
            raise ValueError('CASH and FNO databases must be distinct')
        confirmation='RESET '+a['database']+' + '+b['database']
        plan={'format':'tios-reset-v1','targets':targets,'journal_root':str(self.journal_root),
              'confirmation':confirmation,
              'effect':'All base tables in BOTH reviewed databases are dropped, then owned empty schemas are recreated. Parquet files are archived, not permanently erased. No history is fetched.',
              'retained':'Profile/config/credentials/instrument YAML/quota state and verified backup archives are not reset.',
              'restore_tested':False}
        plan['token']=_digest(plan)
        return plan

    def _drop_tables(self,segment,expected,record):
        engine=self.guard._engine(segment)
        quote=engine.dialect.identifier_preparer.quote
        with engine.connect() as conn:
            previous=conn.exec_driver_sql('SELECT @@SESSION.FOREIGN_KEY_CHECKS').scalar()
            try:
                conn.exec_driver_sql('SET SESSION FOREIGN_KEY_CHECKS=0')
                for name in expected:
                    record('DROP_INTENT',segment=segment,table=name)
                    conn.exec_driver_sql('DROP TABLE '+quote(name))
                    record('TABLE_DROPPED',segment=segment,table=name)
            finally:
                conn.exec_driver_sql('SET SESSION FOREIGN_KEY_CHECKS='+str(int(previous)))
                conn.commit()

    def _recreate(self,segment,definitions,record):
        engine=self.guard._engine(segment)
        with engine.begin() as conn:
            for name,sql in definitions.items():
                record('CREATE_INTENT',segment=segment,table=name)
                conn.execute(text(sql))
                record('TABLE_CREATED',segment=segment,table=name)
        if segment=='CASH':
            # Repository-owned metadata additions, not SQL supplied by the plan.
            for sql in migration_plan(engine):
                record('CASH_METADATA_INTENT',statement_hash=_digest(sql))
                with engine.begin() as conn:conn.execute(text(sql))
                record('CASH_METADATA_APPLIED',statement_hash=_digest(sql))

    def apply(self,plan,*,role,confirmation,writers_stopped=False,accept_data_loss=False):
        self._admin(role)
        if not writers_stopped or not accept_data_loss:
            raise ValueError('Explicit stopped-readers/writers and SQL data-loss acknowledgments are required')
        if confirmation!=plan.get('confirmation'):
            raise ValueError('Exact reset confirmation is required')
        if plan!=self.preview(role=role):raise ValueError('Reset scope or code changed; create a fresh preview')
        self.journal_root.mkdir(parents=True,exist_ok=True)
        with file_lock(self.journal_root/'reset.lock',timeout=0):
            if list(self.journal_root.glob('*/RECOVERY_NEEDED')):
                raise ValueError('Previous reset needs manual recovery review; automatic retry is blocked')
            operation=self.journal_root/uuid.uuid4().hex
            operation.mkdir()
            marker=operation/'RECOVERY_NEEDED'
            with marker.open('x',encoding='utf-8') as stream:
                stream.write('Do not resume writers; inspect journal and verified backups.\n')
                stream.flush();os.fsync(stream.fileno())
            with (operation/'journal.jsonl').open('x',encoding='utf-8') as journal:
                def record(event,**details):
                    journal.write(json.dumps({'event':event,**details},default=str)+'\n')
                    journal.flush();os.fsync(journal.fileno())
                completed=[];backups={}
                record('START',plan=plan)
                try:
                    # No table/file reset occurs until BOTH fresh backups succeed.
                    for target in plan['targets']:
                        bp=target['backup_plan'];segment=bp['segment']
                        result=self.backups.create(bp,role=role,writers_stopped=True)
                        if result.get('status')!='CHECKSUM_VERIFIED':raise ValueError('Backup verification failed')
                        backups[segment]=result
                        record('BACKUP_VERIFIED',segment=segment,backup=result)
                    with ExitStack() as locks:
                        for segment in SEGMENTS:
                            locks.enter_context(self.guard._database_lock(self.guard._engine(segment)))
                        if plan!=self.preview(role=role):raise ValueError('Scope changed after backups')
                        scopes=self._paths()
                        if any(root.stat().st_dev!=operation.stat().st_dev for root,_ in scopes.values()):
                            raise ValueError('Archive must share the filesystem of both Parquet roots; no reset performed')
                        for target in plan['targets']:
                            bp=target['backup_plan'];segment=bp['segment'];root,_=scopes[segment]
                            for rel in target['archive_files']:
                                source=guard(root/rel);destination=operation/'parquet'/segment/rel
                                destination.parent.mkdir(parents=True,exist_ok=True)
                                record('MOVE_INTENT',segment=segment,source=str(source),destination=str(destination))
                                os.replace(source,destination)
                                record('FILE_ARCHIVED',segment=segment,relative_path=rel)
                            completed.append(segment+':FILES_ARCHIVED')
                        remaining=self._paths()
                        if any(remaining[s][1] for s in SEGMENTS):
                            raise ValueError('New Parquet files appeared during maintenance')
                        for target in plan['targets']:
                            bp=target['backup_plan']
                            if sorted(inspect(self.guard._engine(bp['segment'])).get_table_names())!=bp['tables']:
                                raise ValueError('Table inventory changed during maintenance')
                        for target in plan['targets']:
                            bp=target['backup_plan'];segment=bp['segment']
                            self._drop_tables(segment,bp['tables'],record)
                            completed.append(segment+':TABLES_DROPPED')
                            self._recreate(segment,owned_definitions(segment),record)
                            completed.append(segment+':EMPTY_SCHEMA_CREATED')
                    record('COMPLETED',completed=completed)
                    marker.unlink()
                    return {'status':'EMPTY_SCHEMA_READY','journal':str(operation/'journal.jsonl'),
                            'completed':completed,'backups':backups,'restore_tested':False,
                            'next':'Review instrument/master synchronization, then explicitly fetch/aggregate/verify a small scope. No market data was created.'}
                except Exception as exc:
                    record('RECOVERY_NEEDED',error_type=type(exc).__name__,completed=completed)
                    return {'status':'RECOVERY_NEEDED','journal':str(operation/'journal.jsonl'),
                            'error_type':type(exc).__name__,'completed':completed,'backups':backups,
                            'message':'No atomic rollback. Keep readers/writers stopped; inspect per-step journal and backups. Do not rerun automatically.'}
