"""Archived, journaled replacement of scoped derived candles; raw data is read-only."""
import datetime as dt
import json
import os
import shutil
import uuid
from collections import Counter
from pathlib import Path
from sqlalchemy import text

from model.cash_rebuild import normalized, derived_sql, file_rows, differences
from model.cash_recovery import identity, enrich, quality, write_json_new, FIELDS
from model.cash_repair import write_parquet_new
from model.cash_restore import guard, require, digest, append_event
from model.storage_inventory import safe_root, fingerprint
from model.storage.locking import file_lock
from model.storage.windows_paths import recovery_io_path
from model.config.market_calendar import IST, calendar_verified, session_window, in_session
from model.processing.models import Candle
from model.processing.timeframe_aggregator import SUPPORTED_TIMEFRAMES, aggregate_1m_to_timeframe
from model.storage.parquet import _candle_to_row
from model.quality import stamp, canonical


def json_form(value):
    return json.loads(json.dumps(value, default=str))


def source_state(source, root, store, now):
    symbol, day = identity(source['relative_path'])
    require(day < now.date() and calendar_verified(day), 'closed_verified_session_required')
    window = session_window(day); require(window is not None, 'calendar_review_required')
    meta = store.metadata(symbol); path = guard(root/source['relative_path'])
    state, rows = file_rows(path)
    require(state is not None and state == source['fingerprint'], 'raw_file_changed_since_preview')
    quality(rows, symbol, day, now, meta, preserve_session=True)
    base = normalized(rows, symbol, day, '1m')
    require(digest(base) == source['sql_hash'], 'raw_hash_changed_since_preview')
    require(base == normalized(enrich(store.rows(meta['id'], day), symbol), symbol, day, '1m'), 'raw_SQL_Parquet_mismatch')
    regular = [r for r in rows if in_session(stamp(r['candle_timestamp']))]
    q = quality(regular, symbol, day, now, meta)
    require(not q['review_reasons'] and q['coverage']['missing'] == 0, 'incomplete_regular_session')
    candles = [Candle(**{k: meta[k] for k in ('internal_name', 'fyers_symbol', 'exchange', 'instrument_type')},
                      timestamp=stamp(r['candle_timestamp']), timeframe='1m', **{k: r[k] for k in FIELDS}) for r in regular]
    return symbol, day, meta, path, base, candles


def backup_partition(attempt, rows, meta, target, state):
    payload = {'metadata': meta, 'rows': rows}
    write_json_new(attempt/'sql_before.json', payload)
    require(json.loads((attempt/'sql_before.json').read_text()) == json_form(payload), 'SQL_backup_readback_failed')
    if state:
        with target.open('rb') as src, (attempt/'target_before.parquet').open('xb') as dst:
            shutil.copyfileobj(src, dst); dst.flush(); os.fsync(dst.fileno())
        require(fingerprint(attempt/'target_before.parquet') == (state['sha256'], state['bytes']), 'Parquet_backup_readback_failed')


def change_sql(conn, store, iid, day, tf, before, after):
    """Keep IDs for matching keys. Remove only explicitly obsolete derived keys."""
    require(tf in SUPPORTED_TIMEFRAMES and tf != '1m', 'derived_timeframe_required')
    old = {r['candle_timestamp']: r for r in before}; new = {r['candle_timestamp']: r for r in after}
    for key, row in new.items():
        if old.get(key) == row: continue
        values = {k: canonical(row[k], k) for k in FIELDS}
        if store.engine.dialect.name == 'sqlite':
            for k in ('open', 'high', 'low', 'close'): values[k] = float(values[k])
        values.update(i=iid, tf=tf, ts=stamp(key).replace(tzinfo=None))
        if key in old:
            result = conn.execute(text('UPDATE candles SET '+','.join(k+'=:'+k for k in FIELDS)+
                                       ' WHERE instrument_id=:i AND timeframe=:tf AND candle_timestamp=:ts'), values)
        else:
            result = conn.execute(text('INSERT INTO candles (instrument_id,timeframe,candle_timestamp,'+','.join(FIELDS)+') VALUES '
                                       '(:i,:tf,:ts,'+','.join(':'+k for k in FIELDS)+')'), values)
        require(result.rowcount == 1, 'unexpected_derived_write_count')
    for key in old.keys()-new.keys():
        require(stamp(key).date() == day, 'delete_outside_scoped_day')
        result = conn.execute(text('DELETE FROM candles WHERE instrument_id=:i AND timeframe=:tf AND candle_timestamp=:ts'),
                              {'i': iid, 'tf': tf, 'ts': stamp(key).replace(tzinfo=None)})
        require(result.rowcount == 1, 'unexpected_derived_delete_count')


def apply_rebuild(plan, root, store, operations_root, *, writers_stopped=False, accept_replacement=False, now=None, progress=None):
    require(writers_stopped and accept_replacement, 'writers_stopped_and_accept_derived_replacement_required')
    require(plan.get('operation') == 'CASH_DERIVED_REBUILD_PREVIEW' and plan.get('format_version') == 1, 'rebuild_preview_required')
    root = safe_root(root); require(root == Path(plan['target_root']).resolve(), 'configured_root_changed')
    op = guard(operations_root)
    require(root != op and root not in op.parents and op not in root.parents, 'operation_directory_overlaps_data')
    sources = {s['relative_path']: s for s in plan['sources']}
    require(len(sources) == len(plan['sources']), 'duplicate_source')
    entries = []; seen = set()
    for e in plan['entries']:
        if e['status'] not in ('NEEDS_REBUILD', 'ALREADY_CONSISTENT'): continue
        source = sources[e['source_relative_path']]; identity(source['relative_path'])
        require(source['status'] == 'SOURCE_VERIFIED', 'unverified_source_in_apply_scope')
        require(e['timeframe'] in SUPPORTED_TIMEFRAMES, 'invalid_derived_timeframe')
        expected_path = source['relative_path'].replace('raw/1m/', 'processed/'+e['timeframe']+'/', 1)
        require(e['relative_path'] == expected_path and expected_path not in seen, 'invalid_or_duplicate_target')
        seen.add(expected_path); entries.append(e)
    require(bool(entries), 'no_eligible_derived_partitions')
    store.ensure_insert_schema(); now = now or dt.datetime.now(IST)
    run = recovery_io_path(guard(op/digest(plan))); run.mkdir(parents=True, exist_ok=True)
    journal = run/'events.jsonl'; outcomes = []
    with file_lock(run/'operation.lock', timeout=0):
        if not (run/'plan.json').exists(): write_json_new(run/'plan.json', plan)
        for index, e in enumerate(entries, 1):
            result = {'relative_path': e['relative_path']}; outcomes.append(result)
            temp = None; attempted_commit = False; stage = 'preflight'
            try:
                source = sources[e['source_relative_path']]; tf = e['timeframe']
                raw_path = guard(root/source['relative_path']); target = guard(root/e['relative_path'])
                target.parent.mkdir(parents=True, exist_ok=True)
                with file_lock(str(raw_path)+'.lock', timeout=0), file_lock(str(target)+'.lock', timeout=0):
                    symbol, day, meta, raw_path, base, candles = source_state(source, root, store, now)
                    generated = [_candle_to_row(c) for c in aggregate_1m_to_timeframe(candles, tf)]
                    after = normalized(generated, symbol, day, tf)
                    require(bool(after) and after == e['expected'], 'recomputed_candidate_differs_from_plan')
                    candidate = guard(e['candidate'])
                    require(root != candidate and root not in candidate.parents, 'candidate_must_be_outside_data')
                    candidate_state, candidate_rows = file_rows(candidate)
                    require(candidate_state == e['candidate_fingerprint'] and normalized(candidate_rows, symbol, day, tf) == after,
                            'candidate_changed_since_preview')
                    require(all(all(str(r.get(k)) == str(meta[k]) for k in ('internal_name','exchange','instrument_type'))
                                for r in candidate_rows), 'candidate_metadata_changed')
                    require(all(r['instrument_id'] == meta['id'] for r in e['sql_before']), 'instrument_id_changed')
                    before = normalized(e['sql_before'], symbol, day, tf)
                    current_rows = derived_sql(store, meta['id'], day, tf)
                    current = normalized(current_rows, symbol, day, tf)
                    require(current in (before, after), 'derived_SQL_changed_replan')
                    state, pq = file_rows(target); pq_values = normalized(pq, symbol, day, tf)
                    if state and current == after == pq_values:
                        require(all(all(str(r.get(k)) == str(meta[k]) for k in ('internal_name','exchange','instrument_type')) for r in pq),
                                'target_metadata_changed')
                        result.update(status='ALREADY_APPLIED', inserted=0, updated=0, archived_removed=0)
                        append_event(journal, dict(event='ALREADY_APPLIED', **result)); continue
                    require(state == e['target_before'], 'derived_file_changed_replan')
                    # Archive before any transaction or canonical file replacement.
                    stage = 'backup'; attempt = run/('attempt-'+uuid.uuid4().hex); attempt.mkdir()
                    backup_partition(attempt, current_rows, meta, target, state)
                    stage = 'stage_parquet'; temp = guard(target.parent/('.rebuild-'+uuid.uuid4().hex+'.tmp'))
                    write_parquet_new(temp, generated)
                    require(normalized(file_rows(temp)[1], symbol, day, tf) == after, 'staged_derived_readback_failed')
                    # Probe same-directory hardlink support before committing SQL.
                    probe = temp.with_suffix('.probe'); os.link(temp, probe); probe.unlink()
                    append_event(journal, {'event':'PREPARED', 'path':e['relative_path'], 'backup':str(attempt),
                                          'before_hash':digest(current), 'after_hash':digest(after)})
                    stage = 'sql_transaction'
                    with store.engine.begin() as conn:
                        locked_meta = store.metadata(symbol, conn)
                        require(all(locked_meta[k] == meta[k] for k in ('id','internal_name','exchange','instrument_type','fyers_symbol')),
                                'metadata_changed_under_lock')
                        require(base == normalized(enrich(store.rows(meta['id'], day, conn, True), symbol), symbol, day, '1m'),
                                'raw_SQL_changed_under_lock')
                        locked_rows = derived_sql(store, meta['id'], day, tf, conn, True)
                        require(json_form(locked_rows) == json_form(current_rows), 'derived_SQL_changed_after_backup')
                        locked = normalized(locked_rows, symbol, day, tf)
                        if locked != after: change_sql(conn, store, meta['id'], day, tf, locked, after)
                        require(normalized(derived_sql(store, meta['id'], day, tf, conn, True), symbol, day, tf) == after,
                                'derived_SQL_readback_failed')
                        require(file_rows(target)[0] == state, 'target_changed_before_commit')
                        require(file_rows(raw_path)[0] == source['fingerprint'], 'raw_file_changed_before_commit')
                        attempted_commit = True
                    stage = 'publish_parquet'; append_event(journal, {'event':'SQL_COMMITTED', 'path':e['relative_path']})
                    require(file_rows(target)[0] == state, 'target_changed_before_publish')
                    if state is None: os.link(temp, target); temp.unlink()
                    else: os.replace(temp, target)
                    temp = None; stage = 'postcheck'
                    require(normalized(file_rows(target)[1], symbol, day, tf) == after, 'derived_Parquet_postcheck_failed')
                    require(normalized(derived_sql(store, meta['id'], day, tf), symbol, day, tf) == after, 'derived_SQL_postcheck_failed')
                    require(file_rows(raw_path)[0] == source['fingerprint'] and
                            normalized(enrich(store.rows(meta['id'], day), symbol), symbol, day, '1m') == base, 'raw_source_changed_during_apply')
                    changes = differences(current, after)
                    result.update(status='VERIFIED', inserted=changes['missing'], updated=changes['changed'],
                                  archived_removed=changes['extra'], rows=len(after), backup=str(attempt))
                    append_event(journal, dict(event='VERIFIED', **result))
            except Exception as exc:
                result.update(status='REVIEW_REQUIRED', stage=stage, sql_may_have_committed=attempted_commit,
                              error=str(exc) if isinstance(exc, ValueError) else type(exc).__name__)
                if isinstance(exc, OSError):
                    result['os_error'] = {'errno':exc.errno, 'winerror':getattr(exc,'winerror',None),
                                          'message':exc.strerror, 'filename':str(exc.filename) if exc.filename else None}
                append_event(journal, dict(event='REVIEW_REQUIRED', **result))
            finally:
                if temp is not None and temp.exists(): temp.unlink()
                if progress: progress(index, len(entries))
        result = {'status':'PARTIAL' if any(o['status']=='REVIEW_REQUIRED' for o in outcomes) else 'SCOPED_DERIVED_REBUILD_VERIFIED',
                  'applied_statuses':dict(Counter(o['status'] for o in outcomes)), 'outcomes':outcomes,
                  'totals':{k:sum(o.get(k,0) for o in outcomes) for k in ('inserted','updated','archived_removed')},
                  'source_review_pending':[s for s in plan['sources'] if s['status']!='SOURCE_VERIFIED'],
                  'excluded_derived_entries':len(plan['entries'])-len(entries), 'journal':str(journal),
                  'scope':'Selected derived partitions only. Raw 1m unchanged by this tool; old derived rows archived before replacement. '
                          'No whole-project certification or atomic cross-store transaction claimed.'}
        report = run/('result-'+uuid.uuid4().hex+'.json'); result['report'] = str(report)
        write_json_new(report, result); return result
