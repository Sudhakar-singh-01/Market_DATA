"""Streaming SQL + Parquet backups and verified recovery-folder extraction.

Recovery staging never executes SQL or overwrites either live store. Archives are
local admin artifacts; checksums detect corruption, not a malicious replacement.
"""
from model.config.runtime_paths import state_path
import datetime as dt
import decimal
import hashlib
import json
import math
import os
import re
import shutil
import stat
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from sqlalchemy import inspect, text
from model.read_contracts import segment_name
from model.storage_scope import validate_storage_roots, owned_paths
from model.schema_management import SchemaManager, ROOT, _digest

CHUNK = 1024 * 1024
MAX_MEMBERS = 100000
MAX_EXPANDED_BYTES = 1024**4  # 1 TiB; fail explicitly for larger archives


def _json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate manifest key')
        result[key] = value
    return result


def _manifest(raw, names):
    """Parse and validate the complete v1 inventory before trusting its fields."""
    try:
        manifest = json.loads(raw, object_pairs_hook=_json_object)
    except (TypeError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('Invalid backup manifest') from exc
    if not isinstance(manifest, dict):
        raise ValueError('Invalid backup manifest')
    if manifest.get('format') != 'tios-backup-v1' or manifest.get('segment') not in ('CASH', 'FNO'):
        raise ValueError('Unsupported backup format')
    database, tables, members = manifest.get('database'), manifest.get('tables'), manifest.get('members')
    if (not isinstance(database, str) or not database or len(database) > 64 or
            any(ord(ch) < 32 for ch in database)):
        raise ValueError('Invalid backup database identity')
    if (not isinstance(tables, dict) or len(tables) > 10000 or
            any(not isinstance(name, str) or not name or len(name) > 64 or
                type(count) is not int or count < 0 for name, count in tables.items())):
        raise ValueError('Invalid backup table inventory')
    if not isinstance(members, dict) or set(members) != (set(names) - {'manifest.json'}) or 'database.sql' not in members:
        raise ValueError('Incomplete backup inventory')
    for name, entry in members.items():
        if (not isinstance(name, str) or not isinstance(entry, dict) or
                type(entry.get('bytes')) is not int or entry['bytes'] < 0 or
                not isinstance(entry.get('sha256'), str) or
                not re.fullmatch(r'[0-9a-f]{64}', entry['sha256'])):
            raise ValueError('Invalid backup member metadata')
    try:
        stamp = dt.datetime.fromisoformat(manifest.get('created_at'))
    except (TypeError, ValueError):
        raise ValueError('Invalid backup creation time') from None
    if stamp.tzinfo is None or stamp.utcoffset() is None or type(manifest.get('restore_tested')) is not bool:
        raise ValueError('Invalid backup manifest')
    return manifest


def sql_literal(value):
    """MySQL literals independent of source SQL mode, preserving binary/decimal data."""
    if value is None: return 'NULL'
    if isinstance(value, bool): return '1' if value else '0'
    if isinstance(value, int): return str(value)
    if isinstance(value, (float, decimal.Decimal)):
        if not math.isfinite(value): raise ValueError('Nonfinite SQL value cannot be backed up')
        return str(value)
    if isinstance(value, bytes): return "X'"+value.hex()+"'"
    if isinstance(value, str): return "CONVERT(X'"+value.encode('utf-8').hex()+"' USING utf8mb4)"
    if isinstance(value, (dt.datetime,dt.date,dt.time)):
        if getattr(value,'tzinfo',None) is not None: raise ValueError('Unexpected timezone-aware MySQL value')
        return "'"+value.isoformat(sep=' ') +"'" if isinstance(value,dt.datetime) else "'"+value.isoformat()+"'"
    if isinstance(value,dt.timedelta):
        micros = (value.days*86400+value.seconds)*1000000+value.microseconds
        sign='-' if micros<0 else ''; micros=abs(micros)
        seconds,frac=divmod(micros,1000000); hours,seconds=divmod(seconds,3600); minutes,seconds=divmod(seconds,60)
        return f"'{sign}{hours:02}:{minutes:02}:{seconds:02}.{frac:06}'"
    raise ValueError('Unsupported SQL data type: '+type(value).__name__)


def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(CHUNK),b''): h.update(block)
    return h.hexdigest()


class BackupService:
    def __init__(self,catalog,backup_root=None,recovery_root=None):
        self.catalog=catalog
        self.guard=SchemaManager(catalog)
        self.backup_root=Path(backup_root or state_path('backups'))
        self.recovery_root=Path(recovery_root or state_path('recovery'))

    @staticmethod
    def _admin(role):
        if role!='admin': raise PermissionError('Administrator access required')

    def _files(self,segment):
        configured=self.catalog.roots.get(segment)
        if configured is None: return None,{}
        scope=validate_storage_roots(self.catalog.roots)[segment]
        root=Path(scope['root'])
        if not root.is_dir(): raise ValueError('Configured Parquet root is missing')
        files={}
        for path in owned_paths(root, scope['excluded_subtrees']):
            if path.is_symlink(): raise ValueError('Symlinks are not allowed in backup sources')
            if path.is_file():
                # Back up owned files and sidecars, excluding a nested peer segment.
                info=path.stat()
                files[path.relative_to(root).as_posix()]={'size':info.st_size,'mtime_ns':info.st_mtime_ns}
        if len(files)>MAX_MEMBERS-2: raise ValueError('Too many backup files; split storage before backing up')
        for destination in (self.backup_root.resolve(),self.recovery_root.resolve()):
            if destination==root or root in destination.parents:
                raise ValueError('Backup/recovery directories must be outside the data root')
        return root,files

    def preview(self,segment,*,role):
        self._admin(role); segment=segment_name(segment)
        engine=self.guard._engine(segment)
        inspector=inspect(engine)
        tables=sorted(inspector.get_table_names())
        if inspector.get_view_names(): raise ValueError('Views require a DBA backup; this tool backs up base tables only')
        with engine.connect() as conn:
            unsupported=conn.execute(text("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=:db AND TABLE_TYPE='BASE TABLE' AND ENGINE <> 'InnoDB'"),{'db':engine.url.database}).all()
            objects=sum(conn.execute(text('SELECT COUNT(*) FROM information_schema.'+kind+' WHERE '+field+'=:db'),{'db':engine.url.database}).scalar() for kind,field in [('TRIGGERS','TRIGGER_SCHEMA'),('ROUTINES','ROUTINE_SCHEMA'),('EVENTS','EVENT_SCHEMA')])
            if unsupported or objects: raise ValueError('Non-InnoDB tables or stored objects require a DBA backup')
            quote=engine.dialect.identifier_preparer.quote
            ddl={n:conn.exec_driver_sql('SHOW CREATE TABLE '+quote(n)).one()[1] for n in tables}
        root,files=self._files(segment)
        plan={'segment':segment,'database':engine.url.database,'host':engine.url.host,'port':engine.url.port,
              'tables':tables,'schema_hash':_digest(ddl),'file_count':len(files),'file_bytes':sum(f['size'] for f in files.values()),
              'file_hash':_digest(files),'parquet_root':str(root) if root else None}
        plan['token']=_digest(plan)
        return plan

    def _dump_database(self,engine,path):
        quote=engine.dialect.identifier_preparer.quote
        counts={}
        with engine.connect().execution_options(isolation_level='REPEATABLE READ') as conn:
            original_zone=conn.exec_driver_sql('SELECT @@session.time_zone').scalar()
            conn.commit()
            try:
                with conn.begin():
                    conn.exec_driver_sql("SET SESSION time_zone = '+00:00'")
                    conn.exec_driver_sql('START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY')
                    inspector=inspect(conn)
                    tables=sorted(inspector.get_table_names())
                    with path.open('w',encoding='utf-8',newline='\n') as out:
                        out.write('-- TIOS recovery dump. Import into an EMPTY, separate recovery database.\n')
                        out.write("SET NAMES utf8mb4;\nSET SESSION SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET SESSION time_zone='+00:00';\nSET FOREIGN_KEY_CHECKS=0;\n")
                        for name in tables:
                            ddl=conn.exec_driver_sql('SHOW CREATE TABLE '+quote(name)).one()[1]
                            out.write(ddl+';\n')
                        for name in tables:
                            columns=[c['name'] for c in inspector.get_columns(name) if not c.get('computed')]
                            if not columns: raise ValueError('Table has no insertable columns')
                            names=','.join(quote(c) for c in columns)
                            result=conn.execution_options(stream_results=True).exec_driver_sql('SELECT '+names+' FROM '+quote(name))
                            count=0
                            try:
                                for row in result:
                                    out.write('INSERT INTO '+quote(name)+' ('+names+') VALUES ('+','.join(sql_literal(v) for v in row)+');\n')
                                    count+=1
                            finally: result.close()
                            counts[name]=count
                        out.write('SET FOREIGN_KEY_CHECKS=1;\n')
                        out.flush(); os.fsync(out.fileno())
            finally:
                conn.exec_driver_sql("SET SESSION time_zone = %s", (original_zone,))
                conn.commit()
        return counts

    def create(self,plan,*,role,writers_stopped=False):
        self._admin(role)
        if not writers_stopped: raise ValueError('Stop all SQL/Parquet writers and schema tools first')
        engine=self.guard._engine(segment_name(plan['segment']))
        with self.guard._database_lock(engine):
            if plan!=self.preview(plan['segment'],role=role): raise ValueError('Backup scope changed; preview again')
            root,files=self._files(plan['segment'])
            self.backup_root.mkdir(parents=True,exist_ok=True)
            ident=uuid.uuid4().hex
            staging=self.backup_root/('.'+ident)
            staging.mkdir()
            partial=self.backup_root/(ident+'.partial')
            final=self.backup_root/(ident+'.zip')
            try:
                counts=self._dump_database(engine,staging/'database.sql')
                members={}
                with zipfile.ZipFile(partial,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as archive:
                    sources=[('database.sql',staging/'database.sql')]+[('parquet/'+n,root/n) for n in files]
                    for name,path in sources:
                        before=path.stat(); h=hashlib.sha256(); total=0
                        with path.open('rb') as source, archive.open(name,'w',force_zip64=True) as target:
                            for block in iter(lambda:source.read(CHUNK),b''):
                                target.write(block); h.update(block); total+=len(block)
                        after=path.stat()
                        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns) or total!=before.st_size:
                            raise ValueError('Source changed during backup; stop writers and retry')
                        members[name]={'sha256':h.hexdigest(),'bytes':total}
                    if files!=self._files(plan['segment'])[1]: raise ValueError('Parquet files changed during backup')
                    if plan!=self.preview(plan['segment'],role=role): raise ValueError('Schema or files changed during backup')
                    manifest={'format':'tios-backup-v1','created_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                              'segment':plan['segment'],'database':plan['database'],'tables':counts,'members':members,
                              'consistency':'SQL snapshot; cross-store consistency relies on all writers being stopped',
                              'restore_tested':False}
                    archive.writestr('manifest.json',json.dumps(manifest,indent=2))
                # Verify every byte before publishing a completed backup name.
                self._verify_path(partial)
                os.replace(partial,final)
                return {'backup_id':ident,'path':str(final),'sha256':sha256_file(final),'tables':counts,
                        'files':len(files),'status':'CHECKSUM_VERIFIED','restore_tested':False}
            finally:
                shutil.rmtree(staging,ignore_errors=True)
                partial.unlink(missing_ok=True)

    def _archive(self,backup_id):
        if not re.fullmatch('[0-9a-f]{32}',backup_id): raise ValueError('Invalid backup identifier')
        path=self.backup_root/(backup_id+'.zip')
        if path.is_symlink() or not path.is_file(): raise ValueError('Backup not found')
        return path

    def list_backups(self,*,role):
        self._admin(role)
        return [{'backup_id':p.stem,'bytes':p.stat().st_size} for p in sorted(self.backup_root.glob('*.zip'))
                if re.fullmatch('[0-9a-f]{32}',p.stem) and not p.is_symlink()]

    def _verify_path(self,path):
        with zipfile.ZipFile(path) as archive:
            infos=archive.infolist(); names=[i.filename for i in infos]
            if sum(i.file_size for i in infos)>MAX_EXPANDED_BYTES:
                raise ValueError('Backup exceeds the 1 TiB expanded-size limit')
            if len(infos)>MAX_MEMBERS or len(names)!=len({n.casefold() for n in names}): raise ValueError('Duplicate or excessive archive members')
            for info in infos:
                # ZipInfo.filename may already have normalized Windows separators or
                # truncated NULs. Reject those original spellings before manifest reads.
                name=info.orig_filename; parts=PurePosixPath(name).parts
                if (name != info.filename or not parts or str(PurePosixPath(name))!=name or PurePosixPath(name).is_absolute() or '\\' in name or ':' in name or
                    any(p in ('..','.') or p.rstrip(' .')!=p or p.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]} for p in parts) or name.endswith('/') or any(any(ch in p for ch in '<>"|?*') or any(ord(ch)<32 for ch in p) for p in parts) or
                    stat.S_ISLNK(info.external_attr>>16) or
                    (name not in ('database.sql','manifest.json') and not name.startswith('parquet/'))):
                    raise ValueError('Unsafe archive member')
            if archive.getinfo('manifest.json').file_size>32*1024*1024: raise ValueError('Manifest too large')
            manifest=_manifest(archive.read('manifest.json'), names)
            members=manifest['members']
            for name,entry in members.items():
                if archive.getinfo(name).file_size!=entry['bytes']: raise ValueError('Backup size mismatch')
                h=hashlib.sha256()
                with archive.open(name) as source:
                    for block in iter(lambda:source.read(CHUNK),b''): h.update(block)
                if h.hexdigest()!=entry['sha256']: raise ValueError('Backup checksum mismatch')
            return manifest

    def verify(self,backup_id,*,role):
        self._admin(role)
        path=self._archive(backup_id)
        return {'backup_id':backup_id,'sha256':sha256_file(path),'manifest':self._verify_path(path),
                'status':'CHECKSUM_VERIFIED','restore_tested':False}

    def stage_recovery(self,verified,*,role,confirmation):
        self._admin(role)
        ident=verified['backup_id']
        if confirmation!='STAGE '+ident: raise ValueError('Explicit recovery staging confirmation required')
        path=self._archive(ident)
        if self.recovery_root.is_symlink(): raise ValueError('Recovery directory cannot be a symlink')
        self.recovery_root.mkdir(parents=True,exist_ok=True)
        target=self.recovery_root/(ident+'_'+uuid.uuid4().hex[:8])
        target.mkdir()
        try:
            # Copy immutable input into a fresh folder; validate that exact copy before extraction.
            copy=target/'backup.zip'; shutil.copyfile(path,copy)
            if sha256_file(copy)!=verified['sha256']: raise ValueError('Backup changed; verify again')
            manifest=self._verify_path(copy)
            if sum(e['bytes'] for e in manifest['members'].values()) > shutil.disk_usage(target).free:
                raise ValueError('Insufficient free space for recovery staging')
            with zipfile.ZipFile(copy) as archive:
                for info in archive.infolist():
                    dest=target/info.filename
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    with archive.open(info) as source,dest.open('xb') as output:
                        shutil.copyfileobj(source,output,CHUNK)
            copy.unlink()
            actual={p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()}
            if actual != set(manifest['members']) | {'manifest.json'}:
                raise ValueError('Staged recovery inventory mismatch')
            staged_manifest=_manifest((target/'manifest.json').read_bytes(), actual)
            if staged_manifest != manifest:
                raise ValueError('Staged recovery manifest mismatch')
            for name,entry in manifest['members'].items():
                staged=target/name
                if staged.stat().st_size != entry['bytes'] or sha256_file(staged) != entry['sha256']:
                    raise ValueError('Staged recovery checksum mismatch')
            return {'status':'STAGED_ONLY','path':str(target),'database_modified':False,
                    'next':'Import database.sql into a separate empty recovery database and validate SQL/Parquet before any live replacement.'}
        except Exception:
            shutil.rmtree(target,ignore_errors=True)
            raise
