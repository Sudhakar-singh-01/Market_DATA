"""Strict, session-anchored FNO adapter for the shared OHLCV combiner.

Every output requires all CLOSED one-minute bars in its session-clipped bucket.
No interpolation or assumption about silent option ticks is made. Daily bars
start at session open, including the shortened final intraday bucket.
"""
import datetime as dt
import math
from dataclasses import dataclass, field

from model.fno.config import DEFAULT_SESSION
from model.fno.models import FnoCandle, IST, SOURCE_AGGREGATED
from model.config.market_calendar import session_windows
from model.processing.models import Candle
from model.processing.timeframe_aggregator import _combine

MINUTES = {"3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "1d": 1440}


def session_bounds(day, session=DEFAULT_SESSION):
    """Session envelope; closed dates have an empty interval at normal open."""
    windows = session_windows(day, 'FNO', session=session)
    start = dt.datetime.combine(day, session.open, tzinfo=IST)
    return (windows[0][0], windows[-1][1]) if windows else (start, start)


def session_minutes(day, session=DEFAULT_SESSION):
    """Actual configured minute starts, excluding holidays and split-session breaks."""
    return [start + dt.timedelta(minutes=i)
            for start, end in session_windows(day, 'FNO', session=session)
            for i in range(int((end-start).total_seconds()//60))]


def buckets(day, timeframe, session=DEFAULT_SESSION):
    if timeframe not in MINUTES:
        raise ValueError(f"Unsupported FNO target timeframe: {timeframe}")
    windows = session_windows(day, 'FNO', session=session)
    if timeframe == '1d':
        if windows:
            yield windows[0][0], windows[-1][1]
        return
    for start, close in windows:
        while start < close:
            end = min(close, start + dt.timedelta(minutes=MINUTES[timeframe]))
            yield start, end
            start = end


def invalid_candle(c):
    try:
        prices = [c.open, c.high, c.low, c.close]
        quantities = [c.volume] + ([] if c.oi is None else [c.oi])
        return (any(not p.is_finite() or p <= 0 for p in prices)
                or c.low > min(c.open, c.close) or c.high < max(c.open, c.close)
                or c.low > c.high or any(isinstance(v, bool) or not math.isfinite(float(v))
                    or v < 0 or v != int(v) for v in quantities))
    except (AttributeError, TypeError, ValueError, OverflowError):
        return True


@dataclass
class AggregationResult:
    candles: list = field(default_factory=list)
    input_rows: int = 0
    invalid_rows: int = 0
    missing_buckets: int = 0
    incomplete_buckets: int = 0
    forming_buckets: int = 0

    @property
    def skipped(self):
        return self.missing_buckets + self.incomplete_buckets + self.forming_buckets


def aggregate_day(rows, day, timeframe, session=DEFAULT_SESSION, now=None):
    now = now or dt.datetime.now(IST)
    if now.tzinfo is None:
        raise ValueError("now must be timezone aware")
    result = AggregationResult(input_rows=len(rows))
    minute_starts = session_minutes(day, session)
    allowed_starts = set(minute_starts)
    stamps, bad_stamps = {}, set()
    ids = {c.contract_id for c in rows}
    if len(ids) > 1:
        raise ValueError("aggregate_day accepts one contract at a time")
    for c in rows:
        if c.timestamp.tzinfo is None:
            raise ValueError("FNO timestamps must be timezone aware")
        ts = c.timestamp.astimezone(IST)
        if (c.timeframe != "1m" or ts not in allowed_starts
                or invalid_candle(c)):
            result.invalid_rows += 1
            bad_stamps.add(ts)
            continue
        if ts in stamps:
            result.invalid_rows += 1
            bad_stamps.add(ts)
        stamps[ts] = c
    for start, end in buckets(day, timeframe, session):
        if end > now:
            result.forming_buckets += 1
            continue
        expected = [ts for ts in minute_starts if start <= ts < end]
        group = [stamps[t] for t in expected if t in stamps]
        if not group:
            result.missing_buckets += 1
            continue
        if len(group) != len(expected) or any(t in bad_stamps for t in expected) or any(c.status != "CLOSED" for c in group):
            result.incomplete_buckets += 1
            continue
        # Decimal values pass through the shared combiner without float conversion.
        base = [Candle(str(c.contract_id), str(c.contract_id), "FNO", "NSE", c.timestamp,
                       "1m", c.open, c.high, c.low, c.close, c.volume, c.source, c.status) for c in group]
        combined = _combine(base, start, timeframe, "CLOSED")
        oi = next((c.oi for c in reversed(group) if c.oi is not None), None)
        result.candles.append(FnoCandle(group[0].contract_id, timeframe, start, combined.open,
                             combined.high, combined.low, combined.close, combined.volume,
                             source=SOURCE_AGGREGATED, oi=oi))
    return result
