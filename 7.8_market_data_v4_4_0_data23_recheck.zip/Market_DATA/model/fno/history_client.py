"""
model/fno/history_client.py
One-symbol-per-request FYERS history fetch for FNO contracts, with explicit response
classification, bounded retries and exponential backoff.

classify_response():
    OK             candles present
    NO_DATA        s == 'no_data', or ok with an empty candle list
    INVALID_SYMBOL code in config invalid_symbol_codes (default -300) or 'invalid symbol'
    RATE_LIMIT     429-style code or 'rate limit' text            -> retried
    AUTH           token rejected/expired                         -> TokenExpiredError, never retried
    ERROR          anything else                                  -> permanent for this request
Network/timeout exceptions are retried. All FYERS error CODES are config values and are
UNVERIFIED until the probe has recorded the real ones.
"""
import datetime
import logging
import re
import time
from dataclasses import dataclass
from typing import Optional

from model.fno.config import HistorySettings
from controller import worker_lifecycle as lifecycle
from model.fno.errors import TokenExpiredError

log = logging.getLogger("market_data.fno.history")

OK, NO_DATA, INVALID_SYMBOL, RATE_LIMIT, AUTH, ERROR = "OK", "NO_DATA", "INVALID_SYMBOL", "RATE_LIMIT", "AUTH", "ERROR"


def _safe_message(value) -> str:
    """Bound provider diagnostics and remove common credential fields."""
    value = str(value or "")[:500]
    value = re.sub(
        r"(?i)\b(access_token|refresh_token|authorization|client_secret|api_key|token)"
        r"\s*[:=]\s*[^,}\]\s]+",
        r"\1=***",
        value,
    )
    return value[:200]


class TransientFetchError(Exception):
    """Retries exhausted on a transient problem (429/network/timeout). The range stays retryable."""


@dataclass
class FetchResult:
    status: str
    rows: list
    requests: int = 0
    retries: int = 0
    message: str = ""
    code: Optional[int] = None
    columns: Optional[list] = None


def classify_response(resp, s: HistorySettings) -> tuple:
    if not isinstance(resp, dict):
        return ERROR, f"non-dict response: {type(resp).__name__}", None
    message = _safe_message(resp.get("message", ""))
    low = message.lower()
    try:
        code = int(resp.get("code")) if resp.get("code") is not None else None
    except (TypeError, ValueError):
        code = None
    status = resp.get("s")
    if status == "ok":
        # Only an explicit empty list proves a successful empty response.
        # Missing/malformed payloads must remain retryable errors, never a
        # terminal NO_DATA checkpoint for an unobserved date range.
        candles = resp.get("candles")
        if not isinstance(candles, list):
            return ERROR, "successful response has no valid candle list", code
        return (OK, "", code) if candles else (NO_DATA, "empty candle list", code)
    if code in s.auth_error_codes or "token" in low and ("expired" in low or "invalid" in low) or "authenticate" in low:
        return AUTH, message or "authentication rejected", code
    if (code in s.rate_limit_codes or "rate limit" in low or "too many requests" in low
            or "requests/second" in low or "plan limit" in low):
        return RATE_LIMIT, message, code
    if code in s.invalid_symbol_codes or "invalid symbol" in low:
        return INVALID_SYMBOL, message, code
    if status == "no_data":
        return NO_DATA, message, code
    return ERROR, message or f"provider response fields: {','.join(sorted(map(str, resp.keys()))[:20])}", code


class FnoHistoryFetcher:
    def __init__(self, client, settings: HistorySettings, sleep=time.sleep):
        self.client, self.s, self._sleep = client, settings, sleep

    def payload(self, symbol: str, d_from: datetime.date, d_to: datetime.date) -> dict:
        p = {"symbol": symbol, "resolution": self.s.resolution, "date_format": "1",
             "range_from": d_from.isoformat(), "range_to": d_to.isoformat(), "cont_flag": self.s.cont_flag}
        if self.s.oi_flag:
            p["oi_flag"] = "1"
        return p

    def fetch_expired(self, contract, d_from, d_to):
        from model.fno.capabilities import capabilities, UnsupportedCapabilityError
        if not capabilities(self.client)['fno_historical_data']:
            raise UnsupportedCapabilityError('Expired history unavailable in installed SDK; no terminal checkpoint was written')
        return self.fetch(contract.fyers_symbol,d_from,d_to,expired=True,greeks=contract.category=='OPTIONS' and contract.exchange!='MCX')

    def fetch(self, symbol: str, d_from: datetime.date, d_to: datetime.date, expired=False,greeks=False) -> FetchResult:
        backoff, requests_made, retries = self.s.initial_backoff_seconds, 0, 0
        while True:
            lifecycle.check()
            requests_made += 1
            try:
                if expired:
                    from model.fyers.rate_limiter import get_shared_limiter
                    limiter=get_shared_limiter()
                    if hasattr(limiter,'acquire_expired'):limiter.acquire_expired()
                    payload=self.payload(symbol,d_from,d_to)
                    payload.pop('cont_flag',None);payload.pop('oi_flag',None)
                    payload.update(include_oi='1' if self.s.oi_flag else '0',include_greeks='1' if greeks else '0')
                    resp=self.client.fno_historical_data(data=payload)
                else:resp = self.client.history(data=self.payload(symbol, d_from, d_to))
                kind, msg, code = classify_response(resp, self.s)
            except (TimeoutError, ConnectionError, OSError) as exc:     # requests' errors subclass OSError
                kind, msg, code, resp = "NETWORK", f"{type(exc).__name__}: {_safe_message(exc)}", None, None
            lifecycle.check()
            if kind == AUTH:
                raise TokenExpiredError(f"FYERS rejected the access token ({msg or 'code ' + str(code)}). "
                                        f"Run `python -m model.fyers.auth` and update FYERS_ACCESS_TOKEN.")
            if kind in (RATE_LIMIT, "NETWORK"):
                if retries >= self.s.max_retries:
                    raise TransientFetchError(f"{symbol} {d_from}..{d_to}: {kind} after {retries} retries ({msg})")
                retries += 1
                log.warning("%s %s..%s: %s, retry %d/%d in %.1fs", symbol, d_from, d_to, kind, retries, self.s.max_retries, backoff)
                if self._sleep is time.sleep:
                    deadline = time.monotonic() + backoff
                    while time.monotonic() < deadline:
                        lifecycle.check()
                        time.sleep(min(0.1, max(0, deadline - time.monotonic())))
                else:
                    self._sleep(backoff)
                backoff *= self.s.backoff_multiplier
                continue
            rows = resp.get("candles", []) if kind == OK else []
            return FetchResult(kind, rows, requests_made, retries, msg, code,(resp or {}).get("columns") if expired else None)
