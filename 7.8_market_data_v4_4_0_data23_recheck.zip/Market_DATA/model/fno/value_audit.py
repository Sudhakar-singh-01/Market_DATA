"""Bounded historical value checks; no provider, jobs, repairs or persistent cache."""
import datetime as dt
from collections import Counter

import pandas as pd
from sqlalchemy import select

from controller.unified_workflow import fingerprint
from model.config.market_calendar import IST, calendar_metadata, calendar_verified
from model.data_inventory import _targets, _version
from model.fno.parquet_store import COLUMNS
from model.fno.read_verification import verified_day, MAX_CONTRACT_ROWS
from model.market_read_service import MarketReadService
from model.read_contracts import ReadRequestError, DataNotVerifiedError, date_scope
from model.timeframes import TIMEFRAMES

MAX_CHECKS = 500
MAX_FILE_ROWS = 200000
MAX_TOTAL_ROWS = 500000
MAX_FILES = 100
REASONS = {
    'Empty session cannot prove no trading; fetch/verify evidence is required': 'NO_CANDLES_OBSERVED',
    'Futures minute coverage is incomplete': 'INCOMPLETE_FUTURES_MINUTE_COVERAGE',
    'SQL and Parquet values/keys disagree': 'SQL_PARQUET_VALUE_MISMATCH',
    'Parquet manifest is not VERIFIED': 'MANIFEST_NOT_VERIFIED',
    'Manifest references missing Parquet': 'PARQUET_FILE_MISSING',
    'Parquet checksum/row count differs from manifest': 'PARQUET_CHECKSUM_OR_ROW_COUNT_MISMATCH',
    'Calendar evidence unavailable': 'CALENDAR_UNCONFIRMED',
    'Invalid contract scope': 'CONTRACT_SCOPE_INVALID',
    'Derived candles disagree with canonical source': 'AGGREGATION_MISMATCH',
    'Partition changed during audit': 'PARTITION_CHANGED_DURING_AUDIT',
    'Contract-day exceeds verification bound': 'READ_BOUND_EXCEEDED',
}


class AuditLimit(ReadRequestError):
    pass


def _manifest(entry):
    return (entry['status'], entry['checksum'], entry['row_count'])


class PartitionCache:
    """One scan/hash per unchanged shared file, discarded after this audit."""
    def __init__(self):
        self.files = {}
        self.rejected = {}
        self.scanned_rows = 0
        self.sql_rows = 0

    def before_sql(self):
        if self.sql_rows >= MAX_TOTAL_ROWS:
            raise AuditLimit('SQL row budget exhausted')

    def note_sql_rows(self, count):
        self.sql_rows += count
        if self.sql_rows > MAX_TOTAL_ROWS:
            raise AuditLimit('SQL row budget exceeded')

    def rows(self, service, store, path, rel, entry, contract_id):
        key = str(path)
        version = (_version(path), _manifest(entry))
        if key in self.rejected:
            old, error, message = self.rejected[key]
            if old != version:
                raise DataNotVerifiedError('Partition changed during audit')
            raise error(message)
        try:
            return self._rows(service, store, path, rel, entry, contract_id)
        except (AuditLimit, DataNotVerifiedError) as exc:
            self.rejected[key] = (version, type(exc), str(exc))
            raise

    def _rows(self, service, store, path, rel, entry, contract_id):
        key = str(path)
        current = (_version(path), _manifest(entry))
        if key in self.files:
            saved = self.files[key]
            if current != saved['version']:
                raise DataNotVerifiedError('Partition changed during audit')
            return saved['groups'].get(contract_id, [])
        if len(self.files) + len(self.rejected) >= MAX_FILES:
            raise AuditLimit('Shared file count exceeds audit bound')
        import pyarrow.parquet as pq
        with path.open('rb') as stream:
            file = pq.ParquetFile(stream)
            count = file.metadata.num_rows
            if count > MAX_FILE_ROWS or self.scanned_rows + count > MAX_TOTAL_ROWS:
                raise AuditLimit('Shared file rows exceed audit bound')
            if count != entry['row_count'] or store.sha256(path) != entry['checksum']:
                raise DataNotVerifiedError('Parquet checksum/row count differs from manifest')
            self.scanned_rows += count
            groups = {}
            for batch in file.iter_batches(batch_size=2000, columns=COLUMNS):
                for row in batch.to_pylist():
                    identity = row['contract_id']
                    if type(identity) is not int or identity <= 0:
                        raise DataNotVerifiedError('Invalid Parquet contract identity')
                    group = groups.setdefault(identity, [])
                    group.append(row)
                    if len(group) > MAX_CONTRACT_ROWS:
                        raise AuditLimit('Contract partition exceeds audit bound')
        if _version(path) != current[0]:
            raise DataNotVerifiedError('Partition changed during audit')
        self.files[key] = {'version': current, 'groups': groups, 'path': path, 'rel': rel}
        return groups.get(contract_id, [])

    def unchanged(self, service):
        table = service.catalog.table('FNO', 'fno_storage_manifest')
        for saved in self.files.values():
            entries = service._read('FNO', select(table).where(table.c.relative_path == saved['rel']))
            if (len(entries) != 1 or (_version(saved['path']), _manifest(entries[0])) != saved['version']):
                return False
        return True


def audit_values(reads, start, end, *, contract_ids=None, underlyings=None, timeframes=('1m',)):
    if not isinstance(reads, MarketReadService):
        raise TypeError('MarketReadService required')
    a, b = date_scope(start, end, max_days=31)
    now = reads.clock()
    if now.tzinfo is None or b >= now.astimezone(IST).date():
        raise ReadRequestError('Select completed historical dates')
    tfs = list(dict.fromkeys(timeframes))
    if not tfs or any(tf not in TIMEFRAMES for tf in tfs):
        raise ReadRequestError('Select supported timeframes')
    targets = _targets(reads.catalog, 'FNO', a, b, None, contract_ids, underlyings)
    if len(targets) * ((b-a).days+1) * len(tfs) > MAX_CHECKS:
        raise ReadRequestError('Select at most 500 contract/day/timeframe checks')
    before = fingerprint(calendar_metadata())
    cache = PartitionCache()
    checks = []
    complete = True
    for target in targets:
        for offset in range((b-a).days+1):
            day = a + dt.timedelta(days=offset)
            for tf in tfs:
                item = {'contract_id': target['id'], 'symbol': target['fyers_symbol'],
                        'date': str(day), 'timeframe': tf}
                checks.append(item)
                try:
                    if not calendar_verified(day, 'FNO'):
                        raise DataNotVerifiedError('Calendar evidence unavailable')
                    if day > target['expiry'] or target['category'] not in ('FUTURES', 'OPTIONS'):
                        raise DataNotVerifiedError('Invalid contract scope')
                    rows, sparse = verified_day(reads, target, tf, day, cache=cache)
                    item.update(status='VERIFIED_SPARSE' if sparse else 'VERIFIED_COMPLETE', rows=len(rows),
                                coverage='SPARSE_UNCONFIRMED' if sparse else 'COMPLETE')
                    if not rows:
                        item.update(status='NO_OBSERVATIONS', coverage='NO_SESSION')
                    item['optional_fields'] = {field: {
                        'present': sum(int(r.get(field) is not None and not pd.isna(r[field])) for r in rows),
                        'null': sum(int(r.get(field) is None or pd.isna(r[field])) for r in rows)}
                        for field in ('oi', 'iv', 'delta', 'gamma', 'theta', 'vega')}
                except AuditLimit:
                    item.update(status='NOT_VERIFIED', reason='READ_BOUND_EXCEEDED')
                    complete = False
                except DataNotVerifiedError as exc:
                    item.update(status='NOT_VERIFIED', reason=REASONS.get(str(exc), 'STRICT_VALUE_OR_COVERAGE_CHECK_FAILED'))
                    if item['reason'] == 'READ_BOUND_EXCEEDED':
                        complete = False
                except Exception:
                    item.update(status='NOT_VERIFIED', reason='SOURCE_INSPECTION_UNAVAILABLE')
                    complete = False
    try:
        stable = fingerprint(calendar_metadata()) == before and cache.unchanged(reads)
    except Exception:
        stable = False
    if not stable:
        complete = False
        for item in checks:
            item.update(status='NOT_VERIFIED', reason='SOURCE_OR_CALENDAR_CHANGED_DURING_AUDIT')
    values_ok = bool(checks) and all(c['status'] in ('VERIFIED_COMPLETE', 'VERIFIED_SPARSE') for c in checks)
    coverage_ok = values_ok and all(c['status'] == 'VERIFIED_COMPLETE' for c in checks)
    return {'status': 'PARTIAL' if not complete else 'FNO_VALUES_CHECK_PASS' if values_ok else 'FINDINGS',
        'complete': complete, 'segment': 'FNO', 'from': str(a), 'to': str(b),
        'values_verified': values_ok, 'complete_minute_coverage': coverage_ok,
        'checks': checks, 'summary': {'targets': len(targets), 'checks': len(checks),
            'statuses': dict(Counter(c['status'] for c in checks)),
            'verified_rows': sum(c.get('rows', 0) for c in checks if c['status'].startswith('VERIFIED_')),
            'shared_files_read': len(cache.files), 'parquet_rows_scanned': cache.scanned_rows,
            'sql_rows_read': cache.sql_rows},
        'issues': (['NO_TARGETS_IN_SCOPE'] if not targets else []) + ([] if stable else ['SOURCE_OR_CALENDAR_CHANGED_DURING_AUDIT']),
        'limits': {'max_checks': MAX_CHECKS, 'max_file_rows': MAX_FILE_ROWS,
                   'max_total_parquet_rows': MAX_TOTAL_ROWS, 'max_files': MAX_FILES,
                   'max_total_sql_rows': MAX_TOTAL_ROWS, 'sql_budget_sentinel_max_rows': MAX_CONTRACT_ROWS},
        'external_evidence_verified': False, 'unit_scale_verified': False,
        'live_verified': False, 'sql_modified': False, 'market_data_modified': False,
        'scope': 'Selected historical FNO values and declared-session coverage only. Sparse option values can match without proving minute completeness. Sequential reads are not a cross-store atomic snapshot. No broker/exchange truth, unit scale, index alignment or live-readiness certificate.'}
