"""
model/fno/parquet_store.py
Parquet storage for FNO candles. The root is a REQUIRED argument (no default),
so nothing can silently fall back to Subsystem A's `data/` tree.

Layout (relative to the FNO root):
    candles/<timeframe>/underlying=<U>/expiry=<YYYY-MM-DD>/date=<YYYY-MM-DD>.parquet
One file per underlying + expiry + day, with a contract_id column -- not one
tiny file per option contract per day. Timestamps are IST wall-clock
(timezone-naive), period start, matching the MySQL column.

Write protocol (per file):
    1. manifest row -> WRITING
    2. read the existing file (only if its manifest row is VERIFIED), merge
    3. write a temp file in the SAME folder
    4. validate the temp file (row count, timestamp range, schema, unique keys)
    5. os.replace() it over the final name (atomic on one filesystem)
    6. sha256 the result, manifest row -> VERIFIED
A crash between 5 and 6 leaves a WRITING row; `fno-reconcile` validates the file
and promotes or quarantines it. Readers use ONLY VERIFIED manifest entries.

Merge policy is the same as the MySQL policy (model/fno/repository.py):
CLOSED beats OPEN, an existing CLOSED candle's OHLCV is never overwritten
(conflicts are counted and dropped), NULL optional columns are filled.
"""

import datetime
import hashlib
import logging
import os
import re
import uuid
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import pyarrow.pandas_compat  # noqa: F401  (import on main thread; see model/storage/parquet.py)

from model.exceptions import ConfigurationError
from model.fno.config import assert_within_fno_root
from model.fno.errors import StorageVerificationError
from model.fno.models import FnoCandle

log = logging.getLogger("market_data.fno.parquet")

SCHEMA_VERSION = 1
DATASET_CANDLES = "candles"
KEY = ["contract_id", "timeframe", "candle_timestamp"]
OHLC = ["open", "high", "low", "close"]
OPTIONAL = ["oi", "iv", "delta", "gamma", "theta", "vega"]
CHAIN_COLUMNS = ["batch_id", "underlying", "captured_at", "chain_expiry", "contract_id", "strike", "side", "ltp", "bid", "ask",
                 "volume", "oi", "oi_change", "iv", "delta", "gamma", "theta", "vega"]
CHAIN_KEY = ["batch_id", "contract_id"]
COLUMNS = ["contract_id", "timeframe", "candle_timestamp", "open", "high", "low", "close", "volume",
           "oi", "iv", "delta", "gamma", "theta", "vega", "source", "status"]
_LOCKS = {}
_LOCKS_GUARD = threading.Lock()


def _read_frame(path, **kwargs):
    """Own and close the file handle before a later Windows publication."""
    with Path(path).open('rb') as stream:
        return pd.read_parquet(stream, **kwargs)


def _replace_candidate(source, target):
    """Retry only Windows sharing/lock violations, always the same candidate."""
    delays=(0.1,0.2,0.4,0.8)
    for attempt in range(len(delays)+1):
        try:
            os.replace(source,target)
            return
        except PermissionError as exc:
            if getattr(exc,'winerror',None) not in (32,33) or attempt==len(delays):
                raise
            time.sleep(delays[attempt])


def _safe(part: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]", "_", str(part))


def candles_to_frame(candles: list) -> pd.DataFrame:
    rows = [{
        "contract_id": int(c.contract_id), "timeframe": c.timeframe, "candle_timestamp": c.naive_ist(),
        "open": float(c.open), "high": float(c.high), "low": float(c.low), "close": float(c.close),
        "volume": int(c.volume), "oi": c.oi, "iv": None if c.iv is None else float(c.iv),
        "delta": None if c.delta is None else float(c.delta), "gamma": None if c.gamma is None else float(c.gamma),
        "theta": None if c.theta is None else float(c.theta), "vega": None if c.vega is None else float(c.vega),
        "source": c.source, "status": c.status,
    } for c in candles]
    return _typed(pd.DataFrame(rows, columns=COLUMNS))


def _typed(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["contract_id"] = df["contract_id"].astype("int64")
    df["candle_timestamp"] = pd.to_datetime(df["candle_timestamp"]).astype("datetime64[ns]")
    for c in OHLC + ["iv", "delta", "gamma", "theta", "vega"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float64")
    df["volume"] = pd.to_numeric(df["volume"]).astype("int64")
    df["oi"] = pd.to_numeric(df["oi"], errors="coerce").astype("Int64")
    for c in ("timeframe", "source", "status"):
        df[c] = df[c].astype("object")
    return df[COLUMNS]


def merge_candle_frames(existing: Optional[pd.DataFrame], new: pd.DataFrame) -> tuple:
    """Returns (merged_frame, stats). stats = {'new_rows', 'conflicts', 'duplicates'}."""
    new = new.copy()
    stats = {"new_rows": 0, "conflicts": 0, "duplicates": 0}
    if existing is None or len(existing) == 0:
        merged = (new.assign(_r=np.where(new["status"] == "CLOSED", 1, 2))
                  .sort_values(KEY + ["_r"], kind="stable").groupby(KEY, as_index=False, sort=True).first())
        stats["new_rows"] = len(merged)
        stats["duplicates"] = len(new) - len(merged)
        return _typed(merged.drop(columns="_r")), stats

    ec = existing[existing["status"] == "CLOSED"][KEY + OHLC + ["volume", "source"]]
    # An incoming OPEN bar must not back-fill optional columns on a conflicting
    # CLOSED candle; LIVE is ignored entirely after authoritative history.
    protected = ec[ec["source"] == "FYERS_HISTORICAL"][KEY]
    if len(protected):
        marked = new.merge(protected.assign(_protected=1),on=KEY,how="left")
        new = new[~((new["source"]=="FYERS_LIVE").to_numpy() & marked["_protected"].notna().to_numpy())]
    nc = new
    joined = nc.merge(ec, on=KEY, suffixes=("", "_e"))
    joined = joined[~((joined["source_e"]=="FYERS_LIVE") & (joined["source"]=="FYERS_HISTORICAL") & (joined["status"]=="CLOSED"))]
    if len(joined):
        same = np.isclose(joined[OHLC].to_numpy(float), joined[[c + "_e" for c in OHLC]].to_numpy(float),
                          rtol=0, atol=1e-6).all(axis=1) & (joined["volume"].to_numpy() == joined["volume_e"].to_numpy())
        bad = joined.loc[~same, KEY]
        if len(bad):
            stats["conflicts"] = len(bad)
            marked = new.merge(bad.assign(_bad=1), on=KEY, how="left")
            new = new[marked["_bad"].isna().to_numpy()]

    e, n = existing.assign(_src=0), new.assign(_src=1)
    df = pd.concat([e, n], ignore_index=True)
    closed = df["status"] == "CLOSED"
    hist = df["source"] != "FYERS_LIVE"                            # HISTORICAL/AGGREGATED outrank provisional LIVE
    df["_r"] = np.select([closed & hist & (df["_src"] == 0), closed & hist & (df["_src"] == 1),
                          closed & ~hist & (df["_src"] == 0), closed & ~hist & (df["_src"] == 1),
                          ~closed & (df["_src"] == 1)], [0, 1, 2, 3, 4], default=5)
    df = df.sort_values(KEY + ["_r"], kind="stable")
    merged = df.groupby(KEY, as_index=False, sort=True).first()
    merged = _typed(merged.drop(columns=["_r", "_src"]))
    stats["new_rows"] = len(merged) - len(existing)
    stats["duplicates"] = (len(existing) + len(new)) - len(merged) - 0
    return merged, stats


@dataclass
class ParquetWriteResult:
    files: list = field(default_factory=list)       # relative paths written
    new_rows: int = 0
    conflicts: int = 0
    quarantined_existing: list = field(default_factory=list)


class FnoParquetStore:
    def __init__(self, root, manifest):
        """root: REQUIRED FNO Parquet root. manifest: a FnoRepository (or None in unit tests)."""
        if root is None or str(root).strip() == "":
            raise ConfigurationError("FnoParquetStore needs an explicit root (no default).")
        self.root = Path(root).resolve()
        self.manifest = manifest

    # ---------------------------------------------------------------- paths
    def _guard(self, path) -> Path:
        return assert_within_fno_root(path, self.root)

    def relative_candle_path(self, timeframe: str, underlying: str, expiry: datetime.date, day: datetime.date) -> str:
        return (f"{DATASET_CANDLES}/{_safe(timeframe)}/underlying={_safe(underlying)}/"
                f"expiry={expiry.isoformat()}/date={day.isoformat()}.parquet")

    @staticmethod
    def partition_key(relative_path: str) -> str:
        parts = relative_path.split("/")
        return "/".join(parts[2:] if parts[0] == DATASET_CANDLES else parts[1:]).removesuffix(".parquet")

    def abs_path(self, relative_path: str) -> Path:
        return self._guard(self.root / relative_path)

    @contextmanager
    def lock_partition(self, rel):
        path = str(self.abs_path(rel))
        with _LOCKS_GUARD:
            lock = _LOCKS.setdefault(path,threading.RLock())
        with lock:
            engine = getattr(self.manifest,"engine",None)
            if engine is None:
                yield
            else:
                from model.fno.release3_repository import Release3Repository
                with Release3Repository(engine).partition_lock(rel):
                    yield

    # ----------------------------------------------------------------- write
    def write_candles(self, candles: list, contract_meta: dict, job_id: Optional[int] = None) -> ParquetWriteResult:
        """contract_meta: {contract_id: (underlying, expiry_date)}. Raises on any verification failure;
        a failed file leaves the previous VERIFIED file (if any) untouched."""
        result = ParquetWriteResult()
        groups: dict = {}
        for c in candles:
            underlying, expiry = contract_meta[c.contract_id]
            day = c.timestamp.date() if c.timestamp.tzinfo is None else c.naive_ist().date()
            groups.setdefault((c.timeframe, underlying, expiry, day), []).append(c)
        for (tf, underlying, expiry, day), items in sorted(groups.items(), key=lambda kv: str(kv[0])):
            rel = self.relative_candle_path(tf, underlying, expiry, day)
            with self.lock_partition(rel):
                stats = self._write_partition(rel, candles_to_frame(items), job_id, result)
            result.files.append(rel)
            result.new_rows += stats["new_rows"]
            result.conflicts += stats["conflicts"]
        return result

    def _read_trusted(self, rel: str, result: ParquetWriteResult) -> Optional[pd.DataFrame]:
        path = self.abs_path(rel)
        if not path.exists():
            return None
        if self.manifest is not None:
            entry = self.manifest.manifest_get(rel)
            if entry is None or entry["status"] != "VERIFIED":
                # Untrusted leftover (crash, manual edit). Keep it for inspection, rebuild from new rows;
                # fno-reconcile restores anything missing from MySQL (which is always written first).
                qdir = self._guard(self.root / "quarantine")
                qdir.mkdir(parents=True, exist_ok=True)
                target = qdir / f"{uuid.uuid4().hex[:8]}_{path.name}"
                os.replace(path, target)
                result.quarantined_existing.append(rel)
                log.warning("Existing Parquet file %s was not VERIFIED in the manifest; quarantined to %s", rel, target.name)
                return None
        return _typed(_read_frame(path))

    def _write_partition(self, rel: str, new_df: pd.DataFrame, job_id, result: ParquetWriteResult) -> dict:
        final = self.abs_path(rel)
        final.parent.mkdir(parents=True, exist_ok=True)
        prev = self.manifest.manifest_get(rel) if self.manifest is not None else None
        existing = self._read_trusted(rel, result)
        merged, stats = merge_candle_frames(existing, new_df)
        if self.manifest is not None:
            self.manifest.manifest_begin(rel, DATASET_CANDLES, new_df["timeframe"].iloc[0], self.partition_key(rel),
                                         len(merged), job_id)
        self._commit(rel, merged, DATASET_CANDLES, "candle_timestamp", prev,
                     lambda tmp: self._validate(tmp, merged), tf=new_df["timeframe"].iloc[0])
        return stats

    def _commit(self, rel: str, merged: pd.DataFrame, dataset: str, ts_col: str, prev, validate, tf=None) -> None:
        """temp file -> validate -> atomic rename -> manifest VERIFIED. A failure before the rename leaves the previous
        file and (restored) manifest row untouched."""
        final = self.abs_path(rel)
        tmp = final.parent / f".{final.name}.tmp-{os.getpid()}-{uuid.uuid4().hex[:8]}"
        replaced = False
        try:
            with tmp.open('xb') as stream:
                merged.to_parquet(stream, index=False, engine="pyarrow")
                stream.flush()
                os.fsync(stream.fileno())
            validate(tmp)
            _replace_candidate(tmp, final)
            replaced = True
            checksum = self.sha256(final)
            if self.manifest is not None:
                self.manifest.manifest_verify(rel, merged[ts_col].min().to_pydatetime(), merged[ts_col].max().to_pydatetime(),
                                              len(merged), checksum, SCHEMA_VERSION)
        except Exception as exc:
            if tmp.exists():
                try:tmp.unlink()
                except OSError:
                    # A sharing lock may also prevent cleanup. Keep diagnostic
                    # evidence and restore the prior manifest; do not mask the
                    # original publication failure with a second unlink error.
                    log.warning("Failed candidate retained for inspection: %s", tmp.name)
            if self.manifest is not None and not replaced:
                if prev is not None and prev["status"] == "VERIFIED":
                    self.manifest.manifest_verify(rel, prev["min_timestamp"], prev["max_timestamp"], prev["row_count"],
                                                  prev["checksum"], prev["schema_version"])
                else:
                    self.manifest.manifest_quarantine(rel, f"write failed: {type(exc).__name__}: {exc}")
            raise StorageVerificationError(f"Parquet write of {rel} failed: {type(exc).__name__}: {exc}") from exc

    # ------------------------------------------------------- option-chain snapshots
    def write_chain_snapshot(self, rows: list, underlying: str, day: datetime.date, job_id: Optional[int] = None) -> str:
        rel = f"option_chain/underlying={_safe(underlying)}/date={day.isoformat()}.parquet"
        with self.lock_partition(rel):
            return self._write_chain_snapshot(rows,underlying,day,job_id)

    def _write_chain_snapshot(self, rows: list, underlying: str, day: datetime.date, job_id: Optional[int] = None) -> str:
        """rows: dicts with CHAIN_COLUMNS keys. One file per underlying and day; merged on (batch_id, contract_id)."""
        rel = f"option_chain/underlying={_safe(underlying)}/date={day.isoformat()}.parquet"
        path = self.abs_path(rel); path.parent.mkdir(parents=True, exist_ok=True)
        prev = self.manifest.manifest_get(rel) if self.manifest is not None else None
        new_df = pd.DataFrame(rows, columns=CHAIN_COLUMNS)
        new_df["captured_at"] = pd.to_datetime(new_df["captured_at"]).astype("datetime64[ns]")
        for col in ("strike", "ltp", "bid", "ask", "iv", "delta", "gamma", "theta", "vega"):
            new_df[col] = pd.to_numeric(new_df[col], errors="coerce").astype("float64")
        for col in ("volume", "oi", "oi_change"):
            new_df[col] = pd.to_numeric(new_df[col], errors="coerce").astype("Int64")
        new_df["contract_id"] = new_df["contract_id"].astype("int64")
        new_df["chain_expiry"] = pd.to_datetime(new_df["chain_expiry"]).dt.date
        existing = None
        if path.exists():
            if self.manifest is None or (prev is not None and prev["status"] == "VERIFIED"):
                existing = _read_frame(path)
            else:
                q = self._guard(self.root / "quarantine"); q.mkdir(parents=True, exist_ok=True)
                os.replace(path, q / f"{uuid.uuid4().hex[:8]}_{path.name}")
        merged = pd.concat([existing, new_df], ignore_index=True) if existing is not None else new_df
        merged = merged.drop_duplicates(subset=CHAIN_KEY, keep="first").reset_index(drop=True)
        if self.manifest is not None:
            self.manifest.manifest_begin(rel, "option_chain", None, self.partition_key(rel), len(merged), job_id)

        def validate(tmp):
            back = _read_frame(tmp)
            if list(back.columns) != CHAIN_COLUMNS or len(back) != len(merged) or back.duplicated(subset=CHAIN_KEY).any():
                raise StorageVerificationError("chain snapshot file failed validation")
        self._commit(rel, merged, "option_chain", "captured_at", prev, validate)
        return rel

    @staticmethod
    def _validate(path: Path, expected: pd.DataFrame) -> None:
        back = _read_frame(path)
        if list(back.columns) != COLUMNS:
            raise StorageVerificationError(f"schema mismatch: {list(back.columns)}")
        if len(back) != len(expected):
            raise StorageVerificationError(f"row count {len(back)} != expected {len(expected)}")
        if len(back) and (back["candle_timestamp"].min() != expected["candle_timestamp"].min()
                          or back["candle_timestamp"].max() != expected["candle_timestamp"].max()):
            raise StorageVerificationError("timestamp range mismatch")
        if back.duplicated(subset=KEY).any():
            raise StorageVerificationError("duplicate (contract_id, timeframe, timestamp) keys")

    @staticmethod
    def sha256(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for block in iter(lambda: fh.read(1 << 20), b""):
                h.update(block)
        return h.hexdigest()

    # ------------------------------------------------------------------ read
    def replace_derived_partition(self, rel: str, candles: list, job_id=None):
        """Authoritative rebuild of one derived partition from MySQL.

        Called under the aggregation partition lock, after MySQL read-back.
        It deliberately bypasses the immutable canonical candle merge policy.
        """
        from model.fno.aggregation import MINUTES
        parts = rel.split("/")
        if len(parts) != 5 or parts[0] != "candles" or parts[1] not in MINUTES:
            raise ConfigurationError("Only derived FNO candle partitions can be replaced")
        path = self.abs_path(rel)
        frame = candles_to_frame(candles)
        if candles and (set(frame.timeframe) != {parts[1]} or set(frame.source) != {"AGGREGATED"}):
            raise ConfigurationError("Derived partition contains non-aggregated rows")
        prev = self.manifest.manifest_get(rel) if self.manifest is not None else None
        if self.manifest is not None:
            self.manifest.manifest_begin(rel, "candles", parts[1], self.partition_key(rel), len(frame), job_id)
        if not candles:
            path.unlink(missing_ok=True)
            if self.manifest is not None:
                self.manifest.manifest_delete(rel)
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        self._commit(rel, frame, "candles", "candle_timestamp", prev, lambda p: self._validate(p, frame))

    def read_partition(self, rel: str, contract_id: Optional[int] = None) -> Optional[pd.DataFrame]:
        """Reads one file ONLY if its manifest row is VERIFIED (or there is no manifest, in unit tests)."""
        path = self.abs_path(rel)
        if not path.exists():
            return None
        if self.manifest is not None:
            entry = self.manifest.manifest_get(rel)
            if entry is None or entry["status"] != "VERIFIED":
                return None
        filters = [("contract_id","=",int(contract_id))] if contract_id is not None else None
        return _typed(_read_frame(path,filters=filters))

    def list_candle_files(self) -> list:
        base = self.root / DATASET_CANDLES
        if not base.exists():
            return []
        return sorted(p.relative_to(self.root).as_posix() for p in base.rglob("date=*.parquet"))

    def list_chain_files(self) -> list:
        base = self.root / "option_chain"
        return sorted(p.relative_to(self.root).as_posix() for p in base.rglob("date=*.parquet")) if base.exists() else []

    def read_chain_partition(self, rel: str):
        """VERIFIED manifest rows only (or no manifest in unit tests)."""
        path = self.abs_path(rel)
        if not path.exists():
            return None
        if self.manifest is not None:
            entry = self.manifest.manifest_get(rel)
            if entry is None or entry["status"] != "VERIFIED":
                return None
        return _read_frame(path)

    def stale_temp_files(self) -> list:
        out = []
        for ds in (DATASET_CANDLES, "option_chain"):             # candles AND option-chain day files can leave temp files
            base = self.root / ds
            if base.exists():
                out += [p.relative_to(self.root).as_posix() for p in base.rglob(".*.tmp-*")]
        return sorted(out)

    # --------------------------------------------------------------- cleanup
    def cleanup_old_files(self, retain_days: int, dry_run: bool = True, confirm: bool = False,
                          today: Optional[datetime.date] = None, chain_retain_days: Optional[int] = None) -> list:
        """Deletes day-files older than retain_days under the FNO root ONLY. Dry-run by default; a real
        delete additionally requires confirm=True. MySQL candles are never touched by Parquet cleanup."""
        from model.fno.models import IST
        if retain_days < 0 or (chain_retain_days is not None and chain_retain_days < 0):
            raise ConfigurationError("Retention days must be non-negative")
        today = today or datetime.datetime.now(IST).date()
        cutoff = today - datetime.timedelta(days=retain_days)
        victims = []
        for rel in self.list_candle_files():
            m = re.search(r"date=(\d{4}-\d{2}-\d{2})\.parquet$", rel)
            if m and datetime.date.fromisoformat(m.group(1)) < cutoff:
                victims.append(rel)
        if chain_retain_days is not None:
            chain_cutoff = today - datetime.timedelta(days=chain_retain_days)
            base = self._guard(self.root / "option_chain")
            if base.exists():
                for path in sorted(base.rglob("date=*.parquet")):
                    self._guard(path)
                    m = re.search(r"date=(\d{4}-\d{2}-\d{2})\.parquet$",path.name)
                    if m and datetime.date.fromisoformat(m.group(1)) < chain_cutoff:
                        victims.append(path.relative_to(self.root).as_posix())
        if dry_run:
            return victims
        if not confirm:
            raise ConfigurationError("Deleting Parquet files requires confirm=True (dry-run is the default).")
        for rel in victims:
            with self.lock_partition(rel):
                self._guard(self.root / rel).unlink(missing_ok=True)
                if self.manifest is not None:
                    self.manifest.manifest_delete(rel)
        if victims:
            log.info("FNO Parquet cleanup removed %d file(s) older than %s", len(victims), cutoff)
        return victims


def frame_to_candles(df: pd.DataFrame) -> list:
    """Parquet rows -> FnoCandle (used by reconcile to repair MySQL from Parquet)."""
    from model.fno.models import IST
    out = []
    num = lambda v: None if pd.isna(v) else Decimal(str(v))
    for r in df.itertuples(index=False):
        out.append(FnoCandle(
            contract_id=int(r.contract_id), timeframe=r.timeframe,
            timestamp=r.candle_timestamp.to_pydatetime().replace(tzinfo=IST),
            open=Decimal(str(r.open)), high=Decimal(str(r.high)), low=Decimal(str(r.low)), close=Decimal(str(r.close)),
            volume=int(r.volume), oi=None if pd.isna(r.oi) else int(r.oi), iv=num(r.iv), delta=num(r.delta),
            gamma=num(r.gamma), theta=num(r.theta), vega=num(r.vega), source=r.source, status=r.status))
    return out
