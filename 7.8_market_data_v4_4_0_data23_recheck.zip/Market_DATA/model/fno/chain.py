"""
model/fno/chain.py
Parses an options-chain-v3 response, using the field layout CONFIRMED by the probe (2026-10-22):
  data.optionsChain[]  -> first row is the UNDERLYING (option_type "", strike_price -1); option rows carry
                          symbol (a real FYERS symbol), strike_price, option_type CE|PE, ltp, bid, ask, volume,
                          oi, oich (OI change), oichp, prev_oi, fyToken
  with greeks=1        -> option rows gain "greeks": {delta, gamma, theta, vega, iv}; iv is in PERCENT
  data.expiryData[]    -> available expiries (shape tolerated, see parse_expiry_data)
  no capture time exists in the response: the caller stamps its own clock.
Unknown / not-quoted values stay None (a 0 bid/ask/ltp means "no quote" and is stored NULL, never 0).
"""
import datetime
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Optional

from model.fno.symbol_master import parse_expiry

_Q4, _Q6, _Q8 = Decimal("0.0001"), Decimal("0.000001"), Decimal("0.00000001")


def _d(v, q, zero_is_none=False) -> Optional[Decimal]:
    if v is None or isinstance(v, bool):
        return None
    try:
        d = Decimal(str(v)).quantize(q)
    except (InvalidOperation, ValueError):
        return None
    if not d.is_finite():
        return None
    return None if (zero_is_none and d == 0) else d


def _i(v) -> Optional[int]:
    if v is None or isinstance(v, bool):
        return None
    try:
        value = Decimal(str(v))
        return int(value) if value.is_finite() and value == value.to_integral() else None
    except (TypeError, ValueError, InvalidOperation, OverflowError):
        return None


@dataclass
class ChainParse:
    rows: list = field(default_factory=list)            # option rows as dicts
    underlying_ltp: Optional[Decimal] = None
    expiries: list = field(default_factory=list)        # [(date, timestamp_str)]
    skipped: dict = field(default_factory=dict)

    def skip(self, why):
        self.skipped[why] = self.skipped.get(why, 0) + 1


def parse_expiry_data(items) -> list:
    """Tolerant: each item {"date": "DD-MM-YYYY", "expiry": "<epoch>"} (FYERS docs shape; NOT yet seen in a probe)."""
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        ts = it.get("expiry") or it.get("timestamp")
        d = parse_expiry(it.get("date")) or parse_expiry(ts)
        if d is not None and ts not in (None, ""):
            out.append((d, str(ts)))
    return sorted(out)


def parse_chain(resp: dict) -> ChainParse:
    out = ChainParse()
    data = (resp or {}).get("data") or {}
    out.expiries = parse_expiry_data(data.get("expiryData"))
    for e in data.get("optionsChain") or []:
        if not isinstance(e, dict):
            out.skip("malformed_entry"); continue
        side = (e.get("option_type") or "").upper()
        if side == "":
            out.underlying_ltp = _d(e.get("ltp"), _Q4, True); continue
        if side not in ("CE", "PE") or not e.get("symbol"):
            out.skip("unclassifiable_entry"); continue
        g = e.get("greeks") if isinstance(e.get("greeks"), dict) else {}
        out.rows.append({
            "symbol": e["symbol"], "strike": _d(e.get("strike_price"), _Q4), "side": side,
            "ltp": _d(e.get("ltp"), _Q4, True), "bid": _d(e.get("bid"), _Q4, True), "ask": _d(e.get("ask"), _Q4, True),
            "volume": _i(e.get("volume")), "oi": _i(e.get("oi")), "oi_change": _i(e.get("oich")),
            "iv": _d(g.get("iv"), _Q6), "delta": _d(g.get("delta"), _Q8), "gamma": _d(g.get("gamma"), _Q8),
            "theta": _d(g.get("theta"), _Q8), "vega": _d(g.get("vega"), _Q8)})
    return out
