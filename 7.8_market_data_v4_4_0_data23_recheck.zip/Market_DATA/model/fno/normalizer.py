"""
model/fno/normalizer.py
Raw FYERS history rows -> FnoCandle, plus validation.

The session window comes from config (default 09:15-15:39, confirmed from real FYERS data).
Row layout assumed: [epoch, open, high, low, close, volume(, oi)]. The optional
7th column is read as open interest ONLY when history.oi_flag is enabled in
config (i.e. after the probe confirmed it). Anything unparseable is rejected
and reported, never repaired. Unknown optional values stay None (never 0).
"""
import datetime
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

from model.fno.config import SessionSettings, DEFAULT_SESSION
from model.fno.models import FnoCandle, IST, SOURCE_HISTORICAL

_Q4 = Decimal("0.0001")


@dataclass
class Rejected:
    row: object
    reason: str


@dataclass
class NormalizeResult:
    valid: list = field(default_factory=list)
    invalid: list = field(default_factory=list)       # list[Rejected]
    response_duplicates: int = 0                      # identical repeated timestamps INSIDE one FYERS response (dropped)

    @property
    def raw_count(self):
        return len(self.valid) + len(self.invalid) + self.response_duplicates      # everything FYERS returned


def _price(v) -> Decimal:
    d = Decimal(str(v)).quantize(_Q4)
    if not d.is_finite():
        raise InvalidOperation
    return d


def normalize_history_rows(rows: list, contract_id: int, timeframe: str = "1m", oi_enabled: bool = False,
                           source: str = SOURCE_HISTORICAL, session: SessionSettings = DEFAULT_SESSION) -> NormalizeResult:
    res = NormalizeResult()
    seen: dict = {}
    for raw in rows or []:
        try:
            if not isinstance(raw, (list, tuple)) or len(raw) < 6:
                res.invalid.append(Rejected(raw, "malformed_row")); continue
            ts = datetime.datetime.fromtimestamp(float(raw[0]), tz=datetime.timezone.utc).astimezone(IST)
            o, h, l, c = (_price(raw[i]) for i in range(1, 5))
            vol_value=Decimal(str(raw[5]))
            if not vol_value.is_finite() or vol_value!=vol_value.to_integral() or isinstance(raw[5],bool):raise ValueError("Invalid volume")
            vol = int(vol_value)
            oi = None
            if oi_enabled and len(raw) >= 7 and raw[6] is not None:
                if isinstance(raw[6], bool):raise ValueError('Invalid OI')
                oi_value=Decimal(str(raw[6]))
                if not oi_value.is_finite() or oi_value!=oi_value.to_integral():raise ValueError("Invalid OI")
                oi = int(oi_value)
        except (ValueError, TypeError, InvalidOperation, OverflowError, OSError):
            res.invalid.append(Rejected(raw, "unparseable_value")); continue
        cand = FnoCandle(contract_id=contract_id, timeframe=timeframe, timestamp=ts, open=o, high=h, low=l, close=c,
                         volume=vol, oi=oi, source=source, status="CLOSED")
        reason = validate_candle(cand, session)
        if reason:
            res.invalid.append(Rejected(raw, reason)); continue
        key = cand.timestamp
        if key in seen:
            prev = seen[key]
            if (prev.open, prev.high, prev.low, prev.close, prev.volume, prev.oi) == (cand.open, cand.high, cand.low, cand.close, cand.volume, cand.oi):
                res.response_duplicates += 1            # FYERS sent the same candle twice: keep one
            else:
                res.invalid.append(Rejected(raw, "conflicting_duplicate_timestamp"))
            continue
        seen[key] = cand
        res.valid.append(cand)
    return res


def validate_candle(c: FnoCandle, session: SessionSettings = DEFAULT_SESSION):
    """Returns None if valid, else a short reason string."""
    if min(c.open, c.high, c.low, c.close) <= 0:
        return "non_positive_price"
    if c.high < max(c.open, c.close, c.low) or c.low > min(c.open, c.close, c.high):
        return "invalid_ohlc"
    if c.volume < 0:
        return "negative_volume"
    if c.oi is not None and c.oi < 0:
        return "negative_oi"
    if c.timeframe == "1m":
        t = c.timestamp.astimezone(IST)
        if t.second or t.microsecond:
            return "timestamp_not_on_minute"
        from model.config.market_calendar import calendar_metadata, in_session
        special = calendar_metadata().get('special_sessions', {}).get(t.date().isoformat())
        applies = (isinstance(special, dict) and special.get('verified')
                   and 'FNO' in special.get('segments', ['CASH', 'FNO']))
        if applies:
            if not in_session(t, 'FNO', session=session):
                return 'outside_session'
            return None
        if not (session.open <= t.time() <= session.last_minute):
            return "outside_session"
        if session.reject_weekend_timestamps and t.weekday() >= 5:
            return "weekend_timestamp"
    return None


def normalize_expired_rows(rows,columns,contract_id,session=DEFAULT_SESSION):
    """Optional fields are resolved by name. Never guess OI/Greek positions."""
    from dataclasses import replace
    result=NormalizeResult()
    core=['timestamp','open','high','low','close','volume']
    if (not isinstance(columns, (list, tuple)) or not all(isinstance(c, str) for c in columns)
            or list(columns[:6]) != core or len(set(columns)) != len(columns)
            or {'iv', 'implied_volatility'} <= set(columns)):
        return NormalizeResult(invalid=[Rejected(r,'unverified_expired_schema') for r in rows])
    aliases={'open_interest':'oi','implied_volatility':'iv','iv':'iv','delta':'delta','gamma':'gamma','theta':'theta','vega':'vega'}
    seen_ts={}
    for row in rows:
        if not isinstance(row, (list, tuple)):
            result.invalid.append(Rejected(row, 'malformed_row')); continue
        if len(row)!=len(columns):result.invalid.append(Rejected(row,'column_count'));continue
        normal=normalize_history_rows([row[:6]],contract_id,session=session)
        if normal.invalid:result.invalid.extend(normal.invalid);continue
        try:
            values={}
            for column,field in aliases.items():
                if column not in columns:continue
                value=row[columns.index(column)]
                if value is None:values[field]=None;continue
                decimal=Decimal(str(value))
                if not decimal.is_finite():raise ValueError('nonfinite')
                if field=='oi':
                    if decimal!=decimal.to_integral() or decimal<0:raise ValueError('invalid OI')
                    value=int(decimal)
                else:value=decimal
                if field=='iv' and decimal<0:raise ValueError('invalid IV')
                values[field]=value
            cand=replace(normal.valid[0],**values)
            prev=seen_ts.get(cand.timestamp)
            if prev is not None:
                if (prev.open,prev.high,prev.low,prev.close,prev.volume,prev.oi,prev.iv,prev.delta,prev.gamma,prev.theta,prev.vega)==(cand.open,cand.high,cand.low,cand.close,cand.volume,cand.oi,cand.iv,cand.delta,cand.gamma,cand.theta,cand.vega):
                    result.response_duplicates+=1
                else:result.invalid.append(Rejected(row,'conflicting_duplicate_timestamp'))
                continue
            seen_ts[cand.timestamp]=cand
            result.valid.append(cand)
        except (ValueError,InvalidOperation):result.invalid.append(Rejected(row,'invalid_optional_value'))
    return result
