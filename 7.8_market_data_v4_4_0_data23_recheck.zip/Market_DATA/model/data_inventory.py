"""Bounded, provider-free candle inventory; never writes SQL or source files.

Counts and timestamp/status keys are inspected. OHLCV values and manifest
checksums are deliberately NOT certified by this inventory.
"""
import datetime as dt
import re
from collections import Counter, defaultdict
from pathlib import Path

from sqlalchemy import and_, or_, select

from model.config.market_calendar import IST, calendar_verified, expected_starts
from model.quality import stamp
from model.read_contracts import ReadRequestError, date_scope, segment_name
from model.storage_scope import validate_storage_roots
from model.timeframes import TIMEFRAMES

MAX_TARGETS = 50
MAX_PARTITIONS = 1000
MAX_SQL_ROWS = 20000
MAX_FILE_ROWS = 200000
MAX_TOTAL_ROWS = 500000


def _version(path):
    s = path.stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def _safe_path(root, relative):
    path = root / relative
    if not path.resolve().is_relative_to(root):
        raise ValueError('Unsafe partition path')
    if any(p.is_symlink() or getattr(p, 'is_junction', lambda: False)()
           for p in (path, *path.parents)):
        raise ValueError('Linked partition path')
    return path


def _targets(catalog, segment, a, b, symbols, contract_ids, underlyings):
    master = catalog.table(segment, 'instruments' if segment == 'CASH' else 'fno_instruments')
    if segment == 'CASH':
        if not symbols or contract_ids or underlyings:
            raise ReadRequestError('CASH requires --symbols only')
        names = set(symbols)
        if len(names) > MAX_TARGETS:
            raise ReadRequestError('Select at most 50 targets')
        predicate = or_(master.c.internal_name.in_(names), master.c.fyers_symbol.in_(names))
    else:
        if symbols or bool(contract_ids) == bool(underlyings):
            raise ReadRequestError('FNO requires either --contract-ids or --underlyings')
        if contract_ids:
            if len(set(contract_ids)) > MAX_TARGETS or any(type(i) is not int or i <= 0 for i in contract_ids):
                raise ReadRequestError('Select at most 50 positive contract IDs')
            predicate = master.c.id.in_(contract_ids)
        else:
            if len(set(underlyings)) > MAX_TARGETS:
                raise ReadRequestError('Select at most 50 underlyings')
            candles = catalog.table('FNO', 'fno_candles')
            checkpoints = catalog.table('FNO', 'fno_checkpoint_ranges')
            lo = dt.datetime.combine(a, dt.time())
            hi = dt.datetime.combine(b + dt.timedelta(days=1), dt.time())
            data = select(candles.c.contract_id).where(candles.c.candle_timestamp >= lo,
                                                       candles.c.candle_timestamp < hi)
            claims = select(checkpoints.c.contract_id).where(checkpoints.c.range_from <= b,
                                                              checkpoints.c.range_to >= a)
            predicate = and_(master.c.underlying.in_([u.upper() for u in underlyings]),
                             or_(master.c.id.in_(data), master.c.id.in_(claims)))
    with catalog.engine(segment).connect() as conn:
        result = [dict(r) for r in conn.execute(select(master).where(predicate).order_by(master.c.id)
                                               .limit(MAX_TARGETS + 1)).mappings()]
    if len(result) > MAX_TARGETS:
        raise ReadRequestError('More than 50 targets; narrow the selection or dates')
    if segment == 'CASH':
        found = {str(t[k]) for t in result for k in ('internal_name', 'fyers_symbol')}
        if names - found:
            raise ReadRequestError('Some selected CASH symbols are not registered')
    elif contract_ids and set(contract_ids) - {t['id'] for t in result}:
        raise ReadRequestError('Some selected FNO contract IDs are not registered')
    for t in result:
        if not re.fullmatch(r'[A-Za-z0-9:_&.\-]{1,80}', t['fyers_symbol']):
            raise ReadRequestError('Unsupported stored symbol spelling')
        if segment == 'FNO':
            if not re.fullmatch(r'[A-Za-z0-9_&.\-]{1,40}', t['underlying']):
                raise ReadRequestError('Unsupported stored underlying spelling')
            if not isinstance(t['expiry'], dt.date):
                t['expiry'] = dt.date.fromisoformat(str(t['expiry']))
    return result


def _expected(segment, day, timeframe, session):
    if segment == 'FNO':
        from model.fno.aggregation import session_minutes, buckets
        return set(session_minutes(day, session) if timeframe == '1m'
                   else (start for start, _ in buckets(day, timeframe, session)))
    starts = expected_starts(day)
    if timeframe == '1m':
        return set(starts)
    from model.processing.timeframe_aggregator import _bucket_start
    return {_bucket_start(ts, timeframe) for ts in starts}


def _stats(rows):
    keys = [(stamp(r['candle_timestamp']), str(r['status'])) for r in rows]
    timestamps = [k[0] for k in keys]
    if any(status not in ('OPEN', 'CLOSED') for _, status in keys):
        raise ValueError('Invalid candle status')
    return {'rows': len(rows), 'closed_rows': sum(s == 'CLOSED' for _, s in keys),
            'open_rows': sum(s == 'OPEN' for _, s in keys),
            'duplicate_timestamps': len(timestamps) - len(set(timestamps)),
            'first': min(timestamps).isoformat() if timestamps else None,
            'last': max(timestamps).isoformat() if timestamps else None}, keys


class _Files:
    def __init__(self):
        self.cache = {}
        self.rows = 0

    def read(self, path, segment):
        key = str(path)
        if key in self.cache:
            return self.cache[key]
        result = {'status': 'READ_ERROR', 'groups': {}}
        self.cache[key] = result
        if not path.exists():
            result['status'] = 'MISSING'
            return result
        import pyarrow.parquet as pq
        before = _version(path)
        with path.open('rb') as stream:
            file = pq.ParquetFile(stream)
            size = file.metadata.num_rows
            if size > MAX_FILE_ROWS or self.rows + size > MAX_TOTAL_ROWS:
                result['status'] = 'ROW_BOUND_EXCEEDED'
                return result
            self.rows += size
            identity = 'fyers_symbol' if segment == 'CASH' else 'contract_id'
            fields = [identity, 'timeframe', 'candle_timestamp', 'status']
            if not set(fields) <= set(file.schema_arrow.names):
                raise ValueError('Partition identity columns unavailable')
            groups = defaultdict(list)
            for batch in file.iter_batches(batch_size=2000, columns=fields):
                for row in batch.to_pylist():
                    groups[(row[identity], row['timeframe'])].append(row)
        if _version(path) != before:
            result['status'] = 'CHANGED_DURING_READ'
            return result
        result.update(status='READ', groups=dict(groups), file_rows=size)
        return result


def inventory_report(catalog, segment, start, end, *, symbols=None, contract_ids=None,
                     underlyings=None, timeframes=TIMEFRAMES, now=None):
    segment = segment_name(segment)
    a, b = date_scope(start, end, max_days=31)
    now = now or dt.datetime.now(IST)
    if now.tzinfo is None or b >= now.astimezone(IST).date():
        raise ReadRequestError('Inventory requires completed historical dates')
    timeframes = list(dict.fromkeys(timeframes))
    if not timeframes or any(tf not in TIMEFRAMES for tf in timeframes):
        raise ReadRequestError('Select supported timeframes')
    roots = validate_storage_roots(catalog.roots)
    if segment not in roots:
        raise ReadRequestError('Selected Parquet root is not configured')
    root = Path(roots[segment]['root'])
    targets = _targets(catalog, segment, a, b, symbols, contract_ids, underlyings)
    days = [a + dt.timedelta(days=i) for i in range((b-a).days + 1)]
    if len(targets) * len(days) * len(timeframes) > MAX_PARTITIONS:
        raise ReadRequestError('Scope exceeds 1000 target/day/timeframe partitions; narrow it')
    table = catalog.table(segment, 'candles' if segment == 'CASH' else 'fno_candles')
    identity = table.c.instrument_id if segment == 'CASH' else table.c.contract_id
    session = None
    claims, manifest = [], {}
    if segment == 'FNO':
        from model.fno.config import DEFAULT_SESSION
        session = getattr(getattr(catalog, 'fno_settings', None), 'session', DEFAULT_SESSION)
        ck = catalog.table('FNO', 'fno_checkpoint_ranges')
        with catalog.engine('FNO').connect() as conn:
            claims = [dict(r) for r in conn.execute(select(ck.c.contract_id, ck.c.timeframe, ck.c.status,
                ck.c.job_type, ck.c.range_from, ck.c.range_to).where(ck.c.contract_id.in_([t['id'] for t in targets]),
                    ck.c.range_from <= b, ck.c.range_to >= a).limit(10001)).mappings()]
        if len(claims) > 10000:
            raise ReadRequestError('Checkpoint metadata exceeds inventory bound')
        mt = catalog.table('FNO', 'fno_storage_manifest')
    files = _Files()
    rows, sql_total = [], 0
    with catalog.engine(segment).connect() as conn:
        for target in targets:
            for day in days:
                for tf in timeframes:
                    item = {'id': target['id'], 'symbol': target['fyers_symbol'], 'date': day.isoformat(),
                            'timeframe': tf, 'issues': [], 'values_verified': False}
                    rows.append(item)
                    try:
                        expected = _expected(segment, day, tf, session)
                        expired = segment == 'FNO' and day > target['expiry']
                        if expired:
                            expected = set()
                        item['after_expiry'] = expired
                        known = calendar_verified(day, segment)
                        if not known:
                            item['issues'].append('CALENDAR_UNVERIFIED')
                        if sql_total >= MAX_TOTAL_ROWS:
                            item['issues'].append('SQL_ROW_BUDGET_EXCEEDED')
                            continue
                        lo = dt.datetime.combine(day, dt.time())
                        data = [dict(r) for r in conn.execute(select(table.c.candle_timestamp, table.c.status)
                            .where(identity == target['id'], table.c.timeframe == tf,
                                   table.c.candle_timestamp >= lo, table.c.candle_timestamp < lo + dt.timedelta(days=1))
                            .order_by(table.c.candle_timestamp)
                            .limit(min(MAX_SQL_ROWS, MAX_TOTAL_ROWS-sql_total)+1)).mappings()]
                        sql_total += len(data)
                        if sql_total > MAX_TOTAL_ROWS:
                            item['issues'].append('SQL_ROW_BUDGET_EXCEEDED')
                            continue
                        if len(data) > MAX_SQL_ROWS:
                            item['issues'].append('SQL_PARTITION_ROW_BOUND_EXCEEDED')
                            continue
                        item['sql'], sql_keys = _stats(data)
                        if segment == 'CASH':
                            relative = ('raw/1m' if tf == '1m' else 'processed/' + tf) + '/' + target['fyers_symbol'].replace(':', '_') + '/' + day.isoformat() + '.parquet'
                        else:
                            relative = f"candles/{tf}/underlying={target['underlying']}/expiry={target['expiry']}/date={day}.parquet"
                            if relative not in manifest:
                                manifest[relative] = conn.execute(select(mt.c.status).where(mt.c.relative_path == relative)).scalar_one_or_none()
                            item['manifest_status'] = manifest[relative]
                        item['relative_path'] = relative
                        path = _safe_path(root, relative)
                        file = files.read(path, segment)
                        if file['status'] not in ('READ', 'MISSING'):
                            item['issues'].append('PARQUET_' + file['status'])
                            continue
                        pq_data = file['groups'].get((target['fyers_symbol'] if segment == 'CASH' else target['id'], tf), [])
                        # Wrong symbol/timeframe in a CASH-owned file is never silently ignored.
                        if segment == 'CASH' and any(key != (target['fyers_symbol'], tf) for key in file['groups']):
                            item['issues'].append('PARQUET_IDENTITY_MISMATCH')
                        if segment == 'FNO' and any(key[1] != tf for key in file['groups']):
                            item['issues'].append('PARQUET_TIMEFRAME_MISMATCH')
                        item['parquet'], pq_keys = _stats(pq_data)
                        item['parquet']['file_status'] = file['status']
                        if segment == 'FNO' and (file['status'] == 'READ' or item['manifest_status']) and item['manifest_status'] != 'VERIFIED':
                            item['issues'].append('MANIFEST_NOT_VERIFIED')
                        if segment == 'FNO' and item['manifest_status'] and file['status'] == 'MISSING':
                            item['issues'].append('MANIFEST_FILE_MISSING')
                        item['keys_match'] = Counter(sql_keys) == Counter(pq_keys)
                        if not item['keys_match']:
                            item['issues'].append('SQL_PARQUET_KEY_MISMATCH')
                        item['coverage'] = {'calendar_verified': known, 'expected_slots': len(expected)}
                        for name, keys in [('sql', sql_keys), ('parquet', pq_keys)]:
                            closed = {ts for ts, status in keys if status == 'CLOSED'}
                            missing = sorted(expected - closed)
                            item['coverage'][name] = {'observed_closed_slots': len(closed & expected),
                                'unobserved_slots': len(missing), 'unobserved_samples': [ts.isoformat() for ts in missing[:10]],
                                'unobserved_samples_truncated': len(missing) > 10,
                                'outside_expected_slots': sum(ts not in expected for ts, _ in keys)}
                            if missing:
                                item['issues'].append(name.upper() + '_UNOBSERVED_SLOTS')
                            if any(ts not in expected for ts, _ in keys):
                                item['issues'].append(name.upper() + '_OUTSIDE_SESSION_OR_EXPIRY')
                            if item[name]['duplicate_timestamps'] or item[name]['open_rows']:
                                item['issues'].append(name.upper() + '_DUPLICATE_OR_OPEN_ROWS')
                        if segment == 'FNO':
                            item['checkpoint_statuses'] = sorted({ck['status'] for ck in claims
                                if ck['contract_id'] == target['id'] and ck['timeframe'] == tf and ck['range_from'] <= day <= ck['range_to']})
                        if not data and not pq_data and expected:
                            item['issues'].append('NO_CANDLES_OBSERVED')
                    except Exception as exc:
                        item['issues'].append('INSPECTION_UNAVAILABLE')
                        item['error_type'] = type(exc).__name__  # Never include credentials/DB URLs.
    incomplete_codes = {'INSPECTION_UNAVAILABLE', 'SQL_ROW_BUDGET_EXCEEDED', 'SQL_PARTITION_ROW_BOUND_EXCEEDED',
                        'PARQUET_ROW_BOUND_EXCEEDED', 'PARQUET_CHANGED_DURING_READ', 'PARQUET_READ_ERROR'}
    complete = not any(incomplete_codes.intersection(r['issues']) for r in rows)
    totals = Counter(code for row in rows for code in row['issues'])
    if not targets:
        totals['NO_TARGETS_IN_SCOPE'] += 1
    if not root.is_dir():
        totals['PARQUET_ROOT_MISSING'] += 1
    summaries = []
    for target in targets:
        selected = [r for r in rows if r['id'] == target['id']]
        firsts = [r['sql']['first'] for r in selected if r.get('sql', {}).get('first')]
        lasts = [r['sql']['last'] for r in selected if r.get('sql', {}).get('last')]
        summaries.append({'id': target['id'], 'symbol': target['fyers_symbol'],
            'category': target.get('category', target.get('instrument_type')),
            **({'underlying': target['underlying'], 'expiry': target['expiry'].isoformat()} if segment == 'FNO' else {}),
            'first_sql_in_scope': min(firsts) if firsts else None, 'last_sql_in_scope': max(lasts) if lasts else None,
            'sql_rows': sum(r.get('sql', {}).get('rows', 0) for r in selected),
            'parquet_rows': sum(r.get('parquet', {}).get('rows', 0) for r in selected),
            'base_days_observed': sorted({r['date'] for r in selected if r['timeframe'] == '1m' and r.get('sql', {}).get('closed_rows', 0)}),
            'base_days_without_candles': sorted({r['date'] for r in selected if r['timeframe'] == '1m' and 'NO_CANDLES_OBSERVED' in r['issues']})})
    status = 'PARTIAL' if not complete else 'FINDINGS' if totals or not targets else 'SCOPED_INVENTORY_PASS'
    return {'status': status, 'complete': complete, 'segment': segment, 'from': str(a), 'to': str(b),
        'as_of': now.isoformat(), 'storage_root': str(root), 'storage_root_exists': root.is_dir(),
        'targets': summaries, 'partitions': rows,
        'summary': {'targets': len(targets), 'partitions': len(rows), 'issues': dict(totals),
                    'sql_rows_read': sql_total, 'unique_parquet_paths_inspected': len(files.cache),
                    'parquet_files_read': sum(f['status'] == 'READ' for f in files.cache.values()),
                    'parquet_rows_read': files.rows},
        'limits': {'max_days': 31, 'max_targets': MAX_TARGETS, 'max_partitions': MAX_PARTITIONS,
                   'max_sql_rows_per_partition': MAX_SQL_ROWS, 'max_parquet_rows_per_file': MAX_FILE_ROWS,
                   'max_rows_per_store': MAX_TOTAL_ROWS},
        'values_verified': False, 'sql_modified': False, 'market_data_modified': False,
        'scope': 'Requested historical range only; counts and timestamp/status keys. OHLCV/OI values, checksums and trading readiness NOT certified. Unobserved option slots do not prove missing trades. Concurrent SQL/Parquet reads are not an atomic snapshot.'}
