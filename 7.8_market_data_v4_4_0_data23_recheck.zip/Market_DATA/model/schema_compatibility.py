"""Read-only comparison of repository MySQL contracts with SQLAlchemy reflection.

This deliberately accepts only the small CREATE TABLE grammar used by this repo.
Unknown clauses fail closed rather than silently omitting a contract requirement.
"""
import re
from sqlalchemy.dialects import mysql
from model.quality_store import ADDITIONS


def _parts(value):
    parts, start, depth, quote = [], 0, 0, None
    for i, ch in enumerate(value):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "'\"`":
            quote = ch
        elif ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == ',' and depth == 0:
            parts.append(value[start:i].strip()); start = i + 1
    if depth or quote:
        raise ValueError('Unbalanced repository schema definition')
    return parts + [value[start:].strip()]


def _type(value):
    # SQLAlchemy includes reflected string collation/charset in compiled types.
    # Those attributes are explicitly outside this comparator's contract.
    value = re.sub(r'\s+(?:CHARACTER\s+SET|COLLATE)\s+(?:`\w+`|\w+)', '', value, flags=re.I)
    value = re.sub(r'\s+', '', value.upper())
    value = value.replace('INTEGER', 'INT').replace('NUMERIC', 'DECIMAL')
    if value in ('BOOLEAN', 'BOOL', 'TINYINT(1)'):
        return 'TINYINT'
    # MySQL integer display widths do not change storage or value range.
    value = re.sub(r'^(BIGINT|INT|SMALLINT|TINYINT|MEDIUMINT)\(\d+\)', r'\1', value)
    return value.replace('DATETIME(0)', 'DATETIME')


def _default(value):
    if value is None:
        return None
    value = str(value).strip()
    if value.upper() == 'NULL':
        return None
    if value.startswith("'") and value.endswith("'"):
        value = value[1:-1]
        if not re.fullmatch(r'\d+', value):
            return 'literal:' + value
    upper = value.upper()
    if upper in ('TRUE', 'FALSE'):
        return '1' if upper == 'TRUE' else '0'
    if upper in ('CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP()'):
        return 'CURRENT_TIMESTAMP'
    return value


def _check(value):
    canonical = _check_tree(value)
    if canonical is not None:
        return repr(canonical)
    # Strict fallback for grammar not handled above; preserve literal case.
    tokens = re.split(r"('[^']*')", value)
    value = ''.join(t if i % 2 else re.sub(r'[\s`]+', '', t).upper() for i, t in enumerate(tokens))
    while value.startswith('(') and value.endswith(')'):
        depth = 0
        for i, ch in enumerate(value):
            depth += (ch == '(') - (ch == ')')
            if depth == 0:
                break
        if i != len(value) - 1:
            break
        value = value[1:-1]
    return value


def _check_tree(value):
    """Parse only owned predicate grammar; preserve precedence and literal case.

    MySQL adds grouping and utf8mb4 literal introducers during reflection. Unknown
    operators/introducers fall back to strict textual comparison, never omission.
    """
    pattern = r"\s+|'(?:''|[^'\\])*'|`[A-Za-z_][A-Za-z_0-9]*`|[A-Za-z_][A-Za-z_0-9]*|\d+(?:\.\d+)?|<=|>=|<>|!=|[=<>(),]"
    pieces = re.findall(pattern, value)
    if ''.join(pieces) != value:
        return None
    tokens = [p if p.startswith("'") else p.strip('`').upper()
              for p in pieces if not p.isspace()]
    # Accept only the introducer emitted for this repository's utf8mb4 literals.
    tokens = [p for i, p in enumerate(tokens) if not
              (p == '_UTF8MB4' and i + 1 < len(tokens) and tokens[i + 1].startswith("'"))]
    position = 0

    def take(expected=None):
        nonlocal position
        if position >= len(tokens) or (expected is not None and tokens[position] != expected):
            raise ValueError()
        token = tokens[position]
        position += 1
        return token

    def operand():
        token = take()
        if not (token.startswith("'") or re.fullmatch(r'[A-Z][A-Z_0-9]*|\d+(?:\.\d+)?', token)):
            raise ValueError()
        return token

    def primary():
        if position < len(tokens) and tokens[position] == '(':
            take('('); result = expression('OR'); take(')')
            return result
        left = operand()
        operator = take()
        if operator == 'IN':
            take('('); items = [operand()]
            while position < len(tokens) and tokens[position] == ',':
                take(','); items.append(operand())
            take(')')
            return ('IN', left, tuple(items))
        if operator == 'IS':
            negate = position < len(tokens) and tokens[position] == 'NOT'
            if negate: take('NOT')
            take('NULL')
            return ('IS NOT NULL' if negate else 'IS NULL', left)
        if operator not in ('=', '!=', '<>', '<', '>', '<=', '>='):
            raise ValueError()
        return (operator, left, operand())

    def expression(operator):
        parse = (lambda: expression('AND')) if operator == 'OR' else primary
        result = parse()
        while position < len(tokens) and tokens[position] == operator:
            take(operator)
            result = (operator, result, parse())
        return result

    try:
        result = expression('OR')
        return result if position == len(tokens) else None
    except ValueError:
        return None


def _action(value):
    return 'RESTRICT' if not value or str(value).upper() == 'NO ACTION' else str(value).upper()


def _column(column):
    default = column.get('default')
    onupdate = None
    if default is not None:
        pieces = re.split(r'\s+ON UPDATE\s+', str(default), flags=re.I)
        default = pieces[0]
        if len(pieces) == 2:
            onupdate = _default(pieces[1])
    return {'type': _type(str(column['type'].compile(dialect=mysql.dialect()))),
            'nullable': bool(column['nullable']), 'default': _default(default),
            'autoincrement': column.get('autoincrement', False) is True, 'onupdate': onupdate}


def parse_definition(sql):
    sql = re.sub(r'--[^\n]*', '', sql).strip().rstrip(';')
    match = re.fullmatch(r'CREATE TABLE\s+(?:IF NOT EXISTS\s+)?([a-z_]+)\s*\((.*)\)\s*ENGINE=InnoDB(?:\s+DEFAULT CHARSET=utf8mb4)?', sql, re.I | re.S)
    if not match:
        raise ValueError('Unsupported repository CREATE TABLE definition')
    result = {'columns': {}, 'pk': [], 'indexes': {}, 'fk': {}, 'checks': {}, 'engine': 'INNODB'}
    for part in _parts(match[2]):
        index = re.fullmatch(r'(UNIQUE KEY|INDEX)\s+(\w+)\s*\(([^()]+)\)', part, re.I)
        fk = re.fullmatch(r'CONSTRAINT\s+(\w+)\s+FOREIGN KEY\s*\(([^()]+)\)\s+REFERENCES\s+(\w+)\s*\(([^()]+)\)', part, re.I)
        check = re.fullmatch(r'CONSTRAINT\s+\w+\s+CHECK\s*\(.*\)', part, re.I | re.S)
        if index:
            result['indexes'][index[2]] = {'columns': [v.strip() for v in index[3].split(',')], 'unique': index[1].upper() == 'UNIQUE KEY', 'prefix_lengths': {}}
        elif fk:
            result['fk'][fk[1]] = {'columns': [v.strip() for v in fk[2].split(',')], 'table': fk[3], 'referred_columns': [v.strip() for v in fk[4].split(',')], 'ondelete': 'RESTRICT', 'onupdate': 'RESTRICT'}
        elif check:
            named = re.fullmatch(r'CONSTRAINT\s+(\w+)\s+CHECK\s*\((.*)\)', part, re.I | re.S)
            result['checks'][named[1]] = _check(named[2])
        else:
            col = re.fullmatch(r'(\w+)\s+((?:BIGINT|INT|TINYINT|VARCHAR|CHAR|DECIMAL|DATETIME|DATE|TEXT|JSON|BOOLEAN)(?:\s*\([\d, ]+\))?(?:\s+UNSIGNED)?)\s*(.*)', part, re.I | re.S)
            if not col:
                raise ValueError('Unsupported repository column or constraint: ' + part)
            tail = re.sub(r'\s+', ' ', col[3].strip()).upper()
            # Only known repository modifiers are accepted.
            remaining = re.sub(r"DEFAULT (?:'[^']*'|CURRENT_TIMESTAMP|TRUE|FALSE|\d+)", '', tail)
            remaining = re.sub(r'ON UPDATE CURRENT_TIMESTAMP|AUTO_INCREMENT|PRIMARY KEY|NOT NULL|\bNULL\b', '', remaining)
            if remaining.strip():
                raise ValueError('Unsupported repository column modifier: ' + remaining)
            primary = 'PRIMARY KEY' in tail
            default = re.search(r"DEFAULT ('[^']*'|CURRENT_TIMESTAMP|TRUE|FALSE|\d+)", col[3], re.I)
            result['columns'][col[1]] = {'type': _type(col[2]), 'nullable': not (primary or 'NOT NULL' in tail),
                'autoincrement': 'AUTO_INCREMENT' in tail, 'default': _default(default[1] if default else None),
                'onupdate': 'CURRENT_TIMESTAMP' if 'ON UPDATE CURRENT_TIMESTAMP' in tail else None}
            if primary:
                result['pk'].append(col[1])
    return result


def compatibility_report(inspector, definitions, segment):
    """Return deterministic JSON-safe findings; never execute SQL or alter schema.

    MISSING means expected objects are absent; BLOCKING means existing objects
    disagree. EXTENSION identifies additional objects without proposing removal.
    """
    if segment not in ('CASH', 'FNO'):
        raise ValueError('Unsupported segment')
    contracts = {}
    for name, sql in sorted(definitions.items()):
        declared = re.match(r'CREATE TABLE\s+(?:IF NOT EXISTS\s+)?([a-z_]+)\s*\(', sql.strip(), re.I)
        if not declared or declared[1] != name:
            raise ValueError('Definition table name differs from contract key')
        contracts[name] = parse_definition(sql)
    if any((segment == 'FNO') != n.startswith('fno_') for n in contracts):
        raise ValueError('Schema definition violates segment ownership')
    if segment == 'CASH' and 'ingestion_jobs' in contracts:
        jobs = contracts['ingestion_jobs']
        for name, ddl in ADDITIONS.items():
            jobs['columns'][name] = parse_definition('CREATE TABLE x (' + name + ' ' + ddl + ') ENGINE=InnoDB')['columns'][name]
        jobs['indexes']['uq_pipeline_active'] = {'columns': ['active_key'], 'unique': True, 'prefix_lengths': {}}
    findings = []
    def finding(table, kind, name, severity, expected, actual):
        findings.append(dict(table=table, kind=kind, name=name, severity=severity, expected=expected, actual=actual))
    names = set(inspector.get_table_names())
    for table, expected in contracts.items():
        if table not in names:
            finding(table, 'table', table, 'MISSING', expected, None)
            continue
        actual_cols = {c['name']: _column(c) for c in inspector.get_columns(table)}
        try:
            options = inspector.get_table_options(table)
        except (AttributeError, NotImplementedError):
            options = {}
        engine = options.get('mysql_engine')
        if not engine:
            finding(table, 'engine', table, 'UNVERIFIED', expected['engine'], None)
        elif str(engine).upper() != expected['engine']:
            finding(table, 'engine', table, 'BLOCKING', expected['engine'], str(engine).upper())
        for name, spec in expected['columns'].items():
            actual = actual_cols.get(name)
            if actual != spec:
                finding(table, 'column', name, 'MISSING' if actual is None else 'BLOCKING', spec, actual)
        for name in sorted(actual_cols.keys() - expected['columns'].keys()):
            column = actual_cols[name]
            required = not column['nullable'] and column['default'] is None and not column['autoincrement']
            finding(table, 'column', name, 'BLOCKING' if required else 'EXTENSION', None, column)
        actual_pk = inspector.get_pk_constraint(table).get('constrained_columns') or []
        if actual_pk != expected['pk']:
            finding(table, 'primary_key', 'PRIMARY', 'BLOCKING', expected['pk'], actual_pk)
        indexes = {i['name']: {'columns': i.get('column_names', []), 'unique': bool(i.get('unique')), 'prefix_lengths': i.get('dialect_options', {}).get('mysql_length') or {}} for i in inspector.get_indexes(table)}
        # Some dialects reflect unique keys separately; retain explicit indexes first.
        for i in inspector.get_unique_constraints(table):
            indexes.setdefault(i['name'], {'columns': i.get('column_names', []), 'unique': True, 'prefix_lengths': {}})
        foreign = {i['name']: {'columns': i.get('constrained_columns', []), 'table': i.get('referred_table'), 'referred_columns': i.get('referred_columns', []), 'ondelete': _action(i.get('options', {}).get('ondelete')), 'onupdate': _action(i.get('options', {}).get('onupdate')), **({'schema': i['referred_schema']} if i.get('referred_schema') and i['referred_schema'] != getattr(inspector, 'default_schema_name', None) else {})} for i in inspector.get_foreign_keys(table)}
        for kind, actual, wanted in [('index', indexes, expected['indexes']), ('foreign_key', foreign, expected['fk'])]:
            for name, spec in wanted.items():
                if actual.get(name) != spec:
                    finding(table, kind, name, 'MISSING' if name not in actual else 'BLOCKING', spec, actual.get(name))
            for name in actual.keys() - wanted.keys():
                restrictive = kind == 'foreign_key' or actual[name].get('unique', False)
                finding(table, kind, name, 'BLOCKING' if restrictive else 'EXTENSION', None, actual[name])
        try:
            actual_checks = {c['name']: _check(c['sqltext']) for c in inspector.get_check_constraints(table)}
        except (AttributeError, NotImplementedError):
            actual_checks = None
        if actual_checks is None:
            if expected['checks']:
                finding(table, 'check', '*', 'UNVERIFIED', expected['checks'], None)
        else:
            for name, expression in expected['checks'].items():
                if actual_checks.get(name) != expression:
                    finding(table, 'check', name, 'MISSING' if name not in actual_checks else 'BLOCKING', expression, actual_checks.get(name))
            for name in actual_checks.keys() - expected['checks'].keys():
                finding(table, 'check', name, 'BLOCKING', None, actual_checks[name])
    for table in names - contracts.keys():
        finding(table, 'table', table, 'EXTENSION', None, 'present')
    findings.sort(key=lambda f: (f['table'], f['kind'], str(f['name'])))
    blocking = any(f['severity'] == 'BLOCKING' for f in findings)
    missing = any(f['severity'] == 'MISSING' for f in findings)
    unverified = any(f['severity'] == 'UNVERIFIED' for f in findings)
    return {'segment': segment, 'status': 'INCOMPATIBLE' if blocking else 'MISSING' if missing else 'CHECKED_WITH_LIMITATIONS' if unverified else 'COMPATIBLE',
            'compatible': not (blocking or missing or unverified), 'findings': findings,
            'limitations': ['Charset, collation, index algorithms and visibility are not compared.',
                            'Owned CHECK predicates normalize identifier quotes, redundant grouping and utf8mb4 literal introducers; literal case and logical precedence remain significant. Unknown rewrites fail closed.']}
