"""
model/processing/normalizer.py
Converts raw FYERS structures into the canonical Candle/Tick models
(model/processing/models.py). This is the ONLY module that both the
historical and live pipelines share for this conversion (spec Section 9)
-- historical.py and websocket.py must never build Candle/Tick objects
themselves.

Three entry points, matching the two places normalization happens in
the data-flow diagram (spec Section 21):
    normalize_historical_candle()  -- FYERS historical row -> Candle
    normalize_live_tick()          -- raw WebSocket message -> Tick
    normalize_live_candle()        -- candle_builder's raw OHLCV bucket
                                       + instrument metadata -> Candle
"""

import logging
import math
from decimal import Decimal, InvalidOperation
from typing import Optional

from model.config.instrument_loader import Instrument
from model.processing.models import Candle, Tick, to_ist

log = logging.getLogger("market_data.processing.normalizer")


class NormalizationError(Exception):
    """Raised when a raw record cannot be normalized at all (malformed
    beyond repair). Callers should catch this per-record and skip/log
    it rather than let it abort a whole batch -- see historical_controller.py."""


def normalize_historical_candle(raw_row: list, instrument: Instrument, timeframe: str = "1m") -> Candle:
    """
    raw_row: [epoch_timestamp, open, high, low, close, volume] as
    returned by FYERS's Historical API (see model/fyers/historical.py).
    Raises NormalizationError for a malformed row rather than returning
    a partially-built Candle.
    """
    if not isinstance(raw_row, (list, tuple)) or len(raw_row) < 6:
        raise NormalizationError(f"Historical row has fewer than 6 fields: {raw_row!r}")

    epoch_ts, o, h, l, c, v = raw_row[:6]

    if any(val is None or isinstance(val, bool) for val in (epoch_ts, o, h, l, c, v)):
        raise NormalizationError(f"Historical row has missing value(s): {raw_row!r}")

    try:
        from decimal import Decimal, InvalidOperation
        volume=Decimal(str(v))
        if not volume.is_finite() or volume!=volume.to_integral() or isinstance(v,bool):raise ValueError("Volume must be an integer")
        return Candle(
            internal_name=instrument.internal_name,
            fyers_symbol=instrument.fyers_symbol,
            instrument_type=instrument.instrument_type,
            exchange=instrument.exchange,
            timestamp=to_ist(float(epoch_ts)),
            timeframe=timeframe,
            open=float(o),
            high=float(h),
            low=float(l),
            close=float(c),
            volume=int(volume),
            source="FYERS_HISTORICAL",
            status="CLOSED",
        )
    except (TypeError, ValueError, InvalidOperation, OverflowError, OSError) as exc:
        raise NormalizationError(f"Historical row has non-numeric field(s): {raw_row!r} ({exc})") from exc


def _first_present(message: dict, *candidate_keys):
    for key in candidate_keys:
        if key in message and message[key] is not None:
            return message[key]
    return None


def normalize_live_tick(message: dict) -> Optional[Tick]:
    """
    Converts a raw FYERS WebSocket message into a Tick. Returns None
    (and logs at debug level, not warning) for messages that don't look
    like a tick at all -- e.g. connection-status/subscription-ack
    messages the SDK may also deliver through the same callback. Does
    NOT raise, so the WebSocket receive loop is never broken by an
    unexpected message shape (spec Section 12).

    UNVERIFIED ASSUMPTION (spec Section 28 requires this be flagged):
    FYERS's exact per-tick field names could not be independently
    confirmed against a live response at implementation time. This
    function tries multiple plausible field-name candidates per value
    and never guesses a numeric default for a field it can't find.
    Before trusting this in production: log a handful of raw messages
    once and confirm the actual field names, then tighten the
    candidate lists below to match exactly.
    """
    if not isinstance(message, dict):
        log.debug(f"Ignoring non-dict WebSocket message: {message!r}")
        return None

    fyers_symbol = _first_present(message, "symbol", "s")
    ltp = _first_present(message, "ltp", "last_traded_price")

    if fyers_symbol is None or ltp is None:
        log.debug(f"Ignoring message without symbol/ltp (likely a status/ack message): {message}")
        return None

    epoch_ts = _first_present(message, "exch_feed_time", "last_traded_time", "timestamp")

    try:
        if not isinstance(fyers_symbol, str) or not fyers_symbol.strip():
            return None
        if isinstance(epoch_ts, bool) or epoch_ts is None or not math.isfinite(float(epoch_ts)) or float(epoch_ts) <= 0:
            return None
        if isinstance(ltp, bool):
            return None
        price = float(ltp)
        if not math.isfinite(price) or price <= 0:
            return None
        volume = _first_present(message, "vol_traded_today", "volume")
        if volume is not None:
            number = Decimal(str(volume))
            if isinstance(volume, bool) or not number.is_finite() or number < 0 or number != number.to_integral():
                return None
            volume = int(number)
        return Tick(
            fyers_symbol=fyers_symbol,
            timestamp=to_ist(epoch_ts),
            ltp=float(ltp),
            volume_traded_today=volume,
            bid_price=_first_present(message, "bid_price", "bid"),
            ask_price=_first_present(message, "ask_price", "ask"),
            open_price=_first_present(message, "open_price", "o"),
            high_price=_first_present(message, "high_price", "h"),
            low_price=_first_present(message, "low_price", "l"),
            prev_close_price=_first_present(message, "prev_close_price", "prev_close"),
            raw=message,
        )
    except (TypeError, ValueError, InvalidOperation, OverflowError, OSError) as exc:
        log.warning(f"Could not parse tick message (non-numeric field?): {message} ({exc})")
        return None


def normalize_live_candle(bucket, instrument: Instrument, status: str) -> Candle:
    """
    Enriches candle_builder's raw OHLCV bucket (which only knows
    fyers_symbol/timestamp/OHLCV -- see model/processing/candle_builder.py)
    with full instrument metadata and source provenance, producing the
    same canonical Candle type historical normalization produces (spec
    Section 21's data-flow: candle_builder -> normalizer -> validator).
    """
    return Candle(
        internal_name=instrument.internal_name,
        fyers_symbol=instrument.fyers_symbol,
        instrument_type=instrument.instrument_type,
        exchange=instrument.exchange,
        timestamp=bucket.period_start,
        timeframe="1m",
        open=bucket.open,
        high=bucket.high,
        low=bucket.low,
        close=bucket.close,
        volume=bucket.volume,
        source="FYERS_LIVE",
        status=status,
    )
