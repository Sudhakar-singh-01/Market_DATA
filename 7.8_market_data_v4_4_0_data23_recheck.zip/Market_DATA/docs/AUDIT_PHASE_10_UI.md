# Audit Phase 10 — workflow dashboard usability

The UI work keeps the existing Streamlit pages, roles and backend operations.
Administration now lists Unified Workflow first so the reviewed fetch/aggregate/
verify flow is easier to find.

## New workflow

The disabled Preview button now explains missing targets, an inverted date range,
or a range exceeding 31 inclusive days. FNO requires an underlying plus at least
one selected contract type. These hints do not submit previews or fetch data.
The existing service still performs final validation.

If submission cannot be confirmed, the reviewed plan is consumed and the UI asks
the operator to inspect Monitor jobs for the selected segment before submitting
again. The message deliberately avoids raw provider/database exception text.
It does not claim that a failed response means no job was created.

## Monitor jobs

Queued and running jobs have informational guidance rather than a generic
readiness warning. Partial, failed and interrupted jobs explain explicit review
and resume; cancelled jobs explain that completed stored work may remain.
No-data results ask the operator to review scope before a new workflow.

READY still requires both persisted SUCCESS and ready=true. Verification findings
explain whether strict data validation failed or verification was unavailable.
Refresh remains read-only. Existing confirmations, worker scope warnings, resume
semantics and role checks remain in place.

## Windows check

From the extracted project root, run:

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_workflow_dashboard.py tests\test_workflow_dashboard_service.py tests\test_workflow_integration.py tests\test_job_pages.py tests\test_reported_dashboard_failures.py
```

Expected: 44 passed, with dependency warnings possible. The widget tests exercise
actual Streamlit reruns against an isolated service double; SQL-backed adapter
and workflow tests verify service behavior. No production DB or provider is used.

For a visual smoke check, start the dashboard:

```bat
.venv\Scripts\python.exe -m streamlit run ui/dashboard.py --server.address 127.0.0.1
```

Sign in as admin and open Administration → Unified Workflow. Check missing target
and date-range hints without submitting a workflow; open Monitor jobs to inspect
existing status. Real browser rendering on the operator's Windows desktop is a
separate acceptance check from AppTest. No live job needs to be created for it.

This phase covers the existing workflow navigation, input guidance and job status
presentation. A full visual redesign of every legacy admin/F&O screen was not
implemented. Event Bus and full indicator/trading engines remain deferred.

## Recorded validation

Baseline targeted suites: 30 passed. Updated targeted suites: 44 passed.
Broader dashboard/workflow/HTTP regression: 196 passed, including the lost-response case.
That regression initially exposed stale submission controls after uncertain
outcomes; a full rerun now removes them immediately and displays the notice.
Changed-file diff and Python compilation reviewed. These are Linux/Python 3.12
results; native Windows/browser acceptance is not claimed.
