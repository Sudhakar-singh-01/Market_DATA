# Optional guarded reset utility (not executed on production)

Added an authenticated preview-only CMD launcher and separately confirmed reset
CLI. Apply requires fresh checksum-verified backups of both segments, archives
Parquet before SQL drops, recreates owned empty schemas and retains a per-step
recovery journal. Config, credentials and runtime/quota state are preserved.
Reset is not a cure for UI/file-lock bugs. Read docs/GUARDED_RESET.md before any
explicit apply; native Windows/MySQL reset has not been executed.

# Red/white UI and live-usage regressions

Use a white/red theme across the shell, task center and Streamlit widgets.
Give CSV exports stable context-specific keys to prevent preview/job-fragment
collisions. Explicitly close owned FNO Parquet streams and bound retries for
Windows sharing violations while preserving failure/recovery state. Existing
failed production jobs/data are not repaired automatically. Read
`docs/UI_RED_WHITE_HOTFIX.md` before an explicit resume.

# New workspace UI and persistent multiple-task center

Replaces old numeric page navigation and overview with nine workspaces, named
role-gated domain views, a new stored-candle reader and dark application shell.
Adds a persistent top-right task center combining CASH/FNO active queues, local
background/live/scheduler state and foreground activity. Every observed task
has its own escaped card; unavailable sources are explicit. Existing backend
processing, permissions and confirmation gates remain. Read docs/UI_REBUILD.md
and docs/UI_FEATURE_MAP.md before upgrading to a fresh code directory.

# Audit Phase 10: workflow UI guidance and navigation

Prioritize Unified Workflow in Administration, explain disabled previews, render
state-specific monitoring guidance, and direct uncertain submissions to persisted
job inspection. Existing backend validation, readiness, confirmations and worker
semantics are preserved. See docs/AUDIT_PHASE_10_UI.md.

# Phase 9 Windows ZIP-name verification fix

Validate ZipInfo.orig_filename and reject names changed by ZIP reader
normalization before reading the manifest. Backslash and NUL original spellings
are covered by regressions that emulate Windows normalization on Linux. The
literal-backslash fixture checks the raw original archive name. Backup/recovery
suite: 69 passed. Native Windows rerun remains pending.

# Phase 9 Windows operations portability fix

Fix cleanup fsync handles for Windows, explicitly decode dashboard source tests
as UTF-8, preserve malicious ZIP paths in fixtures, and skip only real symlink
fixtures denied with Windows error 1314. Privilege-free link and writable-fsync
regressions remain active. No production cleanup was run; SQL/Parquet recovery
semantics are preserved. See docs/AUDIT_PHASE_9_WINDOWS_E2E.md.

# Phase 9 final runner hardening

Added runner-only pre-setup skipping for MySQL fixtures, removed inherited
FNO_TEST_DB/CASH_DATA_ROOT/TIOS_RUNTIME_DIR overrides, and verified the standard
42-test HTTP integration suite. The 3m fixture correction and named assertions
remain included. Native Windows acceptance is separate from Linux evidence.

# Phase 9 hotfix: probe fixture includes 3m

Corrects the integration fixture to seed and snapshot 3m bars, and asserts probe results by check name instead of obsolete positional indexes. Production probe and quality policies are unchanged. Core/runner regression: 103 passed. Native Windows API rerun remains required.

# Audit Phase 9: isolated Windows backend validation

Added a one-command Windows runner for the current core, GET API/client and
lifecycle/recovery regression groups. It uses a temporary credential-free runtime
profile, strips DB/FYERS/password variables from child tests and excludes live
provider and MySQL integration suites. Linux validation completed the core and
operations groups with 486 passes and 64 optional skips; 42 API tests are prepared
for native Windows execution. See `docs/AUDIT_PHASE_9_WINDOWS_E2E.md`.

# Audit Phase 8: canonical server timeframes

Server reads/workflows and aggregation now derive their existing public timeframe
aliases from one canonical definition in `model/timeframes.py`. This removes the
drift that previously required separate code edits when `3m` was introduced.
Public tuple/list ordering, aggregation durations, client wire contract and YAML
configuration remain unchanged. See `docs/AUDIT_PHASE_8_SAFE_REFACTORING.md`.

# Audit Phase 7: GET API pagination and bounded reads

Service-side candle iteration now rejects cursor cycles and stops at an explicit
page bound. The GET SDK rejects responses that exceed the requested row limit,
and latest-candle freshness metadata uses one clock sample for consistent
`as_of`/`age_seconds` values. Existing read formats, cursor scopes, verification
policy and live-view pagination semantics are preserved. See
`docs/AUDIT_PHASE_7_GET_API.md`.

# Audit Phase 6: live reconnect and restart ownership

WebSocket stop is idempotent and releases ownership after provider close exceptions. A stuck SDK close retains ownership, and the dashboard blocks restart until the old controller thread exits. Reconnect resubscription is regression-tested, while Cash/F&O history backfill excludes the still-forming reconnect minute to prevent historical/live overlap. See `docs/AUDIT_PHASE_6_LIVE_RECONNECT.md`.

# Audit Phase 5: database backup and recovery hardening

Backup manifests now reject duplicate JSON keys and malformed inventory metadata. Recovery staging rejects a symlinked root and rechecks every extracted file and checksum before returning success, cleaning incomplete stages on failure. Existing migration SQL, live databases and manual isolated-recovery workflow are unchanged. See `docs/AUDIT_PHASE_5_DATABASE_RECOVERY.md`.

# Audit Phase 4: calendar/session-correct 3m integration

Added `3m` across Cash/F&O aggregation, configuration, reads, SDK/probe, workflow UI, CLI, recovery and cleanup scopes. Cash buckets restart at every configured session interval; incomplete source minutes are never fabricated. Full sessions produce 125 Cash bars and 129 F&O bars, including the F&O session-clipped final bucket. No provider-native timeframe, production data or migration behavior changed. See `docs/AUDIT_PHASE_4_CALENDAR_3M.md`.

# First indicator calculation: SMA_CLOSE_V1

Added a bounded SMA kernel and verified historical replay example. Production event bus, registry/cache and indicator engine lifecycle remain pending. No market data storage changes.

# Verified consumer adapter

Added bounded immutable Decimal candle batches, complete-input validation and GET-only consumer check. Existing storage and SDK wire methods unchanged. Indicator/backtest engines remain pending.

# GET integration probe and per-check timing

Adds controller.read_probe_cli and client.read_probe: a single-password, bounded GET-only check of Cash verified derived timeframes, pagination against a fresh baseline, selected FNO contract reads and option-chain sample. Records per-check wall time; no automatic retries, provider calls, direct SQL access or market-data mutation. Existing API process and behavior unchanged. Reports under recovery/read_checks. See docs/READ_INTEGRATION_PROBE.md.

Validation: 69 API/client/integration tests passed on Linux SQLite/Parquet, including all-timeframe batch success, missing-data findings, no SQL mutation statements, and immediate auth failure. Windows/MySQL batch verification pending. Previous full core suite: 830 passed / 194 skipped.

# Explicit Cash regular-session reads

Adds session=regular to candle GET, MarketReadService, the HTTP SDK and strict repository iterator. Raw mode filters SQL before pagination and reports full-scope exclusions without a quality claim. Verified mode checks full SQL/Parquet parity and non-session integrity before filtering preserved raw off-session rows; validates complete regular-minute coverage and derived recomputation. Cash only; default all-session and FNO behavior retained. Session/calendar-bound cursors, 31-day bounded requests and SDK range splitting included. No provider request, migration, data deletion or repair on GET. See docs/REGULAR_SESSION_READS.md.

Validation: 90 focused tests and full suite 830 passed / 194 skipped on Linux SQLite/Parquet. Windows/MySQL GET validation is the next owner command. Previous production calendar report: 41 Parquet files checked, 14 session passes, 27 containing 299 outside-session rows; no missing regular minutes, duplicates or other integrity findings in that scope. The 1,358 report-only matches are not fresh parity certification.

# Cash calendar 2024/2025 and split-session review

Adds explicit backed-up cash_calendar_cli profile merge, preserving existing 2026 entries and FNO verification scope. Split-session membership, expected minutes, quality, aggregation, rebuild and coverage now exclude breaks; daily candles combine valid intervals. Intraday buckets restart per interval. Fast report reads only special/outside-session Parquet files, no SQL/provider or market-data writes; old report-only matches are explicitly not fresh certification. See docs/CASH_CALENDAR_UPDATE.md.

Validation: 817 passed / 194 skipped in full Linux suite; after final calendar/rule version tags and CLI integration test, 50 focused tests passed with TIOS_HOME override. Windows runtime application remains to be run by owner. Earlier October 26 recovery was verified from supplied plans/results/journals: 6 raw partitions, 2,076 inserts / 174 updates, then 30 derived partitions, 696 inserts / 30 updates; cumulative derived recovery scope 335 partitions. No repeat of that repair is required.

# Incomplete-session backfill and scoped derived rebuild

Extends cash_gap_cli with --check-report and mandatory --date. Uses fresh full-session provider validation, existing archived/journaled raw repair and optional --rebuild for only repaired partitions. No calendar-review or complete-session selection. Original off-session gap mode remains insert-only. Corrects successful BASE_REPAIR_VERIFIED exit handling and identifies admin-auth errors. 147 focused tests passed; Windows/MySQL application pending. See docs/CASH_INCOMPLETE_SESSION_REPAIR.md.

# Final read-only Cash recovery verification

Adds cash_final_check_cli: current SQL/Parquet parity for 2,280 inventory raw paths and recomputed comparison for 305 derived plan paths. No broker calls, repair or canonical data writes; one JSON report only. Reports session/calendar/coverage quality separately. Strict default validation preserved; explicit raw-preservation mode still checks non-session integrity. 140 focused tests passed with runtime override; standard full suite 787 passed, 194 skipped. See docs/CASH_FINAL_CHECK.md.

# Guarded derived rebuild apply

Adds --apply-plan with explicit writers-stopped and derived replacement flags. Archives old derived SQL/Parquet, recomputes candidates from unchanged raw data, updates scoped candles, removes archived obsolete keys, and verifies both stores. Resume uses the same plan; raw 1m never changes. Two calendar-review sources remain deferred. 136 focused tests passed (Linux/SQLite); Windows/MySQL run pending. See docs/CASH_DERIVED_REBUILD.md.

# Cash derived rebuild preview

Adds scoped, read-only comparison and session-filtered candidate generation from verified recovery reports. No canonical data writes or apply mode. See docs/CASH_DERIVED_REBUILD.md. Existing aggregation and storage behavior unchanged.

# Session-gap historical recovery

Adds scoped staging/planning and optional guarded application for off-session-only restored partitions. Reuses provider fetch normalization and the journaled repair engine; requires complete regular-session coverage and zero updates to existing SQL rows. See docs/CASH_SESSION_GAPS.md. Focused tests: 109 passed; production run pending.

# SQL-exact session preservation restore

Adds a single-run restore of session-flagged source files only when they fully match current SQL. No SQL changes, target overwrite or quality certification. Strict default validation remains unchanged. Local focused tests: 103 passed. Provider repair hotfix has now succeeded on the owner machine: 45 VERIFIED. Higher-timeframe rebuild remains pending.

# Windows Parquet staging hotfix

Use an exclusive writable staging handle for Parquet serialization, flush and fsync; previous read-only reopen could fail on Windows. Apply outcomes now include stage and OSError errno/winerror/path details. Existing repair plans remain compatible. Focused suite: 100 passed locally; native Windows execution remains to be verified.

# Guarded provider repair planning and apply

Adds explicit provider-preference promotion with per-partition backups, stale-state guards, SQL transactions, preserved SQL-only rows, Parquet parity checks and resumable cross-store publication. Session cases and higher-timeframe rebuild remain tracked as pending. See docs/CASH_PROVIDER_REPAIR.md.

# Session preservation and historical candidate staging

Adds cash_resolution_cli: preserve SQL-exact sources with explicit session classification; fetch conflicting days through existing FYERS history logic and stage nonempty candidates separately. No canonical or SQL mutations.

# Read-only field-level conflict audit

Adds cash_conflict_cli for unresolved partitions: OHLC/volume versus source/status differences, key differences, quality findings and bounded exact-value samples. No market-data mutation. 85 focused tests passed under a valid runtime profile (local Python 3.12).

# One-command scoped Cash recovery

Adds cash_recovery_cli run with fresh scoped planning, durable automatic plan/result files and guarded eligible apply. Explicitly reports skipped previously consistent partitions. 81 focused tests passed under a valid temporary runtime profile.

# Runtime-profile test isolation and missing-file diagnostics hotfix

Default-path test isolates TIOS_HOME; runtime-profile path has separate coverage. Recovery CLI checks input/output paths before authentication and reports FileNotFoundError filename. Focused suite: 77 passed with a valid temporary TIOS_HOME profile (Linux Python 3.12).

# SQL-exact recovery candidate selection

Adds explicit --prefer-sql-exact planning for conflicting old source variants, with fresh nonempty SQL equality required during apply. Default selection is unchanged. Preserves all originals and no-overwrite behavior. Includes remaining 61-partition review snapshot.

# v4.4.0 — Combined insert-only Cash recovery (27 October 2026)

- Added cash_recovery_cli plan/apply and model.cash_recovery. One fresh report covers all Cash minute candidates, reports already-consistent partitions and unresolved variants, and plans only compatible missing SQL keys/absent files.
- Apply uses plain INSERT transactions, requires unique nonnullable candle keys and MySQL InnoDB, preserves existing values/files, creates scoped preimage backups and an fsynced journal, and verifies both stores. Per-partition failures continue safely; cross-store interruptions are resumable and reported PARTIAL.
- Calendar/partial-coverage warnings retained. No SQL update/delete, checkpoint advance, FNO or aggregate changes. Exact planned missing keys prevent silent scope expansion.
- Validation: full 724 passed, 194 skipped; final focused 68 passed. Windows production MySQL remains user-side validation. See docs/COMBINED_CASH_RECOVERY.md.

# v4.4.0 — Idle heartbeat hotfix (27 October 2026)

- Replace repeated CRITICAL silence alerts and misleading "looks alive" heartbeat text with throttled INFO activity status and last observed transport state. Real SDK close/error callbacks retain their error reporting.
- Watchdog uses interruptible Event.wait, stops promptly, and ignores post-stop SDK ticks/connect/error callbacks. Existing SDK shutdown ownership safeguards are retained; this does not claim to fix every provider-side close hang.
- Validation: 50 focused tests passed on Python 3.12. User previously confirmed 46 tests on Windows Python 3.13 and successful off-market Cash connection. No production database/data changes in this hotfix.

# v4.4.0 — Live idle connection and calendar-warning policy (27 October 2026)

- Manual Cash/FNO live starts and FNO live jobs no longer require an open verified market session. Real valid ticks are admitted off-session; empty/invalid feed messages create no market data. Missing timestamps and nonfinite/nonpositive prices are rejected. Zero volume stays valid.
- Removed automatic transport close at market end; retained explicit stop/lifecycle behavior. FNO forming candles remain OPEN on shutdown and entirely idle freshness polling does not write quality rows. Scheduled market-open/EOD mode retains its explicit schedule.
- Unknown calendar evidence is advisory for Smart Fetch/workflow submission and SQL-identical Cash restoration. Existing integrity/conflict/overwrite guards remain; strict verification does not falsely certify unknown sessions. Fresh restore plans skip previously restored identical destinations.
- Full regression: 704 passed, 194 skipped; final focused checks: 63 passed. No live Windows/FYERS testing in build environment. See docs/IDLE_LIVE_POLICY.md.

# v4.4.0 — Controlled Cash Parquet restoration (27 October 2026)

- Added cash_restore_cli plan/apply and cash_restore module for missing, SQL-identical canonical minute partitions only. Fresh metadata/quality/calendar/hash/SQL checks; no SQL mutations, FNO changes or aggregate writes.
- Plan is read-only apart from its new report. Apply requires stopped-writers acknowledgment, refuses overwrites, uses compatible partition locks and atomic hard-link publication, and keeps an fsynced journal. Rerun the same plan to reverify/skip completed copies.
- 77 focused tests passed on Python 3.12. Windows production apply pending; see docs/CASH_RESTORE.md for limitations and exact commands.

# v4.4.0 — Cash minute validation preview (27 October 2026)

- Added controller.cash_preview_cli and model.cash_inventory_preview. Read-only inventory-driven Cash raw/1m checks, optional authenticated SQL comparison, bounded pairwise variant comparisons, source hash rechecks and calendar/timezone review gates.
- Reuses existing quality, calendar, catalog and CashReader logic. No broker calls, imports, repairs or UI changes; import_allowed remains false.
- 65 focused tests passed on Python 3.12; Windows production preview pending. See docs/CASH_VALIDATION_PREVIEW.md.

# v4.4.0 — Read-only legacy-folder inventory (27 October 2026)

- Added standalone controller.inventory_cli and model.storage_inventory. No database/broker bootstrap or source mutations.
- Groups Cash/FNO partitions by logical path and SHA256; preserves expiry and raw/processed identity. Different bytes remain review candidates, not confirmed candle conflicts.
- Reports skipped/unknown/error paths, deduplicates overlapping roots, rejects linked roots and skips linked descendants. Reports never overwrite existing files.
- Validation: 38 focused inventory/runtime/storage tests passed on Python 3.12. Windows scan pending. No consolidation, repair, UI or market-session logic changes.
- See docs/STORAGE_INVENTORY.md for exact Windows command and scope limitations.

# v4.4.0 — Permanent runtime and historical/live session separation (27 October 2026)

- Opt-in Windows TIOS_HOME profile keeps credentials/configuration, instruments, Cash/FNO Parquet, quotas, backups, recovery and operation journals stable across code-folder upgrades. Database names, schemas and data are unchanged.
- Added runtime_cli init: preview first, authenticated explicit copy with writers stopped, source/checksum revalidation, private staging and no source deletion or existing-target overwrite. Copied configuration points at the new persistent roots. Default no-profile behavior remains supported.
- Historical fetch remains runnable on weekends, holidays and nights for supported target ranges. Live startup/tick admission is gated by a verified session; close stops the transport and flushes existing data. Configured FNO session hours are preserved; verified special sessions override regular hours. No new automatic historical scheduler.
- Cash stop no longer writes the same completed bucket twice or closes a forming minute; partial minute stays OPEN.
- Validation: full regression 649 passed, 194 skipped on Python 3.12.14. Final relative-profile-path adjustment passed the focused profile/storage/session suite; see docs/PERMANENT_RUNTIME.md. Windows/MySQL/FYERS validation remains pending. Copied bytes do not certify market-data parity or repair existing invalid candles.
- UI presentation work and broad Step 10 duplication refactoring remain pending.

# Step 9 hotfix 2 — Windows test portability correction

The supplied Windows Python 3.13 run passed 34 tests; the remaining test failed
while creating a symlink fixture (WinError 1314), before application logic ran.
Only that privileged fixture is skipped when Windows denies link creation.
Independent simulated symlink/junction guard checks still run without privileges.
No production logic, configuration or data is changed by this correction.
Validation: 38 targeted tests passed on the build environment, including simulated
Windows privilege denial. Actual Windows rerun remains pending.

# v4.4.0 Step 9 hotfix 2 — backend logic (26 October 2026)

- Correct Cash/FNO ownership for the existing nested data/fno layout; backup excludes the peer segment and cleanup retains its files.
- Shared optional CASH_DATA_ROOT for default Cash readers/writers/catalog, anchored to project directory; FNO isolation checks the same configured Cash root. No automatic migration or repair.
- Preserve structured workflow fetch blockers and sanitized FYERS history availability errors; no silent clamping, fabricated candles or retry of unavailable history.
- Cooperative pre-executor shutdown for persisted and legacy workers; stop checks between requests and stores, interrupted status instead of false success. No UI presentation changes.
- Read-only diagnostics CLI for roots, manifest-backed missing files, Cash fetch preview and persisted job quality findings. See docs/BACKEND_CHECKS.md and docs/LOGIC_HOTFIX_2026_10_26.md.
- Validation: 615 passed, 194 skipped on Python 3.12.14. Final diagnostic status-label adjustment: 9 focused tests passed. MySQL integration, live FYERS and Windows/Python 3.13 checks remain pending. Blocking I/O cannot be forcibly cancelled; the lifecycle hook uses CPython's pre-thread-shutdown API.
- No .env, runtime logs, credentials, databases or user data included. Step 10 broad duplication refactor remains pending.

# Step 9 hotfix 1: reported Windows output (2026-10-26)

Fixed Coverage Heatmap's uncaught blocked-fetch exception: it now previews missing
ranges, shows exact symbol/day blockers and revalidates on explicit submission.
Historical Smart Fetch also displays structured revalidation findings. Safety
checks remain active; no source data is overwritten to force a successful fetch.

Aggregation no longer reports SUCCESS for zero complete daily buckets or missing
source coverage. It reports reasons and expected/missing/skipped/pending counts;
Cash persisted and legacy UI job outcomes propagate incomplete results. Complete
OHLCV generation is preserved. Cash jobs now log CASH rather than FNO; background
login audits avoid Streamlit-context access; two deprecated width calls are fixed.

Distribution omits the inherited runtime log containing old test failures. No
existing user logs, databases, credentials or market-data files are deleted.
Step 10 generic duplication refactoring remains pending while this user-reported
hotfix is delivered.

Full regression: **575 passed, 194 skipped, 2280 warnings in 45.89s**.
21 new regression tests cover the reported failures and aggregation edge cases.
Actual Windows/MySQL/FYERS behavior still needs deployment verification. The old
traceback does not identify the exact source conflict; new preview diagnostics do.
Guide and evidence: docs/HOTFIX_2026_10_26.md.

---

# Step 9: isolated recovery verification (2026-10-26)

Added Administration → Recovery Verification and
`python -m controller.recovery_cli` for checks after a trusted manual import into
a separate `tios_recovery_*` database. New RECOVERY_DB_ configuration uses a fresh,
independent connection and rejects both configured live database names and the
backup's source database. No product code imports SQL or performs live cutover.

The verifier compares original archive/staged file hashes, exact server CREATE
TABLE definitions (including empty tables), complete typed row multisets and
counts, table inventory and composite foreign-key orphan checks. It reads a UTC,
read-only repeatable-read snapshot. Duplicate rows are counted exactly and row
order is irrelevant; comparison uses temporary disk-backed storage. Limits and
conservative schema-text matching are documented. Errors/reports omit credentials
and row values; each run produces a separate flushed, read-only report.

Reports scope VERIFIED to SQL_AND_FILES_VERIFIED. They explicitly retain
market_parity=NOT_TESTED and restore_tested=false; original archives are unchanged.
Faithful recovery of files/schema/rows does not certify pre-existing market-data
quality, Parquet readability, application recovery or live replacement readiness.
Manual import with a target-scoped account remains required because arbitrary
exported DDL cannot safely be imported using a simple statement whitelist.

Full regression: **554 passed, 194 skipped, 2280 warnings in 33.68s**.
50 additional passing tests cover recovery identity, schema/content mismatches,
duplicate multiplicity, composite NULL/orphan semantics, source mutation, path
guards, bounded parsing, reports, configuration, CLI and actual Streamlit controls.
An opt-in real MySQL test creates a fresh disposable recovery database, imports a
test-generated dump, verifies it and drops only that test database. It was skipped;
no successful real MySQL restore or Windows drill is claimed for this release.

Existing ingestion, storage, workflow, cleanup and GET API behavior is preserved.
Guide: docs/RECOVERY_VERIFICATION.md. The actual deployment recovery drill remains
pending. Next development step: remaining confirmed shared-code refactors.

---

# Step 8: scoped SQL/Parquet cleanup and progress invalidation (2026-10-26)

Added Administration → Scoped Data Cleanup for one exact Cash/FNO symbol and up
to 31 completed IST days. Preview binds SQL content, partition hashes, manifests,
progress, instrument and schema to the reviewed plan. Admin reauthentication,
exact database confirmation, backup and stopped-writer acknowledgment are required.
Changing inputs invalidates review; an execution attempt consumes it.

Canonical 1m cleanup includes supported derived timeframes. Cash checkpoint
high-water marks and overlapping FNO ranges are invalidated conservatively; FNO
harvest state resets. Shared FNO partitions preserve other contracts and update
their manifests. Existing instrument masters, jobs and option chains stay intact.
Legacy SQL-only methods remain available; their UI scope is explicitly labelled.

Original affected files are retained outside live roots with a durable operation
journal. Partial/uncertain failures retain RECOVERY_NEEDED and block further
cleanup execution. No cross-store atomicity, automatic restore or blind retry is
claimed. FNO partition advisory locks share one dedicated connection across the
full scope, preventing pool exhaustion while using existing writer lock names.
Unsafe roots, symlinks, incompatible partition metadata, active jobs, excessive
data sizes, non-InnoDB tables and visible trigger/cascade side effects fail closed.

Full regression: **504 passed, 193 skipped, 2280 warnings in 29.31s**.
New coverage includes real SQLite/Parquet cleanup, preserved peer contracts,
same-count stale data, malformed manifests, partial file publication, SQL commit
failure, recovery-marker blocking, 186 partition locks on one connection and
actual Streamlit confirmation controls. The optional real-MySQL integration test
was skipped; five additional skips are parameter cases applicable only to FNO.
Live MySQL/FYERS, Windows locking/durability and a real restore drill remain pending.

No live user data was cleaned during implementation. Existing fetching, cleaning,
validation, storage, workflow and GET consumer paths are unchanged.
Guide: docs/SCOPED_CLEANUP.md. Next: controlled separate-database recovery testing.

---

# Step 7: schema compatibility and controlled migration preflight (2026-10-25)

Administration → Schema Manager now offers a read-only compatibility report for
the configured Cash/FNO database. Expected contracts come from existing SQL and
Cash pipeline additions. Findings distinguish missing objects, incompatible
existing definitions, unverified critical metadata and additional objects.

The report compares column types/defaults/nullability/AUTO_INCREMENT/ON UPDATE,
primary keys, named indexes/uniqueness/prefixes, foreign-key targets/actions,
CHECK expressions and table engine. Fixed allowlisted migrations now include the
report in the reviewed plan and block incompatible/unverified schemas. Duplicate
non-null Cash active job keys block unique-index creation without exposing keys.
Plans are rechecked under the existing lock, confirmation controls bind to the
plan token, and existing per-statement journals/partial-failure handling remain.

Full regression: **453 passed, 187 skipped, 2280 warnings in 25.02s**.
24 added tests cover contracts, schema drift, migration blockers, duplicate-key
preflight and actual Streamlit controls. No live MySQL/FYERS or Windows validation
was available. CHECK expression normalization is conservative: server-specific
rewrites can require manual review. Charset/collation and index algorithm/visibility
comparison remain outside this report. SUCCESS of a migration is not a full schema
or market-data readiness certificate; re-run compatibility after each operation.

No fetching, cleaning, validation, storage, workflow or consumer API behavior was
changed. No automatic destructive repair, job deduplication or data deletion was
introduced. See docs/SCHEMA_MANAGEMENT.md for supported migrations and limitations.

---

# Step 6: unified workflow dashboard (2026-10-25)

Added Administration → Unified Workflow with separate Cash/FNO inputs, reviewed
scope/estimate, explicit submission confirmation, bounded persisted job monitoring,
manual/optional read-only auto-refresh, frozen scope display, real stage/counter
progress, READY timestamp and confirmed cancel/resume/queue-worker controls.
Changing inputs invalidates the preview; uncertain submissions consume the review;
identical active submissions focus the existing job. Resume selects the new job ID.

Full regression: 429 passed, 187 skipped, 2280 warnings in 25.28s.
12 new tests exercise actual Streamlit widgets/reruns and SQL-backed service guards.
No live FYERS/MySQL job or Windows browser was run; those remain deployment checks.
Lighter-model review found no concrete state, role or dispatch blocker.
Existing processing and API code is unchanged. Navigation is extended and the old
Operations API caption is corrected to acknowledge the separate local GET server.

Start: python -m streamlit run ui/dashboard.py
Guide: docs/WORKFLOW_DASHBOARD.md. READY remains historical evidence, not a durable
certificate; consuming modules should continue to request quality=verified.

---

# Step 5: unified historical workflow (2026-10-25)

One persisted WORKFLOW job reuses existing Cash/FNO fetch, cleaning, validation,
dual-store writes and optional aggregation, then runs strict SQL/Parquet readiness
checks over a frozen historical scope. READY is only reported after all checks pass
complete coverage and nonempty data. FNO contracts are frozen at preview; sparse
options remain non-ready. Existing standalone job behavior remains available.

Added reviewed preview/submission service methods, headless admin preview/run CLI,
and safe workflow summaries through the existing GET job endpoint. No schema
migration is required. A dedicated workflow dashboard is the next UI step.

Full regression: 415 passed, 187 skipped, 2280 warnings in 23.47s.
22 new workflow/real SQLite-Parquet integration/headless tests pass; the added
MySQL persistence/resume test skips without its disposable database. CLI help
entry point checked. Live FYERS/MySQL workflow and Windows validation remain pending.
Lighter-model review found no blocking scope/readiness defect. Existing cancellation
semantics remain terminal; failed/partial/interrupted workflows resume explicitly.

Usage and limitations: docs/UNIFIED_WORKFLOW.md. READY is point-in-time job evidence;
consumers must still request quality=verified to recheck current source data.

---

# Step 4: downstream GET client (2026-10-25)

Added a standalone httpx consumer SDK, CLI check/atomic JSONL export and runnable
example for Cash/FNO module integration. Historical reads default to verified
complete coverage; sparse options require explicit opt-in. Client handles date
chunking, cursor pagination, bounded retry/size limits, typed errors, timestamp
ordering and latest-data freshness checks. Wire Decimal strings/nulls and page
quality metadata are preserved. No automatic raw fallback or broker calls.

Full regression: 393 passed, 186 skipped, 2276 warnings in 23.76s.
New client/CLI and actual FastAPI→SQLite/Parquet integration tests: 32 passed.
CLI help entry point checked. Optional MySQL integration remains skipped without
its disposable server; Windows execution and real FYERS/MySQL runs remain pending.
Lighter-model review found no remaining blocker after partial-export and freshness
contracts were tightened. Existing ingestion/storage/API source is unchanged.
requirements-api.txt now includes the shared requirements-client.txt dependency.

See docs/CONSUMER_INTEGRATION.md for setup, failure/quality policies and examples.

---

# Step 3: Backup & Recovery staging (2026-10-25)

Added BackupService and Admin → Backup & Recovery. Streams all SQL base-table
schema/rows and the configured Parquet root into a checksum-verified archive.
Includes scope preview, isolated Cash/FNO ownership, read-only SQL snapshots,
exact scalar serialization, source-change checks and archive verification.
Recovery staging extracts a verified private copy to a new folder; live SQL and
Parquet are never overwritten. Separate-database import instructions are included.

Validation: 19 archive/literal tests pass. Full suite: 361 passed, 186 skipped, 2274 warnings in 22.32s. Real MySQL dump/import and Windows GUI execution need deployment tests.
The optional MySQL integration tests skip when no disposable test server is present.
SQL snapshot and file checks rely on the operator stopping every writer for a
consistent dual-store backup. Checksums do not certify market-data quality or a
successful restore. Read docs/BACKUP_RECOVERY.md for limits and recovery drill.

Existing ingestion, cleaning, validation, schema and GET API implementations remain
unchanged. One existing source file changes: dashboard navigation adds the new page.
Focused lighter-model review identified timezone/path issues; these were corrected.

---

# Step 2: Schema Manager (2026-10-25)

Added an admin schema setup page and shared SchemaManager. Creates missing owned
Cash/FNO tables and exposes the existing Cash pipeline metadata migration plan.
Includes preview download, admin password reauthentication, backup acknowledgment,
stale/tampered-plan rejection, MySQL advisory locking and per-statement journals.
No existing market-data algorithms or schema definitions were changed.

Full regression: **340 passed, 185 skipped, 2274 warnings** (24.18 seconds).
Nine new schema orchestration tests pass. MySQL integration was skipped because
no disposable server was reachable; real MySQL DDL execution, Windows launch and
FYERS calls remain deployment validation tasks. Lighter-model review found no
blocking issues. No production database was accessed or modified during this build.

Read docs/SCHEMA_MANAGEMENT.md before applying schema changes. Existing tables are
not automatically repaired; whole database creation/deletion and destructive
market-data lifecycle management remain future work.

---

# Additive shared-data foundation (4.4.0 milestone 1)

Added: model/read_contracts.py, model/database_catalog.py,
model/market_read_service.py, model/fno/read_verification.py,
controller/market_data_service.py, api package, requirements-api.txt,
ui/pages/29_Admin_Database_Catalog.py, tests/test_read_api.py and usage documentation.
Existing source edit: ui/dashboard.py adds the admin catalog navigation entry.
Existing ingestion/cleaning/validation/storage algorithms and schemas are unchanged.

Validation on 2026-10-25, Python 3.12/Linux:
- Full suite: 329 passed, 184 skipped, 2274 warnings (20.59 seconds).
- Added read/API/facade tests: 22 passed.
- Actual loopback API process startup and unauthenticated 401 rejection checked.
- Environment has no MySQL server or FYERS credentials; skipped integration tests
  are not evidence of production database/broker compatibility. Test with a
  disposable MySQL database before rollout. Windows launch remains untested.
- Existing dependencies emit warnings; this milestone does not upgrade or silence
  the original application's warnings.

Usage, limits and follow-up work: docs/READ_API_AND_CATALOG.md.
This milestone implements read access and database/table visibility. New schema
lifecycle/write management is deferred; existing guarded operations are retained.
