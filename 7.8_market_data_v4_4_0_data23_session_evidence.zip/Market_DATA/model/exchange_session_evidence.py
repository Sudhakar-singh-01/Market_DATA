"""Scoped claims reviewed from supplied NSE circulars; never a full calendar certificate."""
import datetime as dt

FNO_EFFECTIVE_FROM = dt.date(2026, 8, 3)
FNO_DOCUMENT = {
    'reference': 'NSE/FAOP/74467', 'issue_date': '2026-05-29', 'pages': (1, 2),
    'sha256': '6ff897abbe384e65426b5a53922e6a46690c315a0d80d1e923a09dd82d1b20d3',
}
CASH_DOCUMENT = {
    'reference': 'NSE/CMTR/73362', 'issue_date': '2026-03-18', 'pages': (1, 4),
    'sha256': 'c7da4fb3a74954903d9ac2106e16f22679654405774df7abe602f369fd1e8377',
}


def source_review(segment, start, end, days):
    result = {'review_method': 'Content review of user-supplied circular PDFs',
              'direct_agent_download_verified': False,
              'holiday_and_special_session_sources_verified': False,
              'provider_units_verified': False}
    if segment == 'FNO':
        normal = [d for d in days if d.get('trading_day') and not d.get('special_session')]
        match = bool(normal)
        for day in normal:
            intervals = day.get('intervals', [])
            match &= (len(intervals) == 1 and
                      dt.datetime.fromisoformat(intervals[0]['open']).time() == dt.time(9, 15) and
                      dt.datetime.fromisoformat(intervals[0]['close_exclusive']).time() == dt.time(15, 40))
        applicable = start >= FNO_EFFECTIVE_FROM and not any(d.get('special_session') or d.get('error_type') for d in days)
        result.update(document=dict(FNO_DOCUMENT), normal_session_rule_content_reviewed=True,
                      effective_from=str(FNO_EFFECTIVE_FROM), normal_open='09:15', normal_close='15:40',
                      rule_applicable_to_requested_normal_date_range=applicable,
                      configured_normal_hours_match_reviewed_rule=bool(match and applicable),
                      exchange_closing_price_vwap_window='15:10–15:40',
                      note='Normal equity-derivatives hours only. Holiday/special sessions and provider fields are separate. A derived daily candle close is not automatically the exchange official closing-price VWAP.')
    else:
        result.update(document=dict(CASH_DOCUMENT), normal_session_rule_content_reviewed=False,
                      configured_normal_hours_match_reviewed_rule=False,
                      cas_index_distinction_reviewed=True,
                      note='CAS initially applies to stocks with derivative contracts. Section6.5 distinguishes actual index values from indicative index close values during CAS. These pages do not establish complete CASH/index session bounds or which series a FYERS symbol supplies.')
    return result
