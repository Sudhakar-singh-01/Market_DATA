"""Read-only session declarations and bounded stored numeric-unit audit.

Provider-native quantities are never converted to lots from divisibility alone.
Existing calendar flags/citations are not independent exchange verification.
"""
import datetime as dt
import hashlib
import json
from collections import Counter
from decimal import Decimal, InvalidOperation

from sqlalchemy import select

from model.config import market_calendar as calendar
from model.data_inventory import _targets
from model.quality import stamp
from model.read_contracts import ReadRequestError, date_scope, segment_name

MAX_TARGET_DAYS = 500
MAX_DAY_ROWS = 20000
MAX_TOTAL_ROWS = 200000
REFERENCES = {
    'CASH': ['https://nsearchives.nseindia.com/content/circulars/CMTR71775.pdf'],
    'FNO': ['https://nsearchives.nseindia.com/content/circulars/FAOP71777.pdf',
            'https://nsearchives.nseindia.com/content/circulars/FAOP75472.pdf'],
}


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


def _number(value, *, integer=False, positive=False):
    if isinstance(value, bool) or value is None:
        raise ValueError('Unknown or boolean numeric value')
    value = Decimal(str(value))
    if not value.is_finite() or (value <= 0 if positive else value < 0):
        raise ValueError('Invalid numeric value')
    if integer and value != value.to_integral():
        raise ValueError('Fractional quantity')
    return value


def _optional_master(value, integer=False):
    try:
        return _number(value, integer=integer, positive=True)
    except (ValueError, TypeError, InvalidOperation):
        return None


def audit_report(segment, start, end, *, catalog=None, symbols=None, contract_ids=None,
                 underlyings=None, offline=False, session=None, now=None):
    segment = segment_name(segment)
    a, b = date_scope(start, end, max_days=31)
    now = now or dt.datetime.now(calendar.IST)
    if now.tzinfo is None:
        raise ReadRequestError('Use a timezone-aware audit clock')
    if not offline and b >= now.astimezone(calendar.IST).date():
        raise ReadRequestError('Stored-data audit requires completed historical dates; use --offline for future calendar review')
    if offline and (symbols or contract_ids or underlyings):
        raise ReadRequestError('--offline reviews configuration only; omit data selectors')
    before = _hash(calendar.calendar_metadata())
    if segment == 'FNO' and session is None:
        if catalog is not None and catalog.fno_settings is not None:
            session = catalog.fno_settings.session
        else:
            from model.fno.config import load_fno_settings
            session = load_fno_settings().session
    days, issues = [], Counter()
    for offset in range((b-a).days+1):
        day = a + dt.timedelta(days=offset)
        item = {'date': str(day), 'issues': []}
        days.append(item)
        try:
            windows = calendar.session_windows(day, segment, session=session)
            known = calendar.calendar_verified(day, segment)
            special = calendar.calendar_metadata().get('special_sessions', {}).get(str(day))
            applicable = isinstance(special, dict) and segment in special.get('segments', ['CASH','FNO'])
            item.update(config_calendar_verified=known,
                intervals=[{'open': op.isoformat(), 'close_exclusive': cl.isoformat()} for op,cl in windows],
                configured_minutes=sum(int((cl-op).total_seconds()//60) for op,cl in windows),
                special_session=applicable, trading_day=bool(windows))
            if not known:item['issues'].append('CALENDAR_NOT_DECLARED_VERIFIED')
            earliest=calendar.calendar_metadata().get('verified_from',{}).get(segment)
            if earliest and day<dt.date.fromisoformat(str(earliest)):
                item['issues'].append('SESSION_EFFECTIVE_RANGE_UNVERIFIED')
            if applicable and not special.get('verified',False):item['issues'].append('SPECIAL_SESSION_UNCONFIRMED')
            if segment == 'FNO' and windows and not applicable and session.last_minute != (
                    dt.datetime.combine(day,session.close)-dt.timedelta(minutes=1)).time():
                item['issues'].append('FNO_LAST_MINUTE_INCONSISTENT')
        except Exception as exc:
            item.update(error_type=type(exc).__name__)
            item['issues'].append('CALENDAR_INSPECTION_UNAVAILABLE')
        issues.update(item['issues'])
    # These are existing code/storage conventions, not freshly verified broker docs.
    units = {
        'timestamps': {'status':'IMPLEMENTATION_CONTRACT', 'timezone':'Asia/Kolkata',
            'historical_input':'Unix epoch seconds', 'sql':'naive IST wall-clock',
            'candle_timestamp':'period start', 'session_close':'exclusive'},
        'price': {'status':'DECLARED_NOT_EXTERNALLY_CONFIRMED',
            'meaning':'Stock price / index points / futures quote or option premium as returned; no lot multiplier applied'},
        'historical_volume': {'status':'NATIVE_SCALE_UNCONFIRMED', 'shape':'nonnegative integer per candle',
            'meaning':'Provider native; lots versus underlying quantity not inferred'},
        'live_volume': {'status':'IMPLEMENTATION_CONTRACT', 'meaning':'Differences of cumulative vol_traded_today; provisional across joins/gaps'},
        'oi': {'status':'NATIVE_SCALE_UNCONFIRMED', 'shape':'nullable nonnegative integer',
            'meaning':'Snapshot stock, not summed flow; no lot conversion; live FNO candles currently leave OI unknown'},
        'chain_iv': {'status':'EXISTING_PROBE_NOTE_NOT_EXTERNALLY_CONFIRMED', 'declared_unit':'percent',
            'example':'15.96 percent would be 0.1596 as a fraction; stored value is not auto-rescaled'},
        'chain_greeks': {'status':'UNIT_EVIDENCE_REQUIRED',
            'meaning':'Delta/gamma/theta/vega normalization/time-basis require provider evidence before use'},
        'unknown': {'status':'IMPLEMENTATION_CONTRACT', 'meaning':'Missing optional fields remain null; null is not zero'},
    }
    if segment=='CASH':
        for key in ('oi','chain_iv','chain_greeks'):units.pop(key)
    issues['EXCHANGE_SOURCE_CONFIRMATION_PENDING'] += 1
    issues['PROVIDER_UNIT_EVIDENCE_PENDING'] += 1
    observed, read_rows = [], 0
    if not offline:
        if catalog is None:raise ReadRequestError('Configured catalog is required')
        targets = _targets(catalog,segment,a,b,symbols,contract_ids,underlyings)
        if len(targets)*(b-a).days+len(targets) > MAX_TARGET_DAYS:
            raise ReadRequestError('Select at most 500 target/day scopes')
        if not targets:issues['NO_TARGETS_IN_SCOPE'] += 1
        table = catalog.table(segment,'candles' if segment=='CASH' else 'fno_candles')
        identity = table.c.instrument_id if segment=='CASH' else table.c.contract_id
        fields = ['candle_timestamp','open','high','low','close','volume','status']
        if segment=='FNO':fields.append('oi')
        with catalog.engine(segment).connect() as conn:
            for target in targets:
                lot = _optional_master(target.get('lot_size'),integer=True)
                tick = _optional_master(target.get('tick_size'))
                for info in days:
                    day = dt.date.fromisoformat(info['date'])
                    row = {'id':target['id'],'symbol':target['fyers_symbol'],'date':str(day),
                           'issues':[], 'lot_size':str(lot) if lot is not None else None,
                           'tick_size':str(tick) if tick is not None else None,
                           'lot_and_tick_effective_date_verified':False}
                    observed.append(row)
                    if read_rows>=MAX_TOTAL_ROWS:
                        row['issues'].append('ROW_BUDGET_EXCEEDED');issues.update(row['issues']);continue
                    try:
                        lo=dt.datetime.combine(day,dt.time())
                        data=list(conn.execute(select(*(table.c[f] for f in fields)).where(identity==target['id'],
                            table.c.timeframe=='1m',table.c.candle_timestamp>=lo,
                            table.c.candle_timestamp<lo+dt.timedelta(days=1)).order_by(table.c.candle_timestamp)
                            .limit(min(MAX_DAY_ROWS,MAX_TOTAL_ROWS-read_rows)+1)).mappings())
                        read_rows+=len(data)
                        if len(data)>MAX_DAY_ROWS or read_rows>MAX_TOTAL_ROWS:
                            row['issues'].append('ROW_BUDGET_EXCEEDED')
                        else:
                            counts=Counter(rows=len(data))
                            for field in ('open','high','low','close','volume',*(['oi'] if segment=='FNO' else [])):
                                for state in ('present','null','invalid'):counts[field+'_'+state]=0
                            row['instrument_kind']=target.get('category',target.get('instrument_type'))
                            if segment=='CASH' and str(row['instrument_kind']).lower()=='index':
                                row['issues'].append('INDEX_VOLUME_NOT_A_TRADED_SHARE_QUANTITY')
                            if segment=='FNO' and day>target['expiry'] and data:
                                row['issues'].append('ROWS_AFTER_CONTRACT_EXPIRY')
                            windows=calendar.session_windows(day,segment,session=session)
                            for candle in data:
                                try:
                                    ts=stamp(candle['candle_timestamp'])
                                    if ts.second or ts.microsecond:counts['unaligned_timestamps']+=1
                                    if not any(op<=ts<cl for op,cl in windows):counts['outside_configured_session']+=1
                                except (ValueError,TypeError,OverflowError):counts['invalid_timestamps']+=1
                                for field in ('open','high','low','close','volume',*(['oi'] if segment=='FNO' else [])):
                                    if candle[field] is None:
                                        counts[field+'_null']+=1
                                        if field!='oi':counts[field+'_invalid']+=1
                                        continue
                                    try:
                                        value=_number(candle[field],integer=field in ('volume','oi'),positive=field not in ('volume','oi'))
                                        counts[field+'_present']+=1
                                        if field in ('volume','oi') and lot:
                                            counts[field+'_multiple_of_current_lot']+=int(value%lot==0)
                                        if field in ('open','high','low','close') and tick:
                                            counts[field+'_off_current_tick_grid']+=int(value%tick!=0)
                                    except (ValueError,TypeError,InvalidOperation):counts[field+'_invalid']+=1
                            row['counts']=dict(counts)
                            if not data:row['issues'].append('NO_CANDLES_IN_SCOPE')
                            if any(v for k,v in counts.items() if k.endswith('_invalid') or k in
                                   ('invalid_timestamps','unaligned_timestamps','outside_configured_session')):
                                row['issues'].append('STORED_NUMERIC_OR_TIMESTAMP_REVIEW')
                            if any(v for k,v in counts.items() if k.endswith('_off_current_tick_grid')):
                                row['issues'].append('CURRENT_TICK_GRID_REVIEW_NOT_HISTORICAL_PROOF')
                            if segment=='FNO' and (lot is None or tick is None):row['issues'].append('LOT_OR_TICK_METADATA_UNAVAILABLE')
                    except Exception as exc:
                        row['error_type']=type(exc).__name__;row['issues'].append('DATA_INSPECTION_UNAVAILABLE')
                    issues.update(row['issues'])
    changed=_hash(calendar.calendar_metadata())!=before
    if changed:issues['CALENDAR_CHANGED_DURING_AUDIT']+=1
    complete=not any(issues[k] for k in ('ROW_BUDGET_EXCEEDED','DATA_INSPECTION_UNAVAILABLE',
                                       'CALENDAR_INSPECTION_UNAVAILABLE','CALENDAR_CHANGED_DURING_AUDIT'))
    from model.exchange_session_evidence import source_review
    return {'status':'AUDIT_FINDINGS' if complete else 'PARTIAL','complete':complete,
        'segment':segment,'from':str(a),'to':str(b),'offline':offline,'data_inspected':not offline,
        'calendar':days,'calendar_snapshot_sha256':before,'units':units,'observations':observed,
        'source_references':REFERENCES[segment], 'references_status':'EXISTING_CITATIONS_NOT_INDEPENDENTLY_RETRIEVED',
        'reviewed_exchange_source':source_review(segment,a,b,days),
        'external_evidence_verified':False,'unit_scale_verified':False,'values_verified':False,
        'summary':{'target_days':len(observed),'sql_rows_read':read_rows,'issues':dict(+issues)},
        'limits':{'max_days':31,'max_target_days':MAX_TARGET_DAYS,'max_day_rows':MAX_DAY_ROWS,'max_total_rows':MAX_TOTAL_ROWS},
        'market_data_modified':False,'sql_modified':False,
        'scope':'Configured session and stored 1m numeric shapes only. No quantity scaling inferred from lot divisibility; current tick grids are not historical tick-size proof. No value parity, live freshness or trading-readiness certificate.'}
