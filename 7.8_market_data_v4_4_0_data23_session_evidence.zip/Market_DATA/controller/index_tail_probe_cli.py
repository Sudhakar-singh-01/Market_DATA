"""Read-only provider probe of historical NIFTY/BANKNIFTY 15:30–15:39 timestamps."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date', required=True)
    parser.add_argument('--underlyings', nargs='+', choices=['NIFTY','BANKNIFTY'], default=['NIFTY','BANKNIFTY'])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv); stage = 'report_path'
    try:
        from model.config.runtime_paths import report_path
        from model.read_contracts import ReadRequestError
        args.output = report_path(args.output)
        if args.output.suffix.lower() != '.json' or args.output.exists():
            raise ReadRequestError('Select a new .json report')
        stage = 'admin_authentication'
        from controller.workflow_cli import authenticate_admin
        authenticate_admin()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        stage = 'configuration'
        from model.config.instrument_loader import load_instrument_registry
        from model.fno.config import load_fno_settings
        from controller.index_tail_probe import probe_index_tail
        def make_client():
            from model.config.env_loader import load_env_config
            from model.fyers.auth import get_authenticated_client
            from model.fyers.rate_limiter import get_shared_limiter, RateLimitedClient, LOW
            client = get_authenticated_client(load_env_config().fyers)
            return RateLimitedClient(client, get_shared_limiter(), LOW)
        stage = 'provider_tail_probe'
        result = probe_index_tail(load_instrument_registry(), load_fno_settings(), args.underlyings,
                                  args.date, make_client,
                                  progress=lambda r:print(json.dumps(r),flush=True))
        stage = 'write_report'
        with args.output.open('x', encoding='utf-8') as stream: json.dump(result,stream,indent=2)
        print(json.dumps({'status':result['status'],'checks':result['checks'],
                          'history_call_attempts':result['history_call_attempts'],
                          'report':str(args.output.absolute()),'items_2_3_fully_verified':False}))
        return 2
    except FileNotFoundError as exc:
        print(json.dumps({'status':'FILE_NOT_FOUND','stage':stage,'missing_path':str(exc.filename) if exc.filename else None})); return 1
    except Exception as exc:
        from model.read_contracts import ReadRequestError
        print(json.dumps({'status':'INVALID_SCOPE' if isinstance(exc,ReadRequestError) else 'STOPPED',
                          'stage':stage,'error_type':type(exc).__name__,
                          'message':str(exc) if isinstance(exc,ReadRequestError) else
                          'Check selected configuration, admin authentication and broker access. No storage or session change was performed.'}))
        return 2 if isinstance(exc,ReadRequestError) else 1
    except KeyboardInterrupt:
        print(json.dumps({'status':'INTERRUPTED','stage':stage})); return 130


if __name__ == '__main__':
    raise SystemExit(main())
