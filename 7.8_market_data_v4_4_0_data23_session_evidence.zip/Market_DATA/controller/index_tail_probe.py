"""Observe only the disputed historical index tail; do not extend/store sessions."""
import datetime as dt
from decimal import Decimal

from controller.underlying_service import resolve_underlyings
from model.config.market_calendar import IST
from model.exchange_session_evidence import FNO_EFFECTIVE_FROM, FNO_DOCUMENT, CASH_DOCUMENT
from model.fno.history_client import classify_response, OK, NO_DATA, AUTH, RATE_LIMIT
from model.read_contracts import ReadRequestError, date_scope


def _tail_rows(rows, start, end):
    slots = set(); invalid = outside = duplicates = 0
    for row in rows:
        try:
            if not isinstance(row, (list, tuple)) or len(row) < 6 or any(isinstance(v, bool) or v is None for v in row[:6]):
                raise ValueError()
            epoch, *values = [Decimal(str(v)) for v in row[:6]]
            if not all(v.is_finite() for v in (epoch, *values)) or epoch != epoch.to_integral():
                raise ValueError()
            o, h, l, c, volume = values
            if min(o,h,l,c) <= 0 or l > min(o,c) or h < max(o,c) or volume < 0 or volume != volume.to_integral():
                raise ValueError()
            ts = dt.datetime.fromtimestamp(int(epoch), dt.timezone.utc).astimezone(IST)
            if ts.second or ts.microsecond:
                raise ValueError()
            if not start <= ts < end:
                outside += 1; continue
            if ts in slots: duplicates += 1
            slots.add(ts)
        except (ValueError, ArithmeticError, OverflowError, OSError, TypeError):
            invalid += 1
    return {'valid_unique_slots': len(slots), 'timestamps': [t.isoformat() for t in sorted(slots)],
            'invalid_rows': invalid, 'outside_requested_window_rows': outside, 'duplicate_rows': duplicates}


def probe_index_tail(registry, settings, underlyings, day, make_client, *, now=None, progress=None):
    day, _ = date_scope(day, day, max_days=1)
    now = now or dt.datetime.now(IST)
    if now.tzinfo is None or day >= now.astimezone(IST).date() or day < FNO_EFFECTIVE_FROM:
        raise ReadRequestError('Select a completed date on/after 2026-08-03')
    selected = sorted(set(underlyings))
    if not selected or len(selected) > 2 or set(selected) - {'NIFTY','BANKNIFTY'}:
        raise ReadRequestError('Select NIFTY and/or BANKNIFTY only')
    mappings = resolve_underlyings(selected, registry, settings)
    start = dt.datetime.combine(day, dt.time(15,30), IST)
    end = dt.datetime.combine(day, dt.time(15,40), IST)
    checks = []; client = None; attempts = 0; stopped = False
    for mapping in mappings:
        item = {**mapping, 'status': 'NOT_ATTEMPTED'}; checks.append(item)
        if stopped: continue
        try:
            if client is None: client = make_client()
            payload = {'symbol': mapping['symbol'], 'resolution':'1', 'date_format':'0',
                       'range_from':str(int(start.timestamp())),
                       'range_to':str(int((end-dt.timedelta(seconds=1)).timestamp())), 'cont_flag':'0'}
            if progress: progress({**mapping, 'status':'REQUESTING_INDEX_TAIL'})
            attempts += 1
            response = client.history(data=payload)
            kind, _, _ = classify_response(response, settings.history)
            if kind in (AUTH, RATE_LIMIT):
                item['status'] = 'PROVIDER_AUTH_REQUIRED' if kind == AUTH else 'PROVIDER_RATE_LIMITED'
                stopped = True
            elif kind == NO_DATA:
                item['status'] = 'PROVIDER_NO_DATA_IN_TAIL_REQUEST'
            elif kind != OK:
                item['status'] = 'PROVIDER_RESPONSE_NOT_VERIFIED'
            elif len(response['candles']) > 2000:
                item['status'] = 'RESPONSE_BOUND_EXCEEDED'
            else:
                rows = response['candles']; stats = _tail_rows(rows,start,end)
                item.update(stats, raw_rows=len(rows))
                item['status'] = ('RANGE_OR_ROW_REVIEW_REQUIRED' if any(stats[k] for k in
                    ('invalid_rows','outside_requested_window_rows','duplicate_rows')) else
                    'ALL_REQUESTED_TAIL_SLOTS_OBSERVED' if stats['valid_unique_slots'] == 10 else
                    'PARTIAL_TAIL_OBSERVATIONS')
        except KeyboardInterrupt:
            item['status'] = 'INTERRUPTED_RESPONSE_UNCONFIRMED'; stopped = True
        except Exception:
            item['status'] = 'REQUEST_UNAVAILABLE'; stopped = True
    return {'status':'PARTIAL' if stopped else 'INDEX_TAIL_OBSERVATIONS','date':str(day),
            'observed_at':now.astimezone(IST).isoformat(), 'requested_window':{
                'from':start.isoformat(),'to_exclusive':end.isoformat(),'requested_minute_slots':10},
            'checks':checks,'history_call_attempts':attempts,
            'source_documents':[dict(FNO_DOCUMENT),dict(CASH_DOCUMENT)],
            'index_actual_or_indicative_mapping_verified':False,'values_verified':False,
            'unit_scale_verified':False,'live_verified':False,'items_2_3_fully_verified':False,
            'sql_modified':False,'market_data_modified':False,'session_configuration_modified':False,
            'scope':'Historical provider timestamp/row-shape observations in exactly the disputed ten-minute window. No SQL/Parquet reads or writes, no full-day scan, no imports/retries, no inference of actual versus indicative index identity or missing trades. A complete observed grid does not certify prices, official close, units or trading readiness.'}
