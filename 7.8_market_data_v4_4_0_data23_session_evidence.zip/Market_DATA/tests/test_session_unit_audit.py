import datetime as dt
import json
from decimal import Decimal
from types import SimpleNamespace

import pytest
from sqlalchemy import create_engine, text, event

from model import session_unit_audit as audit
from model.config import market_calendar as cal
from model.fno.config import DEFAULT_SESSION
from model.database_catalog import DatabaseCatalog
from controller import diagnostics_cli

DAY=dt.date(2026,11,5)
NOW=dt.datetime(2026,11,7,12,tzinfo=cal.IST)


@pytest.fixture
def db(tmp_path):
    engine=create_engine('sqlite://')
    with engine.begin() as c:
        c.execute(text('CREATE TABLE fno_instruments (id INTEGER PRIMARY KEY, fyers_symbol TEXT, underlying TEXT, category TEXT, expiry DATE, lot_size INTEGER, tick_size NUMERIC)'))
        c.execute(text("INSERT INTO fno_instruments VALUES (1,'NSE:TEST','NIFTY','OPTIONS','2026-11-09',50,0.05)"))
        c.execute(text('CREATE TABLE fno_candles (id INTEGER PRIMARY KEY,contract_id INTEGER,timeframe TEXT,candle_timestamp DATETIME,open NUMERIC,high NUMERIC,low NUMERIC,close NUMERIC,volume BIGINT,oi BIGINT,status TEXT)'))
        c.execute(text("INSERT INTO fno_candles VALUES (1,1,'1m','2026-11-05 09:15:00',100,101,99,100,100,0,'CLOSED')"))
        c.execute(text("INSERT INTO fno_candles VALUES (2,1,'1m','2026-11-05 15:39:00',100,101,99,100,101,NULL,'CLOSED')"))
    cat=DatabaseCatalog({'FNO':lambda:engine},fno_settings=SimpleNamespace(session=DEFAULT_SESSION))
    yield cat,engine
    engine.dispose()


def test_offline_does_not_authenticate_or_connect_and_keeps_sources_unverified(monkeypatch,capsys):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:pytest.fail('offline auth'))
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:pytest.fail('offline DB'))
    assert diagnostics_cli.main(['session-units','--segment','CASH','--from',str(DAY),'--to',str(DAY),'--offline'])==2
    r=json.loads(capsys.readouterr().out)
    assert r['complete'] and not r['data_inspected']
    assert not r['external_evidence_verified'] and not r['unit_scale_verified']
    assert r['calendar'][0]['configured_minutes']==375
    assert 'oi' not in r['units']


def test_declared_fno_385_minutes_and_effective_date_are_not_new_exchange_proof():
    r=audit.audit_report('FNO',DAY,DAY,offline=True,session=DEFAULT_SESSION,now=NOW)
    assert r['calendar'][0]['configured_minutes']==385
    assert not r['external_evidence_verified']
    old=audit.audit_report('FNO','2026-08-01','2026-08-02',offline=True,session=DEFAULT_SESSION,now=NOW)
    assert 'SESSION_EFFECTIVE_RANGE_UNVERIFIED' in old['calendar'][0]['issues']


def test_unknown_muhurat_is_not_assumed_regular_or_verified():
    r=audit.audit_report('FNO','2026-11-08','2026-11-08',offline=True,session=DEFAULT_SESSION,now=NOW)
    day=r['calendar'][0]
    assert 'SPECIAL_SESSION_UNCONFIRMED' in day['issues']
    assert not day['config_calendar_verified'] and day['configured_minutes']==0


def test_split_sessions_respect_breaks_and_close_exclusive(monkeypatch):
    meta={'verified_years':{'CASH':[2026]},'special_sessions':{str(DAY):{
        'verified':True,'segments':['CASH'],'intervals':[{'open':'09:15','close':'10:00'}, {'open':'11:00','close':'12:00'}]}}}
    monkeypatch.setattr(cal,'calendar_metadata',lambda:meta)
    r=audit.audit_report('CASH',DAY,DAY,offline=True,now=NOW)
    assert r['calendar'][0]['configured_minutes']==105
    assert len(r['calendar'][0]['intervals'])==2


def test_bounded_read_is_sql_readonly_and_lot_divisibility_does_not_prove_units(db):
    cat,engine=db;statements=[]
    event.listen(engine,'before_cursor_execute',lambda c,cu,s,p,ctx,m:statements.append(s))
    r=audit.audit_report('FNO',DAY,DAY,catalog=cat,contract_ids=[1],now=NOW)
    row=r['observations'][0];counts=row['counts']
    assert counts['rows']==2 and counts['volume_present']==2
    assert counts['volume_multiple_of_current_lot']==1
    assert counts['oi_present']==1 and counts['oi_null']==1  # zero is not missing
    assert not row['lot_and_tick_effective_date_verified']
    assert not r['unit_scale_verified']
    assert not any(s.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','ALTER','DROP')) for s in statements)


def test_current_tick_grid_review_does_not_round_or_rewrite_history(db):
    cat,engine=db
    with engine.begin() as c:c.execute(text('UPDATE fno_candles SET close=100.03 WHERE id=1'))
    r=audit.audit_report('FNO',DAY,DAY,catalog=cat,contract_ids=[1],now=NOW)
    assert 'CURRENT_TICK_GRID_REVIEW_NOT_HISTORICAL_PROOF' in r['observations'][0]['issues']
    with engine.connect() as c:assert c.execute(text('SELECT close FROM fno_candles WHERE id=1')).scalar()==100.03


def test_negative_fractional_quantities_and_outside_session_are_reported(db):
    cat,engine=db
    with engine.begin() as c:c.execute(text("UPDATE fno_candles SET volume=1.5,oi=-1,candle_timestamp='2026-11-05 15:40:00' WHERE id=1"))
    r=audit.audit_report('FNO',DAY,DAY,catalog=cat,contract_ids=[1],now=NOW)
    counts=r['observations'][0]['counts']
    assert counts['volume_invalid']==counts['oi_invalid']==counts['outside_configured_session']==1


def test_numeric_shape_handles_large_exact_integers_and_rejects_bools_nan():
    assert audit._number('9007199254740993',integer=True)==Decimal('9007199254740993')
    for v in [True, 'NaN', 'Infinity', '-1', '1.2']:
        with pytest.raises((ValueError,ArithmeticError)):audit._number(v,integer=True)


def test_row_limit_and_calendar_change_are_partial(db,monkeypatch):
    cat,_=db;monkeypatch.setattr(audit,'MAX_DAY_ROWS',1)
    r=audit.audit_report('FNO',DAY,DAY,catalog=cat,contract_ids=[1],now=NOW)
    assert r['status']=='PARTIAL' and not r['complete']
    monkeypatch.setattr(audit,'MAX_DAY_ROWS',20000)
    original=cal.calendar_metadata;calls=[]
    def moving():
        calls.append(1);return {**original(),'test_revision':len(calls)}
    monkeypatch.setattr(cal,'calendar_metadata',moving)
    r=audit.audit_report('FNO',DAY,DAY,offline=True,session=DEFAULT_SESSION,now=NOW)
    assert r['status']=='PARTIAL' and r['summary']['issues']['CALENDAR_CHANGED_DURING_AUDIT']==1


def test_online_requires_auth_and_report_is_exclusive(db,tmp_path,monkeypatch,capsys):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:db[0])
    p=tmp_path/'report.json'
    args=['session-units','--segment','FNO','--contract-ids','1','--from',str(DAY),'--to',str(DAY),'--output',str(p)]
    assert diagnostics_cli.main(args)==2
    before=p.read_bytes();assert diagnostics_cli.main(args)==2 and p.read_bytes()==before
    def denied():raise PermissionError('no')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',denied)
    assert diagnostics_cli.main(args[:-2])==1


def test_invalid_scope(db):
    with pytest.raises(ValueError):audit.audit_report('FNO',DAY,NOW.date(),catalog=db[0],contract_ids=[1],now=NOW)
    with pytest.raises(ValueError):audit.audit_report('CASH',DAY,DAY,offline=True,symbols=['SBIN'],now=NOW)


def test_reviewed_fno_normal_rule_does_not_verify_units_calendar_or_changed_hours():
    import dataclasses
    r=audit.audit_report('FNO',DAY,DAY,offline=True,session=DEFAULT_SESSION,now=NOW)
    e=r['reviewed_exchange_source']
    assert e['normal_session_rule_content_reviewed'] and e['configured_normal_hours_match_reviewed_rule']
    assert e['document']['reference']=='NSE/FAOP/74467' and e['effective_from']=='2026-08-03'
    assert not e['holiday_and_special_session_sources_verified'] and not r['unit_scale_verified']
    changed=dataclasses.replace(DEFAULT_SESSION,close=dt.time(15,30),last_minute=dt.time(15,29))
    r=audit.audit_report('FNO',DAY,DAY,offline=True,session=changed,now=NOW)
    assert not r['reviewed_exchange_source']['configured_normal_hours_match_reviewed_rule']


def test_cash_actual_indicative_distinction_does_not_extend_index_hours():
    r=audit.audit_report('CASH',DAY,DAY,offline=True,now=NOW)
    e=r['reviewed_exchange_source']
    assert e['cas_index_distinction_reviewed'] and not e['normal_session_rule_content_reviewed']
    assert e['document']['reference']=='NSE/CMTR/73362'
    assert r['calendar'][0]['configured_minutes']==375
