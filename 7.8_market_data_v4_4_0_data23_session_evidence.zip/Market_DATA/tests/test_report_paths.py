import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

from model.config.runtime_paths import report_path
from model.exceptions import ConfigurationError


@pytest.fixture
def folders(tmp_path, monkeypatch):
    home = tmp_path / 'persistent'; home.mkdir()
    code = tmp_path / 'code-release'; code.mkdir()
    monkeypatch.setenv('TIOS_HOME', str(home)); monkeypatch.chdir(code)
    return home, code


def test_report_paths_persist_across_code_folders_and_keep_absolute_exports(folders, tmp_path, monkeypatch):
    home, code = folders
    assert report_path('report.json') == home / 'report.json'
    assert report_path('reports/a.json') == home / 'reports/a.json'
    other = tmp_path / 'new-release'; other.mkdir(); monkeypatch.chdir(other)
    assert report_path('report.json') == home / 'report.json'
    explicit = tmp_path / 'exports/a.json'
    assert report_path(explicit) == explicit
    with pytest.raises(ConfigurationError): report_path('../escape.json')


def test_no_profile_preserves_existing_cwd_semantics(tmp_path, monkeypatch):
    monkeypatch.delenv('TIOS_HOME', raising=False); monkeypatch.chdir(tmp_path)
    assert report_path('a.json') == Path('a.json')
    monkeypatch.setenv('TIOS_HOME', str(tmp_path / 'missing'))
    with pytest.raises(ConfigurationError): report_path('a.json')
    assert not (tmp_path / 'missing').exists()


def test_probe_reads_runtime_report_instead_of_stale_code_copy_and_creates_parent(folders, monkeypatch):
    from controller import data23_probe_cli as cli
    home, code = folders
    (home / 'prior.json').write_text(json.dumps({'marker': 'runtime'}))
    (code / 'prior.json').write_text(json.dumps({'marker': 'stale'}))
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: object())
    monkeypatch.setattr('model.fno.config.load_fno_settings', lambda: object())
    seen = []
    def probe(reads, settings, reports, client, progress):
        seen.extend(reports)
        return {'status': 'RECHECK_OBSERVATIONS', 'summary': {}}
    monkeypatch.setattr('controller.data23_probe.probe_empty', probe)
    assert cli.main(['--reports','prior.json','--output','reports/new.json']) == 2
    assert seen == [{'marker': 'runtime'}]
    assert (home / 'reports/new.json').is_file()
    assert not (code / 'reports').exists()


def test_missing_runtime_report_names_exact_path_and_never_falls_back(folders, monkeypatch, capsys):
    from controller import data23_probe_cli as cli
    home, code = folders
    (code / 'prior.json').write_text('{}')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: pytest.fail('No DB before input validation'))
    assert cli.main(['--reports','prior.json','--output','new.json']) == 1
    result = json.loads(capsys.readouterr().out)
    assert result['status'] == 'FILE_NOT_FOUND' and result['stage'] == 'input_reports'
    assert Path(result['missing_path']) == home / 'prior.json'
    assert not (home / 'new.json').exists()


def test_existing_runtime_output_preserved_and_auth_failure_creates_no_folder(folders, monkeypatch):
    from controller import data23_probe_cli as cli
    home, _ = folders
    (home / 'existing.json').write_text('preserve')
    def denied(): raise PermissionError('denied')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', denied)
    assert cli.main(['--reports','prior.json','--output','existing.json']) == 2
    assert (home / 'existing.json').read_text() == 'preserve'
    assert cli.main(['--reports','prior.json','--output','new-folder/a.json']) == 1
    assert not (home / 'new-folder').exists()


@pytest.mark.parametrize('command',['inventory','session-units','fno-values'])
def test_diagnostic_outputs_follow_runtime_profile(folders, monkeypatch, command):
    from controller import diagnostics_cli as cli
    home, code = folders
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: object())
    result = {'status':'FINDINGS','complete':True,'segment':'FNO','from':'2026-11-05','to':'2026-11-05',
              'summary':{},'values_verified':False,'complete_minute_coverage':False,'offline':False,
              'external_evidence_verified':False,'unit_scale_verified':False,'live_verified':False}
    monkeypatch.setattr('model.data_inventory.inventory_report', lambda *a, **k: dict(result))
    monkeypatch.setattr('model.session_unit_audit.audit_report', lambda *a, **k: dict(result))
    monkeypatch.setattr('model.fno.value_audit.audit_values', lambda *a, **k: dict(result))
    args = [command,'--from','2026-11-05','--to','2026-11-05','--output','reports/'+command+'.json']
    args += ['--contract-ids','1'] if command == 'fno-values' else ['--segment','FNO','--contract-ids','1']
    assert cli.main(args) == 2
    assert (home / 'reports' / (command+'.json')).is_file()
    assert not (code / 'reports').exists()


def test_underlying_preview_output_and_run_input_use_runtime_profile(folders, monkeypatch):
    from controller import underlying_cli as cli
    home, code = folders
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.fno.config.load_fno_settings', lambda: object())
    monkeypatch.setattr('controller.market_data_service.MarketDataService', lambda: object())
    plan = {'mappings':[], 'workflow':{'fetch_plan':{},'stages':[]},'marker':'runtime'}
    monkeypatch.setattr('controller.underlying_service.preview_underlyings', lambda *a, **k: dict(plan))
    assert cli.main(['preview','--underlyings','NIFTY','--from','2026-11-05','--to','2026-11-05','--output','plan.json']) == 0
    assert (home / 'plan.json').is_file()
    (code / 'plan.json').write_text('{"marker":"stale"}')
    seen = []
    def run(service, settings, actual, progress):
        seen.append(actual); return {'status':'TEST'}, 0
    monkeypatch.setattr('controller.underlying_service.run_underlyings', run)
    assert cli.main(['run','--plan','plan.json','--confirm']) == 0
    assert seen == [plan]


def test_explicit_absolute_probe_report_still_supported(folders, monkeypatch, tmp_path):
    from controller import data23_probe_cli as cli
    home, _ = folders
    external = tmp_path / 'explicit'; external.mkdir()
    source = external / 'input.json'; source.write_text('{}')
    output = external / 'new.json'
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: object())
    monkeypatch.setattr('model.fno.config.load_fno_settings', lambda: object())
    monkeypatch.setattr('controller.data23_probe.probe_empty', lambda *a, **k: {'status':'NO_EMPTY_SCOPES','summary':{}})
    assert cli.main(['--reports',str(source),'--output',str(output)]) == 2
    assert output.is_file() and list(home.iterdir()) == []
