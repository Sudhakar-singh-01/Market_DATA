import datetime as dt
import json
from types import SimpleNamespace as NS

import pytest

from controller import index_tail_probe as probe, index_tail_probe_cli as cli
from model.config.market_calendar import IST
from model.fno.config import load_fno_settings
from test_underlying_data import registry

DAY = dt.date(2026,11,5)
NOW = dt.datetime(2026,11,9,14,tzinfo=IST)


def rows(n=10, minute=30):
    return [[int(dt.datetime.combine(DAY,dt.time(15,minute+i),IST).timestamp()),
             100,101,99,100,0] for i in range(n)]


def invoke(response, underlyings=('NIFTY','BANKNIFTY')):
    calls = []
    def history(data):
        calls.append(data)
        if isinstance(response,BaseException): raise response
        return response
    result = probe.probe_index_tail(registry(),load_fno_settings(),underlyings,str(DAY),
                                   lambda:NS(history=history),now=NOW)
    return result,calls


def test_only_two_ten_minute_requests_no_storage_or_identity_certificate():
    r,calls = invoke({'s':'ok','candles':rows()})
    assert len(calls)==r['history_call_attempts']==2
    for p in calls:
        assert p['date_format']=='0' and p['resolution']=='1'
        assert int(p['range_to'])-int(p['range_from'])==599
        assert dt.datetime.fromtimestamp(int(p['range_from']),IST).time()==dt.time(15,30)
    assert {p['symbol'] for p in calls}=={'NSE:NIFTY50-INDEX','NSE:NIFTYBANK-INDEX'}
    assert all(c['status']=='ALL_REQUESTED_TAIL_SLOTS_OBSERVED' and c['valid_unique_slots']==10 for c in r['checks'])
    for key in ('values_verified','unit_scale_verified','live_verified','index_actual_or_indicative_mapping_verified',
                'sql_modified','market_data_modified','session_configuration_modified','items_2_3_fully_verified'):
        assert r[key] is False


def test_no_data_not_interpreted_as_zero_trades_or_failed_storage():
    r,calls=invoke({'s':'ok','candles':[],'message':'SECRET'})
    assert len(calls)==2 and all(c['status']=='PROVIDER_NO_DATA_IN_TAIL_REQUEST' for c in r['checks'])
    assert 'SECRET' not in json.dumps(r)


@pytest.mark.parametrize('fault',['out_of_window','duplicates','bad_volume','nan','bad_ohlc','malformed'])
def test_invalid_or_ignored_range_cannot_get_complete_observation_status(fault):
    sample=rows()
    if fault=='out_of_window':sample += rows(1,29)
    elif fault=='duplicates':sample += rows(1)
    elif fault=='bad_volume':sample[0][-1]=True
    elif fault=='nan':sample[0][1]='NaN'
    elif fault=='bad_ohlc':sample[0][2]=90
    else:sample[0]=[1]
    r,_=invoke({'s':'ok','candles':sample},['NIFTY'])
    assert r['checks'][0]['status']=='RANGE_OR_ROW_REVIEW_REQUIRED'


def test_partial_grid_and_response_bound_are_explicit():
    r,_=invoke({'s':'ok','candles':rows(3)},['NIFTY'])
    assert r['checks'][0]['status']=='PARTIAL_TAIL_OBSERVATIONS'
    assert r['checks'][0]['valid_unique_slots']==3
    r,_=invoke({'s':'ok','candles':[[]]*2001},['NIFTY'])
    assert r['checks'][0]['status']=='RESPONSE_BOUND_EXCEEDED'


@pytest.mark.parametrize('response',[
    {'s':'error','code':401,'message':'SECRET'},
    {'s':'error','code':429,'message':'SECRET'}, OSError('SECRET'), KeyboardInterrupt()])
def test_auth_rate_network_interrupt_stop_later_calls_with_partial_report(response):
    r,calls=invoke(response)
    assert len(calls)==1 and r['status']=='PARTIAL'
    assert r['checks'][1]['status']=='NOT_ATTEMPTED'
    assert 'SECRET' not in json.dumps(r)


def test_scope_and_mapping_preflight_before_client():
    for day,names in [(NOW.date(),['NIFTY']),('2026-08-02',['NIFTY']),(DAY,['FINNIFTY'])]:
        with pytest.raises(ValueError):
            probe.probe_index_tail(registry(),load_fno_settings(),names,str(day),lambda:pytest.fail('No broker'),now=NOW)


def test_cli_runtime_output_no_db_bootstrap_and_existing_file_preserved(tmp_path,monkeypatch,capsys):
    home=tmp_path/'runtime';home.mkdir();code=tmp_path/'code';code.mkdir()
    settings=load_fno_settings()
    monkeypatch.setenv('TIOS_HOME',str(home));monkeypatch.chdir(code)
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('model.database_catalog.configured_catalog',lambda:pytest.fail('No DB'))
    monkeypatch.setattr('model.config.instrument_loader.load_instrument_registry',registry)
    monkeypatch.setattr('model.fno.config.load_fno_settings',lambda:settings)
    monkeypatch.setattr('model.config.env_loader.load_env_config',lambda:NS(fyers=object()))
    monkeypatch.setattr('model.fyers.auth.get_authenticated_client',lambda creds:NS(history=lambda data:{'s':'ok','candles':rows()}))
    calls=[]
    monkeypatch.setattr('model.fyers.rate_limiter.get_shared_limiter',lambda:NS(acquire=calls.append))
    args=['--date',str(DAY),'--output','tail.json']
    assert cli.main(args)==2
    assert len(calls)==2 and (home/'tail.json').is_file() and not (code/'tail.json').exists()
    before=(home/'tail.json').read_bytes();assert cli.main(args)==2
    assert before==(home/'tail.json').read_bytes() and len(calls)==2


def test_cli_auth_failure_does_not_create_output_or_contact_provider(tmp_path,monkeypatch):
    def denied():raise PermissionError('SECRET')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',denied)
    monkeypatch.setattr('model.config.instrument_loader.load_instrument_registry',lambda:pytest.fail('Auth first'))
    target=tmp_path/'new-folder/tail.json'
    assert cli.main(['--date',str(DAY),'--output',str(target)])==1
    assert not target.parent.exists()
