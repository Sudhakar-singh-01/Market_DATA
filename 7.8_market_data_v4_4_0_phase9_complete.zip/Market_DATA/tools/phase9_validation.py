"""Targeted provider-free release validation for Windows and local CI.

The manifest intentionally excludes live FYERS and disposable/production MySQL
tests. Commands use the current interpreter and never print environment values.
"""
import argparse
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import yaml


ROOT = Path(__file__).resolve().parents[1]

TEST_GROUPS = {
    "core": (
        "tests/test_release4.py",
        "tests/test_consumer_adapter.py",
        "tests/test_market_data_client.py",
        "tests/test_unified_workflow.py",
        "tests/test_workflow_integration.py",
        "tests/test_sma.py",
    ),
    "api": (
        "tests/test_read_api.py",
        "tests/test_client_api_integration.py",
    ),
    "operations": (
        "tests/test_backup_service.py",
        "tests/test_schema_management.py",
        "tests/test_schema_compatibility.py",
        "tests/test_recovery_verification.py",
        "tests/test_cleanup_service.py",
        "tests/test_cash_calendar_update.py",
        "tests/test_aggregation_reporting.py",
        "tests/test_runtime_profile.py",
        "tests/test_runtime_setup.py",
        "tests/test_storage_scope.py",
        "tests/test_websocket_idle_watchdog.py",
        "tests/test_idle_live_policy.py",
        "tests/test_market_session_policy.py",
        "tests/test_dashboard_layer.py",
        "tests/test_dual_store_consistency.py",
        "tests/fno/test_fno_live.py",
        "tests/fno/test_fno_repository.py",
        "tests/fno/test_fno_parquet.py",
        "tests/fno/test_worker_shutdown.py",
    ),
}


def validate_manifest():
    paths = [path for group in TEST_GROUPS.values() for path in group]
    if len(paths) != len(set(paths)):
        raise RuntimeError("Validation manifest contains duplicate test files")
    missing = [path for path in paths if not (ROOT / path).is_file()]
    if missing:
        raise RuntimeError("Validation manifest references missing test files")
    if any("mysql" in path.lower() for path in paths):
        raise RuntimeError("Validation manifest must not select MySQL integration tests")


def isolated_environment(runtime):
    """Create a credential-free profile so tests cannot select operator state."""
    home = Path(runtime)
    (home / "config").mkdir(parents=True)
    (home / "instruments").mkdir()
    for name in ("data_settings.yaml", "timeframe_settings.yaml", "fno_settings.yaml", "holidays.yaml"):
        shutil.copy2(ROOT / "config" / name, home / "config" / name)
    for name in ("stocks.yaml", "indices.yaml"):
        shutil.copy2(ROOT / "instruments" / name, home / "instruments" / name)
    fno_path = home / "config" / "fno_settings.yaml"
    fno = yaml.safe_load(fno_path.read_text(encoding="utf-8"))
    fno["parquet"]["root"] = (home / "data" / "fno").as_posix()
    fno_path.write_text(yaml.safe_dump(fno, sort_keys=False), encoding="utf-8")
    cash = home / "data" / "cash"
    runtime_dir = home / "runtime"
    cash.mkdir(parents=True)
    (home / "data" / "fno").mkdir()
    runtime_dir.mkdir()
    (home / "config" / ".env").write_text(
        f"CASH_DATA_ROOT={cash.as_posix()}\nTIOS_RUNTIME_DIR={runtime_dir.as_posix()}\n", encoding="utf-8")
    return home


def run(groups, runner=subprocess.run):
    validate_manifest()
    results = []
    started = time.monotonic()
    safe_env = os.environ.copy()
    blocked_prefixes = ("FYERS_", "DB_", "FNO_DB_", "RECOVERY_DB_", "TEST_FNO_DB_", "TEST_CASH_DB_", "FNO_TEST_DB_")
    blocked_exact = {"MARKET_DATA_API_PASSWORD", "MARKET_DATA_ADMIN_PASSWORD",
                     "USER_PASSWORD_HASH", "ADMIN_PASSWORD_HASH", "CASH_DATA_ROOT", "TIOS_RUNTIME_DIR"}
    for key in tuple(safe_env):
        if key in blocked_exact or key.startswith(blocked_prefixes):
            safe_env.pop(key, None)
    with tempfile.TemporaryDirectory(prefix="tios-phase9-") as runtime:
        safe_env["TIOS_HOME"] = str(isolated_environment(runtime))
        for name in groups:
            command = [sys.executable, "-m", "pytest", "-q", "-p", "tools.phase9_pytest_guard", *TEST_GROUPS[name]]
            before = time.monotonic()
            completed = runner(command, cwd=ROOT, env=safe_env)
            results.append({"group": name, "exit_code": completed.returncode,
                            "seconds": round(time.monotonic() - before, 3)})
            if completed.returncode:
                break
    return {"status": "PASSED" if len(results) == len(groups) and all(r["exit_code"] == 0 for r in results) else "FAILED",
            "platform": platform.system(), "python": platform.python_version(),
            "groups": results, "seconds": round(time.monotonic() - started, 3),
            "scope": "provider-free; no MySQL integration or production data access"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--groups", nargs="+", choices=tuple(TEST_GROUPS),
                        default=tuple(TEST_GROUPS), help="Ordered validation groups")
    parser.add_argument("--list", action="store_true", help="Validate and print the manifest without running pytest")
    args = parser.parse_args(argv)
    try:
        validate_manifest()
        if args.list:
            print(json.dumps({"groups": TEST_GROUPS}, indent=2))
            return 0
        result = run(tuple(args.groups))
        print(json.dumps(result, indent=2))
        return 0 if result["status"] == "PASSED" else 1
    except Exception as exc:
        print(json.dumps({"status": "FAILED", "error": type(exc).__name__,
                          "message": "Validation could not run; inspect the project environment and manifest."}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

