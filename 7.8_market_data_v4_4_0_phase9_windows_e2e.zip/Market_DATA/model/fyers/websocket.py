"""
model/fyers/websocket.py
Thin transport wrapper around fyers_apiv3.FyersWebsocket.data_ws.FyersDataSocket.

Responsibility: connectivity, authentication, subscription, and message
delivery ONLY (spec Section 15 -- candle-building logic must live in
model/processing/candle_builder.py, never here).

Verified against fyers-apiv3's documented usage: the constructor takes
access_token, log_path, litemode, write_to_file, reconnect, and
on_connect/on_close/on_error/on_message callbacks; subscribe()/
unsubscribe() take (symbols, data_type); keep_running() blocks to
receive data.

RECONNECTION MODEL (spec Section 14/26 -- must be explicit, not assumed):
    reconnect=True is passed to the SDK, which handles the actual
    socket-level reconnect internally. on_connect is re-invoked by the
    SDK after every reconnect (not just the first connect), which is
    why re-subscribing inside _handle_connect() also restores
    subscriptions after a reconnect (spec Section 14 step 3), without
    this wrapper needing its own reconnect loop.

    LIMITATION: the SDK's reconnect behavior does NOT expose its own
    max-attempts/backoff parameters that this wrapper could plug our
    data_settings.yaml `reconnect` config into directly -- that level
    of control was not confirmed as available in the SDK's public
    interface. What this wrapper DOES do with reconnect_settings is a
    supervisory watchdog: if no message (of any kind) is received for
    longer than the activity threshold, it logs throttled informational
    FEED_IDLE status. Silence alone does not prove disconnection or tick
    freshness. It does not attempt to out-guess the SDK's internal
    reconnect logic. If FYERS's SDK exposes finer reconnect control in
    a version newer than what could be verified here, tighten this.

CONCURRENCY MODEL (spec Section 26):
    Callback-based, matching the FYERS SDK's own design -- on_connect/
    on_message/on_close/on_error execute on the SDK's internal thread.
    No asyncio is introduced; mixing concurrency models here would add
    complexity without a documented benefit, since the SDK itself is
    not asyncio-based.
"""

import logging
import threading
import time
from typing import Callable, Optional

from fyers_apiv3.FyersWebsocket import data_ws

log = logging.getLogger("market_data.fyers.websocket")

SYMBOL_UPDATE = "SymbolUpdate"

# Watchdog threshold -- see "RECONNECTION MODEL" in module docstring.
STALE_CONNECTION_WARNING_SECONDS = 60
CLOSE_TIMEOUT_SECONDS = 10


class FyersWebSocketClient:
    def __init__(
        self,
        access_token: str,
        symbols: list,
        on_tick: Callable,
        reconnect_settings=None,
        on_reconnect: Optional[Callable] = None,
        data_type: str = SYMBOL_UPDATE,
        litemode: bool = False,
        log_path: str = "",
    ):
        """
        ...
        on_reconnect: called (with no arguments) when _handle_connect
                      fires for the SECOND time or later -- i.e. this is
                      the SDK reconnecting after a drop, not the initial
                      connect. Lets the caller (live_controller.py) run
                      gap-detection/backfill (spec Section 22) without
                      this transport-only module needing to know
                      anything about candles or storage.
        """
        from model.fyers.rate_limiter import account_runtime_path
        self._owner_path=account_runtime_path(access_token.split(":",1)[0],"data-socket.lock")
        self._symbols = list(dict.fromkeys(symbols))
        if len(self._symbols)>100:raise ValueError("Standard FYERS DataSocket supports at most 100 symbols")
        self._data_type = data_type
        self._on_tick = on_tick
        self._reconnect_settings = reconnect_settings
        self._on_reconnect = on_reconnect
        self._has_connected_before = False
        self._last_message_time = time.monotonic()
        self._transport_state = "CONNECTING"
        self._last_watchdog_state = None
        self._last_watchdog_log = 0.0
        self._watchdog_stop = threading.Event()
        # The FYERS SDK's own keep_running() does NOT block -- it just
        # spawns a background thread and returns immediately. Without
        # this event, connect_and_run() (and therefore main()) would
        # return right away, the interpreter would start finalizing,
        # and the SDK's still-running internal ws_thread would go on
        # delivering ticks into on_message after shutdown had begun
        # (root cause of "can't register atexit after shutdown").
        self._stop_event = threading.Event()
        self._shutdown_complete = threading.Event()
        self._stop_lock = threading.Lock()
        self._close_started = False

        self._socket = data_ws.FyersDataSocket(
            access_token=access_token,
            log_path=log_path,
            litemode=litemode,
            write_to_file=False,
            reconnect=True,
            on_connect=self._handle_connect,
            on_close=self._handle_close,
            on_error=self._handle_error,
            on_message=self._handle_message,
        )

    def _handle_connect(self):
        if self._watchdog_stop.is_set():
            return
        self._transport_state = "CONNECTED"
        is_reconnect = self._has_connected_before
        self._has_connected_before = True

        log.info("WebSocket reconnected" if is_reconnect else "WebSocket connected")
        self._last_message_time = time.monotonic()
        if self._symbols:
            log.info(f"Subscribing to {len(self._symbols)} instrument(s)")
            self._socket.subscribe(symbols=self._symbols, data_type=self._data_type)

        if is_reconnect and self._on_reconnect:
            try:
                self._on_reconnect()
            except Exception:
                log.exception("Error in on_reconnect callback")

    def _handle_close(self, message):
        self._transport_state = "DISCONNECTED"
        if self._watchdog_stop.is_set():
            return
        from model.monitoring import emit
        emit("SOCKET_DISCONNECTED",{},severity="ERROR",throttle_seconds=30)
        log.warning("WebSocket closed")

    def _handle_error(self, message):
        if self._watchdog_stop.is_set():
            return
        from model.monitoring import emit
        emit("SOCKET_ERROR",{},severity="ERROR",throttle_seconds=30)
        log.error("WebSocket error; inspect provider connection status")

    def _handle_message(self, message):
        if self._watchdog_stop.is_set():
            return
        self._last_message_time = time.monotonic()
        try:
            self._on_tick(message)
        except Exception:
            # A single malformed/unexpected message must not kill the
            # socket's receive loop (spec Section 12: "Handle malformed
            # messages").
            log.exception("Error handling incoming WebSocket message")

    def add_symbols(self, symbols: list):
        new_symbols = [s for s in symbols if s not in self._symbols]
        if not new_symbols:
            return
        if len(self._symbols)+len(new_symbols)>100:raise ValueError("DataSocket subscription limit exceeded")
        self._symbols.extend(new_symbols)
        self._socket.subscribe(symbols=new_symbols, data_type=self._data_type)
        log.info(f"Added subscription for {len(new_symbols)} instrument(s)")

    def remove_symbols(self, symbols: list):
        to_remove = [s for s in symbols if s in self._symbols]
        if not to_remove:
            return
        for s in to_remove:
            self._symbols.remove(s)
        self._socket.unsubscribe(symbols=to_remove, data_type=self._data_type)
        log.info(f"Removed subscription for {len(to_remove)} instrument(s)")

    def _watchdog_once(self):
        if self._watchdog_stop.is_set():
            return
        now = time.monotonic()
        idle = now - self._last_message_time
        activity = "FEED_IDLE" if idle > STALE_CONNECTION_WARNING_SECONDS else "RECENT_MESSAGE"
        state = (self._transport_state, activity)
        if state == self._last_watchdog_state and now - self._last_watchdog_log < 300:
            return
        if self._watchdog_stop.is_set():
            return
        self._last_watchdog_state, self._last_watchdog_log = state, now
        log.info("%s: last WebSocket message %.0fs ago; last transport state=%s. "
                 "Message silence alone does not prove disconnection or market-data freshness.",
                 activity, idle, self._transport_state)

    def _run_watchdog(self):
        # Interruptible wait prevents a sleeping watchdog from logging after stop.
        while not self._watchdog_stop.wait(10):
            self._watchdog_once()

    def connect_and_run(self):
        """Blocking call -- establishes the connection and processes
        messages until stop() is called or the process is interrupted.

        self._socket.keep_running() (SDK call) does NOT itself block --
        it only starts a background thread. We block on our own event
        instead, so the calling thread (and therefore the whole process)
        stays alive for as long as the WebSocket is meant to be running."""
        from model.storage.locking import file_lock
        with file_lock(self._owner_path,timeout=0):
            self._run_owned_socket()

    def _run_owned_socket(self):
        watchdog = threading.Thread(target=self._run_watchdog, daemon=True)
        watchdog.start()

        log.info("WebSocket connecting")
        self._socket.connect()
        self._socket.keep_running()
        # Wait in a loop rather than a single indefinite wait(): on some
        # Windows/terminal setups a single uninterrupted blocking wait can
        # delay signal delivery. Waking up every second guarantees the
        # interpreter gets frequent chances to notice Ctrl+C/SIGTERM.
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=1)
        self._shutdown_complete.wait() # retain ownership if SDK shutdown is still pending

    def stop(self):
        with self._stop_lock:
            if self._close_started:
                return
            self._close_started = True
            self._watchdog_stop.set()
            self._transport_state = "STOPPING"
            self._stop_event.set()
            log.info("WebSocket shutting down")

        # The SDK's close_connection() calls .join() with NO timeout on
        # its internal ws_thread/message_thread/ping_thread. If any of
        # those don't exit promptly after close() (known to happen on
        # some socket states/platforms), close_connection() hangs
        # forever and our own stop()/shutdown would hang with it --
        # which is exactly what made Ctrl+C look like "nothing happens".
        # Run it in a side thread so stop() itself has a bounded wait. If the
        # SDK remains stuck, connect_and_run() deliberately retains socket
        # ownership and its account lock; starting another live session while
        # the old SDK threads may still exist would create overlapping feeds.
        def _close():
            try:
                self._socket.close_connection()
            except Exception:
                log.exception("Error while closing WebSocket connection")
            finally:
                # A provider close exception must not strand connect_and_run()
                # forever. A genuinely stuck close remains incomplete so the
                # session owner keeps its cross-process socket lock.
                self._shutdown_complete.set()

        closer = threading.Thread(target=_close, daemon=True)
        closer.start()
        closer.join(timeout=CLOSE_TIMEOUT_SECONDS)
        if closer.is_alive():
            log.warning(
                "SDK close_connection() did not finish within %.0fs (its internal "
                "thread join is likely stuck). Socket ownership remains active; "
                "do not restart live ingestion in this process until it exits.",
                CLOSE_TIMEOUT_SECONDS,
            )
