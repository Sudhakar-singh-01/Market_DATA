"""Canonical server-side timeframe names and fixed durations.

The HTTP client keeps its own wire-contract tuple so it can remain installable
without the application package. Server readers, workflows and aggregation use
these definitions through their existing public aliases.
"""

BASE_TIMEFRAME = "1m"

# Daily candles follow configured session windows and therefore have no fixed
# duration here.
DERIVED_TIMEFRAME_SECONDS = {
    "3m": 180,
    "5m": 300,
    "15m": 900,
    "30m": 1800,
    "1h": 3600,
}

DERIVED_TIMEFRAMES = (*DERIVED_TIMEFRAME_SECONDS, "1d")
TIMEFRAMES = (BASE_TIMEFRAME, *DERIVED_TIMEFRAMES)

