import dataclasses
import datetime
import threading
from decimal import Decimal

import pytest
from sqlalchemy import text

from controller import fno_live as fl
from model.fno.config import load_fno_settings
from model.fno.history_client import FnoHistoryFetcher
from model.fno.models import IST
from model.fno.parquet_store import FnoParquetStore
from model.fno.repository import FnoRepository
from test_fno_harvest import FakeFyers, rows_for
from tests_support import sample_contract

DAY = datetime.date(2026, 10, 19)                       # Monday
EXP = datetime.date(2026, 10, 27)
FUT, OPT, OPT2 = "NSE:NIFTY26OCTFUT", "NSE:NIFTY26OCT25500CE", "NSE:NIFTY26OCT25600CE"
S = load_fno_settings()


class Clock:
    def __init__(self, h=9, m=0, day=DAY):
        self.t = datetime.datetime(day.year, day.month, day.day, h, m, tzinfo=IST)
    def __call__(self): return self.t
    def set(self, h, m, s=0): self.t = self.t.replace(hour=h, minute=m, second=s)


def tick(symbol, ltp, vol, h, m, s=0, day=DAY):
    """Shaped like the real SymbolUpdate messages captured by the probe."""
    ep = int(datetime.datetime(day.year, day.month, day.day, h, m, s, tzinfo=IST).timestamp())
    return {"symbol": symbol, "ltp": ltp, "vol_traded_today": vol, "exch_feed_time": ep, "last_traded_time": ep,
            "bid_price": ltp - 0.05, "ask_price": ltp + 0.05, "type": "sf"}


@pytest.fixture()
def env(clean_fno, tmp_path):
    repo = FnoRepository(clean_fno)
    repo.upsert_contracts([sample_contract(FUT, category="FUTURES", expiry=EXP), sample_contract(OPT, expiry=EXP),
                           sample_contract(OPT2, expiry=EXP, strike=Decimal("25600"))])
    class E: pass
    e = E(); e.repo, e.engine, e.clock = repo, clean_fno, Clock()
    e.store = FnoParquetStore(tmp_path / "fno", repo)
    e.contracts = repo.get_contracts()
    e.make = lambda settings=S, store=True, fetcher=None, contracts=None, clock=None: fl.FnoLiveIngestor(
        repo, e.store if store else None, settings, contracts or e.contracts, fetcher=fetcher, clock=clock or e.clock)
    e.count = lambda sym="%": clean_fno.connect().execute(text(
        "SELECT COUNT(*) FROM fno_candles c JOIN fno_instruments i ON i.id=c.contract_id WHERE i.fyers_symbol LIKE :s"), {"s": sym}).scalar()
    return e


def candles(env):
    with env.engine.connect() as c:
        return c.execute(text("SELECT i.fyers_symbol, candle_timestamp, open, high, low, close, volume, oi, c.source FROM fno_candles c "
                              "JOIN fno_instruments i ON i.id=c.contract_id ORDER BY i.fyers_symbol, candle_timestamp")).fetchall()


# ------------------------------------------------------------- universe / cap
def test_universe_is_capped_futures_first_nearest_atm_and_excludes_expired():
    mk = lambda sym, k, exp=EXP, **kw: sample_contract(sym, expiry=exp, strike=Decimal(k), **kw)
    cs = [sample_contract("F", category="FUTURES", expiry=EXP)] + [mk(f"O{k}", str(k)) for k in range(25000, 26100, 100)]
    old = mk("OLD", "25500", exp=datetime.date(2026, 10, 1)); cs.append(old)
    chosen, meta = fl.select_live_universe(cs, S, DAY, {"NIFTY": 25500}, max_subscriptions=4)
    assert [c.fyers_symbol for c in chosen][0] == "F" and "OLD" not in {c.fyers_symbol for c in chosen}
    assert {c.fyers_symbol for c in chosen[1:]} == {"O25500", "O25400", "O25600"} | set() or len(chosen) == 4
    assert meta["subscribed"] == 4 and meta["dropped_by_cap"] == meta["eligible"] - 4 and meta["cap"] == 4
    assert chosen[1].fyers_symbol == "O25500"                                   # nearest to ATM right after the future


def test_default_cap_comes_from_config():
    assert S.subscriptions.max_subscriptions == 100


# --------------------------------------------------------------------- ticks
def test_non_ticks_unknown_symbols_and_out_of_session_ticks_are_counted_not_used(env):
    ing = env.make()
    ing.on_message({"type": "sub", "code": 200, "message": "Subscribed", "s": "ok"})
    ing.on_message("junk")
    ing.on_message(tick("NSE:RELIANCE26OCTFUT", 100, 1, 9, 20))
    ing.on_message(tick(FUT, 100, 1, 9, 10))                                    # pre-open
    ing.on_message(tick(FUT, 100, 1, 15, 45))                                   # after 15:39
    st = ing.stats
    assert (st.ticks_not_tick, st.ticks_unknown_symbol, st.ticks_outside_session) == (2, 1, 0)
    assert ing.builder.current_bucket(FUT) is not None


def test_duplicate_and_late_ticks_are_dropped_and_a_closed_candle_is_never_reopened(env):
    ing = env.make()
    ing.on_message(tick(FUT, 100, 10, 9, 15, 5)); ing.on_message(tick(FUT, 100, 10, 9, 15, 5))      # exact duplicate
    ing.on_message(tick(FUT, 101, 12, 9, 16, 1))                                                    # closes 09:15
    ing.on_message(tick(FUT, 150, 99, 9, 15, 50))                                                   # late: its minute is finished
    assert ing.stats.ticks_duplicate == 1 and ing.stats.ticks_late == 1 and ing.stats.candles_closed == 1
    ing.flush()
    row = [r for r in candles(env) if r[0] == FUT][0]
    assert row[3] == Decimal("100.0000")                                                            # the late 150 never touched it


def test_a_tick_is_never_a_finished_candle_and_a_candle_closes_on_the_next_minutes_first_tick(env):
    ing = env.make()
    for s, ltp, vol in ((1, 100, 10), (20, 103, 15), (40, 99, 18), (58, 101, 20)):
        ing.on_message(tick(FUT, ltp, vol, 9, 15, s))
    assert ing.stats.candles_closed == 0 and ing.flush() == 0                    # still forming: nothing stored
    ing.on_message(tick(FUT, 102, 25, 9, 16, 2))
    assert ing.stats.candles_closed == 1
    assert ing.flush() == 1
    r = candles(env)[0]
    assert (r[2], r[3], r[4], r[5], r[8]) == (Decimal("100.0000"), Decimal("103.0000"), Decimal("99.0000"), Decimal("101.0000"), "FYERS_LIVE")
    assert r[7] is None                                                           # ticks carry no open interest


# -------------------------------------------------------------------- volume
def vols(env, sym=FUT):
    return [r[6] for r in candles(env) if r[0] == sym]


def test_volume_uses_the_previous_candles_cumulative_so_a_single_tick_minute_is_not_zero(env):
    ing = env.make()                                                             # started 09:00 -> day cumulative began at 0
    ing.on_message(tick(FUT, 100, 100, 9, 15, 10))                               # 100 traded by the first tick of the day
    ing.on_message(tick(FUT, 101, 130, 9, 16, 3))                                # minute 2 has ONE tick; 30 traded since
    ing.on_message(tick(FUT, 102, 190, 9, 17, 4))
    ing.on_message(tick(FUT, 102, 190, 9, 18, 1))                                # closes minute 3
    ing.flush()
    assert vols(env) == [100, 30, 60]


def test_silent_minutes_do_not_break_the_volume_baseline(env):
    ing = env.make()
    ing.on_message(tick(OPT, 50, 100, 9, 15, 10)); ing.on_message(tick(OPT, 51, 140, 9, 20, 1))      # minutes 16-19 silent
    ing.on_message(tick(OPT, 52, 150, 9, 21, 2)); ing.flush()
    assert vols(env, OPT) == [100, 40]


def test_mid_session_start_uses_the_lower_bound_never_an_inflated_volume(env):
    ing = env.make(clock=Clock(11, 0))
    ing.on_message(tick(FUT, 100, 5_000_000, 11, 2, 5)); ing.on_message(tick(FUT, 101, 5_000_040, 11, 2, 50))
    ing.on_message(tick(FUT, 101, 5_000_040, 11, 3, 1)); ing.flush()
    assert vols(env) == [40]                                                      # last-first within the minute, not 5,000,040


def test_reconnect_invalidates_the_baseline_so_missed_ticks_cannot_inflate_a_candle(env):
    ing = env.make()
    ing.on_message(tick(FUT, 100, 100, 9, 15, 10)); ing.on_message(tick(FUT, 100, 120, 9, 16, 5))     # candle 09:15 will be 100
    env.clock.set(9, 17)
    ing.on_reconnect()                                                            # (no fetcher: no backfill thread)
    ing.on_message(tick(FUT, 100, 9_000, 9, 20, 1)); ing.on_message(tick(FUT, 100, 9_005, 9, 20, 40))   # ~8,880 traded while down
    ing.on_message(tick(FUT, 100, 9_010, 9, 21, 1))                               # closes 09:20
    ing.on_message(tick(FUT, 100, 9_030, 9, 22, 1))                               # closes 09:21 (continuous again)
    ing.flush()
    by_minute = {r[1].minute: r[6] for r in candles(env) if r[0] == FUT}
    assert by_minute[15] == 100
    assert by_minute[16] == 0                                                     # straddled the disconnect: lower bound, not guessed
    assert by_minute[20] == 5                                                     # lower bound (last-first), NOT 9005-120
    assert by_minute[21] == 5                                                     # baseline trusted again: 9010 -> 9015? first tick 9010, closes at 9010 cum
    assert ing.stats.reconnects == 1


# ------------------------------------------------------------------- storage
def test_flush_writes_mysql_and_parquet_and_tracks_last_persisted(env):
    ing = env.make()
    for m in range(3):
        ing.on_message(tick(FUT, 100 + m, 10 * (m + 1), 9, 15 + m, 5)); ing.on_message(tick(OPT, 50 + m, 5 * (m + 1), 9, 15 + m, 7))
    assert ing.flush() == 4
    assert env.count() == 4
    files = env.store.list_candle_files()
    assert len(files) == 1 and files[0].endswith("date=2026-10-19.parquet")
    df = env.store.read_partition(files[0]); assert set(df["source"]) == {"FYERS_LIVE"} and len(df) == 4
    cid = env.repo.get_contract_id(FUT)
    assert ing.last_persisted_candle_at[cid] == datetime.datetime(2026, 10, 19, 9, 16, tzinfo=IST)
    assert ing.last_received_at[cid] and ing.stats.candles_persisted == 4


def test_storage_failure_keeps_candles_buffered_and_retries_without_duplicates(env, monkeypatch):
    ing = env.make()
    ing.on_message(tick(FUT, 100, 10, 9, 15, 5)); ing.on_message(tick(FUT, 101, 20, 9, 16, 5))
    real = env.repo.upsert_candles
    monkeypatch.setattr(env.repo, "upsert_candles", lambda c: (_ for _ in ()).throw(OSError("db down")))
    assert ing.flush() == 0 and ing.stats.flush_failures == 1 and ing.buffered == 1 and env.count() == 0
    monkeypatch.setattr(env.repo, "upsert_candles", real)
    assert ing.flush() == 1 and ing.buffered == 0 and env.count() == 1
    assert ing.flush() == 0


def test_parquet_failure_after_mysql_success_retries_idempotently(env, monkeypatch):
    ing = env.make()
    ing.on_message(tick(FUT, 100, 10, 9, 15, 5)); ing.on_message(tick(FUT, 101, 20, 9, 16, 5))
    real = env.store.write_candles
    monkeypatch.setattr(env.store, "write_candles", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    assert ing.flush() == 0 and env.count() == 1 and ing.buffered == 1               # MySQL has it, Parquet does not
    monkeypatch.setattr(env.store, "write_candles", real)
    assert ing.flush() == 1 and env.count() == 1 and len(env.store.list_candle_files()) == 1


def test_live_parquet_mirrors_existing_authoritative_mysql_row(env):
    from tests_support import make_candle
    cid = env.repo.get_contract_id(FUT)
    authoritative = make_candle(cid, 0, day=DAY, o="200", h="201", l="199", c="200.5",
                                v=99, source="FYERS_HISTORICAL")
    env.repo.upsert_candles([authoritative])
    ing = env.make()
    ing.on_message(tick(FUT, 100, 10, 9, 15, 5)); ing.on_message(tick(FUT, 101, 20, 9, 16, 5))
    assert ing.flush() == 1
    frame = env.store.read_partition(env.store.list_candle_files()[0])
    row = frame[frame["contract_id"] == cid].iloc[0]
    assert row["source"] == "FYERS_HISTORICAL" and float(row["open"]) == 200.0 and int(row["volume"]) == 99


def test_a_full_buffer_drops_the_oldest_and_counts_it(env, monkeypatch):
    s = dataclasses.replace(S, live=dataclasses.replace(S.live, max_buffered_candles=2))
    ing = env.make(settings=s)
    for m in range(5):
        ing.on_message(tick(FUT, 100, 10 * (m + 1), 9, 15 + m, 5))
    assert ing.buffered == 2 and ing.stats.candles_dropped_buffer_full == 2


def test_end_of_session_closes_forming_buckets_once_per_day(env):
    ing = env.make()
    ing.on_message(tick(FUT, 100, 10, 15, 38, 5)); ing.on_message(tick(FUT, 101, 14, 15, 39, 5))     # 15:39 candle still forming
    assert ing.flush() == 1
    env.clock.set(15, 50)
    assert ing.maybe_end_of_session() == 1 and env.count() == 2
    assert ing.end_of_session() == 0
    env.clock.set(15, 30)
    ing2 = env.make(); ing2.on_message(tick(FUT, 100, 10, 15, 30, 1))
    assert ing2.maybe_end_of_session() == 0                                                         # session not over yet


# ----------------------------------------------------------- reconnect backfill
def history_fetcher(responder=None):
    def ok(sym, p, n):
        a = datetime.date.fromisoformat(p["range_from"]); return {"s": "ok", "candles": [r + [1000 + i] for i, r in enumerate(rows_for(a, a))]}
    client = FakeFyers(responder or ok)
    return FnoHistoryFetcher(client, dataclasses.replace(S.history, oi_flag=True), sleep=lambda s: None), client


def test_backfill_supersedes_provisional_live_candles_with_authoritative_history(env):
    fetcher, client = history_fetcher()
    ing = env.make(fetcher=fetcher)
    ing.on_message(tick(FUT, 100, 7, 9, 15, 5)); ing.on_message(tick(FUT, 100, 9, 9, 16, 5)); ing.flush()
    out = ing.backfill(DAY)
    assert out["contracts"] == 3 and out["candles"] == 15
    r = [x for x in candles(env) if x[0] == FUT and x[1].minute == 15][0]
    assert r[8] == "FYERS_HISTORICAL" and r[7] is not None and r[6] != 7                  # history won; OI now present


def test_backfill_is_bounded_futures_first_active_only_and_aborts_on_token_expiry(env):
    expired = sample_contract("NSE:NIFTY26SEPOLD", expiry=datetime.date(2026, 10, 1))
    env.repo.upsert_contracts([expired]); oid = env.repo.get_contract_id(expired.fyers_symbol)
    contracts = env.repo.get_contracts()
    s = dataclasses.replace(S, live=dataclasses.replace(S.live, backfill_max_contracts=2))
    fetcher, client = history_fetcher()
    ing = env.make(settings=s, fetcher=fetcher, contracts=contracts)
    ing.backfill(DAY)
    called = client.symbols_called()
    assert called[0] == FUT and len(called) == 2 and "NSE:NIFTY26SEPOLD" not in called
    tok = lambda sym, p, n: {"s": "error", "code": -16, "message": "Could not authenticate"}
    f2, c2 = history_fetcher(tok)
    out = env.make(fetcher=f2).backfill(DAY)
    assert out["aborted"] and "model.fyers.auth" in out["aborted"] and len(c2.calls) == 1


def test_on_reconnect_starts_a_background_backfill_only_when_a_fetcher_exists(env):
    fetcher, client = history_fetcher()
    ing = env.make(fetcher=fetcher)
    done = threading.Event(); real = ing.backfill
    ing.backfill = lambda *a, **k: (real(*a, **k), done.set())[0]
    ing.on_reconnect()
    assert done.wait(5) and client.calls


def test_reconnect_backfill_never_closes_the_current_live_minute(env):
    env.clock.set(9,17)
    fetcher,client=history_fetcher();ing=env.make(fetcher=fetcher)
    done=threading.Event();real=ing.backfill
    ing.backfill=lambda *a,**k:(real(*a,**k),done.set())[0]
    ing.on_reconnect();assert done.wait(5)
    assert client.calls
    assert all(row[1].replace(tzinfo=IST)<datetime.datetime(2026,10,19,9,17,tzinfo=IST) for row in candles(env))


def test_concurrent_backfill_requests_are_collapsed(env):
    fetcher, _ = history_fetcher()
    ing = env.make(fetcher=fetcher)
    assert ing._backfill_running.acquire(blocking=False)
    try:
        assert ing.backfill(DAY) == {"skipped": "backfill already running"}
    finally:
        ing._backfill_running.release()


# ----------------------------------------------------------------- freshness
def test_freshness_flags_stale_futures_but_never_silent_options(env):
    ing = env.make()
    env.clock.set(10, 0)
    ing.on_message(tick(OPT, 50, 5, 10, 0, 1))
    env.clock.set(10, 30)
    f = ing.freshness()
    assert [s["symbol"] for s in f["futures_stale"]] == [FUT] and f["options_with_ticks"] == 1 and f["options_total"] == 2
    r = ing.report_freshness()
    assert r["status"] == "WARNING"
    with env.engine.connect() as c:
        row = c.execute(text("SELECT check_name, status FROM fno_data_quality_results")).fetchone()
    assert tuple(row) == ("live_freshness", "WARNING")


def test_freshness_passes_when_futures_tick_and_is_not_verified_outside_the_session(env):
    ing = env.make(); env.clock.set(10, 0)
    ing.on_message(tick(FUT, 100, 5, 10, 0, 1))
    assert ing.report_freshness()["status"] == "PASS"
    env.clock.set(20, 0)
    assert ing.report_freshness()["status"] == "NOT_VERIFIED"


# ----------------------------------------------------------------- run_live
def test_run_live_wires_ticks_flushes_on_stop_and_closes_the_session(env):
    env.clock.set(9, 15)
    ing = env.make(); stop = threading.Event(); seen = {}
    class FakeClient:
        def __init__(self, on_tick, on_reconnect, symbols):
            seen["symbols"] = symbols; self.on_tick = on_tick
        def connect_and_run(self):
            for m in range(3):
                self.on_tick(tick(FUT, 100 + m, 10 * (m + 1), 9, 15 + m, 5))
        def stop(self): seen["stopped"] = True
    fl.run_live(ing, FakeClient, stop, tick_seconds=0.05)
    assert seen["stopped"] and set(seen["symbols"]) == {FUT, OPT, OPT2}
    assert env.count(FUT) == 3                                                    # 2 closed + the forming one flushed at stop


def test_ticks_inside_the_last_session_minute_are_kept_so_the_days_final_candle_is_not_lost(env):
    """Regression: 15:39:05 was compared with 15:39:00 and wrongly dropped as 'after the session'."""
    ing = env.make()
    for s in (0, 5, 59):
        ing.on_message(tick(FUT, 100 + s / 100, 10 + s, 15, 39, s))
    assert ing.stats.ticks_outside_session == 0
    ing.on_message(tick(FUT, 100, 80, 15, 40, 1))                                 # 15:40 is after the session
    assert ing.stats.ticks_outside_session == 0


# ------------------------------------------------------------------- shutdown
def status_rows(env):
    with env.engine.connect() as c:
        return [tuple(r) for r in c.execute(text("SELECT candle_timestamp, status, volume, high FROM fno_candles ORDER BY candle_timestamp"))]


def test_shutdown_mid_minute_stores_the_forming_candle_as_open_not_closed(env):
    ing = env.make(); env.clock.set(11, 28, 57)
    ing.on_message(tick(FUT, 100, 100, 11, 28, 5)); ing.on_message(tick(FUT, 101, 110, 11, 28, 50))     # 11:28 still forming at 11:28:57
    assert ing.shutdown() == 1
    assert status_rows(env) == [(datetime.datetime(2026, 10, 19, 11, 28), "OPEN", 110, Decimal("101.0000"))]


def test_restart_in_the_same_minute_completes_the_open_candle_without_a_conflict(env):
    a = env.make(); env.clock.set(11, 28, 57)
    a.on_message(tick(FUT, 100, 100, 11, 28, 5)); a.shutdown()                                           # partial, stored OPEN
    b = env.make(clock=env.clock)                                                                        # restart, same minute
    b.on_message(tick(FUT, 100, 100, 11, 28, 5)); b.on_message(tick(FUT, 103, 140, 11, 28, 58))
    b.on_message(tick(FUT, 103, 150, 11, 29, 1))                                                         # minute ends -> CLOSED
    env.repo_result = b.flush()
    assert b.stats.candles_persisted == 1
    rows = status_rows(env)
    assert rows == [(datetime.datetime(2026, 10, 19, 11, 28), "CLOSED", rows[0][2], Decimal("103.0000"))]  # OPEN -> CLOSED, high updated


def test_shutdown_after_the_minute_has_ended_stores_closed_and_after_the_session_closes_everything(env):
    ing = env.make(); env.clock.set(11, 29, 30)
    ing.on_message(tick(FUT, 100, 100, 11, 28, 5))
    ing.shutdown()
    assert status_rows(env)[0][1] == "CLOSED"
    late = env.make(); env.clock.set(15, 50)
    late.on_message(tick(OPT, 50, 5, 15, 39, 10))
    late.shutdown()
    assert [r[1] for r in status_rows(env)] == ["CLOSED", "CLOSED"]
