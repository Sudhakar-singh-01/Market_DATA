"""Wire contract, safe pagination and real API adapter tests; no broker/network."""
import copy
import json
import httpx
import pytest
from client import (MarketDataClient,AuthenticationError,DataQualityError,FreshnessError,
                    ProtocolError,ServiceUnavailableError,MarketDataClientError)


def page(rows=None,cursor=None,coverage='COMPLETE',status='VERIFIED'):
    rows=rows if rows is not None else [candle()]
    return {'data':rows,'meta':{'returned':len(rows),'next_cursor':cursor,'segment':'CASH',
            'symbol':'NSE:SBIN-EQ','timeframe':'1m'},'quality':{'status':status,'coverage':coverage}}


def candle(minute=15,day='2026-10-16'):
    return {'candle_timestamp':f'{day}T09:{minute:02}:00+05:30','timeframe':'1m','status':'CLOSED',
            'open':'100.12345678','high':'102','low':'99','close':'101.12345678','volume':10,'oi':None}


def client(handler,**kwargs):
    return MarketDataClient(password='private-password',transport=httpx.MockTransport(handler),**kwargs)


def read(c,**kwargs): return c.get_candles('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16',**kwargs)


def test_verified_default_and_auth_only_get_preserve_values():
    def handler(req):
        assert req.method=='GET' and req.url.path=='/api/v1/candles'
        assert req.url.params['quality']=='verified'
        assert req.headers['authorization'].startswith('Basic ')
        return httpx.Response(200,json=page())
    with client(handler) as c:
        p=read(c)
        assert p['data'][0]['open']=='100.12345678' and p['data'][0]['oi'] is None


@pytest.mark.parametrize('coverage,status',[('COMPLETE','NOT_VERIFIED'),('SPARSE_UNCONFIRMED','VERIFIED'),('UNKNOWN','VERIFIED')])
def test_quality_fail_closed(coverage,status):
    with client(lambda req:httpx.Response(200,json=page(coverage=coverage,status=status))) as c:
        with pytest.raises(DataQualityError): read(c)


def test_sparse_opt_in_preserves_quality_and_raw_is_explicit():
    with client(lambda req:httpx.Response(200,json=page(coverage='SPARSE_UNCONFIRMED'))) as c:
        assert read(c,allow_sparse=True)['quality']['coverage']=='SPARSE_UNCONFIRMED'
    with client(lambda req:httpx.Response(200,json=page(status='NOT_VERIFIED'))) as c:
        assert read(c,quality='raw')['quality']['status']=='NOT_VERIFIED'


def test_iterates_cursor_without_loss_and_preserves_scope():
    requests=[]
    def handler(req):
        requests.append(dict(req.url.params))
        return httpx.Response(200,json=page([candle(15 if len(requests)==1 else 16)],'next' if len(requests)==1 else None))
    with client(handler) as c:
        rows=list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16',limit=1))
    assert len(rows)==2 and requests[1]['cursor']=='next'
    assert {p['symbol'] for p in requests}=={'NSE:SBIN-EQ'}


def test_verified_ranges_split_without_overlapping_dates():
    scopes=[]
    def handler(req):
        scopes.append((req.url.params['from'],req.url.params['to']))
        return httpx.Response(200,json=page([],coverage='NO_SESSION'))
    with client(handler) as c:
        assert list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-01-01','2026-03-05'))==[]
    assert scopes==[('2026-01-01','2026-01-31'),('2026-02-01','2026-03-03'),('2026-03-04','2026-03-05')]


def test_cursor_cycle_and_overlap_rejected():
    with client(lambda req:httpx.Response(200,json=page(cursor='repeat'))) as c:
        with pytest.raises(ProtocolError,match='cursor cycle'): list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16'))
    calls=[]
    def handler(req):
        calls.append(1); return httpx.Response(200,json=page(cursor='first' if len(calls)==1 else None))
    with client(handler) as c:
        with pytest.raises(ProtocolError,match='Overlapping'): list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16'))


@pytest.mark.parametrize('status,error',[(401,AuthenticationError),(403,AuthenticationError),(409,DataQualityError),(422,MarketDataClientError),(302,MarketDataClientError)])
def test_permanent_errors_not_retried_or_leaked(status,error):
    calls=[]
    def handler(req): calls.append(1); return httpx.Response(status,text='private-password secret-db-url',headers={'Location':'https://other.example'})
    with client(handler) as c:
        with pytest.raises(error) as caught: read(c)
    assert len(calls)==1 and 'private-password' not in str(caught.value) and caught.value.status_code==status


def test_transient_get_retries_are_bounded(monkeypatch):
    delays=[]; calls=[]
    monkeypatch.setattr('client.market_data.time.sleep',delays.append)
    def handler(req):
        calls.append(1)
        return httpx.Response(503,headers={'Retry-After':'999999'}) if len(calls)<3 else httpx.Response(200,json=page())
    with client(handler) as c: read(c)
    assert len(calls)==3 and delays==[5,5]
    calls.clear()
    def broken(req): calls.append(1); raise httpx.ReadTimeout('secret text')
    with client(broken,max_retries=1) as c:
        with pytest.raises(ServiceUnavailableError) as caught: read(c)
    assert len(calls)==2 and 'secret' not in str(caught.value)


@pytest.mark.parametrize('mutation',[
    lambda p:p['meta'].update(returned=999),lambda p:p['meta'].update(segment='FNO'),
    lambda p:p['meta'].update(symbol='OTHER'),lambda p:p['data'][0].update(candle_timestamp='2026-10-16T09:15:00'),
    lambda p:p['data'][0].update(status='OPEN'),lambda p:p['data'][0].update(timeframe='5m')])
def test_invalid_contract_rejected(mutation):
    p=page(); mutation(p)
    with client(lambda req:httpx.Response(200,json=p)) as c:
        with pytest.raises(ProtocolError): read(c)


def test_response_size_json_and_page_limit():
    with client(lambda req:httpx.Response(200,content=b'x'*101),max_response_bytes=100) as c:
        with pytest.raises(ProtocolError,match='size'): read(c)
    with client(lambda req:httpx.Response(200,content=b'no json')) as c:
        with pytest.raises(ProtocolError,match='JSON'): read(c)
    with client(lambda req:httpx.Response(200,json=page(cursor='more'))) as c:
        with pytest.raises(ProtocolError,match='Page limit'): list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-10-16','2026-10-16',max_pages=1))


def test_response_cannot_exceed_requested_page_limit():
    payload=page([candle(15),candle(16)])
    with client(lambda req:httpx.Response(200,json=payload)) as c:
        with pytest.raises(ProtocolError,match='requested page limit'):
            read(c,limit=1)


def test_latest_freshness_is_separate_from_verification():
    import datetime as dt
    now=dt.datetime.now(dt.timezone.utc)
    p=page(status='NOT_VERIFIED'); p['meta']['age_seconds']=600
    p['meta']['as_of']=now.isoformat()
    p['data'][0]['candle_timestamp']=(now-dt.timedelta(seconds=600)).isoformat()
    with client(lambda req:httpx.Response(200,json=p)) as c:
        with pytest.raises(FreshnessError): c.get_latest_candles('CASH','NSE:SBIN-EQ',max_age_seconds=60)
        assert c.get_latest_candles('CASH','NSE:SBIN-EQ',max_age_seconds=900)['quality']['status']=='NOT_VERIFIED'


@pytest.mark.parametrize('url',['http://remote.example','http://user:pw@localhost:8000','http://localhost/path','http://localhost?token=secret'])
def test_unsafe_origins_rejected(url):
    with pytest.raises(ValueError): MarketDataClient(url,password='x')


def test_latest_rejects_inconsistent_freshness_metadata():
    import datetime as dt
    p=page(status='NOT_VERIFIED')
    p['meta'].update(age_seconds=1,as_of=dt.datetime.now(dt.timezone.utc).isoformat())
    with client(lambda req:httpx.Response(200,json=p)) as c:
        with pytest.raises(FreshnessError): c.get_latest_candles('CASH','NSE:SBIN-EQ',max_age_seconds=60)


def test_cli_publishes_only_complete_exports(tmp_path,monkeypatch,capsys):
    import sys
    from client.__main__ import main
    dest=tmp_path/'candles.jsonl'
    class Fake:
        def __init__(self,*args,**kwargs): pass
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def iter_candle_pages(self,*args,**kwargs):
            yield page()
            raise DataQualityError('later scope failed')
    monkeypatch.setenv('MARKET_DATA_API_PASSWORD','test')
    monkeypatch.setattr('client.__main__.MarketDataClient',Fake)
    monkeypatch.setattr(sys,'argv',['client','--segment','CASH','--symbol','NSE:SBIN-EQ','--from-date','2026-10-16','--to-date','2026-10-16','--output',str(dest)])
    assert main()==1 and not dest.exists() and list(tmp_path.iterdir())==[]
    monkeypatch.setattr(Fake,'iter_candle_pages',lambda *a,**k:iter([page()]))
    assert main()==0
    assert json.loads(dest.read_text())['quality']['status']=='VERIFIED'
    before=dest.read_bytes()
    assert main()==1 and dest.read_bytes()==before


def test_sparse_policy_requires_real_boolean():
    with client(lambda req:httpx.Response(200,json=page(coverage='SPARSE_UNCONFIRMED'))) as c:
        with pytest.raises(ValueError,match='allow_sparse'): read(c,allow_sparse='false')


def test_regular_request_not_silently_ignored_by_old_api():
    with client(lambda req:httpx.Response(200,json=page())) as c:
        with pytest.raises(ProtocolError,match='regular-session'):read(c,session='regular')


def test_regular_raw_iterator_chunks_large_date_scope():
    requests=[]
    def handler(req):
        requests.append(dict(req.url.params));p=page(rows=[],status='NOT_VERIFIED')
        p['meta'].update(session='regular',session_filter=dict(mode='regular',excluded_rows=0,scope_rows=0))
        return httpx.Response(200,json=p)
    with client(handler) as c:
        assert list(c.iter_candles('CASH','NSE:SBIN-EQ','1m','2026-01-01','2026-02-10',quality='raw',session='regular'))==[]
    assert len(requests)==2 and requests[0]['to']=='2026-01-31' and requests[1]['from']=='2026-02-01'
