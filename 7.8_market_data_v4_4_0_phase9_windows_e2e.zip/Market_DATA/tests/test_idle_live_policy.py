import datetime as dt
import threading
from types import SimpleNamespace as NS
import pytest
from model.processing.normalizer import normalize_live_tick
from model.config.market_calendar import IST
from controller.live_controller import LiveIngestionController
from controller.fno_live import FnoLiveIngestor
from model.fno.config import load_fno_settings

BASE={'symbol':'REAL','ltp':100,'exch_feed_time':1792890000,'vol_traded_today':0}

@pytest.mark.parametrize('message',[None,{},[],{'s':'ok'}, {'symbol':'REAL','ltp':100},
    dict(BASE,ltp=0),dict(BASE,ltp=-1),dict(BASE,ltp=float('nan')),
    dict(BASE,ltp=float('inf')),dict(BASE,exch_feed_time=0),
    dict(BASE,exch_feed_time=float('inf')),dict(BASE,vol_traded_today=-1)])
def test_no_data_and_invalid_tick_never_normalizes(message):
    assert normalize_live_tick(message) is None


def test_zero_volume_is_real_data():
    assert normalize_live_tick(BASE).ltp==100


def test_empty_offmarket_cash_has_no_storage_calls():
    c=LiveIngestionController.__new__(LiveIngestionController)
    c._stop_event=threading.Event();c._stop_lock=threading.Lock()
    c._clock=lambda:dt.datetime(2026,10,25,22,tzinfo=IST)
    c._ws_client=NS(stop=lambda:None)
    c._instruments_by_symbol={'REAL':object()}
    c._candle_builder=NS(current_bucket=lambda s:None,on_tick=lambda t:pytest.fail('empty tick reached builder'))
    c._timeframe_aggregator=NS(flush_all=lambda:[])
    c._sink=NS(write_one=lambda *a:pytest.fail('empty market write'))
    for m in ({},None,{'type':'heartbeat'},dict(BASE,ltp=0)):
        c._handle_raw_message(m)
    c.stop()


def test_empty_offmarket_fno_has_no_database_parquet_or_quality_writes():
    def fail(*a,**k):pytest.fail('empty feed wrote data')
    repo=NS(upsert_candles=fail,save_quality_result=fail)
    store=NS(write_candles=fail)
    contract=NS(fyers_symbol='REAL',contract_id=1,category='FUTURES')
    c=FnoLiveIngestor(repo,store,load_fno_settings(),[contract],
        clock=lambda:dt.datetime(2026,10,25,22,tzinfo=IST))
    for m in ({},None,{'type':'heartbeat'},dict(BASE,ltp=0)):c.on_message(m)
    assert c.flush()==0
    c.report_freshness()
    assert c.shutdown()==0


def test_unknown_calendar_smart_fetch_warns_and_keeps_conflict_guard(monkeypatch):
    import controller.pipeline_service as module
    service=module.PipelineService.__new__(module.PipelineService)
    service.instruments=NS(get=lambda name:NS(fyers_symbol='NSE:SBIN-EQ'))
    service.settings=NS(storage=NS(parquet_enabled=True))
    service.reader=NS(instrument=lambda symbol:{'id':1},sql_day=lambda *a:[],parquet_day=lambda *a:([],None))
    monkeypatch.setattr(module,'calendar_verified',lambda day:False)
    args={'from':'2024-01-01','to':'2024-01-01','symbols':['SBIN']}
    result=service.smart_preview(args,now=dt.datetime(2026,10,27,tzinfo=IST))
    assert not result['blocked'] and result['warnings'] and result['items']
    # Missing calendar evidence must not bypass pre-existing storage conflicts.
    row={'candle_timestamp':dt.datetime(2024,1,1,10,tzinfo=IST),
         'open':100,'high':100,'low':100,'close':100,'volume':0,'source':'FYERS','status':'CLOSED'}
    service.reader.sql_day=lambda *a:[row]
    result=service.smart_preview(args,now=dt.datetime(2026,10,27,tzinfo=IST))
    assert result['blocked'][0]['reason'].startswith('Storage conflict')


def test_cash_reconnect_backfill_excludes_live_forming_minute(monkeypatch):
    c=LiveIngestionController.__new__(LiveIngestionController)
    now=dt.datetime(2026,10,19,10,2,30,tzinfo=IST)
    c._clock=lambda:now;c._historical_client=object()
    c._last_closed_1m_ts={'REAL':dt.datetime(2026,10,19,10,0,tzinfo=IST)}
    c._instruments_by_symbol={'REAL':object()}
    c._data_settings=NS(retry=None,validation_enabled=False)
    stored=[];fed=[]
    c._sink=NS(write_batch=lambda rows:stored.extend(rows))
    c._timeframe_aggregator=NS(on_1m_candle=lambda row:fed.append(row) or [])
    rows=[NS(timestamp=dt.datetime(2026,10,19,10,m,tzinfo=IST)) for m in (0,1,2)]
    monkeypatch.setattr('controller.live_controller.fetch_historical_1m',lambda *a,**k:rows)
    monkeypatch.setattr('controller.live_controller.normalize_historical_candle',lambda row,*a,**k:row)
    c._handle_reconnect()
    assert [row.timestamp.minute for row in stored]==[1]
    assert fed==stored and c._last_closed_1m_ts['REAL'].minute==1
