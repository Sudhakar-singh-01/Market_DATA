"""
controller/fno_live.py
Live FNO ingestion: WebSocket ticks -> 1-minute candles -> MySQL + Parquet.
Reuses Subsystem A's TRANSPORT and PURE processing (FyersWebSocketClient, normalize_live_tick,
CandleBuilder1m); never its storage. Real tick fields were confirmed by the probe
(ltp, vol_traded_today, exch_feed_time, symbol, bid/ask ...). Ticks carry NO open interest, so live
candles have oi = NULL; OI arrives later from history (which also supersedes provisional live candles).

Tick policy (each branch is counted in LiveStats and tested):
  not a tick / unknown symbol      ignored (counted)
  outside the session window       dropped (pre-open / after 15:39)
  exact duplicate of the last tick dropped
  late / out-of-order              dropped, a CLOSED candle is never reopened
  tick for a NEW minute            closes the previous candle (a tick is never a finished candle)
Volume: cumulative `vol_traded_today`; candle volume = cum(end of this minute) - cum(end of previous
candle). Without a trustworthy previous cumulative (first candle after a mid-session start or after a
reconnect, when ticks may have been missed) it falls back to A's lower bound (last - first tick of the
minute): never inflated, possibly too low, and history supersedes it.
Subscription cap: max_subscriptions (config); futures first, then nearest expiry, nearest ATM; only ACTIVE,
unexpired contracts; never "everything discovered".
Storage: closed candles are buffered and flushed in batches (MySQL first, then Parquet); on failure they stay
buffered and are retried (bounded; drops are counted).
"""
import datetime
import logging
import threading
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from model.config.market_calendar import live_session_status, session_window, calendar_metadata
from controller import fno_historical as fh
from controller import worker_lifecycle as lifecycle
from model.fno.errors import TokenExpiredError
from model.fno.history_client import OK
from model.fno.models import (FnoCandle, IST, CATEGORY_FUTURES, SOURCE_LIVE, SOURCE_HISTORICAL, STATUS_ACTIVE)
from model.fno.normalizer import normalize_history_rows
from model.processing.candle_builder import CandleBuilder1m
from model.processing.normalizer import normalize_live_tick

log = logging.getLogger("market_data.fno.live")
_Q4 = Decimal("0.0001")


@dataclass
class LiveStats:
    ticks_received: int = 0
    ticks_not_tick: int = 0
    ticks_unknown_symbol: int = 0
    ticks_outside_session: int = 0
    ticks_duplicate: int = 0
    ticks_late: int = 0
    candles_closed: int = 0
    candles_persisted: int = 0
    flush_failures: int = 0
    candles_dropped_buffer_full: int = 0
    reconnects: int = 0


def select_live_universe(contracts: list, settings, today: datetime.date, atm: dict, max_subscriptions: Optional[int] = None) -> tuple:
    u = settings.universe
    chosen = fh.select_contracts(contracts, u.underlyings, u.expiries_ahead, u.strike_window, u.include_futures,
                                 u.include_options, today, atm)
    chosen = [c for c in chosen if c.status == STATUS_ACTIVE and c.expiry >= today]

    def key(c):
        dist = 0.0 if c.category == CATEGORY_FUTURES else abs(float(c.strike) - float(atm.get(c.underlying, c.strike)))
        return (0 if c.category == CATEGORY_FUTURES else 1, c.expiry, dist, c.fyers_symbol)
    chosen.sort(key=key)
    cap = settings.subscriptions.max_subscriptions if max_subscriptions is None else max_subscriptions
    meta = {"eligible": len(chosen), "subscribed": min(len(chosen), cap), "cap": cap, "dropped_by_cap": max(0, len(chosen) - cap)}
    return chosen[:cap], meta


class FnoLiveIngestor:
    def __init__(self, repo, store, settings, contracts: list, fetcher=None, clock=lambda: datetime.datetime.now(tz=IST)):
        self.repo, self.store, self.settings, self.fetcher, self.clock = repo, store, settings, fetcher, clock
        self.contracts = list(contracts)
        self._by_symbol = {c.fyers_symbol: c for c in self.contracts}
        self.stats = LiveStats()
        self.builder = CandleBuilder1m(on_candle_closed=self._handle_closed)
        self._lock = threading.RLock()
        self._buffer: list = []
        self._last_tick: dict = {}
        self._last_cum: dict = {}                       # symbol -> (date, cumulative volume at last closed candle)
        self.last_received_at: dict = {}                # contract_id -> datetime (any accepted tick)
        self.last_persisted_candle_at: dict = {}        # contract_id -> candle timestamp (stored in MySQL)
        start = self.clock()
        self._baseline_ok_date = start.date() if start.time() <= (datetime.datetime.combine(start.date(), settings.session.open)
                                                                   + datetime.timedelta(minutes=1)).time() else None
        self._session_flushed_date = None
        self._reconnect_minute = None                  # buckets opened at/before this minute may have missed ticks
        self._stop = threading.Event()
        lifecycle.register(self._stop)
        self._backfill_running = threading.Lock()

    @property
    def symbols(self) -> list:
        return [c.fyers_symbol for c in self.contracts]

    # ------------------------------------------------------------------ ticks
    def on_message(self, message) -> None:
        if self._stop.is_set() or lifecycle.stopping():
            return
        tick = normalize_live_tick(message)
        if tick is None:
            self.stats.ticks_not_tick += 1; return
        contract = self._by_symbol.get(tick.fyers_symbol)
        if contract is None:
            self.stats.ticks_unknown_symbol += 1; return
        self.stats.ticks_received += 1
        t = tick.timestamp.astimezone(IST)
        self.last_received_at[contract.contract_id] = self.clock()
        sig = (t.timestamp(), tick.ltp, tick.volume_traded_today)
        if self._last_tick.get(tick.fyers_symbol) == sig:
            self.stats.ticks_duplicate += 1; return
        self._last_tick[tick.fyers_symbol] = sig
        cur = self.builder.current_bucket(tick.fyers_symbol)
        if cur is not None and t.replace(second=0, microsecond=0) < cur.period_start:
            self.stats.ticks_late += 1; return           # never reopen or mutate a finished/rolled-past candle
        with self._lock:
            self.builder.on_tick(tick)

    def _volume(self, bucket) -> int:
        prev = self._last_cum.get(bucket.fyers_symbol)
        day = bucket.period_start.date()
        if self._reconnect_minute is not None and bucket.period_start <= self._reconnect_minute:
            return bucket.volume                         # this minute straddled a disconnect: ticks may have been missed
        if prev is not None and prev[0] == day and bucket.volume_last >= prev[1]:
            return bucket.volume_last - prev[1]
        if prev is None and self._baseline_ok_date == day and bucket.volume_last >= 0:
            return bucket.volume_last                    # started before the open: cumulative began at 0 for the day
        return bucket.volume                             # lower bound (see module docstring)

    def _make_candle(self, bucket, status: str) -> FnoCandle:
        contract = self._by_symbol[bucket.fyers_symbol]
        q = lambda x: Decimal(str(x)).quantize(_Q4)
        return FnoCandle(contract_id=contract.contract_id, timeframe="1m", timestamp=bucket.period_start, open=q(bucket.open),
                         high=q(bucket.high), low=q(bucket.low), close=q(bucket.close), volume=self._volume(bucket),
                         source=SOURCE_LIVE, status=status, oi=None)

    def _handle_closed(self, bucket) -> None:
        candle = self._make_candle(bucket, "CLOSED")
        if self._reconnect_minute is None or bucket.period_start > self._reconnect_minute:
            self._last_cum[bucket.fyers_symbol] = (bucket.period_start.date(), bucket.volume_last)
        with self._lock:
            self._buffer.append(candle)
            self.stats.candles_closed += 1
            over = len(self._buffer) - self.settings.live.max_buffered_candles
            if over > 0:
                del self._buffer[:over]
                self.stats.candles_dropped_buffer_full += over
                log.error("Live candle buffer full: dropped %d oldest candle(s)", over)

    # --------------------------------------------------------------- storage
    def flush(self) -> int:
        if lifecycle.stopping():
            return 0
        with self._lock:
            batch, self._buffer = self._buffer, []
        if not batch:
            return 0
        try:
            self.repo.upsert_candles(batch)
            if not self.repo.verify_candles_present(batch):
                raise RuntimeError("MySQL read-back verification failed")
            accepted = self.repo.accepted_candles(batch)
            if len(accepted) != len({(c.contract_id, c.timeframe, c.naive_ist()) for c in batch}):
                raise RuntimeError("MySQL canonical read-back was incomplete")
            if self.store is not None:
                lifecycle.check()
                meta = self.repo.contract_meta({c.contract_id for c in accepted})
                self.store.write_candles(accepted, meta)
        except Exception:
            log.exception("Live flush failed; %d candle(s) kept for retry", len(batch))
            self.stats.flush_failures += 1
            with self._lock:
                self._buffer = batch + self._buffer
                over = len(self._buffer) - self.settings.live.max_buffered_candles
                if over > 0:
                    del self._buffer[:over]; self.stats.candles_dropped_buffer_full += over
            return 0
        for c in batch:
            if c.contract_id not in self.last_persisted_candle_at or c.timestamp > self.last_persisted_candle_at[c.contract_id]:
                self.last_persisted_candle_at[c.contract_id] = c.timestamp
        self.stats.candles_persisted += len(batch)
        log.info("FNO live: persisted %d candle(s) (minute %s)", len(batch), max(c.timestamp for c in batch).strftime("%H:%M"))
        return len(batch)

    def end_of_session(self) -> int:
        """Closes the still-forming buckets (no next-minute tick will come) and flushes. Once per day."""
        today = self.clock().date()
        if self._session_flushed_date == today:
            return 0
        self._session_flushed_date = today
        with self._lock:
            self.builder.flush_all()
        return self.flush()

    def shutdown(self) -> int:
        """Stop (Ctrl+C / process end). After the session: close everything (end_of_session). Mid-session: minutes that
        are still forming are stored as OPEN, NOT CLOSED, so a restart inside the same minute (OPEN -> CLOSED) or the
        history harvest can complete them without a spurious conflict. A minute that already ended is stored CLOSED."""
        self._stop.set()
        if lifecycle.stopping():
            return 0
        now = self.clock().astimezone(IST)
        with self._lock:
            for c in self.contracts:
                b = self.builder.current_bucket(c.fyers_symbol)
                if b is None:
                    continue
                over = now >= b.period_start + datetime.timedelta(minutes=1, seconds=2)
                self._buffer.append(self._make_candle(b, "CLOSED" if over else "OPEN"))
                self.stats.candles_closed += over
        return self.flush()

    def maybe_end_of_session(self) -> int:
        now = self.clock().astimezone(IST)
        window = session_window(now.date(), "FNO", session=self.settings.session)
        return self.end_of_session() if window and now >= window[1] else 0

    @property
    def buffered(self) -> int:
        return len(self._buffer)

    # ------------------------------------------------------------- freshness
    def freshness(self) -> dict:
        now = self.clock()
        stale_after = self.settings.live.stale_after_seconds
        fut = [c for c in self.contracts if c.category == CATEGORY_FUTURES]
        stale = []
        for c in fut:
            last = self.last_received_at.get(c.contract_id)
            age = None if last is None else (now - last).total_seconds()
            if age is None or age > stale_after:
                stale.append({"symbol": c.fyers_symbol, "seconds_since_last_tick": age})
        opts = [c for c in self.contracts if c.category != CATEGORY_FUTURES]
        return {"futures_total": len(fut), "futures_stale": stale,
                "options_total": len(opts), "options_with_ticks": sum(1 for c in opts if c.contract_id in self.last_received_at),
                "options_note": "silent options are normal (NOT_VERIFIED, never FAIL)",
                "contracts_with_persisted_candle": len(self.last_persisted_candle_at), "buffered_candles": self.buffered,
                "stats": vars(self.stats).copy()}

    def report_freshness(self) -> dict:
        f = self.freshness()
        in_session = live_session_status(self.clock(), "FNO", session=self.settings.session)["open"]
        status = "NOT_VERIFIED" if not in_session else ("WARNING" if f["futures_stale"] or f["stats"]["flush_failures"] else "PASS")
        if self.stats.ticks_received:
            self.repo.save_quality_result("live_freshness", "live", status, f)
        return {"status": status, **f}

    # ------------------------------------------------------------- reconnect
    def on_reconnect(self) -> None:
        """The socket dropped and came back: ticks may have been missed, so cumulative-volume baselines are no
        longer trustworthy, and active contracts are backfilled from history (in the background)."""
        if self._stop.is_set() or lifecycle.stopping():
            return
        self.stats.reconnects += 1
        self._last_cum.clear()
        self._baseline_ok_date = None
        self._reconnect_minute = self.clock().astimezone(IST).replace(second=0, microsecond=0)
        if self.fetcher is not None:
            def work():
                with lifecycle.scope(self._stop):
                    self.backfill()
            thread = threading.Thread(target=work, name="fno-backfill", daemon=True)
            lifecycle.register(self._stop, thread)
            thread.start()

    def backfill(self, day: Optional[datetime.date] = None) -> dict:
        """History for TODAY, active contracts only, futures and contracts that already ticked first, bounded and
        paced by the shared limiter (the fetcher's client is the low-priority RateLimitedClient)."""
        if not self._backfill_running.acquire(blocking=False):
            return {"skipped": "backfill already running"}
        out = {"contracts": 0, "candles": 0, "failed": 0, "aborted": None}
        try:
            day = day or self.clock().astimezone(IST).date()
            order = sorted((c for c in self.contracts if c.status == STATUS_ACTIVE and c.expiry >= day),
                           key=lambda c: (0 if c.category == CATEGORY_FUTURES else 1,
                                          0 if c.contract_id in self.last_received_at else 1, c.expiry, c.fyers_symbol))
            for c in order[: self.settings.live.backfill_max_contracts]:
                if self._stop.is_set() or lifecycle.stopping():
                    out["aborted"] = "Worker shutting down"; break
                try:
                    res = self.fetcher.fetch(c.fyers_symbol, day, day)
                except lifecycle.WorkerInterrupted as exc:
                    out["aborted"] = str(exc); break
                except TokenExpiredError as exc:
                    out["aborted"] = str(exc); break
                except Exception as exc:
                    out["failed"] += 1; log.warning("backfill %s failed: %s", c.fyers_symbol, exc); continue
                if self._stop.is_set() or lifecycle.stopping():
                    out["aborted"] = "Worker shutting down"; break
                if res.status != OK:
                    continue
                norm = normalize_history_rows(res.rows, c.contract_id, "1m", self.settings.history.oi_flag,
                                              session=self.settings.session)
                valid = norm.valid
                if self._reconnect_minute is not None and day == self._reconnect_minute.date():
                    valid = [row for row in valid if row.timestamp < self._reconnect_minute]
                if not valid:
                    continue
                try:
                    lifecycle.check()
                    if self._stop.is_set():
                        out["aborted"] = "Worker shutting down"; break
                    self.repo.upsert_candles(valid)
                    if not self.repo.verify_candles_present(valid):
                        raise RuntimeError("MySQL read-back verification failed")
                    accepted = self.repo.accepted_candles(valid)
                    if len(accepted) != len({(x.contract_id, x.timeframe, x.naive_ist()) for x in valid}):
                        raise RuntimeError("MySQL canonical read-back was incomplete")
                    if self.store is not None:
                        lifecycle.check()
                        if self._stop.is_set():
                            out["aborted"] = "Worker shutting down"; break
                        self.store.write_candles(accepted, {c.contract_id: (c.underlying, c.expiry)})
                    out["contracts"] += 1; out["candles"] += len(accepted)
                except lifecycle.WorkerInterrupted as exc:
                    out["aborted"] = str(exc); break
                except Exception:
                    out["failed"] += 1; log.exception("backfill storage failed for %s", c.fyers_symbol)
            log.info("Reconnect backfill done: %s", out)
            return out
        finally:
            self._backfill_running.release()


def run_live(ingestor: FnoLiveIngestor, client_factory, stop_event: threading.Event, tick_seconds: Optional[float] = None) -> None:
    """Runs until stop_event is set. client_factory(on_tick, on_reconnect, symbols) returns an object with
    connect_and_run() (blocking) and stop(). A timer thread flushes batches, reports freshness and closes the
    session. On stop, everything buffered is flushed."""
    lifecycle.register(stop_event)
    interval = tick_seconds or ingestor.settings.live.flush_seconds
    last_report = [0.0]

    def timer():
        import time
        while not stop_event.wait(interval):
            try:
                ingestor.flush()
                if time.monotonic() - last_report[0] > 60:
                    last_report[0] = time.monotonic(); ingestor.report_freshness()
            except Exception:
                log.exception("live timer iteration failed")
    def session_tick(message):
        if not stop_event.is_set():
            ingestor.on_message(message)
    client = client_factory(session_tick, ingestor.on_reconnect, ingestor.symbols)
    t = threading.Thread(target=timer, name="fno-live-timer", daemon=True)
    t.start()
    # connect_and_run blocks. A stop event must close the socket from another
    # thread; waiting until finally would make dashboard cancellation hang.
    def close_on_stop():
        stop_event.wait()
        try:
            client.stop()
        except Exception:
            log.exception("live socket stop failed")
    closer = threading.Thread(target=close_on_stop,name="fno-live-stop",daemon=True)
    closer.start()
    try:
        client.connect_and_run()
    finally:
        stop_event.set(); t.join(timeout=3); closer.join(timeout=3)
        try:
            client.stop()
        except Exception:
            pass
        ingestor.shutdown()

