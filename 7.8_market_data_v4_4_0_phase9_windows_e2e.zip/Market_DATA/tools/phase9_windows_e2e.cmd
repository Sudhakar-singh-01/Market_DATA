@echo off
setlocal
cd /d "%~dp0\.."
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv\Scripts\python.exe was not found. 1>&2
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.phase9_validation
exit /b %ERRORLEVEL%

