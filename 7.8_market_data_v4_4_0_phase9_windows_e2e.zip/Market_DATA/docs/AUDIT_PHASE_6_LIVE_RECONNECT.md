# Audit Phase 6 — live reconnect, restart and historical overlap

Phase 6 hardens the existing Cash/F&O live lifecycle without opening a real
provider connection.

- Every SDK reconnect re-subscribes the complete current symbol set before the
  gap callback runs.
- WebSocket stop is idempotent. A provider close exception releases the owner
  wait; a genuinely stuck SDK close keeps socket ownership active so a second
  dashboard session cannot overlap it.
- The dashboard manager waits for the controller thread and reports shutdown in
  progress instead of marking it stopped early. Restart stays blocked until the
  previous thread exits.
- Cash and F&O reconnect history excludes the reconnect minute because that
  minute may already be forming from live ticks. Completed earlier minutes keep
  the existing historical-over-provisional-live storage policy.

The transport still relies on the FYERS SDK's internal reconnect mechanism. Feed
silence alone remains informational and does not prove a disconnect. A blocked
provider close cannot be killed safely inside Python; stop remains visible and
restart remains blocked until that close returns or the process exits.

## Optional Windows check

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_websocket_idle_watchdog.py tests\test_idle_live_policy.py tests\test_market_session_policy.py tests\test_dashboard_layer.py tests\test_dual_store_consistency.py tests\fno\test_fno_live.py tests\fno\test_fno_repository.py tests\fno\test_fno_parquet.py tests\fno\test_worker_shutdown.py
```

Expected: no failures. Database-backed F&O tests require disposable test schemas;
they skip when those are not configured. Do not use production database names.
