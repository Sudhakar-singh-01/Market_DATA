# Audit Phase 7 — GET API pagination and bounded reads

Phase 7 hardens existing read paths without changing stored market data, schemas,
provider access or write workflows.

- `MarketReadService.iter_candles()` now has a bounded `max_pages` contract and
  rejects repeated continuation cursors. This prevents an invalid or replaced
  page source from keeping an in-process consumer in an unbounded loop.
- The synchronous SDK rejects any paginated response containing more rows than
  the caller's requested `limit`. The safeguard applies to instruments,
  candles, latest candles, option-chain snapshots and quality findings.
- Latest-candle `as_of` and `age_seconds` metadata now use the same clock sample,
  so freshness metadata remains internally consistent even with a custom or
  boundary-crossing clock.

Existing keyset cursors, live-view pagination semantics, verified-read checks,
31-day verified scopes, 366-day coverage bound, response-byte limit and retry
bounds remain unchanged. Pagination is still a live view rather than a database
snapshot. Verified pages intentionally recheck SQL/Parquet evidence; this phase
does not cache or weaken that check.

## Optional Windows check

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_read_api.py tests\test_client_api_integration.py tests\test_market_data_client.py tests\test_consumer_adapter.py
```

Expected: no failures. These tests use disposable SQLite/Parquet fixtures and
mock HTTP transports. They do not need FYERS credentials or a production DB.

