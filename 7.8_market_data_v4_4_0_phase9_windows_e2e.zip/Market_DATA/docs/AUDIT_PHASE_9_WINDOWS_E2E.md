# Audit Phase 9 — documentation and targeted Windows E2E

Phase 9 consolidates the safe backend acceptance checks into one Windows command.
It does not migrate, fetch, repair, reset or connect to production data.

From Windows CMD in the extracted project directory:

```bat
tools\phase9_windows_e2e.cmd
```

The wrapper requires `.venv\Scripts\python.exe` and runs three fail-fast groups:

1. Core workflows, client/consumer contracts and SMA replay.
2. FastAPI/read-service integration and HTTP client integration.
3. Backup/recovery, schema planning, cleanup, calendar/aggregation, runtime paths,
   live lifecycle and F&O repository/Parquet regressions.

The runner creates a temporary isolated `TIOS_HOME`, copies only non-secret
configuration and instrument declarations, redirects Cash/F&O data roots into
that temporary directory, and removes DB/FYERS/password variables from child test
processes. It does not print the removed values. Explicit MySQL integration test
files and all live-provider probes are excluded.

Expected on the current test set:

- core: `100 passed`
- API: `42 passed`
- operations: `386 passed, 64 skipped` when optional database integrations are
  unavailable
- combined: `528 passed, 64 skipped`, with warning counts varying by installed
  dependency versions

An exit code of zero and final JSON `"status": "PASSED"` mean all three groups
completed. A failure stops later groups and returns a nonzero code.

## Evidence and limits

Linux/Python 3.12 ran the same isolated core and operations groups successfully:
`100 passed`, then `386 passed, 64 skipped`. The API group contains 42 collected
tests but cannot execute in this cloud executor because its cross-thread TestClient
wakeup blocks; earlier native Windows execution passed the prior 40-test version.
The two added tests directly cover Phase 7 service bounds and freshness metadata.

The command is an application regression check, not production acceptance for
MySQL 8.0, real FYERS entitlement, browser interaction or Windows filesystem
locking. Those require explicitly scoped operator checks. Do not supply production
database test URLs merely to turn skips into passes.

