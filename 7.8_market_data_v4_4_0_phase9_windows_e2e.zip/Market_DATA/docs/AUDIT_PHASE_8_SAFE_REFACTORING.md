# Audit Phase 8 — safe timeframe refactoring

Phase 8 removes one confirmed server-side duplication without changing market
data behavior.

Before this phase, public read/workflow code defined the complete timeframe tuple
in `model/read_contracts.py`, while aggregation independently defined derived
timeframe names and durations in `model/processing/timeframe_aggregator.py`. The
two lists had to be edited separately when `3m` was added.

`model/timeframes.py` is now the canonical server-side definition for the base
timeframe, derived names and fixed durations. Existing imports remain compatible:

- `model.read_contracts.TIMEFRAMES` remains the same tuple and order.
- `model.processing.timeframe_aggregator.SUPPORTED_TIMEFRAMES` remains a list of
  derived timeframes.
- `_TIMEFRAME_SECONDS` remains available to its existing controller caller.

The separately installable GET SDK intentionally retains its wire-contract tuple.
The configuration YAML remains an operator-readable declaration and is still
validated independently; it is not generated or overwritten.

No aggregation formula, calendar/session rule, API field, schema, runtime path,
provider call or SQL/Parquet operation changed.

## Optional Windows check

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_aggregation_reporting.py tests\test_release4.py tests\test_unified_workflow.py tests\test_workflow_integration.py tests\test_market_data_client.py tests\test_sma.py tests\fno\test_quality_release4.py
```

Expected: 98 passed and 29 skipped when disposable F&O MySQL integration is not
configured. Dependency warning counts may vary.

