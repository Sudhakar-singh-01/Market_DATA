"""Synchronous GET-only SDK for the existing TIOS read API.

Default historical reads require verified, complete coverage. Yielded pages are
provisional until iteration completes; later pages can fail. Stream pages when
quality metadata matters. Pagination remains a live view, never a snapshot.
"""
import datetime as dt
import ipaddress
import json
import math
import os
import time
from urllib.parse import urlsplit
import httpx

IST = dt.timezone(dt.timedelta(hours=5,minutes=30))
TIMEFRAMES = ('1m','3m','5m','15m','30m','1h','1d')


class MarketDataClientError(RuntimeError):
    def __init__(self,message,status_code=None):
        super().__init__(message); self.status_code=status_code
class AuthenticationError(MarketDataClientError): pass
class DataQualityError(MarketDataClientError): pass
class FreshnessError(MarketDataClientError): pass
class ProtocolError(MarketDataClientError): pass
class ServiceUnavailableError(MarketDataClientError): pass


def _integer(value,name,maximum):
    if isinstance(value,bool) or not isinstance(value,int) or not 1<=value<=maximum:
        raise ValueError(f'{name} must be between 1 and {maximum}')
    return value


def _boolean(value,name):
    if type(value) is not bool: raise ValueError(f'{name} must be True or False')


def _segment(value):
    value=str(value).upper()
    if value not in ('CASH','FNO'): raise ValueError('segment must be CASH or FNO')
    return value


def _dates(start,end,max_days=3661):
    try: a,b=dt.date.fromisoformat(str(start)),dt.date.fromisoformat(str(end))
    except (ValueError,TypeError): raise ValueError('Use ISO dates YYYY-MM-DD') from None
    if a>b or (b-a).days>=max_days: raise ValueError(f'Use an ordered range of at most {max_days} days')
    return a,b


def _timestamp(value):
    try:
        stamp=dt.datetime.fromisoformat(value)
        if stamp.tzinfo is None or stamp.utcoffset() is None: raise ValueError()
        return stamp.astimezone(IST)
    except (TypeError,ValueError): raise ProtocolError('Candle timestamp must include a valid timezone') from None


class MarketDataClient:
    def __init__(self,base_url='http://127.0.0.1:8000',*,username='user',password,
                 timeout=30.0,max_retries=2,max_response_bytes=16*1024*1024,transport=None):
        parsed=urlsplit(base_url)
        try: local=ipaddress.ip_address(parsed.hostname or '').is_loopback
        except ValueError: local=(parsed.hostname or '').lower()=='localhost'
        if (parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or
            parsed.path not in ('','/') or parsed.query or parsed.fragment or (parsed.scheme=='http' and not local)):
            raise ValueError('Use a server origin: loopback HTTP or HTTPS, without embedded credentials/path/query')
        if username not in ('user','admin') or not isinstance(password,str) or not password:
            raise ValueError('Provide the configured user/admin password')
        if isinstance(max_retries,bool) or not isinstance(max_retries,int) or not 0<=max_retries<=3:
            raise ValueError('max_retries must be between 0 and 3')
        if isinstance(timeout,bool) or not isinstance(timeout,(int,float)) or not math.isfinite(timeout) or timeout<=0:
            raise ValueError('timeout must be a positive finite number')
        _integer(max_response_bytes,'max_response_bytes',64*1024*1024)
        self.max_retries=max_retries; self.max_response_bytes=max_response_bytes
        self._http=httpx.Client(base_url=base_url.rstrip('/')+'/api/v1/',auth=(username,password),
                               timeout=timeout,follow_redirects=False,trust_env=False,transport=transport)

    @classmethod
    def from_env(cls,**kwargs):
        """Explicit consumer config; never reads database/FYERS credentials or .env automatically."""
        return cls(base_url=os.environ.get('MARKET_DATA_API_URL','http://127.0.0.1:8000'),
                   username=os.environ.get('MARKET_DATA_API_USER','user'),
                   password=os.environ.get('MARKET_DATA_API_PASSWORD',''),**kwargs)

    def close(self): self._http.close()
    def __enter__(self): return self
    def __exit__(self,*args): self.close()

    def _get(self,path,params):
        params={k:v for k,v in params.items() if v is not None}
        for attempt in range(self.max_retries+1):
            retry_delay=min(0.25*(2**attempt),2)
            try:
                with self._http.stream('GET',path,params=params) as response:
                    status=response.status_code
                    if status in (429,502,503,504):
                        if attempt==self.max_retries:
                            raise ServiceUnavailableError('Market data service temporarily unavailable',status)
                        try:
                            seconds=float(response.headers.get('Retry-After',''))
                            if math.isfinite(seconds): retry_delay=min(max(seconds,0),5)
                        except ValueError: pass
                    elif status in (401,403):
                        raise AuthenticationError('Market data API credentials or role rejected',status)
                    elif status==409:
                        raise DataQualityError('Requested data could not be verified',status)
                    elif status!=200:
                        # Never echo server bodies, URL queries or credentials into errors.
                        raise MarketDataClientError('Market data GET request rejected',status)
                    else:
                        body=bytearray()
                        for chunk in response.iter_bytes():
                            if len(body)+len(chunk)>self.max_response_bytes:
                                raise ProtocolError('API response exceeds configured size limit')
                            body.extend(chunk)
                        try: payload=json.loads(body)
                        except (ValueError,UnicodeError): raise ProtocolError('API returned invalid JSON') from None
                        return self._page(payload)
            except (httpx.TimeoutException,httpx.NetworkError,httpx.RemoteProtocolError):
                if attempt==self.max_retries:
                    raise ServiceUnavailableError('Market data API connection failed or timed out') from None
            time.sleep(retry_delay)
        raise ServiceUnavailableError('Market data API retry limit reached')

    @staticmethod
    def _page(payload):
        if not isinstance(payload,dict): raise ProtocolError('Expected an API page object')
        rows,meta,quality=payload.get('data'),payload.get('meta'),payload.get('quality')
        if not isinstance(rows,list) or not all(isinstance(r,dict) for r in rows): raise ProtocolError('Invalid data rows')
        if not isinstance(meta,dict) or not isinstance(quality,dict): raise ProtocolError('Missing page metadata or quality')
        if type(meta.get('returned')) is not int or meta['returned']!=len(rows): raise ProtocolError('Invalid returned row count')
        if 'next_cursor' not in meta or (meta['next_cursor'] is not None and
                (not isinstance(meta['next_cursor'],str) or not 0<len(meta['next_cursor'])<=2048)):
            raise ProtocolError('Invalid next cursor')
        if quality.get('status') not in ('VERIFIED','NOT_VERIFIED'): raise ProtocolError('Invalid quality status')
        if meta['next_cursor'] is not None and not rows: raise ProtocolError('Empty page cannot advance a cursor')
        return payload

    @staticmethod
    def _scope(page,segment):
        if page['meta'].get('segment')!=segment: raise ProtocolError('API response segment differs from request')
        return page

    @staticmethod
    def _bounded(page,limit):
        if len(page['data'])>limit: raise ProtocolError('API returned more rows than the requested page limit')
        return page

    def get_instruments(self,segment='CASH',*,category=None,active_only=False,limit=100,cursor=None):
        segment=_segment(segment); _integer(limit,'limit',1000)
        _boolean(active_only,'active_only')
        return self._bounded(self._scope(self._get('instruments',dict(segment=segment,category=category,active_only=active_only,limit=limit,cursor=cursor)),segment),limit)

    def _pages(self,get_page,*,max_pages=100000):
        _integer(max_pages,'max_pages',1000000)
        cursor=None; seen=set()
        for _ in range(max_pages):
            page=get_page(cursor)
            nxt=page['meta']['next_cursor']
            if nxt is not None and nxt in seen: raise ProtocolError('API cursor cycle detected')
            yield page
            if nxt is None: return
            seen.add(nxt); cursor=nxt
        raise ProtocolError('Page limit reached; use a smaller scope or increase max_pages')

    def iter_instruments(self,segment='CASH',*,category=None,active_only=False,limit=100,max_pages=100000):
        for page in self._pages(lambda c:self.get_instruments(segment,category=category,active_only=active_only,limit=limit,cursor=c),max_pages=max_pages):
            yield from page['data']

    def get_candles(self,segment,symbol,timeframe,start,end,*,quality='verified',closed_only=True,
                    allow_sparse=False,limit=1000,cursor=None,session="all"):
        segment=_segment(segment); _integer(limit,'limit',1000)
        if timeframe not in TIMEFRAMES: raise ValueError('Unsupported timeframe')
        _boolean(closed_only,'closed_only'); _boolean(allow_sparse,'allow_sparse')
        if quality not in ('verified','raw'): raise ValueError('quality must be verified or raw')
        if quality=='verified' and not closed_only: raise ValueError('Verified reads require closed_only=True')
        if session not in ('all','regular'):raise ValueError('session must be all or regular')
        if session=='regular' and segment!='CASH':raise ValueError('session=regular supports CASH only')
        a,b=_dates(start,end,31 if quality=='verified' or session=='regular' else 3661)
        page=self._bounded(self._scope(self._get('candles',{'segment':segment,'symbol':symbol,'timeframe':timeframe,
            'from':str(a),'to':str(b),'quality':quality,'closed_only':closed_only,'limit':limit,'cursor':cursor,'session':session}),segment),limit)
        if page['meta'].get('symbol')!=symbol or page['meta'].get('timeframe')!=timeframe:
            raise ProtocolError('API candle scope differs from request')
        if session=='regular':
            info=page['meta'].get('session_filter',{})
            if page['meta'].get('session')!='regular' or info.get('mode')!='regular':
                raise ProtocolError('API did not confirm regular-session filtering')
            for key in ('excluded_rows','scope_rows'):
                value=info.get(key)
                if isinstance(value,bool) or not isinstance(value,int) or value<0:
                    raise ProtocolError('API session counts are missing or invalid')
        if quality=='verified':
            q=page['quality']
            allowed=('COMPLETE','NO_SESSION','SPARSE_UNCONFIRMED') if allow_sparse else ('COMPLETE','NO_SESSION')
            if q['status']!='VERIFIED' or q.get('coverage') not in allowed:
                raise DataQualityError('Verified coverage policy not satisfied; sparse options require explicit allow_sparse=True')
            if q.get('coverage')=='NO_SESSION' and page['data']: raise ProtocolError('No-session result contains candles')
        previous=None
        for row in page['data']:
            stamp=_timestamp(row.get('candle_timestamp'))
            if not a<=stamp.date()<=b or (previous is not None and stamp<=previous):
                raise ProtocolError('Candle timestamps are out of scope, duplicated or unordered')
            if row.get('timeframe')!=timeframe or (closed_only and row.get('status')!='CLOSED'):
                raise ProtocolError('Candle timeframe/status differs from request')
            if 'fyers_symbol' in row and row['fyers_symbol']!=symbol: raise ProtocolError('Candle symbol differs from request')
            previous=stamp
        return page

    def iter_candle_pages(self,segment,symbol,timeframe,start,end,*,quality='verified',closed_only=True,
                          allow_sparse=False,limit=1000,max_pages=100000,session="all"):
        """Split verified histories into <=31-day scopes; preserve every page's quality."""
        a,b=_dates(start,end); last=None; used=0
        _integer(max_pages,'max_pages',1000000)
        while True:
            stop=min(a+dt.timedelta(days=min(30,(b-a).days)),b) if quality=='verified' or session=='regular' else b
            for page in self._pages(lambda c:self.get_candles(segment,symbol,timeframe,str(a),str(stop),quality=quality,
                    closed_only=closed_only,allow_sparse=allow_sparse,limit=limit,cursor=c,session=session),max_pages=max_pages-used):
                used+=1
                if page['data']:
                    first=_timestamp(page['data'][0]['candle_timestamp'])
                    if last is not None and first<=last: raise ProtocolError('Overlapping or unordered candle pages')
                    last=_timestamp(page['data'][-1]['candle_timestamp'])
                yield page
            if stop==b: return
            if used>=max_pages: raise ProtocolError('Page limit reached; use a smaller scope or increase max_pages')
            a=stop+dt.timedelta(days=1)

    def iter_candles(self,*args,**kwargs):
        """Yield wire-format rows. Decimal strings and optional nulls stay unchanged."""
        for page in self.iter_candle_pages(*args,**kwargs): yield from page['data']

    def get_latest_candles(self,segment,symbol,timeframe='1m',*,limit=1,closed_only=True,max_age_seconds=None):
        segment=_segment(segment); _integer(limit,'limit',100)
        _boolean(closed_only,'closed_only')
        if timeframe not in TIMEFRAMES: raise ValueError('Unsupported timeframe')
        if max_age_seconds is not None and (isinstance(max_age_seconds,bool) or not isinstance(max_age_seconds,(int,float)) or not math.isfinite(max_age_seconds) or max_age_seconds<0):
            raise ValueError('max_age_seconds must be finite and nonnegative')
        page=self._bounded(self._scope(self._get('candles/latest',dict(segment=segment,symbol=symbol,timeframe=timeframe,limit=limit,closed_only=closed_only)),segment),limit)
        if page['meta'].get('symbol')!=symbol or page['meta'].get('timeframe')!=timeframe: raise ProtocolError('Latest candle scope differs from request')
        previous=None
        for row in page['data']:
            stamp=_timestamp(row.get('candle_timestamp'))
            if previous is not None and stamp>=previous: raise ProtocolError('Latest candles are not newest-first')
            if row.get('timeframe')!=timeframe or (closed_only and row.get('status')!='CLOSED'):
                raise ProtocolError('Latest candle timeframe/status differs from request')
            previous=stamp
        if max_age_seconds is not None:
            age=page['meta'].get('age_seconds')
            if not page['data'] or isinstance(age,bool) or not isinstance(age,(int,float)) or not math.isfinite(age) or not 0<=age<=max_age_seconds:
                raise FreshnessError('Latest stored candle is absent, stale or has an invalid age')
            as_of=_timestamp(page['meta'].get('as_of'))
            latest=_timestamp(page['data'][0]['candle_timestamp'])
            derived_age=(as_of-latest).total_seconds()
            local_now=dt.datetime.now(IST)
            if (abs(derived_age-age)>5 or not 0<=derived_age<=max_age_seconds or
                (as_of-local_now).total_seconds()>5 or not 0<=(local_now-latest).total_seconds()<=max_age_seconds):
                raise FreshnessError('Latest candle time/age is inconsistent or stale on the consumer clock')
        return page

    def get_coverage(self,segment,symbol,start,end):
        segment=_segment(segment); a,b=_dates(start,end,366)
        return self._scope(self._get('coverage',{'segment':segment,'symbol':symbol,'from':str(a),'to':str(b)}),segment)

    def get_option_chain(self,underlying,start,end,*,batch_id=None,limit=1000,cursor=None):
        a,b=_dates(start,end); _integer(limit,'limit',1000)
        return self._bounded(self._scope(self._get('fno/option-chain',{'underlying':underlying,'from':str(a),'to':str(b),
            'batch_id':batch_id,'limit':limit,'cursor':cursor}),'FNO'),limit)

    def iter_option_chain(self,underlying,start,end,*,batch_id=None,limit=1000,max_pages=100000):
        for page in self._pages(lambda c:self.get_option_chain(underlying,start,end,batch_id=batch_id,limit=limit,cursor=c),max_pages=max_pages):
            yield from page['data']

    def get_job_status(self,segment,job_id):
        segment=_segment(segment); _integer(job_id,'job_id',2**63-1)
        return self._scope(self._get(f'jobs/{job_id}',{'segment':segment}),segment)

    def get_quality_report(self,segment,*,scope=None,job_id=None,limit=100,cursor=None):
        """Requires admin credentials; historical findings are not current certification."""
        segment=_segment(segment); _integer(limit,'limit',1000)
        if job_id is not None: _integer(job_id,'job_id',2**63-1)
        return self._bounded(self._scope(self._get('quality',dict(segment=segment,scope=scope,job_id=job_id,limit=limit,cursor=cursor)),segment),limit)
