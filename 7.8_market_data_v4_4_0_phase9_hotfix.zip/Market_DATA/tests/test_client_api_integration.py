"""SDK → FastAPI → actual SQLite/Parquet reads (no network/provider)."""
import httpx
import pytest
from fastapi.testclient import TestClient
from api.app import create_app
from client import MarketDataClient,DataQualityError,AuthenticationError
from test_read_api import env,seed,fno_parquet,DAY


def sdk(env,role='user'):
    server=TestClient(create_app(env[0],auth_dependency=lambda:role))
    def handle(req):
        response=server.request(req.method,str(req.url),headers=dict(req.headers))
        return httpx.Response(response.status_code,content=response.content,headers=response.headers)
    return MarketDataClient(password='test-password',transport=httpx.MockTransport(handle))


def test_real_api_raw_pagination_and_safe_job_summary(env):
    seed(env,n=5)
    with sdk(env) as client:
        rows=list(client.iter_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),quality='raw',limit=2))
        assert len(rows)==5 and rows[0]['open']=='100.0000'
        assert list(client.iter_instruments('CASH'))[0]['fyers_symbol']=='NSE:SBIN-EQ'
        assert 'error' not in client.get_job_status('CASH',4)['data'][0]
        with pytest.raises(AuthenticationError): client.get_quality_report('CASH')


def test_real_api_fno_verified_sparse_requires_explicit_policy(env):
    fno_parquet(env,seed(env,'FNO',n=3))
    with sdk(env) as client:
        with pytest.raises(DataQualityError): list(client.iter_candles('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY)))
        pages=list(client.iter_candle_pages('FNO','NSE:TEST-OPT','1m',str(DAY),str(DAY),allow_sparse=True,limit=2))
        assert [len(p['data']) for p in pages]==[2,1]
        assert all(p['quality']['coverage']=='SPARSE_UNCONFIRMED' for p in pages)
        assert pages[0]['data'][0]['oi'] is None


def test_real_api_unverified_cash_is_not_silently_used(env):
    seed(env)
    with sdk(env) as client:
        with pytest.raises(DataQualityError): list(client.iter_candles('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY)))


def test_sdk_regular_session_verified_counts_and_pagination(env):
    from test_read_api import seed_cash_outside
    seed_cash_outside(env)
    with sdk(env) as client:
        pages=list(client.iter_candle_pages('CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),session='regular',limit=200))
        assert [len(p['data']) for p in pages]==[200,175]
        assert all(p['meta']['session_filter']['excluded_rows']==2 for p in pages)
        assert all(p['quality']['status']=='VERIFIED' for p in pages)


def test_batch_probe_checks_cash_derived_pagination_fno_and_chain_without_writes(env):
    import datetime as dt
    from types import SimpleNamespace
    from sqlalchemy import select,event
    from test_read_api import seed_cash_outside,cash_snapshot
    from controller.verification_controller import row_candles
    from model.processing.timeframe_aggregator import aggregate_1m_to_timeframe
    from client.read_probe import run_probe
    seed_cash_outside(env);table=env[2]['CASH']['candles']
    with env[1]['CASH'].begin() as conn:
        rows=[dict(r) for r in conn.execute(select(table)).mappings()]
        candles=row_candles(rows,SimpleNamespace(internal_name='SBIN',fyers_symbol='NSE:SBIN-EQ',exchange='NSE',instrument_type='EQUITY'))
        for tf in ('3m','5m','15m','30m','1h','1d'):
            bars=aggregate_1m_to_timeframe(candles,tf)
            conn.execute(table.insert(),[dict(instrument_id=1,timeframe=tf,candle_timestamp=c.timestamp.replace(tzinfo=None),
                open=c.open,high=c.high,low=c.low,close=c.close,volume=c.volume,source=c.source,status=c.status) for c in bars])
    for tf in ('3m','5m','15m','30m','1h','1d'):cash_snapshot(env,tf)
    fno_parquet(env,seed(env,'FNO',n=385))
    chain=env[2]['FNO']['fno_option_chain_snapshots']
    with env[1]['FNO'].begin() as conn:
        conn.execute(chain.insert(),dict(batch_id='batch',underlying='NIFTY',captured_at=dt.datetime.combine(DAY,dt.time(10)),contract_id=1))
    statements=[]
    for engine in env[1].values():event.listen(engine,'before_cursor_execute',lambda c,cu,s,p,ctx,m:statements.append(s))
    with sdk(env) as client:result=run_probe(client,str(DAY),'NSE:SBIN-EQ',fno_symbol='NSE:TEST-OPT',underlying='NIFTY')
    assert result['status']=='SCOPED_READ_CHECK_PASS', result['checks']
    checks={c['check']:c for c in result['checks']}
    assert len(checks)==len(result['checks'])==11
    for tf,count in [('1m',375),('3m',125),('5m',75),('15m',25),('30m',13),('1h',7),('1d',1)]:
        assert checks['cash_verified_'+tf]['rows']==count
    assert checks['cash_pagination']['pages']==2
    assert checks['fno_verified_1m']['rows']==385
    assert not any(s.lstrip().upper().startswith(('INSERT','UPDATE','DELETE','CREATE','ALTER')) for s in statements)


def test_batch_probe_records_missing_data_instead_of_claiming_success(env):
    from client.read_probe import run_probe
    with sdk(env) as client:result=run_probe(client,str(DAY),'NSE:SBIN-EQ',fno_symbol='NSE:TEST-OPT')
    assert result['status']=='FINDINGS'
    assert all(c['status']=='FINDINGS' for c in result['checks'])
    checks={c['check']:c for c in result['checks']}
    assert checks['cash_pagination']['reason']=='Fresh verified 1m baseline unavailable'


def test_batch_probe_stops_on_authentication_failure():
    from client.read_probe import run_probe
    calls=[]
    def handler(req):
        calls.append(req);return httpx.Response(401,json={'detail':'Invalid credentials'})
    with MarketDataClient(password='bad',max_retries=0,transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(AuthenticationError):run_probe(client,str(DAY),'NSE:SBIN-EQ')
    assert len(calls)==1


def test_consumer_adapter_real_verified_regular_input(env):
    from decimal import Decimal
    from client.consumer import load_verified_batch
    from test_read_api import seed_cash_outside
    seed_cash_outside(env)
    with sdk(env) as client:
        batch=load_verified_batch(client,'CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),page_size=200)
    assert len(batch.candles)==375 and batch.pages==2
    assert batch.candles[0].timestamp.strftime('%H:%M')=='09:15'
    assert batch.candles[-1].timestamp.strftime('%H:%M')=='15:29'
    assert isinstance(batch.candles[0].close,Decimal)


def test_verified_adapter_to_sma_historical_replay(env):
    from decimal import Decimal,Context,localcontext
    from client.consumer import load_verified_batch
    from indicators.sma import Sma
    from test_read_api import seed_cash_outside
    seed_cash_outside(env)
    with sdk(env) as client:
        batch=load_verified_batch(client,'CASH','NSE:SBIN-EQ','1m',str(DAY),str(DAY),page_size=200)
    calc=Sma(20)
    outputs=[calc.update(c.timestamp,c.close) for c in batch.candles]
    assert outputs[:19]==[None]*19
    assert len([x for x in outputs if x is not None])==356
    assert outputs[19].candle_timestamp.strftime('%H:%M')=='09:34'
    with localcontext(Context(prec=34)):
        for i in range(19,len(outputs)):
            assert outputs[i].value==sum((c.close for c in batch.candles[i-19:i+1]),Decimal(0))/20
