# Audit Phase 1 — durable FNO workflow jobs

Recorded: 2026-10-30.

## Scope

- A workflow publishes in-flight stage progress through `JobHandle.progress()`.
- `FnoJobStore.progress()` stores the JSON result and refreshes the heartbeat only
  while the job is `RUNNING`.
- The runner still owns final state transitions, cancellation, graceful interruption,
  explicit resume, counters, and background heartbeats.
- Workflow readiness remains point-in-time evidence and is only set after strict reads.

No schema change, provider request, production database operation, child-job model, or
cross-store atomicity claim is part of this phase.

## Regression coverage

- Deterministic runner execution records FETCH/VERIFY/READY progress before SUCCESS.
- Stage failures, cancellation, shutdown, stale recovery, explicit resume, and public
  result redaction retain their existing contracts.
- The disposable-MySQL integration checks that VERIFY progress is readable from
  `fno_ingestion_jobs` while the handler is still running, then verifies the final
  READY result survives runner completion.

Cloud result:

```text
Phase 1 core:       34 passed, 11 skipped
Caller/UI checks:   20 passed, 30 deselected
```

The skipped tests require the dedicated `market_data_test` and
`fno_market_data_test` databases. They must never point at production databases.

## Windows CMD validation

After configuring `FNO_TEST_DB_HOST`, `FNO_TEST_DB_PORT`, `FNO_TEST_DB_USER`, and
`FNO_TEST_DB_PASSWORD` for a disposable MySQL 8 test instance, run:

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_unified_workflow.py tests\fno\test_fno_jobs.py tests\fno\test_workflow_job.py tests\fno\test_worker_shutdown.py
.venv\Scripts\python.exe -m pytest -q tests\test_job_pages.py tests\test_workflow_dashboard.py tests\test_workflow_dashboard_service.py tests\test_workflow_integration.py tests\test_read_api.py -k "job or workflow"
```

Expected: the first command reports 45 passed and no skips when the disposable MySQL
fixture is available; the second reports 20 passed. If MySQL is unavailable, the first
command reports 34 passed and 11 explicit skips rather than certifying persistence.
