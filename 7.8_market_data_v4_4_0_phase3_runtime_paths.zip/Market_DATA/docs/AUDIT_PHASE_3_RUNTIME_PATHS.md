# Audit Phase 3 — permanent runtime paths

Recorded: 2026-10-31.

## Scope

- Relative `TIOS_RUNTIME_DIR` values resolve under the selected permanent profile,
  or under the extracted project root when no profile is selected.
- CLI, FNO and dashboard logging share one resolver. Relative log directories no
  longer depend on the process working directory.
- Logging and disk health checks inspect the selected runtime location and do not
  create probe directories beside an unrelated launcher.
- Configured relative CSV export directories resolve under the profile/project
  root. An explicit CLI `--output` remains operator-selected and unchanged.
- Existing profile-aware configuration, instruments, Cash/FNO roots, symbol cache,
  backups, recovery and administrative journals retain their existing contracts.

No profile initialization, runtime copy, production database access, provider call,
data relocation or configuration overwrite was performed.

## Resolution rules

1. Explicit absolute paths remain absolute.
2. Relative mutable-state paths use `TIOS_HOME` when it is configured.
3. Without `TIOS_HOME`, relative mutable-state paths use the project root derived
   from the installed code, never `os.getcwd()`.
4. A configured but missing profile still fails closed; no replacement profile or
   empty data directory is created.

## Regression coverage

Cloud baseline before changes:

```text
Runtime/profile/storage/dashboard suites: 190 passed, 3 skipped
```

Cloud result after changes:

```text
Runtime/profile/setup/storage suites:      35 passed
Dashboard/config suites without database: 159 passed, 3 explicit MySQL skips
Disposable-MariaDB path/isolation rerun:   44 passed
Total distinct tests with test database:  197 passed
```

The three initial skips required the dedicated scratch databases and passed on the
disposable MariaDB rerun. No Windows profile or operator path was accessed.

## Optional Windows CMD validation

The cloud checks are complete. Retain this for the final Windows smoke run:

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_runtime_profile.py tests\test_runtime_setup.py tests\test_storage_scope.py tests\test_backend_diagnostics.py tests\test_dashboard_layer.py tests\fno\test_fno_foundation.py tests\fno\test_fno_isolation.py
```

Expected with the disposable MySQL variables configured: 197 passed. Without that
test database, 194 tests pass and three database-backed tests skip explicitly. Never
point the fixture variables at `market_data` or `fno_market_data`.
