# Audit Phase 2 — SQL/Parquet consistency and safe gap recovery

Recorded: 2026-10-31.

## Scope

- CASH fan-out writes expose structured completed, failed and pending store state.
- CASH Parquet writes expose completed, failed and pending partition state when a
  multi-partition batch stops part-way through.
- Historical, aggregation, smart-fetch and legacy gap-fill results retain this
  recovery state for the operator instead of presenting a partial write as success.
- A gap-fill that stores raw 1m rows remains `rebuild_required`, even when the fetch
  is otherwise partial. Derived rebuilding is allowed only after raw SQL/Parquet
  parity has been restored.
- The FNO harvest stop boundary preserves a fully processed contract's verified
  checkpoint before honoring graceful cancellation or shutdown.

The existing delete-first CASH rebuild entry point remains disabled. No production
database, provider, migration, recovery plan or canonical data was changed by this
phase.

## Failure and recovery contract

MySQL and Parquet are independently durable stores and do not share a transaction.
`CrossStoreWriteError.recovery_state` therefore records:

- stores known to have completed;
- the failed store and stores not attempted;
- whether the failed store may itself have changed;
- affected Parquet partition progress when available; and
- the required scoped verification action.

This state is evidence for recovery, not an atomic commit claim. Operators must stop
writers, verify the affected SQL/Parquet scope and restore raw parity before retrying
or running a guarded derived rebuild.

## Regression coverage

Cloud baseline before changes:

```text
Deterministic storage/gap suites: 84 passed
Disposable-MariaDB parity suite: 29 passed
```

Cloud result after changes:

```text
CASH storage/gap/caller suites:              94 passed
Disposable-MariaDB FNO + CASH parity suites: 87 passed
Python compileall:                            passed
```

The MariaDB fixture used only `market_data_test` and `fno_market_data_test`. The
container was disposable and never connected to production databases.

## Optional Windows CMD validation

The cloud run is complete; these commands are retained for the final Windows smoke
run when the operator next has system access:

```bat
.venv\Scripts\python.exe -m pytest -q tests\test_dual_store_consistency.py tests\test_gapfill.py tests\test_gapfill_job.py tests\test_aggregation_reporting.py tests\test_job_manager.py tests\test_release4.py tests\test_reported_dashboard_failures.py tests\test_idle_live_policy.py tests\fno\test_worker_shutdown.py
.venv\Scripts\python.exe -m pytest -q tests\fno\test_fno_harvest.py tests\fno\test_fno_live.py tests\fno\test_quality_release4.py
```

The first command expects 94 passed. The second expects 87 passed only when the
disposable MySQL variables are configured; otherwise its database-backed tests skip
explicitly. Never point those variables at `market_data` or `fno_market_data`.
