> Current policy update: see IDLE_LIVE_POLICY.md. Manual live connections can run off-market; unknown calendar evidence is a warning for ingestion and SQL-identical restoration. Earlier session-gating descriptions below are historical.

# Permanent runtime across code upgrades

Keep code versions separate from mutable state. MySQL databases retain their
existing names, schema and rows. Do not empty either database for an upgrade.
`TIOS_HOME` is an opt-in absolute folder selected once in the Windows user
environment. Every subsequent build uses that same profile:

| Profile directory | Contents |
| --- | --- |
| config | Existing .env credentials, settings, verified calendar |
| instruments | Existing stock and index registries |
| data/cash | Cash raw and processed Parquet |
| data/fno | FNO Parquet and sidecars |
| runtime | Existing account quota/checkpoint runtime state |
| backups, recovery | Backup archives and recovery staging |
| logs | Logs and administrative operation journals |
| exports | Default CSV exports when `storage.csv.output_dir` is relative |

Missing profile/configuration fails explicitly. No empty fallback database or
data directory is substituted. Explicit storage/runtime overrides still take
precedence, so retain only intentional overrides in your process environment.
New configuration keys introduced by future releases may require a reviewed
profile update; new code does not silently overwrite your settings.

Relative runtime settings are anchored to this profile, independent of the
terminal or launcher working directory. This includes `TIOS_RUNTIME_DIR`, log
directories, symbol cache and default CSV export directories. Absolute overrides
remain explicit absolute paths. When `TIOS_HOME` is unset, the same relative
defaults are anchored to the extracted code folder rather than the current
working directory.

## One-time setup on this installation

Stop all dashboards, live feeds, workers and schema/cleanup tasks. Use the new
build's folder containing `main.py`. Leave `TIOS_HOME` unset for the initial
copy so authentication uses that build's existing `config/.env`. Preserve your
current .env and custom configuration when extracting code.

The following source directories come from the supplied directory listings.
Their complete SQL/Parquet parity has not been verified. The new target must
not exist; its parent drive/folder must exist and have enough space.

Preview (does not copy or change data):

```bat
python -m controller.runtime_cli init --home "F:/TIOS_Runtime" --cash-source "F:/_software/_New_Trading_Tool/code/!!project/5.0_market_data_v4_4_0_step9/data" --fno-source "F:/_software/_New_Trading_Tool/code/!!project/5.1_market_data_v4_4_0_step9_hotfix1/data/fno"
```

Copy after reviewing the preview and stopping all writers:

```bat
python -m controller.runtime_cli init --home "F:/TIOS_Runtime" --cash-source "F:/_software/_New_Trading_Tool/code/!!project/5.0_market_data_v4_4_0_step9/data" --fno-source "F:/_software/_New_Trading_Tool/code/!!project/5.1_market_data_v4_4_0_step9_hotfix1/data/fno" --apply --writers-stopped
```

Enter the existing application administrator password. This copies configuration,
instruments, both source trees and any runtime/backups/recovery/logs in the current
code folder. It excludes nested FNO data from Cash inventory, rejects links and
overlaps, checks copied file hashes and detects source changes. It never deletes
sources, creates/empties a database, runs SQL repair or overwrites an existing
profile. Required target path settings change only in the copied configuration.
Old version folders outside the chosen sources/current project are not scanned
or merged. Retain old folders until verification and backup are complete.

Only after `status: INITIALIZED`, enable the profile in Windows CMD:

```bat
setx TIOS_HOME "F:\TIOS_Runtime"
set "TIOS_HOME=F:\TIOS_Runtime"
python -m controller.diagnostics_cli storage --offline
python -m controller.diagnostics_cli storage
python -m controller.diagnostics_cli fetch-preview --segment CASH --from 2026-10-19 --to 2026-10-23 --symbols NIFTYBANK SBIN
```

`setx` persists the variable for future terminals; `set` enables it in this CMD
session. In PowerShell use `$env:TIOS_HOME='F:\TIOS_Runtime'` for the current
session. Restart already-open launchers/terminals to inherit the new setting.
Future code updates only need extraction and their dependency installation;
do not reinitialize, recopy data or reset MySQL. Run from each new code folder.

## Historical versus live policy

Historical fetch can be invoked at night, on Saturday/Sunday and on holidays.
Current market-open status never gates historical requests. Requested past
trading dates, provider history availability, authentication, quota, network,
calendar verification and storage consistency still apply. A closed target date
normally has no expected candles; verified special sessions are considered by
the calendar. No holiday candles or missing data are fabricated. Existing FNO
historical normalization/session settings are preserved.

Live ingestion only opens its transport during a verified open session and
stops at session close. Unknown calendar evidence produces an explicit reason.
Verified special sessions override normal closure. A closed-market live start
does not queue an automatic next-open start; use the existing scheduler or start
it during the next session. This is not an automatic 24/7 historical scheduler:
it permits user-initiated historical jobs regardless of invocation time.

## Checks

```bat
python -m pip install -r requirements-api.txt pytest
python -m pytest -q tests/test_runtime_profile.py tests/test_runtime_setup.py tests/test_market_session_policy.py
```

Copy verification proves copied bytes, not market-data correctness. Existing
missing/invalid candles and historical PARTIAL jobs remain visible and need
separate scoped review. No live Windows/MySQL/FYERS test was performed in the
build environment.
