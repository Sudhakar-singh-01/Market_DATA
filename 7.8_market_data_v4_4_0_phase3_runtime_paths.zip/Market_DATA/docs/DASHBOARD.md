# Market Data Layer Dashboard

A Streamlit control layer **on top of** the existing market-data engine. It does not replace or
duplicate the engine: every operation calls the project's existing controllers/storage/repository.

Run from the project root so the relative `ui/dashboard.py` command locates the
script. Runtime config, data, logs, cache and default exports resolve through
`TIOS_HOME` when configured and do not depend on the launch directory:

```
pip install -r requirements.txt
python tools/hash_password.py "your-user-password"    # -> USER_PASSWORD_HASH in config/.env
python tools/hash_password.py "your-admin-password"   # -> ADMIN_PASSWORD_HASH in config/.env
streamlit run ui/dashboard.py
```

`config/.env` also accepts `SESSION_TIMEOUT_MINUTES` (default 480). See `config/.env.example`.
The audit table is created from **Admin: Audit Log -> "Create audit_log table now"**, or by running
`database/add_audit_log.sql` (idempotent).

## 1. Architecture

Streamlit is a Python process, so pages are the UI *and* the entry point to the backend. The
project had no React/FastAPI, so none was introduced. Responsibilities are still separated:

| Layer | Where | Rule |
|---|---|---|
| Pages (display, inputs, triggering) | `ui/pages/*.py`, `ui/dashboard.py` | No business logic; call controllers/repository |
| Shared wiring | `ui/engine_bootstrap.py` | Config, sinks, checkpoint store, repository (cached) |
| Auth | `ui/auth.py`, `ui/password_hashing.py` | Gate every page |
| Admin data ops | `ui/admin_data_access.py` | Only place that writes/deletes rows |
| Audit | `ui/audit_log.py` | Insert + select only |
| File access | `ui/file_explorer.py` | Whitelist, read-only |
| Read-only inspection | `ui/table_inspector.py`, `ui/data_access.py` | Fixed-shape, parameterised SQL |
| Engine (unchanged) | `controller/*`, `model/*` | FYERS auth, ingestion, aggregation, storage, repository |

**Database access:** pages never open ad-hoc connections; they use SQLAlchemy engines from
`ui/engine_bootstrap.py` / `ui/data_access.py`. There is **no SQL console**. Every query is fixed-shape
and parameterised; table names come from the `KNOWN_TABLES` allow-list.

## 2. Authentication and permissions

* Two roles, **user** and **admin** (admin also satisfies any user check).
* Passwords are stored only as PBKDF2-SHA256 hashes (200k iterations, per-hash salt) in `config/.env`.
* Enforced **on the server side of each page**: `require_auth(...)` is the first executed statement,
  before any config load or data access (verified by `tests/test_dashboard_layer.py`, including running
  every page through Streamlit's `AppTest`).
* Session expires after `SESSION_TIMEOUT_MINUTES`. Logout clears the role.
* 5 wrong passwords lock that browser session for 5 minutes.
* LOGIN / LOGOUT are audit-logged (if the audit table exists).

**Access matrix**

| Role | Pages |
|---|---|
| user + admin | Dashboard (Overview, MySQL Tables, Files & Exports, Run Pipeline, Live), Live Market, Data Explorer, Historical Data, Aggregation, Data Flow, Data Quality, Storage, Logs, API Monitor |
| admin only | Admin (overview + CRUD), Admin Database, Files, Jobs, Checkpoints, Bulk Delete, Operations Center, Audit Log, Security |

Streamlit lists every page in the sidebar, but an admin page shows only the login form to a `user` session.

## 3. Pages and the backend each one uses

| Page | Backend it calls |
|---|---|
| Dashboard / Overview | `controller/health_controller.py`, `ui/data_access.live_run_manager`, `ingestion_jobs`, `candles` |
| Live Market | `LiveIngestionController.latest_ticks()` (real FYERS ticks), stored candles, plotly candlestick |
| Data Explorer | `ui/table_inspector.py`, `fetch_table`, `fetch_candles_filtered`; CSV/JSON export (audit-logged) |
| Historical Data | `controller/historical_controller.run_historical_ingestion`, `get_authenticated_client` (auth flow untouched) |
| Aggregation | `controller/timeframe_controller.run_timeframe_generation` |
| Data Flow | Real stage status from health checks and the live session; not-tracked stages say so |
| Data Quality | `model/processing/gap_detector.find_gaps_1m`, `validator.validate_candles`, DB duplicate/job/freshness queries |
| Storage | `information_schema` sizes, `data/**/*.parquet` scan, health checks |
| Logs | The project's rotating log file (`model/logging_setup.py`, wired via `ui/logging_bootstrap.py`) |
| API Monitor | `model/repository.py -> MarketDataRepository` (see 4) |
| Admin / CRUD | `ui/admin_data_access.py` (every action audit-logged) |
| Admin Files | `ui/file_explorer.py` |
| Jobs / Checkpoints | `ingestion_jobs`, `checkpoints`, `MySQLCheckpointStore`, historical controller (resume) |
| Bulk Delete | `admin_data_access.count_candles_filtered` / `delete_candles_filtered` |
| Operations Center | `LiveRunManager` (start/stop/restart), health checks, links to the job pages |
| Audit Log | `ui/audit_log.py` |

## 4. API Monitor (the project's real API)

The project's read API is `MarketDataRepository` (`model/repository.py`): `get_candles`, `get_candles_df`,
`get_candles_multi`, `get_latest_candle`, `list_instruments`, `has_storage_backend`. The page discovers
public `get_*/list_*/has_*` methods by introspection (read-only by construction; new getters appear automatically).

* **Endpoints tab:** category, parameters, description, status, requests, errors, average ms, records, last request.
* **Inspector tab:** choose a method, fill parameters (dropdowns/calendars), *Send request*; shows the request
  (method, endpoint, params, timestamp) and response (status, time, record count) with **JSON** and **Table** views.
* These are in-process Python calls, not HTTP: HTTP headers/status are shown as N/A.
* Counters cover calls made through this page in this dashboard process. Other modules calling the repository
  from their own processes are not instrumented, so per-consumer traffic is **NOT AVAILABLE**.

## 5. Bulk operations

**Bulk Delete (candles)** - required flow: filters (instrument **required**; timeframe, status, source, date
range optional) -> **PREVIEW DELETE** (exact row count from the *same* WHERE builder used by the delete) ->
confirmation panel -> type `DELETE` **and re-enter the admin password** -> delete -> audit record -> result.
Wrong password = nothing deleted, attempt audited as failed. There is no one-click bulk delete anywhere.

**Checkpoint reset** - shows exactly which checkpoint is affected, requires a confirm step, audit-logged
as `RESET_CHECKPOINT`. **Resume** re-runs the existing historical controller from `synced_through_date + 1`.

## 6. Audit log

Table `audit_log` (append-only: only INSERT/SELECT in code). Columns: time, actor role, action, target,
parameters (JSON), records affected, result, error. Actions: `LOGIN`, `LOGOUT`, `BULK_DELETE`,
`RESET_CHECKPOINT`, `START_HISTORICAL_FETCH`, `START_AGGREGATION`, `EXPORT`, `SYSTEM_OPERATION`.
Passwords, tokens and secrets are never passed in. Audit failures never block the operation itself.

## 7. File access restrictions

Read-only viewer limited to `config, database, model, controller, view, ui, data, logs, tests, instruments`.
Blocked: path traversal (`..`), absolute paths, symlink escapes, files outside those folders, non-text
extensions, and credential files by **name** (`.env*`, `*secret*`, `*token*`, `*password*`, `*.pem`, `*.key` ...),
which are also hidden from listings. Nothing can be executed, edited, or deleted from the UI.

## 8. Data flow

```
FYERS -> FYERS client (auth/historical/websocket) -> fetch / live ticks -> validation -> normalization
      -> 1-minute canonical candles -> MySQL and/or Parquet -> aggregation (5m..1D)
      -> MarketDataRepository (read API) -> consumers (not yet built; traffic not tracked)
```

Historical and live are separate flows in the same layer. Checkpoints track historical sync;
`ingestion_jobs` records operations.

## 9. Testing

```
pip install pytest
pytest tests -q          # 94 tests
```

Covers: hashing, role gates, session expiry, lockout, "user password never grants admin", every page's auth
gate (static + real `AppTest` execution for unauthenticated and `user` sessions on admin pages), file explorer
restrictions, bulk-delete preview == delete for 7 filter combinations, live restart race, API discovery and
serialisation, log parsing, audit append-only behaviour.
**Not covered by automated tests:** a real MySQL/FYERS session (destructive flows were tested against sqlite),
and clicking through the rendered UI.

## 10. Error handling (Section 33)

`ui/error_display.py` renders: which operation/resource failed, backend detail for admins only (users
see a generic message + a link to Logs), a **Retry** button, and a link to the Logs page. Wired into the
highest-value operational flows: Historical Data, Aggregation, Bulk Delete, Checkpoint Resume, Data
Explorer loads. Not applied to every small CRUD button in `1_Admin.py` -- stated plainly rather than
silently inconsistent.

## 11. Bulk Validation and Data Cleanup (Section 27)

`ui/pages/28_Admin_Data_Operations.py`, admin-only:

* **Bulk Validation** (read-only): pick instruments/timeframe/date range -> ESTIMATE (real count from
  storage) -> RUN VALIDATION -> per-instrument progress bar -> result table (valid/invalid/warnings) +
  expandable invalid-candle details. Uses the existing `model/processing/validator.validate_candles`,
  no second validation implementation.
* **Data Cleanup**: removes *stale OPEN* candles -- rows left behind when a live session was interrupted
  before a candle closed (the Ctrl+C/shutdown-race issues fixed elsewhere in this project are exactly why
  these can appear). Scope (instrument/timeframe optional, age threshold) -> ESTIMATE -> confirm panel ->
  type `CLEANUP` -> delete -> audit record. CLOSED candles are never touched; verified by test.

The other items in Section 27's list already have dedicated flows and are linked from Operations Center
rather than duplicated: bulk export (Data Explorer), bulk aggregation (Aggregation page), re-fetch
(Historical Data), checkpoint reset (Admin: Checkpoints), storage verification (Operations Center).

## 12. Audit log: IP and session (Section 29)

`audit_log` now has `ip_address` and `session_id` columns, auto-filled by `record_action()` from
`ui/session_context.py` (`st.context.ip_address` and a per-browser-session UUID) -- existing call sites
needed no changes. `ensure_audit_table()` (the "Create table" button) adds these columns automatically if
the table already existed from before this change.

Honest limits: `ip_address` is the direct TCP peer -- behind a reverse proxy without forwarded-IP
configuration it will be the proxy's address, not the end user's. `session_id` identifies a browser tab's
session for correlation, not an individual person -- this project still has one shared password per role.

## 13. Live auto-refresh, instrument search, logs-to-DB, text wrap, calendar "Today"

* **Live Market auto-refresh**: the top table on `2_Live_Market.py` is an `@st.fragment(run_every=3)` --
  it re-executes and re-fetches `latest_ticks()` every 3 seconds on its own, without reloading the whole
  page (so the Instrument Detail search/selection below it isn't reset every few seconds).
* **Instrument search works with no live session**: previously the whole page (including historical-data
  lookup) was blocked behind `st.stop()` if live wasn't running. Fixed -- only the top table is gated on
  live; the search box below works for any configured instrument's stored data regardless.
* **No temporary "one day" database is needed** for either of the above. Live prices live in an in-memory
  cache (`LiveIngestionController.latest_ticks()`), not a database at all -- it's naturally empty at the
  start of each live session and repopulates as ticks arrive, which already gives the "resets daily"
  behaviour being asked for, with no extra storage layer.
* **Logs also stored in MySQL**: `error_logs` table (WARNING/ERROR/CRITICAL only -- mirroring INFO/DEBUG
  would put a DB write on the live-tick hot path). Wired via `ui/db_log_handler.py`, a standard
  `logging.Handler` attached to the root logger in `ui/logging_bootstrap.py`. Logs page has a
  "Database -- WARNING and above" tab with its own filters; auto-creates the table (or via
  `database/add_error_logs.sql`).
* **Text wrapping**: `ui/table_display.py`'s `wrapped_dataframe()` (wide `TextColumn` + taller
  `row_height`) applied to Logs, Audit Log, Jobs, and Data Explorer's long-text columns.
* **Calendar "Today" button**: every `date_field()` (`ui/date_inputs.py`) now has a Today button beside
  it that snaps the picker back to today's date.

## 14. Search ANY NSE/BSE stock or index (not just configured instruments)

On `2_Live_Market.py`, "Instrument detail" has a mode switch:

* **Configured instruments** -- the original behaviour, searches `instruments/stocks.yaml` + `indices.yaml`.
* **Search NSE / BSE (any symbol)** -- looks up ANY symbol, in the instrument files or not:
  1. Optionally browse by typing a name/symbol; matches come from FYERS's public symbol master files
     (`model/fyers/symbol_master.py`, downloaded from `public.fyers.in`, cached ~1 day, NSE+BSE cash-market
     segment -- covers stocks and indices). A "Refresh" button force-redownloads.
  2. Or type an exact FYERS symbol directly (e.g. `NSE:TCS-EQ`) -- always available, doesn't depend on the
     symbol master having downloaded successfully.
  3. Either way, a live quote (LTP, change, change%, OHLC, volume, name) is fetched via FYERS's `quotes()`
     REST call (`model/fyers/quotes.py`), using the **existing** `get_authenticated_client()` -- no new auth
     flow (Section 41).
  4. If the symbol isn't already configured, an **admin-only** "Add to Instruments" form appends it to
     `stocks.yaml`/`indices.yaml` (`ui/instrument_editor.py`) -- append-only, re-validates the file still
     parses before writing, preserves the file's header comment, and clears the config cache so it's picked
     up immediately without restarting. Audited as `SYSTEM_OPERATION`.

**Important caveat, stated plainly:** `model/fyers/symbol_master.py` and `model/fyers/quotes.py` are written
against FYERS's *publicly documented* response shapes (confirmed via FYERS's own community/support posts),
but could not be exercised against a live FYERS account or the real `public.fyers.in` endpoints from the
sandbox this was built in (no network path to FYERS there). Parsing is deliberately defensive -- unexpected
or missing fields degrade to "N/A" or a clear error rather than crashing, and automated tests cover the
documented shapes plus error paths (bad response, network failure, symbol not found) -- but **please test
the "Search NSE / BSE" mode against your real account once**, and if a field shows "N/A" that shouldn't, or
a symbol search returns nothing even after Refresh, report the exact behaviour (or a sample raw API
response) so the key-name list can be corrected precisely.

## 15. UI polish fixes (login Enter-to-submit, Today alignment, table row-height, text truncation, search auto-download)

* **Login now submits on Enter**: wrapped in `st.form()` + `st.form_submit_button()` instead of a bare
  `text_input` + `st.button` (which only Streamlit forms make Enter-submit).
* **Today button alignment**: the spacer that vertically aligns it with the date box was a bare
  `st.write("")`, which doesn't match the date_input's actual label-row height. Replaced with a
  fixed-height spacer that matches it.
* **Tables looking sparse/oddly tall**: `wrapped_dataframe()` was applying wide-column + tall-row
  styling to EVERY text column passed to it, including short ones (`id`, `internal_name`, `exchange`).
  It now only widens/tallens columns whose actual content is long enough to need it (>25 chars), so a
  table of short values renders at Streamlit's normal compact row height.
* **Timestamps/source text getting cut off with "..."**: `st.metric()` truncates long values and never
  wraps. The Live Market "Latest data information" and ad-hoc quote "Name" fields were using `st.metric()`
  for genuinely long values (full timestamp, source string, company name) -- switched to `st.write()`,
  which shows the full text. Also fixed: "Source" was a hardcoded placeholder string instead of the
  candle's real `source`/`status` fields.
* **NSE/BSE search returning nothing**: if neither symbol-master file had ever been downloaded (first use),
  search silently returned zero matches with an easy-to-miss hint to click "Refresh". The first search now
  auto-downloads the relevant exchange's file inline (with a spinner), and surfaces a clear error if the
  download itself fails rather than silently retrying forever. Also added a browser-like `User-Agent`
  header to the download request (some servers reject the default Python one).
* **API Monitor -- see what every method returns, not just one at a time**: Endpoints tab now has
  "Preview all methods now", which calls every discovered method once with sensible defaults (first
  configured instrument, last 7 days) and shows each one's real input/output in an expander -- answers
  "what data does this store/send" for the whole API at a glance.

**On "live session stopping when the browser tab closes":** verified this should NOT happen --
`live_run_manager` (`ui/data_access.py`) is a module-level singleton, not stored in `st.session_state`, so
it lives in the `streamlit run` server process's memory and is completely independent of any browser
connection; closing the tab has no effect on it (confirmed no `session_state` reference to live state
anywhere in the codebase). If it's still stopping, the likely cause is something other than the browser
tab -- e.g. the terminal/SSH session running `streamlit run` itself being closed (which *does* kill the
process, same as any other long-running script), or a hosting platform that recycles the process when idle.
Please confirm which of those matches what you're seeing so this can be pinned down precisely.

## 16. Known limitations

* One shared password per role: the audit log records the role, not a named person.
* Lockout state is per browser session (Streamlit `session_state`), not a durable rate limit.
* Data Explorer runs a server-side filtered query capped at 5000 rows, then paginates those rows in the page.
* Job ID appears in Logs only when a log line contains one (the engine rarely logs it).
* Default Streamlit styling; no custom theme, toasts, or modal dialogs (confirmations are inline steps).
* No FastAPI/HTTP layer exists, so HTTP-level API metrics do not exist.
* Retry/log-link error handling is wired into the main operational flows, not every CRUD button.

## 11. Changes to existing files

Nothing was removed or renamed. `model/fyers/auth.py`, the historical/timeframe controllers,
`model/storage/mysql.py`, `model/repository.py` and `model/processing/*` are untouched.

| File | Change |
|---|---|
| `controller/live_controller.py` | Signal/stdin shutdown only on the main thread (dashboard runs it on a background thread); `latest_ticks()` cache |
| `model/fyers/websocket.py` | `connect_and_run()` now blocks; bounded `stop()`; heartbeat log (the FYERS SDK's `keep_running()` returns immediately) |
| `model/storage/parquet.py` | Import `pyarrow.pandas_compat` at load (fixes "can't register atexit after shutdown") |
| `database/schema.sql` | Appended `audit_log` and `error_logs` tables (only schema changes) |
| `requirements.txt` | Added `plotly`, `requests` |
| `ui/*` | Dashboard code (auth, pages, helpers) |
| `model/fyers/quotes.py`, `model/fyers/symbol_master.py` | New: ad-hoc quote lookup + NSE/BSE symbol search for ANY symbol (Section 14). Reuses the existing authenticated client; no new auth flow |
| `instruments/stocks.yaml`, `instruments/indices.yaml` | Only ever appended to (never rewritten/reformatted) by `ui/instrument_editor.py`, when an admin explicitly clicks "Add to Instruments" |
