"""Orchestration tests for the gap-fill job and the auto filler (no DB / FYERS: collaborators are faked)."""
import time
import types

import controller.gapfill_controller as gc
import controller.historical_controller as hc
import controller.timeframe_controller as tc
import model.fyers.auth as fauth
import ui.job_manager as jm
from controller.gapfill_controller import FillTarget
from model.fyers.historical import NullCheckpointStore


class Inst:
    def __init__(self, n):
        self.internal_name, self.fyers_symbol = n, f"NSE:{n}-EQ"


class Registry:
    def __init__(self, names):
        self._i = {n: Inst(n) for n in names}
    def get(self, n): return self._i[n]
    def active_instruments(self): return list(self._i.values())


def make_ctx(names=("AAA", "BBB")):
    tfs = [types.SimpleNamespace(name="5m"), types.SimpleNamespace(name="15m")]
    return jm.JobContext(
        env=types.SimpleNamespace(fyers=None),
        data_settings=types.SimpleNamespace(storage=types.SimpleNamespace(mysql_enabled=True, parquet_enabled=False)),
        timeframe_settings=types.SimpleNamespace(derived_timeframes=tfs),
        instruments=Registry(names))


def target(n, **kw):
    return FillTarget(n, f"NSE:{n}-EQ", "2026-10-09", "2026-10-09", "internal", 3, 1, "x", **kw)


def patch_common(monkeypatch, calls, statuses):
    monkeypatch.setattr(jm, "_engine", lambda ctx: "ENGINE")
    monkeypatch.setattr(jm, "_build_sink", lambda ctx, *a, **k: "SINK")
    monkeypatch.setattr(jm, "_recorder", lambda ctx: "REC")
    monkeypatch.setattr(jm, "_remaining_missing", lambda e, i, f, t: 0)
    monkeypatch.setattr(fauth, "get_authenticated_client", lambda creds: "CLIENT")

    def fake_process(client, inst, f, t, ds, reg, sink, ckpt, timeframe_settings=None, job_recorder=None, job_type="historical"):
        calls.append(("fetch", inst.internal_name, type(ckpt).__name__, timeframe_settings, job_type))
        st = statuses[inst.internal_name]
        return types.SimpleNamespace(status=st, raw_count=3 if st == "success" else 0, error="boom" if st == "failed" else None)
    monkeypatch.setattr(hc, "process_instrument", fake_process)


def run(job_params, ctx):
    job = jm.Job(id=1, kind="gapfill", label="t", params=job_params)
    jm.run_gapfill_job(job, ctx)
    return job


def test_gapfill_repairs_raw_data_without_delete_first_rebuild(monkeypatch):
    calls = []
    patch_common(monkeypatch, calls, {"AAA": "success", "BBB": "success"})
    job = run({"targets": [target("AAA")]}, make_ctx())
    kinds = [c[0] for c in calls]
    assert kinds == ["fetch"]
    assert calls[0][2] == "NullCheckpointStore" and calls[0][3] is None and calls[0][4] == "gapfill"
    assert job.results[0]["Status"] == "rebuild_required" and job.results[0]["Still missing"] == 0
    assert "guarded cash gap recovery" in job.results[0]["Next action"]
    assert job.done == 1 and job.final_status == "partial"


def test_no_data_does_not_touch_derived(monkeypatch):
    calls = []
    patch_common(monkeypatch, calls, {"AAA": "no_data", "BBB": "success"})
    job = run({"targets": [target("AAA")]}, make_ctx())
    assert [c[0] for c in calls] == ["fetch"]                                   # holiday / nothing returned: leave data alone
    assert job.results[0]["Status"] == "no_data"


def test_failure_is_partial_and_continues(monkeypatch):
    calls = []
    patch_common(monkeypatch, calls, {"AAA": "failed", "BBB": "success"})
    job = run({"targets": [target("AAA"), target("BBB")]}, make_ctx())
    assert job.final_status == "partial" and job.done == 2
    assert job.results[0]["Error"] == "boom" and [c[1] for c in calls] == ["AAA", "BBB"]


def test_partial_store_failure_requires_parity_recovery_before_rebuild(monkeypatch):
    recovery = {'status':'PARTIAL','atomic':False,'completed_stores':['MySQLCandleSink'],
                'failed_store':'ParquetCandleSink','pending_stores':[],'rows':3}
    monkeypatch.setattr(jm, "_engine", lambda ctx: "ENGINE")
    monkeypatch.setattr(jm, "_build_sink", lambda ctx, *a, **k: object())
    monkeypatch.setattr(jm, "_recorder", lambda ctx: "REC")
    monkeypatch.setattr(fauth, "get_authenticated_client", lambda creds: "CLIENT")
    monkeypatch.setattr(hc, "process_instrument", lambda *a, **k: types.SimpleNamespace(
        status='failed', raw_count=3, error='cross-store write incomplete', storage_recovery=recovery))
    job = run({"targets": [target("AAA")]}, make_ctx())
    row = job.results[0]
    assert row['Status'] == 'storage_recovery_required'
    assert row['Storage recovery'] == recovery
    assert 'verify the affected SQL/Parquet scope' in row['Next action']
    assert 'derived rebuild only after raw-store parity' in row['Next action']
    assert job.final_status == 'partial'


def test_partial_fetch_that_stored_raw_rows_still_requires_derived_rebuild(monkeypatch):
    monkeypatch.setattr(jm, "_engine", lambda ctx: "ENGINE")
    monkeypatch.setattr(jm, "_build_sink", lambda ctx, *a, **k: object())
    monkeypatch.setattr(jm, "_recorder", lambda ctx: "REC")
    monkeypatch.setattr(jm, "_remaining_missing", lambda *a: 2)
    monkeypatch.setattr(fauth, "get_authenticated_client", lambda creds: "CLIENT")
    monkeypatch.setattr(hc, "process_instrument", lambda *a, **k: types.SimpleNamespace(
        status='partial', raw_count=3, stored_count=2, error=None, storage_recovery=None))
    job = run({"targets": [target("AAA")]}, make_ctx())
    row = job.results[0]
    assert row['Status'] == 'rebuild_required' and row['Fetch status'] == 'partial'
    assert row['Stored'] == row['Still missing'] == 2
    assert job.final_status == 'partial'


def test_cancel_between_targets(monkeypatch):
    calls = []
    patch_common(monkeypatch, calls, {"AAA": "success", "BBB": "success"})
    job = jm.Job(id=1, kind="gapfill", label="t", params={"targets": [target("AAA"), target("BBB")]})
    orig = hc.process_instrument
    def cancel_after_first(*a, **k):
        r = orig(*a, **k); job.cancel_requested = True; return r
    monkeypatch.setattr(hc, "process_instrument", cancel_after_first)
    jm.run_gapfill_job(job, make_ctx())
    assert [c[1] for c in calls if c[0] == "fetch"] == ["AAA"]


def test_scan_when_no_targets_given(monkeypatch):
    calls = []
    patch_common(monkeypatch, calls, {"AAA": "success", "BBB": "success"})
    monkeypatch.setattr(gc, "scan_mysql", lambda engine, insts, lookback_days=3, now=None: ([], []))
    job = run({"targets": None, "lookback_days": 2}, make_ctx())
    assert job.results[0]["Status"] == "no gaps found" and calls == []


def test_requires_mysql():
    ctx = make_ctx(); ctx.data_settings.storage.mysql_enabled = False
    job = jm.Job(id=1, kind="gapfill", label="t", params={})
    try:
        jm.run_gapfill_job(job, ctx); assert False
    except RuntimeError as exc:
        assert "MySQL" in str(exc)


def test_legacy_delete_first_rebuild_is_disabled():
    import pytest
    with pytest.raises(RuntimeError, match="guarded cash gap recovery"):
        gc.delete_derived_range(None, "NSE:AAA-EQ", "2026-10-09", "2026-10-09")


def test_auto_filler_cooldown_and_single_flight(monkeypatch, tmp_path):
    monkeypatch.setattr(jm, "_PREF_PATH", tmp_path / "pref.json")
    monkeypatch.setattr(jm, "_engine", lambda ctx: "ENGINE")
    mgr = jm.JobManager()
    submitted = []
    monkeypatch.setattr(jm, "submit_gapfill", lambda ctx, targets=None, **k: submitted.append(targets) or mgr.submit("gapfill", "g", lambda j: time.sleep(0.3), trigger="auto"))
    monkeypatch.setattr(gc, "scan_mysql", lambda engine, insts, lookback: ([target("AAA")], ["NEW"]))
    f = jm.AutoGapFiller(mgr)
    f.ctx = make_ctx()
    assert f.scan_once() is not None and len(submitted) == 1
    assert "never ingested" in f.last_scan_summary
    assert f.scan_once() is None and "already queued" in f.last_scan_summary     # job still active -> single flight
    time.sleep(0.6)
    assert f.scan_once() is None and len(submitted) == 1                          # same range inside cooldown -> not retried
    f._cooldown = {k: 0 for k in f._cooldown}
    assert f.scan_once() is not None and len(submitted) == 2                      # cooldown over -> retried


def test_pref_roundtrip_and_ensure(monkeypatch, tmp_path):
    monkeypatch.setattr(jm, "_PREF_PATH", tmp_path / "pref.json")
    f = jm.AutoGapFiller(jm.JobManager())
    monkeypatch.setattr(jm, "auto_gapfill", f)
    monkeypatch.setattr(f, "scan_once", lambda: None)
    f.start(make_ctx(), interval_min=7, lookback_days=4)
    assert jm.load_pref() == {"enabled": True, "interval_min": 7, "lookback_days": 4} and f.running
    f.stop(); assert jm.load_pref()["enabled"] is False and not f.running


# ---------------------------------------------------------------- historical / aggregation job runners

def test_historical_job_progress_results_and_batch_row(monkeypatch):
    import model.storage.mysql as ms
    recorded, seen = [], []
    ctx = make_ctx(("AAA", "BBB", "CCC"))
    monkeypatch.setattr(jm, "_engine", lambda c: "ENGINE")
    monkeypatch.setattr(jm, "_build_sink", lambda c, *a, **k: "SINK")
    monkeypatch.setattr(ms, "MySQLCheckpointStore", lambda e: "CKPT")
    rec = types.SimpleNamespace(record=lambda **kw: recorded.append(kw))
    monkeypatch.setattr(jm, "_recorder", lambda c: rec)
    monkeypatch.setattr(fauth, "get_authenticated_client", lambda creds: "CLIENT")
    monkeypatch.setattr(hc, "select_instruments", lambda reg, names: reg.active_instruments())
    st = {"AAA": "success", "BBB": "failed", "CCC": "no_data"}

    def fake_process(client, inst, f, t, ds, reg, sink, ckpt, timeframe_settings=None, job_recorder=None, job_type="historical"):
        seen.append((inst.internal_name, ckpt, job_type, timeframe_settings is not None))
        s = st[inst.internal_name]
        return types.SimpleNamespace(fyers_symbol=inst.fyers_symbol, status=s, raw_count=5, valid_count=4, invalid_count=1,
                                     error="x" if s == "failed" else None)
    monkeypatch.setattr(hc, "process_instrument", fake_process)
    job = jm.Job(id=1, kind="historical", label="t",
                 params={"symbols": ["AAA", "BBB", "CCC"], "from_date": "2026-10-01", "to_date": "2026-10-09"})
    jm.run_historical_job(job, ctx)
    assert job.total == 3 and job.done == 3 and job.final_status == "partial"
    assert [s[0] for s in seen] == ["AAA", "BBB", "CCC"] and all(s[1] == "CKPT" and s[2] == "historical" and s[3] for s in seen)
    assert recorded[-1]["fyers_symbol"] is None and recorded[-1]["status"] == "partial" and recorded[-1]["valid_count"] == 12


def test_aggregation_job_runs_every_symbol_timeframe(monkeypatch):
    ctx = make_ctx(("AAA", "BBB"))
    monkeypatch.setattr(jm, "_engine", lambda c: "ENGINE")
    monkeypatch.setattr(jm, "_build_sink", lambda c, *a, **k: "SINK")
    monkeypatch.setattr(jm, "_recorder", lambda c: "REC")
    monkeypatch.setattr(jm, "_build_1m_reader", lambda c: "READER")
    monkeypatch.setattr(hc, "select_instruments", lambda reg, names: reg.active_instruments())
    done = []
    monkeypatch.setattr(tc, "generate_timeframe_for_instrument",
                        lambda inst, tf, f, t, rd, reg, ds, sink, job_recorder=None:
                        done.append((inst.internal_name, tf)) or types.SimpleNamespace(
                            fyers_symbol=inst.fyers_symbol, timeframe=tf, status="success", derived_count=9, error=None))
    job = jm.Job(id=2, kind="aggregation", label="t",
                 params={"symbols": ["AAA", "BBB"], "from_date": "2026-10-01", "to_date": "2026-10-09", "timeframes": None})
    jm.run_aggregation_job(job, ctx)
    assert done == [("AAA", "5m"), ("AAA", "15m"), ("BBB", "5m"), ("BBB", "15m")]
    assert job.total == 4 and job.done == 4 and job.final_status == "done"
