import datetime as dt

import pytest

from controller.sinks import CompositeCandleSink, CrossStoreWriteError
from model.config.market_calendar import IST
from model.processing.models import Candle
from model.storage.parquet import ParquetCandleSink


def candle(day, minute=0):
    return Candle('TEST', 'NSE:TEST-EQ', 'EQ', 'NSE',
                  dt.datetime.combine(day, dt.time(9, 15), IST) + dt.timedelta(minutes=minute),
                  '1m', 100, 102, 99, 101, 10, 'FYERS_HISTORICAL')


def test_composite_sink_reports_completed_failed_and_pending_stores():
    class SQL:
        def write_batch(self, rows):
            return rows
    class Parquet:
        last_write_state = {'status':'FAILED','failed_partition':'day.parquet'}
        def write_batch(self, rows):
            raise OSError('disk full')
    class Later:
        def write_batch(self, rows):
            raise AssertionError('pending store must not run')

    sink = CompositeCandleSink([SQL(), Parquet(), Later()])
    with pytest.raises(CrossStoreWriteError) as caught:
        sink.write_batch([candle(dt.date(2026, 10, 19))])
    state = caught.value.recovery_state
    assert state['status'] == 'PARTIAL' and state['atomic'] is False
    assert state['completed_stores'] == ['SQL']
    assert state['failed_store'] == 'Parquet' and state['pending_stores'] == ['Later']
    assert state['failed_store_may_have_written'] is True
    assert state['failed_store_state']['failed_partition'] == 'day.parquet'
    assert sink.last_write_state == state


def test_parquet_reports_multi_partition_partial_failure(tmp_path, monkeypatch):
    sink = ParquetCandleSink(str(tmp_path))
    rows = [candle(dt.date(2026, 10, 19)), candle(dt.date(2026, 10, 20))]
    real = sink._write_partition
    calls = []
    def fail_second(path, group):
        calls.append(path)
        if len(calls) == 2:
            raise OSError('simulated second partition failure')
        return real(path, group)
    monkeypatch.setattr(sink, '_write_partition', fail_second)
    with pytest.raises(OSError, match='second partition'):
        sink.write_batch(rows)
    state = sink.last_write_state
    assert state['status'] == 'PARTIAL'
    assert state['completed_partitions'] == [str(calls[0])]
    assert state['failed_partition'] == str(calls[1])
    assert state['failed_partition_may_have_changed'] is True
    assert calls[0].exists() and not calls[1].exists()
