"""Stored Cash aggregation reports incomplete source coverage without inventing bars."""
import datetime as dt
from dataclasses import replace
from types import SimpleNamespace

from controller.timeframe_controller import generate_timeframe_for_instrument, _aggregation_coverage
from model.config.instrument_loader import Instrument, InstrumentRegistry
from model.config.market_calendar import IST, session_window
from model.processing.models import Candle

DAY = '2026-10-19'
INSTRUMENT = Instrument('TEST', 'NSE:TEST-EQ', 'NSE', 'EQ', True, 'stock')
REGISTRY = InstrumentRegistry([INSTRUMENT])


def source(count=375):
    start, _ = session_window(dt.date.fromisoformat(DAY))
    return [Candle('TEST', 'NSE:TEST-EQ', 'EQ', 'NSE', start+dt.timedelta(minutes=i),
                   '1m', 100, 102, 99, 101, 10, 'FYERS_HISTORICAL') for i in range(count)]


def generate(rows, timeframe='1d', end=DAY, validation=False):
    written = []
    result = generate_timeframe_for_instrument(INSTRUMENT, timeframe, DAY, end,
        lambda *args: rows, REGISTRY, SimpleNamespace(validation_enabled=validation),
        SimpleNamespace(write_batch=lambda candles: written.extend(candles)))
    return result, written


def test_240_minutes_cannot_make_daily_candle():
    result, written = generate(source(240))
    assert result.status == 'no_complete_buckets'
    assert result.source_1m_count == 240 and result.derived_count == 0
    assert result.missing_1m_count == 135
    assert result.incomplete_bucket_count == result.skipped_bucket_count == 1
    assert '135 missing' in result.reason
    assert not written


def test_full_daily_session_succeeds_with_unchanged_ohlcv():
    result, written = generate(source())
    assert result.status == 'success'
    assert result.expected_1m_count == 375 and result.missing_1m_count == 0
    assert result.derived_count == result.valid_count == 1
    assert (written[0].open, written[0].high, written[0].low, written[0].close, written[0].volume) == (100,102,99,101,3750)


def test_empty_input_remains_no_source_data():
    result, written = generate([])
    assert result.status == 'no_source_data' and not written


def test_missing_minute_reports_partial_even_when_other_buckets_complete():
    rows = source(); del rows[7]
    result, written = generate(rows, '5m')
    assert result.status == 'partial' and result.missing_1m_count == 1
    assert result.incomplete_bucket_count == 1
    assert len(written) == 74


def test_missing_entire_day_in_requested_range_is_not_success():
    result, _ = generate(source(), end='2026-10-21')  # 20th is configured holiday
    assert result.status == 'partial' and result.missing_1m_count == 375
    assert result.incomplete_bucket_count == 1


def test_malformed_and_duplicate_source_rows_are_counted_and_not_fabricated():
    rows = source(); rows[1] = replace(rows[1], high=90)
    rows.append(rows[10])
    result, written = generate(rows, '5m')
    assert result.status == 'partial'
    assert result.rejected_source_count == 2 and result.missing_1m_count == 1
    assert len(written) == 73


def test_unfinished_current_bucket_has_no_gap_until_a_closed_minute_is_missing():
    rows = source(240)
    now = rows[-1].timestamp + dt.timedelta(minutes=1, seconds=30)
    coverage = _aggregation_coverage(rows, '1d', DAY, DAY, INSTRUMENT.fyers_symbol, now)
    assert coverage['missing_1m_count'] == 0
    assert coverage['pending_bucket_count'] == 1 and coverage['incomplete_bucket_count'] == 0
    del rows[10]
    coverage = _aggregation_coverage(rows, '1d', DAY, DAY, INSTRUMENT.fyers_symbol, now)
    assert coverage['missing_1m_count'] == 1
    assert coverage['pending_bucket_count'] == 0 and coverage['incomplete_bucket_count'] == 1


def test_unknown_calendar_does_not_invent_expected_minutes():
    rows = [replace(c, timestamp=c.timestamp.replace(year=2025)) for c in source(240)]
    coverage = _aggregation_coverage(rows, '1d', '2025-10-19', '2025-10-19', INSTRUMENT.fyers_symbol)
    assert coverage['unknown_calendar_days'] == 1
    assert coverage['expected_1m_count'] == coverage['missing_1m_count'] == 0


def test_matching_raw_count_does_not_prove_full_coverage():
    rows = source(); rows[7] = rows[8]
    result, written = generate(rows)
    assert result.source_1m_count == result.expected_1m_count == 375
    assert result.status == 'no_complete_buckets'
    assert result.missing_1m_count == result.rejected_source_count == 1
    assert not written



def test_rejected_derived_candle_cannot_report_success(monkeypatch):
    import controller.timeframe_controller as controller
    monkeypatch.setattr(controller, 'validate_candles', lambda candles, **kwargs:
        [SimpleNamespace(candle=c, status='invalid', errors=['test rejection']) for c in candles])
    result, written = generate(source(), validation=True)
    assert result.status == 'partial'
    assert result.derived_count == result.invalid_count == 1
    assert result.valid_count == 0 and not written


def test_aggregation_reports_cross_store_recovery_state():
    from controller.sinks import CrossStoreWriteError
    recovery = {
        'status': 'PARTIAL', 'atomic': False, 'completed_stores': ['MySQLCandleSink'],
        'failed_store': 'ParquetCandleSink', 'pending_stores': [], 'rows': 1,
    }
    class BrokenSink:
        def write_batch(self, candles):
            raise CrossStoreWriteError(recovery, OSError('disk full'))
    result = generate_timeframe_for_instrument(INSTRUMENT, '1d', DAY, DAY,
        lambda *args: source(), REGISTRY, SimpleNamespace(validation_enabled=False), BrokenSink())
    assert result.status == 'failed'
    assert result.storage_recovery == recovery
    assert 'not atomic' in result.error
