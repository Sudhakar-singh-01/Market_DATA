"""Persisted workflow checks on the disposable MySQL fixture."""
from controller.fno_jobs import FnoJobRunner, JobOutcome
from controller.unified_workflow import run_workflow
from model.fno.job_store import FnoJobStore


def test_workflow_job_survives_claim_and_explicit_resume(clean_fno):
    store=FnoJobStore(clean_fno)
    params={'from':'2026-10-16','to':'2026-10-16','contract_ids':[7],
            'workflow':{'version':1,'segment':'FNO','targets':[{'contract_id':7,'symbol':'NSE:TEST'}]}}
    jid=store.submit('WORKFLOW',params)
    job=store.claim_next(['WORKFLOW'])
    assert job['id']==jid and job['params']==params
    progress={'version':1,'stage':'FETCH','ready':False}
    store.progress(jid,progress)
    assert store.get(jid)['result']==progress and store.get(jid)['heartbeat_at'] is not None
    store.finish(jid,'PARTIAL',result={'version':1,'stage':'BLOCKED','ready':False})
    resumed=store.resume(jid)
    assert store.get(resumed)['params']==params and store.get(resumed)['resumed_from']==jid


def test_workflow_runner_persists_stage_progress_and_ready_result(clean_fno):
    store=FnoJobStore(clean_fno)
    day='2026-10-16'
    params={'from':day,'to':day,'contract_ids':[7],'timeframes':[],'use_parquet':True,
            'workflow':{'version':1,'segment':'FNO','from':day,'to':day,
                        'targets':[{'contract_id':7,'symbol':'NSE:TEST'}],'timeframes':['1m']}}
    class Reads:
        def get_candles(self,*args,**kwargs):
            running=store.get(jid)
            assert running['state']=='RUNNING' and running['result']['stage']=='VERIFY'
            return {'data':[{'close':'100.0000'}], 'quality':{'status':'VERIFIED','coverage':'COMPLETE'},
                    'meta':{'next_cursor':None}}
    jid=store.submit('WORKFLOW',params)
    runner=FnoJobRunner(store,{'WORKFLOW':lambda h:run_workflow(
        h,'FNO',lambda stage:JobOutcome('SUCCESS',{'rows_stored':1}),None,Reads())})
    assert runner.run_until_empty()==[jid]
    row=store.get(jid)
    assert row['state']=='SUCCESS' and row['result']['stage']=='READY'
    assert row['result']['ready'] is True and row['result']['completed_checks']==1
