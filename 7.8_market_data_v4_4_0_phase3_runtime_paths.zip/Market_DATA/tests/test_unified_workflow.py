"""Deterministic workflow orchestration; production fetch/verifiers stay delegated."""
import copy
import json
import datetime as dt
from types import SimpleNamespace
import pytest
from controller.fno_jobs import JobOutcome,JobHandle,FnoJobRunner
from controller.unified_workflow import run_workflow,validate_spec,ScopedRepo,public_result
from controller.market_data_service import MarketDataService
from model.read_contracts import DataNotVerifiedError

DAY='2026-10-16'


def params(segment='CASH',derived=False):
    target={'internal_name':'SBIN','symbol':'NSE:SBIN-EQ'} if segment=='CASH' else {'contract_id':7,'symbol':'NSE:TEST-OPT'}
    p={'from':DAY,'to':DAY,'use_parquet':True,'timeframes':['5m'] if derived else []}
    p['symbols' if segment=='CASH' else 'contract_ids']=['SBIN'] if segment=='CASH' else [7]
    p['workflow']={'version':1,'segment':segment,'targets':[target],'timeframes':['1m','5m'] if derived else ['1m'],'from':DAY,'to':DAY}
    return p


class Store:
    def __init__(self):self.history=[]; self.cancel=False
    def progress(self,jid,result):self.history.append(copy.deepcopy(result))
    def cancel_requested(self,jid):return self.cancel
    def add_counters(self,*args,**kwargs):pass


class Reads:
    def __init__(self,coverage='COMPLETE',fail=False):self.calls=[];self.coverage=coverage;self.fail=fail
    def get_candles(self,*args,**kwargs):
        self.calls.append((args,kwargs))
        if self.fail:raise DataNotVerifiedError('test mismatch')
        return {'data':[] if self.coverage=='NO_SESSION' else [{'close':'100.0000'}],
                'quality':{'status':'VERIFIED','coverage':self.coverage},'meta':{'next_cursor':None}}


def handle(segment='CASH',derived=False):
    import threading
    store=Store()
    return JobHandle(store,{'id':42,'params':params(segment,derived)},threading.Event())


def test_stages_order_and_ready_only_after_strict_checks():
    h=handle(derived=True); calls=[]; reads=Reads()
    def fetch(stage):
        calls.append('fetch'); stage.store.progress(stage.id,{'rows_stored':5})
        assert stage.params==h.params
        return JobOutcome('SUCCESS',{'fetched':5})
    def aggregate(stage):calls.append('aggregate');return JobOutcome('SUCCESS',{})
    result=run_workflow(h,'CASH',fetch,aggregate,reads)
    assert calls==['fetch','aggregate'] and result.state=='SUCCESS'
    assert result.result['ready'] is True and result.result['completed_checks']==2
    assert [c[0][2] for c in reads.calls]==['1m','5m']
    assert all(c[1]['quality']=='verified' for c in reads.calls)
    assert any(r.get('stage_progress')=={'rows_stored':5} and r['stage']=='FETCH' for r in h.store.history)
    assert all(not r['ready'] for r in h.store.history[:-1])


def test_runner_executes_workflow_and_persists_progress_before_final_result():
    class DurableStore(Store):
        def __init__(self):
            super().__init__(); self.claimed=False; self.final=None; self.beats=0
        def claim_next(self, job_types=None):
            if self.claimed:return None
            self.claimed=True
            return {'id':42,'job_type':'WORKFLOW','params':params('FNO'),'state':'RUNNING'}
        def heartbeat(self,jid):self.beats+=1
        def finish(self,jid,state,error=None,result=None):self.final=(jid,state,error,copy.deepcopy(result))
        def recover_interrupted(self,*args):return []
    store=DurableStore(); reads=Reads()
    runner=FnoJobRunner(store,{'WORKFLOW':lambda h:run_workflow(
        h,'FNO',lambda stage:JobOutcome('SUCCESS',{'rows_stored':1}),None,reads)},heartbeat_seconds=.01)
    assert runner.run_until_empty()==[42]
    assert store.final[1]=='SUCCESS' and store.final[3]['stage']=='READY'
    assert store.history and store.history[0]['stage']=='FETCH' and not store.history[0]['ready']
    assert store.history[-1]['stage']=='READY' and store.history[-1]['ready']


@pytest.mark.parametrize('state',['PARTIAL','FAILED','NO_DATA','CANCELLED','INTERRUPTED'])
def test_fetch_terminal_outcomes_stop_following_stages(state):
    h=handle(derived=True); reads=Reads()
    result=run_workflow(h,'CASH',lambda h:JobOutcome(state,{}),lambda h:pytest.fail('must not aggregate'),reads)
    assert result.state==state and not result.result['ready'] and reads.calls==[]


def test_aggregation_failure_prevents_verification():
    reads=Reads()
    result=run_workflow(handle(derived=True),'CASH',lambda h:JobOutcome('SUCCESS'),lambda h:JobOutcome('PARTIAL'),reads)
    assert result.state=='PARTIAL' and reads.calls==[]


def test_validation_failure_and_sparse_options_cannot_be_ready():
    for reads in (Reads(fail=True),Reads('SPARSE_UNCONFIRMED')):
        result=run_workflow(handle('FNO'),'FNO',lambda h:JobOutcome('SUCCESS'),None,reads)
        assert result.state=='PARTIAL' and result.result['stage']=='BLOCKED' and not result.result['ready']


def test_empty_holidays_report_no_data():
    result=run_workflow(handle(),'CASH',lambda h:JobOutcome('SUCCESS'),None,Reads('NO_SESSION'))
    assert result.state=='NO_DATA' and not result.result['ready']


def test_cancellation_between_stages_and_during_verification():
    h=handle(derived=True)
    def fetch(stage):h.store.cancel=True;return JobOutcome('SUCCESS')
    result=run_workflow(h,'CASH',fetch,lambda h:pytest.fail('cancelled'),Reads())
    assert result.state=='CANCELLED' and not result.result['ready']
    h=handle(derived=True)
    class CancelReads(Reads):
        def get_candles(self,*a,**k):
            h.store.cancel=True
            return super().get_candles(*a,**k)
    result=run_workflow(h,'CASH',lambda h:JobOutcome('SUCCESS'),lambda h:JobOutcome('SUCCESS'),CancelReads())
    assert result.state=='CANCELLED' and not result.result['ready']


def test_unexpected_stage_error_is_not_a_ready_result():
    def boom(h):raise RuntimeError('private credential')
    result=run_workflow(handle(),'CASH',boom,None,Reads())
    assert result.state=='FAILED' and 'private' not in result.error


def test_scope_validation_rejects_current_day_missing_targets_and_selection_drift():
    from model.config.market_calendar import IST
    p=params();today=str(dt.datetime.now(IST).date());p['from']=p['to']=today;p['workflow']['from']=p['workflow']['to']=today
    with pytest.raises(ValueError,match='closed'):validate_spec(p,'CASH')
    p=params();p['workflow']['targets']=[]
    with pytest.raises(ValueError,match='targets'):validate_spec(p,'CASH')
    p=params();p['symbols']=['HDFCBANK']
    with pytest.raises(ValueError,match='selection'):validate_spec(p,'CASH')
    p=params();p['use_parquet']=False
    with pytest.raises(ValueError,match='both stores'):validate_spec(p,'CASH')


def test_scoped_repo_never_expands_fno_target_universe():
    repo=SimpleNamespace(get_contracts=lambda **kwargs:[SimpleNamespace(contract_id=i) for i in (1,7,8)],other='preserved')
    scoped=ScopedRepo(repo,[7])
    assert [c.contract_id for c in scoped.get_contracts(status=None)]==[7] and scoped.other=='preserved'


def test_public_result_omits_stage_details_and_credentials():
    result={'version':1,'stage':'BLOCKED','ready':False,'stage_progress':{'secret':'token'},'params':{'password':'secret'},'stages':[{'stage':'FETCH','state':'FAILED','error':'private'}]}
    public=public_result(result)
    assert 'token' not in str(public) and 'password' not in str(public) and 'private' not in str(public)
    assert public_result('not json') is None


def test_cash_preview_and_submission_reuse_existing_service(monkeypatch):
    calls=[]
    class Cash:
        settings=SimpleNamespace(storage=SimpleNamespace(parquet_enabled=True))
        instruments=SimpleNamespace(get=lambda n:SimpleNamespace(fyers_symbol='NSE:'+n+'-EQ'))
        def smart_preview(self,p):return {'blocked':[],'items':[]}
        def submit(self,role,kind,p):calls.append((role,kind,p));return 55
    monkeypatch.setattr('controller.pipeline_service.start_worker',lambda s:None)
    facade=MarketDataService(cash_factory=Cash)
    with pytest.raises(PermissionError):facade.preview_workflow('CASH',{},role='user')
    assert facade._services=={}
    plan=facade.preview_workflow('CASH',{'from':DAY,'to':DAY,'symbols':['SBIN']},role='admin',timeframes=['5m'])
    assert plan['params']['workflow']['timeframes']==['1m','5m']
    assert facade.submit_workflow(plan,role='admin')['job_id']==55
    assert calls[0][1]=='WORKFLOW'
    plan['params']['symbols']=['OTHER']
    with pytest.raises(ValueError,match='changed'):facade.submit_workflow(plan,role='admin')


def test_fno_preview_freezes_only_selected_active_contracts():
    future=dt.datetime.now().date()+dt.timedelta(days=30)
    contracts=[SimpleNamespace(contract_id=i,fyers_symbol=f'NSE:TEST{i}',underlying=und,
               category='FUTURES',status='ACTIVE',expiry=future) for i,und in [(7,'NIFTY'),(8,'OTHER')]]
    repo=SimpleNamespace(get_contracts=lambda **k:contracts,missing_ranges=lambda *a:[],harvest_tracked_ids=lambda:set())
    settings=SimpleNamespace(universe=SimpleNamespace(underlyings=['NIFTY'],expiries_ahead=1,strike_window=0,
               include_futures=True,include_options=False),history=SimpleNamespace(session_close_buffer_minutes=1,max_days_per_request=30),
               session=SimpleNamespace(close=dt.time(15,40)),rate_limits=SimpleNamespace(per_second=2,per_day=1000,fno_reserve_fraction=.2),expired_history_enabled=False)
    class Fno:
        def __init__(self):self.ctx=SimpleNamespace(repo=repo);self.settings=settings
        def historical_preview(self,p):return {**p,'atm':{}},{'unrelated_old_estimate':True},{}
    service=MarketDataService(fno_factory=Fno)
    plan=service.preview_workflow('FNO',{'from':DAY,'to':DAY,'underlyings':['NIFTY']},role='admin')
    assert plan['params']['contract_ids']==[7]
    assert plan['params']['workflow']['targets']==[{'contract_id':7,'symbol':'NSE:TEST7'}]
    assert plan['fetch_plan']['contracts']==1


def test_fno_handler_passes_frozen_repo_to_existing_harvest(monkeypatch):
    from controller.unified_workflow import fno_workflow
    from controller.fno_historical import HarvestContext
    contracts=[SimpleNamespace(contract_id=i,fyers_symbol='NSE:TEST-OPT' if i==7 else 'NSE:OTHER') for i in (7,8)]
    repo=SimpleNamespace(get_contracts=lambda **k:contracts)
    ctx=SimpleNamespace(repo=repo,engine=object(),store=object(),settings=SimpleNamespace(parquet_root='unused'))
    monkeypatch.setattr('controller.fno_cli.ensure_fyers',lambda c:c)
    monkeypatch.setattr('controller.fno_cli._harvest_ctx',lambda *a:HarvestContext(repo,None,ctx.store,ctx.settings))
    def harvest(h,c):
        assert [x.contract_id for x in c.repo.get_contracts(status=None)]==[7]
        assert h.params['contract_ids']==[7]
        return JobOutcome('SUCCESS')
    monkeypatch.setattr('controller.fno_historical.run_harvest',harvest)
    monkeypatch.setattr('model.market_read_service.MarketReadService',lambda c:Reads())
    assert fno_workflow(ctx,handle('FNO')).result['ready'] is True


@pytest.mark.parametrize('state,expected',[('SUCCESS',True),('INTERRUPTED',False)])
def test_headless_command_masks_nonterminal_readiness(tmp_path,monkeypatch,capsys,state,expected):
    import sys,json
    from controller.workflow_cli import main
    preview=tmp_path/'review.json';preview.write_text('{}')
    class Facade:
        def submit_workflow(self,*a,**k):return {'segment':'CASH','job_id':42}
        def _service(self,*a):
            return SimpleNamespace(store=SimpleNamespace(get=lambda jid:{'state':state,
                'result':{'version':1,'stage':'READY','ready':True}}))
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin',lambda:None)
    monkeypatch.setattr('controller.workflow_cli.MarketDataService',Facade)
    monkeypatch.setattr(sys,'argv',['workflow_cli','run','--preview',str(preview),'--confirm'])
    assert main()==(0 if expected else 2)
    result=json.loads(capsys.readouterr().out.splitlines()[-1])
    assert result['ready'] is expected and result['workflow']['ready'] is expected


def test_blocked_workflow_preserves_fetch_diagnostics_without_submission():
    from model.pipeline_errors import FetchPreflightError
    finding={'symbol':'SBIN','date':DAY,'reason':'storage mismatch','details':{'sql_only':2}}
    class Cash:
        settings=SimpleNamespace(storage=SimpleNamespace(parquet_enabled=True))
        def smart_preview(self,p):return {'blocked':[finding],'items':[]}
        def submit(self,*args):raise AssertionError('Blocked preview must not submit')
    service=MarketDataService(cash_factory=Cash)
    with pytest.raises(FetchPreflightError) as exc:
        service.preview_workflow('CASH',{'from':DAY,'to':DAY,'symbols':['SBIN']},role='admin')
    assert exc.value.blocked==[finding]


def test_workflow_cli_reports_blockers_without_creating_plan(tmp_path,monkeypatch,capsys):
    import sys
    from controller import workflow_cli
    from model.pipeline_errors import FetchPreflightError
    params=tmp_path/'params.json';params.write_text('{}')
    output=tmp_path/'plan.json'
    finding={'symbol':'SBIN','date':DAY,'reason':'storage mismatch'}
    class Facade:
        def preview_workflow(self,*args,**kwargs):
            raise FetchPreflightError({'blocked':[finding]})
    monkeypatch.setattr(workflow_cli,'MarketDataService',Facade)
    monkeypatch.setattr(workflow_cli,'authenticate_admin',lambda:None)
    monkeypatch.setattr(sys,'argv',['workflow_cli','preview','--segment','CASH','--params',str(params),'--output',str(output)])
    assert workflow_cli.main()==2
    assert json.loads(capsys.readouterr().out)['blocked']==[finding]
    assert not output.exists()
