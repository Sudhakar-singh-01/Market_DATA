from pathlib import Path

import pytest

from model.config.runtime_paths import config_path, env_path, profile_home, runtime_dir, state_path
from model.exceptions import ConfigurationError
from model.storage_scope import cash_data_root
from model.fno.config import resolve_parquet_root


def profile(tmp_path, monkeypatch):
    home = tmp_path / 'permanent'
    (home / 'config').mkdir(parents=True)
    (home / 'config/.env').write_text('# profile\n')
    monkeypatch.setenv('TIOS_HOME', str(home))
    monkeypatch.delenv('CASH_DATA_ROOT', raising=False)
    return home


def test_defaults_stay_project_local(tmp_path, monkeypatch):
    monkeypatch.delenv('TIOS_HOME', raising=False)
    monkeypatch.delenv('CASH_DATA_ROOT', raising=False)
    assert profile_home() is None
    assert env_path(tmp_path) == tmp_path / 'config/.env'
    assert cash_data_root(tmp_path) == tmp_path / 'data'
    assert resolve_parquet_root('data/fno', tmp_path) == tmp_path / 'data/fno'


def test_profile_survives_different_code_roots(tmp_path, monkeypatch):
    home = profile(tmp_path, monkeypatch)
    for code in (tmp_path / 'release_one', tmp_path / 'release_two'):
        assert env_path(code) == home / 'config/.env'
        assert cash_data_root(code) == home / 'data/cash'
        assert resolve_parquet_root('data/fno', code) == home / 'data/fno'
    assert state_path('backups') == home / 'backups'
    monkeypatch.delenv('TIOS_RUNTIME_DIR', raising=False)
    assert runtime_dir() == home / 'runtime'
    monkeypatch.setenv('TIOS_RUNTIME_DIR', str(tmp_path / 'quota'))
    assert runtime_dir() == tmp_path / 'quota'


def test_explicit_data_paths_preserved(tmp_path, monkeypatch):
    profile(tmp_path, monkeypatch)
    cash = tmp_path / 'existing_cash'
    monkeypatch.setenv('CASH_DATA_ROOT', str(cash))
    assert cash_data_root(tmp_path / 'code') == cash
    fno = tmp_path / 'existing_fno'
    assert resolve_parquet_root(str(fno), tmp_path / 'code') == fno


def test_missing_profile_never_falls_back(tmp_path, monkeypatch):
    monkeypatch.setenv('TIOS_HOME', str(tmp_path / 'missing'))
    with pytest.raises(ConfigurationError, match='does not exist'):
        env_path()
    assert not (tmp_path / 'missing').exists()
    home = profile(tmp_path, monkeypatch)
    with pytest.raises(ConfigurationError, match='Required persistent profile'):
        config_path('config/data_settings.yaml')
    assert not (home / 'config/data_settings.yaml').exists()


def test_only_standard_files_redirected(tmp_path, monkeypatch):
    home = profile(tmp_path, monkeypatch)
    code = tmp_path / 'code'
    (home / 'config/data_settings.yaml').write_text('storage: {}\n')
    assert config_path(code / 'config/data_settings.yaml', code) == home / 'config/data_settings.yaml'
    custom = tmp_path / 'custom/config/data_settings.yaml'
    assert config_path(custom, code) == custom
    assert config_path('config/custom.yaml', code) == Path('config/custom.yaml')


def test_yaml_and_instrument_writer_use_profile(tmp_path, monkeypatch):
    from model.config.runtime_paths import PROJECT_ROOT
    from model.config.yaml_loader import load_yaml
    from ui.instrument_editor import _target_path
    home = profile(tmp_path, monkeypatch)
    (home / 'config/data_settings.yaml').write_text('profile_marker: stable\n')
    (home / 'instruments').mkdir()
    (home / 'instruments/stocks.yaml').write_text('stocks: []\n')
    assert load_yaml(PROJECT_ROOT / 'config/data_settings.yaml') == {'profile_marker': 'stable'}
    assert _target_path('stock') == home / 'instruments/stocks.yaml'


def test_env_loader_reads_profile_and_reload(tmp_path, monkeypatch):
    from model.config.env_loader import load_env_config
    home = profile(tmp_path, monkeypatch)
    keys = {'FYERS_CLIENT_ID': 'profile-client', 'FYERS_SECRET_KEY': 'profile-secret',
            'FYERS_REDIRECT_URI': 'http://localhost', 'DB_NAME': 'unchanged_existing_db'}
    for key in keys:
        monkeypatch.delenv(key, raising=False)
    (home / 'config/.env').write_text(''.join(f'{key}={value}\n' for key, value in keys.items()))
    config = load_env_config(reload=True)
    assert config.fyers.client_id == 'profile-client'
    assert config.db.name == 'unchanged_existing_db'


def test_relative_storage_overrides_stay_with_permanent_profile(tmp_path,monkeypatch):
    home=profile(tmp_path,monkeypatch)
    monkeypatch.setenv('CASH_DATA_ROOT','custom/cash')
    for code in (tmp_path/'release1',tmp_path/'release2'):
        assert cash_data_root(code)==home/'custom/cash'
        assert resolve_parquet_root('custom/fno',code)==home/'custom/fno'


def test_relative_logs_and_symbol_cache_follow_permanent_profile(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from ui.logging_bootstrap import resolve_log_path
    from model.fyers import symbol_master
    home = profile(tmp_path, monkeypatch)
    monkeypatch.setattr(symbol_master, '_CACHE_DIR', None)
    settings = SimpleNamespace(log_dir='logs', log_file='market_data.log')
    assert resolve_log_path(settings) == home / 'logs' / 'market_data.log'
    assert symbol_master._cache_path('NSE') == home / 'data' / 'symbol_master' / 'NSE_CM.json'


def test_relative_runtime_override_is_profile_anchored_across_launch_folders(tmp_path, monkeypatch):
    home = profile(tmp_path, monkeypatch)
    monkeypatch.setenv('TIOS_RUNTIME_DIR', 'custom/runtime')
    for launch in (tmp_path/'launcher-one', tmp_path/'launcher-two'):
        launch.mkdir()
        monkeypatch.chdir(launch)
        assert runtime_dir() == home/'custom/runtime'
        assert not (launch/'custom/runtime').exists()


def test_log_health_and_default_export_use_profile_not_launch_folder(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from controller.health_controller import check_logs_writable
    from model.storage.csv import default_export_path
    home = profile(tmp_path, monkeypatch)
    launch = tmp_path/'unrelated-launcher'; launch.mkdir(); monkeypatch.chdir(launch)
    settings = SimpleNamespace(log_dir='logs', log_file='market_data.log')
    result = check_logs_writable(settings)
    assert result.ok and str(home/'logs') in result.detail
    assert not (launch/'logs').exists()
    assert default_export_path('exports', 'sample.csv') == home/'exports/sample.csv'
    explicit = tmp_path/'operator-selected'/'sample.csv'
    assert default_export_path(explicit.parent, explicit.name) == explicit


def test_project_local_runtime_paths_ignore_cwd_without_profile(tmp_path, monkeypatch):
    from model.logging_setup import resolve_log_path
    from model.storage.csv import default_export_path
    monkeypatch.delenv('TIOS_HOME', raising=False)
    project = tmp_path/'release'; project.mkdir()
    launch = tmp_path/'launcher'; launch.mkdir(); monkeypatch.chdir(launch)
    assert resolve_log_path('logs', 'market_data.log', project) == project/'logs/market_data.log'
    assert default_export_path('exports', 'sample.csv', project) == project/'exports/sample.csv'


def test_disk_health_checks_profile_drive_not_launch_folder(tmp_path, monkeypatch):
    import controller.health_controller as health
    home = profile(tmp_path, monkeypatch)
    launch = tmp_path/'launcher'; launch.mkdir(); monkeypatch.chdir(launch)
    seen = []
    monkeypatch.setattr(health.shutil, 'disk_usage', lambda path: (seen.append(Path(path)) or
        type('Usage', (), {'free': 5 * 1024 ** 3})()))
    result = health.check_disk_space(min_free_gb=1)
    assert result.ok and seen == [home.resolve()]
