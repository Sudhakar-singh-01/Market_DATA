"""
main.py
Final Part 3 entry point. Modes:

    python main.py historical --from 2024-01-01 --to 2024-01-31 [--symbols SBIN | all | stocks | indices]
    python main.py live [--symbols all]
    python main.py aggregate --from 2024-01-01 --to 2024-01-31 [--symbols all] [--timeframes 5m 15m]
    python main.py export --symbol SBIN --timeframe 1m --from 2024-01-01 --to 2024-01-31 [--output exports/x.csv]

Storage wiring: which sink(s) historical/live/aggregate write to is
controlled entirely by config/data_settings.yaml's storage.* toggles
(mysql.enabled / parquet.enabled) -- never hard-coded here. `export`
always reads from Parquet (CSV is an export format built from the
analytical store, not written to directly by historical/live).
"""

import argparse
import logging
import sys

from model.logging_setup import configure_logging
from model.config.env_loader import load_env_config
from model.config.data_settings import load_data_settings
from model.config.timeframe_settings import load_timeframe_settings
from model.config.instrument_loader import load_instrument_registry
from model.validation import validate_startup
from model.fyers.auth import get_authenticated_client, FyersAuthError
from model.exceptions import ConfigurationError
from model.storage.mysql import build_db_url, MySQLCandleSink, MySQLCheckpointStore, MySQLJobRecorder, read_1m_candles, get_engine, sync_all_instruments
from model.storage.parquet import ParquetCandleSink
from model.storage.csv import export_candles_to_csv, deterministic_export_filename, default_export_path
from model.processing.gap_detector import find_gaps_1m, format_gap_report
from controller.historical_controller import run_historical_ingestion, select_instruments
from controller.live_controller import LiveIngestionController
from controller.timeframe_controller import run_timeframe_generation
from controller.health_controller import run_health_check
from controller.scheduler import DataEngineScheduler
from controller.sinks import CompositeCandleSink, NoOpCandleSink, NoOpJobRecorder
from view.console_view import print_startup_banner, print_historical_summary, print_live_starting, print_timeframe_summary


def parse_args():
    parser = argparse.ArgumentParser(description="FYERS Market Data Engine")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    hist = subparsers.add_parser("historical", help="Historical 1m ingestion + derived timeframe generation")
    hist.add_argument("--from", dest="from_date", required=True, help="YYYY-MM-DD")
    hist.add_argument("--to", dest="to_date", required=True, help="YYYY-MM-DD")
    hist.add_argument("--symbols", nargs="+", default=None, help="internal_name(s), or all/stocks/indices")

    live = subparsers.add_parser("live", help="Live WebSocket ingestion + incremental aggregation")
    live.add_argument("--symbols", nargs="+", default=None, help="internal_name(s), or all/stocks/indices")

    agg = subparsers.add_parser("aggregate", help="(Re)generate higher timeframes from stored 1m data")
    agg.add_argument("--from", dest="from_date", required=True, help="YYYY-MM-DD")
    agg.add_argument("--to", dest="to_date", required=True, help="YYYY-MM-DD")
    agg.add_argument("--symbols", nargs="+", default=None, help="internal_name(s), or all/stocks/indices")
    agg.add_argument("--timeframes", nargs="+", default=None, help="e.g. 5m 15m 30m 1h 1d (default: all configured)")

    exp = subparsers.add_parser("export", help="Export stored candles to CSV")
    exp.add_argument("--symbol", required=True, help="internal_name")
    exp.add_argument("--timeframe", required=True)
    exp.add_argument("--from", dest="from_date", required=True, help="YYYY-MM-DD")
    exp.add_argument("--to", dest="to_date", required=True, help="YYYY-MM-DD")
    exp.add_argument("--output", default=None, help="Output CSV path (default: exports/<deterministic name>.csv)")

    health = subparsers.add_parser("health", help="Check FYERS/MySQL/Parquet/disk connectivity")
    health.add_argument("--skip-fyers", action="store_true", help="Skip the FYERS API check")

    gapscan = subparsers.add_parser("gapscan", help="Scan stored 1m data for missing session minutes")
    gapscan.add_argument("--symbols", nargs="+", default=None, help="internal_name(s), or all/stocks/indices")
    gapscan.add_argument("--from", dest="from_date", required=True, help="YYYY-MM-DD")
    gapscan.add_argument("--to", dest="to_date", required=True, help="YYYY-MM-DD")

    subparsers.add_parser("schedule", help="Run unattended: auto live at market open, auto historical+aggregate at close")

    cleanup = subparsers.add_parser("cleanup", help="Delete old Parquet partition files past a retention window")
    cleanup.add_argument("--timeframe", required=True, help="e.g. 1m, 5m, 15m, 30m, 1h, 1d")
    cleanup.add_argument("--retain-days", type=int, required=True)
    cleanup.add_argument("--dry-run", action="store_true", help="List what would be deleted without deleting")

    subparsers.add_parser("sync-instruments", help="Upsert every configured instrument (stocks.yaml/indices.yaml) into MySQL")

    from controller.fno_cli import add_fno_subparsers  # independent FNO subsystem (fno-* modes)
    add_fno_subparsers(subparsers)

    from controller.pipeline_cli import add_parsers
    add_parsers(subparsers)
    return parser.parse_args()


def load_and_validate():
    logging.basicConfig(level="INFO", format="%(asctime)s | %(levelname)-8s | %(message)s")
    bootstrap_log = logging.getLogger("market_data.bootstrap")

    try:
        bootstrap_log.info("Loading configuration...")
        env = load_env_config()
        data_settings = load_data_settings()
        timeframe_settings = load_timeframe_settings()
        instruments = load_instrument_registry()

        log = configure_logging(
            level=data_settings.log_level, log_dir=data_settings.log_dir, log_file=data_settings.log_file,
        )
        log.info("Configuration loaded successfully.")

        validate_startup(env, data_settings, timeframe_settings, instruments)

    except ConfigurationError as exc:
        bootstrap_log.error(f"Configuration error: {exc}")
        sys.exit(1)

    return log, env, data_settings, timeframe_settings, instruments


def authenticate(log, env):
    try:
        client = get_authenticated_client(env.fyers)
    except FyersAuthError as exc:
        log.error(f"FYERS authentication error: {exc}")
        sys.exit(1)
    log.info("FYERS authentication successful.")
    return client


def build_sink(log, env, data_settings, instruments):
    """
    Builds the CandleSink(s) historical/live/aggregate write to, based
    purely on config/data_settings.yaml's storage.* toggles. If neither
    MySQL nor Parquet is enabled, falls back to NoOpCandleSink so the
    pipeline still runs (fully observable via logs) without any storage
    layer configured.
    """
    sinks = []

    if data_settings.storage.mysql_enabled:
        db_url = build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)
        engine = get_engine(db_url)
        sinks.append(MySQLCandleSink(engine, instruments))
        log.info("Storage: MySQL sink enabled.")

    if data_settings.storage.parquet_enabled:
        sinks.append(ParquetCandleSink())
        log.info("Storage: Parquet sink enabled.")

    if not sinks:
        log.warning("No storage backend enabled in config/data_settings.yaml -- using NoOpCandleSink.")
        return NoOpCandleSink()

    return sinks[0] if len(sinks) == 1 else CompositeCandleSink(sinks)


def build_checkpoint_store(log, env, data_settings):
    if data_settings.storage.mysql_enabled:
        db_url = build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)
        return MySQLCheckpointStore(get_engine(db_url))
    return None  # historical.py defaults to NullCheckpointStore


def build_job_recorder(log, env, data_settings):
    """Job history (ingestion_jobs table) is only recordable when
    MySQL is enabled -- otherwise falls back to NoOpJobRecorder, an
    explicit, known limitation rather than a silent gap."""
    if data_settings.storage.mysql_enabled:
        db_url = build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)
        return MySQLJobRecorder(get_engine(db_url))
    return NoOpJobRecorder()


def build_1m_reader(log, env, data_settings, instruments):
    """Returns a callable (fyers_symbol, from_date, to_date, instrument)
    -> list[Candle], backed by whichever storage is enabled. Prefers
    MySQL if both are enabled; falls back to Parquet."""
    if data_settings.storage.mysql_enabled:
        db_url = build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)
        engine = get_engine(db_url)
        return lambda fyers_symbol, from_date, to_date, instrument: read_1m_candles(
            engine, fyers_symbol, from_date, to_date, instrument
        )
    if data_settings.storage.parquet_enabled:
        parquet = ParquetCandleSink()
        return lambda fyers_symbol, from_date, to_date, instrument: parquet.read_candles(
            fyers_symbol, "1m", from_date, to_date
        )
    log.error("Neither MySQL nor Parquet storage is enabled -- 'aggregate'/'export' modes need stored 1m data to read from.")
    sys.exit(1)


def run_historical_mode(args, log, env, data_settings, timeframe_settings, instruments, client):
    if not data_settings.historical_enabled:
        log.error("Historical ingestion is disabled (data_settings.yaml historical.enabled: false)")
        sys.exit(1)

    sink = build_sink(log, env, data_settings, instruments)
    checkpoint_store = build_checkpoint_store(log, env, data_settings)
    job_recorder = build_job_recorder(log, env, data_settings)

    summary = run_historical_ingestion(
        client=client, instruments=instruments, data_settings=data_settings,
        from_date=args.from_date, to_date=args.to_date, symbol_filter=args.symbols,
        sink=sink, checkpoint_store=checkpoint_store, timeframe_settings=timeframe_settings,
        job_recorder=job_recorder,
    )
    print_historical_summary(summary)


def run_live_mode(args, log, env, data_settings, instruments, client):
    if not data_settings.live_enabled:
        log.error("Live ingestion is disabled (data_settings.yaml live.enabled: false)")
        sys.exit(1)

    access_token_ws = f"{env.fyers.client_id}:{env.fyers.access_token}"
    sink = build_sink(log, env, data_settings, instruments)

    controller = LiveIngestionController(
        access_token_ws=access_token_ws, instruments=instruments, data_settings=data_settings,
        symbol_filter=args.symbols, sink=sink, historical_client=client,
    )
    print_live_starting(controller.subscribed_instrument_count)
    controller.start()  # blocking, until Ctrl+C


def run_aggregate_mode(args, log, env, data_settings, timeframe_settings, instruments):
    sink = build_sink(log, env, data_settings, instruments)
    read_1m = build_1m_reader(log, env, data_settings, instruments)
    job_recorder = build_job_recorder(log, env, data_settings)

    summary = run_timeframe_generation(
        instruments=instruments, timeframe_settings=timeframe_settings, data_settings=data_settings,
        read_1m=read_1m, from_date=args.from_date, to_date=args.to_date,
        symbol_filter=args.symbols, timeframes=args.timeframes, sink=sink, job_recorder=job_recorder,
    )
    print_timeframe_summary(summary)


def run_health_mode(args, log, env, data_settings):
    report = run_health_check(env, data_settings, check_fyers_api=not args.skip_fyers)
    print()
    for c in report.checks:
        print(f"  [{'OK' if c.ok else 'FAIL'}] {c.name}: {c.detail}")
    print(f"\nOverall: {'HEALTHY' if report.all_ok else 'UNHEALTHY'}")
    if not report.all_ok:
        sys.exit(1)


def run_gapscan_mode(args, log, env, data_settings, instruments):
    read_1m = build_1m_reader(log, env, data_settings, instruments)
    if read_1m is None:
        log.error("Neither MySQL nor Parquet storage is enabled -- nothing to scan.")
        sys.exit(1)

    selected = select_instruments(instruments, args.symbols)
    if not selected:
        log.error("No matching active instruments to scan.")
        sys.exit(1)

    print()
    total_gaps = 0
    for instrument in selected:
        candles = read_1m(instrument.fyers_symbol, args.from_date, args.to_date, instrument)
        gaps = find_gaps_1m(candles)
        total_gaps += len(gaps)
        print(format_gap_report(gaps, instrument.fyers_symbol))
        print()
    print(f"Total gaps across {len(selected)} instrument(s): {total_gaps}")
    print("Note: session-window only, no exchange-holiday calendar -- verify any reported gap against NSE holidays.")


def run_schedule_mode(log, env, data_settings, timeframe_settings, instruments):
    """
    Unattended operation (spec: "add a scheduler"). Runs forever:
    starts live ingestion at market open on a background thread, stops
    it at market close, then runs historical (+ aggregate) for the day
    that just finished. See controller/scheduler.py for the underlying
    decision logic and its documented session-window limitation
    (no exchange-holiday calendar).
    """
    import threading
    import datetime

    live_state = {"controller": None, "thread": None}

    def start_live():
        try:
            client = get_authenticated_client(env.fyers)
        except FyersAuthError as exc:
            log.error("Scheduler: authentication required for live ingestion")
            raise

        access_token_ws = f"{env.fyers.client_id}:{env.fyers.access_token}"
        sink = build_sink(log, env, data_settings, instruments)
        controller = LiveIngestionController(
            access_token_ws=access_token_ws, instruments=instruments, data_settings=data_settings,
            symbol_filter=None, sink=sink, historical_client=client,
        )
        live_state["controller"] = controller
        thread = threading.Thread(target=controller.start, daemon=True)
        live_state["thread"] = thread
        thread.start()

    def stop_live():
        controller = live_state.get("controller")
        if controller is not None:
            controller.stop()
        live_state["controller"] = None
        live_state["thread"] = None

    def run_eod():
        from controller.pipeline_service import PipelineService,start_worker
        from controller.pipeline_cli import schedule_eod
        service=PipelineService(env,data_settings,timeframe_settings,instruments)
        jid=schedule_eod(service)
        if jid is not None:start_worker(service)
        log.info("EOD durable job: %s",jid)

    scheduler = DataEngineScheduler(on_market_open=start_live, on_market_close=stop_live, on_end_of_day=run_eod)

    def _shutdown(signum, frame):
        log.info("Scheduler shutdown signal received")
        scheduler.stop()
        stop_live()
        sys.exit(0)

    import signal
    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    print("\nScheduler running. Live ingestion will auto-start at market open and auto-stop at close.")
    print("Historical backfill + aggregate will run automatically shortly after close. Press Ctrl+C to stop.\n")
    scheduler.run_forever()


def run_cleanup_mode(args, log, data_settings):
    if not data_settings.storage.parquet_enabled:
        log.error("Cleanup applies to Parquet storage, which is disabled in config/data_settings.yaml.")
        sys.exit(1)

    parquet = ParquetCandleSink()
    deleted = parquet.cleanup_old_partitions(timeframe=args.timeframe, retain_days=args.retain_days, dry_run=args.dry_run)

    print()
    if not deleted:
        print(f"No partition files older than {args.retain_days} day(s) found for timeframe '{args.timeframe}'.")
    else:
        action = "Would delete" if args.dry_run else "Deleted"
        print(f"{action} {len(deleted)} file(s):")
        for path in deleted:
            print(f"  {path}")


def run_sync_instruments_mode(log, env, data_settings, instruments):
    if not data_settings.storage.mysql_enabled:
        log.error("sync-instruments requires MySQL storage to be enabled (config/data_settings.yaml storage.mysql.enabled: true).")
        sys.exit(1)

    db_url = build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password)
    engine = get_engine(db_url)

    result = sync_all_instruments(engine, instruments)

    print()
    print(f"Synced {result['total']} configured instrument(s): "
          f"{result['created']} created, {result['updated']} updated, "
          f"{result['total'] - result['created'] - result['updated']} unchanged.")


def run_export_mode(args, log, env, data_settings, instruments):
    if not data_settings.storage.parquet_enabled:
        log.error("Export requires Parquet storage to be enabled (data_settings.yaml storage.parquet.enabled: true)")
        sys.exit(1)

    try:
        instrument = instruments.get(args.symbol)
    except KeyError:
        log.error(f"Unknown instrument: '{args.symbol}'")
        sys.exit(1)

    parquet = ParquetCandleSink()
    candles = parquet.read_candles(instrument.fyers_symbol, args.timeframe, args.from_date, args.to_date)
    if not candles:
        log.warning(f"No stored candles found for {instrument.fyers_symbol} [{args.timeframe}] in range")
        return

    filename = deterministic_export_filename(instrument.fyers_symbol, args.timeframe, args.from_date, args.to_date)
    output_path = args.output or default_export_path(data_settings.storage.csv_output_dir, filename)
    path = export_candles_to_csv(candles, output_path)
    print(f"\nExported {len(candles)} candle(s) to {path}")


def main():
    args = parse_args()
    from controller.pipeline_cli import MODES,run
    if args.mode in MODES:
        try:sys.exit(run(args))
        except Exception as exc:
            print(f"Pipeline command failed: {type(exc).__name__}: {exc}",file=sys.stderr);sys.exit(1)
    if args.mode.startswith("fno-"):
        # FNO modes bootstrap independently: they do not load Subsystem A's instruments or open A's database.
        from controller.fno_cli import run_fno_mode
        sys.exit(run_fno_mode(args))
    log, env, data_settings, timeframe_settings, instruments = load_and_validate()

    print_startup_banner(
        active_stocks=len(instruments.active_stocks()), active_indices=len(instruments.active_indices()),
        base_timeframe=timeframe_settings.base_timeframe,
    )

    if args.mode == "historical":
        client = authenticate(log, env)
        run_historical_mode(args, log, env, data_settings, timeframe_settings, instruments, client)
    elif args.mode == "live":
        client = authenticate(log, env)
        run_live_mode(args, log, env, data_settings, instruments, client)
    elif args.mode == "aggregate":
        run_aggregate_mode(args, log, env, data_settings, timeframe_settings, instruments)
    elif args.mode == "export":
        run_export_mode(args, log, env, data_settings, instruments)
    elif args.mode == "health":
        run_health_mode(args, log, env, data_settings)
    elif args.mode == "gapscan":
        run_gapscan_mode(args, log, env, data_settings, instruments)
    elif args.mode == "schedule":
        run_schedule_mode(log, env, data_settings, timeframe_settings, instruments)
    elif args.mode == "cleanup":
        run_cleanup_mode(args, log, data_settings)
    elif args.mode == "sync-instruments":
        run_sync_instruments_mode(log, env, data_settings, instruments)


if __name__ == "__main__":
    main()
