"""
controller/fno_jobs.py
Queue-and-worker runner for persisted FNO jobs (same idea as ui/job_manager.py,
but state lives in MySQL with a heartbeat). Works headless: `main.py fno-jobs --run`
needs no dashboard. Handlers return a JobOutcome; the runner records the final state.
"""
import logging
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional

from model.fno.job_store import FnoJobStore
from controller import worker_lifecycle as lifecycle

log = logging.getLogger("market_data.fno.jobs")


@dataclass
class JobOutcome:
    state: str                                  # SUCCESS | PARTIAL | NO_DATA | FAILED | CANCELLED | INTERRUPTED
    result: dict = field(default_factory=dict)
    error: Optional[str] = None


class JobHandle:
    """What a handler sees: params, counters, heartbeat and stop signals."""

    def __init__(self, store: FnoJobStore, job: dict, shutdown: threading.Event):
        self.store, self.job, self.id, self.params = store, job, job["id"], job["params"]
        self._shutdown = shutdown

    def add(self, **counters):
        self.store.add_counters(self.id, **counters)

    def heartbeat(self):
        self.store.heartbeat(self.id)

    def progress(self, result: dict):
        """Persist a safe in-flight result and refresh the durable heartbeat."""
        self.store.progress(self.id, result)

    @property
    def cancel_requested(self) -> bool:
        return self.store.cancel_requested(self.id)

    @property
    def shutdown_requested(self) -> bool:
        return self._shutdown.is_set()

    def stop_outcome(self, result=None) -> Optional[JobOutcome]:
        """Checked between contracts. Cancel -> CANCELLED; graceful shutdown -> INTERRUPTED (resumable)."""
        if self.shutdown_requested or lifecycle.stopping():
            return JobOutcome("INTERRUPTED", result or {}, "Worker shut down gracefully; resume to continue.")
        if self.cancel_requested:
            return JobOutcome("CANCELLED", result or {}, "Cancelled by request after the current contract.")
        return None


class FnoJobRunner:
    def __init__(self, store: FnoJobStore, handlers: dict, heartbeat_seconds: float = 10.0,
                 stale_after_seconds: float = 90.0, segment: str = 'FNO'):
        self.store, self.handlers = store, handlers
        self.heartbeat_seconds, self.stale_after_seconds = heartbeat_seconds, stale_after_seconds
        self.shutdown = threading.Event()
        lifecycle.register(self.shutdown)
        if segment not in ('CASH','FNO'):raise ValueError('Unknown job segment')
        self.segment=segment
        self.log=logging.getLogger('market_data.'+segment.lower()+'.jobs')

    def recover(self) -> list:
        ids = self.store.recover_interrupted(self.stale_after_seconds)
        if ids:
            self.log.warning("Marked %d stale RUNNING job(s) INTERRUPTED: %s", len(ids), ids)
        return ids

    def run_one(self) -> Optional[int]:
        if self.shutdown.is_set() or lifecycle.stopping():
            return None
        job = self.store.claim_next(list(self.handlers))
        if job is None:
            return None
        handle = JobHandle(self.store, job, self.shutdown)
        stop_beat = threading.Event()

        def beat():
            while not stop_beat.wait(self.heartbeat_seconds):
                try:
                    self.store.heartbeat(job["id"])
                except Exception:      # a failed heartbeat must not kill the job thread
                    self.log.exception("heartbeat failed for job %s", job["id"])
        t = threading.Thread(target=beat, daemon=True, name=f"{self.segment.lower()}-heartbeat-{job['id']}")
        t.start()
        try:
            with lifecycle.scope(self.shutdown):
                lifecycle.check()
                outcome = self.handlers[job["job_type"]](handle)
                stop = handle.stop_outcome(outcome.result)
                if stop:
                    outcome = stop
        except lifecycle.WorkerInterrupted as exc:
            outcome = JobOutcome("INTERRUPTED", {}, str(exc))
        except KeyboardInterrupt:
            self.shutdown.set()
            outcome = JobOutcome("INTERRUPTED",{},"Interrupted by operator; resume to rebuild the requested range")
        except Exception as exc:
            self.log.exception("%s job %s crashed", self.segment, job["id"])
            outcome = JobOutcome("FAILED", {}, f"{type(exc).__name__}: {exc}")
        finally:
            stop_beat.set(); t.join(timeout=2)
        self.store.finish(job["id"], outcome.state, outcome.error, outcome.result)
        self.log.info("%s job %s (%s) finished: %s", self.segment, job["id"], job["job_type"], outcome.state)
        return job["id"]

    def run_until_empty(self) -> list:
        done = []
        while not self.shutdown.is_set():
            jid = self.run_one()
            if jid is None:
                break
            done.append(jid)
        return done

    def worker_loop(self, poll_seconds: float = 5.0, concurrency: int = 1) -> None:
        """Headless worker: recover stale jobs once, then poll until shutdown.set()."""
        self.recover()

        def loop():
            while not self.shutdown.is_set():
                if self.run_one() is None:
                    self.shutdown.wait(poll_seconds)
        threads = [threading.Thread(target=loop, name=f"{self.segment.lower()}-worker-{i}", daemon=True) for i in range(max(1, concurrency))]
        for t in threads:
            lifecycle.register(self.shutdown, t)
            t.start()
        try:
            while any(t.is_alive() for t in threads) and not self.shutdown.wait(0.2):
                pass
        finally:
            self.shutdown.set()
            import time
            deadline = time.monotonic() + 5.0
            for t in threads:
                t.join(max(0.0, deadline - time.monotonic()))
