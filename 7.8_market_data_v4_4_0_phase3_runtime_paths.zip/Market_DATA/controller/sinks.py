"""
controller/sinks.py
Part 3 integration contract (spec Section 29). Neither controller
implements database/Parquet/CSV storage -- they only write to a
CandleSink, which Part 3 will implement for real. NoOpCandleSink is the
default used until then: it logs counts and does nothing durable.

Both single-candle and batch writes are part of the interface (spec
Section 29: "should be able to accept single candle / batch of
candles") -- historical_controller naturally has full batches;
live_controller calls write_one() per completed candle to keep latency
low, matching "the live path should preferably support batching...
without introducing unacceptable latency."
"""

import logging
from typing import Optional, Protocol

from model.processing.models import Candle

log = logging.getLogger("market_data.controller.sinks")


class CandleSink(Protocol):
    """Interface Part 3's storage layer (MySQL/Parquet/CSV) must
    implement."""

    def write_one(self, candle: Candle) -> None:
        ...

    def write_batch(self, candles: list) -> None:
        ...


class NoOpCandleSink:
    """Default sink until Part 3 exists. Durably stores nothing --
    logs what WOULD have been written, so historical/live runs are
    still fully observable without a storage layer."""

    def write_one(self, candle: Candle) -> None:
        log.debug(f"NoOpCandleSink: would write 1 candle: {candle.fyers_symbol} {candle.timestamp}")

    def write_batch(self, candles: list) -> None:
        self.last_stored = 0
        log.info(f"NoOpCandleSink: would write {len(candles)} candle(s) (no storage layer configured yet)")


class CrossStoreWriteError(RuntimeError):
    """A fan-out write stopped after one or more independent store attempts.

    SQL and Parquet cannot share a transaction.  The structured recovery state
    is intentionally attached to the exception so every caller can report what
    completed without claiming that the fan-out was atomic.
    """

    def __init__(self, recovery_state: dict, cause: Exception):
        self.recovery_state = recovery_state
        self.cause = cause
        completed = ", ".join(recovery_state["completed_stores"]) or "none"
        super().__init__(
            "Cross-store write incomplete (not atomic): completed stores="
            f"{completed}; failed store={recovery_state['failed_store']}. "
            "Stop writers and run scoped SQL/Parquet verification before retrying."
        )


class CompositeCandleSink:
    """Fans out every write to multiple sinks (e.g. MySQL + Parquet
    simultaneously, per data_settings.yaml storage.* toggles). Spec
    Section 29: MySQL and Parquet must represent the same canonical
    dataset -- writing to both from the SAME already-aggregated/
    validated candle (not two independent aggregation runs) is how
    this module guarantees that."""

    def __init__(self, sinks: list):
        self._sinks = sinks
        self.last_write_state = {
            "status": "NOT_STARTED", "atomic": False, "completed_stores": [],
            "failed_store": None, "pending_stores": [], "rows": 0,
        }

    @staticmethod
    def _store_name(sink) -> str:
        return getattr(sink, "store_name", type(sink).__name__)

    def write_one(self, candle: Candle) -> None:
        return self.write_batch([candle])

    def write_batch(self, candles: list):
        self.last_conflicts = 0
        self.last_stored = 0
        accepted = candles
        names = [self._store_name(s) for s in self._sinks]
        completed = []
        self.last_write_state = {
            "status": "IN_PROGRESS", "atomic": False, "completed_stores": [],
            "failed_store": None, "pending_stores": names, "rows": len(candles),
        }
        for index, sink in enumerate(self._sinks):
            from controller import worker_lifecycle as lifecycle
            try:
                lifecycle.check()
            except lifecycle.WorkerInterrupted:
                self.last_write_state = {
                    "status": "PARTIAL" if completed else "INTERRUPTED",
                    "atomic": False, "completed_stores": list(completed),
                    "failed_store": None, "pending_stores": names[index:],
                    "rows": len(candles),
                    "next_action": "Run scoped SQL/Parquet verification before resuming if any store completed.",
                }
                raise
            try:
                result = sink.write_batch(accepted)
            except lifecycle.WorkerInterrupted:
                self.last_write_state = {
                    "status": "PARTIAL" if completed else "INTERRUPTED",
                    "atomic": False, "completed_stores": list(completed),
                    "failed_store": self._store_name(sink), "pending_stores": names[index + 1:],
                    "failed_store_may_have_written": True, "rows": len(candles),
                    "next_action": "Run scoped SQL/Parquet verification before resuming.",
                }
                raise
            except Exception as exc:
                state = {
                    "status": "PARTIAL" if completed else "FAILED",
                    "atomic": False, "completed_stores": list(completed),
                    "failed_store": self._store_name(sink), "pending_stores": names[index + 1:],
                    "failed_store_may_have_written": True, "rows": len(candles),
                    "next_action": "Stop writers and run scoped SQL/Parquet verification before retrying.",
                }
                detail = getattr(sink, "last_write_state", None)
                if isinstance(detail, dict):
                    state["failed_store_state"] = dict(detail)
                self.last_write_state = state
                raise CrossStoreWriteError(state, exc) from exc
            completed.append(self._store_name(sink))
            self.last_conflicts += getattr(sink, "last_conflicts", 0)
            if hasattr(sink,"last_stored"):self.last_stored = sink.last_stored
            if isinstance(result, list):
                accepted = result
            self.last_write_state["completed_stores"] = list(completed)
            self.last_write_state["pending_stores"] = names[index + 1:]
        self.last_write_state = {
            "status": "COMPLETE", "atomic": False, "completed_stores": list(completed),
            "failed_store": None, "pending_stores": [], "rows": len(candles),
        }
        return accepted


class JobRecorder(Protocol):
    """Interface for recording ingestion job history (the
    ingestion_jobs table). Kept separate from CandleSink since job
    records and candle data have completely different shapes and
    lifecycles."""

    def record(
        self, job_type: str, fyers_symbol: Optional[str], timeframe: Optional[str],
        from_date: Optional[str], to_date: Optional[str], status: str,
        raw_count: Optional[int] = None, valid_count: Optional[int] = None,
        invalid_count: Optional[int] = None, error_message: Optional[str] = None,
    ) -> int:
        ...


class NoOpJobRecorder:
    """Default recorder when MySQL storage is disabled -- job history
    is then only visible in log files, which is an explicit, known
    limitation rather than a silent gap."""

    def record(self, job_type, fyers_symbol, timeframe, from_date, to_date, status,
               raw_count=None, valid_count=None, invalid_count=None, error_message=None) -> int:
        log.debug(f"NoOpJobRecorder: not persisting job record ({job_type}, {fyers_symbol}, {status})")
        return -1
