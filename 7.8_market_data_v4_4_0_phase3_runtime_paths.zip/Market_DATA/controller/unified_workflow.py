"""One persisted job: existing fetch/clean/validate/store, optional aggregation,
then strict read verification. READY is point-in-time evidence, never a certificate
for later mutations. No child jobs, new tables, or broker implementation.
"""
import copy
import datetime as dt
import hashlib
import json
from controller.fno_jobs import JobOutcome
from model.config.market_calendar import IST, calendar_verified
from model.read_contracts import TIMEFRAMES, date_scope, segment_name, DataNotVerifiedError

JOB_TYPE='WORKFLOW'


def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,default=str).encode()).hexdigest()


def validate_spec(params,segment):
    spec=params.get('workflow')
    if not isinstance(spec,dict) or spec.get('version')!=1 or spec.get('segment')!=segment:
        raise ValueError('A reviewed workflow scope is required')
    a,b=date_scope(spec.get('from'),spec.get('to'),31)
    if b>=dt.datetime.now(IST).date(): raise ValueError('Workflow supports closed historical days only')
    if (params.get('from'),params.get('to'))!=(str(a),str(b)):
        raise ValueError('Workflow dates differ from job parameters')
    targets=spec.get('targets')
    if not isinstance(targets,list) or not 1<=len(targets)<=200: raise ValueError('Select 1–200 explicit targets')
    if len(targets)*((b-a).days+1)>5000: raise ValueError('Workflow is limited to 5000 target-days')
    symbols=[]
    for target in targets:
        if not isinstance(target,dict) or not isinstance(target.get('symbol'),str) or not target['symbol']:
            raise ValueError('Invalid target symbol')
        symbols.append(target['symbol'])
        if segment=='FNO' and (type(target.get('contract_id')) is not int or target['contract_id']<=0):
            raise ValueError('FNO workflows require explicit contract IDs')
        if segment=='CASH' and not isinstance(target.get('internal_name'),str): raise ValueError('Cash target name required')
    if len(symbols)!=len(set(symbols)): raise ValueError('Duplicate workflow targets')
    tfs=spec.get('timeframes')
    if not isinstance(tfs,list) or not tfs or tfs[0]!='1m' or len(tfs)!=len(set(tfs)) or any(t not in TIMEFRAMES for t in tfs):
        raise ValueError('Workflow timeframes must start with canonical 1m')
    expected=[t['internal_name'] for t in targets] if segment=='CASH' else [t['contract_id'] for t in targets]
    if params.get('symbols' if segment=='CASH' else 'contract_ids')!=expected:
        raise ValueError('Job selection differs from reviewed workflow targets')
    if params.get('timeframes')!=[tf for tf in tfs if tf!='1m'] or params.get('use_parquet') is not True:
        raise ValueError('Workflow requires matching timeframes and both stores')
    return spec


class StageStore:
    def __init__(self,store,publish): self._store,self._publish=store,publish
    def __getattr__(self,name): return getattr(self._store,name)
    def progress(self,job_id,result): self._publish(result)


class ScopedRepo:
    """Restrict the existing FNO selector/harvester without changing its rules."""
    def __init__(self,repo,ids): self._repo,self._ids=repo,set(ids)
    def __getattr__(self,name): return getattr(self._repo,name)
    def get_contracts(self,*args,**kwargs):
        return [c for c in self._repo.get_contracts(*args,**kwargs) if c.contract_id in self._ids]


def run_workflow(handle,segment,fetch,aggregate,reads,check_targets=lambda spec:None):
    spec=validate_spec(handle.params,segment)
    check_targets(spec)
    summary={'version':1,'stage':'FETCH','ready':False,'verified_at':None,'coverage':None,
             'scope':spec,'stages':[],'completed_checks':0,'total_checks':0,'verified_rows':0}
    def publish(detail=None):
        if detail is not None: summary['stage_progress']=detail
        handle.progress(copy.deepcopy(summary))
    proxy=copy.copy(handle)
    proxy.store=StageStore(handle.store,publish)
    proxy.params=copy.deepcopy(handle.params)
    stages=[('FETCH',fetch)]
    if len(spec['timeframes'])>1: stages.append(('AGGREGATE',aggregate))

    def stopped():
        stop=handle.stop_outcome(summary)
        if stop:
            summary['ready']=False; summary['stage']=stop.state
            stop.result=copy.deepcopy(summary)
        return stop

    for name,operation in stages:
        stop=stopped()
        if stop:return stop
        summary['stage']=name; summary.pop('stage_progress',None); publish()
        try: outcome=operation(proxy)
        except Exception as exc:
            outcome=JobOutcome('FAILED',{},'Stage failed: '+type(exc).__name__)
        summary['stages'].append({'stage':name,'state':outcome.state})
        summary['stage_progress']=outcome.result
        if outcome.state!='SUCCESS':
            summary['stage']='BLOCKED' if outcome.state in ('PARTIAL','NO_DATA') else outcome.state
            publish()
            return JobOutcome(outcome.state,summary,outcome.error)
        publish()

    summary['stage']='VERIFY'; summary.pop('stage_progress',None)
    a,b=date_scope(spec['from'],spec['to'],31)
    summary['total_checks']=len(spec['targets'])*len(spec['timeframes'])*((b-a).days+1)
    publish()
    try:
        for target in spec['targets']:
            for tf in spec['timeframes']:
                for offset in range((b-a).days+1):
                    stop=stopped()
                    if stop:return stop
                    day=str(a+dt.timedelta(days=offset))
                    summary['current']={'symbol':target['symbol'],'timeframe':tf,'date':day}
                    page=reads.get_candles(segment,target['symbol'],tf,day,day,quality='verified',closed_only=True,limit=1000)
                    q=page['quality']
                    if q.get('status')!='VERIFIED' or q.get('coverage') not in ('COMPLETE','NO_SESSION'):
                        raise DataNotVerifiedError('Complete coverage is not established')
                    if page['meta'].get('next_cursor') is not None:
                        raise DataNotVerifiedError('Day exceeds the workflow verification row bound')
                    summary['verified_rows']+=len(page['data'])
                    summary['completed_checks']+=1
                    publish()
        stop=stopped()
        if stop:return stop
    except Exception as exc:
        summary['stage']='BLOCKED'; summary['coverage']='NOT_VERIFIED'
        summary['stages'].append({'stage':'VERIFY','state':'PARTIAL'})
        summary['reason']='DATA_NOT_VERIFIED' if isinstance(exc,DataNotVerifiedError) else 'VERIFICATION_UNAVAILABLE'
        publish()
        return JobOutcome('PARTIAL',summary,'Strict readiness verification did not pass')
    summary['stages'].append({'stage':'VERIFY','state':'SUCCESS'})
    summary['verified_at']=dt.datetime.now(IST).isoformat()
    summary['ready']=summary['verified_rows']>0
    summary['stage']='READY' if summary['ready'] else 'NO_DATA'
    summary['coverage']='COMPLETE' if summary['ready'] else 'NO_SESSION'
    summary.pop('current',None)
    publish()
    return JobOutcome('SUCCESS' if summary['ready'] else 'NO_DATA',summary)


def cash_workflow(service,handle):
    from model.database_catalog import DatabaseCatalog
    from model.market_read_service import MarketReadService
    if not service.settings.storage.parquet_enabled: raise ValueError('Workflow requires Parquet enabled')
    def check(spec):
        for t in spec['targets']:
            if service.instruments.get(t['internal_name']).fyers_symbol!=t['symbol']:
                raise ValueError('Instrument configuration changed; preview again')
    def operation(name,h):
        clone=copy.copy(service); clone.store=h.store
        return getattr(clone,name)(h)
    reads=MarketReadService(DatabaseCatalog({'CASH':lambda:service.engine},{'CASH':service.reader.root}))
    return run_workflow(handle,'CASH',lambda h:operation('smart_fetch',h),lambda h:operation('aggregate',h),reads,check)


def fno_workflow(ctx,handle):
    import dataclasses
    from controller.fno_cli import ensure_fyers,_harvest_ctx
    from controller.fno_historical import run_harvest
    from controller.fno_aggregate import run_aggregation
    from model.database_catalog import DatabaseCatalog
    from model.market_read_service import MarketReadService
    spec=validate_spec(handle.params,'FNO')
    def check(scope):
        current={c.contract_id:c.fyers_symbol for c in ctx.repo.get_contracts(status=None)}
        for t in scope['targets']:
            if current.get(t['contract_id'])!=t['symbol']: raise ValueError('Contract mapping changed; preview again')
    def fetch(h):
        ensure_fyers(ctx)
        harvest=_harvest_ctx(ctx,True)
        harvest=dataclasses.replace(harvest,repo=ScopedRepo(harvest.repo,[t['contract_id'] for t in spec['targets']]))
        return run_harvest(h,harvest)
    reads=MarketReadService(DatabaseCatalog({'FNO':lambda:ctx.engine},{'FNO':ctx.settings.parquet_root},ctx.settings))
    return run_workflow(handle,'FNO',fetch,lambda h:run_aggregation(h,ctx.repo,ctx.store,ctx.settings),reads,check)


def public_result(result):
    """Small allowlisted status; never return nested provider errors or params."""
    if isinstance(result,str):
        try:result=json.loads(result)
        except ValueError:return None
    if not isinstance(result,dict) or result.get('version')!=1:return None
    out={'ready':result.get('ready') is True}
    stages_allowed={'FETCH','AGGREGATE','VERIFY','READY','BLOCKED','NO_DATA','FAILED','CANCELLED','INTERRUPTED'}
    states_allowed={'SUCCESS','PARTIAL','FAILED','NO_DATA','CANCELLED','INTERRUPTED'}
    for key,allowed in [('stage',stages_allowed),('coverage',{'COMPLETE','NO_SESSION','NOT_VERIFIED'}),
                        ('reason',{'DATA_NOT_VERIFIED','VERIFICATION_UNAVAILABLE'})]:
        if isinstance(result.get(key),str) and result[key] in allowed:out[key]=result[key]
    for key in ('completed_checks','total_checks','verified_rows'):
        if type(result.get(key)) is int and result[key]>=0:out[key]=result[key]
    stamp=result.get('verified_at')
    if isinstance(stamp,str):
        try:out['verified_at']=dt.datetime.fromisoformat(stamp).isoformat()
        except ValueError:pass
    else:out['verified_at']=None
    out['note']='Readiness is historical job evidence; consume with quality=verified to recheck current data'
    stages=result.get('stages')
    if not isinstance(stages,list):stages=[]
    out['stages']=[{'stage':s['stage'],'state':s['state']} for s in stages[:3]
                   if isinstance(s,dict) and isinstance(s.get('stage'),str) and s['stage'] in stages_allowed
                   and isinstance(s.get('state'),str) and s['state'] in states_allowed]
    return out
