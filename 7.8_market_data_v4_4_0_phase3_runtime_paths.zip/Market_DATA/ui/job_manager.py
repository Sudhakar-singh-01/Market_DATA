"""
ui/job_manager.py
Background job runner (NO Streamlit imports -> unit-testable).

Historical fetch, timeframe aggregation and gap-fill used to run INSIDE the
Streamlit script, so closing the tab / switching page killed them. Now they
run on one worker thread in the server process (same idea as the live
LiveRunManager): the UI only submits a job and shows its progress, and the job
keeps going if the tab is closed or the page is changed.

  * One worker thread, FIFO queue  -> jobs never overlap (FYERS rate limits,
    no two writers fighting), later jobs show as "queued".
  * Per-instrument progress, cancel between instruments.
  * ingestion_jobs rows are written (the old UI path never passed a recorder).
  * AutoGapFiller: periodic scan -> submits a gap-fill job when needed.

Limit: jobs live in the server PROCESS. If the `streamlit run` process itself
is stopped/restarted, a running job stops (checkpoints/ingestion_jobs remain).
"""

import datetime
from controller import worker_lifecycle as lifecycle
import json
import logging
import queue
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger("market_data.ui.jobs")

MAX_KEPT_JOBS = 100
AUTO_COOLDOWN_SECONDS = 30 * 60   # don't retry the same (symbol, range) more often than this
_PREF_PATH = Path(__file__).resolve().parent.parent / "data" / "auto_gapfill.json"


@dataclass
class JobContext:
    env: object
    data_settings: object
    timeframe_settings: object
    instruments: object


@dataclass
class Job:
    id: int
    kind: str                      # 'historical' | 'aggregation' | 'gapfill'
    label: str
    trigger: str = "manual"        # 'manual' | 'auto'
    params: dict = field(default_factory=dict)
    status: str = "queued"         # queued | running | done | partial | failed | cancelled
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    total: int = 0
    done: int = 0
    current: str = ""
    results: list = field(default_factory=list)
    error: Optional[str] = None
    cancel_requested: bool = False
    final_status: Optional[str] = None   # set by a runner to report 'partial'

    def snapshot(self) -> dict:
        end = self.finished_at or time.time()
        return {
            "id": self.id, "kind": self.kind, "label": self.label, "trigger": self.trigger,
            "status": self.status, "total": self.total, "done": self.done, "current": self.current,
            "error": self.error, "results": list(self.results), "cancel_requested": self.cancel_requested,
            "elapsed_s": (end - self.started_at) if self.started_at else 0.0,
            "created_at": self.created_at, "finished_at": self.finished_at,
        }


class JobManager:
    def __init__(self):
        self._jobs: list = []
        self._lock = threading.RLock()
        self._queue: "queue.Queue" = queue.Queue()
        self._shutdown = threading.Event()
        lifecycle.register(self._shutdown)
        self._seq = 0
        self._worker: Optional[threading.Thread] = None

    # ---------------------------------------------------------------- API
    def submit(self, kind: str, label: str, fn: Callable, params: Optional[dict] = None, trigger: str = "manual") -> Job:
        lifecycle.check()
        with self._lock:
            if self._shutdown.is_set():
                raise lifecycle.WorkerInterrupted("Worker shutting down; new work refused")
            self._seq += 1
            job = Job(id=self._seq, kind=kind, label=label, trigger=trigger, params=params or {})
            self._jobs.append(job)
            self._trim()
            self._queue.put((job, fn))
            if self._worker is None or not self._worker.is_alive():
                self._worker = threading.Thread(target=self._loop, name="job-worker", daemon=True)
                lifecycle.register(self._shutdown, self._worker)
                self._worker.start()
            return job

    def cancel(self, job_id: int) -> bool:
        with self._lock:
            job = self._find(job_id)
            if job is None or job.status not in ("queued", "running"):
                return False
            job.cancel_requested = True
            return True

    def snapshot(self, kinds: Optional[list] = None, limit: int = 30) -> list:
        with self._lock:
            jobs = [j for j in self._jobs if not kinds or j.kind in kinds]
            return [j.snapshot() for j in reversed(jobs)][:limit]

    def active(self, kind: Optional[str] = None) -> list:
        with self._lock:
            return [j.snapshot() for j in self._jobs
                    if j.status in ("queued", "running") and (kind is None or j.kind == kind)]

    def get(self, job_id: int) -> Optional[dict]:
        with self._lock:
            job = self._find(job_id)
            return job.snapshot() if job else None

    # ---------------------------------------------------------------- internals
    def _find(self, job_id: int) -> Optional[Job]:
        return next((j for j in self._jobs if j.id == job_id), None)

    def _trim(self):
        finished = [j for j in self._jobs if j.status not in ("queued", "running")]
        while len(self._jobs) > MAX_KEPT_JOBS and finished:
            self._jobs.remove(finished.pop(0))

    def _loop(self):
        while not self._shutdown.is_set():
            try:
                job, fn = self._queue.get(timeout=0.2)
            except queue.Empty:
                continue
            if job.cancel_requested:
                job.status, job.finished_at = "cancelled", time.time()
                continue
            job.status, job.started_at = "running", time.time()
            try:
                with lifecycle.scope(self._shutdown):
                    lifecycle.check()
                    fn(job)
                    lifecycle.check()
                job.status = "cancelled" if job.cancel_requested else (job.final_status or "done")
            except lifecycle.WorkerInterrupted as exc:
                job.status, job.error = "interrupted", str(exc)
            except Exception as exc:  # a failing job must never kill the worker
                log.exception(f"Job #{job.id} ({job.kind}) failed")
                job.status, job.error = "failed", f"{type(exc).__name__}: {exc}"
            finally:
                job.current = ""
                job.finished_at = time.time()


job_manager = JobManager()


# ====================================================================== runners

def _engine(ctx: JobContext):
    from model.storage.mysql import build_db_url, get_engine
    e = ctx.env.db
    return get_engine(build_db_url(e.host, e.port, e.name, e.user, e.password))


def _build_sink(ctx: JobContext, use_mysql: bool = True, use_parquet: bool = True):
    from model.storage.mysql import MySQLCandleSink
    from model.storage.parquet import ParquetCandleSink
    from controller.sinks import CompositeCandleSink, NoOpCandleSink
    sinks = []
    if use_mysql and ctx.data_settings.storage.mysql_enabled:
        sinks.append(MySQLCandleSink(_engine(ctx), ctx.instruments))
    if use_parquet and ctx.data_settings.storage.parquet_enabled:
        sinks.append(ParquetCandleSink())
    if not sinks:
        return NoOpCandleSink()
    return sinks[0] if len(sinks) == 1 else CompositeCandleSink(sinks)


def _build_1m_reader(ctx: JobContext):
    from model.storage.mysql import read_1m_candles
    from model.storage.parquet import ParquetCandleSink
    if ctx.data_settings.storage.mysql_enabled:
        engine = _engine(ctx)
        return lambda sym, f, t, inst: read_1m_candles(engine, sym, f, t, inst)
    if ctx.data_settings.storage.parquet_enabled:
        pq = ParquetCandleSink()
        return lambda sym, f, t, inst: pq.read_candles(sym, "1m", f, t)
    return None


def _recorder(ctx: JobContext):
    from model.storage.mysql import MySQLJobRecorder
    from controller.sinks import NoOpJobRecorder
    return MySQLJobRecorder(_engine(ctx)) if ctx.data_settings.storage.mysql_enabled else NoOpJobRecorder()


def run_historical_job(job: Job, ctx: JobContext):
    from controller.historical_controller import select_instruments, process_instrument
    from model.fyers.auth import get_authenticated_client
    from model.fyers.historical import NullCheckpointStore
    from model.storage.mysql import MySQLCheckpointStore

    p = job.params
    selected = select_instruments(ctx.instruments, p["symbols"])
    job.total = len(selected)
    if not selected:
        raise RuntimeError("No matching active instruments to process.")

    sink = _build_sink(ctx, p.get("use_mysql", True), p.get("use_parquet", True))
    recorder = _recorder(ctx)
    checkpoints = MySQLCheckpointStore(_engine(ctx)) if ctx.data_settings.storage.mysql_enabled else NullCheckpointStore()
    client = get_authenticated_client(ctx.env.fyers)

    results = []
    for inst in selected:
        if job.cancel_requested:
            break
        job.current = inst.internal_name
        r = process_instrument(client, inst, p["from_date"], p["to_date"], ctx.data_settings, ctx.instruments,
                               sink, checkpoints, timeframe_settings=ctx.timeframe_settings, job_recorder=recorder)
        results.append(r)
        job.results.append({"Symbol": r.fyers_symbol, "Status": r.status, "Downloaded (raw)": r.raw_count,
                            "Validated": r.valid_count, "Stored": getattr(r,"stored_count",None),
                            "Invalid": r.invalid_count, "Error": r.error,
                            "Storage recovery": getattr(r,"storage_recovery",None)})
        job.done += 1

    failed = sum(1 for r in results if r.status in ("failed","partial"))
    recorder.record(job_type="historical", fyers_symbol=None, timeframe="1m",
                    from_date=p["from_date"], to_date=p["to_date"],
                    status="success" if failed == 0 else "partial",
                    raw_count=sum(r.raw_count for r in results), valid_count=sum(r.valid_count for r in results),
                    invalid_count=sum(r.invalid_count for r in results))
    job.final_status = "partial" if failed else "done"


def run_aggregation_job(job: Job, ctx: JobContext):
    from controller.historical_controller import select_instruments
    from controller.timeframe_controller import generate_timeframe_for_instrument

    p = job.params
    read_1m = _build_1m_reader(ctx)
    if read_1m is None:
        raise RuntimeError("Neither MySQL nor Parquet storage is enabled -- nothing to read 1m data from.")
    selected = select_instruments(ctx.instruments, p["symbols"])
    timeframes = p.get("timeframes") or [tf.name for tf in ctx.timeframe_settings.derived_timeframes]
    job.total = len(selected) * len(timeframes)
    sink = _build_sink(ctx)
    recorder = _recorder(ctx)

    failed = 0
    for inst in selected:
        for tf in timeframes:
            if job.cancel_requested:
                return
            job.current = f"{inst.internal_name} [{tf}]"
            r = generate_timeframe_for_instrument(inst, tf, p["from_date"], p["to_date"], read_1m,
                                                  ctx.instruments, ctx.data_settings, sink, job_recorder=recorder)
            failed += 1 if r.status != "success" else 0
            job.results.append({"Symbol": r.fyers_symbol, "Timeframe": r.timeframe, "Status": r.status,
                                "Output records": r.derived_count, "Error": r.error,
                                "Reason": getattr(r,'reason',None),"Missing source minutes":getattr(r,'missing_1m_count',None),
                                "Storage recovery":getattr(r,'storage_recovery',None)})
            job.done += 1
    job.final_status = "partial" if failed else "done"


def _remaining_missing(engine, inst, from_date: str, to_date: str) -> int:
    from controller.gapfill_controller import count_missing, load_symbol_data, plan_fills
    internal = count_missing(engine, inst, from_date, to_date)
    sd = load_symbol_data(engine, [inst], lookback_days=0)[0]
    sd.window_timestamps = []                      # tail part only
    tail = sum(t.missing_minutes for t in plan_fills([sd])[0])
    return internal + tail


def run_gapfill_job(job: Job, ctx: JobContext):
    from controller.gapfill_controller import scan_mysql
    from controller.historical_controller import process_instrument
    from model.fyers.auth import get_authenticated_client
    from model.fyers.historical import NullCheckpointStore

    if not ctx.data_settings.storage.mysql_enabled:
        raise RuntimeError("Gap-fill needs MySQL storage enabled (it reads stored candles to find gaps).")
    engine = _engine(ctx)
    p = job.params

    targets = p.get("targets")
    if targets is None:
        names = p.get("symbols")
        insts = ctx.instruments.active_instruments() if not names else [ctx.instruments.get(n) for n in names]
        targets, _ = scan_mysql(engine, insts, lookback_days=p.get("lookback_days", 3))
    job.total = len(targets)
    if not targets:
        job.results.append({"Symbol": "-", "Status": "no gaps found", "Fetched": 0})
        return

    client = get_authenticated_client(ctx.env.fyers)
    sink = _build_sink(ctx)
    recorder = _recorder(ctx)
    failed = 0
    for t in targets:
        if job.cancel_requested:
            return
        job.current = t.internal_name
        inst = ctx.instruments.get(t.internal_name)
        # NullCheckpointStore: a checkpoint could make the fetch SKIP the very dates we want to repair.
        # timeframe_settings=None: this job repairs only canonical 1m data; guarded rebuild handles derived stores.
        r = process_instrument(client, inst, t.from_date, t.to_date, ctx.data_settings, ctx.instruments,
                               sink, NullCheckpointStore(), timeframe_settings=None,
                               job_recorder=recorder, job_type="gapfill")
        row = {"Symbol": t.internal_name, "Reason": t.reason, "Range": f"{t.from_date}..{t.to_date}",
               "Missing before (est.)": t.missing_minutes, "Fetched": r.raw_count,
               "Stored": getattr(r,"stored_count",0), "Status": r.status}
        recovery=getattr(r,"storage_recovery",None)
        if recovery:
            failed += 1
            row["Status"] = "storage_recovery_required"
            row["Error"] = r.error
            row["Storage recovery"] = recovery
            row["Next action"] = ("Stop writers and verify the affected SQL/Parquet scope. "
                                  "Run guarded derived rebuild only after raw-store parity is restored.")
        elif getattr(r,"stored_count",0)>0 or r.status == "success":
            row["Still missing"] = _remaining_missing(engine, inst, t.from_date, t.to_date)
            row["Fetch status"] = r.status
            row["Status"] = "rebuild_required"
            row["Next action"] = ("Run the guarded cash gap recovery with derived rebuild after stopping writers; "
                                  "the legacy UI job does not delete canonical derived rows.")
            if r.error:row["Error"] = r.error
            failed += 1
        elif r.status in ("failed","partial"):
            failed += 1
            row["Error"] = r.error
        job.results.append(row)
        job.done += 1
    job.final_status = "partial" if failed else "done"


# ====================================================================== submit helpers

def submit_historical(ctx, symbols, from_date, to_date, use_mysql=True, use_parquet=True, trigger="manual") -> Job:
    label = f"Historical {from_date}..{to_date} ({len(symbols)} symbol(s))"
    return job_manager.submit("historical", label, lambda j: run_historical_job(j, ctx),
                              {"symbols": list(symbols), "from_date": from_date, "to_date": to_date,
                               "use_mysql": use_mysql, "use_parquet": use_parquet}, trigger)


def submit_aggregation(ctx, symbols, from_date, to_date, timeframes=None, trigger="manual") -> Job:
    label = f"Aggregation {from_date}..{to_date} ({len(symbols)} symbol(s))"
    return job_manager.submit("aggregation", label, lambda j: run_aggregation_job(j, ctx),
                              {"symbols": list(symbols), "from_date": from_date, "to_date": to_date,
                               "timeframes": timeframes}, trigger)


def submit_gapfill(ctx, targets=None, symbols=None, lookback_days=3, trigger="manual") -> Job:
    n = len(targets) if targets is not None else "scan"
    return job_manager.submit("gapfill", f"Gap-fill ({n} target(s))", lambda j: run_gapfill_job(j, ctx),
                              {"targets": targets, "symbols": symbols, "lookback_days": lookback_days}, trigger)


# ====================================================================== auto gap-filler

def load_pref() -> dict:
    try:
        return {"enabled": False, "interval_min": 5, "lookback_days": 3, **json.loads(_PREF_PATH.read_text())}
    except Exception:
        return {"enabled": False, "interval_min": 5, "lookback_days": 3}


def save_pref(pref: dict) -> None:
    try:
        _PREF_PATH.parent.mkdir(parents=True, exist_ok=True)
        _PREF_PATH.write_text(json.dumps(pref))
    except Exception as exc:
        log.warning(f"Could not save auto gap-fill preference: {exc}")


class AutoGapFiller:
    """Every `interval_min` minutes: scan stored 1m data and, if gaps exist, queue ONE gap-fill job."""

    def __init__(self, manager: JobManager):
        self._manager = manager
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._cooldown: dict = {}
        self.ctx: Optional[JobContext] = None
        self.interval_min = 5
        self.lookback_days = 3
        self.last_scan_at: Optional[str] = None
        self.last_scan_summary: str = ""
        self.last_job_id: Optional[int] = None
        self.last_error: Optional[str] = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive() and not self._stop.is_set()

    def start(self, ctx: JobContext, interval_min: int = 5, lookback_days: int = 3, persist: bool = True):
        self.ctx, self.interval_min, self.lookback_days = ctx, int(interval_min), int(lookback_days)
        if persist:
            save_pref({"enabled": True, "interval_min": self.interval_min, "lookback_days": self.lookback_days})
        if self.running:
            return
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="auto-gapfill", daemon=True)
        lifecycle.register(self._stop, self._thread)
        self._thread.start()

    def stop(self, persist: bool = True):
        self._stop.set()
        if persist:
            save_pref({"enabled": False, "interval_min": self.interval_min, "lookback_days": self.lookback_days})

    def _loop(self):
        while not self._stop.is_set():
            try:
                with lifecycle.scope(self._stop):
                    lifecycle.check()
                    self.scan_once()
            except lifecycle.WorkerInterrupted:
                break
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"
                log.warning(f"Auto gap-fill scan failed: {exc}")
            self._stop.wait(self.interval_min * 60)

    def scan_once(self) -> Optional[Job]:
        from controller.gapfill_controller import scan_mysql
        ctx = self.ctx
        self.last_scan_at = time.strftime("%Y-%m-%d %H:%M:%S")
        if ctx is None or not ctx.data_settings.storage.mysql_enabled:
            self.last_scan_summary = "MySQL storage disabled -- nothing to scan"
            return None
        if self._manager.active("gapfill"):
            self.last_scan_summary = "a gap-fill job is already queued/running"
            return None

        targets, no_baseline = scan_mysql(_engine(ctx), ctx.instruments.active_instruments(), self.lookback_days)
        now = time.time()
        fresh = [t for t in targets
                 if now - self._cooldown.get((t.internal_name, t.from_date, t.to_date), 0) > AUTO_COOLDOWN_SECONDS]
        self.last_scan_summary = (f"{len(targets)} instrument(s) with gaps, {len(fresh)} to fill now"
                                  + (f", {len(no_baseline)} never ingested (skipped)" if no_baseline else ""))
        if not fresh:
            return None
        for t in fresh:
            self._cooldown[(t.internal_name, t.from_date, t.to_date)] = now
        job = submit_gapfill(ctx, targets=fresh, trigger="auto")
        self.last_job_id = job.id
        self.last_error = None
        return job

    def status(self) -> dict:
        return {"running": self.running, "interval_min": self.interval_min, "lookback_days": self.lookback_days,
                "last_scan_at": self.last_scan_at, "last_scan_summary": self.last_scan_summary,
                "last_job_id": self.last_job_id, "last_error": self.last_error}


auto_gapfill = AutoGapFiller(job_manager)


def ensure_auto_gapfill(ctx: JobContext) -> None:
    """Call from pages: if the saved preference says ON and the filler isn't running (e.g. after a
    server restart), start it. It can only start once some page has loaded the config."""
    pref = load_pref()
    if pref.get("enabled") and not auto_gapfill.running:
        auto_gapfill.start(ctx, pref.get("interval_min", 5), pref.get("lookback_days", 3), persist=False)
