"""
ui/logging_bootstrap.py
Streamlit never runs main.py, so nothing ever called configure_logging()
and logs/market_data.log was never created (Logs page showed "no log
file"). This wires the SAME model.logging_setup.configure_logging into
the dashboard process, once per process. Relative log_dir values are
    anchored to the selected runtime profile (or the project root when no
    profile is selected), independent of the Streamlit launch directory.
"""

import logging
from pathlib import Path
from typing import Optional

from model.logging_setup import configure_logging, resolve_log_path as _resolve_log_path

_configured = False


def resolve_log_path(data_settings) -> Path:
    return _resolve_log_path(data_settings.log_dir, data_settings.log_file)


def ensure_logging(data_settings, env: Optional[object] = None) -> None:
    """env is optional (backward compatible with existing call sites)
    but required for WARNING+ log mirroring to MySQL -- without it,
    only file logging is set up."""
    global _configured
    if _configured:
        return
    log_path = resolve_log_path(data_settings)
    configure_logging(level=data_settings.log_level, log_dir=str(log_path.parent), log_file=log_path.name)
    _configured = True
    logging.getLogger("market_data.ui").info(f"Dashboard logging initialised -> {log_path}")

    if env is not None and data_settings.storage.mysql_enabled:
        from ui.db_log_handler import DatabaseLogHandler

        def _engine_factory():
            from model.storage.mysql import build_db_url, get_engine
            return get_engine(build_db_url(env.db.host, env.db.port, env.db.name, env.db.user, env.db.password))

        logging.getLogger().addHandler(DatabaseLogHandler(_engine_factory))
