"""Opt-in permanent runtime profile; path selection never creates files."""
import os
from pathlib import Path
from model.exceptions import ConfigurationError

PROJECT_ROOT = Path(__file__).resolve().parents[2]
STANDARD_CONFIGS = frozenset(("config/.env", "config/data_settings.yaml",
    "config/timeframe_settings.yaml", "config/fno_settings.yaml", "config/holidays.yaml",
    "instruments/stocks.yaml", "instruments/indices.yaml"))


def profile_home():
    value = os.environ.get("TIOS_HOME", "").strip()
    if not value:
        return None
    home = Path(value).expanduser()
    if not home.is_absolute():
        raise ConfigurationError("TIOS_HOME must be an absolute path to an existing permanent profile.")
    if not home.is_dir():
        raise ConfigurationError(f"TIOS_HOME profile directory does not exist: {home}. Copy your existing configuration and data before enabling it.")
    return home


def config_path(path, project_root=None):
    """Redirect only standard repository files; explicit custom paths stay explicit."""
    path = Path(path)
    base = Path(project_root or PROJECT_ROOT)
    home = profile_home()
    if home is None:
        return path
    try:
        relative = path.relative_to(base) if path.is_absolute() else path
    except ValueError:
        return path
    if relative.as_posix() not in STANDARD_CONFIGS:
        return path
    selected = home / relative
    if not selected.is_file():
        raise ConfigurationError(f"Required persistent profile configuration file not found: {selected}. Copy your existing configuration; no new profile was created.")
    return selected


def env_path(project_root=None):
    base = Path(project_root or PROJECT_ROOT)
    return config_path(base / "config" / ".env", base)


def state_path(relative, project_root=None):
    path = Path(relative).expanduser()
    if path.is_absolute():
        return path
    return (profile_home() or Path(project_root or PROJECT_ROOT)) / path


def runtime_dir():
    value = os.environ.get("TIOS_RUNTIME_DIR", "").strip()
    return state_path(value or "runtime")
