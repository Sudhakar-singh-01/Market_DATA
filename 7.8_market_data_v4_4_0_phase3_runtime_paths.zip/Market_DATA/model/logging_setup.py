"""
model/logging_setup.py
Centralized logging configuration. Called once at startup (main.py).
No module should call logging.basicConfig() itself -- this is the only
place that does.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def resolve_log_path(log_dir: str, log_file: str, project_root=None) -> Path:
    """Resolve configured logging independently of the process launch folder."""
    from model.config.runtime_paths import state_path
    directory = Path(log_dir).expanduser()
    if not directory.is_absolute():
        directory = state_path(directory, project_root)
    return directory / log_file


def configure_logging(level: str, log_dir: str, log_file: str) -> logging.Logger:
    """
    Configures root logging with both a console handler and a rotating
    file handler. Returns the application's top-level logger.
    Never logs secrets -- callers must ensure sensitive values are kept
    out of any log message (see model/config/env_loader.py's redacted
    __repr__ for EnvConfig as the primary safeguard).
    """
    log_path = resolve_log_path(log_dir, log_file)
    log_dir_path = log_path.parent
    log_dir_path.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(level.upper())
    root_logger.handlers.clear()  # avoid duplicate handlers if called more than once

    formatter = logging.Formatter(_LOG_FORMAT)

    console_handler = logging.StreamHandler(stream=sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    file_handler = RotatingFileHandler(log_path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    return logging.getLogger("market_data")
