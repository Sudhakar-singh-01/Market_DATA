"""
model/storage/csv.py
CSV export -- an export format, not the primary high-performance
storage layer (spec Section 8). Uses the same canonical column order
as model/storage/parquet.py so output is consistent across formats
(spec Section 29: same canonical dataset regardless of storage backend).
"""

import logging
from pathlib import Path

import pandas as pd

from model.processing.models import IST

log = logging.getLogger("market_data.storage.csv")

CSV_COLUMNS = [
    "internal_name", "fyers_symbol", "instrument_type", "exchange",
    "candle_timestamp", "timeframe", "open", "high", "low", "close",
    "volume", "source", "status",
]


def default_export_path(output_dir: str, filename: str, project_root=None) -> Path:
    """Resolve configured export output without depending on the launch folder."""
    directory = Path(output_dir).expanduser()
    if not directory.is_absolute():
        from model.config.runtime_paths import state_path
        directory = state_path(directory, project_root)
    return directory / filename


def export_candles_to_csv(candles: list, output_path: str) -> str:
    """Exports a batch of candles (spec Section 8: 'export batches')
    to one CSV file with a deterministic column order. Candles may span
    multiple instruments/timeframes/dates -- this function does not
    filter, it exports exactly what it's given; selection (instrument/
    timeframe/date-range) happens one layer up, wherever the candles
    were read from (MySQL or Parquet)."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    rows = [{
        "internal_name": c.internal_name,
        "fyers_symbol": c.fyers_symbol,
        "instrument_type": c.instrument_type,
        "exchange": c.exchange,
        "candle_timestamp": c.timestamp.astimezone(IST).isoformat(),
        "timeframe": c.timeframe,
        "open": c.open, "high": c.high, "low": c.low, "close": c.close,
        "volume": c.volume,
        "source": c.source,
        "status": c.status,
    } for c in candles]

    df = pd.DataFrame(rows, columns=CSV_COLUMNS)
    df.to_csv(path, index=False)

    log.info(f"Exported {len(rows)} candle(s) to {path}")
    return str(path)


def deterministic_export_filename(fyers_symbol: str, timeframe: str, from_date: str, to_date: str) -> str:
    safe_symbol = fyers_symbol.replace(":", "_")
    return f"{safe_symbol}_{timeframe}_{from_date}_{to_date}.csv"
