import json
from types import SimpleNamespace as NS

import pytest
from controller import storage_cli as cli


def test_authentication_precedes_catalog_access(monkeypatch, capsys):
    def deny():raise PermissionError('denied')
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', deny)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: pytest.fail('Must authenticate first'))
    assert cli.main(['backups']) == 1
    assert json.loads(capsys.readouterr().out)['error_type'] == 'PermissionError'


def test_backup_create_requires_stopped_writers_before_authentication(monkeypatch):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: pytest.fail('ack missing'))
    with pytest.raises(SystemExit) as exc:
        cli.main(['backup-create', '--plan', 'unused.json'])
    assert exc.value.code == 2


def test_preview_preserves_existing_plan_and_create_uses_reviewed_plan(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: None)
    saved = {'segment': 'CASH', 'token': 'reviewed'}
    calls = []
    service = NS(preview=lambda segment, **kw: saved,
                 create=lambda plan, **kw: calls.append((plan, kw)) or {'status': 'CHECKSUM_VERIFIED', 'restore_tested': False})
    monkeypatch.setattr('model.backup_service.BackupService', lambda catalog: service)
    path = tmp_path/'plan.json'
    assert cli.main(['backup-preview','--segment','CASH','--output',str(path)]) == 0
    assert json.loads(path.read_text()) == saved and not calls
    assert cli.main(['backup-preview','--segment','CASH','--output',str(path)]) == 1
    assert json.loads(path.read_text()) == saved
    assert cli.main(['backup-create','--plan',str(path),'--writers-stopped']) == 0
    assert calls == [(saved, {'role':'admin','writers_stopped':True})]
    assert '"restore_tested": false' in capsys.readouterr().out


def test_cleanup_preview_only_delegates_read_operation(monkeypatch):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: None)
    calls=[]
    monkeypatch.setattr('model.cleanup_service.CleanupService', lambda cat: NS(
        preview=lambda *a, **kw: calls.append((a, kw)) or {'status':'PREVIEW_ONLY'}))
    assert cli.main(['cleanup-preview','--segment','CASH','--symbol','NSE:TEST-EQ',
                     '--from','2026-10-19','--to','2026-10-19']) == 0
    assert calls == [(('CASH','NSE:TEST-EQ','2026-10-19','2026-10-19','1m'), {'role':'admin'})]


@pytest.mark.parametrize('compatible, code', [(True, 0), (False, 2)])
def test_schema_findings_have_nonzero_status_without_applying_ddl(monkeypatch, compatible, code):
    monkeypatch.setattr('controller.workflow_cli.authenticate_admin', lambda: None)
    monkeypatch.setattr('model.database_catalog.configured_catalog', lambda: None)
    monkeypatch.setattr('model.schema_management.SchemaManager', lambda cat: NS(
        preview=lambda *a, **kw: {'compatibility': {'compatible': compatible}}))
    assert cli.main(['schema','--segment','FNO']) == code
