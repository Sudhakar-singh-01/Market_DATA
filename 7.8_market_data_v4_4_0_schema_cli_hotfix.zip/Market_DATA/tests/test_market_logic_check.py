import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest
from tools import market_logic_check as check


def test_manifest_excludes_ui_and_has_no_duplicates():
    paths = [p for files in check.manifest().values() for p in files]
    assert len(paths) == len(set(paths))
    assert not any('dashboard' in p or 'workspace_shell' in p or 'mysql' in p for p in paths)


def test_source_copy_excludes_credentials_and_runtime(tmp_path, monkeypatch):
    source = tmp_path / 'source'; target = tmp_path / 'copy'; target.mkdir()
    for name in ['config/.env', 'config/.env.example', 'config/operator.json', 'config/data_settings.yaml',
                 'model/app.py', 'data/private.parquet', 'logs/log.txt', 'main.py', 'START_HERE.md', 'RELEASE_NOTES.md']:
        path = source / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_text('fixture')
    monkeypatch.setattr(check, 'ROOT', source)
    check.source_copy(target)
    assert not (target / 'config/.env').exists() and not (target / 'config/operator.json').exists()
    assert not (target / 'data').exists() and not (target / 'logs').exists()
    assert (target / 'model/app.py').is_file() and (target / 'config/.env.example').is_file()


def test_failure_does_not_hide_other_groups_or_claim_production_pass(tmp_path, monkeypatch):
    monkeypatch.setattr(check, 'source_copy', lambda p: None)
    monkeypatch.setenv('DB_PASSWORD', 'must-not-be-used')
    monkeypatch.setenv('TIOS_HOME', str(tmp_path/'operator'))
    calls = []
    def runner(command, cwd, env, stdout, stderr, timeout):
        assert 'DB_PASSWORD' not in env and 'TIOS_HOME' not in env
        assert 'tools.market_logic_guard' in command
        calls.append(command)
        xml = Path(next(x.split('=',1)[1] for x in command if x.startswith('--junitxml=')))
        failures = int(len(calls) == 1)
        xml.write_text(f'<testsuites><testsuite tests="3" failures="{failures}" errors="0" skipped="1"/></testsuites>')
        return SimpleNamespace(returncode=failures)
    report = check.run(['live', 'api'], tmp_path/'report', runner)
    assert report['status'] == 'FAILED' and len(calls) == 2
    assert report['groups'][0]['counts']['passed'] == 1
    assert report['production_verified'] is False
    assert json.loads((tmp_path/'report/summary.json').read_text())['status'] == 'FAILED'
    with pytest.raises(FileExistsError):
        check.run(['live'], tmp_path/'report', runner)


def test_network_guard_blocks_even_a_local_database_connection():
    code = '''import sys, socket
from tools.market_logic_guard import block_network
sys.addaudithook(block_network)
try:
    socket.socket().connect(('127.0.0.1', 3306))
except RuntimeError as exc:
    assert 'forbids' in str(exc)
else:
    raise AssertionError('network was not blocked')
'''
    result = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_timeout_preserves_report_and_runs_remaining_groups(tmp_path, monkeypatch):
    monkeypatch.setattr(check, 'source_copy', lambda p: None)
    calls = []
    def runner(command, **kwargs):
        calls.append(command)
        xml = Path(next(x.split('=',1)[1] for x in command if x.startswith('--junitxml=')))
        if len(calls) == 1:
            xml.write_text('<unfinished')
            raise subprocess.TimeoutExpired(command, kwargs['timeout'])
        xml.write_text('<testsuites><testsuite tests="1"/></testsuites>')
        return SimpleNamespace(returncode=0)
    report = check.run(['live', 'api'], tmp_path/'timed', runner, timeout=1)
    assert report['status'] == 'FAILED' and len(calls) == 2
    assert report['groups'][0]['exit_code'] == 124
    assert report['groups'][0]['counts'] is None
    assert report['groups'][1]['counts']['passed'] == 1


def test_windows_asyncio_socketpair_is_allowed_without_allowing_database_connections():
    code = '''import sys, socket
from tools.market_logic_guard import block_network
sys.addaudithook(block_network)
pair = getattr(socket, '_fallback_socketpair', socket.socketpair)
a,b = pair()
try:
    a.sendall(b'x')
    assert b.recv(1) == b'x'
finally:
    a.close(); b.close()
try:
    socket.socket().connect(('127.0.0.1',3306))
except RuntimeError:
    pass
else:
    raise AssertionError('database connection must remain blocked')
'''
    result = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
