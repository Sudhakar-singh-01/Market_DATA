"""One-command, isolated UI replacement acceptance suite; no live providers."""
from tools import phase9_validation as validation

UI_TESTS=(
    'tests/test_task_center.py','tests/test_workspace_shell.py',
    'tests/test_workflow_dashboard.py','tests/test_workflow_dashboard_service.py',
    'tests/test_dashboard_layer.py','tests/test_job_pages.py','tests/test_schema_dashboard.py',
    'tests/test_cleanup_dashboard.py','tests/test_recovery_dashboard.py',
    'tests/test_reported_dashboard_failures.py','tests/test_coverage.py',
    'tests/fno/test_fno_dashboard.py','tests/fno/test_fno_isolation.py',
)


def main():
    # This is a separate CLI process. Reuse the isolation and MySQL-fixture guard,
    # with a distinct manifest so tests are not duplicated across runner groups.
    original=validation.TEST_GROUPS
    try:
        validation.TEST_GROUPS={'ui_rebuild':UI_TESTS}
        return validation.main(['--groups','ui_rebuild'])
    finally:validation.TEST_GROUPS=original


if __name__=='__main__':raise SystemExit(main())
