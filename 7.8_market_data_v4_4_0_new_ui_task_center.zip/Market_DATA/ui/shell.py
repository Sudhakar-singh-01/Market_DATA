"""New application shell with a persistent multiple-task center."""
import streamlit as st

CSS='''<style>
:root {--tios-line:#334155;--tios-panel:#111c2f;--tios-muted:#b7c5d8;}
.stApp {background:#0b1220;color:#edf2fa;}
[data-testid="stSidebar"] {background:#101b2d;border-right:1px solid var(--tios-line);}
[data-testid="stMainBlockContainer"] {padding-top:2rem;padding-right:350px;max-width:1800px;}
[data-testid="stMetricValue"] {font-size:1.65rem;white-space:normal;}
.task-center {position:fixed;right:20px;top:78px;width:290px;z-index:999;background:var(--tios-panel);color:#edf2fa;border:1px solid var(--tios-line);border-radius:14px;padding:16px;box-shadow:0 12px 35px #0004;}
.task-center h3 {font-size:1rem;margin:0 0 12px;}
.task-list {max-height:65vh;overflow-y:auto;}
.task-card {border:1px solid var(--tios-line);border-left:3px solid #5eead4;border-radius:8px;padding:10px;margin-bottom:9px;font-size:.85rem;}
.task-card b,.task-card span,.task-card small {display:block;overflow-wrap:anywhere;}
.task-card span {color:#5eead4;margin:4px 0;}.task-center small {color:var(--tios-muted);font-size:.72rem;}
.task-warning {color:#fbbf24;font-size:.8rem;}
@media(max-width:1100px){[data-testid="stMainBlockContainer"]{padding-right:1.5rem;}.task-center{position:relative;right:auto;top:auto;width:auto;max-width:100%;}.task-list{max-height:35vh;}}
</style>'''


def render_header(role):
    st.session_state['new_ui_shell']=True
    st.markdown(CSS,unsafe_allow_html=True)
    st.sidebar.title('TIOS')
    st.sidebar.caption('MARKET DATA WORKSPACE')
    st.sidebar.write('Role: '+role)
    st.sidebar.caption('CASH / FNO · separate stores · IST')
    from ui.task_panel import render
    render()
