"""Backend acceptance in a disposable source copy, with no broker or MySQL access."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GROUPS = {
    'live': ('test_cash_live_regressions', 'test_websocket_idle_watchdog', 'test_idle_live_policy',
             'test_market_session_policy', 'fno/test_fno_live'),
    'history': ('test_cash_history_regressions', 'test_historical_provider_errors',
                'test_gapfill', 'test_gapfill_job', 'fno/test_fno_ingestion_regressions',
                'fno/test_fno_history_client', 'fno/test_fno_harvest', 'fno/test_fno_normalizer'),
    'aggregation': ('test_aggregation_boundaries', 'test_aggregation_reporting', 'test_market_calendar',
                    'test_cash_calendar_update', 'fno/test_fno_release3'),
    'jobs': ('test_job_state_regressions', 'test_backend_cli_outcomes', 'test_release4',
             'test_unified_workflow', 'test_workflow_integration', 'fno/test_fno_jobs',
             'fno/test_workflow_job', 'fno/test_worker_shutdown', 'fno/test_fno_cli'),
    'api': ('test_read_api', 'test_client_api_integration', 'test_market_data_client',
            'test_consumer_adapter', 'test_sma'),
    'storage': ('test_backend_read_handles', 'test_dual_store_consistency', 'test_backup_service', 'test_schema_management',
                'test_schema_compatibility', 'test_recovery_verification', 'test_cleanup_service',
                'test_cash_inventory_preview', 'test_cash_recovery', 'test_cash_restore',
                'test_storage_inventory', 'test_storage_scope', 'test_reset_service',
                'fno/test_fno_repository', 'fno/test_fno_parquet', 'fno/test_fno_reconcile'),
    'operations': ('test_storage_cli', 'test_backend_diagnostics', 'test_runtime_profile', 'test_runtime_setup',
                   'test_recovery_config_cli', 'test_coverage', 'test_windows_fixture_portability',
                   'test_phase9_validation', 'test_market_logic_check', 'fno/test_fno_foundation',
                   'fno/test_fno_symbol_master', 'fno/test_fno_chain', 'fno/test_fno_probe',
                   'fno/test_fno_rate_limiter', 'fno/test_quality_release4'),
}
SOURCE_DIRS = ('api', 'client', 'controller', 'model', 'tests', 'tools', 'database',
               'config', 'instruments', 'indicators', 'view', 'ui', 'docs', 'examples')
SUFFIXES = {'.py', '.sql', '.yaml', '.yml', '.md', '.cmd', '.toml', '.txt', '.json'}


def manifest():
    groups = {name: ['tests/' + p + '.py' for p in files] for name, files in GROUPS.items()}
    paths = [p for files in groups.values() for p in files]
    if len(paths) != len(set(paths)) or any(not (ROOT / p).is_file() for p in paths):
        raise ValueError('Backend test manifest contains duplicate or missing files')
    return groups


def source_copy(destination):
    """Tests cannot fall back to the installation's config/.env or runtime data."""
    destination = Path(destination)
    for folder in SOURCE_DIRS:
        source = ROOT / folder
        for path in source.rglob('*'):
            relative = path.relative_to(ROOT)
            if (not path.is_file() or path.is_symlink()
                    or any(p.startswith('.') or p == '__pycache__' for p in relative.parts)
                    or path.suffix not in SUFFIXES):
                continue
            # Only known configuration fixtures, never ad hoc operator JSON files.
            if folder in ('config', 'instruments') and path.suffix not in {'.py', '.yaml', '.yml'}:
                continue
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
    for name in ('main.py', 'START_HERE.md', 'RELEASE_NOTES.md'):
        shutil.copy2(ROOT / name, destination / name)
    # Some tests inspect the repository's safe example explicitly.
    shutil.copy2(ROOT / 'config/.env.example', destination / 'config/.env.example')


def safe_environment():
    env = os.environ.copy()
    prefixes = ('FYERS_', 'DB_', 'FNO_DB_', 'RECOVERY_DB_', 'TEST_FNO_DB_', 'TEST_CASH_DB_', 'FNO_TEST_DB_')
    exact = {'TIOS_HOME', 'TIOS_RUNTIME_DIR', 'CASH_DATA_ROOT', 'MARKET_DATA_API_PASSWORD',
             'MARKET_DATA_ADMIN_PASSWORD', 'USER_PASSWORD_HASH', 'ADMIN_PASSWORD_HASH',
             'PYTHONPATH', 'PYTHONHOME', 'PYTEST_ADDOPTS', 'PYTEST_PLUGINS'}
    for key in tuple(env):
        if key in exact or key.startswith(prefixes):
            env.pop(key, None)
    env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    return env


def junit_counts(path):
    root = ET.parse(path).getroot()
    suites = [root] if root.tag == 'testsuite' else list(root.iter('testsuite'))
    totals = {key: sum(int(s.get(key, 0)) for s in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}
    totals['passed'] = totals['tests'] - totals['failures'] - totals['errors'] - totals['skipped']
    return totals


def print_failure_details(xml, log):
    """Expose bounded fixture tracebacks in the console, retaining the full log."""
    details = []
    try:
        for case in ET.parse(xml).iter('testcase'):
            for node in case:
                if node.tag in ('failure', 'error'):
                    name = case.get('classname', '') + '::' + case.get('name', '')
                    details.append(name + '\n' + (node.text or node.get('message', 'No traceback')))
    except (OSError, ET.ParseError):
        pass
    if not details:
        try:
            with Path(log).open('rb') as stream:
                stream.seek(0, 2)
                stream.seek(max(0, stream.tell() - 12000))
                details = [stream.read().decode('utf-8', errors='replace')]
        except OSError:
            details = ['No readable traceback; retain the report directory.']
    text = ('\nFAILED GROUP DETAILS\n' + '\n\n'.join(details))[-16000:]
    encoding = sys.stdout.encoding or 'utf-8'
    print(text.encode(encoding, errors='backslashreplace').decode(encoding), flush=True)
    print(f'Full failure log: {log}', flush=True)


def run(groups, output, runner=subprocess.run, timeout=600):
    paths = manifest()
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    results = []
    report = {'status': 'RUNNING', 'platform': platform.system(), 'python': platform.python_version(),
              'groups': results, 'scope': 'provider-free disposable fixtures; MySQL integrations skipped; UI excluded',
              'production_verified': False, 'report_directory': str(output)}
    def save():
        report['seconds'] = round(time.monotonic() - started, 3)
        candidate = output / 'summary.tmp'
        candidate.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        candidate.replace(output / 'summary.json')
    save()
    try:
        with tempfile.TemporaryDirectory(prefix='tios-backend-') as scratch:
            project = Path(scratch) / 'Market_DATA'
            project.mkdir()
            source_copy(project)
            for name in groups:
                before = time.monotonic()
                xml = output / (name + '.xml')
                log = output / (name + '.log')
                command = [sys.executable, '-m', 'pytest', '-q', '-ra', '-p', 'tools.market_logic_guard',
                           '--junitxml=' + str(xml), *paths[name]]
                print(f'Checking {name}; log: {log}', flush=True)
                with log.open('w', encoding='utf-8') as stream:
                    try:
                        completed = runner(command, cwd=project, env=safe_environment(), stdout=stream,
                                           stderr=subprocess.STDOUT, timeout=timeout)
                        code = completed.returncode
                    except subprocess.TimeoutExpired:
                        code = 124
                        stream.write('\nGroup timed out; completion is not verified.\n')
                try:
                    counts = junit_counts(xml) if xml.is_file() else None
                except (ET.ParseError, ValueError):
                    counts = None  # interrupted XML cannot certify a completed group
                result = {'group': name, 'exit_code': code,
                          'seconds': round(time.monotonic() - before, 3), 'counts': counts,
                          'log': str(log), 'junit': str(xml)}
                results.append(result)
                save()
                print(json.dumps(result), flush=True)
                if code != 0:
                    print_failure_details(xml, log)
                # Continue independent groups so one Windows run reveals all failures.
        report['status'] = ('PASSED' if len(results) == len(groups) and results
                            and all(r['exit_code'] == 0 and r['counts'] and r['counts']['passed'] > 0
                                    and not r['counts']['failures'] and not r['counts']['errors'] for r in results)
                            else 'FAILED')
    except (KeyboardInterrupt, Exception) as exc:
        report['status'] = 'INTERRUPTED' if isinstance(exc, KeyboardInterrupt) else 'FAILED'
        report['error_type'] = type(exc).__name__
        raise
    finally:
        save()
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--groups', nargs='+', choices=tuple(GROUPS), default=list(GROUPS))
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--output', type=Path, help='New report directory; never overwrites an existing run')
    parser.add_argument('--timeout', type=int, default=600, help='Maximum seconds per group (default 600)')
    args = parser.parse_args(argv)
    if args.timeout < 1:parser.error('--timeout must be positive')
    try:
        if args.list:
            print(json.dumps(manifest(), indent=2))
            return 0
        output = args.output or ROOT / 'validation_reports' / ('backend-' + uuid.uuid4().hex)
        report = run(list(dict.fromkeys(args.groups)), output, timeout=args.timeout)
        print(json.dumps(report, indent=2))
        return 0 if report['status'] == 'PASSED' else 1
    except KeyboardInterrupt:
        print('Interrupted; completed groups and logs remain in the report directory.')
        return 130
    except Exception as exc:
        print(json.dumps({'status': 'FAILED', 'error_type': type(exc).__name__,
                          'message': 'Check the report directory, dependencies and manifest.'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
